Attribute VB_Name = "Connection"
Public adoConn As ADODB.Connection
Dim uuser, upwd, uconnect As String
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

Public Function OpenOracleConnection() As Boolean

Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String

Dim strLineno As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0
On Error GoTo errhand
    

    strUserName = "v3"
    ConnError = ""
    Set adoConn = CreateObject("Adodb.Connection")
    adoConn.CursorLocation = adUseClient
    adoConn.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    adoConn.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If adoConn.State = 1 Then ConnError = "Connected"
Exit Function

errhand:

objErrlog.LogError "ReportPurposeOnly", "DBConnection" & strLineno, Err.Number, Err.Description

If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
   

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If adoConn.State = 1 Then adoConn.Close
    Set adoConn = Nothing
     Set objError = Nothing




End Function



'Public Function OpenOracleConnection() As Boolean
'On Error GoTo errh
'Dim objdblink As Object
'Dim strpassword As String
'Dim ArrLink As Variant
'Dim objPwd As Object
'Dim resDBdate As New ADODB.Recordset
'Dim strUserid As String
'Dim strDataSource As String
'Dim strSupreUserPassword As String
'Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
'strSupreUserPassword = objPwd.getMUP()
'strUserid = objPwd.getMU()
'strDataSource = objPwd.getDS()
'
'
''************Oppening the connection to dblink*************
'
''''' calling shared property manager for dblink
' Set adoConn = CreateObject("Adodb.Connection")
'
'''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
'''    DataLink = objdblink.GetDBLink
'''    Set objdblink = Nothing
'''    ArrLink = Split(DataLink, ",", -1)
'''    If UBound(ArrLink) < 2 Then
'''        ConnError = ArrLink(0)
'''        Exit Sub
'''    ElseIf UBound(ArrLink) = 2 Then
'''        DataLink = ""
'''    ElseIf UBound(ArrLink) = 3 Then
'''        DataLink = Trim(ArrLink(3))
'''    End If
'
'    With adoConn
'
'           .ConnectionString = "user id=scott;password=tiger" & _
'            ";data source=" & strDataSource
'           .CursorLocation = adUseClient
'           .Provider = "MSDAORA"
'           .Open
'
'    End With
'    Set resDBdate = adoConn.Execute("SELECT LatestDaybegindate FROM DBDATE")
'
'    Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
'
'    strpassword = objPwd.getPassword(Format(resDBdate!LatestDaybegindate, "DD-MM-YYYY") & "/bank/city/grams")
'    ''adoConn.Close
'    Set adoConn = Nothing
'
'    ConnError = ""
'    Set adoConn = CreateObject("Adodb.Connection")
'    adoConn.CursorLocation = adUseClient
'    adoConn.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strpassword & ";User ID=" & strUserid
''    adoConn.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"
'    If adoConn.State = 1 Then ConnError = "Connected"
'
'   OpenOracleConnection = True
'  '  strSupreUserPassword = strpassword
'
'Exit Function
'errh:
'
'Screen.MousePointer = vbDefault
'  OpenOracleConnection = False
'  If Err.Number = -2147467259 Then
'        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
'            MsgBox "Please enter correct conect string or " & Chr(13) & Chr(13) & "(TNS:could not resolve service name)"
'        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Then
'            MsgBox "Server or Network not available (Check your Network/Server ) or " & Chr(13) & Chr(13) & "TNS:operation timed out "
'        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
'            MsgBox "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct" & Chr(13) & Chr(13) & "(TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
'        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
'            MsgBox "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor", vbInformation
'        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
'            message "Please Verify your systems Network connection to the Server OR" & Chr(13) & Chr(13) & "Please Verify the HOST Mentioned in the Tnsnames file is correct " & Chr(13) & Chr(13) & "(ORA-12545: Connect failed because target host or object does not exist)", vbInformation
'        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
'            IsDatabaseStarted = False
'            MsgBox "Database is NOT STARTED UP to connect. To start database please click on 'Start Up DB' button.", vbCritical, App.Title
'        Else
'            message Err.Description, vbInformation
'        End If
'    Else
'''    If VerifyConnectionWithRilRil2003 = False Then
'''        message "Unable to connect to Main User .Contact Raminfo", vbInformation
'''        Exit Function
'''    End If
'    MsgBox "Unable to Connect to Database. Please Contact Raminfo", vbCritical
'  End If
'
'
'End Function

Public Sub message(strMessage As String, strMessageStyle As String)
    MsgBox strMessage, strMessageStyle, App.Title
End Sub



