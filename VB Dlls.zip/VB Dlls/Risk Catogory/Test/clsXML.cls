VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "clsXML"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True

Option Explicit
Dim conv As ADODB.Connection
Dim resv As ADODB.Recordset
Dim ObjCont As ObjectContext
Dim strsql As String
Dim xmlNode As IXMLElement2
Dim terrColumnListArr(2000) As terrColumns
Dim intCount As Integer
Dim intCountAddr As Integer
Dim k As Integer
Dim strComment As String
Dim strCity As String
Dim intDateCnt As Integer
Dim lastUpdated1 As Date
Dim lastUpdated2 As Date
Dim lastUpdated3 As Date
Dim lastUpdated4 As Date
Dim lastUpdated5 As Date
Dim lastUpdated6 As Date
Dim strAliasName1 As String
Dim strAliasName2 As String
Dim strAliasName3 As String
Dim strAliasName4 As String
Dim strAliasName5 As String
Dim strAliasName6 As String
Dim strAliasName7 As String
Dim strAliasName8 As String
Dim strAliasName9 As String
Dim strAliasName10 As String
Dim strAliasName11 As String
Dim strAliasName12 As String
Dim strFirstName As String
Dim strSecondName As String
Dim strThirdName As String
Dim strFourthName As String
Dim strAddress1 As String
Dim strAddress2 As String
Dim strAddress3 As String
Dim strAddress4 As String
Dim strAddress5 As String
Dim strAddress6 As String
Dim strAddress7 As String
Dim strAddress8 As String
Dim strAddress9 As String
Dim strAddress10 As String
Dim strTypeOfDocument1 As String
Dim strTypeOfDocument2 As String
Dim strTypeOfDocument3 As String
Dim strDocumentDetails1 As String
Dim strDocumentDetails2 As String
Dim strDocumentDetails3 As String
Dim address As String
Dim addrStreet As String
Dim addrCity As String
Dim addrNote As String
Dim docDetail As String
Dim docDetail1 As String
Dim docDetail2 As String
Dim docDetail3 As String
Dim limiter As String
Dim stryear As String
Dim strnulldate As String
Dim nulldate As Date


Public Function ReadXML(strfile As String) As String
On Error GoTo errh
''instanciate XML DOM Object
    Dim xml As MSXML.XMLDocument
    Set xml = New MSXML.XMLDocument
       
    ''Set XML Document Path
    xml.url = strfile
    'xml.url = App.Path & "\AQList.xml"
    ''Read XML Document from root
    If DumpXMLNode(xml.root, 0) = False Then
        GoTo errh
    End If
    
    ''Inserts Data to database
    If InsertXMLDataToDB = False Then
        GoTo errh
    End If

    ReadXML = " Uploaded Successfully "
Exit Function
errh:
ReadXML = " Uploaded Failed "
 
End Function

Private Function InsertXMLDataToDB() As Boolean
On Error GoTo errh
Dim intCnt As Integer
Dim sdate As Date
'sdate = to_date(terrColumnListArr(intCnt).SYSTEMDATE, dd - mm - yyyy)

OpenOracleConnection

adoConn.Execute "insert into GENTERRORISTLISTHIST SELECT * FROM GENTERRORISTLIST"
adoConn.Execute "delete from GenTerroristList"

    For intCnt = 1 To UBound(terrColumnListArr)
    If intCnt = 165 Then
    'a = 1
    End If
    If terrColumnListArr(intCnt).DATAID = "" Then
    Else
    'intializing the values with null
    strComment = ""
    strCity = ""
    strFirstName = ""
    strSecondName = ""
    strThirdName = ""
    strFourthName = ""
    strAliasName1 = ""
    strAliasName2 = ""
    strAliasName3 = ""
    strAliasName4 = ""
    strAliasName5 = ""
    strAliasName6 = ""
    strAliasName7 = ""
    strAliasName8 = ""
    strAliasName9 = ""
    strAliasName10 = ""
    strAliasName11 = ""
    strAliasName12 = ""
    strAddress1 = ""
    strAddress2 = ""
    strAddress3 = ""
    strAddress4 = ""
    strAddress5 = ""
    strAddress6 = ""
    strAddress7 = ""
    strAddress8 = ""
    strAddress9 = ""
    strAddress10 = ""
    strTypeOfDocument1 = ""
    strTypeOfDocument2 = ""
    strTypeOfDocument3 = ""
    strDocumentDetails1 = ""
    strDocumentDetails2 = ""
    strDocumentDetails3 = ""
    
    ' Replacing the single qupote with double quotes
    Set ObjCont = GetObjectContext
    ' adoConn.BeginTrans
    strComment = Replace(terrColumnListArr(intCnt).COMMENTS, "'", "''")
    strCity = Replace(terrColumnListArr(intCnt).CITY, "'", "''")
    strFirstName = Replace(terrColumnListArr(intCnt).FIRSTNAME, "'", "''")
    strSecondName = Replace(terrColumnListArr(intCnt).SECONDNAME, "'", "''")
    strThirdName = Replace(terrColumnListArr(intCnt).THIRDNAME, "'", "''")
    strFourthName = Replace(terrColumnListArr(intCnt).FOURTHNAME, "'", "''")
    strAliasName1 = Replace(terrColumnListArr(intCnt).ALIASNAME1, "'", "''")
    strAliasName2 = Replace(terrColumnListArr(intCnt).ALIASNAME2, "'", "''")
    strAliasName3 = Replace(terrColumnListArr(intCnt).ALIASNAME3, "'", "''")
    strAliasName4 = Replace(terrColumnListArr(intCnt).ALIASNAME4, "'", "''")
    strAliasName5 = Replace(terrColumnListArr(intCnt).ALIASNAME5, "'", "''")
    strAliasName6 = Replace(terrColumnListArr(intCnt).ALIASNAME6, "'", "''")
    strAliasName7 = Replace(terrColumnListArr(intCnt).ALIASNAME7, "'", "''")
    strAliasName8 = Replace(terrColumnListArr(intCnt).ALIASNAME8, "'", "''")
    strAliasName9 = Replace(terrColumnListArr(intCnt).ALIASNAME9, "'", "''")
    strAliasName10 = Replace(terrColumnListArr(intCnt).ALIASNAME10, "'", "''")
    strAliasName11 = Replace(terrColumnListArr(intCnt).ALIASNAME11, "'", "''")
    strAliasName12 = Replace(terrColumnListArr(intCnt).ALIASNAME12, "'", "''")
    strAddress1 = Replace(terrColumnListArr(intCnt).ADDRESS1, "'", "''")
    strAddress2 = Replace(terrColumnListArr(intCnt).ADDRESS2, "'", "''")
    strAddress3 = Replace(terrColumnListArr(intCnt).ADDRESS3, "'", "''")
    strAddress4 = Replace(terrColumnListArr(intCnt).ADDRESS4, "'", "''")
    strAddress5 = Replace(terrColumnListArr(intCnt).ADDRESS5, "'", "''")
    strAddress6 = Replace(terrColumnListArr(intCnt).ADDRESS6, "'", "''")
    strAddress7 = Replace(terrColumnListArr(intCnt).ADDRESS7, "'", "''")
    strAddress8 = Replace(terrColumnListArr(intCnt).ADDRESS8, "'", "''")
    strAddress9 = Replace(terrColumnListArr(intCnt).ADDRESS9, "'", "''")
    strAddress10 = Replace(terrColumnListArr(intCnt).ADDRESS10, "'", "''")
    strTypeOfDocument1 = Replace(terrColumnListArr(intCnt).TYPEOFDOCUMENT1, "'", "''")
    strTypeOfDocument2 = Replace(terrColumnListArr(intCnt).TYPEOFDOCUMENT2, "'", "''")
    strTypeOfDocument3 = Replace(terrColumnListArr(intCnt).TYPEOFDOCUMENT3, "'", "''")
    strDocumentDetails1 = Replace(terrColumnListArr(intCnt).DOCUMENTDETAILS1, "'", "''")
    strDocumentDetails2 = Replace(terrColumnListArr(intCnt).DOCUMENTDETAILS2, "'", "''")
    strDocumentDetails3 = Replace(terrColumnListArr(intCnt).DOCUMENTDETAILS3, "'", "''")



strsql = "insert into GenTerroristList(DATAID,TYPE,VERSIONNUM,FIRSTNAME," & _
            " SECONDNAME,THIRDNAME,FOURTHNAME,UNLISTTYPE,REFERENCENUM,LISTEDON," & _
            " COMMENTS , NATIONALITY, LISTTYPE, LASTDAYUPDATED, ALIASNAME1, ALIASNAME2, " & _
            " ALIASNAME3,ALIASNAME4,ALIASNAME5,ALIASNAME6,ALIASNAME7,ALIASNAME8," & _
            " ALIASNAME9 , ALIASNAME10, ALIASNAME11, ALIASNAME12, ADDRESS1, ADDRESS2, " & _
            " ADDRESS3,ADDRESS4,ADDRESS5,ADDRESS6,ADDRESS7,ADDRESS8,ADDRESS9," & _
            " ADDRESS10,DATEOFBIRTH,PLACEOFBIRTH,CITY,STATEPROVINCE,COUNTRY," & _
            " TYPEOFDOCUMENT1,DOCUMENTDETAILS1,TYPEOFDOCUMENT2,DOCUMENTDETAILS2," & _
            " TYPEOFDOCUMENT3,DOCUMENTDETAILS3,SORTKEY,SORTKEYLASTMOD,APPLICATIONDATE," & _
            " USERID,MACHINEID,SYSTEMDATE) values(" & terrColumnListArr(intCnt).DATAID & _
            ",'" & terrColumnListArr(intCnt).TYPE & "'," & terrColumnListArr(intCnt).VERSIONNUM & ",'" & strFirstName & _
            "','" & strSecondName & "','" & strThirdName & "','" & strFourthName & "','" & terrColumnListArr(intCnt).UNLISTTYPE & _
            "','" & terrColumnListArr(intCnt).REFERENCENUM & "','" & Format(terrColumnListArr(intCnt).LISTEDON, "dd-MMM-yyyy") & "','" & strComment & "','" & terrColumnListArr(intCnt).NATIONALITY & _
            "','" & terrColumnListArr(intCnt).LISTTYPE & "','" & Format(terrColumnListArr(intCnt).LASTDAYUPDATED, "dd-MMM-yyyy") & "','" & strAliasName1 & "','" & strAliasName2 & _
            "','" & strAliasName3 & "','" & strAliasName4 & "','" & strAliasName5 & "','" & strAliasName6 & _
            "','" & strAliasName7 & "','" & strAliasName8 & "','" & strAliasName9 & "','" & strAliasName10 & _
            "','" & strAliasName11 & "','" & strAliasName12 & "','" & strAddress1 & "','" & strAddress2 & _
            "','" & strAddress3 & "','" & strAddress4 & "','" & strAddress5 & "','" & strAddress6 & _
            "','" & strAddress7 & "','" & strAddress8 & "','" & strAddress9 & "','" & strAddress10 & _
            "','" & Format(terrColumnListArr(intCnt).DATEOFBIRTH, "dd-MMM-yyyy") & "','" & terrColumnListArr(intCnt).PLACEOFBIRTH & "','" & strCity & "','" & terrColumnListArr(intCnt).STATEPROVINCE & _
            "','" & terrColumnListArr(intCnt).COUNTRY & "','" & strTypeOfDocument1 & "','" & strDocumentDetails1 & "','" & strTypeOfDocument2 & _
            "','" & strDocumentDetails2 & "','" & strTypeOfDocument3 & "','" & strDocumentDetails3 & "','" & terrColumnListArr(intCnt).SORTKEY & _
            "','" & Format(terrColumnListArr(intCnt).SORTKEYLASTMOD, "dd-MMM-yyyy") & "','" & Format(terrColumnListArr(intCnt).APPLICATIONDATE, "dd-MMM-yyyy") & "','" & terrColumnListArr(intCnt).USERID & "','" & terrColumnListArr(intCnt).MACHINEID & _
            "',sysdate)"

   adoConn.Execute strsql
   ' MsgBox terrColumnListArr(intCnt).DATAID
    ' adoConn.CommitTrans
    
    
    End If
    Next intCnt
ObjCont.SetComplete
InsertXMLDataToDB = True

Exit Function
errh:
InsertXMLDataToDB = False
'adoConn.RollbackTrans
ObjCont.SetAbort
End Function

Private Function ChildXMLNodeAddress(xmlNode As IXMLElement2, lvl As Integer) As Boolean
On Error GoTo errh
'function for store the address datails into the array

    If xmlNode.children Is Nothing Then Exit Function
    Dim kChildren As Integer, S As Integer
    kChildren = xmlNode.children.length
    If kChildren = 0 Then
    Debug.Print "Branch: " & xmlNode.tagName
    Else
    Debug.Print "Leaf: " & xmlNode.tagName & vbTab & xmlNode.Text


        If xmlNode.tagName = "STREET" Then
        addrStreet = xmlNode.Text
        End If
        If xmlNode.tagName = "CITY" Then
        addrCity = xmlNode.Text
        End If
        If xmlNode.tagName = "NOTE" Then
        addrNote = xmlNode.Text
        End If
        If xmlNode.tagName = "COUNTRY" Then
        terrColumnListArr(k).COUNTRY = xmlNode.Text
        End If

    End If
    For S = 0 To kChildren - 1
       ChildXMLNodeAddress xmlNode.children.Item(S), lvl + 1
    Next
    ChildXMLNodeAddress = True
    Exit Function
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    
    ChildXMLNodeAddress = False
    
End Function

Private Function ChildXMLNodeDocument(xmlNode As IXMLElement2, lvl As Integer) As Boolean
On Error GoTo errh
'function for store the values of document details in the array

    If xmlNode.children Is Nothing Then Exit Function
    Dim mChildren As Integer, u As Integer
    mChildren = xmlNode.children.length
    If mChildren = 0 Then
    Debug.Print "Branch: " & xmlNode.tagName
    Else
    Debug.Print "Leaf: " & xmlNode.tagName & vbTab & xmlNode.Text
        
        
        If xmlNode.tagName = "NUMBER" Then
        docDetail1 = xmlNode.Text
        End If
        If xmlNode.tagName = "ISSUING_COUNTRY" Then
        docDetail2 = xmlNode.Text
        End If
        If xmlNode.tagName = "NOTE" Then
        docDetail3 = xmlNode.Text
        End If
    End If
    For u = 0 To mChildren - 1
        If ChildXMLNodeDocument(xmlNode.children.Item(u), lvl + 1) = False Then Exit Function
    Next
    docDetail = docDetail1 + limiter + docDetail2 + limiter + docDetail3
    
    ChildXMLNodeDocument = True
    Exit Function
    
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    
    ChildXMLNodeDocument = False
    
End Function

Private Function ChildXMLNodePOB(xmlNode As IXMLElement2, lvl As Integer) As Boolean
On Error GoTo errh
'function for store the values of date of birth in the array

    If xmlNode.children Is Nothing Then Exit Function
    Dim aChildren As Integer, f As Integer
    aChildren = xmlNode.children.length
    If aChildren = 0 Then
    Debug.Print "Branch: " & xmlNode.tagName
    Else
    Debug.Print "Leaf: " & xmlNode.tagName & vbTab & xmlNode.Text

        If xmlNode.tagName = "CITY" Then
        terrColumnListArr(k).CITY = xmlNode.Text
        End If
        If xmlNode.tagName = "COUNTRY" Then
        terrColumnListArr(k).PLACEOFBIRTH = xmlNode.Text
        End If

    End If
    For f = 0 To aChildren - 1
        ChildXMLNodePOB xmlNode.children.Item(f), lvl + 1
    Next
    ChildXMLNodePOB = True
    Exit Function
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    
    ChildXMLNodePOB = False
    
End Function

Private Function ChildXMLNodeLastDayUpdated(xmlNode As IXMLElement2, lvl As Integer) As Boolean
On Error GoTo errh
'function for store the values of date of birth in the array

    If xmlNode.children Is Nothing Then Exit Function
    Dim bChildren As Integer, d As Integer
    bChildren = xmlNode.children.length
    If bChildren = 0 Then
    Debug.Print "Branch: " & xmlNode.tagName
    Else
    Debug.Print "Leaf: " & xmlNode.tagName & vbTab & xmlNode.Text

        Select Case intDateCnt
            Case 0
                lastUpdated1 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            Case 1
                lastUpdated2 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            Case 2
                lastUpdated3 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            Case 3
                lastUpdated4 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            Case 4
                lastUpdated5 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            Case 5
                lastUpdated6 = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
        End Select
        
       
    End If
    For d = 0 To bChildren - 1
        ChildXMLNodeLastDayUpdated xmlNode.children.Item(d), lvl + 1
    Next
    ChildXMLNodeLastDayUpdated = True
     intDateCnt = intDateCnt + 1
    Exit Function
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    
    ChildXMLNodeLastDayUpdated = False
    
End Function

Private Function DumpXMLNode(xmlNode As IXMLElement2, lvl As Integer) As Boolean

On Error GoTo errh
  
    ' ignore empty elements
    If xmlNode.children Is Nothing Then
    DumpXMLNode = True ''since we have to igngore
    Exit Function
    End If

    ' get child count
    Dim iChildren As Integer, i As Integer
    iChildren = xmlNode.children.length
    If xmlNode.children.Item(0).TYPE = 1 Then iChildren = 0
    
    ' nodes of type 1 can't have child nodes
    If xmlNode.children.Item(0).TYPE = 1 Then iChildren = 0
    
    ' no children? add leaf node
    If iChildren = 0 Then
        Debug.Print "Leaf: " & xmlNode.tagName & vbTab & xmlNode.Text
  
        ' have children? add branch node
        Else
        Debug.Print "Branch: " & xmlNode.tagName

            If xmlNode.tagName = "INDIVIDUAL" Or xmlNode.tagName = "ENTITY" Then
            intCountAddr = 0
            intCount = 0
            intDateCnt = 0
            k = k + 1
            addrStreet = ""
            addrCity = ""
            addrNote = ""
            strnulldate = "2001" + "-" + "01" + "-" + "01"
            nulldate = Format$(CDate(strnulldate), "dd/MMM/yyyy")
            terrColumnListArr(k).DATEOFBIRTH = nulldate
            End If
            'if tag name is INDIVIDUAL_DOCUMENT then it will go to function "ChildXMLNodeDocument"
            If xmlNode.tagName = "INDIVIDUAL_DOCUMENT" Then
            Call ChildXMLNodeDocument(xmlNode, lvl)
            terrColumnListArr(k).DOCUMENTDETAILS1 = address
            End If
            
            If xmlNode.tagName = "INDIVIDUAL" Then
            terrColumnListArr(k).TYPE = "I"
            End If
            
            If xmlNode.tagName = "ENTITY" Then
            terrColumnListArr(k).TYPE = "E"
            End If
            
            'if tag name is LAST_DAY_UPDATED then the function called in this statement pick the latest date
            If xmlNode.tagName = "LAST_DAY_UPDATED" Then
            lastUpdated1 = DateValue("00:00:00")
            lastUpdated2 = DateValue("00:00:00")
            lastUpdated3 = DateValue("00:00:00")
            lastUpdated4 = DateValue("00:00:00")
            lastUpdated5 = DateValue("00:00:00")
            lastUpdated6 = DateValue("00:00:00")
            Call ChildXMLNodeLastDayUpdated(xmlNode, lvl) 'it will pick the latest date
                If (lastUpdated1 > lastUpdated2) And (lastUpdated1 > lastUpdated3) And (lastUpdated1 > lastUpdated4) And (lastUpdated1 > lastUpdated5) And (lastUpdated1 > lastUpdated6) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated1
                End If
                If (lastUpdated2 > lastUpdated1) And (lastUpdated2 > lastUpdated3) And (lastUpdated2 > lastUpdated4) And (lastUpdated2 > lastUpdated5) And (lastUpdated2 > lastUpdated6) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated2
                End If
                If (lastUpdated3 > lastUpdated1) And (lastUpdated3 > lastUpdated2) And (lastUpdated3 > lastUpdated4) And (lastUpdated3 > lastUpdated5) And (lastUpdated3 > lastUpdated6) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated3
                End If
                If (lastUpdated4 > lastUpdated1) And (lastUpdated4 > lastUpdated2) And (lastUpdated4 > lastUpdated3) And (lastUpdated4 > lastUpdated5) And (lastUpdated4 > lastUpdated6) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated4
                End If
                If (lastUpdated5 > lastUpdated1) And (lastUpdated5 > lastUpdated2) And (lastUpdated5 > lastUpdated3) And (lastUpdated5 > lastUpdated4) And (lastUpdated5 > lastUpdated6) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated5
                End If
                If (lastUpdated6 > lastUpdated1) And (lastUpdated6 > lastUpdated2) And (lastUpdated6 > lastUpdated3) And (lastUpdated6 > lastUpdated4) And (lastUpdated6 > lastUpdated5) Then
                terrColumnListArr(k).LASTDAYUPDATED = lastUpdated6
                End If
            End If
            
            'if tag name is INDIVIDUAL_ADDRESS or ENTITY_ADDRESS then it will go to function "ChildXMLNodeAddress"
            If xmlNode.tagName = "INDIVIDUAL_ADDRESS" Or xmlNode.tagName = "ENTITY_ADDRESS" Then
            intCountAddr = intCountAddr + 1
            Call ChildXMLNodeAddress(xmlNode, lvl)
            limiter = " ,"
            'here the address is concatenation of street, city and note
            address = addrStreet + limiter + addrCity + limiter + addrNote
            
            Select Case intCountAddr
            Case 1
            terrColumnListArr(k).ADDRESS1 = address
            Case 2
            terrColumnListArr(k).ADDRESS2 = address
            Case 3
            terrColumnListArr(k).ADDRESS3 = address
            Case 4
            terrColumnListArr(k).ADDRESS4 = address
            Case 5
            terrColumnListArr(k).ADDRESS5 = address
            Case 6
            terrColumnListArr(k).ADDRESS6 = address
            Case 7
            terrColumnListArr(k).ADDRESS7 = address
            Case 8
            terrColumnListArr(k).ADDRESS8 = address
            Case 9
            terrColumnListArr(k).ADDRESS9 = address
            Case 10
            terrColumnListArr(k).ADDRESS10 = address
          
            End Select
            
            Debug.Print address
            ' MsgBox (terrColumnListArr(k).ADDRESS1)
            End If
            If xmlNode.tagName = "INDIVIDUAL_PLACE_OF_BIRTH" Then
            Call ChildXMLNodePOB(xmlNode, lvl)
            End If
        End If

    For i = 0 To iChildren - 1
        If DumpXMLNode(xmlNode.children.Item(i), lvl + 1) = False Then
        Exit Function
        End If
    Next
    
    If StoringValuesToArr(xmlNode, lvl) = False Then
    Exit Function
    End If
    
    DumpXMLNode = True
    Exit Function
    
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    
    DumpXMLNode = False

End Function


Private Function StoringValuesToArr(xmlNode As IXMLElement2, lvl As Integer) As Variant

' function for storing values into array "terrColumnListArr"
On Error GoTo errh
terrColumnListArr(k).MACHINEID = "SYSTEM"
terrColumnListArr(k).USERID = "SYSTEM"
    
    If xmlNode.tagName = "NAME_ORIGINAL_SCRIPT" Or xmlNode.tagName = "QUALITY" Then
        
        Else

        End If
    
            If xmlNode.tagName = "DATAID" Then
                terrColumnListArr(k).DATAID = xmlNode.Text
            End If
            If xmlNode.tagName = "VERSIONNUM" Then
                terrColumnListArr(k).VERSIONNUM = xmlNode.Text
            End If
            If xmlNode.tagName = "FIRST_NAME" Then
                terrColumnListArr(k).FIRSTNAME = xmlNode.Text
            End If
            If xmlNode.tagName = "SECOND_NAME" Then
                terrColumnListArr(k).SECONDNAME = xmlNode.Text
            End If
            If xmlNode.tagName = "THIRD_NAME" Then
                terrColumnListArr(k).THIRDNAME = xmlNode.Text
            End If
            If xmlNode.tagName = "FOURTH_NAME" Then
                terrColumnListArr(k).FOURTHNAME = xmlNode.Text
            End If
            If xmlNode.tagName = "UN_LIST_TYPE" Then
                terrColumnListArr(k).UNLISTTYPE = xmlNode.Text
            End If
            If xmlNode.tagName = "REFERENCE_NUMBER" Then
                terrColumnListArr(k).REFERENCENUM = xmlNode.Text
            End If
            If xmlNode.tagName = "LISTED_ON" Then
                terrColumnListArr(k).LISTEDON = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            End If
            If xmlNode.tagName = "COMMENTS1" Then
                terrColumnListArr(k).COMMENTS = xmlNode.Text
            End If
            If xmlNode.tagName = "NATIONALITY" Or xmlNode.tagName = "NATIONALITY2" Then
                terrColumnListArr(k).NATIONALITY = xmlNode.Text
            End If
            If xmlNode.tagName = "LIST_TYPE" Then
                terrColumnListArr(k).LISTTYPE = xmlNode.Text
            End If
'            If xmlNode.tagName = "LAST_DAY_UPDATED" Then
'                terrColumnListArr(k).LASTDAYUPDATED = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
'            End If
            
                Select Case intCount ' select case for Alias names
                Case 0
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 0 Then
                    terrColumnListArr(k).ALIASNAME1 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 1
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 1 Then
                    terrColumnListArr(k).ALIASNAME2 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 2
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 2 Then
                    terrColumnListArr(k).ALIASNAME3 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 3
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 3 Then
                    terrColumnListArr(k).ALIASNAME4 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 4
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 4 Then
                    terrColumnListArr(k).ALIASNAME5 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 5
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 5 Then
                    terrColumnListArr(k).ALIASNAME6 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 6
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 6 Then
                    terrColumnListArr(k).ALIASNAME7 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 7
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 7 Then
                    terrColumnListArr(k).ALIASNAME8 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 8
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 8 Then
                    terrColumnListArr(k).ALIASNAME9 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 9
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 9 Then
                    terrColumnListArr(k).ALIASNAME10 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 10
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 10 Then
                    terrColumnListArr(k).ALIASNAME11 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                Case 11
                    If xmlNode.tagName = "ALIAS_NAME" And intCount = 11 Then
                    terrColumnListArr(k).ALIASNAME12 = xmlNode.Text
                    intCount = intCount + 1
                    End If
                
                End Select

            If xmlNode.tagName = "DATE" Then
                nulldate = Format$(Mid(xmlNode.Text, 1, 10), "dd/MMM/yyyy")
                terrColumnListArr(k).DATEOFBIRTH = nulldate
            End If
            If xmlNode.tagName = "YEAR" Then
                stryear = xmlNode.Text + "-" + "01" + "-" + "01"
                nulldate = Format$(CDate(stryear), "dd/MMM/yyyy")
                terrColumnListArr(k).DATEOFBIRTH = nulldate
            End If
            If xmlNode.tagName = "STATE_PROVINCE" Then
                terrColumnListArr(k).STATEPROVINCE = xmlNode.Text
            End If
            If xmlNode.tagName = "TYPE_OF_DOCUMENT" Then
                terrColumnListArr(k).TYPEOFDOCUMENT1 = xmlNode.Text
            End If
            If xmlNode.tagName = "TYPE_OF_DOCUMENT2" Then
                terrColumnListArr(k).TYPEOFDOCUMENT2 = xmlNode.Text
            End If
            If xmlNode.tagName = "TYPE_OF_DOCUMENT3" Then
                terrColumnListArr(k).TYPEOFDOCUMENT3 = xmlNode.Text
            End If
            If xmlNode.tagName = "SORT_KEY" Then
                terrColumnListArr(k).SORTKEY = xmlNode.Text
            End If
            If xmlNode.tagName = "SORT_KEY_LAST_MOD" Then
                terrColumnListArr(k).SORTKEYLASTMOD = Format$(Mid(xmlNode.Text, 1, 10), "dd/mm/yyyy")
            End If

    
    StoringValuesToArr = True
    Exit Function
errh:
        If Err.Number <> 0 Then MsgBox Err.Number & " " & Err.Description, _
        vbInformation, App.Title
    StoringValuesToArr = False
    
    End Function
    






