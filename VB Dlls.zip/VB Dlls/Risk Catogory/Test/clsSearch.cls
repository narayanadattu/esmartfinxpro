VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "clsSearch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim resv As New ADODB.Recordset
Dim ObjCont As ObjectContext
Dim strsql As String
Dim strNameArr() As String
Dim strNameArr1 As String
Dim strNameArr2 As String
Dim strNameArr3 As String
Dim strAllNames As String
Dim strsql1 As String
Dim strsql2 As String
Dim strsql3 As String
Dim strsqlAlias As String
Dim strCheck As String
Dim blncheck As Boolean
Public Function search(strCheck) As String

'====================================================================
'Name               : searchName
'Last Modified date : 29-04-2013
'Purpose            : For Searching the names from the table having four name and ten alias name columns
'Tables used        : 1
'Created Date       : 27-04-2013
'====================================================================


strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME1 LIKE '%" & strCheck & "%')"
Set resv = adoConn.Execute(strsqlAlias)
blncheck = False
    If resv.BOF Or resv.EOF Then
    strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME2 LIKE '%" & strCheck & "%')"
    Set resv = adoConn.Execute(strsqlAlias)
    blncheck = False
        If resv.BOF Or resv.EOF Then
        strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME3 LIKE '%" & strCheck & "%')"
        Set resv = adoConn.Execute(strsqlAlias)
        blncheck = False
            If resv.BOF Or resv.EOF Then
            strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME4 LIKE '%" & strCheck & "%')"
            Set resv = adoConn.Execute(strsqlAlias)
            blncheck = False
                If resv.BOF Or resv.EOF Then
                strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME5 LIKE '%" & strCheck & "%')"
                Set resv = adoConn.Execute(strsqlAlias)
                blncheck = False
                    If resv.BOF Or resv.EOF Then
                    strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME6 LIKE '%" & strCheck & "%')"
                    Set resv = adoConn.Execute(strsqlAlias)
                    blncheck = False
                        If resv.BOF Or resv.EOF Then
                        strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME7 LIKE '%" & strCheck & "%')"
                        Set resv = adoConn.Execute(strsqlAlias)
                        blncheck = False
                            If resv.BOF Or resv.EOF Then
                            strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME8 LIKE '%" & strCheck & "%')"
                            Set resv = adoConn.Execute(strsqlAlias)
                            blncheck = False
                                If resv.BOF Or resv.EOF Then
                                strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME9 LIKE '%" & strCheck & "%')"
                                Set resv = adoConn.Execute(strsqlAlias)
                                blncheck = False
                                    If resv.BOF Or resv.EOF Then
                                    strsqlAlias = "select * from GENTERRORISTLIST where (ALIASNAME10 LIKE '%" & strNameArr1 & "%')"
                                    Set resv = adoConn.Execute(strsqlAlias)
                                    blncheck = False
                                        If resv.BOF Or resv.EOF Then
                                        Else
                                        Do While Not resv.EOF
                                        'Debug.Print (ALIASNAME10)
                                        strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME10 & ";"
                                        resv.MoveNext
                                        Loop
                                         blncheck = True
                                        End If
                                    Else
                                    Do While Not resv.EOF
                                    'Debug.Print (ALIASNAME9)
                                    strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME9 & ";"
                                    resv.MoveNext
                                    Loop
                                    blncheck = True
                                    End If
                                Else
                                Do While Not resv.EOF
                                'Debug.Print (ALIASNAME8)
                                strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME8 & ";"
                                resv.MoveNext
                                Loop
                                blncheck = True
                                End If
                            Else
                            Do While Not resv.EOF
                            'Debug.Print (ALIASNAME7)
                            strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME7 & ";"
                            resv.MoveNext
                            Loop
                            blncheck = True
                            End If
                        Else
                        Do While Not resv.EOF
                        'Debug.Print (ALIASNAME6)
                        strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME6 & ";"
                        resv.MoveNext
                        Loop
                        blncheck = True
                        End If
                    Else
                    Do While Not resv.EOF
                    'Debug.Print (ALIASNAME5)
                    strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME5 & ";"
                    resv.MoveNext
                    Loop
                    blncheck = True
                    End If
                Else
                Do While Not resv.EOF
                'Debug.Print (ALIASNAME4)
                strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME4 & ";"
                resv.MoveNext
                Loop
                blncheck = True
                End If
            Else
            Do While Not resv.EOF
            'Debug.Print (ALIASNAME3)
            strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME3 & ";"
            resv.MoveNext
            Loop
            blncheck = True
            End If
        Else
        Do While Not resv.EOF
        'Debug.Print (ALIASNAME2)
        strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME2 & ";"
        resv.MoveNext
        Loop
        blncheck = True
        End If
    Else
    Do While Not resv.EOF
    'Debug.Print (ALIASNAME1)
    strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & "~" & resv!ALIASNAME1 & ";"
    Debug.Print (strAllNames)
    resv.MoveNext
    Loop
    blncheck = True
    End If
    
End Function

Public Function searchName(strName) As String

strNameArr1 = ""
strNameArr2 = ""
strNameArr3 = ""
strNameArr = Split(strName, " ", 3) ' splitting the name into 3 parts
strNameArr1 = strNameArr(0)
'Debug.Print strNameArr1
    If Not strNameArr(0) = strName Then
        strNameArr2 = strNameArr(1)
        'Debug.Print strNameArr2
        If Not strName = strNameArr1 + " " + strNameArr2 Then
            strNameArr3 = strNameArr(2)
            'Debug.Print strNameArr3
        End If
    End If

OpenOracleConnection
    'adoConn.BeginTrans
    Set ObjCont = GetObjectContext
    strsql = "select * from GENTERRORISTLIST where (FIRSTNAME LIKE '%" & UCase(strName) & "%') OR (SECONDNAME " & _
    " LIKE '%" & UCase(strName) & "%') OR (THIRDNAME LIKE '%" & UCase(strName) & "%')" & _
    " OR (FOURTHNAME LIKE '%" & UCase(strName) & "%')"
    Set resv = adoConn.Execute(strsql)
    If resv.BOF Or resv.EOF Then 'alias name
        strCheck = strName
        Call search(strCheck)
        If blncheck = True Then
            GoTo lastline
        End If
        If resv.BOF Or resv.EOF Then ' it checks the names with first string in the name
            strsql1 = "select * from GENTERRORISTLIST where (FIRSTNAME LIKE '%" & UCase(strNameArr1) & "%')" & _
            "OR (SECONDNAME LIKE '%" & UCase(strNameArr1) & "%')OR (THIRDNAME LIKE '%" & UCase(strNameArr1) & "%')" & _
            "OR (FOURTHNAME LIKE '%" & UCase(strNameArr1) & "%')"
            Set resv = adoConn.Execute(strsql1)
            If resv.BOF Or resv.EOF Then ' it checks the alias names with first string in the name
                strCheck = strNameArr1
                Call search(strCheck)
                If blncheck = True Then
                    GoTo lastline
                End If
                If (resv.BOF Or resv.EOF) And (strNameArr2 <> "") Then 'it checks the names with second string in the name
                    strsql2 = "select * from GENTERRORISTLIST where (FIRSTNAME LIKE '%" & UCase(strNameArr2) & "%')" & _
                    "OR (SECONDNAME LIKE '%" & UCase(strNameArr2) & "%')OR (THIRDNAME LIKE '%" & UCase(strNameArr2) & "%')" & _
                    "OR FOURTHNAME LIKE '%" & UCase(strNameArr2) & "%'"
                    Set resv = adoConn.Execute(strsql2)
                    If (resv.BOF Or resv.EOF) And (strNameArr2 <> "") Then 'it checks the alias names with second string in the name
                        strCheck = strNameArr2
                        Call search(strCheck)
                        If blncheck = True Then
                            GoTo lastline
                        End If
                        If (resv.BOF Or resv.EOF) And (strNameArr3 <> "") Then ' it checks the name with third string in the name
                            strsql3 = "select * from GENTERRORISTLIST where (FIRSTNAME LIKE '%" & UCase(strNameArr3) & "%')" & _
                            "OR (SECONDNAME LIKE '%" & UCase(strNameArr3) & "%') OR (THIRDNAME LIKE '%" & UCase(strNameArr3) & "%') " & _
                            "OR FOURTHNAME LIKE '%" & UCase(strNameArr3) & "%'"
                            Set resv = adoConn.Execute(strsql3)
                            If (resv.BOF Or resv.EOF) And (strNameArr3 <> "") Then ' it checks the alias name with third string in the name
                                strCheck = strNameArr3
                                Call search(strCheck)
                                If blncheck = True Then
                                    GoTo lastline
                                End If
                                If resv.BOF Or resv.EOF Then ' it checks the alias names
                                MsgBox ("no records found")
                                End If
                            Else
                            Do While Not resv.EOF ' prints the names that are match to third string
                            'Debug.Print (resv!DATAID & " " & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME)
                            strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & ";"
                            resv.MoveNext
                            Loop
                            End If ' for third string
                        End If
                    Else
                    Do While Not resv.EOF ' prints the names that are match to second string
                    'Debug.Print (resv!DATAID & " " & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME)
                    strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & ";"
                    resv.MoveNext
                    Loop
                    End If ' for second string
                End If
            Else
            Do While Not resv.EOF ' prints the names that are match to first string
            'Debug.Print (resv!DATAID & " " & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME)
            strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & ";"
            resv.MoveNext
            Loop
            End If ' for first string
        End If
    Else
    Do While Not resv.EOF ' prints the names that are match to name
    'Debug.Print (resv!DATAID & " " & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME)
    strAllNames = strAllNames & resv!DATEOFBIRTH & "~" & resv!FIRSTNAME & " " & resv!SECONDNAME & " " & resv!THIRDNAME & " " & resv!FOURTHNAME & ";"
    resv.MoveNext
    Loop
    End If
lastline:

    'adoConn.CommitTrans
    ObjCont.SetComplete
    If strAllNames = "" Then
    strAllNames = " " + "~" + " No Records Found;"
    End If
    searchName = UCase(strAllNames)
'    MsgBox (strAllNames)
    Exit Function
errh:
    searchName = False

End Function


