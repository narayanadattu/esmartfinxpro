VERSION 5.00
Begin VB.Form frmRiskCategory 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox lstnames 
      Height          =   1425
      Left            =   480
      TabIndex        =   2
      Top             =   1320
      Width           =   2655
   End
   Begin VB.TextBox txtnames 
      Height          =   495
      Left            =   480
      TabIndex        =   1
      Top             =   480
      Width           =   2055
   End
   Begin VB.CommandButton cmdSearch 
      Caption         =   "Search"
      Height          =   495
      Left            =   2760
      TabIndex        =   0
      Top             =   360
      Width           =   1455
   End
End
Attribute VB_Name = "frmRiskCategory"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub cmdSearch_Click()
Dim blnSearch As Boolean
Dim strsearch As String
Dim strnamesarr(10) As String
Dim objSearch As New prjTerroristdll.clsSearch



    strsearch = objSearch.searchName(txtnames.Text)
    MsgBox (strsearch)
'    strnamesarr = Split(strsearch, ";")
'    For i = 0 To ub
'    lstnames.AddItem strnamesarr(i)
'    Next i
End Sub
