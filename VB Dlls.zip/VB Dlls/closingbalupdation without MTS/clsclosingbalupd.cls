VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "clsclosingbalupd"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim objErrlog As Object
Public ConnError As String 'error string
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim AdoRs() As ADODB.Recordset   '    Multiple Recordset Objects
Dim Rstemp As ADODB.Recordset
Dim objdblink As Object
Dim objError As Object
Dim objTrans As Object
Dim ICount As Integer
Dim DataLink As String
Dim ArrLink As Variant
Dim StrCondition As String
Dim ConnTime As String
Dim BrCode As String
Dim MachID As String
Dim Userid As String
Dim arrerr As Variant
Dim errobj As Object
'Dim objContext As ObjectContext
Dim strComponent As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim ArrError As Variant
Dim ErrNum As String
Dim errDesc As String
Dim strstack As String


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String

strSupreUserPassword = "RamSmart2020"
strUserid = "v3"
strDataSource = "v3"
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
    
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection
    
    'AdoConnObj.ConnectionTimeout = 300
    
    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:
strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserid = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "proclosingbalupd", "DBConnection" & strLineno, Err.Number, Err.Description & " : Stack : " & strstack

   
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objErrlog.ErrorProcess(ErrNum, errDesc, " : Stack : " & Replace(strstack, "'", "''"), strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Set objError = Nothing

End Sub

Public Function UpdateClosingBalances(strBranchCode As String, strCurrcd As String, strmodid As String, _
strglcode As String, straccno As String, dtfrmdate As Date, dtApplicationDate As Date, Optional strDayTran As String) As String
On Error GoTo Errhandler
Dim strsql As String
Dim amt As Double
Dim dblamttmp As Double
Dim strupd As String
Dim strtable As String
Dim strtablebal As String
Dim intreccnt As Integer
Dim dbltempbal As Double
dbltempbal = 0
Dim i As Integer
'Set objContext = GetObjectContext

If Trim(strDayTran) = "" Or Trim(strDayTran) = "TRAN" Then
    strtable = strmodid & "TRAN"
ElseIf Trim(strDayTran) = "TRANDAY" Then
    strtable = strmodid & "TRANDAY"
    dtfrmdate = dtApplicationDate
End If

strtablebal = strmodid & "BALANCE"
ConnError = ""
Call DBConnection

If ConnError <> "Connected" Then GoTo Errhandler

Dim rsbal As ADODB.Recordset
Dim strbal As String
Dim dblbal As Double
Dim dbldyaendbal As Double
dblbal = 0
AdoConnObj.BeginTrans

strbal = "select nvl(curbal,0) curbal  from " & strtablebal & " where accno ='" & straccno & "' and " & _
" glcode ='" & strglcode & "' and branchcode ='" & strBranchCode & "' and " & _
" currencycode = '" & strCurrcd & "'"

Set rsbal = AdoConnObj.Execute(strbal)

If Not rsbal.EOF And Not rsbal.BOF Then
    dbltempbal = rsbal!curbal
End If

If Trim(strDayTran) = "TRANDAY" Then
strbal = "SELECT  SUM(AMOUNT) Daybal FROM " & strtable & _
" WHERE ACCNO='" & straccno & "' AND GLCODE='" & strglcode & "' AND BRANCHCODE='" & strBranchCode & "'"

Set rsbal = AdoConnObj.Execute(strbal)

dbltempbal = dbltempbal + rsbal!Daybal

End If

strsql = "SELECT branchcode,currencycode,glcode,accno,nvl(amount,0) amount, NVL(dayendbal,0) Balance " & _
" ,applicationdate,remarks,modeoftran,chqno,batchno,tranno,Chqfvg,NVL(MSTNO,1) mstno " & _
" FROM " & strtable & " WHERE BRANCHCODE='" & strBranchCode & "' AND currencycode = '" & strCurrcd & "' and " & _
" GLCODE='" & strglcode & "' AND  accno='" & straccno & "' AND " & _
"APPLICATIONDATE >= TO_DATE('" & Format(dtfrmdate, "dd-MMM-yyyy") & "','dd-Mon-yyyy') AND " & _
" APPLICATIONDATE<=TO_DATE('" & Format(dtApplicationDate, "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
" ORDER BY   APPLICATIONDATE DESC,NVL(mstno,1) DESC,batchno DESC ,tranno DESC"

Set Rstemp = AdoConnObj.Execute(strsql)

If Not Rstemp.EOF And Not Rstemp.BOF Then
    Rstemp.MoveFirst
    intreccnt = 0
    intreccnt = Rstemp.RecordCount
    If intreccnt > 0 Then
      dbldyaendbal = dbltempbal
      strupd = "update " & strtable & " set dayendbal = " & dbldyaendbal & " where " & _
                    " BRANCHCODE='" & Rstemp!BranchCode & "' AND currencycode = '" & Rstemp!currencycode & "' and " & _
                    " GLCODE='" & Rstemp!glcode & "' AND  accno='" & Rstemp!ACCNO & "' AND " & _
                    " APPLICATIONDATE=TO_DATE('" & Format(Rstemp!ApplicationDate, "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
                    " and batchno = " & Rstemp!batchno & " and tranno = " & Rstemp!tranno
                    
        AdoConnObj.Execute (strupd)
        dblamttmp = 0
        dblamttmp = Rstemp!amount
        Rstemp.MoveNext
        For i = 0 To intreccnt - 2
              amt = 0
              dbldyaendbal = 0
                  If dblamttmp < 0 Then
                   
                           amt = Abs(dblamttmp)
                           dbldyaendbal = dbltempbal + amt
                           strupd = "update " & strtable & " set dayendbal = " & dbldyaendbal & " where " & _
                           " BRANCHCODE='" & Rstemp!BranchCode & "' AND currencycode = '" & Rstemp!currencycode & "' and " & _
                           " GLCODE='" & Rstemp!glcode & "' AND  accno='" & Rstemp!ACCNO & "' AND " & _
                           " APPLICATIONDATE=TO_DATE('" & Format(Rstemp!ApplicationDate, "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
                           " and batchno = " & Rstemp!batchno & " and tranno = " & Rstemp!tranno
                       
                   ElseIf dblamttmp > 0 Then
                       
                           amt = dblamttmp
                           dbldyaendbal = dbltempbal - amt
                           strupd = "update " & strtable & " set dayendbal = " & dbldyaendbal & " where " & _
                           " BRANCHCODE='" & Rstemp!BranchCode & "' AND currencycode = '" & Rstemp!currencycode & "' and " & _
                           " GLCODE='" & Rstemp!glcode & "' AND  accno='" & Rstemp!ACCNO & "' AND " & _
                           " APPLICATIONDATE=TO_DATE('" & Format(Rstemp!ApplicationDate, "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
                           " and batchno = " & Rstemp!batchno & " and tranno = " & Rstemp!tranno
                
                   End If
                dbltempbal = dbldyaendbal
                AdoConnObj.Execute (strupd)
                dblamttmp = 0
                dblamttmp = Rstemp!amount
                Rstemp.MoveNext
        Next i
    End If
End If

If Rstemp.State = 1 Then
    Rstemp.Close
    Set Rstemp = Nothing
End If


UpdateClosingBalances = "Updation Successfull"
'objContext.SetComplete
AdoConnObj.CommitTrans

If AdoConnObj.State = 1 Then
    AdoConnObj.Close
    Set AdoConnObj = Nothing
End If


Exit Function
Errhandler:
AdoConnObj.RollbackTrans
'objContext.SetAbort
UpdateClosingBalances = Err.Description

strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

objErrlog.LogError "proclosingbalupd", "UpdateClosingBalances", Err.Number, Err.Description & " Stack: " & strstack & "  SQL Query: " & strsql & " : Update Statement : " & strupd
''If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

If ConnError <> "Connected" Then

'*************Connection Failed************
    If Err.Number = 0 Then
        '''''ConnError = "Connection Failed !"
        ConnError = ConnError
    Else
        ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    End If
Else
        If strComponent = "" Then
        strComponent = "proclosingbalupd.clsclosingbalupd / UpdateClosingBalances"
        End If
        
        If Err.Number = -2147467259 Then
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Oracle Error"
        ElseIf UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Oracle Error"
            
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Client Error " & Err.Description
        End If
    clntDesc = "Records Could Not Be Retrieved Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    If errDesc = "" Then
    errDesc = "abc"
    End If
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc & " : Stack : " & Replace(strstack, "'", "''") & " SQL Query :  " & Replace(strsql, "'", "''"), strComponent, BrCode, Userid, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
     ReDim ArrError(0, 2)
        ConnError = clntDesc
  
End If

'UpdateClosingBalances = Trim(Replace(Replace(Replace(Replace(ConnError, Chr(13), ""), vbNewLine, ""), vbCrLf, ""), ":", ""))
'UpdateClosingBalances = ConnError
End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
