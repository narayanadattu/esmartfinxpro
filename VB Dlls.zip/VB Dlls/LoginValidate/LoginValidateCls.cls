VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "LoginValidateCls"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim ObjContext As ObjectContext
Dim objQuery As Object
Dim RsRec  As ADODB.Recordset
Dim RsLiamc As ADODB.Recordset
Dim Rsappdt As ADODB.Recordset
Dim rs As ADODB.Recordset
Dim StrSql As String
Dim StrBankName As String
Dim StrLicense As String
Dim StrAMC As String
Dim DtLicFrmDt As Date
Dim DtLicToDt As Date
Dim DtAMCFrmDt As Date
Dim DtAMCToDt As Date
Dim strliamc As String  '' L -- License , A -- AMC
Dim dtappdt As Date
Dim dtfrmdt As Date
Dim dttodt As Date
Dim strbrcode As String
Dim strusermode As String
Dim strmessage As String
Dim strDtlicfeepend As String
Dim strDtamcfeepend As String
Dim curdate As Date

Public Function LoginValidate(UsrId As String) As String
Dim TransResult As String
On Error GoTo ErrHand
   Dim dbldiffdays As Double
LoginValidate = ""
strDtlicfeepend = ""
strliamc = ""
Set ObjContext = GetObjectContext
Set objQuery = ObjContext.CreateInstance("ReportPurposeOnly.Reportonly")

    StrSql = "select distinct a.branchcode,a.GROUPID from genusermst a, genbankbranchmst b where " & _
    " a.branchcode=b.branchcode and upper(a.userid)='" & CStr(UCase(UsrId)) & "'"

 Set rs = objQuery.SingleSelectStat(StrSql)
        
        If Not rs.EOF And Not rs.BOF Then
            strbrcode = rs(0).Value
            strusermode = rs(1).Value
        Else
            strbrcode = ""
            strusermode = ""
        End If
 
Set RsRec = CreateObject("ADODB.Recordset")
StrSql = "SELECT DEPCERTIFICATE FROM genbankparm"
Set RsRec = objQuery.SingleSelectStat(StrSql)
          If Not RsRec.EOF And Not RsRec.BOF Then
             StrBankName = IIf(IsNull(RsRec!DEPCERTIFICATE), "", RsRec!DEPCERTIFICATE)
           End If
           
           If StrBankName = "" Then
           LoginValidate = "Noo~Bank Name Is Not Set"
           GoTo EndofFile
           End If
           
    '' Licence and AMC EXPIRY Dates
    '' Kuppam       -- 30-06-2017   -   AMC          ( Single Branch )  - software changed
    
   
    '' Dharmavaram  -- 19-10-2019   -   AMC          ( Single Branches)
    '' Palamoor     -- 31-10-2019   -   AMC          ( Two Branches )
    '' Nellore      -- 21-11-2019   -   AMC          ( Two Branches)
    '' Salur        -- 31-12-2019   -   AMC          ( Single Branch+ATM)
    '' Eluru        -- 14-02-2019   -   AMC          ( Four Branches )
    '' Swarna       -- 31-03-2019   -   AMC          ( SINGLE BRANCH )
    '' Maharaja     -- 30-04-2019   -   AMC          ( Five BRANCHES + Mobile+IMPS )
    '' Amalapuram   -- 15-06-2019   -   AMC          ( Single Branch) -- AMC increase @10% every two years
    '' GUNTUR       -- 31-08-2019   -   AMC          ( SINGLE BRANCH)

'Set RsLiamc = CreateObject("ADODB.Recordset")
'StrSql = "SELECT LICENAMC FROM genbankbranchmst where branchcode ='" & strbrcode & "'"
'Set RsLiamc = objQuery.SingleSelectStat(StrSql)
'        If RsLiamc.RecordCount > 0 Then
'            If Not RsLiamc.EOF And Not RsLiamc.BOF Then
'               strliamc = IIf(IsNull(RsLiamc!LICENAMC), "", RsLiamc!LICENAMC)
'              Else
'               strliamc = ""
'            End If
'         Else
'            strliamc = ""
'        End If

Set Rsappdt = CreateObject("ADODB.Recordset")
StrSql = "SELECT to_char(applicationdate,'dd-Mon-yyyy') appdate  FROM genapplicationdatemst " & _
" where branchcode ='" & strbrcode & "'"
Set Rsappdt = objQuery.SingleSelectStat(StrSql)
        If Rsappdt.RecordCount > 0 Then
            If Not Rsappdt.EOF And Not Rsappdt.BOF Then
               dtappdt = Rsappdt!appdate
            End If
        End If


LoginValidate = GetBankData(UCase(StrBankName), strbrcode)
If LoginValidate <> "Data Present" Then
GoTo EndofFile
End If
        If strliamc = "L" Then  '' license
            dtfrmdt = DtLicFrmDt
            dttodt = DtLicToDt
        ElseIf strliamc = "A" Then '' AMC
            dtfrmdt = DtAMCFrmDt
            dttodt = DtAMCToDt
        Else
            LoginValidate = "Noo~License Or AMC Not Set"
            GoTo EndofFile
        End If
        
    '' before License or AMC is expired
    ''' start before expiry of license or AMC
 If CDate(dtappdt) >= CDate(dtfrmdt) And CDate(dtappdt) <= CDate(dttodt) Then
    dbldiffdays = DateDiff("d", dtappdt, dttodt)
    If dbldiffdays <= 7 Then        ''' below 7 days
        If strliamc = "A" Then
        LoginValidate = "Mes~Your AMC Is Going To Expire On " & Format(dttodt, "dd-MMM-yyyy") & ", " & _
        " Please Renew It"
        Else
        LoginValidate = "Mes~Your License Is Going To Expire On " & Format(dttodt, "dd-MMM-yyyy") & "," & _
        " Please Enter Into AMC"
        End If
    End If ''dbldiffdays
 End If  ''CDate(dtappdt) >= CDate(dtfrmdt) And CDate(dtappdt) <= CDate(dttodt)
 ''' end before expiry of license or AMC
 
 ''after license or AMC is expired
 ''' start appdate is greater than expiry date
 If CDate(dtappdt) >= CDate(dttodt) Then
  dbldiffdays = DateDiff("d", dttodt, dtappdt)
    If dbldiffdays <= 4 Then        ''' below 4 days
        If strliamc = "A" Then
            LoginValidate = "Mes~Your AMC Is Expired On " & Format(dttodt, "dd-MMM-yyyy") & ", Please " & _
            " Renew Your AMC Before " & Format(DateAdd("d", 7, dttodt), "dd-MMM-yyyy") & " To " & _
            " Extend Our Services "
        Else
            LoginValidate = "Mes~Your License Is Expired On " & Format(dttodt, "dd-MMM-yyyy") & ", Please" & _
            " Enter Into AMC Before " & Format(DateAdd("d", 7, dttodt), "dd-MMM-yyyy")
        End If
    ElseIf dbldiffdays >= 5 And dbldiffdays <= 7 Then  ''' above 5 days below 7 days
        If strliamc = "A" Then
            LoginValidate = "Mes~Your AMC Is Expired On " & Format(dttodt, "dd-MMM-yyyy") & ", Please" & _
            " Renew Your AMC Before " & Format(DateAdd("d", 7, dttodt), "dd-MMM-yyyy") & " To " & _
            " Extend Our Services "
         Else
            LoginValidate = "Mes~Your License Is Expired On " & Format(dttodt, "dd-MMM-yyyy") & ", Please" & _
            " Enter Into AMC Before " & Format(DateAdd("d", 7, dttodt), "dd-MMM-yyyy") & " For " & _
            " Extending Support "
         End If
   
    Else
        If strliamc = "A" Then
            LoginValidate = "NoA~Your AMC Period Is Expired, Please Contact Raminfo Ltd."
        Else
            LoginValidate = "NoL~Your License Period Is Expired, Please Contact Raminfo Ltd."
        End If ''strliamc = "A"
    End If ''dbldiffdays
 End If ''CDate(dtappdt) >= CDate(dttodt)
 ''' end appdate is greater than expiry date
 
 '' start license pending fee
 '' application date less than license fee pending cut off date
 If IsDate(strDtlicfeepend) Then
    If CDate(dtappdt) <= CDate(strDtlicfeepend) Then
    
       dbldiffdays = DateDiff("d", dtappdt, strDtlicfeepend)
       
        If dbldiffdays <= 7 Then   '' before 7 days of cut off date
            LoginValidate = "Mes~Your License Fee Is Pending, Please Pay On" & _
            " Before  " & Format(strDtlicfeepend, "dd-MMM-yyyy") & ". To Extending Services "
        End If ''dbldiffdays <= 7
       
       ElseIf CDate(dtappdt) > CDate(strDtlicfeepend) Then ''  when app date greater than cut off date
        
          LoginValidate = "NoP~License Fee Is Not Paid, Please Contact Raminfo Ltd. To Extend " & _
          "Our Services"
          
      End If '' CDate(dtappdt) <= CDate(strDtlicfeepend)
End If '' IsDate(strDtlicfeepend)
'' end license pending fee

 '' start AMC pending fee
 '' application date less than AMC fee pending cut off date
 If IsDate(strDtamcfeepend) Then
    If CDate(dtappdt) <= CDate(strDtamcfeepend) Then
    
       dbldiffdays = DateDiff("d", dtappdt, strDtamcfeepend)
       
        If dbldiffdays <= 7 Then   '' before 7 days of cut off date
            LoginValidate = "Mes~Your AMC Fee Is Pending, Please Pay On" & _
            " Before  " & Format(strDtamcfeepend, "dd-MMM-yyyy") & ". To Extending Services "
        End If ''dbldiffdays <= 7
       
       ElseIf CDate(dtappdt) > CDate(strDtamcfeepend) Then ''  when app date greater than cut off date
        
          LoginValidate = "NoP~AMC Fee Is Not Paid, Please Contact Raminfo Ltd. To Extend " & _
          "Our Services"
          
      End If '' CDate(dtappdt) <= CDate(strDtamcfeepend)
End If '' IsDate(strDtamcfeepend)
'' end AMC pending fee


''  system date > expiry date
curdate = Now
If CDate(curdate) > CDate(dttodt) Then
 dbldiffdays = DateDiff("d", dttodt, curdate)
  If dbldiffdays > 7 Then
        If dbldiffdays <= 10 Then    '' before 10 days of cut off date
            LoginValidate = "Mes~"
            Else
            LoginValidate = "DLL~Your AMC Period Is Expired, Please Contact SAS Ltd."
        End If ''dbldiffdays <= 10
End If
End If


If (Mid(LoginValidate, 1, 3) <> "NoA") Or (Mid(LoginValidate, 1, 3) <> "NoL") Or (Mid(LoginValidate, 1, 3) <> "NoP") Then
    If strusermode = "ADMIN" Or strusermode = "MGR" Or strusermode = "CASH" Or strusermode = "OFF" Then
    Else                         '' for user modes clerks, cashiers, data entry operators
    LoginValidate = "Yes"
    End If
Else
End If

EndofFile:
ObjContext.SetComplete

Set ObjContext = Nothing
Set objQuery = Nothing

Exit Function
ErrHand:
ObjContext.SetAbort

Set ObjContext = Nothing
Set objQuery = Nothing
                                
If Trim(TransResult) <> "" Then

'*************Connection Failed************
    TransResult = Replace(TransResult, Chr(10), "")
    TransResult = Replace(TransResult, Chr(13), "")
    LoginValidate = TransResult
 Else
LoginValidate = Err.Number & Err.Description
LoginValidate = Replace(LoginValidate, Chr(10), "")
LoginValidate = Replace(LoginValidate, Chr(13), "")
End If

End Function

Private Function GetBankData(strbanknm As String, strbrcd As String) As String
GetBankData = ""
'' START MAHARAJA COOPERATIVE URBAN BANK
    If strbanknm = UCase("MAHARAJA") Then
    
   
    If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A  (set by raminfo)
            
            DtLicFrmDt = "10-Apr-2014"
            DtLicToDt = "09-Apr-2016"
            
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected set by raminfo
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
      ElseIf strbrcd = "100" Then
            strliamc = "A"            '' License -- L or AMC - A  (set by raminfo)
            
            DtLicFrmDt = "10-Apr-2014"
            DtLicToDt = "09-Apr-2016"
            
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected set by raminfo
            '' strDtlicfeepend = "16-Apr-2015"
              GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A  (set by raminfo)
            
            DtLicFrmDt = "10-Apr-2014"
            DtLicToDt = "09-Apr-2016"
            
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected set by raminfo
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "102" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
           DtLicFrmDt = "10-Apr-2014"
            DtLicToDt = "09-Apr-2016"
            
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "103" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "10-Apr-2014"
            DtLicToDt = "09-Apr-2016"
            
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            ''if cust need to chage then set this dates
            ''DtLicFrmDt = "07-Dec-2014"
            ''DtLicToDt = "06-Dec-2016"
            
            ''DtAMCFrmDt = "07-Dec-2016"     ''For One Year
            ''DtAMCToDt = "06-Dec-2017"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "104" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"  ''set later it as '10-apr-2016
            DtAMCToDt = "30-Apr-2027"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "105" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "106" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "107" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "108" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "109" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "110" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
             ElseIf strbrcd = "111" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
             ElseIf strbrcd = "112" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
             ElseIf strbrcd = "113" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
             ElseIf strbrcd = "114" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
             ElseIf strbrcd = "115" Then
            
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "10-Apr-2016"
            DtLicToDt = "09-May-2017"
           
            DtAMCFrmDt = "05-Apr-2016"   ''set later it as '30-apr-2017
            DtAMCToDt = "30-Apr-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END MAHARAJA COOPERATIVE URBAN BANK
        
    '' START NELLORE COOPERATIVE URBAN BANK IS UNDER LICENSE
    ElseIf strbanknm = UCase("NELLORE") Then
    
    If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            ''License fee paid upto 21-nov-2016 --warranty perriod is 22-11-2013 to 21-11-2015
            
            DtLicFrmDt = "22-Nov-2014"
            DtLicToDt = "21-Nov-2016"
            
            DtAMCFrmDt = "22-Nov-2016"  ''AMC will start on 22-11-2016
            DtAMCToDt = "21-Nov-2026"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "30-Nov-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            ''License fee paid upto 21-nov-2016 --warranty perriod is 22-11-2013 to 21-11-2015
             
            DtLicFrmDt = "22-Nov-2014"
            DtLicToDt = "21-Nov-2016"
            
            DtAMCFrmDt = "22-Nov-2016"  ''AMC will start on 22-11-2016
            DtAMCToDt = "21-Nov-2026"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "30-Nov-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "102" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "22-Nov-2014"
            DtLicToDt = "21-Nov-2016"
            
            DtAMCFrmDt = "22-Nov-2016"   ''AMC will start on 22-11-2016
            DtAMCToDt = "21-Nov-2026"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "30-Nov-2016"
            GetBankData = "Data Present"
             GoTo EndOfFunction
       Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
         End If '' strbrcd
    '' END NELLORE COOPERATIVE URBAN BANK
    
    '' START PALAMOOR COOPERATIVE URBAN BANK  (This bank under AMC)
     ElseIf strbanknm = UCase("PCUB") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "21-Aug-2013"
            DtLicToDt = "31-Oct-2014"
            
            DtAMCFrmDt = "01-Nov-2016"      '' AMC Received for yearly
            DtAMCToDt = "31-Oct-2023"
            
       '' pending license fee collection, comment this code for amount collected
       '' strDtlicfeepend = "15-Nov-2016"
       
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "21-Aug-2013"
            DtLicToDt = "31-Oct-2014"
            
            DtAMCFrmDt = "01-Nov-2016"      '' AMC Received for yearly
            DtAMCToDt = "31-Oct-2023"
            
       '' pending license fee collection, comment this code for amount collected
       '' strDtlicfeepend = "15-Nov-2016"
       
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "102" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "21-Aug-2013"
            DtLicToDt = "31-Oct-2014"
            
            DtAMCFrmDt = "01-Nov-2016"      '' AMC Received for yearly
            DtAMCToDt = "31-Oct-2023"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "15-Nov-2016"
            
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END PALAMOOR COOPERATIVE URBAN BANK
    
    '' START UNIVERSAL COOPERATIVE URBAN BANK (This Bank Under AMC)
     ElseIf strbanknm = UCase("UCUB") Then
        
         If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-Apr-2012"
            DtLicToDt = "31-Mar-2013"
            
            '' AMC paid by Quterly - Last AMC Exp Date 31-03-2015 (AMC Is Pending)
            
            DtAMCFrmDt = "01-Apr-2015"
            DtAMCToDt = "31-Dec-2015"
            
       '' pending license fee collection, comment this code for amount collected
       '' strDtlicfeepend = "16-Apr-2015"    ''Lincense pending
       '' strDtamcfeepend = "10-Jun-2015"  ''AMC pending
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-Apr-2012"
            DtLicToDt = "31-Mar-2013"
            
            '' AMC paid by Quterly - Last AMC Exp Date 31-03-2015 (AMC Is Pending)
            
            DtAMCFrmDt = "01-Apr-2015"
            DtAMCToDt = "31-Dec-2015"
            
       '' pending license fee collection, comment this code for amount collected
       '' strDtlicfeepend = "16-Apr-2015"
       '' strDtamcfeepend = "10-Jun-2015"  ''AMC pending
            GetBankData = "Data Present"
            GoTo EndOfFunction
        ElseIf strbrcd = "102" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-Apr-2012"
            DtLicToDt = "31-Mar-2013"
            
            '' AMC paid by Quterly - Last AMC Exp Date 31-03-2015 (AMC Is Pending)
            
           DtAMCFrmDt = "0l-Apr-2015"
            DtAMCToDt = "31-Dec-2015"
            
       '' pending license fee collection, comment this code after amount collected
       '' strDtlicfeepend = "16-Apr-2015"
       '' strDtamcfeepend = "10-Jun-2015"  ''AMC pending
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END UNIVERSAL COOPERATIVE URBAN BANK
    
    '' START MAHAJAN COOPERATIVE URBAN BANK (This bank under Warranty - 1 year)
     ElseIf strbanknm = UCase("MAHAJAN") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Aug-2014"
            DtLicToDt = "31-Jul-2016"
            
            DtAMCFrmDt = "01-Aug-2016"
            DtAMCToDt = "31-Oct-2016"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "15-May-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Aug-2014"
            DtLicToDt = "31-Jul-2016"
            
            DtAMCFrmDt = "01-Aug-2016"
            DtAMCToDt = "31-Oct-2016"  ''AMC Paid for first QTR
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "15-May-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END MAHAJAN COOPERATIVE URBAN BANK
    
    '' START DHARMAVARAM COOPERATIVE URBAN BANK (This Bank under Warranty - 1 year)
     ElseIf strbanknm = UCase("DMM") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "20-Oct-2014"   '' license fees received
            DtLicToDt = "19-Oct-2015"
            
            DtAMCFrmDt = "20-Oct-2016"
            DtAMCToDt = "19-Oct-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "25-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "20-Oct-2014"   '' license feel received
            DtLicToDt = "19-Oct-2015"
            
            DtAMCFrmDt = "20-Oct-2016"
            DtAMCToDt = "19-Oct-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "25-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END DHARMAVARAM COOPERATIVE URBAN BANK
    
    '' START SWARNA COOPERATIVE URBAN BANK    (This bank under AMC)
     ElseIf strbanknm = UCase("SWARNA") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Apr-2012"
            DtLicToDt = "31-Mar-2013"
            
            DtAMCFrmDt = "01-Apr-2016"  '' Under AMC
            DtAMCToDt = "31-Mar-2027"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            ''strDtamcfeepend = "11-APR-2017"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Apr-2015"
            DtLicToDt = "07-Apr-2015"
            
            DtAMCFrmDt = "01-Apr-2016"  '' Under AMC
            DtAMCToDt = "31-Mar-2027"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            '' strDtamcfeepend = "11-APR-2017"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END SWARNA COOPERATIVE URBAN BANK
    
    
     '' START AMALAPURAM COOPERATIVE URBAN BANK (This bank under AMC)
     '' AMC Increase every two years @ 10% on Exisiting AMC
     
     ElseIf strbanknm = UCase("ACTB") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "16-JUN-2017"
            DtLicToDt = "15-JUN-2018"
            
            
            DtAMCFrmDt = "16-JUN-2018"
            DtAMCToDt = "15-JUN-2027"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "20-AUG-2017"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "16-JUN-2017"
            DtLicToDt = "15-JUN-2018"
            
            DtAMCFrmDt = "16-JUN-2018"
            DtAMCToDt = "15-JUN-2027"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "20-AUG-2017"
            GetBankData = "Data Present"
            GoTo EndOfFunction
       Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
       End If '' strbrcd
    '' END AMALAPURAM COOPERATIVE URBAN BANK
    
    '' START SALUR COOPERATIVE URBAN BANK (This bank under AMC)
     ElseIf strbanknm = UCase("SALUR") Then
        
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Jan-2015"
            DtLicToDt = "31-Dec-2015"
            
            DtAMCFrmDt = "01-Jan-2017"  ''AMC start on 01-01-2016
            DtAMCToDt = "31-Dec-2026"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "31-May-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            DtLicFrmDt = "01-Jan-2015"
            DtLicToDt = "31-Dec-2015"
            
            DtAMCFrmDt = "01-Jan-2017"
            DtAMCToDt = "31-Dec-2026"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "31-May-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
       Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
       End If '' strbrcd
    '' END SALUR COOPERATIVE URBAN BANK
    
    ''START ELURU COOPERATIVE URBAN BANK
    
    ElseIf strbanknm = UCase("ELURU") Then
     
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "15-Feb-2016"
            DtLicToDt = "14-Feb-2017"
            
            DtAMCFrmDt = "15-Feb-2017"  '' AMC start on 15-02-2017
            DtAMCToDt = "14-Feb-2022"
            
            
             ''pending license fee collection, comment this code after amount collected
           ''strDtlicfeepend = "06-Sep-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "15-Feb-2016"
            DtLicToDt = "14-Feb-2017"
            
            DtAMCFrmDt = "15-Feb-2017"   '' AMC start on 15-02-2017
            DtAMCToDt = "14-Feb-2022"
                       
            '' pending license fee collection, comment this code for amount collected
            ''strDtlicfeepend = "06-Sep-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "102" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "15-Feb-2016"
            DtLicToDt = "14-Feb-2017"
            
            DtAMCFrmDt = "15-Feb-2017"   '' AMC start on 15-02-2017
            DtAMCToDt = "14-Feb-2022"
           
            '' pending license fee collection, comment this code for amount collected
            ''strDtlicfeepend = "06-Sep-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "103" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-OCT-2017"
            DtLicToDt = "15-NOV-2018"
            
            DtLicFrmDt = "01-OCT-2017"  '' AMC start on 15-11-2018
            DtAMCToDt = "14-Feb-2022"
                      
            '' pending license fee collection, comment this code for amount collected
            ''strDtlicfeepend = "06-Sep-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "104" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-OCT-2017"
            DtLicToDt = "15-NOV-2018"
            
            DtLicFrmDt = "01-OCT-2017"  '' AMC start on 15-nov-2018
            DtAMCToDt = "14-Feb-2022"
                       
           '' pending license fee collection, comment this code for amount collected
            ''strDtlicfeepend = "06-Sep-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END ELURU COOPERATIVE URBAN BANK
    
    '' START GUNTUR WOMEN COOPERATIVE URBAN BANK
     ElseIf strbanknm = UCase("GUNTUR") Then
     
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-MAY-2016"
            DtLicToDt = "31-AUG-2018"
            
            DtAMCFrmDt = "01-SEP-2018"  '' AMC start on 01-09-2018
            DtAMCToDt = "31-AUG-2027"
            
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "15-JUL-2016"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-MAY-2016"
            DtLicToDt = "31-AUG-2018"
            
            DtAMCFrmDt = "01-SEP-2018"  '' AMC start on 01-09-2018
            DtAMCToDt = "31-AUG-2027"
            
            '' pending license fee collection, comment this code for amount collected
             ''strDtlicfeepend = "31-OCT-2017"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    
     '' End GUNTUR WOMEN COOPERATIVE BANK
    
    '' START GOKUL COOPERATIVE URBAN BANK
     ElseIf strbanknm = UCase("GOKUL") Then
     
        If strbrcd = "999" Then
            strliamc = "L"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-Apr-2015"
            DtLicToDt = "31-Mar-2015"
            
            DtAMCFrmDt = "01-Apr-2015"
            DtAMCToDt = "31-Mar-2016"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "L"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-Apr-2015"
            DtLicToDt = "31-Mar-2015"
            
            DtAMCFrmDt = "01-Apr-2015"
            DtAMCToDt = "31-Mar-2016"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "16-Apr-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END GOKUL COOPERATIVE URBAN BANK
    
    '' START KUPPAM COOPERATIVE URBAN BANK
     ElseIf strbanknm = UCase("KUPPAM") Then
     
        If strbrcd = "999" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-JUL-2015"
            DtLicToDt = "30-JUN-2016"
            
            DtAMCFrmDt = "01-JUL-2016"
            DtAMCToDt = "30-JUN-2018"
            '' pending license fee collection, comment this code for amount collected
            ''strDtlicfeepend = "31-Dec-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
            
        ElseIf strbrcd = "101" Then
            strliamc = "A"            '' License -- L or AMC - A (set by raminfo)
            
            DtLicFrmDt = "01-JUL-2015"
            DtLicToDt = "30-JUN-2016"
            
            DtAMCFrmDt = "01-JUL-2016"
            DtAMCToDt = "30-JUN-2018"
            '' pending license fee collection, comment this code for amount collected
            '' strDtlicfeepend = "31-Dec-2015"
            GetBankData = "Data Present"
            GoTo EndOfFunction
        Else
            GetBankData = "Noo~Branch Data Not Set"
            Exit Function
        End If '' strbrcd
    '' END KUPPAM COOPERATIVE URBAN BANK
    
    Else
    GetBankData = "Noo~Bank Name Not Properly Set"
    Exit Function
End If ''strbanknm
EndOfFunction:
'If strliamc = "L" Then
'    If CDate(DtLicFrmDt) > CDate(DtLicToDt) Then
'    GetBankData = "Noo~License From Date Should Not Be Greater Than To Date"
'    Exit Function
'    End If
'ElseIf strliamc = "A" Then
'    If CDate(DtAMCFrmDt) > CDate(DtAMCToDt) Then
'    GetBankData = "Noo~AMC From Date Should Not Be Greater Than To Date"
'    Exit Function
'    End If
'End If
End Function

