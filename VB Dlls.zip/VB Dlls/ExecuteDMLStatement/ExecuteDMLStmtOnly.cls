VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "ExecuteDMLStmtOnly"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public ConnError As String 'error string
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim Rstemp As ADODB.Recordset
Dim objdblink As Object
Dim objError As Object
Dim objTrans As Object
Dim ICount As Integer
Dim DataLink As String
Dim ArrLink As Variant
Dim ArrError As Variant
Dim StrCondition As String
Dim ConnTime As String
Dim BrCode As String
Dim MachID As String
Dim Userid As String
Dim arrerr As Variant
Dim errobj As Object
Dim objContext As ObjectContext
Dim CMD As New ADODB.Command
Dim PR As New ADODB.Parameter
Dim prerr As New ADODB.Parameter
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim objErrlog As Object


Public Sub DBConnection()

Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0


'************Oppening the connection to dblink*************
On Error GoTo errhand
   Set AdoScConnObj = CreateObject("Adodb.Connection")
    
    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
    Set AdoScConnObj = Nothing
    
    'strUserid = "v"
    strUserName = "v3"
    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"



    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:

objErrlog.LogError "ReportPurposeOnly", "DBConnection" & strLineno, Err.Number, Err.Description

If Not resDBdate.EOF Or Not resDBdate.BOF Then
    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
    ConnError = "DBDATE: Latest Date Not Found."
    End If
End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
   Set AdoScConnObj = Nothing

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Public Function ExecuteDMLStmt(selectstat As String) As String
On Error GoTo errhand

ConnError = ""

Dim strcreateview As String
Dim strquery As String


Dim clntDesc As String, ErrNum As String, errDesc As String

Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.ConnectionTimeout = 300


Call DBConnection


If ConnError <> "Connected" Then GoTo errhand


strquery = selectstat

'''*************Opening the Recordset.*************
  
 AdoConnObj.Execute (strquery)
'''''''''''Closing the connection for querying
      
   
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
DeleteRecords = "Success"
 Exit Function
errhand:
If ConnError <> "Connected" Then

'*************Connection Failed************
    Set AdoConnObj = Nothing
    If Err.Number = 0 Then
        ConnError = "Connection Failed !"
    Else
        ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description & " : " & strquery
    End If
Else
    
        ConnError = Err.Number & " " & Err.Description
End If

objErrlog.LogError "Delete", "DeleteRecords", Err.Number, Err.Description

DeleteRecords = "Failure" & Err.Description
End Function


Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub



