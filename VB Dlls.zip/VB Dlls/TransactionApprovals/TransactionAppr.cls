VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "TransactionAppr"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
    Dim objContext As ObjectContext
    Dim ObjTrans As Object
    Dim objQuery As Object
    Dim objBal As Object
    Dim strResult As String


Public Function TransAppr(CurrencyCode As String, UserId As String, MachineID As String, _
                          ApprOrVerify As String, BatchApprYN As String, _
                          ExceptionYN As String, TranNoModIDValues As String, _
                          Optional appdate As String, Optional strBrcod As String) As String

    Dim recTrnTab As ADODB.Recordset
    Dim recTellerPay As ADODB.Recordset
    Dim recBank As ADODB.Recordset
    Dim StrTabName As String
    Dim strFldTrn As String
    Dim arrFldVal(0) As String
    Dim arrFldValFnl(0) As String
    Dim strTrnTab As String
    Dim strTrnFld As String
    
    Dim fldVal As Variant
    Dim BranchCode As String
    Dim BatchNo As Variant
    Dim fldTranNo As Variant
    Dim arrModID As Variant
    Dim arrGlCode As Variant
    Dim arrExcepVal As Variant
    Dim fldValFnl As Variant
    Dim arrServiceID As String
    Dim arrModeofTran As String
    
    Dim strTrnWhCond As String
    Dim strExcpFlds As String
    Dim arrExcpFldVals(0) As String
    Dim introws As Double
    Dim dblBalance As String
    Dim arrAccNo As String
    Dim dblAmount As Double
    Dim strTellerYN As String
    Dim arrFldTellerVal(0) As String
    
    Dim RemType As String, RemGlCode As String, IssOnBankCode  As String
    Dim IssOnBrCode  As String, InstrNo  As String, InstrDt As String
    Dim IssOnBankDesc  As String, IssOnBrDesc  As String, chqfvg As String
    
    Dim InvGlCode As String, InvAccNo As String, RemGlDesc As String
    Dim InvGlDesc As String, InvAccName As String
    Dim InvModId As String, InvModDesc As String, InvAccBal As Double
    Dim objNoGen As Object
    Dim Strbatchno As String, StrDrTranno As String, StrCrTranno As String
    Dim BrCode As String, CurCode As String, DrGlDesc As String
    Dim DrGlCode As String, CrGlCode As String, DrAccNo As String
    Dim CrAccNo As String, DrAmt As Double, CrAmt As Double, sDrRemarks As String
    Dim sCrRemarks As String, CrGlDesc As String, DrAccName As String, DrModId As String
    Dim DrModDesc As String, DrAccBal As Double, appldt As String
    Dim strErrInfo As String
    Dim recdepintaccr As ADODB.Recordset
    
    Dim strWhConddepintaccr As String
    Dim arrFldValdepintaccr(0) As String
    Dim strFlddepintaccr As String
Dim strFlddepintacc As String
Dim strfvg As String

 On Error GoTo ErrHand
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
 
    If UCase(ApprOrVerify) = "A" Then
    
        If UCase(ExceptionYN) = "Y" Then ''Exceptional transaction
            Set recBank = CreateObject("adodb.recordset")
            Set recBank = objQuery.SingleRecordSet("GENBANKPARM", "EXCEPAPPREQYN", "")
        
        ''if second officer approval not required
        If recBank("EXCEPAPPREQYN") = "N" Then
            ApprOrVerify = "V" '' update with Verified status, this record will not go for second officer approval
            strFldTrn = "approvedby,approvedmachine,approvedsystemdate,"
            arrFldVal(0) = "'" & UserId & "'~'" & MachineID & "'~sysdate~"
        ElseIf recBank("EXCEPAPPREQYN") = "Y" Then
            strFldTrn = "approvedby,approvedmachine,approvedsystemdate,approvedtimebal"
            arrFldVal(0) = "'" & UserId & "'~'" & MachineID & "'~sysdate~'"
        End If
       
    Else ''Approve if not an exceptional transaction
        strFldTrn = "transtatus,approvedby,approvedmachine,approvedsystemdate,approvedtimebal"
        arrFldVal(0) = "'A'~'" & UserId & "'~'" & MachineID & "'~sysdate~'"
    End If ''     If UCase(ExceptionYN) = "Y" Then
     
    End If
    
    If UCase(ApprOrVerify) = "V" Then
       strFldTrn = strFldTrn & "transtatus,verifiedby,verifiedmachine,verifiedsystemdate,verifiedtimebal"
       arrFldVal(0) = arrFldVal(0) & "'A'~'" & UserId & "'~'" & MachineID & "'~sysdate~'"
        
       strExcpFlds = "verifiedby,verifiedmachine"
       arrExcpFldVals(0) = "'" & UserId & "'~'" & MachineID & "'"
    End If
    
    
    
    StrTabName = "GENMODULEMST"
    strTrnFld = "trandaytable,moduleid"
    
    fldVal = Split(TranNoModIDValues, "|")
  
    '--------Getting tranday table based on moduleid
 
        Set recTrnTab = CreateObject("ADODB.Recordset")
        Set recTellerPay = CreateObject("adodb.recordset")
        Set recTrnTab = objQuery.SingleRecordSet(StrTabName, strTrnFld)
            
        If objQuery.ConnError <> "Connected" Then
           GoTo ErrHand
        End If
        
        If recTrnTab.RecordCount > 0 Then
           strTrnTab = recTrnTab(0)
        Else
           TransAppr = "Table does not exit"
           objContext.SetAbort
           Exit Function
        End If
        
      Set objBal = CreateObject("AccountDetails.AccDetails")
      Set objContext = GetObjectContext
      Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
   
         For introws = 0 To UBound(fldVal)
   
            recTrnTab.MoveFirst
            
            fldValFnl = Split(fldVal(introws), "~")
            BranchCode = fldValFnl(0)
            BatchNo = fldValFnl(1)
            fldTranNo = fldValFnl(2)
            arrModID = fldValFnl(3)
            arrGlCode = fldValFnl(4)
            arrAccNo = fldValFnl(5)
            arrExcepVal = fldValFnl(6)
            dblAmount = fldValFnl(7)
            arrServiceID = fldValFnl(8)
            arrModeofTran = fldValFnl(9)
            
            dblBalance = "0"
     
            If arrServiceID <> "2" Then
                dblBalance = objBal.GetBalance(BranchCode, CurrencyCode, CStr(arrModID), _
                             CStr(arrGlCode), CStr(arrAccNo), "Y")
                           
                If Left(dblBalance, 5) = "ERROR" Then
                   TransAppr = dblBalance
                   GoTo ErrHand
                End If
           
                If dblBalance <> "" And dblAmount < 0 Then
                   dblBalance = Val(dblBalance) + Abs(dblAmount)
                Else
                    dblBalance = "0"
                End If
            End If
   
            strTrnWhCond = "upper(branchcode)='" & UCase(Trim(BranchCode)) & "' and " & _
                           "upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "' and " & _
                           "batchno='" & BatchNo & "' and tranno='" & fldTranNo & "'"
            '------------
           
            If introws = 0 And (arrModeofTran = 1 Or arrModeofTran = 2) Then
               StrTabName = "CASHTELLERPAYMENTSTRANDAY"
               strTrnFld = "batchno"
               
               Set recTellerPay = objQuery.SingleRecordSet(StrTabName, strTrnFld, strTrnWhCond)
           
                  If recTellerPay.RecordCount > 0 Then
                     strTellerYN = "Y"
                  End If
            End If
            '------------
  
            arrFldValFnl(0) = arrFldVal(0) & dblBalance & "'"
     
            recTrnTab.Filter = "moduleid='" & Trim(arrModID) & "'"
            strTrnTab = UCase(Trim(recTrnTab!trandaytable))
         
            strResult = ObjTrans.UpdateRecord(strTrnTab, strFldTrn, arrFldValFnl, strTrnWhCond)
     
                   If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                   End If
            strTrnTab = "GENTRANSLOG"
            strResult = ObjTrans.UpdateRecord(strTrnTab, strFldTrn, arrFldValFnl, strTrnWhCond)
     
                   If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                   End If
          If UCase(ApprOrVerify) = "V" And UCase(arrExcepVal) = "Y" Then
            strTrnTab = "GENEXCEPTIONALTRANDAY"
            strResult = ObjTrans.UpdateRecord(strTrnTab, strExcpFlds, arrExcpFldVals, strTrnWhCond)
    
                   If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                   End If
          End If
       
          If strTellerYN = "Y" Then
             strTrnTab = "CASHTELLERPAYMENTSTRANDAY"
             strTrnFld = "transtatus,verifiedby,verifiedmachine"
             arrFldTellerVal(0) = "'A'~'" & UserId & "'~'" & MachineID & "'"
             
             strResult = ObjTrans.UpdateRecord(strTrnTab, strTrnFld, arrFldTellerVal, _
                         strTrnWhCond)
    
                   If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                   End If
                   
          End If
          
          ''depintaccrueddtls
          
            Set recdepintaccr = CreateObject("adodb.recordset")
            strWhConddepintaccr = "upper(branchcode)='" & UCase(Trim(BranchCode)) & "' and " & _
                                  "upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "' and " & _
                       " transtatus = 'P' and batchno='" & BatchNo & "' and " & _
                       " tranno='" & fldTranNo & "' AND applicationdate ='" & Format(appdate, "dd-mmm-yyyy") & "'"
            Set recdepintaccr = objQuery.SingleRecordSet("DEPINTACCRUEDDTLS", "accno", strWhConddepintaccr)
            
            If recdepintaccr.RecordCount > 0 Then
        
            strFlddepintaccr = "TRANSTATUS, APPROVEDBY, APPROVEDMACHINE"
            arrFldValdepintaccr(0) = "'A'~'" & UserId & "'~'" & MachineID & "'"
            strResult = ObjTrans.UpdateRecord("DEPINTACCRUEDDTLS", strFlddepintaccr, arrFldValdepintaccr, strWhConddepintaccr)
        
                If strResult <> "Trans Completed" Then
                   GoTo ErrHand
                End If
            End If

         Next introws
         
        'code added by Radhika on 4 sep 2008
        'Reason: When we are doing remitance cancellation entry,
        '        then we should credit remittance gl and debit investment gl
        Dim intCntRemCan As Integer
        intCntRemCan = 0
        For introws = 0 To UBound(fldVal)
   
            recTrnTab.MoveFirst
            
            strErrInfo = "1"
            
            fldValFnl = Split(fldVal(introws), "~")
            BranchCode = fldValFnl(0)
            BatchNo = fldValFnl(1)
            fldTranNo = fldValFnl(2)
            arrModID = fldValFnl(3)
            arrGlCode = fldValFnl(4)
            arrAccNo = fldValFnl(5)
            arrExcepVal = fldValFnl(6)
            dblAmount = fldValFnl(7)
            arrServiceID = fldValFnl(8)
            arrModeofTran = fldValFnl(9)
            
            If UCase(Trim(arrModID)) = "REM" And Val(arrServiceID) = 9 And intCntRemCan = 0 Then
            intCntRemCan = intCntRemCan + 1
            'i.e Remittance Cancellation
                strErrInfo = "2"
                        
                'Get Other details of given Transaction from GenTempTranslog
                StrTabName = "GENTEMPTRANSLOG"
                strTrnFld = "glcode remglcode, respondingbankcode bankcode, " & _
                    "c61 branchcode, c64 instrno, ChqDate ChqDate,c69 remtype," & _
                    "respondingbankdesc bankdesc,c62 brdesc,chqfvg ,applicationdate,c63 fvg "
                strTrnWhCond = "branchcode='" & BranchCode & "' AND batchno = " & _
                BatchNo & " AND tranno = " & fldTranNo & " AND serviceid= " & Val(arrServiceID)
                
                strErrInfo = strErrInfo & "; Table=" & StrTabName & "; Cond =" & strTrnWhCond
                
                Set recTellerPay = objQuery.SingleRecordSet(StrTabName, strTrnFld, strTrnWhCond)
                If recTellerPay.RecordCount <= 0 Then
                    strResult = "Required details of given Batch not found in Temp Trans Log to credit Remitance GL"
                    GoTo ErrHand
                End If
                
                RemType = UCase(Trim(recTellerPay!RemType))
                'i.e. Remitance Type  = Agency DD
                If RemType <> "ADD" Then
                    GoTo EndOfRemLoop
                    'i.e. check for another transaction of same batch
                End If
                
                If IsNull(recTellerPay!ChqDate) = True Then
                    strResult = "Instrument/Cheque date should not be null in Temporary Trans Log"
                    GoTo ErrHand
                ElseIf IsNull(recTellerPay!applicationdate) = True Then
                    strResult = "Transaction date should not be null in Temporary Trans Log"
                    GoTo ErrHand
                End If
                
                'Intialize variables
                strErrInfo = "Qry No 3"
                RemGlCode = recTellerPay!RemGlCode & ""
                IssOnBankCode = recTellerPay!bankcode & ""
                IssOnBrCode = recTellerPay!BranchCode & ""
                InstrNo = recTellerPay!InstrNo & ""
                InstrDt = Format(recTellerPay!ChqDate, "dd-mmm-yyyy")
                IssOnBankDesc = recTellerPay!bankdesc & ""
                IssOnBrDesc = recTellerPay!brdesc & ""
                chqfvg = recTellerPay!chqfvg & ""
                appldt = Format(recTellerPay!applicationdate, "dd-mmm-yyyy")
                strfvg = IIf(IsNull(recTellerPay!fvg), "", recTellerPay!fvg & "")
                
                strErrInfo = strErrInfo & "; Table=GENGLMASTMST; Cond =" & "glcode='" & RemGlCode & "'"
                
                'Get description of remitance GL
                Set recTellerPay = objQuery.SingleRecordSet("GENGLMASTMST", "gldescription", _
                "glcode='" & RemGlCode & "'")
                If recTellerPay.RecordCount <= 0 Then
                    strResult = "Description of Remitance GL " & RemGlCode & " not found"
                    GoTo ErrHand
                End If
                RemGlDesc = IIf(IsNull(recTellerPay(0).Value), "", recTellerPay(0).Value)

                'Get Investment GL Code and A/C number
                strErrInfo = "Qry No 4; Table=REMISSUEBANKMST; Cond =" & _
                "branchcode='" & Trim(BranchCode) & "' AND remtype='ADD'" & _
                " AND otherbankcode='" & Trim(IssOnBankCode) & "' AND otherbranchcode='" & _
                Trim(IssOnBrCode) & "'"
                
                Set recTellerPay = objQuery.SingleRecordSet("REMISSUEBANKMST", "invglcode,invaccno", _
                "branchcode='" & Trim(BranchCode) & "' AND remtype='ADD'" & _
                " AND otherbankcode='" & Trim(IssOnBankCode) & "' AND otherbranchcode='" & _
                Trim(IssOnBrCode) & "'")
                If recTellerPay.RecordCount <= 0 Then
                    strResult = "Investment GL Code and Account number details not found for " & _
                    " the selected Remitance Type"
                    GoTo ErrHand
                ElseIf IsNull(recTellerPay(0).Value) = True Or IsNull(recTellerPay(1).Value) = True Then
                    strResult = "Investment GL Code and Account number details not found for " & _
                    " the selected Remitance Type"
                    GoTo ErrHand
                Else
                    InvGlCode = recTellerPay(0).Value
                    InvAccNo = recTellerPay(1).Value
                
                
                    strErrInfo = "Qry No 5; Table=GENGLMASTMST; Cond =" & _
                "glcode='" & InvGlCode & "'"
                
                    'Get Moduleid and description of Investment GL
                    Set recTellerPay = objQuery.SingleRecordSet("GENGLMASTMST", _
                    "gldescription,moduleid", "glcode='" & InvGlCode & "'")
                    If recTellerPay.RecordCount <= 0 Then
                        strResult = "Description of GL " & InvGlCode & " not found"
                        GoTo ErrHand
                    ElseIf IsNull(recTellerPay(1).Value) = True Then
                        strResult = "Module Code for GL " & InvGlCode & " not found"
                        GoTo ErrHand
                    Else
                        InvGlDesc = IIf(IsNull(recTellerPay(0).Value), "", recTellerPay(0).Value)
                        InvModId = recTellerPay(1).Value & ""
                    End If
                    
                    strErrInfo = "Qry No 6; Table=GENMODULEMST; Cond =" & _
                "moduleid='" & InvModId & "'"
                    
                    'Get Description  of Investment Module
                    Set recTellerPay = objQuery.SingleRecordSet("GENMODULEMST", "narration", "moduleid='" & _
                    InvModId & "'")
                    If recTellerPay.RecordCount <= 0 Then
                        InvModDesc = ""
                    Else
                        InvModDesc = IIf(IsNull(recTellerPay(0).Value), "", recTellerPay(0).Value)
                    End If
                    
                    strErrInfo = "Qry No 7; Table=" & Trim(InvModId) & "MST; Cond =" & _
                    "branchcode='" & BranchCode & "' and glcode='" & InvGlCode & "'" & _
                    " and accno ='" & InvAccNo & "'"
                    
                    'Get Name of Investment A/C
                    Set recTellerPay = objQuery.SingleRecordSet(Trim(InvModId) & "MST", "name", _
                    "branchcode='" & BranchCode & "' and glcode='" & InvGlCode & "'" & _
                    " and accno ='" & InvAccNo & "'")
                    If recTellerPay.RecordCount <= 0 Then
                        strResult = "Account details not found for GL " & InvGlCode & _
                        " and Account No. is " & InvAccNo
                        GoTo ErrHand
                    Else
                        InvAccName = IIf(IsNull(recTellerPay(0).Value), "", recTellerPay(0).Value)
                    End If
                   
                    'Get Balance of Investment A/C
                    strErrInfo = "Qry No 7; GetBalance"

                    dblBalance = objBal.GetBalance(BranchCode, CurrencyCode, InvModId, _
                             InvGlCode, InvAccNo, "Y")
                    If Left(dblBalance, 5) = "ERROR" Then
                        TransAppr = dblBalance
                        GoTo ErrHand
                    End If
                    InvAccBal = Val(dblBalance)
                End If
                
                strErrInfo = "Qry No 8; Assigning values"
                
                BrCode = BranchCode: CurCode = CurrencyCode
                CrGlCode = RemGlCode: CrAccNo = "": CrGlDesc = RemGlDesc
                DrGlCode = InvGlCode: DrGlDesc = InvGlDesc
                DrAccNo = InvAccNo: DrAccName = InvAccName: DrModId = InvModId
                DrModDesc = InvModDesc: DrAccBal = InvAccBal
                
'                sDrRemarks = "Dr Inv Bank A/C and Cr Remitance Gl"
                sDrRemarks = "CANC DDNO " & InstrNo & " " & strfvg
                sCrRemarks = sDrRemarks
                DrAmt = Abs(dblAmount) * -1: CrAmt = Abs(dblAmount)
                
                strErrInfo = "Qry No 9; Get batch & tran numbers"
                
                Set objNoGen = objContext.CreateInstance("GeneralTranQueries.TransactionQueries")
                'Strbatchno = objNoGen.getbatchno(BrCode)
                
                Dim stLen, stAbb, stAbdat, stadyn, stBr As String
                
                Strbatchno = BatchNo
                
                stLen = Len(Strbatchno)
                
                If stLen = "6" Then
            
                    stBr = "ABB"
                    
                    StrDrTranno = objNoGen.gettranno(stBr)
                    StrCrTranno = objNoGen.gettranno(stBr)
                    
                    stAbb = strBrcod
                    stAbdat = appldt
                    stadyn = "Y"
                    
                Else
                    StrDrTranno = objNoGen.gettranno(BrCode)
                    StrCrTranno = objNoGen.gettranno(BrCode)
                    
                    stAbb = ""
                    stAbdat = ""
                    stadyn = "N"
                    
                End If
                
                
                Set objNoGen = Nothing
                
                strErrInfo = "Qry No 10; GENTEMPTRANSLOG - Debit data preparation "
                
                strTrnTab = "GENTEMPTRANSLOG"
                strFldTrn = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO," & _
                    "TRANNO,GLDESC, NAME , AMOUNT, ENTEREDTIMEBAL, CUSTOMERID, MODEOFTRAN," & _
                    "MODEOFTRANDESC,TOKENNO,REMARKS,CHQNO,CHQDATE,CHQFVG," & _
                    "SYSTEMGENERATEDYN, MODULEDESC, EFFECTIVEDATE, SERVICEID, SERVICEDESC," & _
                    "ACCOUNTCHECKYN, EXCEPTIONYN, STANDINSTRYN, APPLICATIONDATE, USERID," & _
                    "MACHINEID, TRANSTATUS, SYSTEMDATE, APPROVEDDATE, ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','" & DrModId & "','" & DrGlCode & _
                    "','" & DrAccNo & "'," & Strbatchno & "," & StrDrTranno & ",'" & _
                    DrGlDesc & "','" & DrAccName & "'," & DrAmt & "," & DrAccBal & ",null,'3','Dr Transfer',1,'" & _
                    sDrRemarks & "','" & InstrNo & "','" & InstrDt & _
                    "','" & chqfvg & "','N','" & DrModDesc & "','" & appldt & "',1," & _
                    "'TRANSACTION','N','N','N','" & appldt & "','" & UserId & "','" & _
                    MachineID & "','D',sysdate,'" & appldt & "','" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
            
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If
                
                'Insert a debit entry into GENTRANSLOG with Approved Status
                strErrInfo = "Qry No 11; GENTRANSLOG - Debit data preparation "
                strTrnTab = "GENTRANSLOG"
                strFldTrn = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO," & _
                    "BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL," & _
                    "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, CHQNO," & _
                    "CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, SYSTEMGENERATEDYN,REMARKS,SERVICEID," & _
                    "EXCEPTIONYN, APPROVEDSYSTEMDATE, APPROVEDDATE," & _
                    "APPLICATIONDATE,USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
                    "APPROVEDBY,APPROVEDMACHINE,SYSTEMYEAR,ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','" & DrModId & "','" & DrGlCode & _
                    "','" & DrAccNo & "'," & Strbatchno & "," & StrDrTranno & "," & _
                    DrAmt & ",'3'," & DrAccBal & "," & DrAccBal & "," & DrAccBal & "," & DrAccBal & ",'" & appldt & "',null,'" & DrAccName & "','" & _
                    InstrNo & "','" & chqfvg & "','" & InstrDt & "',1,'N','N','" & _
                    sDrRemarks & "',1,'N',SYSDATE,'" & appldt & "'," & _
                    "'" & appldt & "','" & UserId & "','" & MachineID & "','A',SYSDATE,'" & UserId & _
                    "','" & MachineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) ,'" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
                
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If
                
                'Insert a debit entry into INVTRANDAY with Approved Status
                strErrInfo = "Qry No 12; INVTRANDAY - Debit data preparation "
                strTrnTab = Trim(DrModId) & "TRANDAY"
                strFldTrn = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO," & _
                    "BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL," & _
                    "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, CHQNO," & _
                    "CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, SYSTEMGENERATEDYN,REMARKS,SERVICEID," & _
                    "EXCEPTIONYN, APPROVEDSYSTEMDATE, APPROVEDDATE," & _
                    "APPLICATIONDATE,USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
                    "APPROVEDBY,APPROVEDMACHINE,SYSTEMYEAR,ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','" & DrModId & "','" & DrGlCode & _
                    "','" & DrAccNo & "'," & Strbatchno & "," & StrDrTranno & "," & _
                    DrAmt & ",'3'," & DrAccBal & "," & DrAccBal & "," & DrAccBal & "," & DrAccBal & ",'" & appldt & "',null,'" & DrAccName & "','" & _
                    InstrNo & "','" & chqfvg & "','" & InstrDt & "',1,'N','N','" & _
                    sDrRemarks & "',1,'N',SYSDATE,'" & appldt & "'," & _
                    "'" & appldt & "','" & UserId & "','" & MachineID & "','A',SYSDATE,'" & UserId & _
                    "','" & MachineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))" & ",'" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
                
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If

                'Insert a credit entry into GENTEMPTRANSLOG with Delete status
                strErrInfo = "Qry No 13; GENTEMPTRANSLOG - Credit data preparation "
                strTrnTab = "GENTEMPTRANSLOG"
                strFldTrn = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO," & _
                    "TRANNO,GLDESC, NAME , AMOUNT, ENTEREDTIMEBAL, CUSTOMERID, MODEOFTRAN," & _
                    "MODEOFTRANDESC,TOKENNO,REMARKS,CHQNO,CHQDATE,CHQFVG," & _
                    "SYSTEMGENERATEDYN, MODULEDESC, EFFECTIVEDATE, SERVICEID, SERVICEDESC," & _
                    "ACCOUNTCHECKYN, EXCEPTIONYN, STANDINSTRYN, APPLICATIONDATE, USERID," & _
                    "MACHINEID, TRANSTATUS, SYSTEMDATE, APPROVEDDATE, ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','REM','" & CrGlCode & _
                    "',''," & Strbatchno & "," & StrCrTranno & ",'" & _
                    CrGlDesc & "',''," & CrAmt & ",null,null,'4','Cr Transfer',1,'" & _
                    sCrRemarks & "','" & InstrNo & "','" & InstrDt & _
                    "','" & chqfvg & "','N','Remittance','" & appldt & "',1," & _
                    "'TRANSACTION','N','N','N','" & appldt & "','" & UserId & "','" & _
                    MachineID & "','D',sysdate,'" & appldt & "','" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
            
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If
                
                'Insert a CREDIT entry into GENTRANSLOG with Approved Status
                strErrInfo = "Qry No 14; GENTRANSLOG - Credit data preparation "
                strTrnTab = "GENTRANSLOG"
                strFldTrn = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO," & _
                    "BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL," & _
                    "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, CHQNO," & _
                    "CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, SYSTEMGENERATEDYN,REMARKS,SERVICEID," & _
                    "EXCEPTIONYN, APPROVEDSYSTEMDATE, APPROVEDDATE," & _
                    "APPLICATIONDATE,USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
                    "APPROVEDBY,APPROVEDMACHINE,SYSTEMYEAR,ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','REM','" & CrGlCode & _
                    "',null," & Strbatchno & "," & StrCrTranno & "," & _
                    CrAmt & ",'4',null,null,null,null,'" & appldt & "',null,'','" & _
                    InstrNo & "','" & chqfvg & "','" & InstrDt & "',1,'N','N','" & _
                    sCrRemarks & "',1,'N',SYSDATE,'" & appldt & "'," & _
                    "'" & appldt & "','" & UserId & "','" & MachineID & "','A',SYSDATE," & _
                    "'" & UserId & "','" & MachineID & "'," & _
                    "TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))" & ",'" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
                
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If
                
                'Insert a debit entry into REMTRANDAY with Approved Status
                strErrInfo = "Qry No 15; REMTRANDAY - Credit data preparation "
                strTrnTab = "REMTRANDAY"
                strFldTrn = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO," & _
                    "BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL," & _
                    "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, CHQNO," & _
                    "CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, SYSTEMGENERATEDYN,REMARKS,SERVICEID," & _
                    "EXCEPTIONYN, APPROVEDSYSTEMDATE, APPROVEDDATE," & _
                    "APPLICATIONDATE,USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
                    "APPROVEDBY,APPROVEDMACHINE,SYSTEMYEAR,ABBYN, ABBBRANCHCODE, ABBAPPLICATIONDATE"
            
                arrFldValFnl(0) = "'" & BrCode & "','" & CurCode & "','REM','" & CrGlCode & _
                    "',null," & Strbatchno & "," & StrCrTranno & "," & _
                    CrAmt & ",'4',null,null,null,null,'" & appldt & "',null,'','" & _
                    InstrNo & "','" & chqfvg & "','" & InstrDt & "',1,'N','N','" & _
                    sCrRemarks & "',1,'N',SYSDATE,'" & appldt & "'," & _
                    "'" & appldt & "','" & UserId & "','" & MachineID & "','A',SYSDATE," & _
                    "'" & UserId & "','" & MachineID & "'," & _
                    "TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))" & ",'" & stadyn & "','" & stAbb & "','" & stAbdat & "'"
                
                strResult = ObjTrans.insertRecord(strTrnTab, strFldTrn, arrFldValFnl, "")
                If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                End If
                
            End If
            
EndOfRemLoop:
            
        Next introws
        'end of code added by Radhika on 4 sep 2008
      
       If introws = UBound(fldVal) + 1 Then
               objContext.SetComplete
               If BatchApprYN = "Y" Then
                  TransAppr = "Batch No : " & BatchNo & "  Approved"
               Else
                  TransAppr = "Transaction No : " & fldTranNo & "  Approved"
               End If
       Else
               GoTo ErrHand
       End If
     
            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
            Set objBal = Nothing
            Exit Function
     
 
ErrHand:
    
       objContext.SetAbort
    
            If objQuery.ConnError <> "Connected" Then
               TransAppr = objQuery.ConnError
               TransAppr = Replace(TransAppr, Chr(10), "")
               TransAppr = Replace(TransAppr, Chr(13), "")
            End If

            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
            Set objBal = Nothing
            
            If Err.Number <> "0" Then
               TransAppr = Err.Number & " : " & Err.Description
               TransAppr = Replace(TransAppr, Chr(10), "")
               TransAppr = Replace(TransAppr, Chr(13), "")
            ElseIf strResult <> "Trans Completed" Then
               TransAppr = strResult & "; " & strErrInfo
               TransAppr = Replace(TransAppr, Chr(10), "")
               TransAppr = Replace(TransAppr, Chr(13), "")
            End If
            
End Function
 
Public Function TransDeletedAppr(CurrencyCode As String, UserId As String, MachineID As String, _
                          ApprOrVerify As String, BatchApprYN As String, _
                          ExceptionYN As String, TranNoModIDValues As String) As String

On Error GoTo ErrHand
 Dim fldVal As Variant
 Dim introws As Double
Dim strTrnWhCond As String
Dim strTrnTab As String
    Dim strTrnFld As String
    Dim arrFldValFnl(0) As String
Dim strFldTrn As String
Dim arrFldVal(0) As String
Dim fldValFnl As Variant
Dim BranchCode As String
    Dim BatchNo As Variant
    Dim fldTranNo As Variant
    Dim arrModID As Variant
    Dim arrGlCode As Variant
    Dim arrExcepVal As Variant
    Dim arrServiceID As String
    Dim arrModeofTran As String
    Dim arrAccNo As String
    Dim dblAmount As Double
    Dim strErrInfo As String
        
strTrnTab = "GENDELETEDTRANSLOG"
strFldTrn = "DELETEDTRANSTATUS,DELETEDAPPROVEDBY, DELETEDAPPROVEDMACHINE"
arrFldValFnl(0) = "'A'~'" & UserId & "'~'" & MachineID & "'"


fldVal = Split(TranNoModIDValues, "|")

Set objContext = GetObjectContext
 Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")

For introws = 0 To UBound(fldVal)
strErrInfo = "1"
  fldValFnl = Split(fldVal(introws), "~")
            BranchCode = fldValFnl(0)
            BatchNo = fldValFnl(1)
            fldTranNo = fldValFnl(2)
            arrModID = fldValFnl(3)
            arrGlCode = fldValFnl(4)
            arrAccNo = fldValFnl(5)
            arrExcepVal = fldValFnl(6)
            dblAmount = fldValFnl(7)
            arrServiceID = fldValFnl(8)
            arrModeofTran = fldValFnl(9)




strTrnWhCond = "upper(branchcode)='" & UCase(Trim(BranchCode)) & "' and " & _
                           "upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "' and " & _
                           "batchno='" & BatchNo & "' and tranno='" & fldTranNo & "'"
           
  strResult = ObjTrans.UpdateRecord(strTrnTab, strFldTrn, arrFldValFnl, strTrnWhCond)

                   If strResult <> "Trans Completed" Then
                      GoTo ErrHand
                   End If

   Next introws
objContext.SetComplete
TransDeletedAppr = "Batch No : " & BatchNo & "  Approved"

     Set objContext = Nothing

           Set ObjTrans = Nothing
         
            Exit Function


ErrHand:
    
       objContext.SetAbort

     If objQuery.ConnError <> "Connected" Then
               TransDeletedAppr = objQuery.ConnError
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(10), "")
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(13), "")
            End If

           Set objContext = Nothing

           Set ObjTrans = Nothing
            
            If Err.Number <> "0" Then
               TransDeletedAppr = Err.Number & " : " & Err.Description
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(10), "")
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(13), "")
            ElseIf strResult <> "Trans Completed" Then
               TransDeletedAppr = strResult & "; " & strErrInfo
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(10), "")
               TransDeletedAppr = Replace(TransDeletedAppr, Chr(13), "")
            End If
            
End Function

