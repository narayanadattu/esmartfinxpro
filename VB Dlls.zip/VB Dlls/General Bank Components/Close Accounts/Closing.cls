VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "ClosingAccounts"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Public Function CloseAccounts(BranchCode As String, CurrencyCode As String, _
            Moduleid As String, GlCode As String, AccNo As String) As String
On Error GoTo myerr
Dim rsTran As New ADODB.Recordset
Dim GenCondition As String
Dim dblBalance As Double
Dim objQuery As Object
Dim objAccBal As Object


Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set objAccBal = CreateObject("AccountDetails.AccDetails")


GenCondition = "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
        "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
        "upper(Moduleid)='" & UCase(Moduleid) & "' and " & _
        "upper(GlCode)='" & UCase(GlCode) & "' and " & _
        "upper(Accno)='" & UCase(AccNo) & "'"


'''''' Checking whether there are any Pending Transactions in Translog
Set rsTran = objQuery.SingleRecordSet("Gentranslog", "Tranno", _
        GenCondition & " and transtatus='P'")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "Few Transactions are pending for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''







'''''' Checking whether the Account has any balance
dblBalance = objAccBal.GetBalance(BranchCode, CurrencyCode, Moduleid, GlCode, AccNo)

If dblBalance <> 0 Then
    CloseAccounts = "Balance (" & dblBalance & ") is Available for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''' Checking Interst Accrued is Available or not in case of LOANS
If Moduleid = "LOAN" Then
    Set rsTran = objQuery.SingleRecordSet("LoanIntAccruedDtls", "nvl(sum(nvl(credit,0)),0)-" & _
                " nvl(sum(nvl(DEBIT,0)),0) intAccr ", _
                "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
                "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
                "upper(Moduleid)='" & UCase(Moduleid) & "' and " & _
                "upper(GlCode)='" & UCase(GlCode) & "' and " & _
                "upper(Accno)='" & UCase(AccNo) & "' ")

    If Not rsTran.EOF And Not rsTran.BOF Then
        If rsTran!intAccr <> 0 Then
            CloseAccounts = "Interst Accrued is Available for this Account.."
            Exit Function
        End If
    End If
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



'''''' Checking Standing Instructions are Pending or not
    Set rsTran = objQuery.SingleRecordSet("SIMst", "TranStatus", _
                "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
                "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
                "((upper(DebitModuleid)='" & UCase(Moduleid) & "' and " & _
                "upper(DebitGlCode)='" & UCase(GlCode) & "' and " & _
                "upper(DebitAccno)='" & UCase(AccNo) & "' and status in('R','P') ) or " & _
                "(upper(CreditModuleid)='" & UCase(Moduleid) & "' and " & _
                "upper(CreditGlCode)='" & UCase(GlCode) & "' and " & _
                "upper(CreditAccno)='" & UCase(AccNo) & "' and status in('R','P')) )")

    If Not rsTran.EOF And Not rsTran.BOF Then
        CloseAccounts = "Standing Instructions are Pending for this Account.."
        Exit Function
    End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''' Checking whether there are any Pending Transactions in Bills
Set rsTran = objQuery.SingleRecordSet("BillsMst", "BillType", _
                "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
                "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
                "upper(CustomerModuleid)='" & UCase(Moduleid) & "' and " & _
                "upper(CustomerGlCode)='" & UCase(GlCode) & "' and " & _
                "upper(CustomerAccno)='" & UCase(AccNo) & "' and (status='R' or " & _
                " transtatus='P') ")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "Bills  are pending for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



'''''' Checking whether there are any Pending Transactions in LG
Set rsTran = objQuery.SingleRecordSet("LGMst", "Purpose", _
                "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
                "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
                "upper(CustomerModuleid)='" & UCase(Moduleid) & "' and " & _
                "upper(CustomerGlCode)='" & UCase(GlCode) & "' and " & _
                "upper(CustomerAccno)='" & UCase(AccNo) & "'  and (status='R' or " & _
                " transtatus='P') ")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "LGs  are pending for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''' Checking whether there are any Pending Transactions in LC
Set rsTran = objQuery.SingleRecordSet("LCMst", "LCType", _
         "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
        "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
        "upper(CustomerModuleid)='" & UCase(Moduleid) & "' and " & _
        "upper(CustomerGlCode)='" & UCase(GlCode) & "' and " & _
        "upper(CustomerAccno)='" & UCase(AccNo) & "'  and (status='R' or " & _
        " transtatus='P') ")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "LCs  are pending for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''' Checking whether there are any Pending Transactions in Outward Returns
Set rsTran = objQuery.SingleRecordSet("CLGOutwardReturnDtls", "LinkAccno", _
                "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
                "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
                "upper(LinkModuleid)='" & UCase(Moduleid) & "' and " & _
                "upper(LinkGlCode)='" & UCase(GlCode) & "' and " & _
                "upper(LinkAccno)='" & UCase(AccNo) & "' and  transtatus='P'")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "Outward Returns Transactions are pending for this Account .."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''' Checking whether there are any Pending Transactions in Clearing Lodgement Voucher Details
''commented by mahender on 07-07-2017
''Set rsTran = objQuery.SingleRecordSet("CLGLodgementVoucherDtls", "CrAccno", _
''        "upper(Branchcode)='" & UCase(BranchCode) & "' and " & _
''        "upper(Currencycode)='" & UCase(CurrencyCode) & "' and " & _
''        "upper(CrModuleid)='" & UCase(Moduleid) & "' and " & _
''        "upper(CrGlCode)='" & UCase(GlCode) & "' and " & _
''        "upper(CrAccno)='" & UCase(AccNo) & "' and  status<>'A'" & _
''        " and  status<>'D'")
''
''If Not rsTran.EOF And Not rsTran.BOF Then
''    CloseAccounts = "Clearing Transactions are pending for this Account in Clearing Lodgement Voucher Details.."
''    Exit Function
''End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'''''' Checking whether there are any Pending Transactions in Master Amendments
Set rsTran = objQuery.SingleRecordSet("GenMasterAmendmentTemp", "Accno", _
        GenCondition & " and transtatus='P'")

If Not rsTran.EOF And Not rsTran.BOF Then
    CloseAccounts = "Master Amendments are pending for this Account.."
    Exit Function
End If
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
CloseAccounts = "Transaction Successful"
rsTran.Close

Set rsTran = Nothing
Set objAccBal = Nothing
Set objQuery = Nothing

Exit Function
myerr:
CloseAccounts = Err.Description
End Function
