VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "Generation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim ReportCode As String
Dim FileName As String
Dim RepCol As Long
Dim ArrRows As Long
Dim TotLines As Long
Dim BrCode As String
Dim Module As String
Dim MachID As String
Dim StrRepCond As String
Dim QueryRes As String
Dim tempstr As String
Dim iCount As Long
Dim RepColHead As String
Dim RepColInt As Long
Dim ArrColName As Variant
Dim intGrpCol As Long
Dim ArrColAlign As Variant
Dim RsRepInfo As ADODB.Recordset
Dim RsTemp As ADODB.Recordset
Dim AdoRsRep As ADODB.Recordset
Dim AdoRsRepGrp As ADODB.Recordset
Dim ObjFetchRec As Object
Dim AdorsDuplicate As ADODB.Recordset
Dim fldRepGrdTot As String
Dim RepGrdTot As Double
Dim Company As String
Dim CurrCode As String
Dim AppDate As String
Dim User As String
Dim arrRepQry As Variant
Dim arrRepCond As Variant
Dim arrRepData() As Variant
Dim strerror As String
Dim RepFields As String
Dim RepSubTot As Double
Dim RepSubTotCol As Long
Dim reptabname As String
Dim strOrder As String
Dim RepColAlign As String
Dim strGrpFld As String
Dim strGrpByFld As String
Dim arrGrpByFld As Variant
Dim arrGrpingFld As Variant
Dim Grpint As Long
Dim colcnt As Long
Dim GrpCnt As Long
Dim Fldcnt As Long
Dim FiltRows As Long
Dim DupRowsCnt As Long
Dim RsFilterCond As String
Dim RepTabCols As String
Dim GrpColcnt As Long
Dim intSlno As Double
Dim ArrRepSubTot() As Variant



Public Function GetDataForReport(RepCode As String, ReportID As String, ModuleID As String, _
                                 UserId As String, BranchCode As String, _
                                 Machineid As String, ApplicationDate As String, _
                                 RepDataQryDetails As Variant) As Variant

ReportCode = Trim(RepCode)
BrCode = Trim(UCase(BranchCode))
Module = Trim(UCase(ModuleID))
MachID = Trim(Machineid)
User = Trim(UCase(UserId))
AppDate = Format(ApplicationDate, "dd-mm-yyyy")
arrRepQry = RepDataQryDetails
'MsgBox UBound(RepDataQryDetails)
On Error GoTo ErrHand
''''retrieving the report information from table repmst
Set RsRepInfo = CreateObject("ADODB.Recordset")
Set RsTemp = CreateObject("ADODB.Recordset")
Set AdorsDuplicate = CreateObject("ADODB.Recordset")
'''' setting the column names in order - first the data column names then the rest.
'''' the data in the REPORTCOL1,REPORTCOL2.... will consist of the column name, the heading
'''' of the column, its width and its allignment.
'''' eg. the data format is : "ACCNO|Account No.|10|L"

RepFields = "REPORTCOL1,REPORTCOL2,REPORTCOL3,REPORTCOL4,REPORTCOL5,REPORTCOL6,REPORTCOL7," _
    & " REPORTCOL8, REPORTCOL9, REPORTCOL10,REPORTCOL11,REPORTCOL12,REPORTCOL13,REPORTCOL14, " _
    & " REPORTCOL15,REPORTTABLE, REPORTVIEW, REPORTGROUPBYCOL," _
    & " REPORTTOTALCOL,REPORTPAGECOLS,REPORTPAGELINES,REPORTTITLE, " _
    & " REPORTGROUPOFCOL,REPORTORDERCOL,REPORTCONDCOL"
StrRepCond = "REPORTCODE='" & ReportCode & "' and reportmoduleid='" & Module & "' and " _
        & " REPORTID='" & ReportID & "'"
Set ObjFetchRec = CreateObject("queryRecordsets.FetchRecordsets")
Set RsRepInfo = ObjFetchRec.SingleRecordset("REPINFODTLS", RepFields, StrRepCond, "", BrCode, _
                User, MachID, "Report.Generation|GetDataForReport")

If ObjFetchRec.connerror <> "Connected" Then
    strerror = ObjFetchRec.connerror
    GoTo ErrHand
End If
 
 If RsRepInfo.EOF And RsRepInfo.BOF Then
    strerror = "Report is Not Developed."
    GoTo ErrHand
 End If
 
RepCol = RsRepInfo!REPORTPAGECOLS
TotLines = RsRepInfo!REPORTPAGELINES
RsRepInfo.MoveFirst
iCount = 0
RepTabCols = ""
RepColHead = ""
    Do Until UCase(RsRepInfo.Fields(iCount).Name) = "REPORTTABLE"
        If RsRepInfo.Fields(iCount).Value <> "" Then
            ArrColName = Split(RsRepInfo.Fields(iCount).Value, "|", -1)
                    '''' the fields name
            RepTabCols = RepTabCols & IIf(IsNull(ArrColName(0)), "", ArrColName(0) & ",")
                    '''' the heading names, the length for each col, the allign of each col
            If UBound(ArrColName) = 3 Then
                RepColHead = RepColHead & IIf(IsNull(ArrColName(0)), "", _
                        ArrColName(1) & "," & ArrColName(2) & "," & ArrColName(3) & "|")
             ElseIf UBound(ArrColName) = 4 Then
                RepColHead = RepColHead & IIf(IsNull(ArrColName(0)), "", _
                        ArrColName(1) & "," & ArrColName(2) & "," & ArrColName(3) _
                        & "," & ArrColName(4) & "|")
            End If
            Erase ArrColName
        End If
        iCount = iCount + 1
    Loop
    RepColHead = Left(RepColHead, Len(RepColHead) - 1)
    If IsNull(RsRepInfo!REPORTGROUPBYCOL) Then
        RepTabCols = Left(RepTabCols, Len(RepTabCols) - 1)
    Else
        RepTabCols = RepTabCols & RsRepInfo!REPORTGROUPBYCOL
    End If
    
    If RsRepInfo!REPORTCONDCOL <> "" Then
        arrRepCond = Split(RsRepInfo!REPORTCONDCOL, ",", -1)
    ElseIf arrRepQry(0, 0) <> "NOTHING" Then
        strerror = "No Conditional Column specified for this Report"
        GoTo ErrHand
    End If
    '''' the table name for report data
reptabname = IIf(IsNull(RsRepInfo!REPORTTABLE), RsRepInfo!REPORTVIEW, RsRepInfo!REPORTTABLE)

    '''' forming the condition for querying the data for the report based on the parameters
    '''' from the client.  the condition values are sent in form of an arrray.
    '''' the array is for eg: arr(n,2)
    '''' arr(n,0)= "BETWEEN" : the logical sign (=,<>,<,>....)
    '''' arr(n,1)= "1"       : the first value for camparision
    '''' arr(n,2)= "10"      : (optional) the second value for camparision in case of between operator
    
    StrRepCond = ""
    strOrder = ""
    'strOrder = RsRepInfo!REPORTORDERCOL
    strOrder = IIf(IsNull(RsRepInfo!REPORTORDERCOL), "", RsRepInfo!REPORTORDERCOL)
    fldRepGrdTot = ""
    If arrRepQry(0, 0) = "NOTHING" Then
       StrRepCond = ""
    Else
'        If UBound(arrRepQry) <> UBound(arrRepCond) Then
'                strerror = "Condition for Report Generation Not properley formed."
'                GoTo ErrHand
'        Else
            For iCount = 0 To UBound(arrRepQry)
              '''' forming the condition for between clause.
                If UCase(Trim(arrRepQry(iCount, 0))) = "BETWEEN" Then
                    StrRepCond = StrRepCond & " ( " & arrRepCond(iCount) & " between " _
                    & arrRepQry(iCount, 1) & " and " & arrRepQry(iCount, 2) & ") and "
               
               '''''''''' the report grand total formula
               ElseIf UCase(Trim(arrRepQry(iCount, 0))) = "RGT" Then
                    fldRepGrdTot = " nvl(" & arrRepQry(iCount, 1) & ",0)"
               Else
               '''' forming the condition for other rational operators.
                    StrRepCond = StrRepCond & " ( " & arrRepCond(iCount) & arrRepQry(iCount, 0) _
                    & arrRepQry(iCount, 1) & ") and "
                       
                End If
            
            Next iCount
            StrRepCond = Left(StrRepCond, Len(StrRepCond) - 4)
    End If
    
'        End If
        
        '''' forming the group function and group by cols.
        If Not IsNull(RsRepInfo!REPORTGROUPOFCOL) Then
            arrGrpingFld = Split(RsRepInfo!REPORTGROUPOFCOL, "~", -1)
            
            strGrpFld = ""
            For iCount = 0 To UBound(arrGrpingFld)
                strGrpFld = strGrpFld & " sum(" & arrGrpingFld(iCount) & "),"
            Next iCount
            strGrpFld = Left(strGrpFld, Len(strGrpFld) - 1)
            ''strGrpFld = RsRepInfo!REPORTGROUPOFCOL
            strGrpByFld = IIf(IsNull(RsRepInfo!REPORTGROUPBYCOL), "", RsRepInfo!REPORTGROUPBYCOL)
            strOrder = IIf(strOrder = "", IIf(IsNull(RsRepInfo!REPORTGROUPBYCOL), "", RsRepInfo!REPORTGROUPBYCOL), strOrder)
            If StrRepCond = "" And strGrpByFld <> "" Then
                StrRepCond = "1=1 "
            End If
        End If
        
                    
        
    Set AdoRsRep = ObjFetchRec.SingleRecordset(reptabname, RepTabCols, StrRepCond, strOrder)
    
    
If ObjFetchRec.connerror <> "Connected" Then
    strerror = ObjFetchRec.connerror
    GoTo ErrHand
End If
 
 If AdoRsRep.EOF And AdoRsRep.BOF Then
    strerror = "No Records to Generate" & RsRepInfo!REPORTTITLE & "."
    GoTo ErrHand
 End If
 
 If Trim(UCase(RsRepInfo!REPORTTOTALCOL)) <> "" Then
    Set RsTemp = ObjFetchRec.SingleRecordset(reptabname, fldRepGrdTot, StrRepCond)
     
    If Not RsTemp.EOF And Not RsTemp.BOF Then
    RepGrdTot = RsTemp(0)
        
    End If
 End If
 
'''' assigning rows to array


If strGrpFld <> "" Then
'Set RsTemp = ObjFetchRec.SingleRecordset(reptabname, " Distinct " & strGrpByFld, StrRepCond, strOrder)
   If strGrpByFld <> "" Then
    StrRepCond = StrRepCond & "  group by " & strGrpByFld
   End If
    Set AdoRsRepGrp = ObjFetchRec.SingleRecordset(reptabname, strGrpFld, StrRepCond) ', strOrder)

    If ObjFetchRec.connerror <> "Connected" Then
        strerror = ObjFetchRec.connerror
        GoTo ErrHand
    End If

     If AdoRsRepGrp.EOF And AdoRsRepGrp.BOF Then
        strerror = "No Records to Generate" & RsRepInfo!REPORTTITLE & "."
        GoTo ErrHand
     End If
     Grpint = (AdoRsRepGrp.RecordCount * 4)
Else
    Grpint = 0
End If



 ArrRows = 3 '''''''''EXTRA ROWs FOR report GRAND TOTAL
 
 ''''' one row extra for sending the report title
 
ArrRows = ArrRows + ((AdoRsRep.RecordCount) + (Grpint)) + 1

''''''' assining of rows in the array completed''''''''''''''''''''''''''''''''''''''''''''''


Grpint = -1
AdoRsRep.MoveFirst


If IsNull(RsRepInfo!REPORTGROUPBYCOL) Then
    ReDim arrRepData(ArrRows, AdoRsRep.Fields.Count - 1)
Else
    ReDim arrRepData(ArrRows, AdoRsRep.Fields.Count - 1)
End If
arrRepData(0, 0) = RsRepInfo!REPORTTITLE & "," & TotLines & "," & RepCol

If strGrpByFld <> "" Then
    arrGrpByFld = Split(strGrpByFld, ",", -1)
    intGrpCol = UBound(arrGrpByFld) + 1
    Grpint = UBound(arrGrpByFld)
    For iCount = 0 To UBound(arrGrpByFld)
        arrRepData(1, iCount) = arrGrpByFld(iCount)
    Next iCount
    
End If

Erase ArrColName
ArrColName = Split(RepColHead, "|", -1)

''''' sending the total lines and the total cols for the reporpt to the client


''''Column Headings of the report.
For iCount = 0 To UBound(ArrColName)
   arrRepData(1, iCount + intGrpCol) = ArrColName(iCount)
Next iCount




'''''''''' sub total array
ReDim ArrRepSubTot(1, UBound(arrRepData, 2))

 ''''*********   sending the report data to the client thru an array *********************
 '''' design of the array arr(AdoRsRep.RecordCount + AdoRsRepGrp.RecordCount,AdoRsRep.fields)
Set AdorsDuplicate = AdoRsRep.Clone
AdoRsRep.MoveFirst
AdorsDuplicate.MoveFirst
RepColInt = intGrpCol
For iCount = 2 To UBound(arrRepData) - 3

'AdoRsRep.Move (iCount - 1)
    If Grpint >= 0 Then
        
        RsFilterCond = ""
        For GrpCnt = 0 To UBound(arrGrpByFld)
            For colcnt = 0 To AdoRsRep.Fields.Count - 1
                If UCase(AdoRsRep.Fields(colcnt).Name) = UCase(arrGrpByFld(GrpCnt)) Then
                        RsFilterCond = RsFilterCond & " and " & arrGrpByFld(GrpCnt) & "='" _
                                    & AdoRsRep.Fields(colcnt).Value & "'"
                     arrRepData(iCount, GrpCnt) = AdoRsRep.Fields(colcnt).Value
                    'arrRepData(iCount, GrpCnt) = AdoRsRep.Fields(AdoRsRep.Fields.Count).Value
                    
                    intSlno = 1
                End If
               
                
            Next colcnt
               
         Next GrpCnt
          iCount = iCount + 1
            FiltRows = 0
                 RsFilterCond = Right(RsFilterCond, Len(RsFilterCond) - 4)
                 AdorsDuplicate.Filter = RsFilterCond
                FiltRows = AdorsDuplicate.RecordCount
            RepSubTot = 0
         For DupRowsCnt = 0 To FiltRows - 1
         '''''''' assigning of report sub totals '''''''''''''''
         'arrRepData(iCount, 0) = intSlno
         'Erase ArrRepSubTot
         'UBound(ArrColName)
            
            'If intGrpCol = 0 Then intGrpCol = 1
            'For colcnt = 0 To AdorsDuplicate.Fields.Count - (intGrpCol)
            For colcnt = 0 To UBound(ArrColName)
                arrRepData(iCount, colcnt + RepColInt) = AdorsDuplicate.Fields(colcnt).Value
'                    For DupColcnt = 0 To AdoRsRep.Fields.Count - 1
'                        If UCase(AdoRsRep.Fields(colcnt).Name) = UCase(arrGrpByFld(GrpCnt)) Then
'
            Next colcnt
            
            For GrpColcnt = 0 To UBound(arrGrpingFld)
                For colcnt = 0 To UBound(ArrColName)
                    If UCase(AdorsDuplicate.Fields(colcnt).Name) = _
                                    UCase(arrGrpingFld(GrpColcnt)) Then
                         If ArrRepSubTot(0, colcnt + RepColInt) = "" Then ArrRepSubTot(0, colcnt + RepColInt) = 0
                         ArrRepSubTot(0, colcnt + RepColInt) = IIf(IsNull(AdorsDuplicate.Fields(colcnt).Value), 0, _
                                    AdorsDuplicate.Fields(colcnt).Value) + ArrRepSubTot(0, colcnt + RepColInt)
'                         ArrRepSubTot(1, colcnt + 1) = IIf(IsNull(AdorsDuplicate.Fields(colcnt).Value), 0, AdorsDuplicate.Fields(colcnt).Value) _
'                                                        + ArrRepSubTot(1, colcnt + 1)
'RepSubTot = RepSubTot + AdorsDuplicate.Fields(colcnt).Value
                         'RepSubTotCol = colcnt + 1
                    End If
                Next colcnt
            Next GrpColcnt
            
            intSlno = intSlno + 1
            AdorsDuplicate.MoveNext
            AdoRsRep.MoveNext
            
            
           ' MsgBox AdoRsRep.AbsolutePosition
            iCount = iCount + 1
         Next DupRowsCnt
         iCount = iCount + 1
         '''' assinging of the sub total to the array
            arrRepData(iCount, 0) = "Sub Tot:"
            
           ' For colcnt = 0 To AdorsDuplicate.Fields.Count - (intGrpCol + 1)
              For colcnt = 0 To UBound(ArrColName)
                If ArrRepSubTot(0, colcnt + RepColInt) <> Empty Then
                    arrRepData(iCount - 1, colcnt + RepColInt) = String(Len(ArrRepSubTot(0, colcnt + RepColInt)) + 4, "-")
                    arrRepData(iCount, colcnt + RepColInt) = ArrRepSubTot(0, colcnt + RepColInt)
                    ArrRepSubTot(1, colcnt + RepColInt) = ArrRepSubTot(0, colcnt + RepColInt) + ArrRepSubTot(1, colcnt + RepColInt)
                    arrRepData(iCount + 1, colcnt + RepColInt) = String(Len(ArrRepSubTot(0, colcnt + RepColInt)) + 4, "-")
                    ArrRepSubTot(0, colcnt + RepColInt) = ""
                End If
                
                'arrRepData(iCount, colcnt + 1) = ArrRepSubTot(0, colcnt + 1)
                'ArrRepSubTot(0, GrpColcnt) = 0
         '''''''''''' accumilating the grand total for the sub otal columns.''''''''''
                'ArrRepSubTot(1, colcnt + 1) = ArrRepSubTot(1, colcnt + 1) + ArrRepSubTot(0, colcnt + 1)
                ArrRepSubTot(0, colcnt + 1) = ""
            Next colcnt
            iCount = iCount + 1
            
''            For GrpColcnt = 0 To UBound(arrGrpingFld)
''                For colcnt = 0 To AdorsDuplicate.Fields.Count - 2
''                    If UCase(AdorsDuplicate.Fields(colcnt).Name) = _
''                                    UCase(arrGrpingFld(GrpColcnt)) Then
''                         ArrRepSubTot(colcnt + 1) = ArrRepSubTot(colcnt + 1) + AdorsDuplicate.Fields(colcnt).Value
'''                         RepSubTot = RepSubTot + AdorsDuplicate.Fields(colcnt).Value
''                         'RepSubTotCol = colcnt + 1
''                    End If
''                Next colcnt
''            Next GrpColcnt
            
'''            arrRepData(iCount, RepSubTotCol) = RepSubTot
'''            RepSubTot = 0
           ' iCount = iCount + 1
           
    Else
        ''''' If no groupping is required then the rows are directly send to the array
        intSlno = 1
       ' arrRepData(iCount, 0) = iCount
        For colcnt = 0 To AdoRsRep.Fields.Count - 1
            'arrRepData(iCount + 1, 0) = intSlno
              arrRepData(iCount, colcnt) = AdoRsRep.Fields(colcnt).Value
        
        Next colcnt
        
        If Not IsNull(RsRepInfo!REPORTGROUPOFCOL) Then
            For GrpColcnt = 0 To UBound(arrGrpingFld)
                    For colcnt = 0 To UBound(ArrColName)
                        If UCase(AdoRsRep.Fields(colcnt).Name) = _
                                        UCase(arrGrpingFld(GrpColcnt)) Then
                             'If ArrRepSubTot(0, colcnt) = "" Then ArrRepSubTot(0, colcnt) = 0
                             ArrRepSubTot(1, colcnt) = IIf(IsNull(AdoRsRep.Fields(colcnt).Value), ArrRepSubTot(1, colcnt), _
                                        AdoRsRep.Fields(colcnt).Value + ArrRepSubTot(1, colcnt))
            
            
                        End If
                Next colcnt
            Next GrpColcnt
        End If
        
        intSlno = intSlno + 1
        AdoRsRep.MoveNext
         If AdoRsRep.EOF Then
            Exit For
         End If
    End If

Next iCount
If IsNull(RsRepInfo!REPORTGROUPOFCOL) = False Then
'''''''''' assigning of report column wise grand total and report grandtotal
    arrRepData(UBound(arrRepData) - 2, 0) = "Total : "
    
    For colcnt = 0 To UBound(ArrRepSubTot, 2)
        If ArrRepSubTot(1, colcnt) <> Empty Then
            'arrRepData(UBound(arrRepData) - 2, colcnt) = String(Len(ArrRepSubTot(0, colcnt)), "_")
            arrRepData(UBound(arrRepData) - 1, colcnt) = String(Len(ArrRepSubTot(1, colcnt)) + 4, "-")
        End If
        arrRepData(UBound(arrRepData) - 2, colcnt) = ArrRepSubTot(1, colcnt)
    Next colcnt
    
    If RepGrdTot <> 0 Then
        arrRepData(UBound(arrRepData), 0) = RsRepInfo!REPORTTOTALCOL
        arrRepData(UBound(arrRepData), 1) = RepGrdTot
    End If
End If
 GetDataForReport = arrRepData

Set ObjFetchRec = Nothing
Exit Function

ErrHand:
ReDim arrRepData(0, 1) As Variant

arrRepData(0, 0) = "ERROR"

    If strerror = "" Then
        arrRepData(0, 1) = Err.Number & " : " & Err.Description
    Else
        arrRepData(0, 1) = strerror
    End If
    Set ObjFetchRec = Nothing
GetDataForReport = arrRepData

End Function

