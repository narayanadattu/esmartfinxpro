VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "UserTransactions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Public Function GenerateNReturnVoucherNo(ByVal i_BrCode As String, i_CurrencyCode As String, _
ByVal i_ClearingType As String, ByVal i_LodgementDt As Date, ByVal i_ApplicationDt As Date, _
ByVal i_UserId As String, ByVal i_MachineId As String, ByRef o_VoucherNo As String) As String
    
    On Error GoTo ErrHandler
    'Desc : Generate Voucher Number
    
    Dim objQuery As Object, ObjTrans As Object, ObjContext As Object
    Dim objAuto As Object
    Dim Rstemp As ADODB.Recordset
    Dim RsAutoPmt As ADODB.Recordset
    Dim AutoFlds As String, AutoValues As String, AutoCondition As String
    Dim sLodgementDate As String, TransResult As String
    Dim AccNoPrefix As String, AccNoSuffix As String, AutoNumValue As String
    Dim AutoPmtCondition As String, InitialValue As String, strDateRes As String
    Dim ActualAccNo As Integer, LineNo As Integer
    Dim ArrRowValues As Variant
    Dim sApplicationDate As String, Errmsg As String
    
    o_VoucherNo = ""
    
    sLodgementDate = Format(i_LodgementDt, "dd-mmm-yyyy")
    sApplicationDate = Format(i_ApplicationDt, "dd-mmm-yyyy")
    
    LineNo = 1
    Set ObjContext = GetObjectContext
    
    LineNo = 2
    Set objQuery = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")
    Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    
    Set Rstemp = CreateObject("ADODB.Recordset")
    
    LineNo = 3
    AutoFlds = "BranchCode,maxautotablename,maxautofieldName," & _
            "CLEARINGTYPE,LODGEMENTDATE,currencycode"
            
    AutoValues = "'" & i_BrCode & "','CLGLODGEMENTVOUCHERDTLS','VOUCHERNO'," & _
            "'" & i_ClearingType & "','" & sLodgementDate & "','" & i_CurrencyCode & "'"
            
    AutoCondition = "branchcode='" & i_BrCode & "' and " & _
              "maxautotablename='CLGLODGEMENTVOUCHERDTLS' and " & _
              "maxautofieldName='VOUCHERNO' AND currencycode='" & i_CurrencyCode & "' and " & _
              "clearingtype='" & i_ClearingType & "' and " & _
              "lodgementdate=to_date('" & sLodgementDate & "','dd-mm-yyyy')"

    AccNoPrefix = "": AccNoSuffix = "": ActualAccNo = 0
    AutoNumValue = ""
    
    AutoPmtCondition = "MAXAUTOTABLENAME='CLGLODGEMENTVOUCHERDTLS' and " & _
                    "MAXAUTOFIELDNAME='VOUCHERNO'"
    
    LineNo = 4
    Set RsAutoPmt = CreateObject("ADODB.Recordset")
    Set RsAutoPmt = objQuery.SingleRecordSet("GENAUTONUMBERPMT", "*", AutoPmtCondition)
    If RsAutoPmt.EOF And RsAutoPmt.BOF Then
        ObjContext.SetAbort
        Set objQuery = Nothing
        Set ObjContext = Nothing
        Set ObjTrans = Nothing
        GenerateNReturnVoucherNo = "Error: Parameters for the AccountNo to be specified"
        Exit Function
    End If
    InitialValue = ""
    strDateRes = ""
    
    LineNo = 5
    Set Rstemp = objQuery.SingleRecordSet("GENAUTONUMMAX", "*", AutoCondition & " FOR UPDATE")
    'Set Rstemp = objQuery.SingleRecordSet("GENAUTONUMMAX", "*", AutoCondition)
            
    LineNo = 6
    TransResult = ""
    Set objAuto = CreateObject("AutoNumber.Generation")
    AutoNumValue = objAuto.GetAutoNumber("GENAUTONUMMAX", "MAXAUTONUM", _
        AutoCondition, CStr(RsAutoPmt!InitialValue))
                                
    If Mid(AutoNumValue, 1, 5) = "ERROR" Then
        ObjContext.SetAbort
        Set objQuery = Nothing
        Set ObjContext = Nothing
        Set ObjTrans = Nothing
        AutoNumValue = Replace(AutoNumValue, Chr(10), "")
        AutoNumValue = Replace(AutoNumValue, Chr(13), "")
        GenerateNReturnVoucherNo = "Error: " & AutoNumValue
        Exit Function
    End If
    Set objAuto = Nothing
            
    LineNo = 7
    ReDim ArrRowValues(0) As Variant
    
    If AutoNumValue = CStr(RsAutoPmt!InitialValue) Then
        AutoFlds = AutoFlds & ",MAXAUTONUM"
        ArrRowValues(0) = AutoValues & "," & AutoNumValue
        TransResult = ""
        Set ObjContext = GetObjectContext

        LineNo = 8
        TransResult = ObjTrans.InsertRecord("GENAUTONUMMAX", AutoFlds, ArrRowValues, _
        i_BrCode, i_UserId, i_MachineId, sApplicationDate, "N")
        If TransResult <> "Trans Completed" Then
            ObjContext.SetAbort
            Set objQuery = Nothing
            Set ObjContext = Nothing
            Set ObjTrans = Nothing
            TransResult = Replace(TransResult, Chr(10), "")
            TransResult = Replace(TransResult, Chr(13), "")
            GenerateNReturnVoucherNo = TransResult
            
            Exit Function
        End If
    Else
        LineNo = 10
        ArrRowValues(0) = AutoNumValue
        AutoFlds = "MAXAUTONUM"
        Set ObjContext = GetObjectContext
        TransResult = objQuery.ModifyQueriedTrans("GENAUTONUMMAX", AutoFlds, _
                        ArrRowValues, AutoCondition, i_BrCode, i_UserId, i_MachineId)
        'TransResult = ObjTrans.UpdateRecord("GENAUTONUMMAX", AutoFlds, ArrRowValues, _
        'AutoCondition, i_BrCode, i_UserId, i_MachineId, sApplicationDate, "N")
        
        If TransResult <> "Trans Completed" Then
            ObjContext.SetAbort
            Set ObjContext = Nothing
            TransResult = Replace(TransResult, Chr(10), "")
            TransResult = Replace(TransResult, Chr(13), "")
            GenerateNReturnVoucherNo = TransResult
            Exit Function
        End If
    End If
    ObjContext.SetComplete
        
    LineNo = 11
    
    AccNoPrefix = Trim(RsAutoPmt!Prefixvalue) & ""
    AccNoSuffix = Trim(RsAutoPmt!suffixvalue) & ""
    ActualAccNo = CDbl(AutoNumValue)
    AutoNumValue = Trim(RsAutoPmt!Prefixvalue) & AutoNumValue & Trim(RsAutoPmt!suffixvalue)
        
    o_VoucherNo = AutoNumValue
    GenerateNReturnVoucherNo = "Successfully Completed"
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If RsAutoPmt.State = 1 Then RsAutoPmt.Close
    Set RsAutoPmt = Nothing
    
    
    Exit Function
    
ErrHandler:
    ObjContext.SetAbort
    Set ObjTrans = Nothing
    Set ObjContext = Nothing
    Set objQuery = Nothing
    
    Errmsg = "Error: " & Err.Number & ", Line No: " & LineNo & _
    ", Err Msg: " & Err.Description
    
    GenerateNReturnVoucherNo = Errmsg
    
    objErrlog.LogError "GeneralTranQueries", "GenerateNReturnVoucherNo", Err.Number, Err.Description
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If RsAutoPmt.State = 1 Then RsAutoPmt.Close
    Set RsAutoPmt = Nothing

End Function


Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
