VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "TransactionQueries"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim Rstemp As ADODB.Recordset
Dim StrQuery As String
Dim DbLink As String
Dim Icount As Integer
Dim objdblink As Object
Dim ArrLink As Variant
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Public AdoConnObj As ADODB.Connection ' Connection Object
Public objError As Object
Public ArrError As Variant
Public ConnError As String 'error object




Public Function GLCodes(BRCode As String, ModuleCode As String, _
                        Optional GLCategory As String) As ADODB.Recordset

Dim StrModuleCode As String, strBranchCode As String
Dim strGlCatCondition As String
On Error GoTo errhand

Call DBConnection

If ConnError <> "Connected" Then Exit Function      '**** Not executing further due to connection faliure
    ConnError = ""
    Set Rstemp = CreateObject("ADODB.Recordset")
    StrQuery = ""
    strBranchCode = Trim(BRCode)
    StrModuleCode = Trim(ModuleCode)
    
'''''''''''****please do not change this piece of code it will effect the list of glcodes****
    If Trim(GLCategory) = "" Or UCase(Trim(GLCategory)) = "A" Then
        strGlCatCondition = " and glcode in (select glcode from GENGLMASTMST where moduleid='" _
        & StrModuleCode & "' and GLCATEGORY='A')"   ''''''''''returns transactional glcodes"
    Else
        strGlCatCondition = " and glcode in (select glcode from GENGLMASTMST where moduleid='" _
        & StrModuleCode & "' and GLCATEGORY='" & GLCategory & "')"   ''''''''' returns other category glcodes based on the request
    End If
''''''''''''*********************************************************************************
    
If UCase(Trim(StrModuleCode)) = "GL" Then

    StrQuery = "select glcode,Narration from genglsheetmst" & DbLink _
    & " where (moduleid in (select moduleid " _
    & " from genmoduletypesmst" & DbLink _
    & " where upper(trim(implementedyn))<>'Y' and branchcode='" _
    & strBranchCode & "') or trim(moduleid)='GL') and (trim(branchcode)='" _
    & strBranchCode & "') and (status='R') order by glcode"
Else

    StrQuery = "select glcode,Narration from genglsheetmst" & DbLink _
    & "  where moduleid in (select moduleid from genmoduletypesmst" _
    & DbLink & "  where trim(moduleid)='" & StrModuleCode & "') " _
    & " and trim(branchcode)='" & strBranchCode & "' and status='R' " _
    & strGlCatCondition & "  order by glcode"
    
End If
    
    Rstemp.Open StrQuery, AdoConnObj
    If Rstemp.EOF And Rstemp.BOF Then
        ConnError = "Glcodes have not created for this Module."
    End If
    
    Set GLCodes = Rstemp
    
    Rstemp.ActiveConnection = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
    
errhand:
ConnError = "GLCodes Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description

objErrlog.LogError "GeneralTranQueries", "GLCodes", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    
End Function

Public Function AccountNumbers(BRCode As String, Optional ModuleCode As String, _
                               Optional GLcode As String, Optional CurrencyCode As String, _
                               Optional AccStatus As String, Optional TableName As String, _
                               Optional RemType As String, Optional accSearch As String) As ADODB.Recordset
                             
Dim StrModuleCode As String, strBranchCode As String, strGLCode As String
Dim status As String
Dim TranStatus As String
Dim arrStatus As Variant
Dim arrTrStatus As Variant
Dim BlnGLcode As Boolean
Dim strTabName As String
Dim strRemType As String
On Error GoTo errhand
If ModuleCode = "" Then
    ConnError = "Module ID is Not Optional"
    Exit Function
End If

Call DBConnection


If ConnError <> "Connected" Then Exit Function      '**** Not executing further due to connection faliure
   ' ConnError = ""
    Set Rstemp = CreateObject("ADODB.Recordset")
    StrQuery = ""
    strBranchCode = UCase(Trim(BRCode))
    StrModuleCode = UCase(Trim(ModuleCode))
    strGLCode = UCase(Trim(GLcode))
    strRemType = UCase(Trim(RemType))
    If AccStatus = "" Then
        status = "'R'"
        TranStatus = "'A'"
    Else
       arrStatus = Split(AccStatus, ",", -1)
       
        If arrStatus(0) = "A" Then
            status = ""
            TranStatus = ""
        Else
            arrTrStatus = Split(arrStatus(0), "OR", -1)
            
                For Icount = 0 To UBound(arrTrStatus)
                    status = status & "'" & UCase(Trim(arrTrStatus(Icount))) & "',"
                Next
                
            status = Left(status, Len(status) - 1)
            arrTrStatus = Empty
            
            arrTrStatus = Split(arrStatus(1), "OR", -1)
                For Icount = 0 To UBound(arrTrStatus)
                    TranStatus = TranStatus & "'" & UCase(Trim(arrTrStatus(Icount))) & "',"
                Next
            TranStatus = Left(TranStatus, Len(TranStatus) - 1)
'            status = UCase(Trim(arrStatus(0)))
'            TranStatus = UCase(Trim(arrStatus(1)))
        End If
   End If
    
    If TableName = "" Then
    
        StrQuery = "select MasterTable,GLCODEYN from genmodulemst" & DbLink _
        & "  where moduleid ='" & StrModuleCode & "'"
        
        StrQuery = UCase(StrQuery)
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        If Rstemp.State = 0 Then GoTo errhand
        strTabName = Rstemp!MasterTable
        If UCase(Rstemp!GlcodeYN) = "Y" Then BlnGLcode = True
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        
        If BlnGLcode = True Then
            If Trim(CurrencyCode) = "" Then
               If status = "" Then
                StrQuery = "select ACCNO,Name,CUSTOMERID,status from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                & " and upper(trim(glcode))='" & Trim(strGLCode) & "' " '''' and upper(trim(status))='R' order by Name"
               Else
                 StrQuery = "select ACCNO,Name,CUSTOMERID,status from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                & " and upper(trim(glcode))='" & Trim(strGLCode) & "' and upper(trim(status)) in (" _
                & status & ") and transtatus in (" & TranStatus & ") "
               End If
            Else
                
                If StrModuleCode = "SCR" Then
                    StrQuery = "select ACCNO,Name,Customerid,status from " & strTabName & DbLink & " where  upper(trim(branchcode))='" & strBranchCode & "' " _
                        & " and upper(trim(glcode))='" & Trim(strGLCode) & "' and upper(trim(status)) in (" & status _
                        & ") and transtatus in (" & TranStatus & ") and upper(trim(currencycode))='" _
                        & UCase(Trim(CurrencyCode)) & "' "
            
                ElseIf status = "" Then
                     StrQuery = "select ACCNO,Name,Customerid,status from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                        & " and upper(trim(glcode))='" & Trim(strGLCode) _
                        & "' and upper(trim(currencycode))='" & UCase(Trim(CurrencyCode)) & "' "
                Else
                 
                    StrQuery = "select ACCNO,Name,Customerid,status from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                        & " and upper(trim(glcode))='" & Trim(strGLCode) & "' and upper(trim(status)) in (" & status _
                        & ") and transtatus in (" & TranStatus & ") and upper(trim(currencycode))='" _
                        & UCase(Trim(CurrencyCode)) & "' "
                     If Not accSearch = "" Then
                        Dim searchby() As String
                        searchby = Split(UCase(accSearch), "|")
                        If searchby(0) = "NAME" Then
                            StrQuery = StrQuery & "AND upper(NAME) LIKE '%" & searchby(1) & "%'"
                        Else
                            StrQuery = StrQuery & "AND ACCNO LIKE '" & searchby(1) & "%'"
                        End If
                     End If
                        
               End If
            End If
        Else
            If status = "" Then
                StrQuery = "select ACCNO,Name,CUSTOMERID,status from " & strTabName & DbLink _
                & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                & "  " '''' and upper(trim(status))='R' order by Name"
            Else
                StrQuery = "select ACCNO,Name,CUSTOMERID,status from " & strTabName & DbLink _
                & " where upper(trim(branchcode))='" & strBranchCode & "' " _
                & " and upper(trim(status)) in (" & status & ") and transtatus in (" & TranStatus _
                & ") "
            End If
        
        End If
    Else
        
        strTabName = TableName
            If status = "" Then
             StrQuery = "select ACCNO,Name,Customerid from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
            & " and upper(trim(glcode))='" & Trim(strGLCode) _
            & "' and upper(trim(moduleid))='" & UCase(Trim(ModuleCode)) & "' "
           Else
            StrQuery = "select ACCNO,Name,Customerid from " & strTabName & DbLink & " where upper(trim(branchcode))='" & strBranchCode & "' " _
            & " and upper(trim(glcode))='" & Trim(strGLCode) & "' and upper(trim(status)) in ( " & status _
            & ") and transtatus in (" & TranStatus & ") and upper(trim(moduleid))='" _
            & UCase(Trim(ModuleCode)) & "' "
           End If
    End If
        If strRemType <> "" Then
            StrQuery = StrQuery & " and MODEOFREMITTANCE='" & strRemType & "'"
        End If
        StrQuery = StrQuery & " order by Accno"
       StrQuery = UCase(StrQuery)
    Set Rstemp = AdoConnObj.Execute(StrQuery)
    If Rstemp.State = 0 Then GoTo errhand
    
    ConnError = ""

    Set AccountNumbers = Rstemp
    
    Rstemp.ActiveConnection = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
    Exit Function
    
errhand:
ConnError = "No Account Numbers Exist for This Module"

objErrlog.LogError "GeneralTranQueries", "AccountNumbers", Err.Number, Err.Description

    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

 End Function



'********* For retrieving Branch Code based On UserID **************

Public Function Branchcodes(UserID As String) As ADODB.Recordset

Dim StrUser As String
On Error GoTo errhand

Call DBConnection  '*********** DataBase Connection.**************

If ConnError <> "Connected" Then Exit Function      '**** Not executing further due to connection faliure
    ConnError = ""
    Set Rstemp = Nothing
    Set Rstemp = CreateObject("ADODB.Recordset")
    StrQuery = ""
    StrUser = UCase(Trim(UserID))
        
        ''New code is
        StrQuery = "select distinct(Branch.Branchcode) BranchCode,Branch.Narration " & _
        " Narration from genbankbranchmst" & DbLink & " Branch, GenUserMst" & DbLink & _
        " GenUser, GENBRANCHPMT BrnchPmt " & _
        " where ((upper(trim(GenUser.userid))='" & Trim(StrUser) _
        & "' and upper(trim(Genuser.ABBUSERYN))='Y') or Branch.branchcode =" & _
        "(select branchcode from genusermst" & DbLink & " where upper(trim(userid))='" & _
        Trim(StrUser) & "')) AND Branch.Branchcode=BrnchPmt.Branchcode " & _
        " order by BranchCode"
    
    Rstemp.Open StrQuery, AdoConnObj
    
    Set Branchcodes = Rstemp
    
    Rstemp.ActiveConnection = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
    Exit Function
    
errhand:


    ConnError = "Modules Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
    
    objErrlog.LogError "GeneralTranQueries", "Branchcodes", Err.Number, Err.Description
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
    
    
End Function

Public Function ModuleID(BRCode As String, _
                         Optional AllModulesYN As String, _
                         Optional UserID As String, _
                         Optional VouchingYN As String, _
                         Optional ModuleCondition As String) As ADODB.Recordset
Dim strBrcode As String, StrUser As String
Dim strVouchCondition As String
Dim strOptModCond As String
On Error GoTo errhand

Call DBConnection

If ConnError <> "Connected" Then Exit Function      '**** Not executing further due to connection faliure
    ConnError = ""
    Set Rstemp = CreateObject("ADODB.Recordset")
    StrQuery = ""
    strBrcode = UCase(Trim(BRCode))
    StrUser = IIf(IsNull(Trim(UserID)), "", UCase(Trim(UserID)))
    strOptModCond = IIf(IsNull(ModuleCondition), "", Trim(ModuleCondition))
    If strOptModCond <> "" Then
        strOptModCond = " and " & strOptModCond
    End If
'''''''''''****please do not change this piece of code it will effect the list of modules****
    If Trim(VouchingYN) = "" Or UCase(Trim(VouchingYN)) = "Y" Then
        strVouchCondition = " and gmm.VOUCHINGYN='Y'"   ''''''''''returns modules with transaction facility
    Else
        strVouchCondition = ""    ''''''''' returns all modules
    End If
''''''''''''*********************************************************************************

'''    If StrUser <> "" Then
        If Trim(AllModulesYN) = "" Or Trim(AllModulesYN) = "Y" Then
            StrQuery = "Select gmt.ModuleID ModuleID,gmt.Narration Narration,gmm.Mastertable Mastertable " _
            & " from GenModuleTypesMST" & DbLink & " gmt, genmodulemst" & DbLink & " gmm where " _
            & "trim(gmt.BranchCode)='" & Trim(strBrcode) & "' and upper(gmt.IMPLEMENTEDYN)='Y' " _
            & "and gmt.ModuleID =gmm.ModuleID " & strVouchCondition & strOptModCond & " order by gmt.ModuleID"
            
        Else
            StrQuery = "Select ModuleID,Narration from GenModuleTypesMST" & DbLink & "  where trim(BranchCode)='" _
            & Trim(strBrcode) & "' and upper(IMPLEMENTEDYN)='Y' and ModuleID in (select gmm.moduleid " _
            & " from genmodulemst" & DbLink & " gmm where trim(gmm.mastertable)is not null " _
            & strVouchCondition & strOptModCond & " )" & strOptModCond & " order by ModuleID"
        End If

    If Rstemp.State = 1 Then Rstemp.Close
    Rstemp.Open StrQuery, AdoConnObj
    If Rstemp.EOF And Rstemp.BOF Then
        ConnError = "Modules have not been implemented for this branch."
        GoTo errhand
    End If
    
    Set ModuleID = Rstemp

    Rstemp.ActiveConnection = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
Exit Function


errhand:
If ConnError = "" Then
    ConnError = "Modules Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

objErrlog.LogError "GeneralTranQueries", "ModuleID", Err.Number, Err.Description

    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
End Function
Public Function GetTranNo(Branchcode As String) As String
    On Error GoTo errh
    If Branchcode = "" Then
     GetTranNo = "Branch Code should be sent or Sequence doesnot exists"
    End If
    
    Call DBConnection
    If ConnError <> "Connected" Then
        GetTranNo = ConnError
        GetTranNo = Replace(GetTranNo, Chr(10), "")
        GetTranNo = Replace(GetTranNo, Chr(13), "")
        Exit Function
    End If
    Dim recTranNo As Object
    Dim seqName As String
        seqName = "SEQTRANNO" & Branchcode
    Set recTranNo = CreateObject("Adodb.Recordset")
    Dim sqname As String
    
      sqname = "select " & seqName & DbLink & ".nextval Tranno from dual"
  
    Set recTranNo = AdoConnObj.Execute(sqname, adCmdText)
       
    If Not recTranNo.EOF And Not recTranNo.BOF Then
        GetTranNo = recTranNo!tranno
    Else
        GetTranNo = "Tran No is Locked"
    End If
        
    If recTranNo.State = 1 Then recTranNo.Close
    Set recTranNo = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
errh:
 GetTranNo = Err.Number & " : " & Err.Description
 GetTranNo = Replace(GetTranNo, Chr(10), "")
 GetTranNo = Replace(GetTranNo, Chr(13), "")
 
 objErrlog.LogError "GeneralTranQueries", "GetTranNo", Err.Number, Err.Description
 
If recTranNo.State = 1 Then recTranNo.Close
Set recTranNo = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    
End Function

Public Function GetBatchno(Branchcode As String) As String
  On Error GoTo errh
  If Branchcode = "" Then
     GetBatchno = "Branch Code should be sent or Sequence doesnot exists"
  End If
  Call DBConnection
    If ConnError <> "Connected" Then
        GetBatchno = ConnError
        GetBatchno = Replace(GetBatchno, Chr(10), "")
        GetBatchno = Replace(GetBatchno, Chr(13), "")
        Exit Function
    End If
  Dim recBatch As Object
  Dim seqName As String
      seqName = "SEQBATCHNO" & Branchcode
  Set recBatch = CreateObject("Adodb.Recordset")
  
  Dim sqname As String
      sqname = "select " & seqName & DbLink & ".nextval BatchNo from dual"
      
  Set recBatch = AdoConnObj.Execute(sqname, adCmdText)
      If Not recBatch.EOF And Not recBatch.BOF Then
         GetBatchno = recBatch!BatchNo
      Else
         GetBatchno = "Batch No is Locked"
      End If
      
    If recBatch.State = 1 Then recBatch.Close
    Set recBatch = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
    Exit Function
errh:
GetBatchno = Err.Number & " : " & Err.Description
GetBatchno = Replace(GetBatchno, Chr(10), "")
GetBatchno = Replace(GetBatchno, Chr(13), "")

objErrlog.LogError "GeneralTranQueries", "GetBatchno", Err.Number, Err.Description

    If recBatch.State = 1 Then recBatch.Close
    Set recBatch = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
  
End Function
Public Function SystemDate() As String
Dim recTrandate As Object
On Error GoTo myerr
  Call DBConnection
    If ConnError <> "Connected" Then
        SystemDate = ConnError
        SystemDate = Replace(SystemDate, Chr(10), "")
        SystemDate = Replace(SystemDate, Chr(13), "")
        Exit Function
    End If
Set recTrandate = CreateObject("Adodb.Recordset")
Set recTrandate = AdoConnObj.Execute("select to_char(sysdate,'dd-mon-yyyy hh:mi:ss') DateNTime from dual", , adCmdText)
SystemDate = recTrandate!DateNTime

If recTrandate.State = 1 Then recTrandate.Close
Set recTrandate = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    
Exit Function
myerr:
SystemDate = Err.Number & " : " & Err.Description
SystemDate = Replace(SystemDate, Chr(10), "")
SystemDate = Replace(SystemDate, Chr(13), "")

objErrlog.LogError "GeneralTranQueries", "SystemDate", Err.Number, Err.Description

If recTrandate.State = 1 Then recTrandate.Close
Set recTrandate = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

End Function



'''''' This function is basically developed for creating the list of parameters based
'''''' on the module id. To avoid the programmer to request the database quite often to
'''''' check the parameters during transactions, which might delay the process.
'''''' This function returns a single disconnected recordset with all the parameters for the
'''''' module.

Public Function ModuleParameters(Branchcode As String, ModuleCode As String, _
                                    Optional CurrenyCode As String) As ADODB.Recordset
                                    
Dim strBrcode As String
Dim StrCurCode As String
Dim StrModuleID As String
Dim TabName() As String
Dim TableNames As String
Dim StrFields As String
Dim StrCondition As String
Dim RsCount As Integer
Dim FldCount As Integer
Dim DummyRS As ADODB.Recordset
Dim RsParam() As ADODB.Recordset
Dim RsCol As ADODB.Recordset
Dim NewRows As Integer
Dim arrFlds() As Variant
Dim arrVals() As Variant
Dim BlnUpdate As Boolean
Dim BlnAddNew As Boolean
Dim RowCount As Integer
Dim ColCount As Integer
Dim ColName As String
Dim fldscnt As Integer
On Error GoTo errhand

strBrcode = UCase(Trim(Branchcode))
StrModuleID = UCase(Trim(ModuleCode))
StrCurCode = IIf(IsNull(Trim(CurrenyCode)), "", UCase(Trim(CurrenyCode)))

Call DBConnection

If ConnError <> "Connected" Then Exit Function
Set Rstemp = CreateObject("ADODB.Recordset")
StrQuery = "Select P.PMTTABLE PMTTABLE, T.Tname Tname from (select PMTTABLE from genmodulemst" & DbLink _
        & " where upper(trim(moduleid))='" _
        & StrModuleID & "') P, (select Tname from Tab" & DbLink & " where tname like" _
        & "'%PMT' and tname like 'GEN%') T"
    If Rstemp.State = 1 Then Rstemp.Close
    
     Set Rstemp = AdoConnObj.Execute(StrQuery)
     If Rstemp.EOF And Rstemp.BOF Then
         ConnError = "No Parameters for this module"
         Exit Function
     End If
     Rstemp.MoveFirst
     If IsNull(Trim(Rstemp!pmttable)) Then
            ReDim TabName(Rstemp.RecordCount - 1) As String
            For Icount = 0 To UBound(TabName)
                TabName(Icount) = Trim(Rstemp!Tname) & DbLink
                Rstemp.MoveNext
            Next Icount
     Else
            ReDim TabName(Rstemp.RecordCount) As String
            TabName(0) = Trim(Rstemp!pmttable) & DbLink
            For Icount = 1 To UBound(TabName)
                TabName(Icount) = Trim(Rstemp!Tname) & DbLink
                Rstemp.MoveNext
            Next Icount
     End If
     
     For Icount = 0 To UBound(TabName)
            TableNames = TableNames & TabName(Icount) & DbLink & ","
     Next Icount

     TableNames = Mid(TableNames, 1, Len(TableNames) - 1)
     StrQuery = " select *  from " & TableNames & " where 1=2"
     
     Set DummyRS = CreateObject("ADODB.Recordset")
     DummyRS.CursorLocation = adUseClient
     DummyRS.LockType = adLockOptimistic
     DummyRS.CursorType = adOpenKeyset
     DummyRS.Open StrQuery, AdoConnObj, adOpenKeyset, adLockOptimistic
     'Set DummyRS = AdoConnObj.Execute(StrQuery)
     BlnUpdate = DummyRS.Supports(adAddNew)
     BlnAddNew = DummyRS.Supports(adUpdate)
     Set RsCol = CreateObject("ADODB.Recordset")
     ReDim RsParam(UBound(TabName)) As ADODB.Recordset
     
     For Icount = 0 To (UBound(TabName))
        Set RsParam(Icount) = CreateObject("ADODB.Recordset")
        ColName = ""
        '''For ColCount = 1 To 2
        StrQuery = "Select * from Col where upper(tname)='" & TabName(Icount) _
        & "' and upper(cname)='MODULEID'"
            If RsCol.State = 1 Then RsCol.Close
        Set RsCol = AdoConnObj.Execute(StrQuery)
            If RsCol.RecordCount > 0 Then
                ColName = "MODULEID"
            Else
                ColName = ""
            End If
         StrQuery = "Select * from Col where upper(tname)='" & TabName(Icount) _
        & "' and upper(cname)='BRANCHCODE'"
            If RsCol.State = 1 Then RsCol.Close
            Set RsCol = AdoConnObj.Execute(StrQuery)
        Set RsCol = AdoConnObj.Execute(StrQuery)
        
        If ColName <> "" And RsCol.RecordCount > 0 Then
            StrQuery = " Select * from " & TabName(Icount) & " where upper(trim(moduleid))='" _
                    & StrModuleID & "' and upper(trim(branchcode))='" & strBrcode & "'"
        ElseIf ColName <> "" Then
             StrQuery = " Select * from " & TabName(Icount) & " where upper(trim(moduleid))='" _
                    & StrModuleID & "'"
        ElseIf RsCol.RecordCount > 0 Then
             StrQuery = " Select * from " & TabName(Icount) & " where upper(trim(branchcode))='" _
                    & strBrcode & "'"
        Else
             StrQuery = " Select * from " & TabName(Icount)
        End If
        Set RsParam(Icount) = AdoConnObj.Execute(StrQuery)
        If Not RsParam(Icount).EOF And Not RsParam(Icount).BOF Then RsParam(Icount).MoveFirst
        If RsParam(Icount).RecordCount > RsCount Then
            RsCount = RsParam(Icount).RecordCount
        End If
     Next Icount
    
    Dim dumfldname As String
    fldscnt = 0
    
For RowCount = 0 To RsCount - 1
fldscnt = 0
'''''' first checking the no. of fields for each parameter table o redim the array of fields and values
 For Icount = 0 To UBound(RsParam)
 If Not RsParam(Icount).EOF And Not RsParam(Icount).BOF Then
    If Not RsParam(Icount).EOF Then
      For FldCount = 0 To RsParam(Icount).Fields.Count - 1
    
        If Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPLICATIONDATE" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "MODULEID" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "BRANCHCODE" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "CURRENCYCODE" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "GLCODE" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "USERID" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "MACHINEID" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "VERIFIEDBY" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "VERIFIEDMACHINE" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPROVEDBY" And _
            Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPROVEDMACHINE" Then
            fldscnt = fldscnt + 1
            dumfldname = dumfldname & "," & RsParam(Icount).Fields(FldCount).Name
        End If
      Next FldCount
    End If
 End If
Next Icount

     ReDim arrFlds(fldscnt - 1) As Variant
     ReDim arrVals(fldscnt - 1) As Variant
     Dim fldnam As String
'''''' asigning the values and fields to the array in order to add a new row to the dmmy recordset.
        fldscnt = 0
        For Icount = 0 To UBound(RsParam)
            If Not RsParam(Icount).EOF And Not RsParam(Icount).BOF Then
              If Not RsParam(Icount).EOF Then
                
                For FldCount = 0 To RsParam(Icount).Fields.Count - 1

                    If Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPLICATIONDATE" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "MODULEID" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "BRANCHCODE" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "CURRENCYCODE" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "GLCODE" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "USERID" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "MACHINEID" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "VERIFIEDBY" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "VERIFIEDMACHINE" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPROVEDBY" And _
                        Trim(RsParam(Icount).Fields(FldCount).Name) <> "APPROVEDMACHINE" Then
                        fldnam = fldnam & "," & RsParam(Icount).Fields(FldCount).Name
                        arrFlds(fldscnt) = RsParam(Icount).Fields(FldCount).Name
                        arrVals(fldscnt) = IIf(IsNull(RsParam(Icount).Fields(FldCount).Value), " ", _
                                                RsParam(Icount).Fields(FldCount).Value)
                        fldscnt = fldscnt + 1
                        
                    End If
                Next FldCount
                
                If Not RsParam(Icount).EOF Then RsParam(Icount).MoveNext
            End If
          End If
        Next Icount
            fldnam = ""
    '''''adding a new row to the dummy recordset so that to send the parameters to the client form.
            DummyRS.AddNew arrFlds, arrVals
    Next RowCount

If DummyRS.EOF And DummyRS.BOF Then ConnError = " No Parameters for this module."
 Set ModuleParameters = DummyRS
 
    DummyRS.ActiveConnection = Nothing
    
    For Icount = 0 To (UBound(TabName))
    
        If RsParam(Icount).State = 1 Then RsParam(Icount).Close
        Set RsParam(Icount) = Nothing
    
    Next Icount
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If RsCol.State = 1 Then RsCol.Close
    Set RsCol = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
Exit Function
     
errhand:

ConnError = Err.Number & " : " & Err.Description
                                            
objErrlog.LogError "GeneralTranQueries", "ModuleID", Err.Number, Err.Description

    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If DummyRS.State = 1 Then DummyRS.Close
    Set DummyRS = Nothing
    If RsCol.State = 1 Then RsCol.Close
    Set RsCol = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

End Function


Public Function PrepareFinanceTranArray(ByRef RawArr() As Variant, ByVal UserID As String, _
ByVal Applicationdate As Date, ByVal machineid As String, ByRef Errmsg As String, _
ByRef BatchNo As String, ByRef TranNos As String, Optional ByVal TranStatus_PA As String = "P", _
Optional ByVal TransactionDesc As String = "", Optional ByVal CashPaidYN As String = "N", _
Optional ByVal SystemGeneratedYN As String = "N") As Variant

    Dim sQuery As String, strTranNo As Long
    Dim ArrIdx As Long
    Dim AccBal As Double, AccName As String, ModeofTran As Integer
    Dim objDBConn As ADODB.Connection
    Dim objAccBal As Object
    Dim BRCode As String, CurCode  As String, ModId  As String, TranType As String
    Dim GLcode  As String, Accno  As String, TranAmt As Double
    Dim TableName As String, FldNames As String, FldValues As String, ExceptionYN As String
    Dim objrs As ADODB.Recordset, CustomerId As String
    Dim TranArr(1000, 4) As String
    Dim TranArrIdx As Long, LineNo As Integer, strAccBal As String
        
    On Error GoTo ErrHandler
        
    If UBound(RawArr) <= 0 Then
        Err.Raise 999, , "Given Input Array does not had any details to Prepare Financial Transactions"
    End If

    'Dim TranArr(UBound(RawArr) * 2, 4) As String
    LineNo = 1
    If UCase(Trim(TranStatus_PA)) <> "P" And UCase(Trim(TranStatus_PA)) <> "A" Then
        Err.Raise 999, , "Invalid Transaction Status is given. It should be either P(Pending) or A(Approved)."
    ElseIf UCase(Trim(CashPaidYN)) <> "Y" And UCase(Trim(CashPaidYN)) <> "N" Then
        Err.Raise 999, , "Invalid value given to CashPaidYN Param. It should be either Y(Yes) or N(No)."
    ElseIf UCase(Trim(SystemGeneratedYN)) <> "Y" And UCase(Trim(SystemGeneratedYN)) <> "N" Then
        Err.Raise 999, , "Invalid value given to SystemGeneratedYN Param. It should be either Y(Yes) or N(No)."
    End If
    
    LineNo = 2
    Call DBConnection
    If ConnError <> "Connected" Then
        Err.Raise 999, , ConnError
    End If
    Set objDBConn = AdoConnObj
    LineNo = 3
    BatchNo = GetBatchno(CStr(RawArr(0, 0)))
    If IsNumeric(BatchNo) = False Then
        Err.Raise 999, , BatchNo
    End If
    TranNos = ""
    
    Set objAccBal = CreateObject("AccountDetails.AccDetails")
    If objAccBal Is Nothing Then
        Err.Raise 999, , "Unable to create object of AccountDetails.AccDetails"
    End If
    
    TranArrIdx = 0
    For ArrIdx = 0 To UBound(RawArr)
        
        If RawArr(ArrIdx, 0) <> "" Then
            LineNo = 4
            BRCode = UCase(Trim(RawArr(ArrIdx, 0)))
            CurCode = UCase(Trim(RawArr(ArrIdx, 1)))
            ModId = UCase(Trim(RawArr(ArrIdx, 2)))
            GLcode = UCase(Trim(RawArr(ArrIdx, 3)))
            Accno = Trim(RawArr(ArrIdx, 4))
            If IsNumeric(RawArr(ArrIdx, 5)) = False Then
                Err.Raise 999, , "Invalid Transaction Amount found : " & RawArr(ArrIdx, 5)
            End If
            TranAmt = Abs(CDbl(RawArr(ArrIdx, 5)))
            TranType = UCase(Trim(RawArr(ArrIdx, 6)))
           
            If Trim(TranType) <> "D" And Trim(TranType) <> "C" Then
                Err.Raise 999, , "Invalid Transaction Type : " & Trim(TranType)
            End If
            LineNo = 5
            strTranNo = GetTranNo(CStr(BRCode))
            TranNos = TranNos & strTranNo & ","
        
            If (TranType = "D") Then
                ModeofTran = 3
                TranAmt = -1 * TranAmt
            Else
                ModeofTran = 4
            End If
            LineNo = 6
            'Get Balance and Name of the given Account
            strAccBal = objAccBal.GetBalance(BRCode, CurCode, ModId, GLcode, Accno)
            If IsNumeric(strAccBal) = False Then
                Err.Raise 999, , strAccBal
            End If
            AccBal = CDbl(strAccBal)
            LineNo = 7
            Set objrs = CreateObject("adodb.recordset")
            Set objrs = objDBConn.Execute("select nvl(name,''),CUSTOMERID from " & Trim(ModId) & "MST " & _
            " where branchcode='" & BRCode & "' and currencycode='" & CurCode & "'" & _
            " and glcode='" & GLcode & "' and accno='" & Accno & "'")
            LineNo = 8
            If objrs.EOF = True Or objrs.BOF = True Then
                Err.Raise 999, , "Unable to Get Name of the A/C : " & Accno & _
                ", GL : " & GLcode
            End If
            AccName = IIf(IsNull(objrs(0).Value), "", objrs(0).Value)
            CustomerId = IIf(IsNull(objrs(1).Value), "", objrs(1).Value)
           
            LineNo = 9
            TableName = "GENTRANSLOG"
            FldNames = "BRANCHCODE," & _
                    " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL," & _
                    " EFFECTIVEDATE," & _
                    " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,CUSTOMERID"
                    
            FldValues = "'" & BRCode & "'," & _
                    " '" & CurCode & "','" & ModId & "'," & _
                    " '" & GLcode & "','" & Accno & "'," & _
                    " " & BatchNo & "," & strTranNo & "," & _
                    " " & TranAmt & ",'" & ModeofTran & "'," & AccBal & "," & _
                    " '" & Format(Applicationdate, "dd-mmm-yyyy") & "'," & _
                    " '" & AccName & "','" & CashPaidYN & "','" & SystemGeneratedYN & _
                    "','" & TransactionDesc & "'," & _
                    " '1','N'," & _
                    " '" & Format(Applicationdate, "dd-mmm-yyyy") & "'," & _
                    " '" & UserID & "','" & machineid & "','" & TranStatus_PA & "'," & _
                    " sysdate,'" & CustomerId & "'"
                
            If TranStatus_PA = "A" Then
                FldNames = FldNames & ",VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                    "APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE"
                    
                FldValues = FldValues & "," & AccBal & "," & AccBal & ",'" & UserID & _
                    "','" & machineid & "','" & Format(Applicationdate, "dd-mmm-yyyy") & "'"
            End If
            
            TranArr(TranArrIdx, 0) = "I"
            TranArr(TranArrIdx, 1) = TableName
            TranArr(TranArrIdx, 2) = FldNames
            TranArr(TranArrIdx, 3) = FldValues
            TranArr(TranArrIdx, 4) = ""
            TranArrIdx = TranArrIdx + 1
            LineNo = 10
            'Insert into respective Tran Day Table
            TableName = Trim(ModId) & "TranDay"
            TranArr(TranArrIdx, 0) = "I"
            TranArr(TranArrIdx, 1) = TableName
            TranArr(TranArrIdx, 2) = FldNames
            TranArr(TranArrIdx, 3) = FldValues
            TranArr(TranArrIdx, 4) = ""
            TranArrIdx = TranArrIdx + 1
            
        End If
        
    Next ArrIdx
    LineNo = 11
    PrepareFinanceTranArray = TranArr
    Errmsg = ""
    
    If objrs.State = 1 Then objrs.Close
    Set objrs = Nothing
    If objDBConn.State = 1 Then objDBConn.Close
    Set objDBConn = Nothing
    
    
    Exit Function
    
ErrHandler:
    
    Errmsg = "Error No : " & Err.Number & ", Line No: " & LineNo & _
    ", Err Msg: " & Err.Description
    PrepareFinanceTranArray = TranArr
    
    objErrlog.LogError "GeneralTranQueries", "PrepareFinanceTranArray", Err.Number, Err.Description
    
    If objrs.State = 1 Then objrs.Close
    Set objrs = Nothing
    If objDBConn.State = 1 Then objDBConn.Close
    Set objDBConn = Nothing
    
End Function

Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With
''
''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "GeneralTranQueries", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
