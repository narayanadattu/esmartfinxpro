VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "TransParameters"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim Rstemp As ADODB.Recordset
Dim RSModule As ADODB.Recordset
Dim RsAccParam As ADODB.Recordset
Dim StrQuery As String
Dim DbLink As String
Dim strTabName As String
Dim Icount As Integer
Dim objdblink As Object
Dim ArrLink As Variant
Dim StrModuleCode As String
Dim strBranchCode As String
Dim strGLCode As String
Dim StrCurCode As String
Dim strAccno As String
Dim TrannDate As String
Dim arrModCond As Variant
Dim strBrCatCode As Variant
Dim ChqBkYN As String
Dim TDSYN As String
Dim CatCode As String
Dim strMsg As String
Dim StrCondition As String
Dim strParamFlds As String
Dim strParamVals As String
Dim strParamTabs As String
Dim strDelimiter As String
Dim arrParamFlds As Variant
Dim arrParamVals As Variant
Public AdoConnObj As ADODB.Connection ' Connection Object
Public objError As Object
Public ArrError As Variant
Public ConnError As String 'error object



Public Function GLTransactionParameters(ModuleCode As String, _
                                        GLcode As String, _
                                        TransactionDate As String, _
                                        Optional CurrencyCode As String, _
                                        Optional userBranchcode As String, _
                                        Optional UserID As String, _
                                        Optional machineid As String) As ADODB.Recordset

Dim RsGLParam As ADODB.Recordset

On Error GoTo errhand
Set RsGLParam = CreateObject("adodb.recordset")
strDelimiter = "~"
Call DBConnection
If ConnError <> "Connected" Then GoTo errhand

StrQuery = ""
StrModuleCode = UCase(Trim(ModuleCode))
strGLCode = UCase(Trim(GLcode))
TrannDate = Format(TransactionDate, "dd-Mmm-yyyy")
StrCurCode = UCase(Trim(CurrencyCode))
'TrannDate = Format(TrannDate, "dd-Mmm-yyyy")

StrQuery = ""
Set Rstemp = CreateObject("ADODB.Recordset")

'''''''' Aquiring the parameter table name  for the given module. ''''''''''''''
StrQuery = "select MasterTable,PMTTABLE from genmodulemst" & DbLink _
        & "  where moduleid ='" & StrModuleCode & "'"
        
        StrQuery = UCase(StrQuery)
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        If Rstemp.State = 0 Then
            ConnError = "Parameters Not Specified !"
            GoTo errhand
        End If
        If Rstemp.RecordCount = 0 Or _
            (Rstemp.RecordCount = 1 And IsNull(Rstemp!pmttable)) Then
                ConnError = "Parameters Not Specified for this Module !"
                GoTo errhand
        Else
            strTabName = UCase(Trim(Rstemp!pmttable))
        End If
        Rstemp.Close
'''''''''''''' parameter table name retrieved ''''''''''''''''''''''''''

''''''''''calling private function for Gl Parameters from the Moduleparameter table based
''''''''''on the effective date.
Set RSModule = CreateObject("ADODB.Recordset")
ConnError = ModuleParameterRecord(strTabName)

        For Icount = 0 To RSModule.Fields.Count - 1
            If UCase(RSModule.Fields(Icount).Name) <> "BRANCHCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "CURRENCYCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "MODULEID" _
                And UCase(RSModule.Fields(Icount).Name) <> "GLCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "EFFECTIVEDATE" _
                And UCase(RSModule.Fields(Icount).Name) <> "STATUS" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPLICATIONDATE" _
                And UCase(RSModule.Fields(Icount).Name) <> "USERID" _
                And UCase(RSModule.Fields(Icount).Name) <> "MACHINEID" _
                And UCase(RSModule.Fields(Icount).Name) <> "VERIFIEDBY" _
                And UCase(RSModule.Fields(Icount).Name) <> "VERIFIEDMACHINE" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPROVEDBY" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPROVEDMACHINE" _
                And UCase(RSModule.Fields(Icount).Name) <> "SYSTEMDATE" Then
                strParamFlds = strParamFlds & RSModule.Fields(Icount).Name & ","
            
                If RSModule.RecordCount > 0 Then
                    strParamVals = strParamVals _
                    & IIf(IsNull(RSModule.Fields(Icount).Value), "", _
                    RSModule.Fields(Icount).Value) & strDelimiter
                Else
                    strParamVals = strParamVals & "" & strDelimiter
                End If
            End If
        Next Icount
    
   ' strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
    'strParamVals = Left(strParamVals, Len(strParamVals) - 1)
    strParamTabs = strTabName
    
'''retrieving data from GENTRANTYPEMST parameter table
StrQuery = "CASHDRYN, CASHCRYN, TRANSFERDRYN, TRANSFERCRYN, CLEARINGDRYN, CLEARINGCRYN"
StrCondition = " currencycode='" & StrCurCode & "'"
ConnError = ParameterRecord("GENTRANTYPEMST", StrQuery, "GENTRANTYPEMSTHIST", StrCondition)

If ConnError <> "Connected" Then GoTo errhand
    
    strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
    strParamVals = Left(strParamVals, Len(strParamVals) - 1)
    strParamTabs = strParamTabs & ",GENTRANTYPEMST"

        If ConnError <> "Connected" Then GoTo errhand

StrQuery = " select " & strParamFlds & " from " & strParamTabs & " where 1=2"
     '''''''''''''Dummy recordset
     
RsGLParam.Open StrQuery, AdoConnObj, adOpenDynamic, adLockOptimistic

'''''entering the parameter data into the dummy recordset.
arrParamFlds = Split(strParamFlds, ",")
arrParamVals = Split(strParamVals, strDelimiter)
StrQuery = ""
        
RsGLParam.AddNew
For Icount = 0 To UBound(arrParamFlds)
    
    RsGLParam(Icount) = IIf(Trim(arrParamVals(Icount)) = "", Null, _
                        Trim(arrParamVals(Icount)))
Next Icount


Set GLTransactionParameters = RsGLParam

RsGLParam.ActiveConnection = Nothing

If RSModule.State = 1 Then RSModule.Close
Set RSModule = Nothing
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

Exit Function

''''''''' Error trapping.
errhand:
    If ConnError = "Connected" Then
        ConnError = Err.Number & " :- " & Err.Description
    End If
    
    objErrlog.LogError "GeneralTranQueries", "GLTransactionParameters", Err.Number, Err.Description

    If RsGLParam.State = 1 Then RsGLParam.Close
    Set RsGLParam = Nothing
    If RSModule.State = 1 Then RSModule.Close
    Set RSModule = Nothing
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    



End Function

Public Function AccNoTransactionParameters(Branchcode As String, _
                                        ModuleCode As String, _
                                        GLcode As String, _
                                        TransactionDate As String, _
                                        Optional CurrencyCode As String, _
                                        Optional Accno As String, _
                                        Optional CategoryCode As String, _
                                        Optional ChqBookYN As String, _
                                        Optional ModuleConditions As Variant, _
                                        Optional userBranchcode As String, _
                                        Optional UserID As String, _
                                        Optional machineid As String) As ADODB.Recordset


                                        
Dim arrModuleQuery As Variant

                                    
On Error GoTo errhand
strDelimiter = "~"
StrQuery = ""
StrModuleCode = UCase(Trim(ModuleCode))
strGLCode = UCase(Trim(GLcode))
strBranchCode = UCase(Trim(Branchcode))
StrCurCode = UCase(Trim(CurrencyCode))
strAccno = IIf(IsNull(Trim(Accno)), "", Trim(Accno))
CatCode = IIf(IsNull(Trim(CategoryCode)), "", UCase(Trim(CategoryCode)))
ChqBkYN = IIf(IsNull(Trim(ChqBookYN)), "", UCase(Trim(ChqBookYN)))
'TDSYN = IIf(IsNull(Trim(TDSYesNo)), "", UCase(Trim(TDSYesNo)))
TrannDate = Format(TransactionDate, "dd-Mmm-yyyy")
arrModCond = ModuleConditions

Call DBConnection
     If ConnError <> "Connected" Then
            GoTo errhand
    End If
Set Rstemp = CreateObject("ADODB.Recordset")
Set RSModule = CreateObject("ADODB.Recordset")
Set RsAccParam = CreateObject("ADODB.Recordset")

If strAccno <> "" Then
''''''''''retrieving the account category code based on moduleid
    If StrModuleCode = "SB" Or StrModuleCode = "CA" Or StrModuleCode = "DEP" Then
        StrQuery = "Select CHEQUEBOOK, TDSYN, CATEGORYCODE from " & StrModuleCode & "MST" _
        & DbLink & " where branchcode='" & strBranchCode & "' and accno='" & strAccno _
        & "' and glcode='" & strGLCode & "' and currencycode='" & StrCurCode & "'"
        
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        If Not Rstemp.EOF And Not Rstemp.BOF Then
        TDSYN = IIf(IsNull(Rstemp!TDSYN), "", Format(Rstemp!TDSYN))
        End If
    ElseIf StrModuleCode = "LOAN" Then
        StrQuery = "Select CHEQUEBOOK, CATEGORYCODE from " & StrModuleCode & "MST" _
        & DbLink & " where branchcode='" & strBranchCode & "' and accno='" & strAccno _
        & "' and glcode='" & strGLCode & "'"
        
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        TDSYN = ""
    Else
        ConnError = "Parameters not avilable for this Module : " & StrModuleCode
        GoTo errhand
        
    End If
        If Not Rstemp.EOF And Not Rstemp.BOF Then
        CatCode = IIf(IsNull(Rstemp!CategoryCode), "", Format(Rstemp!CategoryCode))
        ChqBkYN = IIf(IsNull(Rstemp!CHEQUEBOOK), "", Format(Rstemp!CHEQUEBOOK))
        End If
End If
    ''''''''''retrieving the branch category code
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = AdoConnObj.Execute("Select BRANCHCATCODE from GENBANKBRANCHMST " _
& " where branchcode='" & strBranchCode & "'")
If Not Rstemp.EOF And Not Rstemp.BOF Then
strBrCatCode = IIf(IsNull(Rstemp!BRANCHCATCODE), "", Rstemp!BRANCHCATCODE)
End If
Rstemp.Close
''''''''-----------------------------------------------------------------------------------
''''''''-----------------------------------------------------------------------------------
strParamTabs = ""

    
''''''''-----------------------------------------------------------------------------------
''''''''-----------------------------------------------------------------------------------
  If strBrCatCode = "99" Then
    strBrCatCode = ""
    End If
    
    If CatCode = "99" Then
        CatCode = ""
    End If
    
    '''retrieving data from GENMINMAXBALANCEMST parameter table
StrQuery = "MINAMOUNT, MAXAMOUNT, MINPERIODYEARS, MINPERIODMON, MINPERIODDAYS, " _
        & "MAXPERIODYEARS, MAXPERIODMON, MAXPERIODDAYS,TDS,MULTIPLESOF"

''StrCondition = " (CATEGORYCODE='" & CatCode & "' or CATEGORYCODE='99') and (BRANCHCATCODE='" & strBrCatCode _
        & "' or BRANCHCATCODE='99') and CHEQUEBOOK='" & ChqBkYN & "' and currencycode='" & StrCurCode & "'"

StrCondition = " (CATEGORYCODE='" & CatCode & "' or CATEGORYCODE='99') and (BRANCHCATCODE='" & strBrCatCode _
        & "' or BRANCHCATCODE='99')  and currencycode='" & StrCurCode & "'"

ConnError = ParameterRecord("GENMINMAXBALANCEMST", StrQuery, "GENMINMAXBALANCEMSTHIST", StrCondition)
    If ConnError <> "Connected" Then GoTo errhand
    
       strParamTabs = "GENMINMAXBALANCEMST,"
 ''''''''-----------------------------------------------------------------------------------
 ''''''''-----------------------------------------------------------------------------------
  '''retrieving data from GENCHARGESMSTHIST parameter table
StrQuery = "OUTRTNCHARGES, OUTRTNFREQ, OUTRTNCHARGEEXEMPT, OUTRTNGLCODE, INWRTNCHARGES, " _
& "INWRTNFREQ, INWRTNCHARGESEXEMPT, INWRTNGLCODE, STOPPAYCHARGES, STOPPAYFREQ, " _
& "STOPPAYCHARGESEXEMPT, STOPPAYGLCODE, ACCTCLOSCHARGES, ACCOUNTCLOSFREQ, " _
& "ACCTCLOSCHARGESEXEMPT, ACCTCLOSGLCODE, MINTODCHARGES, MINTODFREQ, MINTODGLCODE, " _
& "CHQISSUECHARGES, CHQISSUEFREQ, CHQISSUECHARGESEXEMPT, CHQISSUEGLCODE, STATEMENTCHARGES, " _
& "STATEMENTCHRGFREQ, STATEMENTCHARGESEXEMPT, STATEMENTCHRGGLCODE, DUPSTATEMENTCHARGES," _
& "DUPSTATEMENTCHRGFREQ, DUPSTATEMENTCHARGESEXEMPT, DUPSTATEMENTGLCODE, CHARGESPERFOLIO, " _
& "FOLIOCHARGESFREQ, ENTRIESPERFOLIO, FOLIOCHARGESGLCODE, EXEMPTEDFOLIOS, MINTODCHARGESEXEMPT," _
& "CHQVALIDPERIOD,OUTRTNCHARGEEXEMPTUNIT, INWRTNCHARGESEXEMPTUNIT, STOPPAYCHARGESEXEMPTUNIT," _
& "ACCTCLOSCHARGESEXEMPTUNIT, CHQISSUECHARGESEXEMPTUNIT, STATEMENTCHARGESEXEMPTUNIT, " _
& "DUPSTATEMENTCHARGESEXEMPTUNIT, MINTODCHARGESEXEMPTUNIT, INWRTNFREQUNITS, OUTRTNFREQUNITS," _
& "STOPPAYFREQUNITS, ACCOUNTCLOSFREQUNITS, MINTODFREQUNITS, CHQISSUEFREQUNITS, " _
& "STATEMENTCHRGFREQUNITS, DUPSTATEMENTCHRGFREQUNITS, FOLIOCHARGESFREQUNITS, OUTRTNINITIAL," _
& "OUTRTNINITIALUNITS, INWRTNINITIAL, INWRTNINITIALUNITS, STOPPAYINITIAL, " _
& "STOPPAYINITIALUNITS, ACCOUNTCLOSINITIAL, ACCOUNTCLOSINITIALUNITS, MINTODINITIAL, " _
& "MINTODINITIALUNITS, CHQISSUEINITIAL, CHQISSUEINITIALUNITS, STATEMENTINITIAL, " _
& "STATEMENTINITIALUNITS, DUPSTATEMENTINITIAL, DUPSTATEMENTINITIALUNITS, FOLIOINITIAL," _
& "FOLIOINITIALUNITS, EXEMPTEDFOLIOSUNITS"
       
StrCondition = " (CATEGORYCODE='" & CatCode & "' or CATEGORYCODE='99') and (BRANCHCATCODE='" _
& strBrCatCode & "' or BRANCHCATCODE='99') and currencycode='" & StrCurCode & "'"


ConnError = ParameterRecord("GENCHARGESMST", StrQuery, "GENCHARGESMSTHIST", StrCondition)
    
    If ConnError <> "Connected" Then GoTo errhand
   
    strParamTabs = strParamTabs & "GENCHARGESMST"
    
''''''''------------------------------------------------------------------------------------
''''''''------------------------------------------------------------------------------------    strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
        
''''''if moduleid is deposits than extra parameters from DEPPENALINTDTLS
If StrModuleCode = "DEP" Then
    StrCondition = " (CATEGORYCODE='" & CatCode & "' or CATEGORYCODE='99') and currencycode='" & StrCurCode & "'"
        
        ConnError = ParameterRecord("DEPPENALINTDTLS", "PNLINTPCNT", "DEPPENALINTDTLSHIST", StrCondition)
            If ConnError <> "Connected" Then GoTo errhand
        
        strParamTabs = strParamTabs & ",DEPPENALINTDTLS"
End If

''''''''------------------------------------------------------------------------------------
''''''''------------------------------------------------------------------------------------    strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
   
'''''''''''''fields for Dummy recordset
    strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
    strParamVals = Left(strParamVals, Len(strParamVals) - 1)
    
'''''''''''''query for Dummy recordset of GENMINMAXBALANCEMST and GENCHARGESMST
StrQuery = " select " & strParamFlds & " from " & strParamTabs & " where 1=2"
     
     
RsAccParam.Open StrQuery, AdoConnObj, adOpenDynamic, adLockOptimistic

'''''entering the parameter data into the dummy recordset.
arrParamFlds = Split(strParamFlds, ",")
arrParamVals = Split(strParamVals, strDelimiter)
StrQuery = ""

 ''''''''''''''''adding record to dummy recordset
RsAccParam.AddNew

For Icount = 0 To UBound(arrParamFlds)
    RsAccParam(Icount) = IIf(Trim(arrParamVals(Icount)) = "", Null, _
                        Trim(arrParamVals(Icount)))
Next Icount
'RsAccParam(0) = Null

'RsAccParam.AddNew arrParamFlds, arrParamVals

ConnError = "Connected"
Set AccNoTransactionParameters = RsAccParam

RsAccParam.ActiveConnection = Nothing

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If RSModule.State = 1 Then RSModule.Close
Set RSModule = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

Exit Function

''''''''' Error trapping.
errhand:

If ConnError = "Connected" Then
    ConnError = Err.Number & " :- " & Err.Description
End If

objErrlog.LogError "GeneralTranQueries", "DBConnection", Err.Number, Err.Description

If RsAccParam.State = 1 Then RsAccParam.Close
Set RsAccParam = Nothing
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If RSModule.State = 1 Then RSModule.Close
Set RSModule = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
End Function

Private Function DepositsParameters() As String



Exit Function

''''''''' Error trapping.
errhand:
Set RSModule = Nothing
Set AdoConnObj = Nothing
If ConnError = "Connected" Then
    ConnError = Err.Number & " :- " & Err.Description
    DepositsParameters = ConnError
End If
End Function

Private Function SBorCAParameters() As String
End Function



Private Function ModuleParameterRecord(ModulePMTtable As String, _
                                       Optional ModuleMSTtable As String, _
                                       Optional Condition As String) As String
''''Selecting the Gl Parameters from the Moduleparameter table based on the effective date.

On Error GoTo errhand

Dim strModPmtTab As String
strModPmtTab = ModulePMTtable

StrQuery = ""
StrQuery = " Select * from " & strModPmtTab & DbLink & " where glcode='" & strGLCode _
            & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from " _
            & strModPmtTab & DbLink & " where glcode='" & strGLCode & "' and " _
            & "EFFECTIVEDATE<='" & TrannDate & "' " & Condition & ") " & Condition
Set RSModule = AdoConnObj.Execute(StrQuery)

        If RSModule.RecordCount < 1 Then
            '''''''' selecting parameters from  module typemsthist table.
            RSModule.Close
            
            StrQuery = " Select * from " & strModPmtTab & "HIST" & DbLink & " where glcode='" _
            & strGLCode & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from " _
            & strModPmtTab & "HIST" & DbLink & " where glcode='" & strGLCode & "' and " _
            & "EFFECTIVEDATE<='" & TrannDate & "' " & Condition & ") " & Condition
            
            Set RSModule = AdoConnObj.Execute(StrQuery)
            If RSModule.RecordCount < 1 Then
                ConnError = "Parameters not specified for this Component"
                
            End If
        End If
        
        If Trim(ModuleMSTtable) <> "" And Trim(strAccno) <> "" Then
            If Rstemp.State = 1 Then Rstemp.Close
            StrQuery = "Select CATEGORYCODE from " & Trim(ModuleMSTtable) & DbLink _
            & " where branchcode='" & strBranchCode & "' and glcode='" & strGLCode & "' " _
            & " and Accno='" & strAccno & "'"
            
            Set Rstemp = AdoConnObj.Execute(StrQuery)
            If Rstemp.RecordCount = 1 Then
                CatCode = Rstemp!CategoryCode
            Else
                ConnError = " Account Holder's Category not specified."
            End If
        End If
        
ModuleParameterRecord = ConnError

''If RSModule.State = 1 Then RSModule.Close
''Set RSModule = Nothing

Exit Function

''''''''' Error trapping.
errhand:
    If ConnError = "Connected" Then
        ConnError = Err.Number & " :- " & Err.Description
    End If
    
    objErrlog.LogError "GeneralTranQueries", "ModuleParameterRecord", Err.Number, Err.Description
    
    ''If RSModule.State = 1 Then RSModule.Close
    ''Set RSModule = Nothing


End Function

Private Function ParameterRecord(PmtDtlsTabName As String, ByVal PmtFields As String, _
                                 PmtDtlsHistTabName As String, Condition As String) As String
If Rstemp.State = 1 Then Rstemp.Close
StrQuery = ""

StrQuery = " Select " & PmtFields & " from " & PmtDtlsTabName & DbLink & " where " _
    & " moduleid='" & StrModuleCode & "' and glcode='" & strGLCode _
    & "' and status='R' and EFFECTIVEDATE<=(select max(EFFECTIVEDATE) from " _
    & PmtDtlsTabName & DbLink & " where moduleid='" & StrModuleCode _
    & "' and glcode='" & strGLCode & "' and " & Condition _
    & " and status='R' and currencycode='" & StrCurCode _
    & "' and EFFECTIVEDATE<='" & TrannDate & "') And " & Condition

If PmtDtlsTabName = "DEPPENALINTDTLS" Then
StrQuery = StrQuery & " order by CATEGORYCODE "
End If

Set Rstemp = AdoConnObj.Execute(StrQuery)

        If Rstemp.RecordCount < 1 Then
            '''''''' selecting parameters from  module typemsthist table.
            Rstemp.Close
            
            StrQuery = " Select " & PmtFields & " from " & PmtDtlsHistTabName & DbLink _
            & " where moduleid='" & StrModuleCode & "' and glcode='" _
            & strGLCode & "' and " & Condition & " and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from " _
            & PmtDtlsHistTabName & DbLink & " where moduleid='" & StrModuleCode _
            & "' and glcode='" & strGLCode & "' and " & Condition _
            & " and status='R' and currencycode='" & StrCurCode _
            & "' and EFFECTIVEDATE<='" & TrannDate & "')"
            
            
If PmtDtlsHistTabName = "DEPPENALINTDTLSHIST" Then
StrQuery = StrQuery & " order by CATEGORYCODE "
End If
        
        Set Rstemp = AdoConnObj.Execute(StrQuery)
            
        End If
        
        For Icount = 0 To Rstemp.Fields.Count - 1
            strParamFlds = strParamFlds & Rstemp.Fields(Icount).Name & ","
            If Rstemp.RecordCount > 0 Then
                strParamVals = strParamVals _
                & IIf(IsNull(Rstemp.Fields(Icount).Value), "", Rstemp.Fields(Icount).Value) _
                & strDelimiter
            Else
                strParamVals = strParamVals & "" & strDelimiter
            End If
        Next Icount
          
        ParameterRecord = ConnError
       
If Rstemp.State = 1 Then Rstemp.Close
''Set Rstemp = Nothing

Exit Function

''''''''' Error trapping.
errhand:

    If ConnError = "Connected" Then
        ConnError = Err.Number & " :- " & Err.Description
    End If
    ParameterRecord = ConnError
    
    objErrlog.LogError "GeneralTranQueries", "ParameterRecord", Err.Number, Err.Description
    
    If Rstemp.State = 1 Then Rstemp.Close
    ''Set Rstemp = Nothing
End Function


Public Function FXTransactionParameters(Branchcode As String, _
                                        ModuleCode As String, _
                                        GLcode As String, _
                                        TransactionDate As String, _
                                        Optional FCurrencyCode As String, _
                                        Optional Accno As String, _
                                        Optional CategoryCode As String, _
                                        Optional userBranchcode As String, _
                                        Optional UserID As String, _
                                        Optional machineid As String) As ADODB.Recordset

Dim RsGLParam As ADODB.Recordset
Dim StrFxMinMAxTab As String
Dim strFxMinMaxFlds As String
Dim strFxNotinalCat As String
On Error GoTo errhand
Set RsGLParam = CreateObject("adodb.recordset")
strDelimiter = "~"
Call DBConnection
If ConnError <> "Connected" Then GoTo errhand

StrQuery = ""
StrModuleCode = UCase(Trim(ModuleCode))
strGLCode = UCase(Trim(GLcode))
TrannDate = Format(TransactionDate, "dd-Mmm-yyyy")
StrCurCode = UCase(Trim(FCurrencyCode))
strBranchCode = UCase(Trim(Branchcode))
strAccno = IIf(IsNull(Trim(Accno)), "", Trim(Accno))
CatCode = IIf(IsNull(Trim(CategoryCode)), "", UCase(Trim(CategoryCode)))
'TrannDate = Format(TrannDate, "dd-Mmm-yyyy")

StrQuery = ""
Set Rstemp = CreateObject("ADODB.Recordset")

If strAccno <> "" Then
''''''''''retrieving the account category code based on moduleid
    
        StrQuery = "Select CATEGORYCODE from " & StrModuleCode & "MST" _
        & DbLink & " where branchcode='" & strBranchCode & "' and accno='" & strAccno _
        & "' and glcode='" & strGLCode & "'"
        
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        
   If Rstemp.RecordCount < 1 Then
        ConnError = "Parameters not avilable for this Module : " & StrModuleCode
        GoTo errhand
        
    End If
        CatCode = Format(Rstemp!CategoryCode)
        
            
End If



'''''''' Aquiring the parameter table name  for the given module. ''''''''''''''
StrQuery = "select MasterTable,PMTTABLE from genmodulemst" & DbLink _
        & "  where moduleid ='" & StrModuleCode & "'"
        
        StrQuery = UCase(StrQuery)
        Set Rstemp = AdoConnObj.Execute(StrQuery)
        If Rstemp.State = 0 Then
            ConnError = "Parameters Not Specified !"
            GoTo errhand
        End If
        If Rstemp.RecordCount = 0 Or _
            (Rstemp.RecordCount = 1 And IsNull(Rstemp!pmttable)) Then
                ConnError = "Parameters Not Specified for this Module !"
                GoTo errhand
        Else
            strTabName = UCase(Trim(Rstemp!pmttable))
        End If
   Rstemp.Close
        
        
        
'''''''''''''' parameter table name retrieved ''''''''''''''''''''''''''

''''''''''calling private function for Gl Parameters from the Moduleparameter table based
''''''''''on the effective date.
Set RSModule = CreateObject("ADODB.Recordset")
ConnError = ModuleParameterRecord(strTabName)

        For Icount = 0 To RSModule.Fields.Count - 1
            If UCase(RSModule.Fields(Icount).Name) <> "BRANCHCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "CURRENCYCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "MODULEID" _
                And UCase(RSModule.Fields(Icount).Name) <> "GLCODE" _
                And UCase(RSModule.Fields(Icount).Name) <> "EFFECTIVEDATE" _
                And UCase(RSModule.Fields(Icount).Name) <> "STATUS" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPLICATIONDATE" _
                And UCase(RSModule.Fields(Icount).Name) <> "USERID" _
                And UCase(RSModule.Fields(Icount).Name) <> "MACHINEID" _
                And UCase(RSModule.Fields(Icount).Name) <> "VERIFIEDBY" _
                And UCase(RSModule.Fields(Icount).Name) <> "VERIFIEDMACHINE" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPROVEDBY" _
                And UCase(RSModule.Fields(Icount).Name) <> "APPROVEDMACHINE" _
                 And UCase(RSModule.Fields(Icount).Name) <> "TRANSTATUS" _
                And UCase(RSModule.Fields(Icount).Name) <> "SYSTEMDATE" _
                And UCase(RSModule.Fields(Icount).Name) <> "FCURRENCYCODE" Then
                strParamFlds = strParamFlds & RSModule.Fields(Icount).Name & ","
            
                If RSModule.RecordCount > 0 Then
                    strParamVals = strParamVals _
                    & IIf(IsNull(RSModule.Fields(Icount).Value), "", _
                    RSModule.Fields(Icount).Value) & strDelimiter
                Else
                    strParamVals = strParamVals & "" & strDelimiter
                End If
            End If
        Next Icount
    
    strParamTabs = strTabName
    
'''retrieving data from GENTRANTYPEMST parameter table
StrQuery = "CASHDRYN, CASHCRYN, TRANSFERDRYN, TRANSFERCRYN, CLEARINGDRYN, CLEARINGCRYN"
StrCondition = " currencycode='" & StrCurCode & "'"
ConnError = ParameterRecord("GENTRANTYPEMST", StrQuery, "GENTRANTYPEMSTHIST", StrCondition)

If ConnError <> "Connected" Then GoTo errhand
    
    
    strParamTabs = strParamTabs & ",GENTRANTYPEMST"

        If ConnError <> "Connected" Then GoTo errhand

''''''''''' parameters for minmaxbalance based on forex moduleid

If StrModuleCode = "FXDEP" Then
   StrFxMinMAxTab = "FXDEPMINMAXDTLS"
ElseIf StrModuleCode = "FXLOAN" Then
    StrFxMinMAxTab = "FXLOANMINMAXDTLS"
End If
    StrQuery = "Select MINTERM, MINPERIOD, MAXTERM, MAXPERIOD, MINAMOUNT, MAXAMOUNT, TDSYN from " _
    & StrFxMinMAxTab & " where glcode='" & strGLCode _
    & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from " & StrFxMinMAxTab _
    & " where glcode='" & strGLCode & "' and " _
    & "EFFECTIVEDATE<='" & TrannDate & "' and FCurrencycode='" _
    & StrCurCode & "' and (categorycode='" & CatCode & "' or categorycode='99') ) " _
    & " and (categorycode='" & CatCode & "'  or categorycode='99') and FCurrencycode='" _
    & StrCurCode & "'"
     
If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = AdoConnObj.Execute(StrQuery)
    
If Rstemp.RecordCount < 1 Then
'''''if no records at master table for that effective date then query history table
     StrQuery = "Select MINTERM, MINPERIOD, MAXTERM, MAXPERIOD, MINAMOUNT, MAXAMOUNT ,TDSYN from " _
    & StrFxMinMAxTab & "HIST where glcode='" & strGLCode _
    & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from " & StrFxMinMAxTab _
    & " where glcode='" & strGLCode & "' and " _
    & "EFFECTIVEDATE<='" & TrannDate & "' and FCurrencycode='" _
    & StrCurCode & "' and (categorycode='" & CatCode & "' or categorycode='99') ) " _
    & "and FCurrencycode='" & StrCurCode & "' and (categorycode='" _
    & CatCode & "'  or categorycode='99')"
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = AdoConnObj.Execute(StrQuery)
End If
    strParamTabs = strParamTabs & "," & StrFxMinMAxTab
    For Icount = 0 To Rstemp.Fields.Count - 1
            strParamFlds = strParamFlds & Rstemp.Fields(Icount).Name & ","
            If Rstemp.RecordCount > 0 Then
                strParamVals = strParamVals _
                & IIf(IsNull(Rstemp.Fields(Icount).Value), "", Rstemp.Fields(Icount).Value) _
                & strDelimiter
            Else
                strParamVals = strParamVals & "" & strDelimiter
            End If
    Next Icount
    
If StrModuleCode = "FXDEP" Then
    StrQuery = "Select PERCENTAGE from FXDEPPENALINTDTLS where glcode='" & strGLCode _
    & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from FXDEPPENALINTDTLS " _
    & " where glcode='" & strGLCode & "' and " _
    & "EFFECTIVEDATE<='" & TrannDate & "' and FCurrencycode='" _
    & StrCurCode & "' and (categorycode='" & CatCode & "' or categorycode='99') ) " _
    & " and (categorycode='" & CatCode & "'  or categorycode='99') and FCurrencycode='" _
    & StrCurCode & "'"
     
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = AdoConnObj.Execute(StrQuery)
    
    If Rstemp.RecordCount < 1 Then
    '''''if no records at master table for that effective date then query history table
         StrQuery = "Select PERCENTAGE from FXDEPPENALINTDTLSHIST where glcode='" & strGLCode _
        & "' and EFFECTIVEDATE= (select max(EFFECTIVEDATE) from FXDEPPENALINTDTLSHIST " _
        & " where glcode='" & strGLCode & "' and " _
        & "EFFECTIVEDATE<='" & TrannDate & "' and FCurrencycode='" _
        & StrCurCode & "' and (categorycode='" & CatCode & "' or categorycode='99') ) " _
        & "and FCurrencycode='" & StrCurCode & "' and (categorycode='" _
        & CatCode & "'  or categorycode='99')"
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = AdoConnObj.Execute(StrQuery)
    End If
    strParamTabs = strParamTabs & ",FXDEPPENALINTDTLS"
    For Icount = 0 To Rstemp.Fields.Count - 1
            strParamFlds = strParamFlds & Rstemp.Fields(Icount).Name & ","
            If Rstemp.RecordCount > 0 Then
                strParamVals = strParamVals _
                & IIf(IsNull(Rstemp.Fields(Icount).Value), "", Rstemp.Fields(Icount).Value) _
                & strDelimiter
            Else
                strParamVals = strParamVals & "" & strDelimiter
            End If
    Next Icount

End If
    
    strParamFlds = Left(strParamFlds, Len(strParamFlds) - 1)
    strParamVals = Left(strParamVals, Len(strParamVals) - 1)
    

StrQuery = " select " & strParamFlds & " from " & strParamTabs & " where 1=2"
     '''''''''''''Dummy recordset
     
RsGLParam.Open StrQuery, AdoConnObj, adOpenDynamic, adLockOptimistic

'''''entering the parameter data into the dummy recordset.
arrParamFlds = Split(strParamFlds, ",")
arrParamVals = Split(strParamVals, strDelimiter)
StrQuery = ""
        
RsGLParam.AddNew
For Icount = 0 To UBound(arrParamFlds)
    
    RsGLParam(Icount) = IIf(Trim(arrParamVals(Icount)) = "", Null, _
                        Trim(arrParamVals(Icount)))
Next Icount


Set FXTransactionParameters = RsGLParam

RsGLParam.ActiveConnection = Nothing

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If RSModule.State = 1 Then RSModule.Close
Set RSModule = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    
Exit Function

''''''''' Error trapping.
errhand:

    If ConnError = "Connected" Then
        ConnError = Err.Number & " :- " & Err.Description
    End If
    
    objErrlog.LogError "GeneralTranQueries", "FXTransactionParameters", Err.Number, Err.Description
    
    
    If RsGLParam.State = 1 Then RsGLParam.Close
    Set RsGLParam = Nothing
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If RSModule.State = 1 Then RSModule.Close
    Set RSModule = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

End Function

Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With
''
''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "GeneralTranQueries", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
