Attribute VB_Name = "ModGen"
Public Const blnDebug As Boolean = True
Public objErrlog As Object



