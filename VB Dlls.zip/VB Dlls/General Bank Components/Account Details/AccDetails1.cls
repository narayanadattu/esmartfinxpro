VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "AccDetails"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim objFetch As Object

Public Function AccountDetail(BranchCode As String, CurrencyCode As String, _
                ModuleType As String, AccountType As String, AccNo As String) As String
       
       Dim strBalTable As String
       Dim strTranTable As String
       Dim strFlds As String
       Dim strWhereCond As String
       Dim recTabName As Object
       Dim recCurBal As Object
       Dim recTranBal As Object
       Dim recTempTran As Object
       Dim recMst As Object
       Dim dblClearBal As Double
       Dim dblUnclrBal As Double
       Dim dblNetBal As Double
       Dim strCustId As String
       Dim strOprBy As String
       Dim strOprInstr As String
       Dim strChqBookYN As String
       Dim dblClBal As Double
       Dim dblTranBal As Double
       Dim dblTmpTrnBal As Double
       
       On Error GoTo errhand
            
            
            Set recTabName = CreateObject("adodb.recordset")
            Set recCurBal = CreateObject("adodb.recordset")
            Set recTranBal = CreateObject("adodb.recordset")
            Set recTempTran = CreateObject("adodb.recordset")
            Set recMst = CreateObject("adodb.recordset")
    
           '----------To find master,tranday,backup,balance tables for the module id
           strFlds = "MASTERTABLE,TRANDAYTABLE,BACKUPTABLE,BALANCETABLE"
           strWhereCond = "upper(moduletype)='" & UCase(Trim(ModuleType)) & "'"
           Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
           Set recTabName = objFetch.SingleRecordSet("GENMODULEMST", strFlds, strWhereCond, _
                            "mastertable")
            If objFetch.connerror <> "Connected" Then
                AccountDetail = objFetch.connerror
                Set objFetch = Nothing
                Exit Function
            End If
          '----------To get Current Balance from respective balance tables
       
           strWhereCond = "branchcode='" & Trim(BranchCode) & "' and upper(Currencycode)='" & _
                           UCase(Trim(CurrencyCode)) & "' and upper(glcode)='" & UCase(Trim(AccountType)) & _
                           "'  and accno='" & Trim(AccNo) & "'"
                          
           strBalTable = recTabName!BALANCETABLE
           
           Set recCurBal = objFetch.SingleRecordSet(strBalTable, "nvl(curbal,0) Curbal", strWhereCond)
            
            If objFetch.connerror <> "Connected" Then
                AccountDetail = objFetch.connerror
                Set objFetch = Nothing
                Exit Function
            End If
            
            If recCurBal.RecordCount > 0 Then
               dblClBal = recCurBal!Curbal
            Else
               dblClBal = 0
            End If
            
          '----------To find sum(debits) or sum(credits) from respective trandaytables, if any
           
           strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
           strTranTable = recTabName!trandaytable
           strWhereCond = "upper(branchcode)='" & UCase(Trim(BranchCode)) & "' and upper(Currencycode)='" & _
                          UCase(Trim(CurrencyCode)) & "' and upper(glcode)='" & UCase(Trim(AccountType)) & _
                          "'  and accno='" & Trim(AccNo) & "'"
                                                  
           Set recTranBal = objFetch.SingleRecordSet(strTranTable, strFlds, strWhereCond)
           
           If objFetch.connerror <> "Connected" Then
                AccountDetail = objFetch.connerror
                Set objFetch = Nothing
                Exit Function
           End If
           
           If recTranBal.RecordCount > 0 Then
               dblTranBal = recTranBal!Amt
           Else
               dblTranBal = 0
           End If
           
          '----------To get sum(debits) or sum(credits) from gentranslog, if any
       
           strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
           strTranTable = "gentemptranslog"
           strWhereCond = "branchcode='" & BranchCode & "' and upper(Currencycode)='" & _
                           UCase(CurrencyCode) & "' and upper(glcode)='" & UCase(Trim(AccountType)) & _
                           "' and accno='" & Trim(AccNo) & "'"
                           
           Set recTempTran = objFetch.SingleRecordSet(strTranTable, strFlds, strWhereCond)
        
            If objFetch.connerror <> "Connected" Then
                AccountDetail = objFetch.connerror
                Set objFetch = Nothing
                Exit Function
            End If
            
            If recTempTran.RecordCount > 0 Then
               dblTmpTrnBal = recTempTran!Amt
            Else
               dblTmpTrnBal = 0
            End If
            
          '----------Calculating Clear Balance, Unclear Balance, Net Balance
       
           dblClearBal = dblClBal + dblTranBal + dblTmpTrnBal
           dblUnclrBal = "0"
           dblNetBal = dblClearBal + dblUnclrBal
           
          '----------To know Custmer Id, Cheque Book fecility
       
           strFlds = "customerid,chequebook"
           strTranTable = recTabName!mastertable
           strWhereCond = "branchcode='" & Trim(BranchCode) & "' and upper(Currencycode)='" & _
                          UCase(Trim(CurrencyCode)) & "' and upper(glcode)='" & UCase(Trim(AccountType)) & _
                          "'  and accno='" & Trim(AccNo) & "'"
        
           Set recMst = objFetch.SingleRecordSet(strTranTable, strFlds, strWhereCond)
           
           If objFetch.connerror <> "Connected" Then
                AccountDetail = objFetch.connerror
                Set objFetch = Nothing
                Exit Function
            End If
            
               strCustId = recMst!customerid
            
                    If Not IsNull(recMst!chequebook) Then
                       strChqBookYN = "Y"
                       Else
                       strChqBookYN = "N"
                    End If
            
       '-------------------Concatenating all these values with "|" to return function
                     
           AccountDetail = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
                      strCustId & "|" & strOprInstr & "|" & strOprBy & "|" & strChqBookYN
          
            Set objFetch = Nothing
            Exit Function
            
errhand:

AccountDetail = Err.Number & " : " & Err.Description
Set objFetch = Nothing
End Function



