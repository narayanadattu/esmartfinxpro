VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "AccDetails"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim objFetch As Object
Dim strBalTable As String
Dim strMstTable As String
Dim strTranTable As String
Dim strFlds As String
Dim strWhereCond As String
Dim strWhereCondp As String
Dim strWhereConda As String
Dim recTabName, recCurBal, recTranBal, recTempTran, recMst, recUnclrBal, recLoanBal, recLoanRecovery, recOprInstr, recCtsClg As Object
Dim recTranBala, recTranBalp As Object
Dim recLoanRecoveryDtls, recCClimitamt As Object
Dim recIntPaidUpto, recIntAccured, recdepdet As Object
Dim strLoanrectab As String
Dim dblClearBal As String
Dim dblpendamt As String
Dim dblFxClearBal As String
Dim dblUnclrBal As String
Dim dblNetBal As String
Dim strCustId As String
Dim strOprBy As String
Dim strOprInstr As String
Dim strChqBookYN, strTotValues As String
Dim strDepMstTab As String
Dim strDepIntAccTab As String
Dim strDepIntPaidTab As String
Dim strFldsIntAccured As String
Dim strFldsPaidupto As String
Dim strIntAccuredWhereCond As String
Dim strFldsMst As String
Dim dblClBal, dblTranBal, dblTmpTrnBal, dblLoanPrnc As Double
Dim dblpendbalp, dblTranBalp, dblTranBala As Double
Dim dblFxClBal, dblFxTranBal, dblFxTmpTrnBal As Double
Dim strGetBal As String
Dim objErrlog As Object

''commented by kishore

Public Function AccountDetail(BranchCode As String, CurrencyCode As String, _
                ModuleId As String, GlCode As String, AccNo As String) As String
                
Dim dblLimitAmt As Double, sBrApplDate As String, dblLoanSchAmt As Double
Dim dblDPAmt As Double, dblIntAccr As Double, dblOverDueBal As Double
                
Set recCurBal = CreateObject("adodb.recordset")
Set recTranBal = CreateObject("adodb.recordset")
Set recTempTran = CreateObject("adodb.recordset")
Set recTranBalp = CreateObject("adodb.recordset")
Set recTranBala = CreateObject("adodb.recordset")
Set recIntPaidUpto = CreateObject("adodb.recordset")
Set recIntAccured = CreateObject("adodb.recordset")
Set recMst = CreateObject("adodb.recordset")
Set recUnclrBal = CreateObject("adodb.recordset")
Set recLoanBal = CreateObject("adodb.recordset")
Set recdepdet = CreateObject("adodb.recordset")
Set recLoanRecovery = CreateObject("adodb.recordset")
Set recLoanRecoveryDtls = CreateObject("adodb.recordset")
Set recOprInstr = CreateObject("adodb.recordset")

If UCase(ModuleId) = "ATM" Then

strGetBal = GetBalance(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo, "Y")

    If Left(strGetBal, 5) = "ERROR" Then
         GoTo ErrHand
    End If
    
strTotValues = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
               strCustId & "|" & strOprBy & "|" & strOprInstr & "|" & strChqBookYN & "|" & dblpendamt

End If

If UCase(ModuleId) = "SB" Or UCase(ModuleId) = "CA" Or UCase(ModuleId) = "LOAN" Or _
   UCase(ModuleId) = "CC" Or UCase(ModuleId) = "PIGMY" Or UCase(ModuleId) = "INV" Or _
   UCase(ModuleId) = "SHARES" Or UCase(ModuleId) = "SCHOOL" Then
          '----------To know Custmer Id, Cheque Book fecility
   
  
    strGetBal = GetBalance(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo, "Y")
  
    If Left(strGetBal, 5) = "ERROR" Then
         GoTo ErrHand
    End If


    strFlds = "customerid,chequebook,operatinginstr,operatedby"
    strMstTable = recTabName!mastertable
    strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & Trim(GlCode) & _
                   "' and branchcode='" & Trim(BranchCode) & "' and Currencycode='" & _
                   UCase(Trim(CurrencyCode)) & "'"
                          
    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recMst = objFetch.singlerecordset(strMstTable, strFlds, strWhereCond)
           
    If objFetch.connerror <> "Connected" Then
         AccountDetail = objFetch.connerror
         AccountDetail = Replace(AccountDetail, Chr(10), "")
         AccountDetail = Replace(AccountDetail, Chr(13), "")
         Set objFetch = Nothing
         recMst.Close
         Set recMst = Nothing
         Exit Function
    End If
        
    If recMst.RecordCount > 0 Then
        strCustId = recMst!customerid
        strOprInstr = Format(recMst!operatinginstr)
        If strOprInstr <> "" Then
        Dim whCond As String
        whCond = "opercode='" & UCase(Trim(strOprInstr)) & "'"
        Set recOprInstr = objFetch.singlerecordset("GENOPERINSTMST", "narration", whCond)
            If recOprInstr.RecordCount > 0 Then
               strOprInstr = recOprInstr!narration
            End If
        End If
               
        strOprBy = Format(recMst!operatedby)
        If Not IsNull(recMst!chequebook) Then
            strChqBookYN = "Y"
        Else
            strChqBookYN = "N"
        End If
    End If
    '-------------------Concatenating all these values with "|" to return function
                     
    If UCase(ModuleId) = "SB" Or UCase(ModuleId) = "CA" Or UCase(ModuleId) = "SCHOOL" Then
    strTotValues = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
               strCustId & "|" & strOprBy & "|" & strOprInstr & "|" & strChqBookYN & "|" & dblpendamt
    Else
    strTotValues = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
               strCustId & "|" & strOprBy & "|" & strOprInstr & "|" & strChqBookYN
    End If
ElseIf UCase(ModuleId) = "FXLOANS" Or UCase(ModuleId) = "FXDEP" Or UCase(ModuleId) = "FXBILLS" Or _
   UCase(ModuleId) = "PL" Or UCase(ModuleId) = "MISC" Or UCase(ModuleId) = "BILLS" _
   Or UCase(ModuleId) = "LC" Or UCase(ModuleId) = "LG" Then


    strGetBal = GetBalance(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo, "N")
  
    If Left(strGetBal, 5) = "ERROR" Then
         GoTo ErrHand
    End If

If UCase(ModuleId) = "FXLOANS" Or UCase(ModuleId) = "FXDEP" Or UCase(ModuleId) = "FXBILLS" Or _
   UCase(ModuleId) = "LC" Or UCase(ModuleId) = "LG" Then
   
    strTotValues = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
               strCustId & "|" & strOprBy & "|" & strOprInstr & "|"
               
ElseIf UCase(ModuleId) = "PL" Or UCase(ModuleId) = "MISC" Or UCase(ModuleId) = "BILLS" Then
 
 strTotValues = dblClearBal & "|" & dblUnclrBal & "|" & dblNetBal & "|" & _
               strCustId & "|" & strOprBy & "|" & strOprInstr & "|" & dblpendamt
               
End If

End If
    
        '---------------------------------------If LOANS
     
If UCase(ModuleId) = "LOAN" Then
     
        strFlds = "nvl(SANCTIONEDAMT,0) SANCTIONAMOUNT"
        Set recLoanBal = objFetch.singlerecordset(strMstTable, strFlds, strWhereCond)
        
        If recLoanBal.RecordCount > 0 Then
        strTotValues = strTotValues & "|" & recLoanBal!SANCTIONAMOUNT
        Else
        strTotValues = strTotValues & "|" & "0"
        End If
        
        
        strLoanrectab = "loanrecoverydaydtls"
        strFlds = "nvl(sum(PRINCIPLEDB),0) principalamt"
        Set recLoanRecovery = objFetch.singlerecordset("loanrecoverydaydtls", strFlds, strWhereCond)
                            
        
        If recLoanRecovery.RecordCount > 0 Then
        dblLoanPrnc = recLoanRecovery!principalamt
        Else
        dblLoanPrnc = 0
        End If
        
        strLoanrectab = "loanrecoverydtls"
        strFlds = "nvl(sum(PRINCIPLEDB),0) principalamt"
        Set recLoanRecoveryDtls = objFetch.singlerecordset("loanrecoverydtls", strFlds, strWhereCond)
        
        If recLoanRecoveryDtls.RecordCount > 0 Then
            dblLoanPrnc = dblLoanPrnc + recLoanRecoveryDtls!principalamt
        Else
            dblLoanPrnc = dblLoanPrnc + 0
        End If
        strTotValues = strTotValues & "|" & dblLoanPrnc
        
        'Get Interest Accrued
        dblIntAccr = GetIntAccrued(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo)
        strTotValues = strTotValues & "|" & dblIntAccr
        
        'Get application date of given branch
        sBrApplDate = GetBranchApplDate(BranchCode)
        
        'Get Loan Schedule Amt as on application date
        dblLoanSchAmt = GetLoanScheduleAmt(BranchCode, CurrencyCode, GlCode, AccNo, sBrApplDate)
        
        'Calculate Overdue Balance
        dblOverDueBal = 0
        If Abs(dblClearBal) > dblLoanSchAmt Then
            dblOverDueBal = Abs(dblClearBal) - dblLoanSchAmt
        End If
        
        strTotValues = strTotValues & "|" & dblOverDueBal
        
        strTotValues = strTotValues & "|" & dblpendamt
End If
        
        '------------------Loan ends
        '-----------------------------------If Cash Credit
If UCase(ModuleId) = "CC" Then
        
        sBrApplDate = GetBranchApplDate(BranchCode)
        
        dblLimitAmt = GetLimitAmt(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo, sBrApplDate)
                
        
        dblDPAmt = GetDrawingPowerAmt(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo)
          
        If Abs(dblDPAmt) > 0 Then
            If Abs(dblDPAmt) < Abs(dblLimitAmt) Then
                dblLimitAmt = dblDPAmt
            End If
        End If
        strTotValues = strTotValues & "|" & dblLimitAmt
        
        'Calculate Overdue Balance
        dblOverDueBal = 0
        If Abs(dblClearBal) > Abs(dblLimitAmt) Then
            dblOverDueBal = Abs(dblClearBal) - Abs(dblLimitAmt)
        End If
        
        strTotValues = strTotValues & "|" & dblOverDueBal & "|" & dblpendamt
        
End If
        '-----------------------------------Cash Credit ends
'''End If
 '-------------------Fetching Deposit details , If deposits
  
If UCase(ModuleId) = "DEP" Then

        strGetBal = GetBalance(BranchCode, CurrencyCode, ModuleId, GlCode, AccNo)
        If Left(strGetBal, 5) = "ERROR" Then
           GoTo ErrHand
        End If
                
        strTotValues = ""
        Dim i As Integer
        strDepMstTab = "DEPMST"
        strDepIntAccTab = "DEPINTACCRUEDDTLS"
       strDepIntPaidTab = "DEPINTPAIDTOCUSTOMERDTLS"
        
        strFldsMst = "nvl(OPBAL,0) OPENINGAMOUNT,nvl(MATURITYVALUE,0),CUSTOMERID," & _
        "to_char(OPDATE,'dd-Mon-yyyy') OPDATE,to_char(EFFDATE,'dd-Mon-yyyy') EFFDATE," & _
        "to_char(MATURITYDATE,'dd-Mon-yyyy') MATDATE,OPERATEDBY,ROI,OPERATINGINSTR"
        
        
        strFldsIntAccured = "nvl(sum(INTAMOUNT),0) INTACCURED"
        
        'strFldsPaidupto = "max(to_char(TRANSFERTODEP,'dd-Mon-yyyy'))"
        
        strFldsPaidupto = "TO_CHAR(MAX(TO_DATE(TO_CHAR(intpaidupto,'dd-Mon-yyyy'),'dd-Mon-yyyy')),'dd-Mon-yyyy')"
        
        strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & _
                          "' and branchcode='" & Trim(BranchCode) & "' and Currencycode='" & _
                          UCase(Trim(CurrencyCode)) & "'  "
        
        'code altered by radhika on 15 apr 2008
        'strIntAccuredWhereCond = strWhereCond & "  and   " & "transfertodep is null"
        strIntAccuredWhereCond = strWhereCond
       
        Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recdepdet = objFetch.singlerecordset(strDepMstTab, strFldsMst, strWhereCond)
        
        If objFetch.connerror <> "Connected" Then
            Err.Description = objFetch.connerror
            GoTo ErrHand
        End If
        
        If recdepdet.RecordCount > 0 Then
            For i = 0 To recdepdet.Fields.Count - 1
                strTotValues = strTotValues & recdepdet.Fields(i) & "|"
            Next
            strTotValues = strGetBal & "|" & Mid(strTotValues, 1, Len(strTotValues) - 1)
       
            Set recIntAccured = objFetch.singlerecordset(strDepIntAccTab, strFldsIntAccured, strIntAccuredWhereCond)
            
            'Set recIntPaidUpto = objFetch.singlerecordset(strDepIntAccTab, strFldsPaidupto, strWhereCond)
            
            Set recIntPaidUpto = objFetch.singlerecordset(strDepIntPaidTab, strFldsPaidupto, strWhereCond)
            
            If recIntAccured.RecordCount > 0 Then
            strTotValues = strTotValues & "|" & recIntAccured(0) & "|" & recIntPaidUpto(0)
            Else
            strTotValues = strTotValues & "|" & "|"
            End If
        
        Else
            strTotValues = strTotValues & "|NO"
        End If
        
        strTotValues = strTotValues & "|" & dblpendamt
End If
        '------------------Deposit Ends
        
            AccountDetail = strTotValues   'Final total values
            
            On Error Resume Next
            Set objFetch = Nothing
            recIntPaidUpto.Close
            Set recIntPaidUpto = Nothing
            recIntAccured.Close
            Set recIntAccured = Nothing
            recMst.Close
            Set recMst = Nothing
            recLoanBal.Close
            Set recLoanBal = Nothing
            recdepdet.Close
            Set recdepdet = Nothing
            recLoanRecovery.Close
            Set recLoanRecovery = Nothing
            recLoanRecoveryDtls.Close
            Set recLoanRecoveryDtls = Nothing
            recOprInstr.Close
            Set recOprInstr = Nothing
            recUnclrBal.Close
            Set recUnclrBal = Nothing
            recTranBalp.Close
            Set recTranBalp = Nothing
            recTempTran.Close
            Set recTempTran = Nothing
            recTranBal.Close
            Set recTranBal = Nothing
            recCurBal.Close
            Set recCurBal = Nothing
            recTabName.Close
            Set recTabName = Nothing
            Exit Function
            
ErrHand:
AccountDetail = Err.Number & " : " & Err.Description
AccountDetail = Replace(AccountDetail, Chr(10), "")
AccountDetail = Replace(AccountDetail, Chr(13), "")

objErrlog.LogError "AccountDetails", "AccountDetail", Err.Number, Err.Description

On Error Resume Next
Set objFetch = Nothing
recIntPaidUpto.Close
Set recIntPaidUpto = Nothing
recIntAccured.Close
Set recIntAccured = Nothing
recMst.Close
Set recMst = Nothing
recLoanBal.Close
Set recLoanBal = Nothing
recdepdet.Close
Set recdepdet = Nothing
recLoanRecovery.Close
Set recLoanRecovery = Nothing
recLoanRecoveryDtls.Close
Set recLoanRecoveryDtls = Nothing
recOprInstr.Close
Set recOprInstr = Nothing
recUnclrBal.Close
Set recUnclrBal = Nothing
recTranBalp.Close
Set recTranBalp = Nothing
recTempTran.Close
Set recTempTran = Nothing
recTranBal.Close
Set recTranBal = Nothing
recCurBal.Close
Set recCurBal = Nothing
recTabName.Close
Set recTabName = Nothing

Exit Function
End Function

Public Function GetBalance(BranchCode As String, CurrencyCode As String, _
                ModuleId As String, GlCode As String, AccNo As String, _
                Optional NetBalYN As String, Optional FCurBalYN As String) As String

Dim recObj As Object
Dim FxCurCode As String
Set recTabName = CreateObject("adodb.recordset")
On Error GoTo ErrHand
    
           '----------To find master,tranday,backup,balance tables for the module id
           
If UCase(ModuleId) = "FXLOANS" Or _
   UCase(ModuleId) = "FXDEP" Or UCase(ModuleId) = "FXBILLS" _
   Or UCase(ModuleId) = "LC" Or UCase(ModuleId) = "PIGMY" Or UCase(ModuleId) = "LG" _
   Or UCase(ModuleId) = "INV" Or UCase(ModuleId) = "SHARES" Then
     
           strFlds = "MASTERTABLE,BACKUPTABLE,BALANCETABLE"
           strWhereCond = "moduleid='" & UCase(Trim(ModuleId)) & "'"
          
           Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
           Set recTabName = objFetch.singlerecordset("GENMODULEMST", strFlds, strWhereCond, _
                            "mastertable")
        If objFetch.connerror <> "Connected" Then
            GetBalance = "ERROR" & objFetch.connerror
            GetBalance = Replace(GetBalance, Chr(10), "")
            GetBalance = Replace(GetBalance, Chr(13), "")
            Set objFetch = Nothing
            Exit Function
        End If
        
      If recTabName!mastertable <> "" And recTabName!BALANCETABLE <> "" Then
            
          '----------To get Current Balance from respective balance tables
       
           
           strBalTable = recTabName!BALANCETABLE
          
           
           If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                strFlds = "nvl(curbal,0) Curbal,nvl(fcurbal,0) FCurbal,FCurrencycode"

           Else
           
                strFlds = "nvl(curbal,0) Curbal"
                
           End If
  '''''--------------------------------------------------------------------------------------
           strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & _
                            "' and branchcode='" & Trim(BranchCode) & "' and Currencycode='" _
                            & UCase(Trim(CurrencyCode)) & "' "
      

           Set recCurBal = objFetch.singlerecordset(strBalTable, strFlds, strWhereCond)
          
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
            End If
      
            If recCurBal.RecordCount > 0 Then
                If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                    dblFxClBal = recCurBal!FCurbal
                    FxCurCode = recCurBal!FCurrencycode
                Else
                    dblFxClBal = 0
                End If
                dblClBal = recCurBal!Curbal
                
            Else
               dblClBal = 0
               dblFxClBal = 0
            End If
      
          '----------To find sum(debits) or sum(credits) from respective trandaytables, if any
           If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                strFlds = "nvl(sum(nvl(amount,0)),0) Amt,nvl(sum(nvl(famount,0)),0) fAmt"
               
           Else
                strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
                
           End If
           
           strWhereCond = " accno='" & UCase(Trim(AccNo)) _
                & "' and glcode='" & UCase(Trim(GlCode)) _
                & "' and branchcode='" & UCase(Trim(BranchCode)) _
                & "' and Currencycode='" & UCase(Trim(CurrencyCode)) _
                & "' and moduleid='" & UCase(Trim(ModuleId)) _
                & "'  and ((modeoftran in('2','4') and transtatus='A')" _
                & " or (modeoftran in('1','3','5','6')))"
                
           strTranTable = "GENTRANSLOG"
                                                  
                                                  
           Set recTranBal = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
           
           If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
           End If
           
           If recTranBal.RecordCount > 0 Then
                If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                    dblFxTranBal = recTranBal!Famt
                Else
                    dblFxTranBal = 0
                End If
               dblTranBal = recTranBal!amt
           Else
               dblTranBal = 0
               dblFxTranBal = 0
           End If
     
          '----------To get sum(debits) or sum(credits) from gentranslog, if any
       
           If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
               strFlds = "nvl(sum(nvl(amount,0)),0) Amt,nvl(sum(nvl(famount,0)),0) fAmt"
           Else
                strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
               
           End If
           
           
               
            strWhereCond = "  accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & "' AND " & _
            " branchcode='" & BranchCode & "' and upper(Currencycode)='" & _
            UCase(CurrencyCode) & "' and upper(moduleid)='" & _
            UCase(Trim(ModuleId)) & "' and  (modeoftran in('1','3','5') and upper(transtatus)='P')"
           
           strTranTable = "gentemptranslog"
            
            recTranBal.Close
            Set recTranBal = Nothing
                
           Set recTempTran = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
        
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTranBal.Close
                Set recTranBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
            End If
            
            If recTempTran.RecordCount > 0 Then
                If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                    dblFxTmpTrnBal = recTempTran!Famt
                Else
                    dblFxTmpTrnBal = 0
                End If
               dblTmpTrnBal = recTempTran!amt
            Else
               dblTmpTrnBal = 0
               dblFxTmpTrnBal = 0
            End If
            
          '----------Calculating Clear Balance, Unclear Balance, Net Balance
       
           dblClearBal = dblClBal + dblTranBal + dblTmpTrnBal
           dblFxClearBal = dblFxClBal + dblFxTranBal + dblFxTmpTrnBal
           
          '----------Calculating Unclear Balance only for domestic purpose
          
        If (UCase(NetBalYN) = "Y") And (FCurBalYN = "" Or FCurBalYN = "N") Then
            strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
            strTranTable = "genunclearbalancedtls"
            strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & _
                            "' and branchcode='" & BranchCode & "' and upper(Currencycode)='" & _
                            UCase(CurrencyCode) & "' and upper(moduleid)='" & UCase(Trim(ModuleId)) & "'"
                            
            Set recUnclrBal = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
            
            If objFetch.connerror <> "Connected" Then
                 GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTempTran.Close
                Set recTempTran = Nothing
                recTranBal.Close
                Set recTranBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                 Exit Function
            End If
             
            If recUnclrBal.RecordCount > 0 Then
                dblUnclrBal = recUnclrBal!amt
            Else
                dblUnclrBal = 0
            End If
            
            'dblUnclrBal = "0"
            
            'dblNetBal = Val(dblClearBal) + Val(dblUnclrBal)
            dblNetBal = Val(dblClearBal) - Val(dblUnclrBal)
            
            'This line of code was uncommented by Radhika on 20-sep-2007
            'Reason: For CC accounts I didnot get balances
            GetBalance = dblNetBal
            
            Set objFetch = Nothing
            recUnclrBal.Close
            Set recUnclrBal = Nothing
            recTempTran.Close
            Set recTempTran = Nothing
            If Not recTranBal Is Nothing Then
                recTranBal.Close
                Set recTranBal = Nothing
            End If
            
            Exit Function
        End If
    End If
    
    If NetBalYN = "Y" Then
       GetBalance = dblNetBal
    Else
        If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
            GetBalance = Val(dblClearBal) & "~" & Val(dblFxClearBal) & "~" & FxCurCode
        Else
            GetBalance = Val(dblClearBal)
        End If
    End If
    

ElseIf UCase(ModuleId) = "SB" Or UCase(ModuleId) = "CA" Or UCase(ModuleId) = "SCHOOL" Or UCase(ModuleId) = "DEP" Or UCase(ModuleId) = "LOAN" _
Or UCase(ModuleId) = "CC" Or UCase(ModuleId) = "PL" Or UCase(ModuleId) = "MISC" Or UCase(ModuleId) = "BILLS" Or UCase(ModuleId) = "ATM" Then
     
           strFlds = "MASTERTABLE,BACKUPTABLE,BALANCETABLE"
           strWhereCond = "moduleid='" & UCase(Trim(ModuleId)) & "'"
          
           Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
           Set recTabName = objFetch.singlerecordset("GENMODULEMST", strFlds, strWhereCond, _
                            "mastertable")
        If objFetch.connerror <> "Connected" Then
            GetBalance = "ERROR" & objFetch.connerror
            GetBalance = Replace(GetBalance, Chr(10), "")
            GetBalance = Replace(GetBalance, Chr(13), "")
            Set objFetch = Nothing
            Exit Function
        End If
        
      If recTabName!mastertable <> "" And recTabName!BALANCETABLE <> "" Then
            
          '----------To get Current Balance from respective balance tables
       
           
           strBalTable = recTabName!BALANCETABLE
          
           
           If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                strFlds = "nvl(curbal,0) Curbal,nvl(fcurbal,0) FCurbal,FCurrencycode"

           Else
           
                strFlds = "nvl(curbal,0) Curbal"
                
           End If
  '''''--------------------------------------------------------------------------------------
           strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & _
                            "' and branchcode='" & Trim(BranchCode) & "' and Currencycode='" _
                         & UCase(Trim(CurrencyCode)) & "'"
      
           Set recCurBal = objFetch.singlerecordset(strBalTable, strFlds, strWhereCond)
          
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
            End If
      
            If recCurBal.RecordCount > 0 Then
                
                dblClBal = recCurBal!Curbal
     
            Else
               dblClBal = 0
               
            End If
      
          '----------To find sum(debits) or sum(credits) from respective trandaytables, if any
           
                strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
                    
               
                
           strTranTable = "GENTRANSLOG"
                                                  
                                                  
           strWhereCond = " accno='" & UCase(Trim(AccNo)) _
                & "' and glcode='" & UCase(Trim(GlCode)) _
                & "' and branchcode='" & UCase(Trim(BranchCode)) _
                & "' and moduleid='" & UCase(Trim(ModuleId)) _
                & "'  and ((modeoftran in('2','4') and transtatus='A')" _
                & " or (modeoftran in('1','3','5','6'))) " _
                & " and Currencycode='" & UCase(Trim(CurrencyCode)) & "' "
                
                                                  
           Set recTranBal = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
           
           If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recCurBal.Close
                Set recCurBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
           End If
           
           If recTranBal.RecordCount > 0 Then
                If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                    dblFxTranBal = recTranBal!Famt
                Else
                    dblFxTranBal = 0
                End If
               dblTranBal = recTranBal!amt
           Else
               dblTranBal = 0
               dblFxTranBal = 0
           End If
     
          '----------To get sum(debits) or sum(credits) from gentranslog, if any
       
           If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
               strFlds = "nvl(sum(nvl(amount,0)),0) Amt,nvl(sum(nvl(famount,0)),0) fAmt"
           Else
                strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
               
           End If
               
            strWhereCond = " accno='" & Trim(AccNo) & "' and glcode='" & UCase(Trim(GlCode)) & _
            "' and branchcode='" & BranchCode & "' and Currencycode='" & UCase(CurrencyCode) & _
            "' and upper(moduleid)='" & UCase(Trim(ModuleId)) & _
            "' and (modeoftran in('1','3','5') and upper(transtatus)='P')"
           
           strTranTable = "gentemptranslog"
                           
            recTranBal.Close
            Set recTranBal = Nothing
           Set recTempTran = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
        
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recCurBal.Close
                Set recCurBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
            End If
            
            If recTempTran.RecordCount > 0 Then
                If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
                    dblFxTmpTrnBal = recTempTran!Famt
                Else
                    dblFxTmpTrnBal = 0
                End If
               dblTmpTrnBal = recTempTran!amt
            Else
               dblTmpTrnBal = 0
               dblFxTmpTrnBal = 0
            End If
               
               
         strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
                    
               
                
           strTranTable = "GENTRANSLOG"
                                                             
           strWhereCondp = " accno='" & UCase(Trim(AccNo)) _
                & "' and glcode='" & UCase(Trim(GlCode)) _
                & "' and branchcode='" & UCase(Trim(BranchCode)) _
                & "' and Currencycode='" & UCase(Trim(CurrencyCode)) _
                & "' and moduleid='" & UCase(Trim(ModuleId)) _
                & "'  and ((modeoftran in('2','4') and transtatus='P'))"
                                                  
                                                  
           Set recTranBalp = objFetch.singlerecordset(strTranTable, strFlds, strWhereCondp)
           
           If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTempTran.Close
                Set recTempTran = Nothing
                recTranBal.Close
                Set recTranBal = Nothing
                recCurBal.Close
                Set recCurBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                Exit Function
           End If
           
           If recTranBalp.RecordCount > 0 Then
           
               dblTranBalp = recTranBalp!amt
               dblpendbalp = recTranBalp!amt
               
           Else
               dblTranBalp = 0
               dblpendbalp = 0
            End If
     
     
         '----------Calculating Clear Balance, Unclear Balance, Net Balance
           
           'account bal
           dblClearBal = dblClBal + dblTranBal + dblTmpTrnBal
       
           
            dblpendamt = dblpendbalp
               
       
          
          '----------Calculating Unclear Balance only for domestic purpose
          
        If (UCase(NetBalYN) = "Y") And (FCurBalYN = "" Or FCurBalYN = "N") Then
            strFlds = "nvl(sum(nvl(amount,0)),0) Amt"
            strTranTable = "genunclearbalancedtls"
            strWhereCond = " accno='" & Trim(AccNo) & "'and glcode='" & UCase(Trim(GlCode)) & _
            "' and branchcode='" & BranchCode & "' and Currencycode='" & UCase(CurrencyCode) & _
            "' and moduleid='" & UCase(Trim(ModuleId)) & "'"
                            
            Set recUnclrBal = objFetch.singlerecordset(strTranTable, strFlds, strWhereCond)
            
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                
                Set objFetch = Nothing
                recTranBalp.Close
                Set recTranBalp = Nothing
                recTempTran.Close
                Set recTempTran = Nothing
                recTranBal.Close
                Set recTranBal = Nothing
                recCurBal.Close
                Set recCurBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                 Exit Function
            End If
             
            If recUnclrBal.RecordCount > 0 Then
                dblUnclrBal = recUnclrBal!amt
            Else
                dblUnclrBal = 0
            End If
            
      
            ''Set recCtsClg = objFetch.singlerecordset("GENCONFIGMST", "IMPYN", "CODE='CLGCTS' AND BRANCHCODE='101'")
            
            Set recCtsClg = objFetch.singlerecordset("GENCONFIGMST", "IMPYN", "CODE='CLGCTS'")
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
                recTranBalp.Close
                Set recTranBalp = Nothing
                recTempTran.Close
                Set recTempTran = Nothing
                recTranBal.Close
                Set recTranBal = Nothing
                recCurBal.Close
                Set recCurBal = Nothing
                recTabName.Close
                Set recTabName = Nothing
                 Exit Function
            End If
            
            Dim strCtsClg As String
            strCtsClg = "N"
            If recCtsClg.RecordCount > 0 Then
                strCtsClg = recCtsClg!IMPYN
            Else
                strCtsClg = "N"
            End If
           ''clearing bal
            dblNetBal = Val(dblClearBal) - Val(dblUnclrBal) + dblpendbalp
            
            If strCtsClg = "Y" Then
                dblNetBal = Val(dblClearBal) + dblpendbalp
                dblClearBal = Val(dblClearBal) + Val(dblUnclrBal)
            Else
                dblNetBal = Val(dblClearBal) - Val(dblUnclrBal) + dblpendbalp
            End If
           
            
            recTempTran.Close
            
            'dblUnclrBal = "0"
            
            'dblNetBal = Val(dblClearBal) + Val(dblUnclrBal)
            
            'This line of code was uncommented by Radhika on 20-sep-2007
            'Reason: For CC accounts I didnot get balances
            GetBalance = dblNetBal
            
            On Error Resume Next
            recUnclrBal.Close
            Set recUnclrBal = Nothing
            recTranBalp.Close
            Set recTranBalp = Nothing
            recTempTran.Close
            Set recTempTran = Nothing
            recTranBal.Close
            Set recTranBal = Nothing
            recCurBal.Close
            Set recCurBal = Nothing
            
            Exit Function
            End If
          
           If NetBalYN = "Y" Then
       GetBalance = dblNetBal
    Else
        If Left(Trim(UCase(ModuleId)), 2) = "FX" And Trim(UCase(FCurBalYN)) = "Y" Then
            GetBalance = Val(dblClearBal) & "~" & Val(dblFxClearBal) & "~" & FxCurCode
        Else
            GetBalance = Val(dblClearBal)
        End If
    End If
                    
End If
            
     'Code added on 20-July-2006
    'Reason:We need to handle Recurring type deposits separately
    If UCase(Trim(ModuleId)) = "DEP" Then
        
        'Check whether given Deposit GL is a RD type or not
        Set recObj = objFetch.singlerecordset("deptypemst", _
        "nvl(instsyn,'N') InstlmntYN", "upper(trim(moduleid))='DEP'" & _
        " and upper(trim(glcode))='" & UCase(Trim(GlCode)) & "'")
        
        If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                Set objFetch = Nothing
''                recObj.Close
''                Set recObj = Nothing
                Exit Function
        End If
        
        If UCase(Trim(recObj!InstlmntYN)) = "Y" Then 'i.e. Given Deposit GL is of RDtype
            'So get & add Interest Accrued to A/C balance
            
            strTranTable = "DEPINTACCRUEDDTLS"
            strFlds = "nvl(SUM(nvl(intamount,0)),0) SumIntAmt"
            strWhereCond = " accno='" & Trim(AccNo) & "' AND glcode='" & UCase(Trim(GlCode)) & _
            "' AND branchcode='" & Trim(BranchCode) & "' AND currencycode='" & UCase(Trim(CurrencyCode)) & _
            "' AND moduleid='DEP' "
                
            Set recObj = objFetch.singlerecordset(strTranTable, _
                strFlds, strWhereCond)
            
            If objFetch.connerror <> "Connected" Then
                GetBalance = "ERROR" & objFetch.connerror
                
                recObj.Close
                Set recObj = Nothing
                Set objFetch = Nothing
                Exit Function
            End If
            
            If NetBalYN = "Y" Then
               GetBalance = dblNetBal
            Else
                GetBalance = Val(dblClearBal)
            End If
                        
        End If
        End If
      
 Else
       GetBalance = ""
End If

    On Error Resume Next
    recObj.Close
    Set recObj = Nothing
    recTranBal.Close
    Set recTranBal = Nothing
    recCurBal.Close
    Set recCurBal = Nothing
    recUnclrBal.Close
    Set recUnclrBal = Nothing
    recTempTran.Close
    Set recTempTran = Nothing
    ''objFetch.Close
    Set objFetch = Nothing

    Exit Function
ErrHand:
    GetBalance = "ERROR" & Err.Number & Err.Description
 
 objErrlog.LogError "AccountDetails", "GetBalance", Err.Number, Err.Description
 
    On Error Resume Next
    recObj.Close
    Set recObj = Nothing
    recTranBal.Close
    Set recTranBal = Nothing
    recCurBal.Close
    Set recCurBal = Nothing
    recUnclrBal.Close
    Set recUnclrBal = Nothing
    recTempTran.Close
    Set recTempTran = Nothing
    recTranBal.Close
    Set recTranBal = Nothing
    recTabName.Close
    Set recTabName = Nothing
    Set objFetch = Nothing
    Exit Function
End Function

Public Function GetSumOfAccsBalance(BranchCode As String, CurrencyCode As String, _
         ModuleId As String, GlCode As String, ParameterDate As String, _
         Applicationdate As String) As Variant
         
On Error GoTo ErrHand
         
    Dim objFetchRec  As Object
    Dim recBalance As Recordset, recTran As Recordset
    Dim CurCode As String, BrCode As String
    Dim Modulecode As String, sCondToReturn As String
    Dim GlId As String, iErrLineNumber As Integer
    Dim StrBalTabName As String, StrBalFlds As String, StrBalCond As String
    Dim StrTranTabName As String, StrTranFlds As String, StrTranCond As String
    Dim StrTranBal As Double

    Set recBalance = CreateObject("adodb.recordset")
    Set recTran = CreateObject("adodb.recordset")

    '''******* Assiging the Arguments to the variables *********
    CurCode = UCase(Trim(CurrencyCode))
    BrCode = UCase(Trim(BranchCode))
    Modulecode = UCase(Trim(ModuleId))
    GlId = UCase(Trim(GlCode))
    sCondToReturn = ""

    Set objFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    StrTranBal = 0
    
    If Modulecode = "REM" Then
    'Remitance
        iErrLineNumber = 1
        StrBalCond = " issueddate<=to_date('" & ParameterDate & "','dd-Mon-yyyy') " & _
            " and branchcode='" & BrCode & "' and " & " currencycode='" & CurCode & "' and " & _
            " glcode='" & GlId & "'" & _
            " and (paiddate > to_date('" & ParameterDate & "','dd-Mon-yyyy') " & _
            " or paiddate is null) "
    
        sCondToReturn = StrBalCond
    
        'Get GL balance from respective Balance table
        Set recBalance = objFetchRec.singlerecordset("REMITISSUEMST", _
            "SUM(nvl(AMOUNT,0))", StrBalCond)
            
        StrTranBal = IIf(IsNull(recBalance(0)), 0, recBalance(0))
            
    ElseIf Modulecode = "SCR" Then
    'Sundry creditors and sundry debtors
    
        'First get its Type of Normal Balance from GLMastMst
        Set recBalance = objFetchRec.singlerecordset("GENGLMASTMST", _
            "NVL(normalbalance,'CR')", "moduleid='SCR' AND " & _
            " upper(trim(glcode))='" & GlId & "'")
        
        iErrLineNumber = 2
        
        StrBalFlds = " NVL( (SELECT SUM(NVL(opbal,0)) FROM SCRDTLS" & _
            " WHERE UPPER(trim(branchcode))='" & BrCode & "' " & _
            " AND  UPPER(trim(currencycode))='" & CurCode & "' " & _
            " AND UPPER(trim(glcode))='" & GlId & "' AND opdate<=" & _
            " to_date('" & ParameterDate & "','dd-Mon-yyyy') ),0)"
        
        sCondToReturn = StrBalFlds
        
        Dim sBalType As String
        
        sBalType = IIf(IsNull(recBalance(0)), "CR", recBalance(0))
        sBalType = UCase(Trim(sBalType))
        
        If sBalType = "DR" Then
            
            iErrLineNumber = 3
            
            StrBalFlds = StrBalFlds & " + " & _
                " NVL( (SELECT SUM(NVL(amount,0)) FROM SCRTRAN " & _
                " WHERE UPPER(trim(branchcode))='" & BrCode & "' " & _
                " AND UPPER(trim(currencycode))='" & CurCode & "'  " & _
                " AND UPPER(trim(glcode))='" & GlId & "'" & _
                " AND NVL(amount,0) >0 AND applicationdate<= " & _
                " to_date('" & ParameterDate & "','dd-Mon-yyyy') ),0)"
                
            sCondToReturn = StrBalFlds
            
        Else
        
            iErrLineNumber = 4
            
            StrBalFlds = StrBalFlds & " + " & _
                " NVL( (SELECT SUM(NVL(amount,0)) FROM SCRTRAN " & _
                " WHERE UPPER(trim(branchcode))='" & BrCode & "'  " & _
                " AND UPPER(trim(currencycode))='" & CurCode & "'  " & _
                " AND UPPER(trim(glcode))='" & GlId & "'" & _
                " AND NVL(amount,0) < 0 AND applicationdate<= " & _
                " to_date('" & ParameterDate & "','dd-Mon-yyyy') ),0)"
        
            sCondToReturn = StrBalFlds
        
        End If
        
    
        'Get GL balance from respective Balance table
        Set recBalance = objFetchRec.singlerecordset("dual", _
            StrBalFlds, " 1 = 1")
            
        StrTranBal = IIf(IsNull(recBalance(0)), 0, recBalance(0))
            
    Else 'For Other Modules
        StrBalTabName = Modulecode & "balance"
        StrBalCond = "upper(trim(branchcode))='" & BrCode & "' and " & _
            "upper(trim(currencycode))='" & CurCode & "' and " & _
            "upper(trim(glcode))='" & GlId & "'"
         
        StrTranTabName = Modulecode & "Tran"
        StrTranCond = "upper(trim(branchcode))='" & BrCode & "' and " & _
            "upper(trim(currencycode))='" & CurCode & "' and " & _
            "upper(trim(glcode))='" & GlId & "' and " & _
            "applicationdate>to_date('" & ParameterDate & "','dd-Mon-yyyy') and " & _
            "applicationdate<=to_date('" & Applicationdate & "','dd-Mon-yyyy')"
    
        iErrLineNumber = 5
        sCondToReturn = StrBalCond
        
    
        'Get GL balance from respective Balance table
        Set recBalance = objFetchRec.singlerecordset(StrBalTabName, _
            "SUM(nvl(CURBAL,0))", StrBalCond)
        
        iErrLineNumber = 6
        sCondToReturn = StrTranCond
        
        'Get sum of transactions effect from Respective tran table
        Set recTran = objFetchRec.singlerecordset(StrTranTabName, _
            "SUM(nvl(AMOUNT,0))", StrTranCond)
        
        iErrLineNumber = 7
        
        StrTranBal = IIf(IsNull(recBalance(0)), 0, recBalance(0))
        StrTranBal = StrTranBal - IIf(IsNull(recTran(0)), 0, recTran(0))
        
    End If
    
    iErrLineNumber = 8
    GetSumOfAccsBalance = StrTranBal
    
    recBalance.Close
    Set recBalance = Nothing
    recTran.Close
    Set recTran = Nothing
    Set objFetchRec = Nothing
    Exit Function

ErrHand:

    GetSumOfAccsBalance = "ERROR At Line " & iErrLineNumber & "; " & _
        Err.Number & " : " & Err.Description & Chr(13) & _
        StrBalFlds & "## Qry=" & sCondToReturn
        
    GetSumOfAccsBalance = Replace(GetSumOfAccsBalance, Chr(10), "")
    GetSumOfAccsBalance = Replace(GetSumOfAccsBalance, Chr(13), "")
    
    objErrlog.LogError "AccountDetails", "GetSumOfAccsBalance", Err.Number, Err.Description
    
    recBalance.Close
    Set recBalance = Nothing
    recTran.Close
    Set recTran = Nothing
    Set objFetchRec = Nothing
    
End Function


Public Function getAccountsInRange(BranchCode As String, CurrencyCode As String, _
                ModuleId As String, GlCode As String, Prefix As String, _
                Suffix As String, FromAccno As Variant, ToAccno As Variant) As String
On Error GoTo myerr

Dim recPrefix As Object

Dim strMstTable As String
Dim strFlds As String
Dim strWhereCond As String
Dim strAccnos As String


If BranchCode <> "" And CurrencyCode <> "" And ModuleId <> "" And GlCode <> "" Then
    strMstTable = Trim(ModuleId) & "Mst"
    strFlds = "Accno"
    
    strWhereCond = " accno between " & FromAccno & " and " & ToAccno & " and GLcode='" & Trim(GlCode) & "'" & _
                    " and Branchcode='" & Trim(BranchCode) & "' and CurrencyCode='" & Trim(CurrencyCode) & "'"
    
    If Trim(Prefix) <> "" And Trim(Suffix) = "" Then
        strWhereCond = "Branchcode='" & Trim(BranchCode) & "' and " & _
                    "CurrencyCode='" & Trim(CurrencyCode) & "' and " & _
                    "GLcode='" & Trim(GlCode) & "' and upper(substr(accno,1," & Len(Trim(Prefix)) & _
                    "))='" & UCase(Trim(Prefix)) & "' and to_number(substr(accno," & Len(Trim(Prefix)) + 1 & _
                    "))>=" & FromAccno & " and to_number(substr(accno," & Len(Trim(Prefix)) + 1 & "))" & _
                    "<=" & ToAccno
    End If
    
    
     If Trim(Suffix) <> "" And Trim(Prefix) = "" Then
        strWhereCond = "Branchcode='" & Trim(BranchCode) & "' and " & _
                    "CurrencyCode='" & Trim(CurrencyCode) & "' and " & _
                    "GLcode='" & Trim(GlCode) & "' and upper(substr(accno,-" & Len(Trim(Suffix)) & _
                    "))='" & UCase(Trim(Suffix)) & "' and to_number(substr(accno,-" & Len(Trim(Suffix)) + 1 & _
                    "))>=" & FromAccno & " and to_number(substr(accno,-" & Len(Trim(Suffix)) + 1 & "))" & _
                    "<=" & ToAccno
    End If
    
    If Trim(Prefix) <> "" And Trim(Suffix) <> "" Then
        strWhereCond = "Branchcode='" & Trim(BranchCode) & "' and " & _
                    "CurrencyCode='" & Trim(CurrencyCode) & "' and " & _
                    "GLcode='" & Trim(GlCode) & "' and upper(substr(accno,1," & Len(Trim(Prefix)) & _
                    "))='" & UCase(Trim(Prefix)) & "' and upper(substr(accno,-" & Len(Trim(Suffix)) & _
                    "))='" & UCase(Trim(Suffix)) & "' and to_number(substr(accno," & Len(Trim(Prefix)) + 1 & _
                    ",length(accno)-" & Len(Trim(Prefix)) + Len(Trim(Suffix)) & "))>=" & FromAccno & _
                    " and  to_number(substr(accno," & Len(Trim(Prefix)) + 1 & _
                    ",length(accno)-" & Len(Trim(Prefix)) + Len(Trim(Suffix)) & "))<=" & ToAccno

    End If
                    

    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recMst = CreateObject("adodb.recordset")
    Set recMst = objFetch.singlerecordset(strMstTable, strFlds, strWhereCond)
    
    If Not recMst.EOF And Not recMst.BOF Then
        Do While Not recMst.EOF
            
            If strAccnos = "" Then
                   strAccnos = "'" & recMst!AccNo & "'"
            Else
                strAccnos = strAccnos & ",'" & recMst!AccNo & "'"
            End If
            recMst.MoveNext
        Loop
        getAccountsInRange = strAccnos
    Else
        getAccountsInRange = "0"
    End If
    
Else
    GoTo myerr

End If

recMst.Close
Set recMst = Nothing
Set objFetch = Nothing
Exit Function

myerr:
getAccountsInRange = Err.Description & "      " & strWhereCond
getAccountsInRange = Replace(getAccountsInRange, Chr(10), "")
getAccountsInRange = Replace(getAccountsInRange, Chr(13), "")

objErrlog.LogError "AccountDetails", "GetAccountsInRange", Err.Number, Err.Description

recMst.Close
Set recMst = Nothing
Set objFetch = Nothing
End Function



Public Function getPrefixSuffix(GlCode As String) As String
On Error GoTo myerr

Dim recPrefix As Object

Dim strMstTable As String
Dim strFlds As String
Dim strWhereCond As String

If GlCode <> "" Then
    Set recPrefix = CreateObject("adodb.recordset")
    strMstTable = "GENAUTONUMBERPMT"
    strFlds = "PREFIXVALUE,SUFFIXVALUE"
    strWhereCond = "glcode='" & Trim(GlCode) & "'"

    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recMst = CreateObject("adodb.recordset")
    Set recMst = objFetch.singlerecordset(strMstTable, strFlds, strWhereCond)
        
    If Not recMst.EOF And Not recMst.BOF Then
        getPrefixSuffix = recMst!PREFIXVALUE & "" & "~" & recMst!SUFFIXVALUE & ""
    Else
        getPrefixSuffix = "0"
    End If
    
    

Else
    GoTo myerr

End If


''recMst.Close
''Set recMst = Nothing
''Set objFetch = Nothing

Exit Function

myerr:
getPrefixSuffix = Err.Description
getPrefixSuffix = Replace(getPrefixSuffix, Chr(10), "")
getPrefixSuffix = Replace(getPrefixSuffix, Chr(13), "")

recMst.Close
Set recMst = Nothing
Set objFetch = Nothing
End Function

Public Function GetBackDatedBalance(BranchCode As String, CurrencyCode As String, _
         ModuleId As String, GlCode As String, ParameterDate As String, _
         Applicationdate As String, Optional AccNo As String) As Variant
Dim objFetchRec  As Object
Dim recMst As Recordset
Dim recBalance As Recordset
Dim recTran As Recordset
Dim CurCode As String
Dim BrCode As String
Dim ParamDate As String
Dim Modulecode As String
Dim GlId As String
Dim AccntNo As String
Dim StrMstTabName As String
Dim StrMstFlds As String
Dim StrMstCond As String
Dim StrBalTabName As String
Dim StrBalFlds As String
Dim StrBalCond As String
Dim StrTranTabName As String
Dim StrTranFlds As String
Dim StrTranCond As String
Dim StrAcc As String
Dim StrCurBal As Double
Dim StrCurDate As String
Dim StrTranBal As Double
ReDim strGetBackDateBal(0) As Variant
Dim icnt As Double
Dim IsItRecurringDeposit As Boolean, recObj As Object

    StrCurBal = 0
    StrTranBal = 0
    icnt = 0
    Set recMst = CreateObject("adodb.recordset")
    Set recBalance = CreateObject("adodb.recordset")
    Set recTran = CreateObject("adodb.recordset")
    
    '''******* Assiging the Arguments to the variables *********
    CurCode = UCase(Trim(CurrencyCode))
    BrCode = UCase(Trim(BranchCode))
    ParamDate = ParameterDate
    Modulecode = UCase(Trim(ModuleId))
    GlId = UCase(Trim(GlCode))
    AccntNo = UCase(Trim(AccNo))
    StrCurDate = Applicationdate

    '''''checking paraterered account is send or not
    If AccntNo = "" Then
       StrAcc = ""
    Else
        StrAcc = " and accno='" & AccntNo & "'"
    End If
    
    '''OPENING AND CLOSING DATES STORING IN VARAIBLES
    Dim stropdate
    Dim strclosedate

    If Modulecode = "LG" Then
        stropdate = "applicationdate"
    ElseIf Modulecode = "LC" Then
        stropdate = "LCISSUEDATE"
    ElseIf Modulecode = "BILLS" Then
        stropdate = "applicationdate"
    Else
        stropdate = "opdate"
    End If
    
    If Mid(Modulecode, 1, 2) = "FX" Then
       strclosedate = "closeddate"
    Else
        strclosedate = "closedate"
    End If
    
'''for storing values in master table querying varaiables
StrMstTabName = Modulecode & "MST"
StrMstFlds = "accno,name"
StrMstCond = "upper(trim(branchcode))='" & BrCode & "' and " & _
            "upper(trim(currencycode))='" & CurCode & "' and " & _
            "upper(trim(glcode))='" & GlId & "'  and " & _
            stropdate & "<=to_date('" & ParamDate & "','dd-mon-yyyy') and " & _
            "(" & strclosedate & " is null or  " & strclosedate & ">=to_date('" & ParamDate & "','dd-Mon-yyyy'))" & _
            StrAcc

'''for storing values in variables for balance table querying varaiables
        StrBalTabName = Modulecode & "balance"
        ''',to_char(applicationdate,'dd-Mon-yyyy')
        StrBalFlds = "CURBAL,to_char(applicationdate,'dd-Mon-yyyy')"
        StrBalCond = "upper(trim(branchcode))='" & BrCode & "' and " & _
            "upper(trim(currencycode))='" & CurCode & "' and " & _
            "upper(trim(glcode))='" & GlId & "'"

 '''for storing values in variables tran table querying varaiables
        StrTranTabName = Modulecode & "Tran"
        StrTranFlds = "Sum(amount)"
        StrTranCond = "upper(trim(branchcode))='" & BrCode & "' and " & _
            "upper(trim(currencycode))='" & CurCode & "' and " & _
            "upper(trim(glcode))='" & GlId & "'"
On Error GoTo ErrHand

Set objFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")

    'Code added on 20-July-2006
    'Reason:We need to handle Recurring type deposits separately
    If UCase(Trim(ModuleId)) = "DEP" Then

        'Check whether given Deposit GL is a RD type or not
        Set recObj = objFetchRec.singlerecordset("deptypemst", _
        "nvl(instsyn,'N') InstlmntYN", "upper(trim(moduleid))='DEP'" & _
        " and upper(trim(glcode))='" & UCase(Trim(GlCode)) & "'")

        If objFetchRec.connerror <> "Connected" Then
             GetBackDatedBalance = "ERROR : " & objFetchRec.connerror
             GetBackDatedBalance = Replace(GetBackDatedBalance, Chr(10), "")
             GetBackDatedBalance = Replace(GetBackDatedBalance, Chr(13), "")
             Set objFetchRec = Nothing
             recObj.Close
             Set recObj = Nothing
             Exit Function
        End If

        If UCase(Trim(recObj!InstlmntYN)) = "Y" Then
            IsItRecurringDeposit = True
        Else
            IsItRecurringDeposit = False
        End If
        Set recObj = Nothing
    End If
    'End of Code added on 20-July-2006


'''' setting a recordset for getting the Accno from modulemst table which are opened as on
'''parameters and not closed
Set recMst = objFetchRec.singlerecordset(StrMstTabName, StrMstFlds, _
                                        StrMstCond)

    If Not recMst.EOF And Not recMst.BOF Then
    ReDim strGetBackDateBal(recMst.RecordCount - 1)
      Do Until recMst.EOF
      StrTranBal = 0
      StrCurBal = 0
        '''for setting arecordset for getting the currenct balance
        Set recBalance = objFetchRec.singlerecordset(StrBalTabName, StrBalFlds, _
                                StrBalCond & " and accno='" & recMst(0) & "'")
            If Not recBalance.EOF And Not recBalance.BOF Then
                    ''checking for null values if null  values in current balance,
                    '''application date then balance as 0 and date as applicationdate
                       If IsNull(recBalance(0)) Then
                            StrCurBal = 0
                       Else
                            StrCurBal = recBalance(0) & ""
                       End If
                       If IsNull(recBalance(1)) Then
                             StrCurDate = Applicationdate
                       Else
                            StrCurDate = recBalance(1) & ""
                       End If
            End If
        '''for setting arecordset for getting the sumof credit and debits balance fromtran
        Set recTran = objFetchRec.singlerecordset(StrTranTabName, StrTranFlds, _
                        StrTranCond & " and accno='" & recMst(0) & "' and  " & _
                        "applicationdate>to_date('" & ParamDate & "','dd-Mon-yyyy') and " & _
                        "applicationdate<=to_date('" & StrCurDate & "','dd-Mon-yyyy')")
            If Not recTran.EOF And Not recTran.BOF Then
            ''opposite credit or debit balances
                If Not IsNull(recTran(0)) Then
                    If Val(recTran(0)) > 0 Then
                        StrTranBal = "-" & recTran(0) & ""
                    ElseIf Val(recTran(0)) < 0 Then
                        StrTranBal = Mid(recTran(0), 2, Len(recTran(0)))
                    Else
                        StrTranBal = recTran(0) & ""
                    End If
               End If
            End If

            'Code added on 20-July-2006
            'Reason:We need to handle Recurring type deposits separately
            If IsItRecurringDeposit = True Then
                'So get & add Interest Accrued to A/C balance
                strGetBackDateBal(icnt) = recMst(0) & "*" & recMst(1) & "*" & Val(StrCurBal) + Val(StrTranBal)
            Else
                strGetBackDateBal(icnt) = recMst(0) & "*" & recMst(1) & "*" & Val(StrCurBal) + Val(StrTranBal)
            End If
            'End of Code added on 20-July-2006

        'strGetBackDateBal(icnt) = recMst(0) & "*" & recMst(1) & "*" & Val(StrCurBal) + Val(StrTranBal) + recObj!SumIntAmt
        icnt = icnt + 1
      recMst.MoveNext
      Loop
      '''function returns array in the form of accno~name~overduebalance
     GetBackDatedBalance = strGetBackDateBal
    '''''if no accounts in module mst table for given parameters condition
    Else
    strGetBackDateBal(icnt) = "No Records"
    GetBackDatedBalance = strGetBackDateBal
    End If
    
    recMst.Close
    Set recMst = Nothing
    recBalance.Close
    Set recBalance = Nothing
    recTran.Close
    Set recTran = Nothing
    recObj.Close
    Set recObj = Nothing
    Set objFetchRec = Nothing
    Exit Function
    
ErrHand:
    
GetBackDatedBalance = Err.Number & " : " & Err.Description
GetBackDatedBalance = Replace(GetBackDatedBalance, Chr(10), "")
GetBackDatedBalance = Replace(GetBackDatedBalance, Chr(13), "")

objErrlog.LogError "AccountDetails", "GetBackDatedBalance", Err.Number, Err.Description

recMst.Close
Set recMst = Nothing
recBalance.Close
Set recBalance = Nothing
recTran.Close
Set recTran = Nothing
recObj.Close
Set recObj = Nothing
Set objFetchRec = Nothing
End Function

Private Function GetLimitAmt(BrCode As String, CurCode As String, ModId As String, _
GlCode As String, AccNo As String, BrApplDate As String) As Double

    Dim RecLimit As Object
    Dim sFlds As String, sCond As String, dblLimitAmt As Double
    
    sFlds = "Sum(nvl(LINKEDAMOUNT,0)) amt"
    
    sCond = " LINKEDACCNO='" & AccNo & "' and LINKEDGLCODE='" & GlCode & _
            "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND " & _
            " LINKEDMODULEID='" & ModId & "'   and closedate is null and " & _
            " status='R' " 'and expirydate >='" & BrApplDate & "'"
    
    Set RecLimit = objFetch.singlerecordset("GENLIMITLNK", sFlds, sCond)
    
    If objFetch.connerror <> "Connected" Then
        RecLimit.Close
        Set RecLimit = Nothing
        Err.Raise 999, , objFetch.connerror
    End If
    
    If RecLimit.RecordCount > 0 Then
        dblLimitAmt = IIf(IsNull(RecLimit!amt), 0, RecLimit!amt)
    Else
        dblLimitAmt = "0"
    End If
    GetLimitAmt = dblLimitAmt
    
    RecLimit.Close
    Set RecLimit = Nothing
    
End Function

Private Function GetDrawingPowerAmt(BrCode As String, CurCode As String, ModId As String, _
GlCode As String, AccNo As String) As Double

    Dim RecLimit As Object
    Dim sFlds As String, sCond As String, dblLimitAmt As Double
    
    sFlds = "nvl(DRAWINGPOWER,0) amt"
    
    sCond = " ACCNO='" & AccNo & "' and GLCODE='" & GlCode & _
        "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND " & _
        " MODULEID='" & ModId & "' and status='R'"
    
    Set RecLimit = objFetch.singlerecordset("gendpdtls", sFlds, sCond)
    
    If objFetch.connerror <> "Connected" Then
         RecLimit.Close
         Set RecLimit = Nothing
         Err.Raise 999, , objFetch.connerror
    End If
    
    If RecLimit.RecordCount > 0 Then
        dblLimitAmt = IIf(IsNull(RecLimit!amt), 0, RecLimit!amt)
    Else
        dblLimitAmt = "0"
    End If
    GetDrawingPowerAmt = dblLimitAmt

    RecLimit.Close
    Set RecLimit = Nothing

End Function

Private Function GetIntAccrued(BrCode As String, CurCode As String, ModId As String, _
GlCode As String, AccNo As String) As Double

    Dim Rec As Object
    Dim sFlds As String, sCond As String, dblAmt As Double
    Dim sTabName As String
    
    sTabName = Trim(UCase(ModId)) & "INTACCRUEDDTLS"
    
    If Trim(UCase(ModId)) = "DEP" Then
        sFlds = "nvl(SUM(INTAMOUNT),'0') AMT"
    Else
        sFlds = "Sum(nvl(debit, 0)) - Sum(nvl(credit, 0))   AMT "
    End If
    
    sCond = " ACCNO='" & AccNo & "' and GLCODE='" & GlCode & _
        "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND " & _
        " MODULEID='" & ModId & "'  "
        
        ' AND TRANSFERTODEP IS NULL"
    
    Set Rec = objFetch.singlerecordset(sTabName, sFlds, sCond)
    
    If objFetch.connerror <> "Connected" Then
         Rec.Close
         Set Rec = Nothing
         Err.Raise 999, , objFetch.connerror
    End If
    
    If Rec.RecordCount > 0 Then
        dblAmt = IIf(IsNull(Rec!amt), 0, Rec!amt)
    Else
        dblAmt = "0"
    End If
    GetIntAccrued = dblAmt
    
    Rec.Close
    Set Rec = Nothing

End Function

Private Function GetLoanScheduleAmt(BrCode As String, CurCode As String, GlCode As String, _
AccNo As String, CutOffDt As String) As Double

    Dim Rec As Object
    Dim sFlds As String, sCond As String, dblAmt As Double
    Dim sTabName As String
    
    sTabName = "LOANSCHEDULEDTLS a"
    sFlds = "NVL(balanceamt,0) AMT"
    
    sCond = " ACCNO='" & AccNo & "' and " & _
        " repayduedate = (SELECT MAX(repayduedate) FROM LOANSCHEDULEDTLS b" & _
        "   WHERE b.BRANCHCODE=a.BRANCHCODE AND b.CURRENCYCODE=a.CURRENCYCODE AND" & _
        "   b.glcode=a.glcode AND b.accno=a.accno AND b.repayduedate <='" & CutOffDt & "') " & _
        " AND GLCODE='" & GlCode & "'AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' "
    
    Set Rec = objFetch.singlerecordset(sTabName, sFlds, sCond)
    
    If objFetch.connerror <> "Connected" Then
        Rec.Close
        Set Rec = Nothing
        Err.Raise 999, , objFetch.connerror
    End If
    
    If Rec.RecordCount > 0 Then
        dblAmt = IIf(IsNull(Rec!amt), 0, Rec!amt)
    Else
        dblAmt = "0"
    End If
    GetLoanScheduleAmt = dblAmt
    
    Rec.Close
    Set Rec = Nothing

End Function

Private Function GetBranchApplDate(BrCode As String) As String

    Dim Rec As Object
    Dim sFlds As String, sCond As String, dblAmt As Double
    Dim sTabName As String
    
    sTabName = "GENAPPLICATIONDATEMST"
    sFlds = "to_char(applicationdate,'dd-Mon-yyyy')"
    sCond = " branchcode='" & BrCode & "'"
    
    Set Rec = objFetch.singlerecordset(sTabName, sFlds, sCond)
    
    If objFetch.connerror <> "Connected" Then
        Rec.Close
        Set Rec = Nothing
        Rec.Close
        Set Rec = Nothing
        Err.Raise 999, , objFetch.connerror
    End If
    
    If Rec.EOF = True Then
        Err.Raise 999, , "Application Date of Given Branch code not found"
    End If
    
    GetBranchApplDate = Rec(0).Value
    
    Rec.Close
    Set Rec = Nothing

End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
