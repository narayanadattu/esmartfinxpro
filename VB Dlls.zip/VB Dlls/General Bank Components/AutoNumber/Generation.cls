VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "Generation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim AdoRs() As ADODB.Recordset   '    Multiple Recordset Objects
Dim Rstemp As ADODB.Recordset
Dim ICount As Integer
Public Function GetAutoNumber(TabName As String, AutoNumFldName As String, _
                                Optional WhereCondition As String, _
                                Optional InitialNum As String) As String
                                

    Dim StrQuery As String, AutoFieldName As String, StrTabName, strCondition As String
    Dim Objquery As Object
    Dim IntLen As Integer
    Dim strPrefix As String
    Dim IntFldLen As Integer
    On Error GoTo errhand

    StrTabName = Trim(TabName)
    AutoFieldName = Trim(AutoNumFldName)
    strCondition = Trim(WhereCondition)

    'If strCondition = "" Then
    '    GetAutoNumber = "Please Give BranchCode For Your Auto Number Generation."
    '    Exit Function
    'End If

ConnError = ""

  '*************Forming the sql select query*************
        Set Rstemp = CreateObject("adodb.recordset")
        StrQuery = ""
        StrQuery = "nvl(max(to_number(" & AutoFieldName & ")),0)"
         
        Set Objquery = CreateObject("QueryRecordsets.FetchRecordsets")
                      
        If Trim(WhereCondition) <> "" Then
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), StrQuery, WhereCondition)
        Else
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), StrQuery)
        End If
          
        If Rstemp.State = 0 Then
            GetAutoNumber = Objquery.ConnError
            GetAutoNumber = Replace(GetAutoNumber, Chr(10), "")
            GetAutoNumber = Replace(GetAutoNumber, Chr(13), "")
            Set Objquery = Nothing
            Exit Function
        End If
        
        
            
        If (Not Rstemp.EOF And Not Rstemp.BOF) Then
            If Trim(InitialNum) = "" Then
                GetAutoNumber = Rstemp.Fields(0).Value + 1
            ElseIf Rstemp.Fields(0) = 0 Then
                GetAutoNumber = InitialNum
            Else
                   IntLen = Len(InitialNum)
                    IntFldLen = Len(Rstemp.Fields(0).Value + 1)
                    strPrefix = ""
                    
                    If IntFldLen < IntLen Then
                        For ICount = 1 To (IntLen - IntFldLen)
                            strPrefix = strPrefix & "0"
                        Next ICount
                    End If
                GetAutoNumber = strPrefix & (Rstemp.Fields(0).Value + 1)
                
            End If
        Else
            If Trim(InitialNum) = "" Then
                GetAutoNumber = 1
            Else
                GetAutoNumber = InitialNum
            End If
        End If
               
        '*************Returned a Recordset to the Client Application*************
        
        Exit Function
        
errhand:

'*************RecordSet Not oppened************
    GetAutoNumber = "Auto Number Could Not Be Generated Due To : " & Objquery.ConnError & Err.Number & " : " & Err.Description
    GetAutoNumber = Replace(GetAutoNumber, Chr(10), "")
    GetAutoNumber = Replace(GetAutoNumber, Chr(13), "")
End Function
Public Function GetAutoText(TabName As String, AutoNumFldName As String, _
                            InitialAutoText As String, _
                            Optional WhereCondition As String) As String
                            
    Dim StrQuery As String
    Dim AutoFieldName As String
    Dim StrTabName As String
    Dim strCondition As String
    Dim StrAlfhaText As String
    Dim Objquery As Object
    Dim intFieldSize As Integer
    Dim StrAutoText As String
    Dim StrInitialChar As String
    Dim Txtlen  As Integer
    Dim Zcount As Integer
    
    On Error GoTo errhand
    
    StrTabName = Trim(TabName)
    AutoFieldName = Trim(AutoNumFldName)
    strCondition = IIf(IsNull(Trim(WhereCondition)), "", Trim(WhereCondition))
    StrAlfhaText = UCase(Trim(InitialAutoText))
    Txtlen = Len(StrAlfhaText)
    
    'If strCondition = "" Then
    '    GetAutoNumber = "Please Give BranchCode For Your Auto Number Generation."
    '    Exit Function
    'End If

ConnError = ""

  '*************Forming the sql select query*************
        Set Rstemp = CreateObject("adodb.recordset")
        StrQuery = ""
        StrQuery = "nvl(max(upper(" & AutoFieldName & ")),'')"
         
        Set Objquery = CreateObject("QueryRecordsets.FetchRecordsets")
                      
        If Trim(WhereCondition) <> "" Then
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), StrQuery, WhereCondition)
          Else
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), StrQuery)
        End If
        
        If Rstemp.State = 0 Then
            GetAutoText = Objquery.ConnError
            GetAutoText = Replace(GetAutoText, Chr(10), "")
            GetAutoText = Replace(GetAutoText, Chr(13), "")
            Set Objquery = Nothing
            Exit Function
        End If
            
        '*************Returned a Recordset to the Client Application*************
        
        
        


''''''''' Seting an Auto text ''''''''''''''''''''''''
    StrAutoText = ""
 
    
        If (Rstemp.EOF And Rstemp.BOF) Or IsNull(Rstemp.Fields(0)) Then
            
                StrAutoText = StrAlfhaText
            
        Else
            StrInitialChar = Mid(StrAlfhaText, 1, 1)
            StrAlfhaText = UCase(Trim(Rstemp.Fields(0).Value))
            
         
            
            For ICount = Txtlen To 1 Step -1
                If Asc(Mid(StrAlfhaText, ICount, 1)) < Asc("Z") Then
                    StrAutoText = Mid(StrAlfhaText, 1, (ICount - 1)) _
                    & Chr((Asc(Mid(StrAlfhaText, (ICount), 1)) + 1))
                        If Len(StrAutoText) < Txtlen Then
                            
                                For Zcount = 1 To (Txtlen - Len(StrAutoText))
                                     StrAutoText = StrAutoText & StrInitialChar
                                Next
                        End If
                    Exit For
                 End If
            Next
        End If
    
    GetAutoText = StrAutoText
    Exit Function
    
    
    
    
    
    

'''  If strAutoText = "" Or strAutoText = "0" Then
'''        GetAutoText = "AAAAA"
'''  ElseIf Asc(Mid(strAutoText, 5)) < Asc("Z") Then
'''        GetAutoText = Mid(strAutoText, 1, 4) _
'''         & Chr((Asc(Mid(strAutoText, 5)) + 1))
'''  ElseIf Asc(Mid(strAutoText, 4, 1)) < Asc("Z") Then
'''      GetAutoText = Mid(strAutoText, 1, 3) _
'''         & Chr((Asc(Mid(strAutoText, 4, 1)) + 1)) & "A"
'''  ElseIf Asc(Mid(strAutoText, 3, 1)) < Asc("Z") Then
'''      GetAutoText = Mid(strAutoText, 1, 2) _
'''         & Chr((Asc(Mid(strAutoText, 3, 1)) + 1)) & "A" & "A"
'''  ElseIf Asc(Mid(strAutoText, 2, 1)) < Asc("Z") Then
'''      GetAutoText = Mid(strAutoText, 1, 1) _
'''         & Chr((Asc(Mid(strAutoText, 2, 1)) + 1)) & "A" & "A" & "A"
'''  ElseIf Asc(Mid(strAutoText, 1, 1)) < Asc("Z") Then
'''      GetAutoText = Chr(Asc(Mid(strAutoText, 1, 1)) + 1) _
'''                     & "A" & "A" & "A" & "A"
'''  End If
'''
errhand:

'*************RecordSet Not oppened************
    GetAutoText = "Auto Number Could Not Be Generated Due To : " & Objquery.ConnError & Err.Number & " : " & Err.Description
    GetAutoText = Replace(GetAutoText, Chr(10), "")
    GetAutoText = Replace(GetAutoText, Chr(13), "")

End Function




Public Function GetMaxAccountNo(TabName As String, AccFldName As String, _
                                Optional WhereCondition As String, _
                                Optional InitialAutoText As String) As String
                                
Dim StrQuery As String, AutoFieldName As String, StrTabName, strCondition As String
    Dim Objquery As Object
    Dim IntLen As Integer
    Dim strPrevAccno As String
    Dim IntFldLen As Integer
    
    On Error GoTo errhand

    StrTabName = Trim(TabName)
    AutoFieldName = Trim(AccFldName)
    strCondition = Trim(WhereCondition)

    'If strCondition = "" Then
    '    GetMaxAccountNo = "Please Give BranchCode For Your Auto Number Generation."
    '    Exit Function
    'End If

ConnError = ""

  '*************Forming the sql select query*************
        Set Rstemp = CreateObject("adodb.recordset")
        StrQuery = ""
        StrQuery = "accno"
         
        Set Objquery = CreateObject("QueryRecordsets.FetchRecordsets")
                      
        If Trim(WhereCondition) <> "" Then
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), AutoFieldName, WhereCondition, AutoFieldName)
        Else
            Set Rstemp = Objquery.singlerecordset(Trim(StrTabName), AutoFieldName, , AutoFieldName)
        End If
            
        If Rstemp.State = 0 Then
            GetMaxAccountNo = Objquery.ConnError
            GetMaxAccountNo = Replace(GetMaxAccountNo, Chr(10), "")
            GetMaxAccountNo = Replace(GetMaxAccountNo, Chr(13), "")
            Set Objquery = Nothing
            Exit Function
        ElseIf Rstemp.EOF And Rstemp.BOF Then
                If InitialAutoText = "" Then
                    GetMaxAccountNo = 1
                Else
                    GetMaxAccountNo = InitialAutoText
                End If
            Set Objquery = Nothing
            Exit Function
        End If
       
        Rstemp.MoveFirst
        strPrevAccno = Rstemp.Fields(0).Value + 1
        Rstemp.MoveNext
        Do While Not Rstemp.EOF
            If Rstemp.Fields(0).Value = strPrevAccno Then
                strPrevAccno = Rstemp.Fields(0).Value + 1
                Rstemp.MoveNext
            Else
                'strPrevAccno = strPrevAccno - 1
                Exit Do
            End If
            ''''strPrevAccno = strPrevAccno + 1
        Loop
        GetMaxAccountNo = strPrevAccno
        Exit Function
        
errhand:
  GetMaxAccountNo = Err.Number & " : " & Err.Description
  GetMaxAccountNo = Replace(GetMaxAccountNo, Chr(10), "")
  GetMaxAccountNo = Replace(GetMaxAccountNo, Chr(13), "")
End Function
