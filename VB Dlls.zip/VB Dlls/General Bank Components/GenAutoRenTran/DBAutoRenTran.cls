VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "DBAutoRenTran"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'Implements ObjectControl
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim ObjContext As ObjectContext
Dim objTrans As Object
Public ConnError As String 'error string
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim strComponent As String
Dim objQuery As Object
Dim objAuto As Object
Dim BrCode As String
Dim MachID As String
Dim Userid As String
Dim AppDate As String
Dim arrerr As Variant
Dim errobj As Object
Dim objErrlog As Object
Dim blnLogErrors As Boolean
Dim RstempSin As ADODB.Recordset
Dim objdblink As Object
Dim objError As Object
Dim ICount As Integer
Dim DataLink As String
Dim strstack As String
Dim ArrLink As Variant
Dim StrCondition As String
Dim clntDesc As String
Dim ArrError As Variant
Dim ErrNum As String
Dim errDesc As String
Public Function SingleRecordSetNew(TabName As String, FldNames As String, _
                                Optional wherecondition As String, _
                                Optional OrderClause As String, _
                                Optional BranchCode As String, Optional UserCode As String, _
                                Optional MachineID As String, Optional CompName As String) As ADODB.Recordset

Dim strquery As String, strTables As String
Dim TableNames As Variant, TableAlias As Variant
Dim BrCode As String, Userid As String, MachID As String
Dim subCnt As Integer
Dim SubQryTabName As Variant
Dim tabSubQry As Variant

'************Oppening the connection to dblink*************


On Error GoTo errhand


ConnError = ""


Call DBConnection

If ConnError <> "Connected" Then GoTo errhand

'''*************Connection oppened Sucessfully*************

'''*************Forming the sql select query*************
BrCode = IIf(IsNull(Trim(BranchCode)), "", UCase(Trim(BranchCode)))
Userid = IIf(IsNull(Trim(UserCode)), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(Trim(MachineID)), "", UCase(Trim(MachineID)))
strComponent = IIf(IsNull(Trim(CompName)), "", UCase(Trim(CompName)))
'StrCondition = IIf(IsNull(trm(WhereCondition)), "", Trim(WhereCondition))
TableNames = Split(TabName, ",", -1)
If UBound(TableNames) < 1 Then
strTables = Trim(TableNames(0)) & DataLink & " "
Else
strTables = ""
For ICount = 0 To UBound(TableNames)
TableAlias = Split(Trim(TableNames(ICount)), " ", -1)
strTables = strTables & Trim(TableAlias(0)) & DataLink & " " & Trim(TableAlias(1)) & ","

Next

strTables = Left(strTables, Len(strTables) - 1)
End If
StrCondition = ""
''''' Cheking for Sub query to concantinate the tablename with dblink
If Trim(wherecondition) <> "" Then
SubQryTabName = Split(UCase(wherecondition), UCase(" from "), -1)
    If UBound(SubQryTabName) > 0 And Trim(DataLink) <> "" Then
        StrCondition = Trim(SubQryTabName(0)) & " from "
        For subCnt = 1 To UBound(SubQryTabName)
            tabSubQry = Split(UCase(SubQryTabName(subCnt)), " WHERE ", -1)
            StrCondition = StrCondition & Trim(tabSubQry(0)) & DataLink & " where " & tabSubQry(1) & " "
            subCnt = subCnt + 1
            If subCnt <= UBound(SubQryTabName) Then
                tabSubQry = Split(UCase(SubQryTabName(subCnt)), " WHERE ", -1)
                StrCondition = StrCondition & Trim(tabSubQry(0)) & DataLink & " where " & tabSubQry(1) & " "
            End If
        Next
    Else
        StrCondition = wherecondition
    End If
End If


          strquery = ""
          If Trim(wherecondition) <> "" And Trim(OrderClause) <> "" Then
            
            strquery = "Select " & FldNames & " from  " & strTables _
                     & " where " & StrCondition & " order by " & OrderClause
                     
          ElseIf Trim(OrderClause) <> "" And Trim(wherecondition) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                      & " order by " & OrderClause
                      
          ElseIf Trim(wherecondition) <> "" And Trim(OrderClause) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                      & " where " & StrCondition
           
                      
          ElseIf Trim(wherecondition) = "" And Trim(OrderClause) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                    
          End If
          
                 
'''*************Opening the Recordset.*************
  
          Set RstempSin = AdoConnObj.Execute(strquery)
'''''''''''Closing the connection if only for querying, but for modification the _
'''''''''''connetion is in open status.
          If UCase(Trim(Right(strquery, 10))) <> "FOR UPDATE" Then
''            If AdoConnObj.State = 1 Then AdoConnObj.Close
''            Set AdoConnObj = Nothing
          End If
          ''RstempSin.ActiveConnection = False
          
          
        If RstempSin.State = 1 Then
            Set SingleRecordSetNew = RstempSin
           
           '*************Returned a Recordset to the Client Application*************
        Else
            ConnError = "Records Could Not Be Retrieved For your Query"
           
        End If

        RstempSin.ActiveConnection = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
        
        Exit Function
            
errhand:
strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

objErrlog.LogError "GenAutoRenTran", "SingleRecordSetNew", Err.Number, Err.Description & " Stack: " & strstack & "  SQL Query: " & strquery
''If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

If ConnError <> "Connected" Then

'*************Connection Failed************
    If Err.Number = 0 Then
        '''''ConnError = "Connection Failed !"
        ConnError = ConnError
    Else
        ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description & " : " & strTables
    End If
Else
        If strComponent = "" Then
        strComponent = "GenAutoRenTran.DBAutoRenTran / SINGLERECORDDSETNEW"
        End If
        
        If Err.Number = -2147467259 Then
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Oracle Error"
        ElseIf UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Oracle Error"
            
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Client Error " & Err.Description
        End If
    clntDesc = "Records Could Not Be Retrieved Due to " & errDesc & " : " & strTables
    Set objError = CreateObject("TrapError.ErrorDescription")
    If errDesc = "" Then
    errDesc = "abc"
    End If
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc & " : Stack : " & Replace(strstack, "'", "''") & " SQL Query :  " & Replace(strquery, "'", "''"), strComponent, BrCode, Userid, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
     ReDim ArrError(0, 2)
        ConnError = ArrError(0, 2) & " : " & strTables
  
End If

End Function


Public Function MultipleTransactions(TransDataString As String) As String
Dim ArrString As Variant
Dim Arrtrans As Variant
Dim ArrTabName As Variant
Dim ArrFldname As Variant
Dim ArrCondition As Variant
Dim ArrTabValues As Variant
Dim ArrRowValues As Variant
Dim StrFld As String, StrTabName As String, StrValueName As String
Dim RecString As String, StrInsert As String
Dim transcount As Integer, TabCount As Integer, TabFldsCount As Integer, FldValueCount As Integer
Dim TransResult As String
On Error GoTo errhand
Set ObjContext = GetObjectContext
ArrString = Split(TransDataString, "|", -1)
Arrtrans = Split(ArrString(0), ",", -1)
ArrTabName = Split(ArrString(1), ",", -1)
ArrFldname = Split(ArrString(2), "~", -1)
ArrTabValues = Split(ArrString(3), "~", -1)
ArrCondition = Split(ArrString(4), "~", -1)
Set objTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")

For transcount = 0 To UBound(Arrtrans)
 
    If UCase(Trim(Arrtrans(transcount))) = "I" Then        'Insert
        
            StrTabName = ArrTabName(transcount)
            StrFld = ArrFldname(transcount)
            ArrRowValues = Split(ArrTabValues(transcount), "^", -1)
            TransResult = objTrans.InsertRecord(StrTabName, StrFld, ArrRowValues)
            
        
    ElseIf UCase(Trim(Arrtrans(transcount))) = "U" Then        'Update
        
        
    End If
    
If Trim(TransResult) <> "Trans Completed" Then GoTo errhand
 
Next transcount


ObjContext.SetComplete
Set objTrans = Nothing
Set ObjContext = Nothing
MultipleTransactions = "Transaction Sucessful."
Exit Function
 
errhand:
ObjContext.SetAbort
Set objTrans = Nothing
Set ObjContext = Nothing
If Trim(TransResult) <> "" Then
'*************Connection Failed************
    MultipleTransactions = TransResult
    MultipleTransactions = Replace(MultipleTransactions, Chr(10), "")
    MultipleTransactions = Replace(MultipleTransactions, Chr(13), "")
 Else
    MultipleTransactions = Err.Number & " : " & Err.Description
    MultipleTransactions = Replace(MultipleTransactions, Chr(10), "")
    MultipleTransactions = Replace(MultipleTransactions, Chr(13), "")
 End If
End Function


''''' Executing the DML Operations based on the mode of transaction as given as parameter
''''' in a single service(single context) to the database.


Public Function DataTransactions(TransDataArray As Variant, _
                                 Optional BranchCode As String, _
                                 Optional UserCode As String, _
                                 Optional MachineID As String, _
                                 Optional ApplicationDate As String, _
                                 Optional DayBeginEndStatusCheckYN As String, _
                                 Optional glcode As String, _
                                 Optional moduleid As String _
                                 ) As String 'glcode parameter added
                                 
Dim DataArray As Variant
Dim ArrRowValues As Variant
Dim ArrRowValuesinit As Variant
Dim TabFldValues As String
Dim StrFld As String, StrTabName As String, TabWhereCondition As String
Dim transcount As Integer
Dim TransResult As String
Dim TransResult2 As String
Dim AutoCondition As String
Dim AutoConditioninit As String
Dim Autoflds As String
Dim Autofldsinit As String
Dim AutoNumValue As String
Dim AutoNumValueinit As String
Dim AccNoPrefix As String, AccNoSuffix As String
Dim ActualAccNo As String, AutoFldNames As String
Dim AutoType As Variant
Dim AutoPmt As Variant
Dim AutoPmtCond As String
Dim RsBankPmt As ADODB.Recordset
Dim Rsnfts As ADODB.Recordset ''vinod
Dim strnfts As String ''vinod
Dim RowCnt As Integer
Dim RsAutoPmt As ADODB.Recordset
Dim Rstemp  As ADODB.Recordset
Dim startDate As String
Dim InitialiseDate As String
Dim InitialValue As String
Dim ObjDate As Object
Dim strDateRes As String
Dim intaccnolen As Integer  ''VINOD

On Error GoTo errhand


Set ObjContext = GetObjectContext
DataArray = TransDataArray
BrCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
Userid = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(AppDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
glcode = IIf(IsNull(UCase(Trim(glcode))), "", UCase(Trim(glcode)))
moduleid = IIf(IsNull(UCase(Trim(moduleid))), "", UCase(Trim(moduleid)))
Set objQuery = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")
Set objTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")

Set Rstemp = CreateObject("ADODB.Recordset")
Set Rsnfts = CreateObject("adodb.recordset")

Autoflds = ""
AutoNumValue = ""
AutoNumValueinit = ""
'AutoConditioninit = ""
AutoFldNames = "": AccNoPrefix = "": AccNoSuffix = "": ActualAccNo = ""



   For transcount = 0 To UBound(DataArray)

''''************* for Auto number generation********************
    If DataArray(transcount, 0) = "A" Then
    Set RsAutoPmt = CreateObject("ADODB.Recordset")
        AutoType = Split(DataArray(transcount, 1), "|", -1)
        'AutoPmt = Split(AutoType(1), ",", -1)
    '''''**** Aquireing all the parameters for Auto number generation from GENAUTONUMBERPMT table
        AutoPmtCond = AutoType(1)
        Set RsAutoPmt = SingleRecordSetNew("GENAUTONUMBERPMT", "*", AutoPmtCond)
       ''''' MsgBox objQuery.ConnError
        If RsAutoPmt.EOF And RsAutoPmt.BOF Then
            ObjContext.SetAbort
            Set objQuery = Nothing
            Set ObjContext = Nothing
            Set objTrans = Nothing
            DataTransactions = "Parameters for the AccountNo to be specified"
            Exit Function
        End If
        InitialValue = ""
        strDateRes = ""

            AutoCondition = DataArray(transcount, 4) & " FOR UPDATE"
            Set Rstemp = SingleRecordSetNew("GENAUTONUMMAX", "*", AutoCondition)
                If Not Rstemp.EOF And Not Rstemp.BOF Then
                    AutoNumValueinit = Rstemp!MAXAUTONUM
                    AutoConditioninit = DataArray(transcount, 4)
                End If
            
            TransResult = ""
            AutoCondition = DataArray(transcount, 4)
            Set objAuto = CreateObject("AutoNumber.Generation")
            If UCase(Trim(AutoType(0))) = "GETAUTONUMBER" Then
                
                AutoNumValue = objAuto.GetAutoNumber("GENAUTONUMMAX", "MAXAUTONUM", AutoCondition, CStr(RsAutoPmt!InitialValue))
            ElseIf UCase(Trim(AutoType(0))) = "GETAUTOTEXT" Then
                AutoNumValue = objAuto.GETAUTOTEXT("GENAUTONUMMAX", "MAXAUTONUM", RsAutoPmt!InitialValue, AutoCondition)
            ElseIf UCase(Trim(AutoType(0))) = "GETMAXACCOUNTNO" Then
                AutoNumValue = objAuto.GETMAXACCOUNTNO("GENAUTONUMMAX", "MAXAUTONUM", AutoCondition, RsAutoPmt!InitialValue)
            End If

                If Mid(AutoNumValue, 1, 5) = "ERROR" Then
                    Set objQuery = Nothing
                    Set ObjContext = Nothing
                    Set objTrans = Nothing
                    AutoNumValue = Replace(AutoNumValue, Chr(10), "")
                    AutoNumValue = Replace(AutoNumValue, Chr(13), "")
                    DataTransactions = AutoNumValue
                    Exit Function
                End If
            Set objAuto = Nothing
            ReDim ArrRowValues(0) As Variant
            ReDim ArrRowValuesinit(0) As Variant
       ' If ((AutoNumValue = CStr(RsAutoPmt!InitialValue)) Or (AutoNumValue = Val(Rstemp!maxautonum) + 1)) Then
            If AutoNumValue = CStr(RsAutoPmt!InitialValue) Then
               

                Autoflds = DataArray(transcount, 2) & ",MAXAUTONUM"
                ArrRowValues(0) = DataArray(transcount, 3) & "," & AutoNumValue
                TransResult = ""
                Set ObjContext = GetObjectContext
                TransResult = objTrans.InsertRecord("GENAUTONUMMAX", Autoflds, ArrRowValues, BrCode, Userid, MachID, AppDate, "N")
                If TransResult <> "Trans Completed" Then
                    ObjContext.SetAbort
                    Set objQuery = Nothing
                    Set ObjContext = Nothing
                    Set objTrans = Nothing
                    TransResult = Replace(TransResult, Chr(10), "")
                    TransResult = Replace(TransResult, Chr(13), "")
                    DataTransactions = TransResult
                    Exit Function
                End If
        Else
                ArrRowValues(0) = AutoNumValue
                
                Autoflds = "MAXAUTONUM"
                AutoCondition = DataArray(transcount, 4)
                
                TransResult = objQuery.ModifyQueriedTrans("GENAUTONUMMAX", Autoflds, _
                                ArrRowValues, AutoCondition, BrCode, Userid, MachID)
        'Set objQuery = Nothing
            If TransResult <> "Trans Completed" Then
                ObjContext.SetAbort
                Set ObjContext = Nothing
                TransResult = Replace(TransResult, Chr(10), "")
                TransResult = Replace(TransResult, Chr(13), "")
                DataTransactions = TransResult
                Exit Function
            End If
        End If
            
            Set Rsnfts = SingleRecordSetNew("genbankparm", "NFTSCONVYN", "")
            
            If Not Rsnfts.EOF And Not Rsnfts.BOF Then
            
            If Rsnfts!NFTSCONVYN = "Y" Then  ' nfts conversion 16 digits
            
            If moduleid = "SB" Or moduleid = "CA" Or moduleid = "CC" Or moduleid = "DEP" Or moduleid = "LOAN" Or _
            moduleid = "LOCKER" Or moduleid = "SHARES" Then
           
            intaccnolen = Len(AutoNumValue) ''vinod
                If intaccnolen = 16 Then
                    AutoNumValue = AutoNumValue
                Else
                    If intaccnolen = 1 Then
                    AutoNumValue = "000000" & AutoNumValue
                    ElseIf intaccnolen = 2 Then
                    AutoNumValue = "00000" & AutoNumValue
                    ElseIf intaccnolen = 3 Then
                    AutoNumValue = "0000" & AutoNumValue
                    ElseIf intaccnolen = 4 Then
                    AutoNumValue = "000" & AutoNumValue
                    ElseIf intaccnolen = 5 Then
                    AutoNumValue = "00" & AutoNumValue
                    ElseIf intaccnolen = 6 Then
                    AutoNumValue = "0" & AutoNumValue
                    ElseIf intaccnolen = 7 Then
                    AutoNumValue = AutoNumValue
                    End If
                    AutoNumValue = BrCode & glcode & AutoNumValue
                End If
             End If
           End If 'MODULE ID END
           End If ' NFTS CONV END
           
        AccNoPrefix = Trim(RsAutoPmt!Prefixvalue) & ""
        AccNoSuffix = Trim(RsAutoPmt!suffixvalue) & ""
        ActualAccNo = (AutoNumValue)
        AutoNumValue = Trim(RsAutoPmt!Prefixvalue) & AutoNumValue & Trim(RsAutoPmt!suffixvalue)
     
     End If

    Next

 
'*************Transaction Started***************
For transcount = 0 To UBound(DataArray)
 StrTabName = DataArray(transcount, 1)
 StrFld = DataArray(transcount, 2)
 TabFldValues = DataArray(transcount, 3)
 ArrRowValues = Split(TabFldValues, "|", -1)
    
 TabWhereCondition = DataArray(transcount, 4)
    
    If UCase(Trim(DataArray(transcount, 0))) = "I" Then
        '''************For Insert****************
        If Trim(Autoflds) <> "" Then
            'StrFld = StrFld & "," & Autoflds
            AutoFldNames = ""
            StrTabName = UCase(Trim(StrTabName))
            
            If StrTabName = "SBMST" Or StrTabName = "CAMST" Or StrTabName = "LOANMST" Or _
            StrTabName = "DEPMST" Or StrTabName = "LGMST" Or StrTabName = "LOCKERMST" Or _
            StrTabName = "FXLGMST" Or StrTabName = "FXBILLSMST" Or _
            StrTabName = "FXDEPMST" Or StrTabName = "CCMST" Or StrTabName = "LCMST" Or _
            StrTabName = "FXLOANSMST" Or StrTabName = "FXLCMST" Or StrTabName = "FXFCMST" Then
            
                AutoFldNames = ",PREFIXVALUE, SUFFIXVALUE, ActualAccNo"
                StrFld = StrFld & AutoFldNames
                
            End If
            
            For RowCnt = 0 To UBound(ArrRowValues)
               ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & ",'" & AutoNumValue & "'"
               
               If AutoFldNames <> "" Then
                    ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & _
                        ",'" & AccNoPrefix & "','" & AccNoSuffix & "','" & ActualAccNo & "'"
               End If
               
            Next RowCnt
        End If
        TransResult = ""
        TransResult = objTrans.InsertRecord(StrTabName, StrFld, ArrRowValues, BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "BI" Then
    
        '''************For Bulk Insertion****************
        TransResult = ""
        TransResult = objTrans.BulkInsert(StrTabName, StrFld, CStr(DataArray(transcount, 3)), _
        BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "U" Then
    
        '''************For Update****************
        If Trim(Autoflds) <> "" Then
            'StrFld = StrFld & "," & Autoflds
            For RowCnt = 0 To UBound(ArrRowValues)
               ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & "~'" & AutoNumValue & "'"
            Next RowCnt
        End If
        TransResult = objTrans.UpdateRecord(StrTabName, StrFld, ArrRowValues, TabWhereCondition, BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "D" Then
        '''************For Delete****************
        TransResult = objTrans.DeleteRecord(StrTabName, TabWhereCondition, BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
   
   ElseIf UCase(Trim(DataArray(transcount, 0))) = "R" Then
        '''************For Rejection****************
        TransResult = objTrans.RejectRecord(StrTabName, TabWhereCondition, BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
        
   ElseIf UCase(Trim(DataArray(transcount, 0))) = "SI" Then
        '''************For Insertion using a Select statement ****************
        TransResult = objTrans.InsertUsingSelect(StrTabName, StrFld, ArrRowValues, TabWhereCondition, BrCode, Userid, MachID, AppDate, DayBeginEndStatusCheckYN)
        
   End If
    
 'TransResult = "trans1"
 If Trim(TransResult) <> "Trans Completed" Then GoTo errhand
 
Next transcount


ObjContext.SetComplete
Set objTrans = Nothing
Set ObjContext = Nothing
Set objQuery = Nothing
    If AutoNumValue <> "" Then
        DataTransactions = "Transaction Sucessful.|" & AutoNumValue
    Else
        DataTransactions = "Transaction Sucessful."
    End If
    
Exit Function
 
errhand:

If blnLogErrors = True Then objErrlog.LogError "GenAutoRenTran", "DBAutoRenTran", Err.Number, Err.Description

If AutoNumValueinit <> "" Then
ArrRowValuesinit(0) = AutoNumValueinit
                Autofldsinit = "MAXAUTONUM"
                TransResult2 = objQuery.ModifyQueriedTrans("GENAUTONUMMAX", Autofldsinit, _
                                ArrRowValuesinit, AutoConditioninit, BrCode, Userid, MachID)
End If

ObjContext.SetAbort
Set objTrans = Nothing
Set ObjContext = Nothing
Set objQuery = Nothing
                                
If Trim(TransResult) <> "" Then

'*************Connection Failed************
    TransResult = Replace(TransResult, Chr(10), "")
    TransResult = Replace(TransResult, Chr(13), "")
    DataTransactions = TransResult
 Else
DataTransactions = Err.Number & Err.Description
DataTransactions = Replace(DataTransactions, Chr(10), "")
DataTransactions = Replace(DataTransactions, Chr(13), "")
End If

End Function


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String

strSupreUserPassword = "RamSmart2020"
strUserid = "v3"
strDataSource = "v3"
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
    
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:
strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserid = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "QueryRecordsets", "DBConnection" & strLineno, Err.Number, Err.Description & " : Stack : " & strstack

   
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objErrlog.ErrorProcess(ErrNum, errDesc, " : Stack : " & Replace(strstack, "'", "''"), strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Set objError = Nothing

End Sub


Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
blnLogErrors = True
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub

