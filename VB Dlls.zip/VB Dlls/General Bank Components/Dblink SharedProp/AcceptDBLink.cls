VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "AcceptDBLink"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

Dim spmMGR As SharedPropertyGroupManager
Dim spmPropGroup As SharedPropertyGroup
Dim spmPropDBLink As SharedProperty
'Dim spm As COMSVCSlib.SharedPropertyGroup
''Dim UserName As String
''Dim PassWRD As String
''Dim DataSource As String
Dim BooleanLink As Boolean

Public Function ChangeDBLink(Optional NewUser As String, Optional NewPassWrd As String, _
                             Optional NewSID As String, Optional Newlink As String) As String

Dim strUser As String
Dim strPassWord As String
Dim strSID As String
Dim strDblink As String
'''Dim strNewUser As String
'''Dim strNewPassWord As String
'''Dim strNewSID As String
'''Dim strNewDblink As String
Dim strResult As String

On Error GoTo Errhand
strResult = ""
'''''' sharing the dblink with the caller component
If NewUser = "" Then
    Set spmMGR = New SharedPropertyGroupManager
    Set spmPropGroup = spmMGR.Group("LinkGroup")
    Set spmPropDBLink = spmPropGroup.Property("DBLinkProp")
    
        If spmPropDBLink.Value = 0 Then
            ChangeDBLink = "Please Enter DBLink"
            Exit Function
        End If
        
    
Else



''''' creating a new DBlink
    strUser = UCase(Trim(NewUser))
    strPassWord = Trim(NewPassWrd)
    strSID = Trim(NewSID)
    strDblink = IIf(IsNull(Trim(Newlink)), "", Trim(Newlink))
    
    strResult = DbConnection(strUser, strPassWord, strSID, strDblink)
    If strResult <> "Connected" Then GoTo Errhand
 
    
    Set spmMGR = New SharedPropertyGroupManager
    Set spmPropGroup = spmMGR.CreatePropertyGroup("LinkGroup", LockMethod, Process, BooleanLink)
    Set spmPropDBLink = spmPropGroup.CreateProperty("DBLinkProp", BooleanLink)
    If strDblink <> "" Then
        spmPropDBLink.Value = strUser & "," & strPassWord & "," & strSID & ",@" & Trim(strDblink)
    Else
        spmPropDBLink.Value = strUser & "," & strPassWord & "," & strSID
    End If
End If

ChangeDBLink = spmPropDBLink.Value
Exit Function

Errhand:

    If strResult <> "" Then
        ChangeDBLink = strResult
    Else
        ChangeDBLink = Err.Number & " : " & Err.Description
    End If
    
End Function

Public Function GetDBLink() As String
'Set spmPropDBLink = spmPropGroup.Property("DBLinkProp")
GetDBLink = ChangeDBLink
End Function

Private Function DbConnection(UserName As String, PassWRD As String, SID As String, DBLink As String) As String
Dim AdoConnObj As ADODB.Connection
Dim RsCheck As ADODB.Recordset
On Error GoTo Errhand

Set AdoConnObj = CreateObject("Adodb.Connection")

''''' checking the connection

AdoConnObj.CursorLocation = adUseClient


'AdoConnObj.Open "Provider=MSDAORA.1;data source=" & Trim(SID) & ";Password=" & Trim(PassWRD) _
                    & ";User ID=" & Trim(UserName)
AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=v3;User ID=v3"

If AdoConnObj.State = 1 Then DbConnection = "Connected"
If Trim(DBLink) <> "" Then
Set RsCheck = CreateObject("ADODB.Recordset")
''''checking the dblink
Set RsCheck = AdoConnObj.Execute("select * from tab@" & Trim(DBLink))
If RsCheck.State <> 1 Then GoTo Errhand
End If
Exit Function


Errhand:

DbConnection = "Invalid UserName Or PassWord Or Dblink"

End Function
