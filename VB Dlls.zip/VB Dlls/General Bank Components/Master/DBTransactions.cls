VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "DBTransactions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'Implements ObjectControl
Option Explicit
Dim ObjContext As ObjectContext
Dim ObjTrans As Object
Dim objQuery As Object
Dim objAuto As Object
Dim BRCode As String
Dim MachID As String
Dim UserId As String
Dim AppDate As String
Dim arrerr As Variant
Dim errobj As Object
Public Function MultipleTransactions(TransDataString As String) As String
Dim ArrString As Variant
Dim Arrtrans As Variant
Dim ArrTabName As Variant
Dim ArrFldname As Variant
Dim ArrCondition As Variant
Dim ArrTabValues As Variant
Dim ArrRowValues As Variant
Dim StrFld As String, StrTabName As String, StrValueName As String
Dim RecString As String, StrInsert As String
Dim transcount As Integer, TabCount As Integer, TabFldsCount As Integer, FldValueCount As Integer
Dim TransResult As String
On Error GoTo ErrHand
Set ObjContext = GetObjectContext
ArrString = Split(TransDataString, "|", -1)
Arrtrans = Split(ArrString(0), ",", -1)
ArrTabName = Split(ArrString(1), ",", -1)
ArrFldname = Split(ArrString(2), "~", -1)
ArrTabValues = Split(ArrString(3), "~", -1)
ArrCondition = Split(ArrString(4), "~", -1)
Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")

For transcount = 0 To UBound(Arrtrans)
 
    If UCase(Trim(Arrtrans(transcount))) = "I" Then        'Insert
        
            StrTabName = ArrTabName(transcount)
            StrFld = ArrFldname(transcount)
            ArrRowValues = Split(ArrTabValues(transcount), "^", -1)
            TransResult = ObjTrans.InsertRecord(StrTabName, StrFld, ArrRowValues)
            
        
    ElseIf UCase(Trim(Arrtrans(transcount))) = "U" Then        'Update
        
        
    End If
    
If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
 
Next transcount


ObjContext.SetComplete
Set ObjTrans = Nothing
Set ObjContext = Nothing
MultipleTransactions = "Transaction Sucessful."
Exit Function
 
ErrHand:
ObjContext.SetAbort
Set ObjTrans = Nothing
Set ObjContext = Nothing
If Trim(TransResult) <> "" Then
'*************Connection Failed************
    MultipleTransactions = TransResult
    MultipleTransactions = Replace(MultipleTransactions, Chr(10), "")
    MultipleTransactions = Replace(MultipleTransactions, Chr(13), "")
 Else
    MultipleTransactions = Err.Number & " : " & Err.Description
    MultipleTransactions = Replace(MultipleTransactions, Chr(10), "")
    MultipleTransactions = Replace(MultipleTransactions, Chr(13), "")
 End If
End Function


''''' Executing the DML Operations based on the mode of transaction as given as parameter
''''' in a single service(single context) to the database.


Public Function DataTransactions(TransDataArray As Variant, _
                                 Optional BranchCode As String, _
                                 Optional UserCode As String, _
                                 Optional MachineID As String, _
                                 Optional ApplicationDate As String, _
                                 Optional DayBeginEndStatusCheckYN As String, _
                                 Optional glcode As String, _
                                 Optional moduleid As String _
                                 ) As String 'glcode parameter added
                                 
Dim DataArray As Variant
Dim ArrRowValues As Variant
Dim ArrRowValuesinit As Variant
Dim TabFldValues As String
Dim StrFld As String, StrTabName As String, TabWhereCondition As String
Dim transcount As Integer
Dim TransResult As String
Dim TransResult2 As String
Dim AutoCondition As String
Dim AutoConditioninit As String
Dim Autoflds As String
Dim Autofldsinit As String
Dim AutoNumValue As String
Dim AutoNumValueinit As String
Dim AccNoPrefix As String, AccNoSuffix As String
Dim ActualAccNo As String, AutoFldNames As String
Dim AutoType As Variant
Dim AutoPmt As Variant
Dim AutoPmtCond As String
Dim RsBankPmt As ADODB.Recordset
Dim Rsnfts As ADODB.Recordset ''vinod
Dim strnfts As String ''vinod
Dim RowCnt As Integer
Dim RsAutoPmt As ADODB.Recordset
Dim Rstemp  As ADODB.Recordset
Dim startDate As String
Dim InitialiseDate As String
Dim InitialValue As String
Dim ObjDate As Object
Dim strDateRes As String
Dim intaccnolen As Integer  ''VINOD

On Error GoTo ErrHand


Set ObjContext = GetObjectContext
DataArray = TransDataArray
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(AppDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
glcode = IIf(IsNull(UCase(Trim(glcode))), "", UCase(Trim(glcode)))
moduleid = IIf(IsNull(UCase(Trim(moduleid))), "", UCase(Trim(moduleid)))
Set objQuery = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")
Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")

Set Rstemp = CreateObject("ADODB.Recordset")
Set Rsnfts = CreateObject("adodb.recordset")

Autoflds = ""
AutoNumValue = ""
AutoNumValueinit = ""
'AutoConditioninit = ""
AutoFldNames = "": AccNoPrefix = "": AccNoSuffix = "": ActualAccNo = ""



   For transcount = 0 To UBound(DataArray)

''''************* for Auto number generation********************
    If DataArray(transcount, 0) = "A" Then
    Set RsAutoPmt = CreateObject("ADODB.Recordset")
        AutoType = Split(DataArray(transcount, 1), "|", -1)
        'AutoPmt = Split(AutoType(1), ",", -1)
    '''''**** Aquireing all the parameters for Auto number generation from GENAUTONUMBERPMT table
        AutoPmtCond = AutoType(1)
        Set RsAutoPmt = objQuery.singlerecordset("GENAUTONUMBERPMT", "*", AutoPmtCond)
       ''''' MsgBox objQuery.ConnError
        If RsAutoPmt.EOF And RsAutoPmt.BOF Then
            ObjContext.SetAbort
            Set objQuery = Nothing
            Set ObjContext = Nothing
            Set ObjTrans = Nothing
            DataTransactions = "Parameters for the AccountNo to be specified"
            Exit Function
        End If
        InitialValue = ""
        strDateRes = ""

            AutoCondition = DataArray(transcount, 4) & " FOR UPDATE"
            Set Rstemp = objQuery.singlerecordset("GENAUTONUMMAX", "*", AutoCondition)
                If Not Rstemp.EOF And Not Rstemp.BOF Then
                    AutoNumValueinit = Rstemp!MAXAUTONUM
                    AutoConditioninit = DataArray(transcount, 4)
                End If
            TransResult = ""
            AutoCondition = DataArray(transcount, 4)
            Set objAuto = CreateObject("AutoNumber.Generation")
            If UCase(Trim(AutoType(0))) = "GETAUTONUMBER" Then
                
                AutoNumValue = objAuto.GetAutoNumber("GENAUTONUMMAX", "MAXAUTONUM", AutoCondition, CStr(RsAutoPmt!InitialValue))
            ElseIf UCase(Trim(AutoType(0))) = "GETAUTOTEXT" Then
                AutoNumValue = objAuto.GETAUTOTEXT("GENAUTONUMMAX", "MAXAUTONUM", RsAutoPmt!InitialValue, AutoCondition)
            ElseIf UCase(Trim(AutoType(0))) = "GETMAXACCOUNTNO" Then
                AutoNumValue = objAuto.GETMAXACCOUNTNO("GENAUTONUMMAX", "MAXAUTONUM", AutoCondition, RsAutoPmt!InitialValue)
            End If

                If Mid(AutoNumValue, 1, 5) = "ERROR" Then
                    Set objQuery = Nothing
                    Set ObjContext = Nothing
                    Set ObjTrans = Nothing
                    AutoNumValue = Replace(AutoNumValue, Chr(10), "")
                    AutoNumValue = Replace(AutoNumValue, Chr(13), "")
                    DataTransactions = AutoNumValue
                    Exit Function
                End If
            Set objAuto = Nothing
            ReDim ArrRowValues(0) As Variant
            ReDim ArrRowValuesinit(0) As Variant
       ' If ((AutoNumValue = CStr(RsAutoPmt!InitialValue)) Or (AutoNumValue = Val(Rstemp!maxautonum) + 1)) Then
            If AutoNumValue = CStr(RsAutoPmt!InitialValue) Then
               

                Autoflds = DataArray(transcount, 2) & ",MAXAUTONUM"
                ArrRowValues(0) = DataArray(transcount, 3) & "," & AutoNumValue
                TransResult = ""
                Set ObjContext = GetObjectContext
                TransResult = ObjTrans.InsertRecord("GENAUTONUMMAX", Autoflds, ArrRowValues, BRCode, UserId, MachID, AppDate, "N")
                If TransResult <> "Trans Completed" Then
                    ObjContext.SetAbort
                    Set objQuery = Nothing
                    Set ObjContext = Nothing
                    Set ObjTrans = Nothing
                    TransResult = Replace(TransResult, Chr(10), "")
                    TransResult = Replace(TransResult, Chr(13), "")
                    DataTransactions = TransResult
                    Exit Function
                End If
        Else
                ArrRowValues(0) = AutoNumValue
                
                Autoflds = "MAXAUTONUM"
                AutoCondition = DataArray(transcount, 4)
                
                TransResult = objQuery.ModifyQueriedTrans("GENAUTONUMMAX", Autoflds, _
                                ArrRowValues, AutoCondition, BRCode, UserId, MachID)
        'Set objQuery = Nothing
            If TransResult <> "Trans Completed" Then
                ObjContext.SetAbort
                Set ObjContext = Nothing
                TransResult = Replace(TransResult, Chr(10), "")
                TransResult = Replace(TransResult, Chr(13), "")
                DataTransactions = TransResult
                Exit Function
            End If
        End If
            
            Set Rsnfts = objQuery.singlerecordset("genbankparm", "NFTSCONVYN", "")
            
            If Not Rsnfts.EOF And Not Rsnfts.BOF Then
            
            If Rsnfts!NFTSCONVYN = "Y" Then  ' nfts conversion 16 digits
            
            If moduleid = "SB" Or moduleid = "CA" Or moduleid = "CC" Or moduleid = "DEP" Or moduleid = "LOAN" Or _
            moduleid = "LOCKER" Or moduleid = "SHARES" Then
           
            intaccnolen = Len(AutoNumValue) ''vinod
                If intaccnolen = 16 Then
                    AutoNumValue = AutoNumValue
                Else
                    If intaccnolen = 1 Then
                    AutoNumValue = "000000" & AutoNumValue
                    ElseIf intaccnolen = 2 Then
                    AutoNumValue = "00000" & AutoNumValue
                    ElseIf intaccnolen = 3 Then
                    AutoNumValue = "0000" & AutoNumValue
                    ElseIf intaccnolen = 4 Then
                    AutoNumValue = "000" & AutoNumValue
                    ElseIf intaccnolen = 5 Then
                    AutoNumValue = "00" & AutoNumValue
                    ElseIf intaccnolen = 6 Then
                    AutoNumValue = "0" & AutoNumValue
                    ElseIf intaccnolen = 7 Then
                    AutoNumValue = AutoNumValue
                    End If
                    AutoNumValue = BRCode & glcode & AutoNumValue
                End If
             End If
           End If 'MODULE ID END
           End If ' NFTS CONV END
           
        AccNoPrefix = Trim(RsAutoPmt!Prefixvalue) & ""
        AccNoSuffix = Trim(RsAutoPmt!suffixvalue) & ""
        ActualAccNo = (AutoNumValue)
        AutoNumValue = Trim(RsAutoPmt!Prefixvalue) & AutoNumValue & Trim(RsAutoPmt!suffixvalue)
     
     End If

    Next

 
'*************Transaction Started***************
For transcount = 0 To UBound(DataArray)
 StrTabName = DataArray(transcount, 1)
 StrFld = DataArray(transcount, 2)
 TabFldValues = DataArray(transcount, 3)
 ArrRowValues = Split(TabFldValues, "|", -1)
    
 TabWhereCondition = DataArray(transcount, 4)
    
    If UCase(Trim(DataArray(transcount, 0))) = "I" Then
        '''************For Insert****************
        If Trim(Autoflds) <> "" Then
            'StrFld = StrFld & "," & Autoflds
            AutoFldNames = ""
            StrTabName = UCase(Trim(StrTabName))
            
            If StrTabName = "SBMST" Or StrTabName = "CAMST" Or StrTabName = "LOANMST" Or _
            StrTabName = "DEPMST" Or StrTabName = "LGMST" Or StrTabName = "LOCKERMST" Or _
            StrTabName = "FXLGMST" Or StrTabName = "FXBILLSMST" Or _
            StrTabName = "FXDEPMST" Or StrTabName = "CCMST" Or StrTabName = "LCMST" Or _
            StrTabName = "FXLOANSMST" Or StrTabName = "FXLCMST" Or StrTabName = "FXFCMST" Then
            
                AutoFldNames = ",PREFIXVALUE, SUFFIXVALUE, ActualAccNo"
                StrFld = StrFld & AutoFldNames
                
            End If
            
            For RowCnt = 0 To UBound(ArrRowValues)
               ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & ",'" & AutoNumValue & "'"
               
               If AutoFldNames <> "" Then
                    ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & _
                        ",'" & AccNoPrefix & "','" & AccNoSuffix & "','" & ActualAccNo & "'"
               End If
               
            Next RowCnt
        End If
        TransResult = ""
        TransResult = ObjTrans.InsertRecord(StrTabName, StrFld, ArrRowValues, BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "BI" Then
    
        '''************For Bulk Insertion****************
        TransResult = ""
        TransResult = ObjTrans.BulkInsert(StrTabName, StrFld, CStr(DataArray(transcount, 3)), _
        BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "U" Then
    
        '''************For Update****************
        If Trim(Autoflds) <> "" Then
            'StrFld = StrFld & "," & Autoflds
            For RowCnt = 0 To UBound(ArrRowValues)
               ArrRowValues(RowCnt) = ArrRowValues(RowCnt) & "~'" & AutoNumValue & "'"
            Next RowCnt
        End If
        TransResult = ObjTrans.UpdateRecord(StrTabName, StrFld, ArrRowValues, TabWhereCondition, BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
    
    ElseIf UCase(Trim(DataArray(transcount, 0))) = "D" Then
        '''************For Delete****************
        TransResult = ObjTrans.DeleteRecord(StrTabName, TabWhereCondition, BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
   
   ElseIf UCase(Trim(DataArray(transcount, 0))) = "R" Then
        '''************For Rejection****************
        TransResult = ObjTrans.RejectRecord(StrTabName, TabWhereCondition, BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
        
   ElseIf UCase(Trim(DataArray(transcount, 0))) = "SI" Then
        '''************For Insertion using a Select statement ****************
        TransResult = ObjTrans.InsertUsingSelect(StrTabName, StrFld, ArrRowValues, TabWhereCondition, BRCode, UserId, MachID, AppDate, DayBeginEndStatusCheckYN)
        
   End If
    
 'TransResult = "trans1"
 If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
 
Next transcount


ObjContext.SetComplete
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set objQuery = Nothing
    If AutoNumValue <> "" Then
        DataTransactions = "Transaction Sucessful.|" & AutoNumValue
    Else
        DataTransactions = "Transaction Sucessful."
    End If
    
Exit Function
 
ErrHand:

If AutoNumValueinit <> "" Then
ArrRowValuesinit(0) = AutoNumValueinit
                Autofldsinit = "MAXAUTONUM"
                TransResult2 = objQuery.ModifyQueriedTrans("GENAUTONUMMAX", Autofldsinit, _
                                ArrRowValuesinit, AutoConditioninit, BRCode, UserId, MachID)
End If

ObjContext.SetAbort
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set objQuery = Nothing
                                
If Trim(TransResult) <> "" Then

'*************Connection Failed************
    TransResult = Replace(TransResult, Chr(10), "")
    TransResult = Replace(TransResult, Chr(13), "")
    DataTransactions = TransResult
 Else
DataTransactions = Err.Number & Err.Description
DataTransactions = Replace(DataTransactions, Chr(10), "")
DataTransactions = Replace(DataTransactions, Chr(13), "")
End If

End Function

