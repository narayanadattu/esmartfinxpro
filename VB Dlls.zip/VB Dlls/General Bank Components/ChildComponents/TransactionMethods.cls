VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "TransactionMethods"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True

Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim ICount As Long
Dim DataLink As String
Dim RecAffect As Long
Dim BRCode As String
Dim MachID As String
Dim UserId As String
Dim AppDate As String
Dim arrerr As Variant
Dim errobj As Object
Dim BlnHistStatus As Boolean
Dim rsHistCol As ADODB.Recordset
Dim rsHistExt As ADODB.Recordset
Dim strHistExt As String
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Dim objError As Object
Dim ArrError As Variant
Const blnDebug As Boolean = True
Dim objErrlog As Object
Dim blnLogErrors As Boolean


Public Function InsertRecord(TableName As String, FldNames As String, Arrvalues As Variant, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String
Dim ArrTempValues As Variant
Dim StrInsert As String, StrTabName As String, strfields As String, StrArrValues As String


'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection

If ConnError <> "Connected" Then
    InsertRecord = ConnError
    InsertRecord = Replace(InsertRecord, Chr(10), "")
    InsertRecord = Replace(InsertRecord, Chr(13), "")
    Exit Function
End If


  '*************Connection oppened Sucessfully*************
ArrTempValues = Arrvalues
StrTabName = UCase(Trim(TableName)): strfields = FldNames
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
''''''''*************** checking day begin status and day end status.***************
If DayBeginEndStatusCheckYN <> "N" Then
    ConnError = CheckDayBeginDayEndStatus("I", StrTabName, strfields, ArrTempValues)
    
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
'    GoTo ErrHand
'End If
ConnError = "Connected"
''''''''*************** checking day begin status and day end status.***************
For ICount = 0 To UBound(ArrTempValues)
RecAffect = 0
  StrInsert = "insert into " & Trim(StrTabName) & DataLink & " (" & strfields & ") " _
                & " values (" & ArrTempValues(ICount) & ")"
   AdoConnObj.Execute StrInsert, RecAffect
   StrInsert = ""
   
If RecAffect = 0 Then
    InsertRecord = "Insert Failed !"
    If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertRecord", Err.Number, InsertRecord & ": " & StrInsert
    Set AdoConnObj = Nothing
    Exit Function
End If

Next ICount
Set AdoConnObj = Nothing
InsertRecord = "Trans Completed"
Exit Function


 '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertRecord", Err.Number, Err.Description & StrInsert

If ConnError = "" Then

'*************Connection Failed************
    Set AdoConnObj = Nothing
    InsertRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    InsertRecord = Replace(InsertRecord, Chr(10), "")
    InsertRecord = Replace(InsertRecord, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / INSERTRECORD"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "INSCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " " & Err.Description
        End If
    '''clntDesc = "Records Could Not Be Inserted Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        InsertRecord = ArrError(0, 2)
    
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

End Function

Public Function BulkInsert(TableName As String, FldNames As String, sQueryToGetValues As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String
Dim ArrTempValues As Variant
Dim StrInsert As String, StrTabName As String, strfields As String, StrArrValues As String


'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection

If ConnError <> "Connected" Then
BulkInsert = ConnError
BulkInsert = Replace(BulkInsert, Chr(10), "")
BulkInsert = Replace(BulkInsert, Chr(13), "")
Exit Function
End If


  '*************Connection oppened Sucessfully*************
'ArrTempValues = Arrvalues
StrTabName = UCase(Trim(TableName)): strfields = FldNames
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
''''''''*************** checking day begin status and day end status.***************
If DayBeginEndStatusCheckYN <> "N" Then
    'ConnError = CheckDayBeginDayEndStatus("I", StrTabName, strfields, ArrTempValues)
    ConnError = CheckDayBeginDayEndStatus("I", StrTabName, strfields)
    
    If ConnError <> "CONTINUE" Then GoTo errhand
End If

ConnError = "Connected"
''''''''*************** checking day begin status and day end status.***************
RecAffect = 0
'  StrInsert = "insert into " & Trim(StrTabName) & DataLink & " (" & strfields & ") " _
'                & " values (" & ArrTempValues(ICount) & ")"
  If Trim(strfields) = "*" Then
    StrInsert = "insert into " & Trim(StrTabName) & DataLink _
                & " " & sQueryToGetValues
  Else
    StrInsert = "insert into " & Trim(StrTabName) & DataLink & " (" & strfields & ") " _
                & " " & sQueryToGetValues
  End If
   AdoConnObj.Execute StrInsert, RecAffect
   StrInsert = ""
   
'Don't check for no. of rows effected/inserted
'If RecAffect = 0 Then
'    BulkInsert = "Insert Failed !"
'    Set AdoConnObj = Nothing
'    Exit Function
'End If

Set AdoConnObj = Nothing
BulkInsert = "Trans Completed"
Exit Function


 '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant
If ConnError = "" Then

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "BulkInsert", Err.Number, Err.Description

'*************Connection Failed************
    Set AdoConnObj = Nothing
    BulkInsert = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    BulkInsert = Replace(BulkInsert, Chr(10), "")
    BulkInsert = Replace(BulkInsert, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / BulkInsert"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "INSCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Inserted into " & StrTabName & " " & Err.Description
        End If
    '''clntDesc = "Records Could Not Be Inserted Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        BulkInsert = ArrError(0, 2)
    
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

End Function

Public Function UpdateRecord(TableName As String, FldNames As String, _
                             Arrvalues As Variant, Optional WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String

Dim ArrTempValues As Variant, ArrRowValue As Variant, arrflds As Variant, strquery As String
Dim Strupdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, StrCondition As Variant, StrTabName As String, strfields As String
'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then
    UpdateRecord = ConnError
    UpdateRecord = Replace(UpdateRecord, Chr(10), "")
    UpdateRecord = Replace(UpdateRecord, Chr(13), "")
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
End If


  '*************Connection oppened Sucessfully*************
ArrTempValues = Arrvalues
StrTabName = UCase(Trim(TableName))
strfields = FldNames
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), " ", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'****** Spliting the conditions For Different Rows
'ConnError = ""
If DayBeginEndStatusCheckYN <> "N" Then
    '''''''''''check for day begin and day end status is required
    ConnError = CheckDayBeginDayEndStatus("U", StrTabName, strfields, ArrTempValues, WhereCondition)
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
ConnError = "Connected"

StrCondition = Split(WhereCondition, "|", -1)
''''''''''' Roll back segment for large transactions
'''''If Right(StrTabName, 3) = "LOG" Then
'''''    AdoConnObj.Execute ("SET TRANSACTION USE ROLLBACK SEGMENT RBS7")
'''''End If

If Trim(WhereCondition) = "" Then
ReDim StrCondition(0) As Variant
StrCondition(0) = ""
End If
'''''''''*************************************************************************************
''''checking if the record is to be send to the respective history table.
'''''''''*************************************************************************************
    BlnHistStatus = False
    strHistExt = ""
    Set rsHistCol = CreateObject("ADODB.Recordset")
    Set rsHistExt = CreateObject("ADODB.Recordset")
    
    Set rsHistCol = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDCOLNAME", RecAffect)
    Set rsHistExt = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDTABEXTNS", RecAffect)
    arrflds = Split(strfields, ",", -1)
    rsHistExt.MoveFirst
    For ICount = 0 To rsHistExt.RecordCount - 1
        If Right(StrTabName, Len(Trim(rsHistExt!TABEXTENSIONNAME))) = UCase(Trim(rsHistExt!TABEXTENSIONNAME)) Then
            strHistExt = Trim(rsHistExt!TABBKPEXTENSIONNAME)
            BlnHistStatus = True
            Exit For
        End If
        rsHistExt.MoveNext
    Next ICount
    
    If (BlnHistStatus = True) And (UBound(arrflds) <= rsHistCol.RecordCount) Then
        For ICount = 0 To UBound(arrflds)
        rsHistCol.MoveFirst
            For ColCnt = 0 To rsHistCol.RecordCount - 1
              
                If UCase(Trim(rsHistCol(0))) = UCase(Trim(arrflds(ICount))) Then
                    BlnHistStatus = True
                    Exit For
                Else
                    BlnHistStatus = False
                End If
                
                rsHistCol.MoveNext
            Next ColCnt
            If BlnHistStatus = False Then Exit For
        Next ICount
    Else
        BlnHistStatus = False
    End If
   
    'Set rsHistCol = Nothing
    'Set rsHistExt = Nothing
    
'''''''''*************************************************************************************
'''''''''*************************************************************************************

For RowCnt = 0 To UBound(ArrTempValues)
    RecAffect = 0
    
''''''' First passing the data into history tables based on the type of tables.
    StrInsert = ""
    If BlnHistStatus = False And strHistExt <> "" Then
    
        If UBound(StrCondition) = UBound(ArrTempValues) And Trim(WhereCondition) <> "" Then
            
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
                & StrTabName & "" & DataLink & " Where " & StrCondition(RowCnt)
       Else
        
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
                & StrTabName & "" & DataLink & ""
  
        End If
    
    End If

    If Trim(StrInsert) <> "" Then AdoConnObj.Execute StrInsert


''''****** Spliting the Collumn Names (Fields) to build the Update Statement

    arrflds = Split(strfields, ",", -1)
        
    '****** Spliting the Collumn Values (Fields Values) to build the Update Statement
    ArrRowValue = Split(ArrTempValues(RowCnt), "~", -1)
            
'''*******  first concantinating the values for update ***********
    For ColCnt = 0 To UBound(arrflds)
        
        strUpdateRow = strUpdateRow & arrflds(ColCnt) & "=" & ArrRowValue(ColCnt) & ","
    
    Next ColCnt
       
  '******* Now building the The Update statement ********
    ''''If StrCondition(RowCnt) <> "" Then
    If UBound(StrCondition) = UBound(ArrTempValues) And Trim(WhereCondition) <> "" Then
      
        Strupdate = "update " & StrTabName & "" & DataLink & " set " _
                    & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1) _
                    & " where " & StrCondition(RowCnt)
       
        strquery = "select " & strfields & " from " & Trim(StrTabName) _
                    & DataLink & " where " & StrCondition(RowCnt) & " for update"
    Else
    
        strquery = "select " & strfields & " from " & Trim(StrTabName) _
                    & DataLink & " for update"
        Strupdate = "update " & StrTabName & "" & DataLink & " set " _
                    & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1)
    
    End If
        
    '***** Executing the update statement Based On Number of Rows ********'
    
          AdoConnObj.Execute strquery
         
         AdoConnObj.Execute Strupdate, RecAffect
         Strupdate = ""
         strUpdateRow = ""
         
    If RecAffect = 0 Then
        UpdateRecord = "Update Failed due to False Condition ! " & StrTabName
        
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "UpdateRecord", "0", UpdateRecord & ": " & Strupdate
        
        If rsHistCol.State = 1 Then rsHistCol.Close
        Set rsHistCol = Nothing
        If rsHistExt.State = 1 Then rsHistExt.Close
        Set rsHistExt = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
        Exit Function
    End If
Next RowCnt

UpdateRecord = "Trans Completed"

If rsHistCol.State = 1 Then rsHistCol.Close
Set rsHistCol = Nothing
If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

Exit Function


 '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "UpdateRecord", Err.Number, Err.Description & Strupdate

If rsHistCol.State = 1 Then rsHistCol.Close
Set rsHistCol = Nothing
If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

If ConnError = "" Then

'*************Connection Failed************
    Set AdoConnObj = Nothing
    UpdateRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    UpdateRecord = Replace(UpdateRecord, Chr(10), "")
    UpdateRecord = Replace(UpdateRecord, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / UPDATERECORD"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "UPDCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        UpdateRecord = ArrError(0, 2)
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function
Public Function DeleteRecord(TableName As String, WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String
Dim StrDelete As String, StrTabName As String
Dim StrCondition As Variant, StrInsert As String
''''************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
'''''' If connection failed then
If ConnError <> "Connected" Then
DeleteRecord = ConnError
DeleteRecord = Replace(DeleteRecord, Chr(10), "")
DeleteRecord = Replace(DeleteRecord, Chr(13), "")

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
End If

   
  ''''*************Connection oppened Sucessfully*************
 StrDelete = ""
 StrTabName = ""
 StrCondition = ""
 StrTabName = UCase(Trim(TableName))
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'ConnError = ""

If DayBeginEndStatusCheckYN <> "N" Then
    ConnError = CheckDayBeginDayEndStatus("D", StrTabName, , , WhereCondition)
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
ConnError = "Connected"

 
 
 ''''First passing the data into History tables before deleting the data from original tables
BlnHistStatus = False

Set rsHistExt = CreateObject("ADODB.Recordset")
''''

Set rsHistExt = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDTABEXTNS", RecAffect)
strHistExt = ""
rsHistExt.MoveFirst
For ICount = 0 To rsHistExt.RecordCount - 1
    If Right(StrTabName, Len(Trim(rsHistExt!TABEXTENSIONNAME))) = UCase(Trim(rsHistExt!TABEXTENSIONNAME)) Then
        strHistExt = rsHistExt!TABBKPEXTENSIONNAME
        BlnHistStatus = False
        Exit For
    End If
    rsHistExt.MoveNext
Next ICount

RecAffect = 0
StrInsert = ""

If Trim(WhereCondition) <> "" Then
  StrCondition = Split(WhereCondition, "|", -1)
    For ICount = 0 To UBound(StrCondition)
       If BlnHistStatus = False And strHistExt <> "" Then
            ''''' First passing the data into history tables based on the type of tables.
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink _
            & " select * from " & Trim(StrTabName) & "" & DataLink & " Where " _
            & StrCondition(ICount)
        Else
        
            StrInsert = ""
            
        End If
        

        StrDelete = "Delete from  " & Trim(StrTabName) & DataLink _
                    & " where " & StrCondition(ICount)
 
        If StrInsert <> "" Then AdoConnObj.Execute StrInsert
        AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecord = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecord", Err.Number, DeleteRecord & ": " & StrDelete
            
            If rsHistExt.State = 1 Then rsHistExt.Close
            Set rsHistExt = Nothing
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
               
    Next ICount
    
Else
    If BlnHistStatus = False And strHistExt <> "" Then
        StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
            & Trim(StrTabName) & "" & DataLink & ""
     Else
    
        StrInsert = ""
        
    End If
    
    
    StrDelete = "Delete from  " & Trim(StrTabName) & DataLink & ""
    If StrInsert <> "" Then AdoConnObj.Execute StrInsert
        AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecord = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecord", Err.Number, DeleteRecord & ": " & StrDelete
            
            If rsHistExt.State = 1 Then rsHistExt.Close
            Set rsHistExt = Nothing
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
        

End If

DeleteRecord = "Trans Completed"

If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
  
  
  '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant
If ConnError = "" Then

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecord", Err.Number, Err.Description & StrDelete
'*************Connection Failed************
If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

    DeleteRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    DeleteRecord = Replace(DeleteRecord, Chr(10), "")
    DeleteRecord = Replace(DeleteRecord, Chr(13), "")

Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / DELETERECORD"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
           
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "DELCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        DeleteRecord = ArrError(0, 2)
    
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function


Public Function DeleteRecordOnly(TableName As String, WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String
Dim StrDelete As String, StrTabName As String
Dim StrCondition As Variant, StrInsert As String
''''************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
'''''' If connection failed then
If ConnError <> "Connected" Then
DeleteRecordOnly = ConnError
DeleteRecordOnly = Replace(DeleteRecordOnly, Chr(10), "")
DeleteRecordOnly = Replace(DeleteRecordOnly, Chr(13), "")

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
End If

   
  ''''*************Connection oppened Sucessfully*************
 StrDelete = ""
 StrTabName = ""
 StrCondition = ""
 StrTabName = UCase(Trim(TableName))
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'ConnError = ""

If DayBeginEndStatusCheckYN <> "N" Then
    ConnError = CheckDayBeginDayEndStatus("D", StrTabName, , , WhereCondition)
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
ConnError = "Connected"

 
 
 ''''First passing the data into History tables before deleting the data from original tables


RecAffect = 0
StrInsert = ""

If Trim(WhereCondition) <> "" Then
  StrCondition = Split(WhereCondition, "|", -1)
    For ICount = 0 To UBound(StrCondition)

        StrDelete = "Delete from  " & Trim(StrTabName) & DataLink _
                    & " where " & StrCondition(ICount)
 
        AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecordOnly = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordOnly", Err.Number, DeleteRecordOnly & ": " & StrDelete
            
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
               
    Next ICount
    
Else
    
    
    StrDelete = "Delete from  " & Trim(StrTabName) & DataLink & ""
     AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecordOnly = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordOnly", Err.Number, DeleteRecordOnly & ": " & StrDelete
            
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
        

End If

DeleteRecordOnly = "Trans Completed"

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
  
  
  '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant
If ConnError = "" Then

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordOnly", Err.Number, Err.Description & StrDelete
'*************Connection Failed************
If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

    DeleteRecordOnly = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    DeleteRecordOnly = Replace(DeleteRecordOnly, Chr(10), "")
    DeleteRecordOnly = Replace(DeleteRecordOnly, Chr(13), "")

Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / DeleteRecordOnly"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
           
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "DELCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        DeleteRecordOnly = ArrError(0, 2)
    
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function


Public Function DeleteRecordGen(TableName As String, WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String
Dim StrDelete As String, StrTabName As String
Dim StrCondition As Variant, StrInsert As String, StrInserttrns As String
''''************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
'''''' If connection failed then
If ConnError <> "Connected" Then
DeleteRecordGen = ConnError
DeleteRecordGen = Replace(DeleteRecordGen, Chr(10), "")
DeleteRecordGen = Replace(DeleteRecordGen, Chr(13), "")

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
End If

   
  ''''*************Connection oppened Sucessfully*************
 StrDelete = ""
 StrTabName = ""
 StrCondition = ""
 StrTabName = UCase(Trim(TableName))
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'ConnError = ""

If DayBeginEndStatusCheckYN <> "N" Then
    ConnError = CheckDayBeginDayEndStatus("D", StrTabName, , , WhereCondition)
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
ConnError = "Connected"

 
 
 ''''First passing the data into History tables before deleting the data from original tables
BlnHistStatus = False

Set rsHistExt = CreateObject("ADODB.Recordset")
''''

Set rsHistExt = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDTABEXTNS", RecAffect)
strHistExt = ""
rsHistExt.MoveFirst
For ICount = 0 To rsHistExt.RecordCount - 1
    If Right(StrTabName, Len(Trim(rsHistExt!TABEXTENSIONNAME))) = UCase(Trim(rsHistExt!TABEXTENSIONNAME)) Then
        strHistExt = rsHistExt!TABBKPEXTENSIONNAME
        BlnHistStatus = False
        Exit For
    End If
    rsHistExt.MoveNext
Next ICount

RecAffect = 0
StrInsert = ""

If Trim(WhereCondition) <> "" Then
  StrCondition = Split(WhereCondition, "|", -1)
    For ICount = 0 To UBound(StrCondition)
       If BlnHistStatus = False And strHistExt <> "" Then
            ''''' First passing the data into history tables based on the type of tables.
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink _
            & " select * from " & Trim(StrTabName) & "" & DataLink & " Where " _
            & StrCondition(ICount)
        Else
        
            StrInsert = ""
            
        End If
        
        If UCase(StrTabName) = "GENTRANSLOG" Then
        StrInserttrns = ""
         StrInserttrns = "INSERT INTO GENDELETEDTRANSLOG(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, " & _
         " BATCHNO, TRANNO, AMOUNT,MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, APPROVEDTIMEBAL, DAYENDBAL," & _
         " EFFECTIVEDATE, CUSTOMERID, NAME, CHQNO,CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
         " CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT,LINKMODULEID, LINKGLCODE, " & _
         " LINKACCNO, LINKACCTYPE, REMARKS, SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE," & _
         " RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, RATEREFCODE, " & _
         " APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE,APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, " & _
         " TRANSTATUS, SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE,APPROVEDBY, APPROVEDMACHINE,SYSTEMYEAR, " & _
         " ABBBRANCHCODE, ABBAPPLICATIONDATE, ABBYN, DELETEDUSERID, DELETEDMACHINEID,DELETEDTRANSTATUS) " & _
         " SELECT BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
         " ENTEREDTIMEBAL,VERIFIEDTIMEBAL, APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
         " CHQNO, CHQSERIESNO, CHQFVG,CHQDATE, TOKENNO, CASHPAIDYN, CASHIERID, SYSTEMGENERATEDYN, RATE, " & _
         " FCURRENCYCODE, FAMOUNT, LINKMODULEID,LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, SERVICEID," & _
         " CLGRATETYPE, RESPONDINGBRANCHCODE, RESPONDINGSECTIONCODE,EXCEPTIONYN, RESPONDINGBANKCODE," & _
         " RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, APPROVEDDATE,APPLICATIONDATE, USERID," & _
         " MACHINEID, TRANSTATUS, SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY,APPROVEDMACHINE, " & _
         " SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, ABBYN,'" & UserCode & "','" & MachineID & "','P' " & _
         " FROM GENTRANSLOG Where" & StrCondition(ICount)
         
        If StrInserttrns <> "" Then AdoConnObj.Execute StrInserttrns
       
        
        End If
        
        StrDelete = "Delete from  " & Trim(StrTabName) & DataLink _
                    & " where " & StrCondition(ICount)
 
        If StrInsert <> "" Then AdoConnObj.Execute StrInsert
        AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecordGen = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordGen", Err.Number, DeleteRecordGen & ": " & StrDelete
            
            If rsHistExt.State = 1 Then rsHistExt.Close
            Set rsHistExt = Nothing
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
               
    Next ICount
    
Else
    If BlnHistStatus = False And strHistExt <> "" Then
        StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
            & Trim(StrTabName) & "" & DataLink & ""
     Else
    
        StrInsert = ""
        
    End If
    
    
    StrDelete = "Delete from  " & Trim(StrTabName) & DataLink & ""
    If StrInsert <> "" Then AdoConnObj.Execute StrInsert
        AdoConnObj.Execute StrDelete, RecAffect
        
        If RecAffect = 0 Then
            DeleteRecordGen = "Delete Failed due to False Condition !"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordGen", Err.Number, DeleteRecordGen & ": " & StrDelete
            
            If rsHistExt.State = 1 Then rsHistExt.Close
            Set rsHistExt = Nothing
            If AdoConnObj.State = 1 Then AdoConnObj.Close
            Set AdoConnObj = Nothing
            Exit Function
        End If
    

End If

DeleteRecordGen = "Trans Completed"

If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function
  
  
  '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant
If ConnError = "" Then

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DeleteRecordGen", Err.Number, Err.Description & StrDelete
'*************Connection Failed************
If rsHistExt.State = 1 Then rsHistExt.Close
Set rsHistExt = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

    DeleteRecordGen = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    DeleteRecordGen = Replace(DeleteRecordGen, Chr(10), "")
    DeleteRecordGen = Replace(DeleteRecordGen, Chr(13), "")

Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / DeleteRecordGen"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
           
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "DELCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Deleted from " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        DeleteRecordGen = ArrError(0, 2)
    
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function



Public Sub GetConnetion(ByRef AdoConnObj1 As ADODB.Connection, ByRef ConnError1 As String)

    Call DBConnection
    ConnError1 = ConnError
    Set AdoConnObj1 = AdoConnObj
    
End Sub

Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With

''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

'''' The functionality of this method is to reject the Modification of a record and place the original
'''' record back to the specified table

Public Function RejectRecord(TableName As String, _
                        Optional WhereCondition As String, _
                        Optional BranchCode As String, _
                        Optional UserCode As String, _
                        Optional MachineID As String, _
                        Optional ApplicationDate As String, _
                        Optional DayBeginEndStatusCheckYN As String) As String

 
Dim ArrTempValues As Variant, ArrRowValue As Variant, arrflds As Variant, strquery As String
Dim Strupdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, StrCondition As Variant, StrTabName As String, strfields As String
Dim strHistTab As String, StrDeleteMst As String, StrDeleteHist
'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then
    RejectRecord = ConnError
    RejectRecord = Replace(RejectRecord, Chr(10), "")
    RejectRecord = Replace(RejectRecord, Chr(13), "")
    Exit Function
End If

StrTabName = UCase(Trim(TableName))
strHistTab = UCase(Trim(TableName)) & "HIST"
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(AppDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
If DayBeginEndStatusCheckYN <> "N" Then
    ConnError = CheckDayBeginDayEndStatus("R", StrTabName, , , WhereCondition)
    If ConnError <> "CONTINUE" Then GoTo errhand
End If
ConnError = "Connected"
  
'****** Spliting the conditions For Different Rows
If Trim(WhereCondition) <> "" Then
    StrCondition = Split(WhereCondition, "|", -1)
    
    
    RecAffect = 0
    
    For ICount = 0 To UBound(StrCondition)
    
        StrDeleteMst = "Delete from  " & Trim(StrTabName) & DataLink & " where " & StrCondition(ICount)
        
        StrInsert = "Insert into " & Trim(StrTabName) & DataLink & " select * from " _
            & Trim(StrTabName) & "Hist" & DataLink & " Where " & StrCondition(ICount) _
            & " and to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss') in " _
            & " (select max(to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss')) from " _
            & Trim(StrTabName) & "Hist" & DataLink & " Where " & StrCondition(ICount) & ") and " _
            & " to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') in " _
            & " (select max(to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')) from " _
            & Trim(StrTabName) & "Hist" & DataLink & " Where " & StrCondition(ICount) & ")"
       
       StrDeleteHist = "Delete from " & Trim(StrTabName) & "Hist" & DataLink & " Where " _
            & StrCondition(ICount) & " and to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss') in " _
            & " (select max(to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss')) from " _
            & Trim(StrTabName) & "Hist" & DataLink & " Where " & StrCondition(ICount) & ") and " _
            & " to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') in " _
            & " (select max(to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')) from " _
            & Trim(StrTabName) & "Hist" & DataLink & " Where " & StrCondition(ICount) & ")"
    
    AdoConnObj.Execute StrDeleteMst, RecAffect
    If RecAffect > 1 Then
        RejectRecord = "Reject failed due to false condition with : " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & ": " & StrDeleteMst
        Exit Function
    End If
    
        AdoConnObj.Execute StrInsert, RecAffect
        If RecAffect < 1 Then
            RejectRecord = "Reject failed due to false condition with : " & StrTabName
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & ": " & StrInsert
            Exit Function
        End If
        
        AdoConnObj.Execute StrDeleteHist, RecAffect
        If RecAffect > 1 Then
            RejectRecord = "Reject failed due to false condition with : " & StrTabName
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & ": " & StrDeleteHist
            Exit Function
        End If
    
    Next ICount
    
Else
    StrDeleteMst = "Delete from  " & Trim(StrTabName) & DataLink
    
    StrInsert = "Insert into " & Trim(StrTabName) & DataLink & " select * from " _
        & Trim(StrTabName) & "Hist" & DataLink _
        & " Where to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss') in " _
        & " (select max(to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss')) from " _
        & Trim(StrTabName) & "Hist" & DataLink & ") and " _
        & " to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') in " _
        & " (select max(to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')) from " _
        & Trim(StrTabName) & "Hist" & DataLink & ")"
   
   StrDeleteHist = " Delete from " & Trim(StrTabName) & "Hist" & DataLink _
        & " Where to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss') in " _
        & " (select max(to_date(to_char(systemdate,'dd-Mon-yyyy HH24:mi:ss'),'dd-Mon-yyyy HH24:mi:ss')) from " _
        & Trim(StrTabName) & "Hist" & DataLink & ") and " _
        & " to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') in " _
        & " (select max(to_date(to_char(APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')) from " _
        & Trim(StrTabName) & "Hist" & DataLink & ")"
   

    AdoConnObj.Execute StrDeleteMst, RecAffect
    If RecAffect > 1 Then
        RejectRecord = "Reject failed due to false condition with : " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & "" & StrDeleteMst
        Exit Function
    End If
    
    AdoConnObj.Execute StrInsert, RecAffect
    If RecAffect < 1 Then
        RejectRecord = "Reject failed due to false condition with : " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & "" & StrInsert
        Exit Function
    End If
    
    AdoConnObj.Execute StrDeleteHist, RecAffect
    If RecAffect > 1 Then
        RejectRecord = "Reject failed due to false condition with : " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", 999, RejectRecord & "" & StrDeleteHist
        Exit Function
    End If
End If

    Set AdoConnObj = Nothing
    RejectRecord = "Trans Completed"
    Exit Function

errhand:
Dim arrErrSplit As Variant
If ConnError = "" Then

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "RejectRecord", Err.Number, Err.Description & " Insert: " & StrInsert & " Insert hist: " & StrDeleteHist

'*************Connection Failed************
    Set AdoConnObj = Nothing
    RejectRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    RejectRecord = Replace(RejectRecord, Chr(10), "")
    RejectRecord = Replace(RejectRecord, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / REJECTRECORD"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Rejected Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
        
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "REJCHK"
            errDesc = ConnError
            clntDesc = ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Rejected Due to " & Err.Description & " " & StrDeleteMst & " " & StrDeleteHist & " " & StrInsert
        End If
    '''clntDesc = "Records Could Not Be Deleted Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc & " : " & StrTabName, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        RejectRecord = ArrError(0, 2)
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

End Function

Private Function CheckDayBeginDayEndStatus(ModeOfTran As String, _
                                            strTab As String, _
                                            Optional strfields As String, _
                                            Optional Arrvalues As Variant, _
                                            Optional StrCond As String) As String
Dim strquery As String
Dim arrflds As Variant
Dim arrChkVal As Variant
Dim ArrCond As Variant
Dim RsTemp As ADODB.Recordset
Dim strtempCode As String
Dim BlnUserMach As Boolean
Dim blnbrCode As Boolean
Dim intArrChk As Integer
On Error GoTo errhand
Set RsTemp = CreateObject("ADODB.Recordset")
''''''''''' if branchcode parameter not available from the frontend then collect it
''''''''''' from the values of the transarray.
 If BRCode = "" Or UserId = "" Or MachID = "" Then
    arrflds = Split(strfields, ",", -1)
    BlnUserMach = False
    blnbrCode = False
    ''''''''if the transaction is insert
    If ModeOfTran = "I" Then
        arrChkVal = Split(Arrvalues(0), ",", -1)
        '''''to trap the userid and machineid position in the values. intArrChk
        intArrChk = UBound(arrChkVal) - UBound(arrflds)
        strquery = "select * from " & strTab & DataLink & " where 1=2"
        
        Set RsTemp = AdoConnObj.Execute(strquery)
        
        For ICount = 0 To RsTemp.Fields.Count - 1
            If Trim(UCase(RsTemp.Fields(ICount).Name)) = "USERID" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "APPROVEDBY" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "VERIFIEDBY" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "MACHINEID" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "APPROVEDMACHINE" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "VERIFIEDMACHINE" Then
                    BlnUserMach = True
            ElseIf Trim(UCase(RsTemp.Fields(ICount).Name)) = "BRANCHCODE" Then
                blnbrCode = True
            End If
            
        Next
        
        
          For ICount = 0 To UBound(arrflds)
        
              If Trim(UCase(arrflds(ICount))) = "BRANCHCODE" Then
                  
                  strtempCode = Trim(UCase(arrChkVal(ICount)))
                    'MsgBox BRCode
                    'MsgBox strTab
                  If Right(strtempCode, 1) = "'" Then
                  '''''''''''please do not change the below coding line
                  '''''''''it gives branch code with out single quotes
                      BRCode = Mid(strtempCode, 2, Len(strtempCode) - 2)
                  Else
                      BRCode = strtempCode
                  End If
                    'MsgBox BRCode
                    'MsgBox strTab
                    
                  
              ElseIf Trim(UCase(arrflds(ICount))) = "USERID" Then
                  strtempCode = Trim(UCase(arrChkVal(ICount - intArrChk)))
            
                  If Right(strtempCode, 1) = "'" Then
                  '''''''''''please do not change the below coding line
                  '''''''''it gives userid with out single quotes
                      UserId = Mid(strtempCode, 2, Len(strtempCode) - 2)
                      
                  End If
                  
              ElseIf Trim(UCase(arrflds(ICount))) = "MACHINEID" Then
                 strtempCode = Trim(UCase(arrChkVal(ICount - intArrChk)))
                  If Right(strtempCode, 1) = "'" Then
                  '''''''''''please do not change the below coding line
                  '''''''''it gives machineid with out single quotes
                      MachID = Mid(strtempCode, 2, Len(strtempCode) - 2)
                      
                  End If
                 
              End If
          Next
    
    ''''''''if the transaction is update
    ElseIf ModeOfTran = "U" Then
        arrChkVal = Split(Arrvalues(0), "~", -1)
        If StrCond <> "" Then
            ArrCond = Split(StrCond, "|", -1)
            strquery = "select * from " & strTab & DataLink & " where " & ArrCond(0)
        Else
            strquery = "select * from " & strTab & DataLink
        End If
        
        Set RsTemp = AdoConnObj.Execute(strquery)
        If RsTemp.EOF And RsTemp.BOF Then
        
            CheckDayBeginDayEndStatus = "Records not available for Modification"
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "CheckDayBeginDayEndStatus", 999, CheckDayBeginDayEndStatus & ": " & strquery
            ErrNum = "MODCHK"
            If RsTemp.State = 1 Then RsTemp.Close
            Set RsTemp = Nothing
            Exit Function
        End If
        
        '''''''''''please do not change the below coding lines
        '''''''''it gives branch code with out single quotes
        For ICount = 0 To RsTemp.Fields.Count - 1
            If Trim(UCase(RsTemp.Fields(ICount).Name)) = "BRANCHCODE" Then
                BRCode = Trim(UCase(RsTemp.Fields(ICount).Value))
                blnbrCode = True
            ElseIf Trim(UCase(RsTemp.Fields(ICount).Name)) = "USERID" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "APPROVEDBY" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "VERIFIEDBY" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "MACHINEID" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "APPROVEDMACHINE" _
                Or Trim(UCase(RsTemp.Fields(ICount).Name)) = "VERIFIEDMACHINE" Then
                BlnUserMach = True
            End If
        Next
        
        If BlnUserMach = True Then
            For ICount = 0 To UBound(arrflds)
                If Trim(UCase(arrflds(ICount))) = "USERID" _
                    Or Trim(UCase(arrflds(ICount))) = "APPROVEDBY" _
                    Or Trim(UCase(arrflds(ICount))) = "VERIFIEDBY" Then
                    strtempCode = Trim(UCase(arrChkVal(ICount)))
                    If Right(strtempCode, 1) = "'" Then
                    '''''''''''please do not change the below coding lines
                    '''''''''it gives userid with out single quotes
                        UserId = Mid(strtempCode, 2, Len(strtempCode) - 2)
                    End If
                ElseIf Trim(UCase(arrflds(ICount))) = "MACHINEID" _
                    Or Trim(UCase(arrflds(ICount))) = "APPROVEDMACHINE" _
                    Or Trim(UCase(arrflds(ICount))) = "VERIFIEDMACHINE" Then
                         strtempCode = Trim(UCase(arrChkVal(ICount)))
                    If Right(strtempCode, 1) = "'" Then
                    '''''''''''please do not change the below coding line
                    '''''''''it gives machineid with out single quotes
                        MachID = Mid(strtempCode, 2, Len(strtempCode) - 2)
                    End If
                End If
            Next
        
        End If
        ''''''''if the transaction is delete or reject
    ElseIf ModeOfTran = "D" Or ModeOfTran = "R" Then
        If StrCond <> "" Then
            ArrCond = Split(StrCond, "|", -1)
            strquery = "select * from " & strTab & DataLink & " where " & ArrCond(0)
        Else
            strquery = "select * from " & strTab & DataLink
        End If
        
        Set RsTemp = AdoConnObj.Execute(strquery)
        If RsTemp.EOF And RsTemp.BOF Then
        
            CheckDayBeginDayEndStatus = "Records not available for Deletion or Rejection."
            If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "CheckDayBeginDayEndStatus", 999, CheckDayBeginDayEndStatus & ": " & strquery
            ErrNum = "DELREJCHK"
            
            If RsTemp.State = 1 Then RsTemp.Close
            Set RsTemp = Nothing
            Exit Function
        End If
        
        For ICount = 0 To RsTemp.Fields.Count - 1
            If Trim(UCase(RsTemp.Fields(ICount).Name)) = "BRANCHCODE" Then
                BRCode = Trim(UCase(RsTemp.Fields(ICount).Value))
                blnbrCode = True
            End If
        Next
    End If
 End If
 
'''''''if branchcode is found then check for the dayend or daybegin status
'''''''else assumed that branch is not implemented.
    If blnbrCode = True Then
        
        
        If BRCode = "" Then
            ErrNum = "BANKCHK"
            CheckDayBeginDayEndStatus = "Branch Not Available"
        Else
            strquery = "select * from GENAPPLICATIONDATEMST where upper(branchcode)='" _
            & UCase(BRCode) & "'"
            If RsTemp.State = 1 Then RsTemp.Close
            Set RsTemp = AdoConnObj.Execute(strquery)
            If RsTemp.RecordCount > 0 Then
    
                If RsTemp!DAYBEGINSTATUS = "O" And RsTemp!DAYENDSTATUS = "N" Then
                     CheckDayBeginDayEndStatus = "CONTINUE"
                Else
                    If RsTemp!DAYBEGINSTATUS = "O" And RsTemp!DAYENDSTATUS = "O" Then
                        CheckDayBeginDayEndStatus = "Your Branch End Over or Day Begin Not Started. Please Check ! "
                        ErrNum = "DAYBEGCHK"
                    ElseIf RsTemp!DAYBEGINSTATUS <> "O" And RsTemp!DAYENDSTATUS = "O" Then
                        CheckDayBeginDayEndStatus = " Your Branch Day End Over. Please Check !"
                        ErrNum = "DAYENDCHK"
                    End If
                End If
            Else
                ErrNum = "BRANCHCHK"
                CheckDayBeginDayEndStatus = "Operation of this Branch is not started."
            End If
        End If
    Else
        CheckDayBeginDayEndStatus = "CONTINUE"
    End If
    
If RsTemp.State = 1 Then RsTemp.Close
Set RsTemp = Nothing
Exit Function

errhand:
If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "CheckDayBeginDayEndStatus", Err.Number, Err.Description
CheckDayBeginDayEndStatus = "Error Occurec NO " & Err.Number & " " & Err.Description

End Function

Public Function InsertUsingSelect(TableName As String, FldNames As String, _
                             Arrvalues As Variant, Optional WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String

Dim RsTemp As ADODB.Recordset
Dim ArrTempValues As Variant, ArrRowValue As Variant, arrflds As Variant, strquery As String
Dim Strupdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, StrCondition As Variant, StrTabName As String, strfields As String
'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then
    InsertUsingSelect = ConnError
    InsertUsingSelect = Replace(InsertUsingSelect, Chr(10), "")
    InsertUsingSelect = Replace(InsertUsingSelect, Chr(13), "")
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
End If

'*************Connection oppened Sucessfully*************
Set RsTemp = CreateObject("Adodb.Recordset")
ArrTempValues = Arrvalues
StrTabName = UCase(Trim(TableName))
strfields = FldNames
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), " ", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'****** Spliting the conditions For Different Rows

ConnError = "Connected"

StrCondition = Split(WhereCondition, "|", -1)

If Trim(WhereCondition) = "" Then
ReDim StrCondition(0) As Variant
StrCondition(0) = ""
End If

For RowCnt = 0 To UBound(ArrTempValues)
    RecAffect = 0
    
    Strupdate = "Insert into " & Trim(StrTabName) & DataLink & "(" & FldNames & ") " & _
    ArrTempValues(RowCnt) & " Where " & WhereCondition
    
    AdoConnObj.Execute Strupdate, RecAffect
    Strupdate = ""
    strUpdateRow = ""

    If RecAffect = 0 Then
        InsertUsingSelect = "Inwertion Failed due to False Condition ! " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertUsingSelect", 999, InsertUsingSelect & ": " & Strupdate

        If RsTemp.State = 1 Then RsTemp.Close
        Set RsTemp = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
    
        Exit Function
    End If
Next RowCnt

                
If RsTemp.State = 1 Then RsTemp.Close
Set RsTemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing



InsertUsingSelect = "Trans Completed"
Exit Function


 '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertUsingSelect", Err.Number, Err.Description & StrInsert

If RsTemp.State = 1 Then RsTemp.Close
Set RsTemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing


If ConnError = "" Then

'*************Connection Failed************
    Set AdoConnObj = Nothing
    InsertUsingSelect = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    InsertUsingSelect = Replace(InsertUsingSelect, Chr(10), "")
    InsertUsingSelect = Replace(InsertUsingSelect, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / InsertUsingSelect"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "UPDCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        InsertUsingSelect = ArrError(0, 2)
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function

Public Function InsertUsingSelectHist(TableName As String, FldNames As String, _
                             Arrvalues As Variant, Optional WhereCondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String, _
                             Optional ApplicationDate As String, _
                             Optional DayBeginEndStatusCheckYN As String) As String

Dim RsTemp As ADODB.Recordset
Dim ArrTempValues As Variant, ArrRowValue As Variant, arrflds As Variant, strquery As String
Dim Strupdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, StrCondition As Variant, StrTabName As String, strfields As String
Dim StrDelete As String
'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then
    InsertUsingSelectHist = ConnError
    InsertUsingSelectHist = Replace(InsertUsingSelectHist, Chr(10), "")
    InsertUsingSelectHist = Replace(InsertUsingSelectHist, Chr(13), "")
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
End If

'*************Connection oppened Sucessfully*************
Set RsTemp = CreateObject("Adodb.Recordset")
ArrTempValues = Arrvalues
StrTabName = UCase(Trim(TableName))
strfields = FldNames
BRCode = IIf(IsNull(UCase(Trim(BranchCode))), " ", UCase(Trim(BranchCode)))
UserId = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
AppDate = IIf(IsNull(Trim(ApplicationDate)), Format(Now, "dd-MMM-yyyy"), Format(ApplicationDate, "dd-MMM-yyyy"))
'****** Spliting the conditions For Different Rows

ConnError = "Connected"

StrCondition = Split(WhereCondition, "|", -1)

If Trim(WhereCondition) = "" Then
ReDim StrCondition(0) As Variant
StrCondition(0) = ""
End If


'''''''''*************************************************************************************
''''checking if the record is to be send to the respective history table.
'''''''''*************************************************************************************
    BlnHistStatus = False
    strHistExt = ""
    Set rsHistCol = CreateObject("ADODB.Recordset")
    Set rsHistExt = CreateObject("ADODB.Recordset")
    
    Set rsHistCol = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDCOLNAME", RecAffect)
    Set rsHistExt = AdoConnObj.Execute("Select * from GENHISTNOTREQUIREDTABEXTNS", RecAffect)
    arrflds = Split(strfields, ",", -1)
    rsHistExt.MoveFirst
    For ICount = 0 To rsHistExt.RecordCount - 1
        If Right(StrTabName, Len(Trim(rsHistExt!TABEXTENSIONNAME))) = UCase(Trim(rsHistExt!TABEXTENSIONNAME)) Then
            strHistExt = Trim(rsHistExt!TABBKPEXTENSIONNAME)
            BlnHistStatus = True
            Exit For
        End If
        rsHistExt.MoveNext
    Next ICount
    
    If (BlnHistStatus = True) And (UBound(arrflds) <= rsHistCol.RecordCount) Then
        For ICount = 0 To UBound(arrflds)
        rsHistCol.MoveFirst
            For ColCnt = 0 To rsHistCol.RecordCount - 1
              
                If UCase(Trim(rsHistCol(0))) = UCase(Trim(arrflds(ICount))) Then
                    BlnHistStatus = True
                    Exit For
                Else
                    BlnHistStatus = False
                End If
                
                rsHistCol.MoveNext
            Next ColCnt
            If BlnHistStatus = False Then Exit For
        Next ICount
    Else
        BlnHistStatus = False
    End If
   
    'Set rsHistCol = Nothing
    'Set rsHistExt = Nothing
    
'''''''''*************************************************************************************
'''''''''*************************************************************************************

For RowCnt = 0 To UBound(ArrTempValues)
    RecAffect = 0
    
    
    ''''''' First passing the data into history tables based on the type of tables.
    StrInsert = ""
    If BlnHistStatus = False And strHistExt <> "" Then
    
        If UBound(StrCondition) = UBound(ArrTempValues) And Trim(WhereCondition) <> "" Then
            
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
                & StrTabName & "" & DataLink & " Where " & StrCondition(RowCnt)
    '        StrDelete = "Delete from " & Trim(StrTabName) & " Where " & StrCondition(RowCnt)
            
       Else
        
            StrInsert = "Insert into " & Trim(StrTabName) & strHistExt & DataLink & " select * from " _
                & StrTabName & "" & DataLink & ""
     '       StrDelete = "Delete from " & Trim(StrTabName)
            
        End If
    
    End If

    If Trim(StrInsert) <> "" Then AdoConnObj.Execute StrInsert
     ''''''' deleting the data from the main table
    'If Trim(StrDelete) <> "" Then AdoConnObj.Execute StrDelete

        
            
    ''insert using select statement
            
    Strupdate = "Insert into " & Trim(StrTabName) & DataLink & "(" & FldNames & ") " & _
    ArrTempValues(RowCnt) & " Where " & WhereCondition
    
    AdoConnObj.Execute Strupdate, RecAffect
    Strupdate = ""
    strUpdateRow = ""

    If RecAffect = 0 Then
        InsertUsingSelectHist = "Inwertion Failed due to False Condition ! " & StrTabName
        If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertUsingSelectHist", 999, InsertUsingSelectHist & ": " & Strupdate

        If RsTemp.State = 1 Then RsTemp.Close
        Set RsTemp = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
    
      If rsHistCol.State = 1 Then rsHistCol.Close
        Set rsHistCol = Nothing
        If rsHistExt.State = 1 Then rsHistExt.Close
        Set rsHistExt = Nothing
        Exit Function
    End If
Next RowCnt

                
If RsTemp.State = 1 Then RsTemp.Close
Set RsTemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
 If rsHistCol.State = 1 Then rsHistCol.Close
        Set rsHistCol = Nothing
        If rsHistExt.State = 1 Then rsHistExt.Close
        Set rsHistExt = Nothing


InsertUsingSelectHist = "Trans Completed"
Exit Function


 '''''******************************ERROR HANDLING*****************************************
errhand:
Dim arrErrSplit As Variant

If blnLogErrors = True Then objErrlog.LogError "DataBaseTransactions", "InsertUsingSelectHist", Err.Number, Err.Description & StrInsert

If RsTemp.State = 1 Then RsTemp.Close
Set RsTemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing


If ConnError = "" Then

'*************Connection Failed************
    Set AdoConnObj = Nothing
    InsertUsingSelectHist = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
    InsertUsingSelectHist = Replace(InsertUsingSelectHist, Chr(10), "")
    InsertUsingSelectHist = Replace(InsertUsingSelectHist, Chr(13), "")
Else
    Set AdoConnObj = Nothing
        If strComponent = "" Then
        strComponent = "DATABASETRANSACTIONS.TRANSACTIONS / InsertUsingSelectHist"
        End If
        
        If UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & errDesc
            arrErrSplit = Split(errDesc, "(")
            
            If UBound(arrErrSplit) > 0 Then
                errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
            End If
            
            
            
        ElseIf ConnError <> "Connected" Then
            If ErrNum = "" Then ErrNum = "UPDCHK"
            errDesc = ConnError
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & ConnError
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Error ! Records Could Not Be Modified on " & StrTabName & " Due to " & Err.Description
        End If
    'clntDesc = "Records Could Not Be Modified Due to " & errDesc
    Set objError = CreateObject("TrapError.ErrorDescription")
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc, strComponent, BRCode, UserId, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
        InsertUsingSelectHist = ArrError(0, 2)
        '''ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If
End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
blnLogErrors = True
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
