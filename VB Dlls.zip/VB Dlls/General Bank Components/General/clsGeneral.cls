VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "clsGeneral"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim ObjContext As ObjectContext
Dim objQuery As Object
Dim rs As ADODB.Recordset
Dim StrSql As String

Public Function GetNEFTRTGSMobileNo(strBrCode As String, strCurcode As String, strModId As String, strGlcode As String, strAccno As String) As String
On Error GoTo ErrHandler
Dim strMobileNo As String
Set ObjContext = GetObjectContext
Set objQuery = ObjContext.CreateInstance("ReportPurposeOnly.Reportonly")

StrSql = "SELECT CUSTMOBILE FROM gencustinfomst  WHERE customerid IN (SELECT customerid " & _
" FROM " & strModId & "mst WHERE  accno ='" & strAccno & "'  AND glcode ='" & strGlcode & "' AND currencycode = '" & strCurcode & "')"


Set rs = objQuery.SingleSelectStat(StrSql)
        
        If Not rs.EOF And Not rs.BOF Then
        strMobileNo = IIf(IsNull(rs!CUSTMOBILE), "", rs!CUSTMOBILE)
        Else
        strMobileNo = ""
        End If
            
GetNEFTRTGSMobileNo = strMobileNo
ObjContext.SetComplete
Set ObjContext = Nothing
Set objQuery = Nothing

Exit Function
ErrHandler:
ObjContext.SetAbort

Set ObjContext = Nothing
Set objQuery = Nothing
                                
GetNEFTRTGSMobileNo = ""
End Function

Public Function GetNEFTRTGSCrMobileNo(strBrCode As String, strCurcode As String, strModId As String, strGlcode As String, strAccno As String, strCrModId As String) As String
On Error GoTo ErrHandler
Dim strMobileNo As String
Set ObjContext = GetObjectContext
Set objQuery = ObjContext.CreateInstance("ReportPurposeOnly.Reportonly")

If Trim(UCase(strCrModId)) = "INV" Or Trim(UCase(strCrModId)) = "MISC" Or Trim(UCase(strCrModId)) = "PL" Then
StrSql = "SELECT NEFTMOBILE CUSTMOBILE FROM genbankbranchmst where branchcode =  '" & strBrCode & "'"
Else
StrSql = "SELECT CUSTMOBILE FROM gencustinfomst  WHERE customerid IN (SELECT customerid " & _
" FROM " & strModId & "mst WHERE  accno ='" & strAccno & "'  AND glcode ='" & strGlcode & "' AND currencycode = '" & strCurcode & "'  " & _
" AND branchcode = '" & strBrCode & "')"
End If

Set rs = objQuery.SingleSelectStat(StrSql)
        
        If Not rs.EOF And Not rs.BOF Then
        strMobileNo = IIf(IsNull(rs!CUSTMOBILE), "", rs!CUSTMOBILE)
        Else
        strMobileNo = ""
        End If
            
GetNEFTRTGSCrMobileNo = strMobileNo
ObjContext.SetComplete
Set ObjContext = Nothing
Set objQuery = Nothing

Exit Function
ErrHandler:
ObjContext.SetAbort

Set ObjContext = Nothing
Set objQuery = Nothing
                                
GetNEFTRTGSCrMobileNo = ""
End Function


Public Function GetRefno() As String
On Error GoTo ErrHandler

Dim strRefno As String
Set ObjContext = GetObjectContext
Set objQuery = ObjContext.CreateInstance("ReportPurposeOnly.Reportonly")

StrSql = "SELECT (SELECT H2Hbankname FROM GENBANKPARM)||TO_CHAR(SYSDATE,'yymmdd')||x.refno  refno FROM (SELECT " & _
" LPAD(NVL(MAX(SUBSTR(refno,11,6)),0)+1,6,'0') refno FROM neftrtgsdtls WHERE TO_NUMBER(SUBSTR(refno,5,6)) = " & _
" TO_NUMBER(TO_CHAR(SYSDATE,'yymmdd'))) x"

Set rs = objQuery.SingleSelectStat(StrSql)
        
    If Not rs.EOF And Not rs.BOF Then
        strRefno = IIf(IsNull(rs!refno), "", rs!refno)
    Else
        strRefno = ""
    End If
    
GetRefno = strRefno
ObjContext.SetComplete
Set ObjContext = Nothing
Set objQuery = Nothing
Exit Function
ErrHandler:
ObjContext.SetAbort

Set ObjContext = Nothing
Set objQuery = Nothing
                                
GetRefno = ""
End Function

Public Function GetSBCADrCrLienYN(strMode As String, strBrCode As String, strCurcode As String, strModId As String, strGlcode As String, _
strAccno As String, TransAmt As Double, TranDate As Date) As String
On Error GoTo ErrHandler

Dim strDrLnYN As String
Dim strCrLnYN As String
Dim strAllowYN As String
Dim dblDrLnAmt As Double
Dim dblCrLnAmt As Double
Dim dblAccBal As Double
Dim dblfinLeinLimAmt As Double
Dim strDrCrLnYN As String

If strModId = "SB" Or strModId = "CA" Then
Else
GoTo End1
End If

Set ObjContext = GetObjectContext
Set objQuery = ObjContext.CreateInstance("ReportPurposeOnly.Reportonly")
' Set objQuery = New ReportPurposeOnly.Reportonly
 StrSql = "select GETANYDAYBAL('" & strBrCode & "'," & _
                          " '" & strCurcode & "' ,'" & strModId & "'," & _
                          " '" & strGlcode & "','" & strAccno & "'," & _
                         " '" & Format(TranDate, "dd-MMM-yyyy") & "') bal from dual"
Set rs = objQuery.SingleSelectStat(StrSql)

If Not rs.EOF And Not rs.BOF Then
dblAccBal = IIf(IsNull(rs!bal), 0, rs!bal)
Else
dblAccBal = 0
End If

rs.Close
Set rs = Nothing

StrSql = "SELECT DRLIENYN, CRLIENYN FROM " & strModId & "mst  WHERE branchcode ='" & strBrCode & "' AND " & _
" currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"
Set rs = objQuery.SingleSelectStat(StrSql)
If Not rs.EOF And Not rs.BOF Then
    strDrLnYN = IIf(IsNull(rs!DRLIENYN), "N", rs!DRLIENYN)
    strCrLnYN = IIf(IsNull(rs!CRLIENYN), "N", rs!CRLIENYN)
    Else
    strDrLnYN = "N"
    strCrLnYN = "N"
End If

rs.Close
Set rs = Nothing

StrSql = "SELECT DRLIENAMT, CRLIENAMT FROM SBCALIENDTLS WHERE branchcode ='" & strBrCode & "' AND " & _
" currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"

Set rs = objQuery.SingleSelectStat(StrSql)

If Not rs.EOF And Not rs.BOF Then
    dblDrLnAmt = IIf(IsNull(rs!DRLIENAMT), 0, rs!DRLIENAMT)
    dblCrLnAmt = IIf(IsNull(rs!CRLIENAMT), 0, rs!CRLIENAMT)
Else
    dblDrLnAmt = 0
    dblCrLnAmt = 0
End If

rs.Close
Set rs = Nothing

'' for Debit lien yn
If strMode = "Dr" Then
    If strDrLnYN = "Y" Then
        If dblAccBal - dblDrLnAmt >= TransAmt Then
            strAllowYN = "Y"
        Else
            strAllowYN = "N"
        End If
    Else
            strAllowYN = "Y"
    End If
End If


'' for Credit Lien YN
If strMode = "Cr" Then
    If strCrLnYN = "Y" Then
         strAllowYN = "N"
    Else
         strAllowYN = "Y"
    End If
End If

If strMode = "Dr" Then
dblfinLeinLimAmt = dblDrLnAmt
strDrCrLnYN = strDrLnYN
ElseIf strMode = "Cr" Then
dblfinLeinLimAmt = dblCrLnAmt
strDrCrLnYN = strCrLnYN
Else
dblfinLeinLimAmt = 0
strDrCrLnYN = ""
End If

GetSBCADrCrLienYN = strAllowYN & "|" & strDrCrLnYN & "|" & dblfinLeinLimAmt

'Exit Function
ObjContext.SetComplete
Set ObjContext = Nothing
Set objQuery = Nothing
Exit Function
End1:
GetSBCADrCrLienYN = "Y||"
Exit Function
ErrHandler:
ObjContext.SetAbort

Set ObjContext = Nothing
Set objQuery = Nothing
                               
GetSBCADrCrLienYN = "N||"
End Function
