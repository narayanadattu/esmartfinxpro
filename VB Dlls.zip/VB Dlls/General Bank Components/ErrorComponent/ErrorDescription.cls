VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "ErrorDescription"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim objcontext As ObjectContext
Dim ObjError As Object
Dim DataLink As String
Dim ArrLink As Variant
Dim objDBlink As Object
Const blnDebug As Boolean = True


Public Function ErrorProcess(ErrNumber As String, ErrDesc As String, ErrClientDesc As String, _
                            Optional ComponentName As String, Optional Branchode As String, _
                            Optional UserId As String, Optional MachineID As String) As Variant


Dim RSError As ADODB.Recordset
Dim InsValues() As Variant, strResult As String
Dim FldNames As String, TabName As String, Condition As String, StrComponent As String
Dim strquery As String, strErrNo As String, strErrDesc As String, StrClientDesc As String
Dim Compname As String, StrUserID As String, StrMachineID As String, StrBranchCode As String
Dim ArrError As Variant
Dim resaff As Integer, OriginalOracleError As String

Set objcontext = GetObjectContext
On Error GoTo ErrHand

OriginalOracleError = ErrDesc
OriginalOracleError = Replace(OriginalOracleError, Chr(10), "")
OriginalOracleError = Replace(OriginalOracleError, Chr(13), "")
OriginalOracleError = Replace(OriginalOracleError, "'", "")

strquery = ""

If Right(Trim(ErrNumber), 1) = ":" Then
    strErrNo = UCase(Trim(Mid(ErrNumber, 1, InStr(1, UCase(Trim(ErrNumber)), ":") - 1)))
Else
    strErrNo = UCase(Trim(ErrNumber))
End If
'''strErrNo = UCase(Trim(Mid(ErrNumber, InStr(1, UCase(Trim(ErrNumber)), "ORA")))) 'ErrNumber
strErrDesc = ErrDesc
StrClientDesc = ErrClientDesc
StrComponent = ComponentName
StrUserID = UserId
StrMachineID = MachineID
StrBranchCode = UCase(Trim(Branchode))
Condition = " upper(trim(errornumber))='" & UCase(Trim(strErrNo)) & "' and upper(trim(oranarration))='" & UCase(Trim(strErrDesc)) & "'"

''Set objDBlink = objcontext.CreateInstance("SharedStaticValues.AcceptDBLink")
''DataLink = objDBlink.GetDBLink
''Set objDBlink = Nothing
''ArrLink = Split(DataLink, ",", -1)
''If UBound(ArrLink) < 2 Then
ReDim ArrError(0, 2) As Variant
''    ArrError(0, 0) = ArrLink(0)
''    ErrorProcess = ArrError
''    Exit Function
''ElseIf UBound(ArrLink) = 2 Then
''    DataLink = ""
''ElseIf UBound(ArrLink) = 3 Then
''    DataLink = Trim(ArrLink(3))
''End If
strquery = "Select ErrorNumber,OraNarration,ClientNarration from GENERRORMST where " _
 & " upper(trim(errornumber))='" & UCase(Trim(strErrNo)) & "'" '''' and upper(trim(oranarration))='" & UCase(Trim(strErrDesc)) & "'"
ConnError = ""
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=v3;Password=RamSmart2020;User ID=v3"
''''AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=v3;User ID=v3"
If AdoConnObj.State = 1 Then ConnError = "Connected"
Set RSError = CreateObject("Adodb.Recordset")

'Set ObjError = objcontext.CreateInstance("QueryRecordsets.FetchRecordsets")
Set RSError = AdoConnObj.Execute(strquery)
ReDim InsValues(0, 0) As Variant
ReDim ArrError(0, 2) As Variant
 If RSError.State = 1 Then
    Set ObjError = Nothing
    
    'Set ObjError = objcontext.CreateInstance("DataBaseTransactions.TransactionMethods")
    
    If RSError.EOF And RSError.BOF Then
    '''''''''Checking if an oracle error
'        If InStr(1, UCase(Trim(ErrNumber & ErrDesc)), "ORA") <> 0 Then
'                'strErrNo = ErrNumber
'                strErrDesc = ErrDesc
'
'        Else
'                'strErrNo = ErrNumber
'                strErrDesc = "NOT AN ORACLE ERROR"
'                StrClientDesc = ErrClientDesc
'        End If
        
        ''''' Insert a new record to the generrormst if the error was generated
        '''''for the first time
        
        TabName = "GenErrorMst"
        FldNames = "ErrorNumber,OraNarration,ClientNarration"
        
        InsValues(0, 0) = "'" & strErrNo & "','" & strErrDesc & "','" & strErrDesc & "'"
                            
                
         strquery = "Insert into GENERRORMST (" & FldNames & ") values (" & InsValues(0, 0) & ")"
        
        AdoConnObj.Execute strquery, resaff
        'Set ObjError = objcontext.CreateInstance("DataBaseTransactions.TransactionMethods")
        If resaff < 1 Then
            ArrError(0, 0) = ""
            ArrError(0, 1) = strResult
            ArrError(0, 2) = "Data Base Problem."
            ErrorProcess = ArrError
            objcontext.SetAbort
            Exit Function
        End If
        
'        FldNames = "ErrorNumber,ClientNarration,Branchcode, userid,machineid,systemdate,errordate,ErrorComponent"
'
'        InsValues(0, 0) = "'" & strErrNo & "', '" & StrClientDesc & "','" & StrBranchCode & "','" _
'        & StrUserID & "','" & StrMachineID & "', sysdate, to_date('" _
'        & Format(Now, "dd-mmm-yy HH:MM:SS") & "','dd-mon-yy HH24:mi:ss'), '" & StrComponent & "'"
'
'        strquery = "insert into GenErrorlog (" & FldNames & ") values (" & InsValues(0, 0) & ")"
'        'strResult = ObjError.InsertRecord("GenErrorlog", FldNames, InsValues)
'
'        AdoConnObj.Execute strquery, resaff
'             ''If strResult <> "Trans Completed" Then
'             If resaff < 1 Then
'                    ArrError(0, 0) = ""
'                    ArrError(0, 1) = strResult
'                    ArrError(0, 2) = "Data Base Problem."
'                    ErrorProcess = ArrError
'                    objcontext.SetAbort
'                    Exit Function
'            End If
        
        If RSError.State = 1 Then RSError.Close
        
        strquery = "Select ErrorNumber,OraNarration,ClientNarration from GENERRORMST where " _
        & " upper(trim(errornumber))='" & UCase(Trim(strErrNo)) & "'"
        
        Set RSError = AdoConnObj.Execute(strquery)
    End If
    
    
    ''''now inserting the error details into th errorlog table
        strErrNo = UCase(RSError!errornumber)
        strErrDesc = RSError!oranarration
        StrClientDesc = ErrClientDesc
        FldNames = "ErrorNumber,ClientNarration,Branchcode, userid,machineid,systemdate,errordate,ErrorComponent,ORACLENARRATION"

        InsValues(0, 0) = "'" & strErrNo & "', '" & StrClientDesc & "','" & StrBranchCode & "','" _
        & StrUserID & "','" & StrMachineID & "', sysdate, to_date('" _
        & Format(Now, "dd-mmm-yy HH:MM:SS") & "','dd-mon-yy HH24:mi:ss'), '" & StrComponent & "','" & OriginalOracleError & "'"
        
        strquery = "insert into GenErrorlog (" & FldNames & ") values (" & InsValues(0, 0) & ")"
        
        
        'strResult = ObjError.InsertRecord("GenErrorlog", FldNames, InsValues)
             'If strResult <> "Trans Completed" Then
             
             AdoConnObj.Execute strquery, resaff
             If resaff < 1 Then
                    ArrError(0, 0) = ""
                    ArrError(0, 1) = strResult
                    ArrError(0, 2) = "Data Base Problem. " & strResult
                    ErrorProcess = ArrError
                    objcontext.SetAbort
                    Exit Function
             End If
        
        
        
     
        objcontext.SetComplete
        ArrError(0, 0) = RSError!errornumber
        ArrError(0, 1) = RSError!oranarration
        ArrError(0, 2) = StrClientDesc
        
        Set ObjError = Nothing
        Set objcontext = Nothing
        ErrorProcess = ArrError
        Exit Function
Else
    GoTo ErrHand
End If

ErrHand:

objcontext.SetAbort
ArrError(0, 0) = Err.Number
ArrError(0, 1) = Err.Description
ArrError(0, 2) = Err.Description _
        & ". Error from GenErrorLog and the error occured at client transaction is " _
        & StrClientDesc
Set ObjError = Nothing
Set objcontext = Nothing
ErrorProcess = ArrError
Exit Function


End Function


Public Sub LogError(ApplName$, ProcName$, ErrNum&, ErrorMsg$)
  On Error GoTo ErrHandler
  Dim strErrLogPaht As String
  strErrLogPaht = "C:\Inetpub\wwwroot\eSmartdotnet\errorlog"
  
  If blnDebug = True Then
  Dim fso As New FileSystemObject
  
    Dim nUnit As Integer
    nUnit = FreeFile
    
    If fso.FolderExists(strErrLogPaht) = False Then
        fso.CreateFolder (strErrLogPaht)
    End If
    
    ' This assumes write access to the directory containing the program '
    ' You will need to choose another directory if this is not possible '
    Open "C:\Inetpub\wwwroot\eSmartdotnet\errorlog\" & ApplName$ & ".log" For Append As nUnit
    Print #nUnit, "Error in " & ProcName
    Print #nUnit, "  " & ErrNum & ", " & ErrorMsg
    
    Print #nUnit, "  " & Format$(Now)
    Print #nUnit, ""
    Close nUnit
  End If
  Exit Sub

ErrHandler:
  'Failed to write log for some reason.'
  'Show MsgBox so error does not go unreported '
  ''MsgBox "Error in " & ProcName & vbNewLine & _
    ErrNum & ", " & ErrorMsg
End Sub

