VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "CheckDate"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public Function GetDueDate(ArrDate As Variant, _
                           Optional BranchCode As String, Optional userid As String, _
                           Optional MachineId As String) As String

'Public Function GetDueDate(CurrentDate As String, Optional Days As Variant, _
'                           Optional Months As Variant, Optional Years As Variant, _
'                           Optional BranchCode As String, Optional userid As String, _
'                           Optional MachineId As String) As String
                           
'''' this funtion is for returning a due date based on the no. of days or months or years _
''''
On Error GoTo ErrHand
Dim ArrDtVal As Variant
Dim intYear As Double
Dim intMonths As Double
Dim intDays As Double
Dim CurrDate As Date
Dim DueDate As String
ArrDtVal = ArrDate
If UBound(ArrDtVal) <> 3 Then
    GetDueDate = "Please Send Proper Values"
    Exit Function
End If

CurrDate = Format(ArrDtVal(0), "dd-mmm-yyyy")
intYear = IIf(ArrDtVal(1) = "", 0, ArrDtVal(1))
intMonths = IIf(ArrDtVal(2) = "", 0, ArrDtVal(2))
intDays = IIf(ArrDtVal(3) = "", 0, ArrDtVal(3))

'''''If intDays = 0 And intMonths = 0 And intYear = 0 Then
'''''    GetDueDate = "One of the Parameters (Days or Months or Year) is required To get Due Date"
'''''    Exit Function
'''''End If

If intDays = 0 And intMonths = 0 And intYear = 0 Then
    GetDueDate = CStr(CurrDate)
    Exit Function
End If
DueDate = DateAdd("yyyy", intYear, CurrDate)
DueDate = DateAdd("m", intMonths, DueDate)
DueDate = DateAdd("d", intDays, DueDate)
GetDueDate = Format(DueDate, "dd-mmm-yyyy")
Exit Function

ErrHand:
GetDueDate = Err.Number & Err.Description
GetDueDate = Replace(GetDueDate, Chr(10), "")
GetDueDate = Replace(GetDueDate, Chr(13), "")
End Function


