VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "FetchRecordsets"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim objErrlog As Object
Public ConnError As String 'error string
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim AdoRs() As ADODB.Recordset   '    Multiple Recordset Objects
Dim Rstemp As ADODB.Recordset
Dim objdblink As Object
Dim objError As Object
Dim objTrans As Object
Dim ICount As Integer
Dim DataLink As String
Dim ArrLink As Variant
Dim StrCondition As String
Dim ConnTime As String
Dim BrCode As String
Dim MachID As String
Dim Userid As String
Dim arrerr As Variant
Dim errobj As Object
Dim objContext As ObjectContext
Dim strComponent As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim ArrError As Variant
Dim ErrNum As String
Dim errDesc As String
Dim strstack As String

Public Function RecordsetCollection(ArrRecRS As Variant) As Variant
Dim TempArr As Variant
Dim strquery As String
Dim recAff As Integer
'************Oppening the connection to dblink*************
On Error GoTo errhand

ConnError = ""

Call DBConnection
If ConnError <> "Connected" Then GoTo errhand

  '*************Connection oppened Sucessfully*************
   
  '***Fetching the multiple Recordsets.*******
  TempArr = ArrRecRS
  
  
  ReDim AdoRs(UBound(TempArr)) As ADODB.Recordset
       For ICount = 0 To UBound(TempArr)
          strquery = ""
          Set AdoRs(ICount) = CreateObject("adodb.recordset")
          strquery = "Select " & TempArr(ICount, 1) & " from  " & TempArr(ICount, 0) _
                   & DataLink & " where " & TempArr(ICount, 2)
          AdoRs(ICount).Open strquery, AdoConnObj, adOpenDynamic, adLockOptimistic
          
       Next ICount
       
       RecordsetCollection = AdoRs
       
       For ICount = 0 To UBound(TempArr)
       
            AdoRs(ICount).ActiveConnection = Nothing
       
       Next ICount
       
       
       If AdoConnObj.State = 1 Then AdoConnObj.Close
       Set AdoConnObj = Nothing
       Exit Function


errhand:

If ConnError = "" Then
'*************Connection Failed************
ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else
ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

objErrlog.LogError "QueryRecordsets", "RecordsetCollection", Err.Number, Err.Description

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function

End Function



'************    Function to return a Single Recordset.   *************************

Public Function SingleRecordSet(TabName As String, FldNames As String, _
                                Optional wherecondition As String, _
                                Optional OrderClause As String, _
                                Optional BranchCode As String, Optional UserCode As String, _
                                Optional MachineID As String, Optional CompName As String) As ADODB.Recordset

Dim strquery As String, strTables As String
Dim TableNames As Variant, TableAlias As Variant
Dim BrCode As String, Userid As String, MachID As String
Dim subCnt As Integer
Dim SubQryTabName As Variant
Dim tabSubQry As Variant

'************Oppening the connection to dblink*************


On Error GoTo errhand


ConnError = ""


Call DBConnection

If ConnError <> "Connected" Then GoTo errhand

'''*************Connection oppened Sucessfully*************

'''*************Forming the sql select query*************
BrCode = IIf(IsNull(Trim(BranchCode)), "", UCase(Trim(BranchCode)))
Userid = IIf(IsNull(Trim(UserCode)), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(Trim(MachineID)), "", UCase(Trim(MachineID)))
strComponent = IIf(IsNull(Trim(CompName)), "", UCase(Trim(CompName)))
'StrCondition = IIf(IsNull(trm(WhereCondition)), "", Trim(WhereCondition))
TableNames = Split(TabName, ",", -1)
If UBound(TableNames) < 1 Then
strTables = Trim(TableNames(0)) & DataLink & " "
Else
strTables = ""
For ICount = 0 To UBound(TableNames)
TableAlias = Split(Trim(TableNames(ICount)), " ", -1)
strTables = strTables & Trim(TableAlias(0)) & DataLink & " " & Trim(TableAlias(1)) & ","

Next

strTables = Left(strTables, Len(strTables) - 1)
End If
StrCondition = ""
''''' Cheking for Sub query to concantinate the tablename with dblink
If Trim(wherecondition) <> "" Then
SubQryTabName = Split(UCase(wherecondition), UCase(" from "), -1)
    If UBound(SubQryTabName) > 0 And Trim(DataLink) <> "" Then
        StrCondition = Trim(SubQryTabName(0)) & " from "
        For subCnt = 1 To UBound(SubQryTabName)
            tabSubQry = Split(UCase(SubQryTabName(subCnt)), " WHERE ", -1)
            StrCondition = StrCondition & Trim(tabSubQry(0)) & DataLink & " where " & tabSubQry(1) & " "
            subCnt = subCnt + 1
            If subCnt <= UBound(SubQryTabName) Then
                tabSubQry = Split(UCase(SubQryTabName(subCnt)), " WHERE ", -1)
                StrCondition = StrCondition & Trim(tabSubQry(0)) & DataLink & " where " & tabSubQry(1) & " "
            End If
        Next
    Else
        StrCondition = wherecondition
    End If
End If


          strquery = ""
          If Trim(wherecondition) <> "" And Trim(OrderClause) <> "" Then
            
            strquery = "Select " & FldNames & " from  " & strTables _
                     & " where " & StrCondition & " order by " & OrderClause
                     
          ElseIf Trim(OrderClause) <> "" And Trim(wherecondition) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                      & " order by " & OrderClause
                      
          ElseIf Trim(wherecondition) <> "" And Trim(OrderClause) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                      & " where " & StrCondition
           
                      
          ElseIf Trim(wherecondition) = "" And Trim(OrderClause) = "" Then
            strquery = "Select " & FldNames & " from  " & strTables _
                    
          End If
          
                 
'''*************Opening the Recordset.*************
  
          Set Rstemp = AdoConnObj.Execute(strquery)
'''''''''''Closing the connection if only for querying, but for modification the _
'''''''''''connetion is in open status.
          If UCase(Trim(Right(strquery, 10))) <> "FOR UPDATE" Then
''            If AdoConnObj.State = 1 Then AdoConnObj.Close
''            Set AdoConnObj = Nothing
          End If
          ''Rstemp.ActiveConnection = False
          
          
        If Rstemp.State = 1 Then
            Set SingleRecordSet = Rstemp
           
           '*************Returned a Recordset to the Client Application*************
        Else
            ConnError = "Records Could Not Be Retrieved For your Query"
           
        End If

        Rstemp.ActiveConnection = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
        
        Exit Function
            
errhand:
strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

objErrlog.LogError "QueryRecordsets", "SingleRecordSet", Err.Number, Err.Description & " Stack: " & strstack & "  SQL Query: " & strquery
''If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

If ConnError <> "Connected" Then

'*************Connection Failed************
    If Err.Number = 0 Then
        '''''ConnError = "Connection Failed !"
        ConnError = ConnError
    Else
        ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description & " : " & strTables
    End If
Else
        If strComponent = "" Then
        strComponent = "QUERYRECORDSETS.FETCHRECORDSET / SINGLERECORDDSET"
        End If
        
        If Err.Number = -2147467259 Then
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Oracle Error"
        ElseIf UCase(Trim(Left(Err.Description, 3))) = "ORA" Then
            ErrNum = UCase(Mid(Trim(Err.Description), 1, InStr(1, Err.Description, ":")))
            errDesc = UCase(Mid(Trim(Err.Description), InStr(1, Err.Description, ":")))
            clntDesc = "Oracle Error"
            
        Else
            ErrNum = Err.Number
            errDesc = Err.Description
            clntDesc = "Client Error " & Err.Description
        End If
    clntDesc = "Records Could Not Be Retrieved Due to " & errDesc & " : " & strTables
    Set objError = CreateObject("TrapError.ErrorDescription")
    If errDesc = "" Then
    errDesc = "abc"
    End If
    ArrError = objError.ErrorProcess(ErrNum, errDesc, clntDesc & " : Stack : " & Replace(strstack, "'", "''") & " SQL Query :  " & Replace(strquery, "'", "''"), strComponent, BrCode, Userid, MachID)
    '''''*************RecordSet Not oppened************
     Set objError = Nothing
     ReDim ArrError(0, 2)
        ConnError = ArrError(0, 2) & " : " & strTables
  
End If

End Function

Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String

strSupreUserPassword = "RamSmart2020"
strUserid = "v3"
strDataSource = "v3"
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
    
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:
strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserid = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "QueryRecordsets", "DBConnection" & strLineno, Err.Number, Err.Description & " : Stack : " & strstack

   
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objErrlog.ErrorProcess(ErrNum, errDesc, " : Stack : " & Replace(strstack, "'", "''"), strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Set objError = Nothing

End Sub

Public Function ModifyQueriedTrans(TableName As String, FldNames As String, _
                             ArrValues As Variant, Optional wherecondition As String, _
                             Optional BranchCode As String, Optional UserCode As String, _
                             Optional MachineID As String) As String

Dim RecAffect As Integer
Dim ArrTempValues As Variant, ArrRowValue As Variant, ArrFlds As Variant, strquery As String
Dim Strupdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, StrCondition As Variant, StrTabName As String, StrFields As String
'************Oppening the connection to DataLink*************
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then ModifyQueriedTrans = ConnError: Exit Function

  '*************Connection oppened Sucessfully*************
ArrTempValues = ArrValues
StrTabName = UCase(Trim(TableName))
StrFields = FldNames
BrCode = IIf(IsNull(UCase(Trim(BranchCode))), "", UCase(Trim(BranchCode)))
Userid = IIf(IsNull(UCase(Trim(UserCode))), "", UCase(Trim(UserCode)))
MachID = IIf(IsNull(UCase(Trim(MachineID))), "", UCase(Trim(MachineID)))
'****** Spliting the conditions For Different Rows
StrCondition = Split(wherecondition, "|", -1)

If Trim(wherecondition) = "" Then
ReDim StrCondition(0) As Variant
StrCondition(0) = ""
End If

For RowCnt = 0 To UBound(ArrTempValues)
RecAffect = 0

''''' First passing the data into history tables based on the type of tables.
If UBound(StrCondition) = UBound(ArrTempValues) Then

    If Right(Trim(StrTabName), 3) = "MST" Or Right(Trim(StrTabName), 3) = "TRN" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST" & DataLink & " select * from " _
        & StrTabName & "" & DataLink & " Where " & StrCondition(RowCnt)
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "DEM" & DataLink & " select * from " _
        & StrTabName & "" & DataLink & " Where " & StrCondition(RowCnt)
    Else
        StrInsert = ""
    End If
    
    strquery = "select " & StrFields & " from " & Trim(StrTabName) & DataLink & " where " _
    & StrCondition(RowCnt) & " for update"
    
    
Else
    
    If Right(Trim(StrTabName), 3) = "MST" Or Right(Trim(StrTabName), 3) = "TRN" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST" & DataLink & " select * from " _
        & StrTabName & "" & DataLink & ""
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
         StrInsert = "Insert into " & Trim(StrTabName) & "DEM" & DataLink & " select * from " _
        & StrTabName & "" & DataLink & ""
    Else
        StrInsert = ""
    End If
    
    strquery = "select " & StrFields & " from " & Trim(StrTabName) & DataLink & " for update"
    
   
    
End If

If Trim(StrInsert) <> "" Then AdoConnObj.Execute StrInsert

'AdoConnObj.Execute strquery
'****** Spliting the Collumn Names (Fields) to build the Update Statement

ArrFlds = Split(StrFields, ",", -1)
    
'****** Spliting the Collumn Values (Fields Values) to build the Update Statement
ArrRowValue = Split(ArrTempValues(RowCnt), "~", -1)
        
  '*******  first concantinating the values for update ***********
    For ColCnt = 0 To UBound(ArrFlds)
        
 
       strUpdateRow = strUpdateRow & ArrFlds(ColCnt) & "=" & ArrRowValue(ColCnt) & ","
    
    Next ColCnt
    
  '******* Now building the The Update statement ********
    ''''If StrCondition(RowCnt) <> "" Then
    If UBound(StrCondition) = UBound(ArrTempValues) Then
      
       Strupdate = "update " & StrTabName & "" & DataLink & " set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1) _
                    & " where " & StrCondition(RowCnt)
       
    Else
    
        Strupdate = "update " & StrTabName & "" & DataLink & " set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1)
    
    End If
    
    '***** Executing the update statement Based On Number of Rows ********'
         AdoConnObj.Execute Strupdate, RecAffect
         Strupdate = ""
         strUpdateRow = ""
If RecAffect = 0 Then
    ModifyQueriedTrans = "Update Failed due to False Condition !"
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
End If
Next RowCnt

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing

ModifyQueriedTrans = "Trans Completed"
Exit Function

errhand:

strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile

objErrlog.LogError "QueryRecordsets", "ModifyQueriedTrans", Err.Number, Err.Description & _
" : Stack : " & strstack & " : SQL Query : " & strquery & " : Insert : " & StrInsert & " : Update : " & Strupdate


ModifyQueriedTrans = "Records Could Not Be Updated Due to : " & Err.Number & " : " & Err.Description & " ! " & StrTabName
ModifyQueriedTrans = Replace(ModifyQueriedTrans, Chr(10), "")
ModifyQueriedTrans = Replace(ModifyQueriedTrans, Chr(13), "")

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
End Function

Public Function Modify(BlnModify As Boolean, Optional arrTabDetails As Variant) As String
Dim arrTran As Variant
Dim strquery As String
Dim recAff As Integer
On Error GoTo errhand
Set objContext = GetObjectContext
If BlnModify = True Then
    arrTran = arrTabDetails
    If UBound(arrTran) > 1 Then
    'Set objContext = GetObjectContext
        strquery = " update " & Trim(arrTran(0)) & DataLink & " set " & Trim(arrTran(1)) _
        & " where " & arrTran(2)
    Else
        strquery = " update " & Trim(arrTran(0)) & DataLink & " set " & Trim(arrTran(1))
    End If
    
Call DBConnection

    If AdoConnObj.State = 1 Then
    AdoConnObj.Execute strquery, recAff
    End If
    If recAff > 0 Then
        
        objContext.SetComplete
        Modify = "Modification Completed"
    Else
        objContext.SetAbort
        Modify = " Modification Aborted due to false condition."
    End If
Else
    objContext.SetAbort
    Modify = "Modification Canceled"
End If
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Set objContext = Nothing
    Exit Function
    
errhand:

strstack = "Error Number: " & Err.Number & " Error Description: " & Err.Description & _
" Source: " & Err.Source & " Last Dll Error: " & Err.LastDllError & " Help Context: " & Err.HelpContext & _
" Help File: " & Err.HelpFile


objErrlog.LogError "QueryRecordsets", "Modify", Err.Number, Err.Description & " : Stack : " & strstack & " :  Update : " & strquery

Modify = Err.Number & Err.Description
Modify = Replace(Modify, Chr(10), "")
Modify = Replace(Modify, Chr(13), "")
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
