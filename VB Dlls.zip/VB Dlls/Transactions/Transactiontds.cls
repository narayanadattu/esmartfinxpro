VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "Transactiontds"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim objContext As ObjectContext
Dim ObjTrans As Object
Dim objQuery As Object
Dim strInsDel As String
Dim strRec As String
Dim dblScrAmount As Double

'--------------------------------------------------------------------------------------------
Dim batchno, tranno, GLCode, GLDesc, AccNo, Name, Amount, EntTimeBal, ApplDate, CustId, _
    ModeofTran, Status, curcode, EnteredBy, EnteredMC, ModuleId, brcode, TokenNo, _
    Narration, ChqSrs, ChqNo, ChqDate, ChqFVG, SysGenYN, EffDate, ClgRateType, Rate, _
    FCurrCode, FAmount, LinkModId, LinkGLCode, LinkAccType, LinkAccNo, ServiceId, _
    RespBrCode, RespSectCode, DispBatchNo, DispTranNo, AccChkYN, ExcpYN, ExcpCodes, _
    dblApprTimeBal, ApprovedBy, ApprovedMC, Verifiedby, VerifiedMechine, RespBnkCode, CounterNo, CashierId, ScrollNo, _
    Remisonbank, Remisonbrn, Fvgcr, InstrdateCr, Remcustid, Comm, CommTranno, ApplName, _
    RemType, SusConDate, SusConBatch, SusConTranno, SusConCom, Crinstype, Drinstype, _
    DrInstrno, Remisbybank, Remisbybrn, Fvgdr, InstrdateDr, Advno, AdvrecYN, Advrdate, _
    native, CatCode, FRateRefCode, FRateRefDesc As Variant
    Dim loanintcr, loannpacr, loanchrgcr, loaninsurcr, loanexcesscr, loanprinciplecr, _
    loancredit, loanintdr, loannpadr, loanchrgdr, loaninsurdr, loanprncpledr, _
    loanexcessdr As Variant
    Dim strinstrtype As String
    Dim SrvCharge, SrvChargeTranNo, LinkAccName As Variant
    
    Dim sAccBranchCode As String, ABBYN As String
    
    Dim lockerPaiddate, lockerNextduedate As String
    ''''----- variables for CLG Module
    ''''---- for CLGOutward Presentation
    Dim voucherno, ClearingType, LodgementDate As String
    ''''for CLG InwardReturns
    Dim InstrNo, BankCode, PresBranchcode, ClgBranchcode As String
    Dim StandInstrYN, SIFromDate, SIToDate, SIAccNo, SITranType, SIRemType As Variant
    Dim Reasoncode As String
    Dim ABBbranchCode, ABBApplDt As String
    'Dim abbtranno As Double
    
    '********** Variables for Deposit Interest Posting ****************
    Dim DepGL As String, DepAccNo As String, DepAccROI As Double
    Dim DepAccIntCalcFromDt As Date, DepAccIntCalcToDt As Date, DepModule As String
    Dim DepAccLastIntApplDt As Date, DepAccIntAmt As Double, DepAccBal As Double
    


Public Function TranInserttds(arrgrid As Variant, arrgridtds As Variant, Optional arrDenoms As Variant, _
Optional ByVal IsItDirectTran As Boolean = False) As String

Dim recDel As ADODB.Recordset, recTrnTab As ADODB.Recordset, recModTypes As ADODB.Recordset, _
strCashPYN As String, strDel As String, strTrnsLog As String, strWhrCond As String, _
strTrnTab As String, strMstTab As String, strTrnFld As String, strTrnWhCond As String, _
introws As Integer, strTabName As String, strTnameMod As String, strFldMod As String, _
strWhCndMod As String, strFldTrn As String, arrFldVal(0) As Variant, strTrnsTab As String, _
strTransFld As String, arrTransVal(0) As Variant, TempTransValArr(0) As Variant

Dim introwstds As Integer


Dim strRemArr() As String
Dim batchnotds1, trannotds1, GLCodetds1, AccNotds1, brcodetds1, curcodetds1, tranDatetds1 As Variant



Dim batchnotdsval1, trannotdsval1, brcodetdsval1, paiddateval1 As Variant
Dim strtdsdtls As String
Dim strFldtdsdtls As String
Dim arrFldtdsdtls(0) As Variant

Dim strWhrCondtdsdtls As String
Dim strInstdsdtls As String

'--------------------------------------------------------------------------------------------

On Error GoTo errhand
    '-------Assigning values to variables
 'MsgBox " Point 344"
    strCashPYN = "N"
   
    strTrnsLog = "GENTEMPTRANSLOG"
    strFldTrn = "transtatus"
    arrFldVal(0) = "'D'"

    strTnameMod = "GENMODULETYPESMST"
    strFldMod = "implementedyn"
    
    strTrnsTab = "GENTRANSLOG"
    
    strTransFld = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,MODULEID,batchno,TRANNO,GLCODE," & _
                  "ACCNO,NAME,CUSTOMERID,AMOUNT,TOKENNO,MODEOFTRAN,ENTEREDTIMEBAL,APPROVEDTIMEBAL," & _
                  "DAYENDBAL,TRANSTATUS,SERVICEID,REMARKS,CASHPAIDYN,CASHIERID,USERID," & _
                  "MACHINEID,APPROVEDBY,APPROVEDMACHINE,VERIFIEDBY," & _
                  "VERIFIEDMACHINE,SYSTEMDATE,CHQNO,CHQSERIESNO,CHQFVG,CHQDATE," & _
                  "SYSTEMGENERATEDYN,EFFECTIVEDATE,CLGRATETYPE,RATE,FCURRENCYCODE," & _
                  "FAMOUNT,LINKMODULEID,LINKGLCODE,LINKACCNO,LINKACCTYPE,EXCEPTIONYN," & _
                  "RESPONDINGBANKCODE,RATEREFCODE,ABBBRANCHCODE,ABBAPPLICATIONDATE,ABBYN"
                  
    Set objContext = GetObjectContext
    Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    
 '----------------------------------------
   For introws = 0 To UBound(arrgrid) - 1
   
       batchno = Trim(arrgrid(introws, 0))
       tranno = Trim(arrgrid(introws, 1))
       GLCode = Trim(arrgrid(introws, 2))
       GLDesc = Trim(arrgrid(introws, 3))
       AccNo = Trim(arrgrid(introws, 4))
       Name = Trim(arrgrid(introws, 5))
       Amount = Trim(arrgrid(introws, 6))
       EntTimeBal = Trim(arrgrid(introws, 7))
       ApplDate = Trim(arrgrid(introws, 8))
       CustId = Trim(arrgrid(introws, 9))
       ModeofTran = Trim(arrgrid(introws, 10))
        
       ABBApplDt = Trim(arrgrid(introws, 12))
       Status = Trim(arrgrid(introws, 13))
       curcode = Trim(arrgrid(introws, 14))
       EnteredBy = Trim(arrgrid(introws, 15))
       EnteredMC = Trim(arrgrid(introws, 16))
       ModuleId = Trim(arrgrid(introws, 17))
       brcode = Trim(arrgrid(introws, 18))
       TokenNo = Trim(arrgrid(introws, 19))
       Narration = Trim(arrgrid(introws, 20))
       
       ChqSrs = Trim(arrgrid(introws, 21))
       ChqNo = Trim(arrgrid(introws, 22))
       ChqDate = Trim(arrgrid(introws, 23))
       ChqFVG = Trim(arrgrid(introws, 24))
       SysGenYN = Trim(arrgrid(introws, 25))
       EffDate = Trim(arrgrid(introws, 27))
       
       ABBYN = "N"
       On Error Resume Next
       ABBYN = Trim(arrgrid(introws, 100))
       If ABBYN = "" Then ABBYN = "N"
       On Error GoTo errhand
       
      If ModuleId = "MISC" And ModeofTran = "3" Then

        paiddateval1 = ApplDate
        brcodetdsval1 = brcode
        batchnotdsval1 = batchno
        trannotdsval1 = tranno

    End If


      
       '--------- for Forex
       ClgRateType = Trim(arrgrid(introws, 28))
       Rate = Trim(arrgrid(introws, 29))
       FCurrCode = Trim(arrgrid(introws, 30))
       
       FAmount = Trim(arrgrid(introws, 31))
       LinkModId = Trim(arrgrid(introws, 32))
       LinkGLCode = Trim(arrgrid(introws, 34))
       LinkAccType = Trim(arrgrid(introws, 36))
       LinkAccNo = Trim(arrgrid(introws, 37))
       LinkAccName = Trim(arrgrid(introws, 38))
       '---------abbbranch=Trim(arrgrid(introws, 40))
        
       ServiceId = Trim(arrgrid(introws, 39))
       RespBrCode = Trim(arrgrid(introws, 41))
       RespSectCode = Trim(arrgrid(introws, 43))
       ABBbranchCode = Trim(arrgrid(introws, 45))
       DispBatchNo = Trim(arrgrid(introws, 47))
       DispTranNo = Trim(arrgrid(introws, 48))
       AccChkYN = Trim(arrgrid(introws, 49))
       ExcpYN = Trim(arrgrid(introws, 50))
       ExcpCodes = Trim(arrgrid(introws, 51))
       RespBnkCode = Trim(arrgrid(introws, 52))
       StandInstrYN = Trim(arrgrid(introws, 54))
       CounterNo = Trim(arrgrid(introws, 55))
       CashierId = Trim(arrgrid(introws, 56))
       ScrollNo = Trim(arrgrid(introws, 57))
       FRateRefCode = Trim(arrgrid(introws, 58))
       FRateRefDesc = Trim(arrgrid(introws, 59))
       strinstrtype = Trim(arrgrid(introws, 63))
       
   'If AccChkYN = "N" Then
   
'   If ServiceId = "2" Or ServiceId = "3" Then
'        CashierId = Trim(arrgrid(introws, 56))
'        ApplName = Trim(arrgrid(introws, 60))
'        CatCode = Trim(arrgrid(introws, 61))
'   End If
    
   If UCase(Trim(ModuleId)) = "REM" And _
   (ModeofTran = "3" Or ModeofTran = "1" Or ModeofTran = "5") Then
        AdvrecYN = arrgrid(introws, 64)
        Remisbybank = arrgrid(introws, 52)
        Remisbybrn = arrgrid(introws, 60)
        Fvgdr = arrgrid(introws, 62)
        DrInstrno = arrgrid(introws, 63)
        Advno = arrgrid(introws, 65)
        Advrdate = arrgrid(introws, 66)
        InstrdateDr = arrgrid(introws, 67)
        Drinstype = arrgrid(introws, 68)
        native = arrgrid(introws, 69)
       
    ElseIf UCase(Trim(ModuleId)) = "REM" And (ModeofTran = "4" Or ModeofTran = "2") Then
        Remisonbank = arrgrid(introws, 52)
        Remisonbrn = arrgrid(introws, 60)
        Fvgcr = arrgrid(introws, 62)
        InstrdateCr = arrgrid(introws, 8)
        Remcustid = arrgrid(introws, 65)
        'code commented by Radhika on 21 May 2008
        'Reason: we may also had Service charge along with commission.
        '  and both the values are separated by Comma symbol. So Split them
        'Comm = arrgrid(introws, 64)
        'CommTranno = arrgrid(introws, 67)
        'New code written by Radhika on 21 May 2008
        If Trim(arrgrid(introws, 67)) = "" Then
            Comm = ""
            CommTranno = ""
            SrvCharge = ""
            SrvChargeTranNo = ""
        Else
            'Commission and service charge amounts
            strRemArr = Split(arrgrid(introws, 64), ",")
            Comm = strRemArr(0)
            If UBound(strRemArr) >= 1 Then
                SrvCharge = strRemArr(1)
            End If
            
            'Commission and service charge Tran numbers
            strRemArr = Split(arrgrid(introws, 67), ",")
            CommTranno = strRemArr(0)
            If UBound(strRemArr) >= 1 Then
                SrvChargeTranNo = strRemArr(1)
            End If
        End If
        'End of New code written by Radhika on 21 May 2008
        
        ApplName = arrgrid(introws, 66)
        Crinstype = arrgrid(introws, 68)
        
'    ElseIf UCase(Trim(ModuleId)) = "FXREM" And (ModeofTran = "4" Or ModeofTran = "2") Then
'        RemType = arrgrid(introws, 60)
'        Fvgcr = arrgrid(introws, 61)
'        Comm = arrgrid(introws, 64)
'        ApplName = arrgrid(introws, 63)
'        CommTranno = arrgrid(introws, 67)
'        Crinstype = arrgrid(introws, 65)
'
'    ElseIf (UCase(Trim(ModuleId)) = "SCR" And ((ModeofTran = "3") Or (ModeofTran = "1"))) Then
'
'
'
'        SusConDate = arrgrid(introws, 60)
'        SusConBatch = arrgrid(introws, 61)
'        SusConTranno = arrgrid(introws, 62)
'        SusConCom = arrgrid(introws, 71)
'
'
'    ElseIf (UCase(Trim(ModuleId)) = "SCR" And (ModeofTran = "4" Or ModeofTran = "2" Or ModeofTran = "6")) Then
'        SusConDate = arrgrid(introws, 60)
'        SusConBatch = arrgrid(introws, 61)
'        SusConTranno = arrgrid(introws, 62)
'        SusConCom = arrgrid(introws, 71)
    
    End If
    
  If UCase(Trim(ModuleId)) = "LOAN" And (ModeofTran = "2" Or ModeofTran = "4") Then
        loanintcr = arrgrid(introws, 60)
        loanchrgcr = arrgrid(introws, 61)
        loaninsurcr = arrgrid(introws, 62)
        loannpacr = arrgrid(introws, 63)
        loanprinciplecr = arrgrid(introws, 64)
        loanexcesscr = arrgrid(introws, 65)
        
        
  ElseIf UCase(Trim(ModuleId)) = "LOAN" And (ModeofTran = "1" Or ModeofTran = "3") Then
        loancredit = arrgrid(introws, 60)
  End If
    
'  'for CLG MOdule for clearing presentation------------------------------------------------
'  If UCase(arrgrid(introws, 79)) = "CLEARING" Then
'        voucherno = arrgrid(introws, 60)
'        LodgementDate = arrgrid(introws, 63)
'        ClearingType = arrgrid(introws, 64)
'        PresBranchcode = arrgrid(introws, 65)
'  End If
'  'for CLG MOdule for clearing Inwardreturns------------------------------------------------
'  If UCase(arrgrid(introws, 79)) = "INWARDRETURNS" Then
'        BankCode = ""
'        voucherno = arrgrid(introws, 70)
'        LodgementDate = arrgrid(introws, 64)
'        ClearingType = arrgrid(introws, 63)
'        InstrNo = arrgrid(introws, 62)
'        BankCode = arrgrid(introws, 68)
'        ClgBranchcode = arrgrid(introws, 72)
'        PresBranchcode = arrgrid(introws, 41)
'
'   End If
' If UCase(arrgrid(introws, 79)) = "CLGOWRETURN" Then
' 'for CLG MOdule for clearing outwardreturns-------------------------------------------
'
'        BankCode = ""
'        BankCode = UCase(Trim(arrgrid(introws, 60)))
'        PresBranchcode = UCase(Trim(arrgrid(introws, 61)))
'        Reasoncode = arrgrid(introws, 62)
'  '''--------------------------------------------------------------------
'  End If
  If UCase(arrgrid(introws, 79)) = "TPAY" Then
        dblApprTimeBal = Trim(arrgrid(introws, 7))
        Status = "A"
     '  CashierId = Trim(arrgrid(introws, 15))
        ApprovedBy = Trim(arrgrid(introws, 15))
        ApprovedMC = Trim(arrgrid(introws, 16))
        
        Dim recBank As ADODB.Recordset
        Set recBank = CreateObject("adodb.recordset")
        Set recBank = objQuery.SingleRecordSet("GENBANKPARM", "TELLERVERIFYREQYN", "")
        
        ''if second officer approval not required
        If recBank("TELLERVERIFYREQYN") = "N" Then
            Verifiedby = Trim(arrgrid(introws, 15))
            VerifiedMechine = Trim(arrgrid(introws, 16))
        End If
        
        Set recBank = Nothing
        
  End If
  'End If
  
  If AccChkYN = "Y" Then
  
    If UCase(LinkModId) = "LOCKER" Then
        lockerPaiddate = Trim(arrgrid(introws, 86))
        lockerNextduedate = Trim(arrgrid(introws, 87))
    End If
  End If
  If UCase(StandInstrYN) = "Y" Then
      SITranType = Trim(arrgrid(introws, 60))
      SIFromDate = Trim(arrgrid(introws, 66))
      SIToDate = Trim(arrgrid(introws, 67))
      SIAccNo = Trim(arrgrid(introws, 68))
  End If
  
  '======================================================================================
  
    strWhrCond = "trim(upper(branchcode))='" & UCase(brcode) & _
                "' and trim(upper(currencycode))='" & UCase(curcode) & "' and " & _
                "trim(batchno)='" & CDbl(Trim(batchno)) & "' and trim(tranno)='" & _
                CDbl(Trim(tranno)) & "'"
                
    strTrnTab = "GENMODULEMST"
    strTrnFld = "trandaytable,mastertable"
    strTrnWhCond = "upper(moduleid)='" & UCase(Trim(ModuleId)) & "'"
    
    'code commented by Radhika on 19-sep-2007
    'Reason: While checking module implemented yes/no, consider branch code
    'strWhCndMod = "upper(moduleid)='" & UCase(Trim(ModuleId)) & "'"
    strWhCndMod = "upper(moduleid)='" & UCase(Trim(ModuleId)) & "'" & _
        " and trim(upper(branchcode))='" & UCase(brcode) & "'"
    
    ApplDate = Format(CDate(ApplDate), "dd-mmm-yyyy")
    
    If IsDate(ChqDate) Then
    ChqDate = Format(CDate(ChqDate), "dd-mmm-yyyy")
    End If
    
    If IsDate(EffDate) Then
    EffDate = Format(CDate(EffDate), "dd-mmm-yyyy")
    End If
    
    If IsDate(ABBApplDt) Then
    ABBApplDt = Format(CDate(ABBApplDt), "dd-mmm-yyyy")
    End If
  '-------Storing field names and values for GenTranslog and Tranday tables
     
    'Code altered by Radhika on 20 May 2008
    'Reason: New column ABBYN was introduced into all transaction related tables
                      
    arrTransVal(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & ModuleId & _
                     "','" & batchno & "','" & tranno & "','" & GLCode & "','" & AccNo & _
                     "','" & Name & "','" & CustId & "','" & Amount & "','" & TokenNo & _
                     "','" & ModeofTran & "','" & EntTimeBal & "','" & dblApprTimeBal & _
                     "','','" & Status & "','" & ServiceId & "','" & Narration & "','" & _
                     strCashPYN & "','" & CashierId & "','" & EnteredBy & "','" & _
                     EnteredMC & "','" & ApprovedBy & "','" & ApprovedMC & "','" & Verifiedby & _
                     "','" & VerifiedMechine & "'," & _
                     "sysdate,'" & ChqNo & "','" & ChqSrs & "','" & ChqFVG & "','" & _
                     ChqDate & "','" & UCase(SysGenYN) & "','" & EffDate & "','" & _
                     ClgRateType & "','" & Rate & "','" & FCurrCode & "','" & FAmount & "','" & _
                     LinkModId & "','" & LinkGLCode & "','" & LinkAccNo & "','" & _
                     LinkAccType & "','" & ExcpYN & "','" & RespBnkCode & "','" & _
                     FRateRefCode & "','" & ABBbranchCode & "','" & ABBApplDt & "','" & _
                     UCase(IIf(ABBYN = "", "N", ABBYN)) & "'"
                    
 '-------Updating gentemptranslog
    If IsItDirectTran = False Then
           Dim strWhrCondForTTLog As String
           
           strWhrCondForTTLog = strWhrCond & " and transtatus='P'"
           
           strInsDel = ObjTrans.UpdateRecord(strTrnsLog, strFldTrn, arrFldVal(), strWhrCondForTTLog)
              ''''MsgBox strInsDel
              If strInsDel <> "Trans Completed" Then
                 GoTo errhand
              End If
    End If
  
 '--------Getting tranday,master table based on moduleid
 
        Set recTrnTab = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recTrnTab = objQuery.SingleRecordSet(strTrnTab, strTrnFld, strTrnWhCond)
   
        If objQuery.ConnError <> "Connected" Then
           GoTo errhand
        End If
        
        If recTrnTab.RecordCount > 0 Then
           strTrnTab = recTrnTab(0)
           strMstTab = UCase(Format(recTrnTab!mastertable))
        Else
           TranInserttds = "Table does not exist"
           objContext.SetAbort
           Exit Function
        End If
                     
'--------Checks whether the module is  implemented or not
        
        Set recModTypes = objQuery.SingleRecordSet(strTnameMod, strFldMod, strWhCndMod)
    
        If objQuery.ConnError <> "Connected" Then
           GoTo errhand
        End If
        If recModTypes.RecordCount > 0 Then
           If UCase(recModTypes!implementedyn) = "Y" Then
'--------Checks wether the Account or GL is running or not
        If ServiceId = "1" Then 'Or ServiceId = "4" Or ServiceId = "8" Then
            If UCase(Trim(ModuleId)) <> "FXREM" Then
                strRec = AccountAndGLCheck(strMstTab)
           
                If strRec <> "Sucessfully Completed" Then
                   strInsDel = strRec & ".... Batch No : " & batchno & " Cannot be Posted"
                   GoTo errhand
                End If
            End If
        End If

'--------If module is implemented then, Inserting into gentranslog and respective tranday tables
'--------------------------------------------------------------------------------------------
            strInsDel = ObjTrans.InsertRecord(strTrnsTab, strTransFld, arrTransVal)
            ''''MsgBox strInsDel
               If strInsDel <> "Trans Completed" Then
                  GoTo errhand
               End If
            strInsDel = ObjTrans.InsertRecord(strTrnTab, strTransFld, arrTransVal)
            ''''MsgBox strInsDel
               If strInsDel <> "Trans Completed" Then
                  GoTo errhand
               End If
'--------------------------------------------------------------------------------------------
'--------Exception Transactoin Handling

           If ExcpYN = "Y" Then
           Dim ExcpTran As String
               ExcpTran = ExcepTransacton()
               If ExcpTran <> "Sucessfully Completed" Then
                  strInsDel = ExcpTran
                  GoTo errhand
               End If
           End If
'--------------------------------------------------------------------------------------------
'Inserting Cheque Details

        'This line of code was commented by Radhika on 04-aug-2007
        'Reason: Cheque series number is not a mandatory column
        'If ChqSrs <> "" And ChqNo <> "" And ChqDate <> "" And ServiceId <> "8" Then
        If ChqNo <> "" And ChqDate <> "" And ServiceId <> "8" Then
           
            strRec = ChequeDetails
            If strRec <> "Sucessfully Completed" Then
               strInsDel = strRec
               GoTo errhand
            End If
               
        End If
        
'--------------------------------------------------------------------------------------------
'For Non Disposal Transactions i.e Ordinary Transactions directly done from Transactions Screen
' If AccChkYN = "N" Then

    'If ServiceId = "1" Or ServiceId = "9" Then
    If ServiceId = "1" Then
         'For Clearing
       '  If UCase(arrgrid(introws, 79)) = "CLEARING" Or UCase(arrgrid(introws, 79)) = "INWARDRETURNS" Then
           
       '''for clearing presentation calling a function to do transactions
'            If UCase(arrgrid(introws, 79)) = "CLEARING" Then
'
'                        strRec = CLGPresentaion()
'                        If strRec <> "Sucessfully Completed" Then
'                           strInsDel = strRec
'                           GoTo errhand
'                        End If
'            End If
    '-----------------------
    '''for clearing InwardReturns calling a function to do transactions
'            If UCase(arrgrid(introws, 79)) = "INWARDRETURNS" Then
'                strRec = CLGInwardReturn()
'                If strRec <> "Sucessfully Completed" Then
'                   strInsDel = strRec
'                   GoTo errhand
'                End If
'            End If
      '  Else
       
       'For Others
'        If UCase(arrgrid(introws, 79)) = "TPAY" Then
'           strRec = TellerPayments()
'
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'
'        End If
'        If UCase(Trim(ModuleId)) = "CASH" And ModeofTran = "1" Then
'
'            'Hold Branch code of selected Account
'            If ABBYN = "Y" Then
'
'                If introws > 0 Then
'                    sAccBranchCode = Trim(arrgrid(introws - 1, 18))
'                Else
'                    sAccBranchCode = Trim(arrgrid(introws + 1, 18))
'                End If
'            Else
'                sAccBranchCode = brcode
'            End If
'
'
'           strRec = Receipts(arrDenoms)
'
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'        End If
'--------------------
  
        If UCase(Trim(ModuleId)) = "REM" Then
       
           strRec = RemTranInsert(ModuleId, ModeofTran)
           If strRec <> "Sucessfully Completed" Then
              strInsDel = strRec
              GoTo errhand
           End If
        End If
     
'        If (UCase(Trim(ModuleId)) = "FXREM" And (ModeofTran = "4" Or ModeofTran = "2")) Then
'
'           strRec = FxRemittance()
'
'           If strRec <> "Sucessfully Completed" Then
'             strInsDel = strRec
'             GoTo errhand
'           End If
'        End If
        
        
'--------------------
'Suspence

'        If UCase(Trim(ModuleId)) = "SCR" And _
'        (ModeofTran = "3" Or ModeofTran = "1" Or ModeofTran = "5") Then
'           strRec = SuspenceInsert(ModuleId, ModeofTran)
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'        End If
'---------------------
'Suspence
'        If UCase(Trim(ModuleId)) = "SCR" And (ModeofTran = "4" Or ModeofTran = "2" Or ModeofTran = "6") Then
'           strRec = SuspenceContraInsert(ModuleId, ModeofTran)
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'        End If

'---------------------
'if loans then fill interest charges
        If UCase(Trim(ModuleId)) = "LOAN" Then
           strRec = Loans()
           If strRec <> "Sucessfully Completed" Then
              strInsDel = strRec
              GoTo errhand
           End If
        End If

'---------------------
     'End If
   End If
'-------------------------------------------------------------------------------------------
'    If ServiceId = "2" Then
'       strRec = AccountOpening()
'
'       If strRec <> "Sucessfully Completed" Then
'          strInsDel = strRec
'          GoTo errhand
'       End If
'
'       If UCase(Trim(ModuleId)) = "CASH" And ModeofTran = "1" Then
'
'            'Hold Branch code of selected Account
'            If ABBYN = "Y" Then
'
'                If introws > 0 Then
'                    sAccBranchCode = Trim(arrgrid(introws - 1, 18))
'                Else
'                    sAccBranchCode = Trim(arrgrid(introws + 1, 18))
'                End If
'            Else
'                sAccBranchCode = brcode
'            End If
'
'           strRec = Receipts(arrDenoms)
'
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'        End If
'    End If
'-------------------------------------------------------------------------------------------
'    If ServiceId = "3" Then
'       strRec = AccountOpening()
'
'       If strRec <> "Sucessfully Completed" Then
'          strInsDel = strRec
'          GoTo errhand
'       End If
'    End If
'-------------------------------------------------------------------------------------------
''''Any Branch Banking
'''    If ServiceId = "7" Then
'''        If UCase(ModuleId) = "ABB" Then
'''           strRec = AnyBranchBanking()
'''           If strRec <> "Sucessfully Completed" Then
'''              strInsDel = strRec
'''              GoTo ErrHand
'''           End If
'''        End If
'''    End If
'-------------------------------------------------------------------------------------------
'for clearing outwardReturns calling a function to do transactions
'    If ServiceId = "8" Then
'        If UCase(arrgrid(introws, 79)) = "CLGOWRETURN" Then
'           strRec = CLGOutwardReturn()
'           If strRec <> "Sucessfully Completed" Then
'              strInsDel = strRec
'              GoTo errhand
'           End If
'        End If
'    End If
'-------------------------------------------------------------------------------------------
 
    If LinkModId <> "" And UCase(AccChkYN) <> "Y" Then
            strRec = LinkModule()
            If strRec <> "Sucessfully Completed" Then
               strInsDel = strRec
               GoTo errhand
            End If
            
          '' code added by anil
        If LinkModId = "LOCKER" Then
            strRec = LockersForReceipts()
            If strRec <> "Sucessfully Completed" Then
               strInsDel = strRec
               GoTo errhand
            End If
         End If
            '' end of code added by anil
            
    End If
    
'    If UCase(ModuleId) = "DEP" Or UCase(ModuleId) = "FXDEP" Then
'            strRec = depCommCode()
'            If strRec <> "Sucessfully Completed" Then
'               strInsDel = strRec
'               GoTo errhand
'            End If
'    End If
    
    'Code added on 03-aug-2006
    'Desc: Deposit Interest details posting
    'Reason: This code is used to insert data into Interest related tables
'    If UCase(arrgrid(introws, 79)) = "DEPIC" Or _
'        UCase(arrgrid(introws, 79)) = "DEPICINTACCR" Then
'
'        DepGL = arrgrid(introws, 62)
'        DepAccNo = arrgrid(introws, 63)
'        DepAccROI = arrgrid(introws, 64)
'        DepAccIntCalcFromDt = arrgrid(introws, 65)
'        DepAccIntCalcToDt = arrgrid(introws, 66)
'        DepAccLastIntApplDt = arrgrid(introws, 67)
'        DepAccIntAmt = arrgrid(introws, 68)
'        DepAccBal = arrgrid(introws, 69)
'        DepModule = arrgrid(introws, 70)
'
'        If UCase(arrgrid(introws, 79)) = "DEPIC" Then
'        'Posting calcllated Deposit Interest
'        strRec = DepIntPosting()
'        If strRec <> "Sucessfully Completed" Then
'           strInsDel = strRec
'           GoTo errhand
'        End If
'        End If
'
'        If UCase(arrgrid(introws, 79)) = "DEPICINTACCR" Then
'            'Posting Interest accrued details
'            strRec = DepIntAccrPosting()
'            If strRec <> "Sucessfully Completed" Then
'               strInsDel = strRec
'               GoTo errhand
'            End If
'        End If
'    End If
'    'end of code added on 03-aug-2006

'End If

'===========================================================================================
'Disposals
If UCase(AccChkYN) = "Y" Then
 If ServiceId = "1" Then
'------------------------
'For Lockers
    If UCase(LinkModId) = "LOCKER" And lockerPaiddate <> "" And lockerNextduedate <> "" Then
           strRec = Lockers()
           If strRec <> "Sucessfully Completed" Then
              strInsDel = strRec
              GoTo errhand
           End If
    End If
 End If
End If

'===========================================================================================
'For Standing Instructions

If UCase(StandInstrYN) = "Y" Then
   Dim TempAccNo As Variant
   If UCase(TempAccNo) <> UCase(SIAccNo) Then
        strRec = StandingInstructions()
                     If strRec <> "Sucessfully Completed" Then
                        strInsDel = strRec
                        GoTo errhand
                     End If
                     TempAccNo = SIAccNo
   End If
 
End If
'===========================================================================================

            Else
            GoTo errhand
            End If
         Else
         GoTo errhand
         End If
  
   Next introws
   
  
    strtdsdtls = "tdsdtls"
    strFldtdsdtls = "PAIDDATE, PAIDBRCODE, PAIDBATCHNO, PAIDTRANNO"
    arrFldtdsdtls(0) = "'" & paiddateval1 & "'~'" & brcodetdsval1 & "'~" & batchnotdsval1 & "~" & trannotdsval1


For introwstds = 0 To UBound(arrgridtds) - 1

       brcodetds1 = Trim(arrgridtds(introwstds, 0))
       curcodetds1 = Trim(arrgridtds(introwstds, 1))
       tranDatetds1 = Trim(arrgridtds(introwstds, 2))
       GLCodetds1 = Trim(arrgridtds(introwstds, 3))
       AccNotds1 = Trim(arrgridtds(introwstds, 4))
       batchnotds1 = Trim(arrgridtds(introwstds, 5))
       trannotds1 = Trim(arrgridtds(introwstds, 6))


       strWhrCondtdsdtls = " branchcode ='" & brcodetds1 & "' AND currencycode = '" & curcodetds1 & _
       "' and applicationdate = '" & tranDatetds1 & "' AND glcode = '" & GLCodetds1 & _
       "' AND accno = '" & AccNotds1 & "' AND batchno = " & batchnotds1 & " AND tranno = " & trannotds1
           
       strInstdsdtls = ObjTrans.UpdateRecord(strtdsdtls, strFldtdsdtls, arrFldtdsdtls, strWhrCondtdsdtls)
           
          If strInstdsdtls <> "Trans Completed" Then
             GoTo errhand
          End If

Next introwstds


 'For disposals Common Code
 
 If AccChkYN = "Y" And UCase(StandInstrYN) <> "Y" Then
    strRec = DispCommCode()
    If strRec <> "Sucessfully Completed" Then
       strInsDel = strRec
       GoTo errhand
    End If
 End If
 
 
  
            If introws = UBound(arrgrid) And introwstds = UBound(arrgridtds) Then
               objContext.SetComplete
               TranInserttds = "Batch No : " & batchno & " Completed"
            Else
               GoTo errhand
            End If
     
            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
            Exit Function
     
     
'------------------------------------------------------------------------------------------

errhand:
  
            objContext.SetAbort
   
            If Not objQuery Is Nothing Then
                If objQuery.ConnError <> "Connected" Then
                   TranInserttds = objQuery.ConnError
                   TranInserttds = Replace(TranInserttds, Chr(10), "")
                   TranInserttds = Replace(TranInserttds, Chr(13), "")
                End If
            End If
            
            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
     
            If Err.Number <> "0" Then
               TranInserttds = Err.Number & " : " & Err.Description
               TranInserttds = Replace(TranInserttds, Chr(10), "")
               TranInserttds = Replace(TranInserttds, Chr(13), "")
            ElseIf strInsDel <> "Trans Completed" Then
               TranInserttds = strInsDel
               TranInserttds = Replace(TranInserttds, Chr(10), "")
               TranInserttds = Replace(TranInserttds, Chr(13), "")
            End If
   
End Function

Function AccountAndGLCheck(strMstTab As String) As String
  Dim strTabName As String
  Dim StrFldNames As String
  Dim strWhrCond As String
  Dim strWhrAdd As String
  Dim strWhrFnl As String
  Dim strWhrCondTrn As String
  Dim strStatus As String
  Dim strTransStatus As String
  Dim recMstTab As ADODB.Recordset
  Dim recCodeTab As ADODB.Recordset
  Dim recCodeTabTrn As ADODB.Recordset
 
     If UCase(AccChkYN) = "Y" Then
        If UCase(ModuleId) = UCase(LinkModId) And UCase(GLCode) = UCase(LinkGLCode) Then
           AccountAndGLCheck = "Sucessfully Completed"
           Exit Function
        End If
     End If
     
     If UCase(AccChkYN) = "N" Then
        AccountAndGLCheck = "Sucessfully Completed"
        Exit Function
     End If
     
     Set recMstTab = CreateObject("ADODB.Recordset")
  'If Master Table exits then queries for record availability i.e for customer accounts
     If strMstTab <> "" Then
        strTabName = strMstTab
        StrFldNames = "status,transtatus"
        ''''''''''''''' Where Codition Formation'''''''''''''''''''''
        ''''''''''' If SCR Module then Branch code is not required
        If UCase(ModuleId) = "SCR" Then
            strWhrCond = " upper(currencycode)='" & _
                 UCase(curcode) & "' and upper(glcode)='" & UCase(GLCode) & _
                 "' and upper(accno)='" & UCase(AccNo) & "'"
        Else
            '''''''''''''' else Check with branch code
            strWhrCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                 UCase(curcode) & "' and upper(glcode)='" & UCase(GLCode) & _
                 "' and upper(accno)='" & UCase(AccNo) & "'"
        
        End If
         If ServiceId = "1" Or ServiceId = "8" Then
             strWhrAdd = " and upper(Status) = 'R' And upper(transtatus) ='A'"
         ElseIf ServiceId = "4" Then
         strWhrAdd = " and upper(Status) = 'C' And upper(transtatus) ='P'"
         End If
         strWhrFnl = strWhrCond & strWhrAdd
   
   'If Master Table doesnot exists then queries for GL availability
     ElseIf strMstTab = "" Then
        If UCase(ModuleId) = "GL" Then
        'strTabName = "GENGLMASTMST"
        'StrFldNames = "upper(status),glcode"
        'strWhrFnl = "glcode not in(select glcode from GENGLSHEETMST where " & _
        '             "upper(branchcode)='" & UCase(brcode) & "' and upper(glcode)='" & _
        '             UCase(GLCode) & "' and upper(status)='R' ) " & _
        '             "and upper(glcode)='" & UCase(GLCode) & _
        '             "' and upper(glcategory)='A' and upper(status)='A'"
        
        strTabName = "GENGLSHEETMST"
        StrFldNames = "upper(status),glcode"
        
        strWhrFnl = "moduleid in (select moduleid from genmoduletypesmst" & _
                   " where upper(trim(implementedyn))<>'Y' and upper(trim(branchcode))='" & _
                    UCase(brcode) & "') or (trim(moduleid)='GL') and upper(trim(branchcode))='" & _
                    UCase(brcode) & "' and (status='R')"
        
        
        Else
        strTabName = "GENGLSHEETMST"
        StrFldNames = "upper(status) status"
        strWhrCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(ModuleId)='" & _
                     UCase(ModuleId) & "' and upper(glcode)='" & UCase(GLCode) & "'"
        strWhrAdd = " and upper(status)='R'"
        strWhrFnl = strWhrCond & strWhrAdd
        End If
     End If
      
          
        Set recMstTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strWhrFnl)
   
        If objQuery.ConnError <> "Connected" Then
           AccountAndGLCheck = objQuery.ConnError
           AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
           AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
           Exit Function
        End If
   'If RecordCount greaterthan zero i.e Record is available and function exits
      
     If recMstTab.RecordCount > 0 Then
        AccountAndGLCheck = "Sucessfully Completed"
        Exit Function
     Else
        
     '''''It Checks different possible conditions ....To Display Userfriendly meessge
     'If record doesnot exists then it queries again without status condition
        If UCase(ModuleId) = "GL" Then
           AccountAndGLCheck = GLDesc & " GL not in Required Status " & _
                                                 "for Transaction No :" & tranno
                                                 
           AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
           AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
           Exit Function
        End If
        Set recMstTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strWhrCond)
  
           If objQuery.ConnError <> "Connected" Then
              AccountAndGLCheck = objQuery.ConnError
              AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
              AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
              Exit Function
           End If
      
      'If RecordCount is zero i.e Account or GL does not exists
  
           If recMstTab.RecordCount <= 0 Then
              If strMstTab <> "" Then
                 AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                     " Doesnot Exists for Transaction No :" & tranno
                 AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                 AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
              ElseIf strMstTab = "" Then
                 AccountAndGLCheck = GLDesc & " GL not available for this " & _
                                              "Branch for Transaction No :" & tranno
                 AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                 AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
              End If
           Else
      'If Record exits i.e with different status...Queries GENACCOUNTSTATUSTYPEMST
      'for status description.
       
 
              Set recCodeTab = CreateObject("ADODB.Recordset")
              StrFldNames = "upper(code) code,upper(description) MstDesc"
              strWhrCond = "code='" & recMstTab!Status & "' and upper(status)='A'"
    
              Set recCodeTab = objQuery.SingleRecordSet("GENACCOUNTSTATUSTYPEMST", _
                           StrFldNames, strWhrCond)
 
                   If objQuery.ConnError <> "Connected" Then
                      AccountAndGLCheck = objQuery.ConnError
                      AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                      AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                      Exit Function
                   End If
      
                   If recCodeTab.RecordCount <= 0 Then
                          If strMstTab <> "" Then
                             AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                                 " not in Required Status for " & _
                                                 "Transaction No :" & tranno
                                                 
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                          ElseIf strMstTab = "" Then
                             AccountAndGLCheck = GLDesc & " GL not in Required Status " & _
                                                 "for Transaction No :" & tranno
                             AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                             AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                          End If
                    Exit Function
                    End If

                Set recCodeTabTrn = CreateObject("ADODB.Recordset")
                StrFldNames = "upper(code) code,description TranDesc"
                strWhrCondTrn = "code='" & recMstTab!TRANSTATUS & "' and upper(status)='A'"
                Set recCodeTabTrn = objQuery.SingleRecordSet("GENACCOUNTSTATUSTYPEMST", _
                           StrFldNames, strWhrCondTrn)
                  
                   If objQuery.ConnError <> "Connected" Then
                      AccountAndGLCheck = objQuery.ConnError
                      AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                      AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                      Exit Function
                   End If
      
                   If recCodeTabTrn.RecordCount <= 0 Then
                          If strMstTab <> "" Then
                             AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                              " Transaction Status not in Required Status" & _
                                              " for Transaction No :" & tranno
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                          ElseIf strMstTab = "" Then
                            AccountAndGLCheck = GLDesc & " GL not in Required Status" & _
                                              " for Transaction No :" & tranno
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                            AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                          End If
                    Exit Function
                   End If

                If strMstTab <> "" Then
    
                    If ServiceId = "1" Or ServiceId = "8" Then
    
                       If recMstTab!Status <> "R" Then
                          AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                         " in " & recCodeTab!MstDesc & " Status" & _
                                         " for Transaction No :" & tranno
                                         
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                       ElseIf recMstTab!TRANSTATUS <> "A" Then
                          AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                      " Transaction Status in " & recCodeTabTrn!TranDesc & _
                                      " for Transaction No :" & tranno
                                      
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                       End If
                       
                    ElseIf ServiceId = "4" Then
                       If recMstTab!Status <> "C" Then
                          AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                         " in " & recCodeTab!MstDesc & " Status" & _
                                         " for Transaction No :" & tranno
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                       ElseIf recMstTab!TRANSTATUS <> "P" Then
                                            
                          AccountAndGLCheck = GLDesc & " Account No : " & AccNo & _
                                     " Transaction Status in " & recCodeTabTrn!TranDesc & _
                                     " for Transaction No :" & tranno
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                          AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
                       End If
                     
                  End If

               ElseIf strMstTab = "" Then
                  AccountAndGLCheck = GLDesc & " in " & recCodeTab!MstDesc & " Status" & _
                                     " for Transaction No :" & tranno
                  AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
                  AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
               End If
                  
        End If
     End If
        AccountAndGLCheck = "GL or Account Status Problem for Transaction No :" & tranno
        AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(10), "")
        AccountAndGLCheck = Replace(AccountAndGLCheck, Chr(13), "")
        Exit Function


End Function



Public Function ExcepTransacton() As String

    Dim strTabName As String
    Dim StrFldNames As String
    Dim arrExcpCode() As String
    Dim ExcpCodeCnt As Integer
    Dim excpCode As Integer
    Dim cnt As Integer
    Dim FldVal As String
    Dim arrFldVal() As String
    Dim TempVal As String
    
             
        strTabName = "GENEXCEPTIONALTRANDAY"
        StrFldNames = "BRANCHCODE , CURRENCYCODE, batchno, tranno, EXCEPTIONCODE," & _
                    "APPLICATIONDATE, VERIFIEDBY, VERIFIEDMACHINE, systemdate"
                        
        arrExcpCode = Split(ExcpCodes, "^")
        ExcpCodeCnt = UBound(arrExcpCode)
                     
        FldVal = ""
        ReDim arrFldVal(ExcpCodeCnt - 1) As String
        
        For cnt = 0 To ExcpCodeCnt - 1
            
            excpCode = arrExcpCode(cnt)
            TempVal = "'" & brcode & "','" & curcode & "','" & batchno & "','" & tranno & _
                     "','" & excpCode & "','" & ApplDate & "','','', sysdate"
                     
            arrFldVal(cnt) = arrFldVal(cnt) & TempVal
 
        Next cnt
           
        strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
        
               If strInsDel <> "Trans Completed" Then
                  ExcepTransacton = strInsDel
                  ExcepTransacton = Replace(ExcepTransacton, Chr(10), "")
                  ExcepTransacton = Replace(ExcepTransacton, Chr(13), "")
                  Exit Function
               End If
        
        
        ExcepTransacton = "Sucessfully Completed"
        Exit Function
        
'ErrHand:
        
End Function



Function ChequeDetails() As String
    Dim strTabName As String
    Dim StrFldNames As String
    Dim arrFldVal(0) As Variant
    Dim arrExcpCode() As String
    Dim strWhrCond As String
 
'On Error GoTo ErrHand
    
    strTabName = "GENCHEQUEPAIDDTLS"
    StrFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCode,ACCNO,CHQSERIESNO,CHQEQUENO," & _
                  "APPLICATIONDATE,BATCHNO,TRANNO,instrtype"
   
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & ModuleId & "','" & GLCode & _
                   "','" & AccNo & "','" & ChqSrs & "','" & ChqNo & "','" & ApplDate & _
                   "','" & batchno & "','" & tranno & "','" & strinstrtype & "'"
                         
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
        
    If strInsDel <> "Trans Completed" Then
       ChequeDetails = strInsDel
       ChequeDetails = Replace(ChequeDetails, Chr(10), "")
       ChequeDetails = Replace(ChequeDetails, Chr(13), "")
       Exit Function
    End If
    
    
    'For Cheque Exceptinal Transaction
       If ExcpYN = "Y" And ExcpCodes <> "" Then
          arrExcpCode = Split(ExcpCodes, "4")
          If UBound(arrExcpCode) = 1 Then
             ChequeDetails = "Sucessfully Completed"
             Exit Function
          End If
       End If
       
'Code commented by Radhika on 04 Mar 2008
'Reason: Cheque details storage process was changed in the database
'        Now we were saving From cheque number and To Cheque Number in a single row
'        We were not saving each cheque number individually
'    strTabName = "GENCHEQUEDTLS"
'    StrFldNames = "status"
'    arrFldVal(0) = "'D'"
'
'    'This code was modified by Radhika on 04-aug-2007
'    'Reason: Cheque series number is not a mandatory column
'    If Trim(ChqSrs) <> "" Then
'        strWhrCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
'                 UCase(curcode) & "' and upper(ModuleId)='" & UCase(ModuleId) & "' and " & _
'                 "upper(glcode)='" & UCase(GLCode) & "' and upper(accno)='" & _
'                 UCase(AccNo) & "' and chqseriesno='" & ChqSrs & "' and " & _
'                 "chequeno='" & ChqNo & "'"
'    Else
'        strWhrCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
'                 UCase(curcode) & "' and upper(ModuleId)='" & UCase(ModuleId) & "' and " & _
'                 "upper(glcode)='" & UCase(GLCode) & "' and upper(accno)='" & _
'                 UCase(AccNo) & "' and chequeno='" & ChqNo & "'"
'    End If
'
'
'    strInsDel = ObjTrans.UpdateRecord(strTabName, StrFldNames, arrFldVal(), strWhrCond)
'
'              If strInsDel <> "Trans Completed" Then
'                 ChequeDetails = strInsDel
'                 ChequeDetails = Replace(ChequeDetails, Chr(10), "")
'                 ChequeDetails = Replace(ChequeDetails, Chr(13), "")
'                 Exit Function
'              End If
                         
                         
                         
    ChequeDetails = "Sucessfully Completed"
    Exit Function
                         
 
'ErrHand:
End Function


''------------------------------------------------------------------------------------------
''' this function is used to do transactions for clearing presentation
'''''' for updating status as 'P' in clglodgementvoucherdtls table
''''' for inserting records into genunclearbalancedtls table
'''''---------------------------------------------------------------------------------------
Public Function CLGPresentaion() As String
'''declaring variables
Dim StrFldNames As String
Dim strTabName As String
Dim StrValues(0) As Variant
Dim StrUpdate As String
Dim StrInsert As String
Dim StrInsTabName As String
Dim StrInsFldNames As String
Dim StrInsFldvalues(0) As Variant
Dim StrCondition As String

'On Error GoTo ErrHand

strInsDel = ""
'StrInsert = ""
'LDGDate = Format(CDate(LodgementDate), "dd-mm-yyyy")
''' calling transaction component to do transactions(insert,update)
 'Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
 ''''' storing values into variables for update the status in clglodgementvoucherdtls
    StrFldNames = "status,PRESENTATIONDATE"
    strTabName = "CLGLODGEMENTVOUCHERDTLS"
    StrValues(0) = "'P'~to_date('" & ApplDate & "','dd-mm-yyyy')"
    StrCondition = "upper(trim(branchcode))='" & brcode & "' and " & _
                   "upper(trim(BRANCHCODE))='" & PresBranchcode & "' and " & _
                    "upper(trim(currencycode))='" & curcode & "' and " & _
                    "lodgementdate= to_date('" & LodgementDate & "','dd-mm-yyyy') and " & _
                    "trim(voucherno)='" & Trim(voucherno) & "' and " & _
                    "upper(trim(CLEARINGTYPE))='" & ClearingType & "'"
             
  ''''' storing values into variables for inserting rows into genunclearbalancedtls
     StrInsTabName = "Genunclearbalancedtls"
     StrInsFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,NAME," & _
                    "LODGEMENTDATE,CLEARINGTYPE,PRESENTATIONDATE,AMOUNT," & _
                    "APPLICATIONDATE,STATUS,USERID,MACHINEID,SYSTEMDATE,CLGACCTBRCODE,voucherno"
     StrInsFldvalues(0) = "'" & brcode & "','" & curcode & "','" & ModuleId & "'," & _
                        "'" & GLCode & "','" & AccNo & "','" & Name & "'," & _
                        "to_date('" & LodgementDate & "','dd-mm-yyyy')," & _
                        "'" & ClearingType & "',to_date('" & ApplDate & "','dd-mm-yyyy')," & _
                        "" & Amount & ",to_date('" & ApplDate & "','dd-mm-yyyy')," & _
                        "'P','" & EnteredBy & "','" & EnteredMC & "',sysdate," & _
                        "'" & PresBranchcode & "'," & voucherno & ""
                        
                        
    '''' calling transaction component update method
    strInsDel = ObjTrans.UpdateRecord(strTabName, StrFldNames, StrValues, StrCondition)
    '''if updation is not successfull goto errorhandle
    
           ''' MsgBox strInsDel
    If strInsDel <> "Trans Completed" Then
       CLGPresentaion = strInsDel
       CLGPresentaion = Replace(CLGPresentaion, Chr(10), "")
       CLGPresentaion = Replace(CLGPresentaion, Chr(13), "")
        Exit Function
     '''if updation is successfull call insert component method to insert into
     '''genunclearbalancedtls
    Else
    strInsDel = ObjTrans.InsertRecord(StrInsTabName, StrInsFldNames, StrInsFldvalues)
    
        '''MsgBox strInsDel
        If strInsDel <> "Trans Completed" Then
           CLGPresentaion = strInsDel
           CLGPresentaion = Replace(CLGPresentaion, Chr(10), "")
           CLGPresentaion = Replace(CLGPresentaion, Chr(13), "")
           Exit Function
        Else
            CLGPresentaion = "Sucessfully Completed"
            Exit Function
        End If
    End If
 '''error handling
'ErrHand:

End Function

''------------------------------------------------------------------------------------------
''' this function is used to do transactions for clearing presentation
'''''' for updating status as 'P' in clglodgementvoucherdtls table
''''' for inserting records into genunclearbalancedtls table
'''''---------------------------------------------------------------------------------------
Public Function CLGInwardReturn() As String
'''declaring variables
Dim StrReturnFldNames As String
Dim StrReturnTabName As String
Dim StrReturnValues(0) As Variant
Dim StrReturnUpdate As String
Dim StrReturnCondition As String
Dim RecVoucher As Recordset
Dim vdate As String
'On Error GoTo ErrHand

StrReturnUpdate = ""
'''' for fetching lodgementdate for selected presentationdate in
''''CLGLODGEMENTvoucherdtls

Set RecVoucher = CreateObject("adodb.recordset")
Set RecVoucher = objQuery.SingleRecordSet("CLGLODGEMENTVOUCHERDTLS", _
                "to_char(LODGEMENTDATE,'dd-mm-yyyy')", _
                "upper(trim(CLGACCTBRCODE))='" & brcode & "' and " & _
                "upper(trim(BRANCHCODE))='" & PresBranchcode & "' and " & _
                "upper(trim(currencycode))='" & curcode & "' and " & _
                "PRESENTATIONDATE= to_date('" & LodgementDate & "','dd-mm-yyyy') and " & _
                "trim(voucherno)='" & Trim(voucherno) & "' and " & _
                "upper(trim(CLEARINGTYPE))='" & ClearingType & "'")
 
                
    If Not RecVoucher.EOF Then
             vdate = RecVoucher(0)
    End If
    
    Set RecVoucher = Nothing
''' calling transaction component to do transactions(insert,update)
' Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
 ''''' storing values into variables for update the status in clglodgementvoucherdtls
    StrReturnFldNames = "status,CHQRETURNDATE,CHQRETURNBATCHNO," & _
                        "CHQRETURNTRANNO,VERIFIEDBY,VERIFIEDMACHINE"
    StrReturnTabName = "CLGLODGEMENTINSTRUMENTDTLS"
    StrReturnValues(0) = "'U'~'" & ApplDate & "'~'" & batchno & "'~" & _
                        "'" & tranno & "'~'" & EnteredBy & "'~'" & EnteredMC & "'"
    StrReturnCondition = "upper(trim(CLGACCTBRCODE))='" & brcode & "' and " & _
                        "upper(trim(BRANCHCODE))='" & PresBranchcode & "' and " & _
                    "upper(trim(PAYABLEBRANCHCODE))='" & ClgBranchcode & "' and " & _
                    "upper(trim(currencycode))='" & curcode & "' and " & _
                    "lodgementdate= to_date('" & vdate & "','dd-mm-yyyy') and " & _
                    "trim(voucherno)='" & Trim(voucherno) & "' and " & _
                    "upper(trim(CLEARINGTYPE))='" & ClearingType & "' and " & _
                    "upper(trim(PAYABLEBANKCODE))='" & BankCode & "' and " & _
                    "INSTRNO='" & InstrNo & "'"
          
    
    '''' calling transaction component update method
    StrReturnUpdate = ObjTrans.UpdateRecord(StrReturnTabName, StrReturnFldNames, _
                    StrReturnValues, StrReturnCondition)
  
    '''if updation is not successfull goto errorhandle
    If StrReturnUpdate <> "Trans Completed" Then
       CLGInwardReturn = StrReturnUpdate
       CLGInwardReturn = Replace(CLGInwardReturn, Chr(10), "")
       CLGInwardReturn = Replace(CLGInwardReturn, Chr(13), "")
        Exit Function
    End If
    'Else
        CLGInwardReturn = "Sucessfully Completed"
        'objContext.SetAbort
        'Exit Function
   ' End If
    
 '''error handling
'ErrHand:

End Function

Function TellerPayments() As String
    Dim strTabName As String
    Dim StrFldNames As String
    Dim arrFldVal(0) As String
    
    strTabName = "CASHTELLERPAYMENTSTRANDAY"
    StrFldNames = "BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,CASHIERID,CASHPAIDYN," & _
                  "TRANSTATUS,USERID,MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY," & _
                  "APPROVEDMACHINE,systemdate,APPLICATIONDATE,ABBYN"
   
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & batchno & "','" & tranno & _
                     "','" & CashierId & "','N','P','" & EnteredBy & "','" & EnteredMC & _
                     "','','','" & ApprovedBy & "','" & ApprovedMC & "',sysdate,'" & _
                     ApplDate & "','" & IIf(Trim(ABBYN) = "", "N", Trim(ABBYN)) & "'"
   
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
   
    If strInsDel <> "Trans Completed" Then
       TellerPayments = strInsDel
       TellerPayments = Replace(TellerPayments, Chr(10), "")
       TellerPayments = Replace(TellerPayments, Chr(13), "")
        Exit Function
    End If
                         
    TellerPayments = "Sucessfully Completed"
    Exit Function
End Function


Public Function Receipts(arrDenom As Variant) As String
'-------------------------------------Variables
Dim strCashMst As String, strCashMstFldnms As String, strCashMstVal(0) As String, _
strCashMstWhCond As String, strCashTrn As String, strCashTrnFld As String, _
strCashTrnVal(0) As String, strTrans As String, strTransFld As String, strTransVal(0) As String, _
strCshTrnDay As String, strCshTrnDayFld As String, strCshTrnDayVal(0) As String, _
strSbTrnDay As String, strSbTrnFld As String, strSbTrnVal(0) As String, strTempTrans As String, _
strTempTranWhCnd As String, systemdate As Date, strVal(0) As String, strWhereCond As String, _
strquerytab As String, strorder As String, ICount As Integer, strFldnms As String, _
strFldupd As String, strDenomval As String, strDenupd As String, strFinal As String, _
strnegden  As String, strtemp As String, strqueryflds As String, recdenom As ADODB.Recordset
'--------------------------------------------------------------------------------------------
 ' On Error GoTo ErrHand
  strInsDel = ""
'--------------Querying DenominationMst to get Denominations---------------------------------
 
  strquerytab = "CashDenominationMst"
  strqueryflds = " Denominationvalue,Denominationcode,denominationtype "
  strWhereCond = " upper(Currencycode)='" & curcode & "'"
  strorder = " substr(denominationtype,1,1) desc, substr(denominationtype,2,1) , " _
             & " to_number( denominationvalue) desc"
    
  Set recdenom = CreateObject("ADODB.Recordset")
        
  Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
  Set recdenom = objQuery.SingleRecordSet(strquerytab, strqueryflds, _
                                            strWhereCond, strorder)
  If objQuery.ConnError <> "Connected" Then
     Receipts = objQuery.ConnError
     Receipts = Replace(Receipts, Chr(10), "")
     Receipts = Replace(Receipts, Chr(13), "")
     Exit Function
  End If
        
  If recdenom.RecordCount <= 0 Then
     Receipts = "No Denominations Found"
     Exit Function
  End If
  Set objQuery = Nothing
'---Finding DenominationCode from DenominationMst, using DenominationValue and DenominationType
    
    For ICount = 0 To UBound(arrDenom)
        recdenom.MoveFirst
             
        recdenom.Filter = "Denominationvalue='" & Trim(arrDenom(ICount, 0)) & "' and " & _
                     UCase("denominationtype='") & UCase(Trim(arrDenom(ICount, 3))) & "'"
          
'--------------Concatinating Denomination Code and Denomination Values to insert and Update tables
     
    If Not recdenom.EOF Then
       
       strFldnms = strFldnms & "," & recdenom!Denominationcode
       strFldupd = recdenom!Denominationcode
       strDenomval = strDenomval & "," & Val(arrDenom(ICount, 1)) - Val(arrDenom(ICount, 2))
       strDenupd = Val(arrDenom(ICount, 1))
              
'-------------If User gives any denominations to the customer then.....
     
    If Val(arrDenom(ICount, 2)) > 0 Then
       strnegden = (Val(arrDenom(ICount, 1)) - Val(arrDenom(ICount, 2)))
                        
           If Val(arrDenom(ICount, 1)) > Val(arrDenom(ICount, 2)) Then
              strFinal = "NVL(" & strFldupd & ",0)" & "+" & Abs(strnegden)
           Else
              strFinal = "NVL(" & strFldupd & ",0)" & "-" & Abs(strnegden)
           End If
    Else
       strFinal = "NVL(" & strFldupd & ",0)" & "+" & strDenupd
    End If
                 
       strFinal = strtemp & "~" & strFinal
       strtemp = strFinal
    End If
    Next ICount
   
    'ApplDate = Format(ApplDate, "dd-mmm-yyyy")
   
    '-------------Storing field names and values to update cashcashierposmst----------------
         
    strCashMst = "CASHCASHIERPOSMST"
    strCashMstFldnms = "BranchCode,CurrencyCode,CashierId,UserId,MachineID," & _
                       "ApplicationDate,systemdate,Narration,TOTAMOUNT" & strFldnms
                       
    strCashMstVal(0) = "'" & brcode & "'~'" & curcode & "'~'" & CashierId & "'~'" & _
                  EnteredBy & "'~'" & EnteredMC & "'~'" & Format(ApplDate, "dd-mmm-yyyy") & _
                  "'~sysdate~'" & Narration & "'~" & _
                  "nvl(totamount, 0) +" & Abs(Amount) & strtemp
    
    strCashMstWhCond = "upper(trim(branchcode))='" & UCase(Trim(brcode)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                       "'and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & "'"
         
    '------Storing field names and values for inserting into cashpaymentstrn----------------
       
   strCashTrn = "CASHRECEIPTSTRN"
   'code commented by Radhika on 21 may 2008
   'Reason: Insert a/c holder name along with its original branch code
   '        This is helpful for ABB transactions
'   strCashTrnFld = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CASHIERID," & _
'                   "RECEIPTSCROLLNO,AMOUNT,NARRATION,STATUS,UserId,MachineID," & _
'                   "APPLICATIONDATE,SYSTEMDATE,TRANNO,COUNTERNO" & strFldnms
'
'   strCashTrnVal(0) = "'" & brcode & "','" & curcode & "','" & LinkModId & "','" & _
'                 LinkGLCode & "','" & LinkAccNo & "','" & CashierId & "','" & ScrollNo & _
'                 "','" & Abs(Amount) & "','" & Narration & "','P" & "','" & EnteredBy & _
'                 "','" & EnteredMC & "','" & Format(ApplDate, "dd-mmm-yyyy") & _
'                 "',sysdate,'" & tranno & "','" & CounterNo & "'" & strDenomval
                 
   'New code written on 21 may 2008 by Radhika
   strCashTrnFld = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CASHIERID," & _
                   "RECEIPTSCROLLNO,AMOUNT,NARRATION,STATUS,UserId,MachineID," & _
                   "APPLICATIONDATE,SYSTEMDATE,TRANNO,COUNTERNO" & _
                   ",NAME , AccBranchcode" & strFldnms
     
   strCashTrnVal(0) = "'" & brcode & "','" & curcode & "','" & LinkModId & "','" & _
                 LinkGLCode & "','" & LinkAccNo & "','" & CashierId & "','" & ScrollNo & _
                 "','" & Abs(Amount) & "','" & Narration & "','P" & "','" & EnteredBy & _
                 "','" & EnteredMC & "','" & Format(ApplDate, "dd-mmm-yyyy") & _
                 "',sysdate,'" & tranno & "','" & CounterNo & "'" & _
                 ",'" & Trim(LinkAccName) & "','" & sAccBranchCode & "'" & strDenomval
   'END OF New code written on 21 may 2008 by Radhika

    
'----------------------------------------------------------------------------------------
     
   strInsDel = ObjTrans.UpdateRecord(strCashMst, strCashMstFldnms, strCashMstVal, _
               strCashMstWhCond)
            
               If strInsDel <> "Trans Completed" Then
                  Receipts = strInsDel
                  Receipts = Replace(Receipts, Chr(10), "")
                  Receipts = Replace(Receipts, Chr(13), "")
                  Exit Function
               End If
   strInsDel = ObjTrans.InsertRecord(strCashTrn, strCashTrnFld, strCashTrnVal)
              
               If strInsDel <> "Trans Completed" Then
                  Receipts = strInsDel
                  Receipts = Replace(Receipts, Chr(10), "")
                  Receipts = Replace(Receipts, Chr(13), "")
                  Exit Function
               End If
   '----------------------------------------------------------------------------------------
         Receipts = "Sucessfully Completed"
         Exit Function
     
'ErrHand:

End Function


Public Function RemTranInsert(ByVal ModuleId As String, ByVal ModeofTran As String) As String
Dim strRemCrTrn As String
Dim strRemCrTrnFld As String
Dim strRemCrTrnVal(0) As Variant
Dim strRemCrTrnPay As String
Dim strRemCrTrnAdv As String
Dim strRemCrTrnFldAdv As String
Dim strWhrCondAdv As String
Dim commBatchNo As String, SrvChargeBatchNo As String
'On Error GoTo ErrHand

  If IsDate(Advrdate) Then
    Advrdate = Format(CDate(Advrdate), "dd-mmm-yyyy")
  End If
  
  If IsDate(InstrdateDr) Then
    InstrdateDr = Format(CDate(InstrdateDr), "dd-mmm-yyyy")
  End If

If ModeofTran = "3" Or ModeofTran = "1" Or ModeofTran = "5" Then
 
    strRemCrTrnFld = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE ," & _
               " BATCHNO ,TRANNO , ADVISENO, ADVISERECDATE," & _
               " ISSUEDBYBANK , ISSUEDBYBRANCH, INSTRNO," & _
               " RUNNNO , AMOUNT, INSTRTYPE, DUPLICATEYN," & _
               " FAVG , CONTRADATE, INSTRDATE," & _
               " INSTRSTATUS , STATUS, NARRATION," & _
               " USERID , MACHINEID, VERIFIEDBY," & _
               " VERIFIEDMACHINE , APPROVEDBY, APPROVEDMACHINE, SYSTEMDATE "
     

     strRemCrTrn = "REMITTPAYREGMST" 'Remparticulardtls"
              
     strRemCrTrnVal(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & batchno & _
                 "','" & tranno & "','" & Advno & "','" & Advrdate & "','" & RespBnkCode & "','" & Remisbybrn & "','" & _
                 DrInstrno & "','','" & Amount & "','" & Drinstype & "','N','" & Fvgdr & _
                 "','" & ApplDate & "','" & InstrdateDr & "','PA','A','" & Narration & "','" & EnteredBy & "','" & EnteredMC & _
                 "','','','','',sysdate"
                 
   
     strInsDel = ObjTrans.InsertRecord(strRemCrTrn, strRemCrTrnFld, strRemCrTrnVal())
     
                If strInsDel <> "Trans Completed" Then
                   RemTranInsert = strInsDel
                   RemTranInsert = Replace(RemTranInsert, Chr(10), "")
                   RemTranInsert = Replace(RemTranInsert, Chr(13), "")
                   Exit Function
                End If
                
     If Drinstype <> "ADD" Then
     
        strRemCrTrn = "REMITISSUEMST"
        strRemCrTrnFld = "PAIDBATCHNO,PAIDTRANNO,PAIDBRANCHCODE,PaidDate,INSTRCANCELYN"
        strRemCrTrnVal(0) = "'" & batchno & "'~'" & tranno & "'~'" & brcode & _
                            "'~'" & ApplDate & "'~'N'"
       
       If ServiceId = "9" Then
            Dim cBranch As String
             strRemCrTrnVal(0) = "'" & batchno & "'~'" & tranno & "'~'" & brcode & _
                            "'~'" & ApplDate & "'~'Y'"
            cBranch = brcode
            brcode = Remisbybrn
            
            'Code corrected on 05 sep 2008 by Radhika
            'Reason: While doing remitance cancellation of Banker's Cheque(i.e PO), system is
            '   throwing an error saying that no rows found to update in REMITISSUEMST
            'RespBnkCode = cBranch
            'end of Code corrected on 05 sep 2008 by Radhika
      
       End If
        
        strWhrCondAdv = "upper(trim(ISSONBANKCODE))='" & UCase(Trim(RespBnkCode)) & _
                       "' and upper(trim(issonbranchcode))='" & UCase(Trim(brcode)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                       "' and upper(trim(REMSERINSTRNO))='" & UCase(Trim(DrInstrno)) & _
                       "' and paidbatchno is null and paidtranno is null and " & _
                       " PAIDBRANCHCODE is null and paidDate is null" & _
                       " and ISSUEDDATE='" & InstrdateDr & "'"
     
        strInsDel = ObjTrans.UpdateRecord(strRemCrTrn, strRemCrTrnFld, strRemCrTrnVal(), _
                    strWhrCondAdv)
        'MsgBox strInsDel
                If strInsDel <> "Trans Completed" Then
                   RemTranInsert = strInsDel
                   RemTranInsert = Replace(RemTranInsert, Chr(10), "")
                   RemTranInsert = Replace(RemTranInsert, Chr(13), "")
                   Exit Function
                  
                End If
        
     End If
     
     If Drinstype = "ADD" And UCase(Trim(AdvrecYN)) = "Y" Then
 
            '--------------------------------------------------------------------
            'FOR UPADTING CONTRADATE IN ADVICE and PAYMENT  REGSTR IF RECORD  FOUND
           '---------------------------------------------------------------------
    
      
    'strRemCrTrnAdv = "REMITTADVREGMST"
    'strRemCrTrnFldAdv = "BATCHNO,TRANNO,CONTRADATE,INSTRDATE,INSTRSTATUS,STATUS,NARRATION"
    'strRemCrTrnVal = "'" & batchno & "','" & tranno & "','" & ApplDate & "','PA','A'"
    'strWhrCondAdv =
    
     'strInsDel = objTrans.UpdateRecord(strRemCrTrnAdv, strRemCrTrnFldAdv, strRemCrTrnVal())
      '          If strInsDel <> "Trans Completed" Then
      '            GoTo errhand
      '         End If
  
      End If

  ElseIf ModeofTran = "4" Or ModeofTran = "2" Then
     
    If Val(Comm) = 0 Then
       commBatchNo = ""
    Else
       commBatchNo = batchno
    End If
    
    'New code added by Radhika on 21 May 2008
    'Reason: We may also had service charge
    If Val(SrvCharge) = 0 Then
       SrvChargeBatchNo = ""
    Else
       SrvChargeBatchNo = batchno
    End If
    'end of New code added by Radhika on 21 May 2008
     
     
    strRemCrTrn = "REMPARTICULARTRN" 'Remparticulardtls"

    strRemCrTrnFld = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,BATCHNO," & _
                " TRANNO,GLCODE,ACCNO,CUSTOMERID,APPLNAME,MODEOFTRAN,AMOUNT," & _
                " TRANSTATUS,NARRATION,MODULE,ISSUEDONBANK,ISSUEDONBRANCH," & _
                " PRINTINSTRNO,SERIALNO,FAVG,COMMISSION,COMMBATCHNO,COMMTRANNO," & _
                " INSTRTYPE,INSTRSTATUS,ISSUESTATUS,PRINTSTATUS,STOPPAYMENTYN,USERID, " & _
                " MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                "SYSTEMDATE, SRVCHARGE , SRVCHARGEBATCHNO, SRVCHARGETRANNO"
                
   strRemCrTrnVal(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & batchno & _
                 "','" & tranno & "','" & GLCode & "','" & AccNo & "','" & Remcustid & _
                 "','" & ApplName & "','" & ModeofTran & "','" & Amount & "','A','" & _
                 Narration & "','" & ModuleId & "','" & Remisonbank & "','" & Remisonbrn & _
                 "','','','" & Fvgcr & "','" & Comm & "','" & commBatchNo & "','" & CommTranno & _
                 "','" & Crinstype & "','P','P','','N','" & EnteredBy & "','" & EnteredMC & _
                 "','','','','',sysdate,'" & SrvCharge & "','" & SrvChargeBatchNo & _
                 "','" & SrvChargeTranNo & "'"
     
strInsDel = ObjTrans.InsertRecord(strRemCrTrn, strRemCrTrnFld, strRemCrTrnVal())
               If strInsDel <> "Trans Completed" Then
                    RemTranInsert = strInsDel
                    RemTranInsert = Replace(RemTranInsert, Chr(10), "")
                    RemTranInsert = Replace(RemTranInsert, Chr(13), "")
                    Exit Function
               End If
  
  End If

  
  RemTranInsert = "Sucessfully Completed"

Exit Function


'ErrHand:
 
End Function

Function FxRemittance()
    Dim strTabName As String
    Dim StrFldNames As String
    Dim arrFldVal(0) As Variant
       
  'On Error GoTo ErrHand
  
    strTabName = "FXREMPENDINGINSTRTEMP"
    
    StrFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,REMITTANCETYPE,ACCNO,BATCHNO," & _
                  "TRANNO,CUSTOMERID,FAVOURING,COMMISSION,COMMTRANNO,MODEOFREMITTANCE," & _
                  "PRINTSTATUS,USERID,MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY," & _
                  "APPROVEDMACHINE,SYSTEMDATE,APPLICATIONDATE,CATEGORYDESC"
                  
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & ModuleId & "','" & GLCode & _
                     "','" & RemType & "','','" & batchno & "','" & tranno & _
                     "','" & CustId & "','" & Fvgcr & "','" & Comm & "','" & CommTranno & _
                     "','" & Crinstype & "','N','" & EnteredBy & _
                     "','" & EnteredMC & "','','','','',sysdate,'" & ApplDate & "','" & _
                     FRateRefDesc & "'"
                     
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
   
               If strInsDel <> "Trans Completed" Then
                  FxRemittance = strInsDel
                  FxRemittance = Replace(FxRemittance, Chr(10), "")
                  FxRemittance = Replace(FxRemittance, Chr(13), "")

                  Exit Function
               End If
           
    FxRemittance = "Sucessfully Completed"
    Exit Function
           
           
           
'ErrHand:
                          
End Function

Public Function SuspenceInsert(ByVal ModuleId As String, ByVal ModeofTran As String) As String
Dim StrScrFields As String
Dim StrScrTab As String
Dim StrScrVal(0) As String
Dim strInsDel As String
Dim StrMstWhr As String
Dim Scrstatus As String
Scrstatus = ""
StrScrTab = ""
StrScrFields = ""
StrScrVal(0) = ""
StrMstWhr = ""
'On Error GoTo ErrHand
strInsDel = ""
ApplDate = Format(CDate(ApplDate), "dd-mmm-yyyy")
 If Len(Trim(SusConDate)) > 0 Then
    SusConDate = Format(CDate(SusConDate), "dd-mmm-yyyy")
 End If
Scrstatus = ""

If (ModeofTran = "3" Or ModeofTran = "1" Or ModeofTran = "5") Then

    If Len(Trim(SusConTranno)) > 0 Then
   '''''''''''''''''''''''''''''''''' ''''''''''''''''''''''''''''''''''''''''''''''
   ''''' checking whether Contra Amount is exceeding Original Amount
    Dim rsContra As ADODB.Recordset
    Dim rsSCRDtls As ADODB.Recordset
    
    Set rsContra = CreateObject("ADODB.Recordset")
    Set rsSCRDtls = CreateObject("ADODB.Recordset")
     
          
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    '''''''''''''''''' get Total Contra Amount posted from ContraDtls
    Set rsContra = objQuery.SingleRecordSet("SCRCONTRADTLS", "nvl(sum(abs(amount)),0)", _
        "ORIGINATINGTRANNO=" & SusConTranno & " and " & _
        " ORIGINATINGBATCHNO = " & SusConBatch & " and branchcode='" & brcode & "' " & _
        " and currencycode='" & curcode & "' and ORIGINATINGDATE='" & SusConDate & "'")
        
     MsgBox " Point 0"
    If Not rsContra.EOF And Not rsContra.BOF Then
    '''''''''''''''''' get Original Amount posted from SCRDtls
         Set rsSCRDtls = objQuery.SingleRecordSet("scrdtls", "nvl(abs(opbal),0)", _
            "TRANNO=" & SusConTranno & " and " & _
            " BATCHNO = " & SusConBatch & " and branchcode='" & brcode & "' " & _
            " and currencycode='" & curcode & "' and opDATE='" & SusConDate & "'")
    
        MsgBox " Point 1"
        If Not rsSCRDtls.EOF And Not rsSCRDtls.BOF Then
            ''''''' if Contra amount already posted + amount that is about to post
            '''''''' is greater than original amount raise an exception
            
            MsgBox "point 2" & CDbl(Abs(rsContra(0))) & "         " & Abs(Amount) & _
                    "            " & Abs(CDbl(rsSCRDtls(0)))
            
            If CDbl(Abs(rsContra(0))) + Abs(Amount) > Abs(CDbl(rsSCRDtls(0))) Then
                 SuspenceInsert = "Contra Amount is Exceeding Original Amount.."
                 Exit Function
            End If
        End If
      
    End If
   
   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
             
             
             
             
             StrScrFields = "BRANCHCODE,CURRENCYCODE,Amount,ORIGINATINGDATE," & _
                            "tranno,ORIGINATINGTRANNO," & _
                            "batchno,ORIGINATINGBATCHNO,APPLICATIONDATE," & _
                            "USERID,systemdate,MACHINEID,Narration"
                           
             StrScrTab = "SCRCONTRADTLS"
                        
             StrScrVal(0) = "'" & brcode & "','" & curcode & "'," & Amount & "," & _
                             "'" & SusConDate & "','" & tranno & "'," & _
                             "'" & SusConTranno & "','" & batchno & "','" & SusConBatch & "'," & _
                             "'" & ApplDate & "','" & EnteredBy & "',sysdate," & _
                             "'" & EnteredMC & "','" & Narration & "'"
                             
            Scrstatus = "SuspenceContra"
   Else
     
            StrScrFields = "BRANCHCODE,CURRENCYCODE,GLCODE,APPLICATIONDATE," & _
                           "OPDATE,OPBAL,CLOSEDATE,EFFECTIVEDATE," & _
                           "NARRATION,ACCNO,TRANNO,BATCHNO," & _
                           "VERIFIEDBY,VERIFIEDMACHINE,SYSTEMDATE," & _
                           "CONTRACOMPLETE," & _
                           "APPROVEDBY,APPROVEDMACHINE,USERID,MACHINEID"
                           
             StrScrTab = "SCRDTLS"
                        
             StrScrVal(0) = "'" & brcode & "','" & curcode & "','" & GLCode & "'," & _
                             "'" & ApplDate & "','" & ApplDate & "'," & _
                             "'" & Amount & "','','','" & Narration & "','" & AccNo & "'," & _
                             "'" & tranno & "', " & _
                             "'" & batchno & "','','','','N','','','" & EnteredBy & _
                             "','" & EnteredMC & "'"
    End If
        
End If
    
   strInsDel = ObjTrans.InsertRecord(StrScrTab, StrScrFields, StrScrVal())
    If strInsDel <> "Trans Completed" Then
       SuspenceInsert = strInsDel
       SuspenceInsert = Replace(SuspenceInsert, Chr(10), "")
       SuspenceInsert = Replace(SuspenceInsert, Chr(13), "")

       Exit Function
    Else
   
        If Scrstatus = "SuspenceContra" Then
                StrScrTab = "SCRDTLS"
                StrScrFields = "CONTRACOMPLETE"
                StrScrVal(0) = "'" & Trim(SusConCom) & "'"
                StrMstWhr = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                UCase(curcode) & "' and tranno='" & Trim(SusConTranno) & "'" & _
                " and BATCHNO = " & SusConBatch & " and opDATE='" & SusConDate & "'"
        
          strInsDel = ObjTrans.UpdateRecord(StrScrTab, StrScrFields, StrScrVal, StrMstWhr)
     
        End If
     
      If strInsDel <> "Trans Completed" Then
         SuspenceInsert = strInsDel
         SuspenceInsert = Replace(SuspenceInsert, Chr(10), "")
         SuspenceInsert = Replace(SuspenceInsert, Chr(13), "")
        Exit Function
      End If
        SuspenceInsert = "Sucessfully Completed"
     Exit Function
 End If
'ErrHand:

End Function



Public Function SuspenceContraInsert(ByVal ModuleId As String, ByVal ModeofTran As String) As String
Dim StrScrConFields As String
Dim StrScrConTab As String
Dim StrScrConVal(0) As String
Dim strInsDel As String
Dim strInsUpdate As String
Dim strMstTab As String
Dim StrMstFields As String
Dim StrMstVal(0) As Variant
Dim StrMstWhr As String
Dim Scrstatus As String

'On Error GoTo ErrHand

strInsDel = ""
ApplDate = Format(CDate(ApplDate), "dd-mmm-yyyy")
If Len(Trim(SusConDate)) > 0 Then
    SusConDate = Format(CDate(SusConDate), "dd-mmm-yyyy")
End If
Scrstatus = ""
If (ModeofTran = "4" Or ModeofTran = "2" Or ModeofTran = "6") Then
    
     ' Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")

    If Len(Trim(SusConTranno)) > 0 Then
    
    
    '''''''''''''''''''''''''''''''''' ''''''''''''''''''''''''''''''''''''''''''''''
   ''''' checking whether Contra Amount is exceeding Original Amount
    Dim rsContra As ADODB.Recordset
    Dim rsSCRDtls As ADODB.Recordset
    
    Set rsContra = CreateObject("ADODB.Recordset")
    Set rsSCRDtls = CreateObject("ADODB.Recordset")
     
          
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    '''''''''''''''''' get Total Contra Amount posted from ContraDtls
    Set rsContra = objQuery.SingleRecordSet("SCRCONTRADTLS", "nvl(sum(abs(amount)),0)", _
        "ORIGINATINGTRANNO=" & SusConTranno & " and " & _
        " ORIGINATINGBATCHNO = " & SusConBatch & " and branchcode='" & brcode & "' " & _
        " and currencycode='" & curcode & "' and ORIGINATINGDATE='" & SusConDate & "'")
        
    MsgBox " Point 000"
    If Not rsContra.EOF And Not rsContra.BOF Then
    '''''''''''''''''' get Original Amount posted from SCRDtls
         Set rsSCRDtls = objQuery.SingleRecordSet("scrdtls", "nvl(abs(opbal),0)", _
            "TRANNO=" & SusConTranno & " and " & _
            " BATCHNO = " & SusConBatch & " and branchcode='" & brcode & "' " & _
            " and currencycode='" & curcode & "' and opDATE='" & SusConDate & "'")
    
        If Not rsSCRDtls.EOF And Not rsSCRDtls.BOF Then
            ''''''' if Contra amount already posted + amount that is about to post
            '''''''' is greater than original amount raise an exception
            If CDbl(Abs(rsContra(0))) + Abs(Amount) > Abs(CDbl(rsSCRDtls(0))) Then
                 SuspenceContraInsert = "Contra Amount is Exceeding Original Amount.."
                 Exit Function
            End If
        End If
      
    End If
   
   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    
            StrScrConFields = "BRANCHCODE,CURRENCYCODE,Amount,ORIGINATINGDATE," & _
                              "tranno,ORIGINATINGTRANNO," & _
                              "batchno,ORIGINATINGBATCHNO,APPLICATIONDATE," & _
                              "USERID,systemdate,MACHINEID,Narration"
            
            StrScrConTab = "SCRCONTRADTLS"
                       
            StrScrConVal(0) = "'" & brcode & "','" & curcode & "'," & Amount & "," & _
                            "'" & SusConDate & "','" & tranno & "'," & _
                            "'" & SusConTranno & "','" & batchno & "','" & SusConBatch & "'," & _
                            "'" & ApplDate & "','" & EnteredBy & "','" & ApplDate & "'," & _
                            "'" & EnteredMC & "','" & Narration & "'"
            Scrstatus = "Suspence"
    
   Else
         StrScrConFields = "BRANCHCODE,CURRENCYCODE,GLCODE,APPLICATIONDATE," & _
                             "OPDATE,OPBAL,CLOSEDATE,EFFECTIVEDATE," & _
                             "NARRATION,ACCNO,TRANNO,BATCHNO," & _
                             "VERIFIEDBY,VERIFIEDMACHINE,SYSTEMDATE," & _
                             "CONTRACOMPLETE," & _
                             "APPROVEDBY,APPROVEDMACHINE,USERID,MACHINEID"
         
        ' StrScrConTab = "SCRMST"
         StrScrConTab = "SCRDTLS"
         StrScrConVal(0) = "'" & brcode & "','" & curcode & "','" & GLCode & "'," & _
                         "'" & ApplDate & "','" & ApplDate & "'," & _
                         "'" & Amount & "','','','" & Narration & "','" & AccNo & "'," & _
                         "'" & tranno & "', " & _
                         "'" & batchno & "','','','','N','','','" & EnteredBy & _
                         "','" & EnteredMC & "'"
    End If
        
    strInsDel = ObjTrans.InsertRecord(StrScrConTab, StrScrConFields, StrScrConVal())
 
    If strInsDel <> "Trans Completed" Then
        SuspenceContraInsert = strInsDel
        SuspenceContraInsert = Replace(SuspenceContraInsert, Chr(10), "")
        SuspenceContraInsert = Replace(SuspenceContraInsert, Chr(13), "")
        Exit Function
      Else
    If Scrstatus = "Suspence" Then
    
        strMstTab = "SCRDTLS"
        StrMstFields = "CONTRACOMPLETE"
        
        StrMstVal(0) = "'" & Trim(SusConCom) & "'"
        
        'Code commented and rewritten by Radhika on 14 Oct 2008
        'Reason: Wrong query is using to update SCRDTLS
        'StrMstWhr = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
        'UCase(curcode) & "' and tranno='" & Trim(SusConTranno) & "'"
        
        StrMstWhr = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
        UCase(curcode) & "' and BATCHNO = " & SusConBatch & _
        " and TRANNO=" & SusConTranno & " and opDATE='" & SusConDate & "'"
               
        strInsDel = ObjTrans.UpdateRecord(strMstTab, StrMstFields, StrMstVal, StrMstWhr)
    End If

       If strInsDel <> "Trans Completed" Then
            SuspenceContraInsert = strInsDel
            SuspenceContraInsert = Replace(SuspenceContraInsert, Chr(10), "")
            SuspenceContraInsert = Replace(SuspenceContraInsert, Chr(13), "")
            Exit Function
        Else
            SuspenceContraInsert = "Sucessfully Completed"
        End If
    End If
    Exit Function
 End If
 
'ErrHand:


End Function


Public Function Loans() As String   'ynk
Dim strloanint, strloanchrg, strloaninsur As Double
Dim strloannpa, strloanexcess, strloanprinciple As Double
Dim strloantab As String
Dim strloanfield  As String
Dim strloanvals(0) As Variant
Dim recloanbal As ADODB.Recordset, recloanrecovery As ADODB.Recordset
Dim totDB, totCR, totBAL As Double
Dim strLoanTrnVal(0) As Variant
'On Error GoTo ErrHand
strInsDel = ""

If UCase(Trim(ModuleId)) = "LOAN" And ((ModeofTran = "2") Or (ModeofTran = "4")) Then 'if loans then fill interest charges
'crediting account
        Set recloanbal = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recloanbal = objQuery.SingleRecordSet("LOANRECOVERYBALDTLS", _
        "NVL(INTERESTBAL,0),NVL(INSURANCEBAL,0),NVL(CHARGESBAL,0),NVL(NPAINTERESTBAL,0)," & _
        " NVL(EXCESSBAL,0),NVL(principleBAL,0)", "BRANCHCODE='" & brcode & "' and " & _
        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
        " ACCNO='" & AccNo & "'")
        If objQuery.ConnError <> "Connected" Then
           Loans = objQuery.ConnError
           Exit Function
        End If
        
        
        If recloanbal.RecordCount > 0 Then
           strloanint = recloanbal(0)
           strloaninsur = recloanbal(1)
           strloanchrg = recloanbal(2)
           strloannpa = recloanbal(3)
           strloanexcess = recloanbal(4)
           strloanprinciple = recloanbal(5)
        'Else
           'Loans = "Table does not exit"
           'objContext.SetAbort
           'Exit Function
        End If
        
        
        
        
        Set recloanrecovery = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recloanrecovery = objQuery.SingleRecordSet("LOANRECOVERYDAYDTLS", _
        "nvl(sum(INTERESTCR)-sum(INTERESTDb),0),nvl(sum(INSURANCECR)-sum(INSURANCEDb),0),nvl(sum(CHARGESCR)-sum(CHARGESDb),0),nvl(sum(NPAINTERESTCR)-sum(NPAINTERESTDb),0)," & _
        " nvl(sum(EXCESSCR)-sum(EXCESSDb),0),nvl(sum(PRINCIPLECR)-sum(PRINCIPLEDb),0)", "BRANCHCODE='" & brcode & "' and " & _
        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
        " ACCNO='" & AccNo & "'")
           
        If recloanrecovery.RecordCount > 0 Then
           strloanint = CDbl(strloanint) + CDbl(recloanrecovery(0)) + CDbl(loanintcr)
           strloaninsur = CDbl(strloaninsur) + CDbl(recloanrecovery(1)) + CDbl(loaninsurcr)
           strloanchrg = CDbl(strloanchrg) + CDbl(recloanrecovery(2)) + CDbl(loanchrgcr)
           strloannpa = CDbl(strloannpa) + CDbl(recloanrecovery(3)) + CDbl(loannpacr)
           strloanexcess = CDbl(strloanexcess) + CDbl(recloanrecovery(4)) + CDbl(loanexcesscr)
           strloanprinciple = CDbl(strloanprinciple) + CDbl(recloanrecovery(5)) + CDbl(loanprinciplecr)
        'Else
           'Loans = "Table does not exit"
           'objContext.SetAbort
           'Exit Function
        End If

             
    strloantab = "LOANRECOVERYDAYDTLS"

    strloanfield = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,GLCode,batchno,tranno," & _
                   "LOANTYPE,AccNo,INTERESTDB,INTERESTCR,INTERESTBAL,CHARGESDB," & _
                   "CHARGESCR,CHARGESBAL,INSURANCEDB,INSURANCECR,INSURANCEBAL," & _
                   "NPAINTERESTDB,NPAINTERESTCR,NPAINTERESTBAL,EXCESSDB,EXCESSCR," & _
                   "EXCESSBAL,PRINCIPLEDB,PRINCIPLECR,PRINCIPLEBAL," & _
                   "TOTALDB,TOTALCR,TOTALBAL"
    
    totDB = ""
    totCR = CDbl(loanintcr) + CDbl(loanchrgcr) + CDbl(loaninsurcr) + _
            CDbl(loanexcesscr) + CDbl(loanprinciplecr)
    totBAL = CDbl(strloanint) + CDbl(strloanchrg) + CDbl(strloaninsur) + _
             CDbl(strloanexcess) + CDbl(strloanprinciple)
 
    strloanvals(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & GLCode & _
                     "','" & batchno & "','" & tranno & "','" & GLCode & "','" & AccNo & _
                     "','0','" & loanintcr & "','" & strloanint & "','0','" & _
                     loanchrgcr & "','" & strloanchrg & "','0','" & loaninsurcr & "','" & _
                     strloaninsur & "','0','" & loannpacr & "','" & _
                     strloannpa & "','0','" & loanexcesscr & "','" & strloanexcess & _
                     "','0','" & loanprinciplecr & "','" & strloanprinciple & _
                     "','" & totDB & "','" & totCR & "','" & totBAL & "'"

  
   strInsDel = ObjTrans.InsertRecord(strloantab, strloanfield, strloanvals)
               If strInsDel <> "Trans Completed" Then
                  Loans = strInsDel
                  Exit Function
               End If
   Loans = "Sucessfully Completed"
   
   Exit Function

ElseIf UCase(Trim(ModuleId)) = "LOAN" And ((ModeofTran = "1") Or (ModeofTran = "3")) Then 'if loans then fill interest charges
    'Debiting account

    If UCase(loancredit) = "PRINCIPLE" Then
        loanintdr = 0
        loannpadr = 0
        loanchrgdr = 0
        loaninsurdr = 0
        loanprncpledr = Amount
        loanexcessdr = 0
    ElseIf UCase(loancredit) = "CHARGES" Then
        loanintdr = 0
        loannpadr = 0
        loanchrgdr = Amount
        loaninsurdr = 0
        loanprncpledr = 0
        loanexcessdr = 0
    ElseIf UCase(loancredit) = "INTEREST" Then
        loanintdr = Amount
        loannpadr = 0
        loanchrgdr = 0
        loaninsurdr = 0
        loanprncpledr = 0
        loanexcessdr = 0
    ElseIf UCase(loancredit) = "INSURANCE" Then
        loanintdr = 0
        loannpadr = 0
        loanchrgdr = 0
        loaninsurdr = Amount
        loanprncpledr = 0
        loanexcessdr = 0
    ElseIf UCase(loancredit) = "NPA" Then
        loanintdr = 0
        loannpadr = Amount
        loanchrgdr = 0
        loaninsurdr = 0
        loanprncpledr = 0
        loanexcessdr = 0
    End If
    
    
    
    Set recloanbal = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recloanbal = objQuery.SingleRecordSet("LOANRECOVERYBALDTLS", _
        "NVL(INTERESTBAL,0),NVL(INSURANCEBAL,0),NVL(CHARGESBAL,0),NVL(NPAINTERESTBAL,0)," & _
        " NVL(EXCESSBAL,0),NVL(principleBAL,0)", "BRANCHCODE='" & brcode & "' and " & _
        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
        " ACCNO='" & AccNo & "'")
        
        
        
        If recloanbal.RecordCount > 0 Then
           strloanint = recloanbal(0)
           strloaninsur = recloanbal(1)
           strloanchrg = recloanbal(2)
           strloannpa = recloanbal(3)
           strloanexcess = recloanbal(4)
           strloanprinciple = recloanbal(5)
        'Else
           'Loans = "Table does not exit"
           'objContext.SetAbort
          ' Exit Function
        End If
        
        
        
        Set recloanrecovery = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recloanrecovery = objQuery.SingleRecordSet("LOANRECOVERYDAYDTLS", _
        "nvl(sum(INTERESTCR)-sum(INTERESTDb),0),nvl(sum(INSURANCECR)-sum(INSURANCEDb),0),nvl(sum(CHARGESCR)-sum(CHARGESDb),0),nvl(sum(NPAINTERESTCR)-sum(NPAINTERESTDb),0)," & _
        " nvl(sum(EXCESSCR)-sum(EXCESSDb),0),nvl(sum(PRINCIPLECR)-sum(PRINCIPLEDb),0)", "BRANCHCODE='" & brcode & "' and " & _
        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
        " ACCNO='" & AccNo & "'")
           
        If recloanrecovery.RecordCount > 0 Then
           strloanint = CDbl(strloanint) + CDbl(recloanrecovery(0)) - CDbl(Abs(loanintdr))
           strloaninsur = CDbl(strloaninsur) + CDbl(recloanrecovery(1)) - CDbl(Abs(loaninsurdr))
           strloanchrg = CDbl(strloanchrg) + CDbl(recloanrecovery(2)) - CDbl(Abs(loanchrgdr))
           strloannpa = CDbl(strloannpa) + CDbl(recloanrecovery(3)) - CDbl(Abs(loannpadr))
           strloanexcess = CDbl(strloanexcess) + CDbl(recloanrecovery(4)) - CDbl(Abs(loanexcessdr))
           strloanprinciple = CDbl(strloanprinciple) + CDbl(recloanrecovery(5)) - CDbl(Abs(loanprncpledr))
        'Else
           'Loans = "Table does not exit"
           'objContext.SetAbort
           'Exit Function
        End If

      
    strloantab = "LOANRECOVERYDAYDTLS"

    strloanfield = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,GLCode,batchno,tranno," & _
                   "LOANTYPE,AccNo,INTERESTCR,INTERESTDB,INTERESTBAL,CHARGESCR," & _
                   "CHARGESDB,CHARGESBAL,INSURANCEcr,INSURANCEdb,INSURANCEBAL," & _
                   "NPAINTERESTcr,NPAINTERESTdb,NPAINTERESTBAL,EXCESScr,EXCESSdb," & _
                   "EXCESSBAL,PRINCIPLECR,PRINCIPLEDB,PRINCIPLEBAL,TOTALDB,TOTALCR,TOTALBAL"
    
    totDB = Abs(loanintdr) + Abs(loanchrgdr) + Abs(loaninsurdr) + _
            Abs(loanexcessdr) + Abs(loanprncpledr)
    totCR = ""
    totBAL = CDbl(strloanint) + CDbl(strloanchrg) + CDbl(strloaninsur) + _
             CDbl(strloanexcess) + CDbl(strloanprinciple)
 
   strloanvals(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & GLCode & _
                     "','" & batchno & "','" & tranno & "','" & GLCode & "','" & AccNo & _
                     "','0','" & Abs(loanintdr) & "','" & strloanint & "','0','" & _
                     Abs(loanchrgdr) & "','" & strloanchrg & "','0','" & Abs(loaninsurdr) & _
                     "','" & strloaninsur & "','0','" & Abs(loannpadr) & "','" & _
                     strloannpa & "','0','" & Abs(loanexcessdr) & "','" & strloanexcess & _
                     "','0','" & Abs(loanprncpledr) & "','" & strloanprinciple & _
                     "','" & totDB & "','" & totCR & "','" & totBAL & "'"



   strInsDel = ObjTrans.InsertRecord(strloantab, strloanfield, strloanvals)
               If strInsDel <> "Trans Completed" Then
                   Loans = strInsDel
                   Exit Function
               End If
               
               
''''''''''''''''''''' Loan Disbursement Details''''''''''''''''''''''''''''''''''''''
   If UCase(loancredit) = "PRINCIPLE" Then
   
    strloantab = "loandisbursementdtls"
    Dim strWhrCondAdv As String

    
 ''''''''''''''' Check whether Loan Disbursement Details
 '''''''''''''''''are avialble or not for the selected loan
    strWhrCondAdv = "BRANCHCODE='" & brcode & "' and " & _
        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
        " ACCNO='" & AccNo & "' "
        
        strloanfield = "DISBURSEMENTDATE, DISBURSEMENTAMOUNT, INSTALLMENTNO, DISBURSMENETSTATUS"
        
        Set recloanrecovery = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        
        Set recloanrecovery = objQuery.SingleRecordSet("loandisbursementdtls", _
            strloanfield, strWhrCondAdv)


        If Not recloanrecovery.EOF And Not recloanrecovery.BOF Then
        ''''''''''''''if Loan Disrbursement Details available
        ''''''''''''''' then Check whether any pending Loan Disbursement Details
        '''''''''''''''''are avialble or not for the selected loan
            strWhrCondAdv = "BRANCHCODE='" & brcode & "' and " & _
                        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
                        " ACCNO='" & AccNo & "' and INSTALLMENTNO=(select min(INSTALLMENTNO) " & _
                        " from loandisbursementdtls where BRANCHCODE='" & brcode & "' and " & _
                        " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
                        " ACCNO='" & AccNo & "' and DISBURSMENETSTATUS='P' and " & _
                        " DISBURSEDDATE is null) "
                Set recloanrecovery = objQuery.SingleRecordSet("loandisbursementdtls", _
                    strloanfield, strWhrCondAdv)
                If Not recloanrecovery.EOF And Not recloanrecovery.BOF Then
                ''''''''''''''if Pending Loan Disrbursement Details available
                ''''''''''''''' then Check whether any Amount given is equal to
                '''''''''''''''''disbursement installment amount or not
                   If Abs(recloanrecovery!DISBURSEMENTAMOUNT) > Abs(Amount) Then
                    '''''''''''''' if disbursement amount is greater than transaction amount
                        Loans = "Disbursed Amount(" & Abs(Amount) & ") is Less than " & _
                            " the Installment Amount to be disbursed(" & _
                            Abs(recloanrecovery!DISBURSEMENTAMOUNT) & ").."
                        Exit Function
                    ElseIf Abs(recloanrecovery!DISBURSEMENTAMOUNT) < Abs(Amount) Then
                    '''''''''''''' if disbursement amount is less than transaction amount
                        Loans = "Disbursed Amount(" & Abs(Amount) & ") is Greater than " & _
                            " the Installment Amount to be disbursed(" & _
                            Abs(recloanrecovery!DISBURSEMENTAMOUNT) & ").."
                        Exit Function
                   Else
                   '''''''''''''' if disbursement amount is equal to transaction amount
                   ''''''''''''' update disbursement details and set disbursement status to C
                   ''''''''''''''' and disbursed date to transactiondate
                        strWhrCondAdv = "BRANCHCODE='" & brcode & "' and " & _
                            " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
                            " ACCNO='" & AccNo & "' and INSTALLMENTNO=(select min(INSTALLMENTNO) " & _
                            " from loandisbursementdtls where BRANCHCODE='" & brcode & "' and " & _
                            " CURRENCYCODE='" & curcode & "' and GLCode='" & GLCode & "' and " & _
                            " ACCNO='" & AccNo & "' and DISBURSMENETSTATUS='P' and " & _
                            " DISBURSEDDATE is null)"
            
                        strLoanTrnVal(0) = "'C'~'" & ApplDate & "'"
                        strloanfield = "DISBURSMENETSTATUS,DISBURSEDDATE"
                        strInsDel = ObjTrans.UpdateRecord(strloantab, strloanfield, strLoanTrnVal(), _
                                strWhrCondAdv)
                        If strInsDel <> "Trans Completed" Then
                           Loans = strInsDel
                           Loans = strWhrCondAdv
                           Exit Function
                        End If
                            
                   End If
                Else
                    '''''''''''''''' if no more pending disbursements available then message
                    Loans = "No more Disbursements are in Pending for this Loan.."
                    Exit Function
                End If
        Else
            '''''''''''''''' if disbursement details are not available then message
            Loans = "Disbursement Details are not Available for this Loan.."
            Exit Function
        End If


   
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    
            
    End If
          Loans = "Sucessfully Completed"
          
         Exit Function
End If
'ErrHand:
End Function

Public Function AccountOpening() As String
    Dim StrFldNames As String
    Dim strTabName As String
    Dim arrFldVal(0) As Variant
       
 'On Error GoTo ErrHand

      
    StrFldNames = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,batchno,tranno,GLCode,ACCNO," & _
                  "Amount,FAVOURING,ModeofTran,Status,ServiceId,Narration,CashierId," & _
                  "USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE,VERIFIEDBY,VERIFIEDMACHINE," & _
                  "systemdate,MODULEID,CATEGORYCODE,MASTERCOMPLETEDYN,FCURRENCYCODE,FAMOUNT"
                   
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & batchno & _
                   "','" & tranno & "','" & GLCode & "','" & AccNo & "','" & Amount & _
                   "','" & ApplName & "','" & ModeofTran & "','" & Status & "','" & _
                   ServiceId & "','" & Narration & "','" & CashierId & "','" & _
                   EnteredBy & "','" & EnteredMC & "','','','','',sysdate,'" & _
                   ModuleId & "','" & CatCode & "','N','" & FCurrCode & "','" & _
                   FAmount & "'"
    
    strTabName = "GENOPENRENTEMP"
           
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
   ''' MsgBox strInsDel
               If strInsDel <> "Trans Completed" Then
                  AccountOpening = strInsDel
                  AccountOpening = Replace(AccountOpening, Chr(10), "")
                  AccountOpening = Replace(AccountOpening, Chr(13), "")
                  Exit Function
               End If
           
    AccountOpening = "Sucessfully Completed"
    Exit Function
           
           
           
'ErrHand:

End Function



''------------------------------------------------------------------------------------------
''' this function is used to do transactions for clearing presentation
'''''' for updating status as 'P' in clglodgementvoucherdtls table
''''' for inserting records into genunclearbalancedtls table
'''''---------------------------------------------------------------------------------------
Public Function CLGOutwardReturn() As String
'''declaring variables
Dim StrFldNames As String
Dim strTabName As String
Dim StrValues(0) As Variant
'On Error GoTo ErrHand
strInsDel = ""

''' calling transaction component to do transactions(insert)
 ''Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
 ''''' storing values into variables for update the status in clglodgementvoucherdtls
    StrFldNames = "BRANCHCODE,CURRENCYCODE,LINKMODULEID,LINKGLCODE,LINKACCNO," & _
                "CHQSERIESNO,CHQNO,CHQFVG,CHQDATE,FAMOUNT,tRANSTATUS,USERID,MACHINEID," & _
                "SYSTEMDATE,APPLICATIONDATE,PRESENTINGBANKCODE,PRESENTINGBRANCHCODE," & _
                "Reasoncode,batchno,tranno,CLEARINGTYPE, INSTRTYPE"
    strTabName = "CLGOUTWARDRETURNDTLS"
      
    StrValues(0) = "'" & brcode & "','" & curcode & "','" & LinkModId & "'," & _
                    "'" & LinkGLCode & "','" & LinkAccNo & "','" & ChqSrs & "'," & _
                    "'" & ChqNo & "','" & ChqFVG & "'," & _
                    "to_date('" & ChqDate & "','dd-mm-yyyy')," & _
                    "" & Amount & ",'P','" & EnteredBy & "'," & _
                    "'" & EnteredMC & "',sysdate," & _
                    "to_date('" & ApplDate & "','dd-mm-yyyy'),'" & BankCode & "'," & _
                    "'" & PresBranchcode & "','" & Reasoncode & "'," & _
                    "'" & batchno & "','" & tranno & "','" & Trim(ClgRateType) & "','Cheque'"

    '''' calling transaction component insert method
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, _
                    StrValues)
                    
     
    '''if updation is not successfull goto errorhandle
    If strInsDel <> "Trans Completed" Then
       CLGOutwardReturn = strInsDel
       CLGOutwardReturn = Replace(CLGOutwardReturn, Chr(10), "")
       CLGOutwardReturn = Replace(CLGOutwardReturn, Chr(13), "")
       
       Exit Function
    End If
   ' Else
        CLGOutwardReturn = "Sucessfully Completed"
   '     objContext.SetAbort
        Exit Function
   ' End If
    
 '''error handling
'ErrHand:

End Function



Function LinkModule() As String
    Dim strTabName As String
    Dim StrFldNames As String
    Dim arrFldVal(0) As String
    
 
'On Error GoTo ErrHand
    
    strTabName = "GENDISPOSALDTLS"
    StrFldNames = "BRANCHCODE,CURRENCYCODE,ModuleId,GLCode,AccNo,CUSTOMERID,NAME," & _
                  "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,Amount," & _
                  "DISPOSALMODULEID,DISPOSALGLCODE,DISPOSALACCTYPE,DISPOSALACCNO," & _
                  "DISPOSALBATCHNO,DISPOSALTRANNO,LINKNO,DISPOSALSERVICEID,batchno," & _
                  "tranno,ModeofTran,EFFECTIVEDATE,REMARKS,TRANSTATUS,USERID,MACHINEID," & _
                  "VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                  "systemdate,APPLICATIONDATE,FROMDATE,TODATE"
   
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & LinkModId & "','" & LinkGLCode & _
                     "','" & LinkAccNo & "','" & CustId & "','" & Name & "',''," & _
                     "'','','" & LinkAccType & "','" & Amount & _
                     "','" & ModuleId & "','" & GLCode & "','','" & AccNo & "','','','','" & _
                     ServiceId & "','" & batchno & "','" & tranno & "','" & _
                     ModeofTran & "','" & EffDate & "','" & Narration & "','" & _
                     Status & "','" & EnteredBy & "','" & EnteredMC & "','','','',''," & _
                     "sysdate,'" & ApplDate & "','" & lockerPaiddate & "','" & _
                     lockerNextduedate & "'"
                     
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)

    If strInsDel <> "Trans Completed" Then
       LinkModule = strInsDel
       LinkModule = Replace(LinkModule, Chr(10), "")
       LinkModule = Replace(LinkModule, Chr(13), "")
       Exit Function
    End If
                         
    LinkModule = "Sucessfully Completed"
    Exit Function
                         
'ErrHand:
End Function




Public Function LockersForReceipts()

    Dim strRcpttab As String
    Dim strFlds As String
    Dim recLockMst As ADODB.Recordset
    Dim RsRentdtls  As ADODB.Recordset
    Dim RsSizePrm As ADODB.Recordset
    Dim RsDesc As ADODB.Recordset
    Dim NextDueDate, DueAmt, NextInst
    Dim i, Date1, Date2, DateString, DateDffr, NoOfInst, Inst, DecAmt
    Dim strlocvals(0) As Variant
    Dim strloctab As String
    Dim strlocfield  As String
    Dim ToDate, FromDate, PaidAmt, ApDate

   'On Error GoTo errhand

    Set recLockMst = CreateObject("adodb.recordset")
    Set RsRentdtls = CreateObject("adodb.recordset")
    Set RsSizePrm = CreateObject("adodb.recordset")
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")

    Set recLockMst = objQuery.SingleRecordSet("LOCKERMST", _
       "LOCKERUNIT,LOCKERSIZE,LOCKERNO,LOCKERKEYNO,NAME,CUSTOMERID," & _
       " to_char(OPDATE,'DD-Mon-YYYY'),GLCODE", "BRANCHCODE='" & _
       brcode & "' And currencycode='" & curcode & _
       "' AND GLCODE='" & LinkGLCode & "' And " & _
       " accno= '" & LinkAccNo & "'")

       If objQuery.ConnError <> "Connected" Then
         LockersForReceipts = objQuery.ConnError
         Exit Function
       End If
      If recLockMst.RecordCount > 0 Then
          Dim strMasterDtls
          strMasterDtls = ""

          For i = 0 To recLockMst.Fields.Count - 1
             strMasterDtls = strMasterDtls & recLockMst(i) & "|"
          Next
          
  
       Set RsRentdtls = objQuery.SingleRecordSet("LOCKERRENTDTLS", _
        "NVL(AMOUNT,0),TO_CHAR(fromdate,'DD-Mon-YYYY'),TO_CHAR(todate,'dd-Mon-YYYY')," & _
        "TO_CHAR(APPLICATIONDATE,'DD-Mon-YYYY')", "todate =(SELECT MAX(todate)" & _
        "FROM LOCKERRENTDTLS WHERE ACCNO='" & LinkAccNo & "' AND " & _
        "BRANCHCODE='" & brcode & "' and GLCODE='" & LinkGLCode & "') AND " & _
        "ACCNO='" & LinkAccNo & "' AND BRANCHCODE='" & brcode & "' AND " & _
        "GLCODE='" & LinkGLCode & "'")

        If RsRentdtls.RecordCount > 0 Then
            ToDate = RsRentdtls(2)
            FromDate = RsRentdtls(1)
            PaidAmt = RsRentdtls(0)
        '' added by monica on 30-Dec-2010
        Else
            ToDate = ApplDate
        End If
        
        'dim RsSizePrm as CreateObject("adodb.recordset")
      
      Set RsSizePrm = objQuery.SingleRecordSet("LOCKERRENTMST", "RENTAMOUNT," & _
        "RENTTYPE,RENTPERIOD,MODULEID,GLCODE,ACCNO", "SIZECODE='" & recLockMst(1) & "'")

      Dim RentAmt, RentType, RentPrd, DueDate, LkrModId, LkrGlCode, LkrAccno

     If RsSizePrm.RecordCount > 0 Then
        RentAmt = RsSizePrm(0)
        RentType = RsSizePrm(1)
        RentPrd = RsSizePrm(2)
        LkrModId = RsSizePrm(3)
        LkrGlCode = RsSizePrm(4)
        LkrAccno = RsSizePrm(5)
     End If
        If (RentType = "M") And (RsRentdtls.RecordCount = 0) Then
            ApplDate = DateAdd("D", 0, ApplDate)
            NextDueDate = DateAdd("M", RentPrd, ApplDate)
            NextDueDate = DateAdd("d", -1, NextDueDate)
            'NextDueDate = DateConvert(NextDueDate)
            DueAmt = 0
            '' added by monica on 30-Dec-2010
            ApplDate = Format(ApplDate, "dd-mmm-yyyy")
         ElseIf (RentType = "Y") And (RsRentdtls.RecordCount = 0) Then
            ApplDate = DateAdd("D", 0, ApplDate)
            NextDueDate = DateAdd("YYYY", RentPrd, ApplDate)
            NextDueDate = DateAdd("d", -1, NextDueDate)
            'NextDueDate = DateConvert(NextDueDate)
            DueAmt = 0
            '' added by monica on 30-Dec-2010
            ApplDate = Format(ApplDate, "dd-mmm-yyyy")
        ElseIf (RentType = "M") And (RsRentdtls.RecordCount > 0) Then
            NextDueDate = DateAdd("M", RentPrd, ToDate)
        ElseIf (RentType = "Y") And (RsRentdtls.RecordCount > 0) Then
            NextDueDate = DateAdd("YYYY", RentPrd, ToDate)

        End If

         If CDate(NextDueDate) < CDate(ApplDate) Then
                NextDueDate = ApplDate
         End If

  
  strInsDel = ""
  strloctab = "LOCKERRENTDTLS"

  strlocfield = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,batchno,tranno,AccNo," & _
  "Amount,FROMDATE, TODATE,GLCODE,status,systemdate,userid,machineid"

    strlocvals(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & _
                batchno & "','" & tranno & "','" & LinkAccNo & "','" & _
                Amount & "','" & Format(ToDate, "dd-mmm-yyyy") & _
                "','" & Format(NextDueDate, "dd-mmm-yyyy") & "','" & _
                LinkGLCode & "','R',sysdate,'" & EnteredBy & "','" & EnteredMC & "'"

    '" & Format(ToDate, "dd-mmm-yyyy")
    '" & Format(NextDueDate, "dd-mmm-yyyy") & "

    strInsDel = ObjTrans.InsertRecord("LOCKERRENTDTLS", strlocfield, strlocvals)

    'LockersForReceipts = strInsDel

              If strInsDel <> "Trans Completed" Then
                  LockersForReceipts = strInsDel
                 Exit Function
              End If

  LockersForReceipts = "Sucessfully Completed"
  Exit Function
  End If
errhand:
  LockersForReceipts = Err.Description

End Function



Public Function depCommCode() As String
    Dim StrFldNames As String
    Dim strTabName As String
    Dim arrFldVal(0) As Variant
    Dim NatofTran As String
    Dim PaidDate As String
    Dim PaidTrnNo As String
'On Error GoTo ErrHand

        If IsDate(PaidDate) Then
           PaidDate = Format(PaidDate, "dd-mmm-yyyy")
        Else
           PaidDate = ""
        End If
        
        If ServiceId = "2" Or ModeofTran = "1" Or ModeofTran = "3" Then
           NatofTran = "P"
           PaidTrnNo = ""
        ElseIf ModeofTran = "4" Then
           NatofTran = "I"
           PaidTrnNo = ""
        End If
        
        StrFldNames = "BRANCHCODE,CURRENCYCODE,GLCode,AccNo,batchno,tranno,ModeofTran," & _
                      "NATUREOFTRAN,Amount,PAIDDATE,PAIDTRANNO,APPLICATIONDATE,USERID," & _
                      "MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                      "systemdate,NARRATION"
          
        arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & GLCode & "','" & AccNo & _
                   "','" & batchno & "','" & tranno & "','" & ModeofTran & "','" & NatofTran & _
                   "','" & Amount & "','" & PaidDate & "','" & PaidTrnNo & "','" & _
                   ApplDate & "','" & EnteredBy & "','" & EnteredMC & "','" & _
                   "','','','',sysdate,'" & Narration & "'"
        
        strTabName = "DEPSTATEMENTDTLS"
        
        If UCase(ModuleId) = "FXDEP" Then
           StrFldNames = StrFldNames & ",FCURRENCYCODE,FAMOUNT"
           arrFldVal(0) = arrFldVal(0) & ",'" & FCurrCode & "','" & FAmount & "'"
           strTabName = "FXDEPSTATEMENTDTLS"
        End If
        
        strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
       
               If strInsDel <> "Trans Completed" Then
                  depCommCode = strInsDel
                  depCommCode = Replace(depCommCode, Chr(10), "")
                  depCommCode = Replace(depCommCode, Chr(13), "")
                  Exit Function
               End If
           
       depCommCode = "Sucessfully Completed"
       
       Exit Function
        
'ErrHand:

End Function





Private Function DepIntPosting() As String
'Desc : Deposit Interest Posting
    Dim StrFldNames As String
    Dim strTabName As String
    Dim arrFldVal(0) As Variant
    Dim NatofTran As String
    Dim PaidDate As String
    Dim PaidTrnNo As String
'On Error GoTo ErrHand

    StrFldNames = "BRANCHCODE,CURRENCYCODE,GLCode,AccNo,ROI,CALCULATEDFROMDATE," & _
        "CALCULATEDTODATE,LASTINTERESTAPPLIEDDATE,INTAMOUNT,APPLICATIONDATE," & _
        "USERID,MACHINEID,TRANSTATUS,Status,SYSTEMYEAR"
      
    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & DepGL & "','" & DepAccNo & _
        "'," & DepAccROI & ",'" & Format(DepAccIntCalcFromDt, "dd-mmm-yyyy") & "','" & _
        Format(DepAccIntCalcToDt, "dd-mmm-yyyy") & "','" & _
        Format(DepAccLastIntApplDt, "dd-mmm-yyyy") & "'," & _
        DepAccIntAmt & ",'" & ApplDate & "','" & EnteredBy & _
        "','" & EnteredMC & "','P','R'," & Year(ApplDate)
    
    strTabName = "DEPINTCALCULATIONDTLS"
    
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
    If strInsDel <> "Trans Completed" Then
       DepIntPosting = strInsDel
       DepIntPosting = Replace(DepIntPosting, Chr(10), "")
       DepIntPosting = Replace(DepIntPosting, Chr(13), "")
       Exit Function
    End If
    
    DepIntPosting = "Sucessfully Completed"
    
    Exit Function
        
'ErrHand:

End Function



Private Function DepIntAccrPosting() As String
'Desc : Deposit Interest Accrued Posting
    Dim StrFldNames As String
    Dim strTabName As String
    Dim arrFldVal(0) As Variant
    Dim NatofTran As String
    Dim PaidDate As String
    Dim PaidTrnNo As String
    
    strTabName = "DEPINTACCRUEDDTLS"

    StrFldNames = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, " & _
        "BATCHNO,TRANNO,INTAMOUNT, " & _
        "APPLICATIONDATE,USERID, MACHINEID, TRANSTATUS,SYSTEMYEAR"

    arrFldVal(0) = "'" & brcode & "','" & curcode & "','" & DepModule & "','" & _
        DepGL & "','" & DepAccNo & "'," & batchno & "," & tranno & "," & _
        DepAccIntAmt & ",'" & ApplDate & "','" & EnteredBy & "','" & _
        EnteredMC & "','P'," & Year(ApplDate)
    
    strInsDel = ""
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
    If strInsDel <> "Trans Completed" Then
       DepIntAccrPosting = strInsDel
       DepIntAccrPosting = Replace(DepIntAccrPosting, Chr(10), "")
       DepIntAccrPosting = Replace(DepIntAccrPosting, Chr(13), "")
       Exit Function
    End If
    
    DepIntAccrPosting = "Sucessfully Completed"
    
    Exit Function
End Function



'==================================biju
Public Function Lockers() As String
Dim strloctab As String
Dim strlocfield  As String
Dim strlocvals(0) As Variant

'On Error GoTo ErrHand

strInsDel = ""
    strloctab = "LOCKERRENTDTLS"

    strlocfield = "BRANCHCODE , CURRENCYCODE,APPLICATIONDATE,batchno,tranno,AccNo," & _
    "Amount,FROMDATE, TODATE,GLCODE,status,systemdate,userid,machineid"
   
    strlocvals(0) = "'" & brcode & "','" & curcode & "','" & ApplDate & "','" & _
                     batchno & "','" & tranno & "','" & LinkAccNo & "','" & _
                     Amount & "','" & Format(lockerPaiddate, "dd-mmm-yyyy") & _
                     "','" & Format(lockerNextduedate, "dd-mmm-yyyy") & "','" & _
                     LinkGLCode & "','R',sysdate," & "'" & EnteredBy & "','" & EnteredMC & "'"
    
    strInsDel = ObjTrans.InsertRecord(strloctab, strlocfield, strlocvals)
    
               If strInsDel <> "Trans Completed" Then
                  Lockers = strInsDel
                  Exit Function
               End If

Lockers = "Sucessfully Completed"

Exit Function

'ErrHand:

End Function


Public Function StandingInstructions() As String
    Dim strTabName As String
    Dim StrFldNames As String
    Dim Periodicity As String
    Dim intColCnt As Integer
    Dim dblRowCnt As Double
    Dim lastExcDt As Variant
    Dim nextExcDt As Variant
    Dim fldValues As String
    Dim strTrnWhCond As String
    'Dim strInsDel As String
    Dim recDispTab As ADODB.Recordset
    Dim arrFldVal(0) As String
    Dim arrFldValLink() As String
  
'On Error GoTo ErrHand
 
    strTabName = "SIDISPOSALDTLS"
    StrFldNames = "to_char(TODATE,'dd-Mon-yyyy') todate"
    strTrnWhCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                   UCase(curcode) & "' and upper(siaccno)='" & UCase(SIAccNo) & "' and " & _
                   "upper(sistatus)='S' and modeoftran=3"
    
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recDispTab = CreateObject("ADODB.Recordset")
    Set recDispTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strTrnWhCond)
    
    If objQuery.ConnError <> "Connected" Then
       StandingInstructions = objQuery.ConnError
       StandingInstructions = Replace(StandingInstructions, Chr(10), "")
       StandingInstructions = Replace(StandingInstructions, Chr(13), "")
       Exit Function
    End If
 
    If recDispTab.RecordCount > 0 Then
       lastExcDt = recDispTab!ToDate
    Else
       StandingInstructions = "No Data Found in SIDISPOSALDTLS"
       Exit Function
    End If
    
    strTabName = "SIMST"
    StrFldNames = "upper(periodicity) Periodicity"
    
    strTrnWhCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                   UCase(curcode) & "' and upper(accno)='" & UCase(SIAccNo) & "'"
                   
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recDispTab = CreateObject("ADODB.Recordset")
    Set recDispTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strTrnWhCond)
     
    If objQuery.ConnError <> "Connected" Then
       StandingInstructions = objQuery.ConnError
       StandingInstructions = Replace(StandingInstructions, Chr(10), "")
       StandingInstructions = Replace(StandingInstructions, Chr(13), "")
       Exit Function
    End If
       
    If recDispTab.RecordCount > 0 Then
        Periodicity = recDispTab!Periodicity
        If Periodicity = "D" Then
           nextExcDt = DateAdd("D", "1", lastExcDt)
        ElseIf Periodicity = "W" Then
           nextExcDt = DateAdd("D", "7", lastExcDt)
        ElseIf Periodicity = "M" Then
           nextExcDt = DateAdd("M", "1", lastExcDt)
        ElseIf Periodicity = "Q" Then
           nextExcDt = DateAdd("M", "3", lastExcDt)
        ElseIf Periodicity = "H" Then
           nextExcDt = DateAdd("M", "6", lastExcDt)
        ElseIf Periodicity = "Y" Then
           nextExcDt = DateAdd("M", "12", lastExcDt)
        Else
           StandingInstructions = "New Periodicity Found"
           Exit Function
        End If
    Else
        StandingInstructions = "Periodicity is Null for SI Acc No :" & SIAccNo
        Exit Function
    End If
    
         
    
    nextExcDt = Format(CDate(nextExcDt), "dd-mmm-yyyy")
    lastExcDt = Format(CDate(lastExcDt), "dd-mmm-yyyy")
    
    strTabName = "SIMST"
    StrFldNames = "LASTEXECUTIONDATE, NEXTEXECUTIONDATE"
    
    arrFldVal(0) = "'" & lastExcDt & "'~'" & nextExcDt & "'"
    
    strTrnWhCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                   UCase(curcode) & "' and upper(accno)='" & UCase(SIAccNo) & "'"
                   
    
    strInsDel = ObjTrans.UpdateRecord(strTabName, StrFldNames, arrFldVal(), strTrnWhCond)
    
    If strInsDel <> "Trans Completed" Then
       StandingInstructions = strInsDel
       StandingInstructions = Replace(StandingInstructions, Chr(10), "")
       StandingInstructions = Replace(StandingInstructions, Chr(13), "")
        Exit Function
      
    End If
     
       
    If UCase(LinkModId) = "LOCKER" Then
    
    strTabName = "SIDISPOSALDTLS"

    StrFldNames = "BRANCHCODE,CURRENCYCODE,ModuleId,GLCode,AccNo,CUSTOMERID,NAME," & _
                  "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,Amount," & _
                  "DISPOSALMODULEID,DISPOSALGLCODE,DISPOSALACCTYPE,DISPOSALACCNO," & _
                  "DISPOSALBATCHNO,DISPOSALTRANNO,LINKNO,DISPOSALSERVICEID,batchno," & _
                  "tranno,ModeofTran,EFFECTIVEDATE,REMARKS,TRANSTATUS,USERID,MACHINEID," & _
                  "VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                  "to_char(systemdate,'dd-Mon-yyyy'),to_char(APPLICATIONDATE,'dd-Mon-yyyy')," & _
                  "to_char(FROMDATE,'dd-Mon-yyyy'),to_char(TODATE,'dd-Mon-yyyy')"



    strTrnWhCond = "upper(branchcode)='" & UCase(brcode) & "' and upper(currencycode)='" & _
                   curcode & "' and batchno='" & batchno & "' and upper(siaccno)='" & _
                   UCase(SIAccNo) & "' and upper(sistatus)='S'"

    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recDispTab = CreateObject("ADODB.Recordset")
    Set recDispTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strTrnWhCond)
    
    If objQuery.ConnError <> "Connected" Then
       StandingInstructions = objQuery.ConnError
       StandingInstructions = Replace(StandingInstructions, Chr(10), "")
       StandingInstructions = Replace(StandingInstructions, Chr(13), "")
    Exit Function
    End If
    
    If recDispTab.RecordCount = 0 Then
       StandingInstructions = "No Data Found in SIDISPOSALDTLS"
       Exit Function
    End If


    StrFldNames = "BRANCHCODE,CURRENCYCODE,ModuleId,GLCode,AccNo,CUSTOMERID,NAME," & _
                  "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,Amount," & _
                  "DISPOSALMODULEID,DISPOSALGLCODE,DISPOSALACCTYPE,DISPOSALACCNO," & _
                  "DISPOSALBATCHNO,DISPOSALTRANNO,LINKNO,DISPOSALSERVICEID,batchno," & _
                  "tranno,ModeofTran,EFFECTIVEDATE,REMARKS,TRANSTATUS,USERID,MACHINEID," & _
                  "VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                  "systemdate,APPLICATIONDATE,FROMDATE,TODATE"


    ReDim arrFldValLink(recDispTab.RecordCount - 1) As String

    For dblRowCnt = 0 To recDispTab.RecordCount - 1

        For intColCnt = 0 To recDispTab.Fields.Count - 1
            arrFldValLink(dblRowCnt) = arrFldValLink(dblRowCnt) & "'" & recDispTab(intColCnt) & "',"
        Next intColCnt
        recDispTab.MoveNext
        arrFldValLink(dblRowCnt) = Mid(arrFldValLink(dblRowCnt), 1, Len(arrFldValLink(dblRowCnt)) - 1)

    Next dblRowCnt

    strTabName = "GENDISPOSALDTLS"
    strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldValLink)

    If strInsDel <> "Trans Completed" Then
       StandingInstructions = strInsDel
       StandingInstructions = Replace(StandingInstructions, Chr(10), "")
       StandingInstructions = Replace(StandingInstructions, Chr(13), "")
    Exit Function
    End If
    End If
     
    
    StandingInstructions = "Sucessfully Completed"
    Exit Function
     
     
     
'ErrHand:

End Function



Public Function DispCommCode() As String
    Dim strTabName As String
    Dim StrFldNames As String
    Dim intColCnt As Integer
    Dim dblRowCnt As Double
    
    Dim fldValues As String
    Dim strTrnWhCond As String
    Dim strInsDel As String
    Dim recDispTab As ADODB.Recordset
    Dim arrFldVal() As String
    Dim arrDisVal(0) As String
    Dim strSI As Boolean            ''''''' to flag SI Transactions
'On Error GoTo ErrHand
 
    strTabName = "GENDISPOSALDTLSTEMP"
                   
    StrFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCode,AccNo,CUSTOMERID,Name," & _
                  "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,RATETYPE," & _
                  "DEALINGROOMCODE,Rate,REFNO,to_char(REFDATE,'dd-Mon-yyyy')," & _
                  "RATECATEGORY,CROSSCURRENCYCODE,FCURRENCYCODE,FAmount,Amount," & _
                  "CORRBANKCODE,CORRBRANCHCODE,to_char(NOSTRODEBITDATE,'dd-Mon-yyyy')," & _
                  "to_char(NOSTROCREDITDATE,'dd-Mon-yyyy'),DISPOSALMODULEID," & _
                  "DISPOSALGLCODE,DISPOSALACCTYPE,DISPOSALACCNO,DISPOSALBATCHNO," & _
                  "DISPOSALTRANNO,LINKNO,DISPOSALSERVICEID,batchno,tranno," & _
                  "ModeofTran,to_char(EFFECTIVEDATE,'dd-Mon-yyyy'),CHARGETYPE," & _
                  "RESPONDINGBANKCODE,RESPONDINGSECTIONCODE," & _
                  "to_char(FROMDATE,'dd-Mon-yyyy'),to_char(TODATE,'dd-Mon-yyyy')," & _
                  "REMARKS,TRANSTATUS,USERID,MACHINEID,VERIFIEDBY," & _
                  "VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                  "to_char(systemdate,'dd-Mon-yyyy')," & _
                  "to_char(APPLICATIONDATE,'dd-Mon-yyyy'),CONTRAYN,CORRESPONDENTACCNO"
                  
                    
    
    'RATETYPEDESC,
    'DEALINGROOMDESC,FORWARDCONTRACTNAME,
    'RATECATEGORYDESC,CORRBANKDESC,CORRBRANCHDESC,
    'DISPOSALMODULEDESC ,DISPOSALGLDESC,
    'DISPOSALACCTYPEDESC,DISPOSALACCNAME,DISPOSALSERVICEDESC,
    'MODEOFTRANDESC, RESPONDINGBANKDESC,RESPONDINGSECTIONDESC,
    
                    
                    
 
    strTrnWhCond = "branchcode='" & brcode & "' and currencycode='" & curcode & _
                   "' and batchno='" & batchno & "'"
   
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recDispTab = CreateObject("ADODB.Recordset")
    Set recDispTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strTrnWhCond)
   
    If objQuery.ConnError <> "Connected" Then
       DispCommCode = objQuery.ConnError
       DispCommCode = Replace(DispCommCode, Chr(10), "")
       DispCommCode = Replace(DispCommCode, Chr(13), "")
       Exit Function
    End If
    If recDispTab.RecordCount = 0 Then
       strTabName = "SIDISPOSALDTLS"
       
       StrFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCode,AccNo,CUSTOMERID,Name," & _
                    "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,'','','','',''," & _
                    "'','','','',Amount,'','','','',DISPOSALMODULEID," & _
                    "DISPOSALGLCODE,DISPOSALACCTYPE,DISPOSALACCNO,DISPOSALBATCHNO," & _
                    "DISPOSALTRANNO,LINKNO,DISPOSALSERVICEID,batchno,tranno," & _
                    "ModeofTran,TO_CHAR(EFFECTIVEDATE,'dd-Mon-yyyy'),'','',''," & _
                    "TO_CHAR(FROMDATE,'dd-Mon-yyyy'),TO_CHAR(TODATE,'dd-Mon-yyyy')," & _
                    "REMARKS,TRANSTATUS,USERID,MACHINEID,VERIFIEDBY," & _
                    "VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                    "TO_CHAR(systemdate,'dd-Mon-yyyy')," & _
                    "TO_CHAR(APPLICATIONDATE,'dd-Mon-yyyy'),'',''"
       
       Set recDispTab = objQuery.SingleRecordSet(strTabName, StrFldNames, strTrnWhCond)
       If recDispTab.RecordCount = 0 Then
            DispCommCode = "No Data Found in GENDISPOSALDTLSTEMP"
            GoTo errhand
        End If
       strSI = True
       
    End If
        
    StrFldNames = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCode,AccNo,CUSTOMERID,Name," & _
                  "ServiceId,TRANSACTIONTYPE,REMITTANCETYPE,ACCTYPE,RATETYPE," & _
                  "DEALINGROOMCODE,Rate,REFNO,REFDATE,RATECATEGORY,CROSSCURRENCYCODE," & _
                  "FCURRENCYCODE,FAmount,Amount,CORRBANKCODE,CORRBRANCHCODE," & _
                  "NOSTRODEBITDATE,NOSTROCREDITDATE,DISPOSALMODULEID,DISPOSALGLCODE," & _
                  "DISPOSALACCTYPE,DISPOSALACCNO,DISPOSALBATCHNO,DISPOSALTRANNO,LINKNO," & _
                  "DISPOSALSERVICEID,batchno,tranno,ModeofTran,EFFECTIVEDATE,CHARGETYPE," & _
                  "RESPONDINGBANKCODE,RESPONDINGSECTIONCODE,FROMDATE,TODATE,REMARKS," & _
                  "TRANSTATUS,USERID,MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY," & _
                  "APPROVEDMACHINE,systemdate,APPLICATIONDATE,CONTRAYN,CORRESPONDENTACCNO"
     
     
    ReDim arrFldVal(recDispTab.RecordCount - 1) As String
    
    For dblRowCnt = 0 To recDispTab.RecordCount - 1
     
        For intColCnt = 0 To recDispTab.Fields.Count - 1
            arrFldVal(dblRowCnt) = arrFldVal(dblRowCnt) & "'" & recDispTab(intColCnt) & "',"
        Next intColCnt
        recDispTab.MoveNext
        arrFldVal(dblRowCnt) = Mid(arrFldVal(dblRowCnt), 1, Len(arrFldVal(dblRowCnt)) - 1)
    
    Next dblRowCnt
     If strSI = False Then
            strTabName = "GENDISPOSALDTLS"
            strInsDel = ObjTrans.InsertRecord(strTabName, StrFldNames, arrFldVal)
 
            If strInsDel <> "Trans Completed" Then
                DispCommCode = strInsDel
                DispCommCode = Replace(DispCommCode, Chr(10), "")
                DispCommCode = Replace(DispCommCode, Chr(13), "")
                Exit Function
            End If
 
 
        strTabName = "GENDISPOSALDTLSTEMP"
        StrFldNames = "TRANSTATUS"
        arrDisVal(0) = "'D'"
    Else
        strTabName = "SIDISPOSALDTLS"
        StrFldNames = "TRANSTATUS"
        arrDisVal(0) = "'D'"
    End If
    strInsDel = ObjTrans.UpdateRecord(strTabName, StrFldNames, arrDisVal, strTrnWhCond)
 
    If strInsDel <> "Trans Completed" Then
       DispCommCode = strInsDel
       DispCommCode = Replace(DispCommCode, Chr(10), "")
       DispCommCode = Replace(DispCommCode, Chr(13), "")
        Exit Function
    End If
     
     
    DispCommCode = "Sucessfully Completed"
    Exit Function
     
     
     
errhand:
     
End Function


