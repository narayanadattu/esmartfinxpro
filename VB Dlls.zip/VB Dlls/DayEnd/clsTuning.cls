VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "clsTuning"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Public Function changedpass() As Boolean
On Error GoTo errh
Dim strpassword As String
Dim resTable As ADODB.Recordset
Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strUserid = objPwd.getMU()
Set AdoConnObj = CreateObject("Adodb.Connection")
Dim resDBdate As New ADODB.Recordset
changedpass = False

 
With AdoConnObj

           .ConnectionString = "user id=scott;password=tiger" & _
            ";data source=" & strDataSource
           .CursorLocation = adUseClient
           .Provider = "MSDAORA"
           .Open

End With
    Set resDBdate = AdoConnObj.Execute("SELECT LatestDaybegindate FROM " & strUserid & ".DBDATE")
    

    Set resTable = CreateObject("Adodb.Recordset")
    
    
    strpassword = objPwd.getPassword(Format(resDBdate!LatestDaybegindate, "DD-MM-YYYY") & "/bank/city/grams")
    
    
    Set AdoConnObj = Nothing
    
    Call DBConnection
    
    AdoConnObj.Execute ("alter user " & strUserid & " identified by " & strpassword)

changedpass = True
Exit Function
errh:
changedpass = False


End Function


Public Function AnalyzeTables() As Boolean
On Error Resume Next
Dim i As Integer
Dim resTable As ADODB.Recordset

Call DBConnection
Set resTable = CreateObject("Adodb.Recordset")

'Selecting all tables belonging to tran_day and translog
Set resTable = AdoConnObj.Execute("SELECT TNAME FROM TAB WHERE TABTYPE = 'TABLE' AND " & _
" (TNAME LIKE '%TRANDAY' OR TNAME LIKE '%TRANSLOG' OR TNAME LIKE '%TEMP')AND TNAME NOT LIKE 'FX%'")

'Analyzing All tables
    For i = 0 To resTable.RecordCount - 1
        
        AdoConnObj.Execute ("Analyze table " & resTable!TNAME & _
        " compute statistics ")

        resTable.MoveNext
    Next
    resTable.Close
    Set resTable = Nothing
    AnalyzeTables = True
End Function

Public Function AnalyzeIndexes() As Boolean
On Error Resume Next
Call DBConnection
Dim i As Integer
Dim resIndex As ADODB.Recordset

Set resIndex = CreateObject("Adodb.Recordset")

'Selecting all Indexes into the recordset
Set resIndex = AdoConnObj.Execute("SELECT INDEX_NAME,TABLE_NAME " & _
                        " FROM ALL_INDEXES WHERE TABLE_OWNER ='" & strUserid & "' AND " & _
                        "(TABLE_NAME LIKE '%TRANDAY' OR TABLE_NAME LIKE '%TRANSLOG' OR TABLE_NAME LIKE '%TEMP') " & _
                        " AND TABLE_NAME NOT LIKE 'FX%'")

    
'Analyzing all Indexes
    For i = 0 To resIndex.RecordCount - 1
        
        AdoConnObj.Execute ("Analyze Index " & resIndex!INDEX_NAME & _
        " compute statistics ")
        AdoConnObj.Execute ("Alter Index " & resIndex!INDEX_NAME & _
        " rebuild ")
        resIndex.MoveNext
    Next
    resIndex.Close
    Set resIndex = Nothing
    AnalyzeIndexes = True
    
End Function

