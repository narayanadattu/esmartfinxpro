VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "DayEnd"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim RecEffected As String
Dim recSupplement As Recordset
Dim strQuery As String
Dim StrInsert As String
Dim StrCondition As String
Dim StrDelete As String
Dim recTransLog As Recordset
Dim recTranDay As Recordset
Dim recTemp As Recordset
Dim recBranch As Recordset
Dim recCurrency As Recordset
Dim recAppdate As Recordset
Dim recAccno As Recordset
Dim recDay As Recordset
Dim recGL As Recordset
Dim recDelete As Recordset
Dim recMstTabs As Recordset
Dim recTrans As Recordset
Dim recCash As Recordset
Dim recClg As Recordset
Dim recMod As Recordset
Dim appDate As String
Dim strValues As String
Dim recSeq As Recordset
Dim recCurbal As Recordset
Dim ColName As String
Dim ObjCont As ObjectContext
Dim recBrTemp As ADODB.Recordset
Dim strBrQuery As String

''Private Sub DBConnection()
''    Dim objdblink As Object
''    Dim ArrLink As Variant
''
'''************Oppening the connection to dblink*************
''On Error GoTo ErrHand
'''''' calling shared property manager for dblink
''
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
''
''    ConnError = ""
''    Set AdoConnObj = CreateObject("Adodb.Connection")
''    AdoConnObj.CursorLocation = adUseClient
''
''    'AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=esmart123;User ID=v3"
''    AdoConnObj.ConnectionTimeout = 120
''    AdoConnObj.CommandTimeout = 18000
''    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''
''    If AdoConnObj.State = 1 Then ConnError = "Connected"
''
''Exit Sub
''
''ErrHand:
''ConnError = "Connection Failed Due To : " & Err.Number & " : " & Err.Description
''End Sub




Public Function HoDayEnd(BranchCode As String, ApplicationDate As String)
On Error GoTo myErr

    Dim BrCode As String
    Dim appDate As String
    
        BrCode = BranchCode
        appDate = ApplicationDate
        ConnError = ""
        
        
        Call DBConnection
        If ConnError <> "Connected" Then HoDayEnd = ConnError: Exit Function
        
        Set recBranch = CreateObject("Adodb.Recordset")
        Set recCurrency = CreateObject("Adodb.Recordset")
        Set recAppdate = CreateObject("Adodb.Recordset")
        
        Set recCurrency = AdoConnObj.Execute("select count(*) cnt from tab where tname like 'GENHODAYENDDTLS' ")
        If recCurrency!cnt = 0 Then HoDayEnd = "GENHODAYENDDTLS table is missing"
        recCurrency.Close
        
        Set recCurrency = AdoConnObj.Execute("select CurrencyCode from GenCurrencyTypeMst ")
               
        If BrCode = "ALL" Then
            '''''' It day end is to be done for all branches
            Set recBranch = AdoConnObj.Execute("select BranchCode from GenApplicationdateMst where dayBeginStatus='O' " & _
                            " and DayEndStatus='N' ")
            If Not recBranch.EOF And Not recBranch.BOF Then
      
                GoTo myErr
       
            End If
            
           Set recBranch = AdoConnObj.Execute("select BranchCode from GenApplicationdateMst where HodayBeginStatus='O' " & _
                            " and HoDayEndStatus='N'")
        Else
            
            '''''' If day end is to be done for those branches for which day end
            ''''''''' is completed
            Set recBranch = AdoConnObj.Execute("select BranchCode from GenApplicationDateMst " & _
                            "where DayEndStatus='O'  and DayBeginStatus='O' and " & _
                            "applicationdate='" & appDate & "' and HodayBeginStatus='O' " & _
                            " and HoDayEndStatus='N'")
        End If
            StrCondition = ""
  
                                    
            If Not recBranch.EOF And Not recBranch.BOF Then
                Do While Not recBranch.EOF
                    
                    CheckFunExeStatus recBranch(0), "Executing HoDayend", appDate
''                    ObjCont.SetComplete
''                    Set ObjCont = Nothing
                    
                    If CheckFunExeStatus(recBranch(0), "Executing ABBUpdations", appDate) = False Then
                    
                            ''''''' ABB Upations
                            recCurrency.MoveFirst
                            Do While Not recCurrency.EOF
                                result = ABBUpdations(CStr(recBranch(0)), CStr(recCurrency(0)), appDate)
                                If result <> "Proceed" Then
                                    GoTo myErr
                                End If
                                recCurrency.MoveNext
                            Loop
                            
                    UpdateFunExeStatus recBranch(0), "Executing ABBUpdations", appDate
                    End If
                    
                    If CheckFunExeStatus(recBranch(0), "Executing DayBook", appDate) = False Then
                    
                            '''''''' Day book Updations
                            recCurrency.MoveFirst
                            Do While Not recCurrency.EOF
                                result = DayBook(CStr(recBranch(0)), CStr(recCurrency(0)), appDate)
                                If result <> "No Transaction found..." And result <> "Records Inserted.." Then
                                    GoTo myErr
                                End If
                                recCurrency.MoveNext
                            Loop
                   
                    UpdateFunExeStatus recBranch(0), "Executing DayBook", appDate
                    End If
                                      
                    If CheckFunExeStatus(recBranch(0), "Executing BalanceUpdation", appDate) = False Then
                    
                            ''''''' Balance Upations
                            recCurrency.MoveFirst
                            result = BalanceUpdation(CStr(recBranch(0)), appDate)
                             If result <> "Proceed" Then
                                 GoTo myErr
                            End If
                       
                    UpdateFunExeStatus recBranch(0), "Executing BalanceUpdation", appDate
                    End If
                       
                    If CheckFunExeStatus(recBranch(0), "Executing GLDayWiseBalance", appDate) = False Then
                    
                            '''''''' GL Day Wise Balance Updations
                            recCurrency.MoveFirst
                            Do While Not recCurrency.EOF
                                result = GLDayWiseBalance(CStr(recBranch(0)), CStr(recCurrency(0)), appDate)
                                If result <> "Records Inserted.." Then
                                    GoTo myErr
                                End If
                                recCurrency.MoveNext
                            Loop
                        
                    UpdateFunExeStatus recBranch(0), "Executing GLDayWiseBalance", appDate
                    End If
                    
                    If CheckFunExeStatus(recBranch(0), "Executing AbnormalBalanceUpdation", appDate) = False Then

                            ''''''' Abnormal Balance Upations
                            recCurrency.MoveFirst
                                
                            result = AbnormalBalanceUpdation(CStr(recBranch(0)), appDate)
                            If result <> "Proceed" Then
                                GoTo myErr
                            End If
                   
                    UpdateFunExeStatus recBranch(0), "Executing AbnormalBalanceUpdation", appDate
                    End If
                    
                    ''''''' Product Upations
                    recCurrency.MoveFirst
                    
                    
                    If CheckFunExeStatus(recBranch(0), "Executing DumpToBackup", appDate) = False Then
                    
                            ''''''' Taking Backups for necessary tables
                            result = DumpToBackup(CStr(recBranch(0)), appDate)
                               If result <> "Completed" Then
                                   GoTo myErr
                               End If
                       
                    UpdateFunExeStatus recBranch(0), "Executing DumpToBackup", appDate
                    End If
                    
                    If CheckFunExeStatus(recBranch(0), "Executing ALMProcedures", appDate) = False Then
                                   
                            ''''''''' ALM Module Updataion
                             Set recMstTabs = CreateObject("Adodb.Recordset")
                                 
                             Set recMstTabs = AdoConnObj.Execute("select moduleid from genModuleTypesmst " & _
                                            " where branchcode='" & CStr(recBranch(0)) & "' and " & _
                                            " implementedyn='Y' and moduleid='ALM'")
                            
                            If Not recMstTabs.EOF And Not recMstTabs.BOF Then
                                
                                result = ALMProcedures(CStr(recBranch(0)), appDate)
                                
                                If result <> "Proceed" Then
                                   GoTo myErr
                                End If
                            End If
                    
                     UpdateFunExeStatus recBranch(0), "Executing ALMProcedures", appDate
                    End If
                        
                        
                    If CheckFunExeStatus(recBranch(0), "Executing ATMCashReAllot", appDate) = False Then
                    
                        ''''''' ATM Upations
                        recCurrency.MoveFirst
                        Do While Not recCurrency.EOF
                            result = ATMCashReAllot(CStr(recBranch(0)), CStr(recCurrency(0)), appDate)
                            If result <> "Proceed" Then
                                GoTo myErr
                            End If
                            recCurrency.MoveNext
                        Loop
                    
                     UpdateFunExeStatus recBranch(0), "Executing ATMCashReAllot", appDate
                    End If
                        
                        
'                    ''''''''' TM Module Updataion
'                     Set recMstTabs = CreateObject("Adodb.Recordset")
'
'                     Set recMstTabs = AdoConnObj.Execute("select moduleid from genModuleTypesmst " & _
'                                    " where branchcode='" & CStr(recBranch(0)) & "' and " & _
'                                    " implementedyn='Y' and moduleid='TM'")
'
'                    If Not recMstTabs.EOF And Not recMstTabs.BOF Then
'
'                        result = TMProcedures(CStr(recBranch(0)), appDate)
'
'                        If result <> "Proceed" Then
'                           GoTo myerr
'                        End If
'                    End If
                        
                    Set ObjCont = GetObjectContext
                    
                    '''''' Update Ho Day end status to over
                    AdoConnObj.Execute ("Update GenApplicationdateMst set " & _
                                        "HodayBeginStatus='O' , HodayEndStatus='O'" & _
                                        " where Branchcode='" & CStr(recBranch(0)) & "'")
                    
                    AdoConnObj.Execute ("delete from GENHODAYENDDTLS where BRANCHCODE='" & CStr(recBranch(0)) & _
                    "' and APPLICATIONDATE='" & appDate & "' and MESSAGE<>'Executing HoDayend'")
                     
                    UpdateFunExeStatus recBranch(0), "Executing HoDayend", appDate
                    
                    '''''' Commit  HO Day End for a for praticular branch
''                    ObjCont.SetComplete
''                    Set ObjCont = Nothing
                    
                    recBranch.MoveNext
                Loop

            Else
                Set ObjCont = GetObjectContext
                result = "Branch Day End is not completed for any Branch. HO Day End is aborted.."
                GoTo myErr
            End If
                                

    
    HoDayEnd = "HO Day End is Completed Successfully.." & ch



Exit Function
myErr:
    If result <> "" Then
        ObjCont.SetAbort
        Set ObjCont = Nothing
    End If
    If result <> "" Then
        HoDayEnd = result & Err.Description & " ; " & AdoConnObj.State
    Else
        HoDayEnd = Err.Description & " ; " & AdoConnObj.State
    End If

End Function


Private Function CheckFunExeStatus(strBrCode As String, strMessage As String, strappldate As String) As Boolean
Dim rsHOdtls As New ADODB.Recordset
CheckFunExeStatus = True

    Set rsHOdtls = AdoConnObj.Execute("select count(*) cnt from GENHODAYENDDTLS where BRANCHCODE='" & strBrCode & _
    "' and CURRENCYCODE='INR' AND MESSAGE='" & strMessage & "' and APPLICATIONDATE='" & strappldate & "' and STATUS='C'")
    
    If rsHOdtls!cnt = 1 Then
        CheckFunExeStatus = True
    ElseIf rsHOdtls!cnt = 0 Then
        CheckFunExeStatus = False
        Set ObjCont = GetObjectContext
        
        
        AdoConnObj.Execute ("DELETE GENHODAYENDDTLS WHERE BRANCHCODE='" & strBrCode & _
        "' and CURRENCYCODE='INR' AND MESSAGE='" & strMessage & "' and APPLICATIONDATE='" & strappldate & "'")
        
        AdoConnObj.Execute ("insert into GENHODAYENDDTLS(BRANCHCODE, CURRENCYCODE, MODULEID, MESSAGE, APPLICATIONDATE, " & _
        "STATUS) values('" & strBrCode & "','INR','','" & strMessage & "','" & strappldate & "','R')")
        
        ObjCont.SetComplete
        Set ObjCont = Nothing
        
        Set ObjCont = GetObjectContext

    End If

End Function

Private Function UpdateFunExeStatus(strBrCode As String, strMessage As String, strappldate As String)

AdoConnObj.Execute ("update GENHODAYENDDTLS set status='C', enddate=sysdate where BRANCHCODE='" & strBrCode & _
    "' and CURRENCYCODE='INR' AND MESSAGE='" & strMessage & "' and APPLICATIONDATE='" & strappldate & "'")
    
        ObjCont.SetComplete
        Set ObjCont = Nothing
    
End Function

Public Function DumpToBackup(BranchCode As String, ApplicationDate As String)
On Error GoTo myErr
Dim BrCode As String
Dim appDate As String
Dim icnt As Integer

    BrCode = BranchCode
    appDate = ApplicationDate
    
    StrCondition = " Where Branchcode='" & BrCode & _
                    "' and applicationdate='" & appDate & "'"

    Set recTransLog = CreateObject("Adodb.Recordset")
    Set recTranDay = CreateObject("Adodb.Recordset")
    Set recTemp = CreateObject("Adodb.Recordset")
    Set recDay = CreateObject("Adodb.Recordset")

    ''''''''''' Querying all Translog table names
    'strquery = "Select Tname from Tab where Tname like '%TRANSLOG'"
    strQuery = "Select Tname from Tab where tabtype='TABLE' and Tname like '%TRANSLOG'"

    Set recTransLog = AdoConnObj.Execute(strQuery)

    ''''''''''' Querying all Tran table names
    strQuery = "Select TRANDAYTABLE from GENMODULEMST where TRANDAYTABLE is not null "
    Set recTranDay = AdoConnObj.Execute(strQuery)

    ''''''''''' Querying all Temp table names
    strQuery = "Select Tname from Tab where tabtype='TABLE' and " & _
        " Tname like '%TEMP' and tname not like 'INTERNET%'"
    Set recTemp = AdoConnObj.Execute(strQuery)
    

    ''''''''''' Querying all table names which are to be flushed and deleted
    strQuery = "Select TABLENAME,BACKUPTABLENAME from GENBACKUPINFO "
    Set recDay = AdoConnObj.Execute(strQuery)
    
    ''''''''''' Querying all table names which are to be flushed and deleted
    strQuery = "Select TABLENAME from GENDELETETABLEATDAYEND "
    Set recDelete = AdoConnObj.Execute(strQuery)
    
    '''''''''''' Moving ABB transactions to backup
     ''  Changed condition to move all ABB Transactions into Backup Table irrespective of Branch
     ''  This Code will work if all Branches DayEnd is completed.
     
    ''skip APP trans kishore
    result = "Insert into GENTRANSLOGBKP Select * from GENTRANSLOG a" & _
                " where (abbbranchcode is not null and branchcode='" & BrCode & "') OR " & _
                " (branchcode in(Select branchcode from GENAPPLICATIONDATEMST " & _
                " where ((a.applicationdate<>applicationdate) " & _
                " or (hodaybeginstatus='O' and hodayendstatus='O')) " & _
                " and abbbranchcode='" & BrCode & "'))"
               
               
    AdoConnObj.Execute (result)
    
    ''check while execution kishore
    result = " Delete from GENTRANSLOG a" & _
                " where (abbbranchcode is not null and branchcode='" & BrCode & "') OR " & _
                " (branchcode in (Select branchcode from GENAPPLICATIONDATEMST " & _
                " where ((a.applicationdate<>applicationdate) " & _
                " or (hodaybeginstatus='O' and hodayendstatus='O')) " & _
                " and abbbranchcode='" & BrCode & "'))"
    
     AdoConnObj.Execute (result)
    
    '' Moving ABB Transactions from GenTempTranslog to GenTempTransLogBkp
    
        result = "Insert into GENTEMPTRANSLOGBKP Select * from GENTEMPTRANSLOG a" & _
                " where (abbbranchcode is not null and branchcode='" & BrCode & "') OR " & _
                " (branchcode in(Select branchcode from GENAPPLICATIONDATEMST " & _
                " where ((a.applicationdate<>applicationdate) " & _
                " or (hodaybeginstatus='O' and hodayendstatus='O')) " & _
                " and abbbranchcode='" & BrCode & "'))"
               
               
         AdoConnObj.Execute (result)
    
         result = " Delete from GENTEMPTRANSLOG a" & _
                " where (abbbranchcode is not null and branchcode='" & BrCode & "') OR " & _
                " (branchcode in (Select branchcode from GENAPPLICATIONDATEMST " & _
                " where ((a.applicationdate<>applicationdate) " & _
                " or (hodaybeginstatus='O' and hodayendstatus='O')) " & _
                " and abbbranchcode='" & BrCode & "'))"
    
         AdoConnObj.Execute (result)
     
     '' END of Moving ABB Transactions from GenTempTranslog to GenTempTransLogBkp
     
    result = "Insert into ABBTran select * from ABBTranday Where Branchcode='" & BrCode & "'"
    
    AdoConnObj.Execute (result)
    
    result = "Delete from ABBtranday Where Branchcode='" & BrCode & "'"
    
    AdoConnObj.Execute (result)
    
    '''''''' dump Translog to TranslogDEM tables and Delete all translog tables
    If Not recTransLog.EOF And Not recTransLog.BOF Then
        icnt = 0
        Do While Not recTransLog.EOF
              StrInsert = "Insert into " & recTransLog(0) & "BKP " & _
                "Select * from " & recTransLog(0) & " Where Branchcode='" & BrCode & "'" & _
                " and Abbbranchcode is null "
                        
            StrDelete = "Delete from " & recTransLog(0) & " Where Branchcode='" & BrCode & "'" & _
                        " and Abbbranchcode is null "
            result = StrInsert
            AdoConnObj.Execute StrInsert
            result = StrDelete
            AdoConnObj.Execute StrDelete
            recTransLog.MoveNext
        Loop
    End If
    
    'Delete data from table "GenTempTransLog"
    StrDelete = "Delete from GenTempTransLog Where Branchcode='" & BrCode & "'" & _
                " and Abbbranchcode is null "
    result = StrInsert
    AdoConnObj.Execute StrInsert
            
    
    '''''''' dump Tranday tables to Tran tables and Delete all Tranday tables
    If Not recTranDay.EOF And Not recTranDay.BOF Then
        icnt = 0
        Do While Not recTranDay.EOF
            
            
            StrInsert = "Insert into " & Left(recTranDay(0), Len(recTranDay(0)) - 3) & " " & _
                "Select * from " & recTranDay(0) & " Where Branchcode='" & BrCode & "'"
            
            StrDelete = "Delete from " & recTranDay(0) & " Where Branchcode='" & BrCode & "'"
            result = StrInsert
            AdoConnObj.Execute StrInsert
            result = StrDelete
            AdoConnObj.Execute StrDelete
            recTranDay.MoveNext
        Loop
    End If
    
    ''''''''''' Delete all temp tables
    If Not recTemp.EOF And Not recTemp.BOF Then
        icnt = 0
        Do While Not recTemp.EOF
            StrDelete = "Delete from " & recTemp(0) & " where Branchcode='" & BrCode & "'"
            result = StrDelete
            AdoConnObj.Execute StrDelete
            recTemp.MoveNext
        Loop
    End If
    
    '''''''' dump tables to backup tables and Delete all tables which are mentioned
    '''''''' in GenBackUpInfo
    If Not recDay.EOF And Not recDay.BOF Then
        icnt = 0
        Do While Not recDay.EOF
            
            
            StrInsert = "Insert into " & recDay(1) & " " & _
                        "Select * from " & recDay(0) & " Where Branchcode='" & BrCode & "'"
            
            StrDelete = "Delete from " & recDay(0) & " Where Branchcode='" & BrCode & "'"
            result = StrInsert
            AdoConnObj.Execute StrInsert
            result = StrDelete
            AdoConnObj.Execute StrDelete
            recDay.MoveNext
        Loop
    End If
    
    ''''''''''' Delete data from tables which are listed in "GENDELETETABLEATDAYEND" table
    If Not recDelete.EOF And Not recDelete.BOF Then
        icnt = 0
        Do While Not recDelete.EOF
            'StrDelete = "Delete from " & recDelete(0) & StrCondition
            StrDelete = "Delete from " & recDelete(0) & " Where Branchcode='" & BrCode & "'"
            result = StrDelete
            AdoConnObj.Execute StrDelete
            recDelete.MoveNext
        Loop
    End If
    
    DumpToBackup = "Completed"
    Exit Function
myErr:
    
    DumpToBackup = result & " " & Err.Description
End Function

Public Function ATMCashReAllot(BranchCode As String, CurrencyCode As String, ApplicationDate As String)

On Error GoTo myErr
    
    result = "SELECT nvl(IMPLEMENTEDYN,'N')  IMPLEMENTEDYN FROM GENMODULETYPESMST WHERE moduleid='ATM' " & _
    " and branchcode='" & BranchCode & "'"
    Set recMod = AdoConnObj.Execute(result)
    
    If Not recMod.EOF Or Not recMod.BOF Then
    
        If recMod(0) = "N" Then
                ATMCashReAllot = "Proceed"
                Exit Function
        End If
    Else
            ATMCashReAllot = "Proceed"
            Exit Function
    End If
    
    result = "Insert into CASHALLOTMENTSTRN(BRANCHCODE, CURRENCYCODE, CASHIERID, COUNTERNO," & _
      " ALLOTMENTNO, ALLOTMENTDATE, ACCEPTEDDATE, ACCEPTEDUSERID, ALLOTEDUSERID," & _
      " ALLOTEDMACHINEDID, ACCEPTEDMACHINEID, AMOUNTALLOTED,APPLICATIONDATE, USERID," & _
      " MACHINEID,STATUS,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE)" & _
      " select BRANCHCODE, CURRENCYCODE, CASHIERID, COUNTERNO,1," & _
      " to_char(applicationdate+1,'dd-Mon-yyyy'),to_char(applicationdate+1,'dd-Mon-yyyy')," & _
      " 'SYS','SYS','SYS','SYS',TOTAMOUNT,TO_CHAR(applicationdate+1,'dd-Mon-yyyy'),'SYS'," & _
      " 'SYS','A', SYSTEMDATE, 'SYS','SYS','SYS','SYS' FROM ATMCASHPOSMST where" & _
      " BRANCHCODE='" & BranchCode & "'"
      
    AdoConnObj.Execute (result)
    
    result = "Insert into ATMCASHPOSMSTHIST select * from ATMCASHPOSMST where" & _
      " BRANCHCODE='" & BranchCode & "'"
    
    AdoConnObj.Execute (result)
    
    
    result = "update ATMCASHPOSMST set applicationdate=to_char(applicationdate+1,'dd-Mon-yyyy') where" & _
      " BRANCHCODE='" & BranchCode & "'"
    
    AdoConnObj.Execute (result)
    
    ATMCashReAllot = "Proceed"
    
 Exit Function
 
myErr:
    
    ATMCashReAllot = result & " " & Err.Description

End Function

''''''''''''''' to prepare Day Book at Day End
Public Function DayBook(BranchCode As String, CurrencyCode As String, ApplicationDate As String)
On Error GoTo myErr
    ''''''' Variables Declaration
    Dim appDate As String
    Dim BrCode As String
    Dim CRCode As String
    Dim StrString As String

    
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    CRCode = CurrencyCode
    
    ''''' Createing Instances of  recordsets
    Set recSupplement = CreateObject("adodb.recordset")
        
    ''''' Setting variable values
    
    ''''' Temp Table name
    StrTabName = "RepSupplementaryTemp"
    
    ''''' Field names to temp table
    strflds = "BRANCHCODE,BRANCHNARRATION,CURRENCYCODE,CURRENCYNARRATION," & _
                "MODULEID,GLCODE,GLNarration,ACCNO,NAME,TRANNO,DRCASH,DRTRAN,DRCLG," & _
                "CRCASH,CRTRAN,CRCLG,APPLICATIONDATE,REPNO,USERID"
    
    ''''''' Query fields
    qryflds = " a.branchcode,x.narration,a.currencycode,y.narration," & _
            "a.moduleid,a.glcode,z.narration,a.accno,a.name," & _
            "a.tranno, decode(a.modeoftran,'1',b.amount,null) DRCASH ," & _
            "decode(a.modeoftran,'3',b.amount,null) DRTRAN ," & _
            "decode(a.modeoftran,'5',b.amount,null) DRCLG ," & _
            "decode(a.modeoftran,'2',b.amount,null) CRCASH , " & _
            "decode(a.modeoftran,'4',b.amount,null) CRTRAN ," & _
            "decode(a.modeoftran,'6',b.amount,null) CRCLG,'" & UCase(appDate) & "',999,'CHANDANA'"
    
    ''''' Query Tables
    qrytable = "GenTransLog a,GenTransLog b,GenBankBranchMst x,GenCurrencyTypeMst y," & _
                "GenGlSheetMst z"
  
    '''''' Query condition
    qrycondition = "a.branchcode = b.branchcode And a.currencycode = b.currencycode " & _
                " and a.branchcode='" & BrCode & "' and a.currencycode='" & CRCode & "'" & _
                " and to_char(a.applicationdate,'dd-MON-yyyy')='" & UCase(appDate) & "' and a.modeoftran=b.modeoftran " & _
                " and a.tranno=b.tranno and a.batchno=b.batchno " & _
                " and a.branchcode=x.branchcode and b.branchcode=x.branchcode " & _
                " and a.currencycode=y.currencycode and b.currencycode=y.currencycode " & _
                " and upper(a.glcode)=upper(z.glcode) " & _
                " and upper(b.glcode)=upper(z.glcode) " & _
                " and z.branchcode=x.branchcode " & _
                " order by a.glcode,a.accno,a.batchno,a.modeoftran"

    
    strQuery = "   Select " & qryflds & "  from " & qrytable & " where " & qrycondition
    
    result = StrInsert
    
    StrInsert = "Insert into " & StrTabName & "( " & strflds & ") " & strQuery
                        
                        
    ''''''' Insert into Supplementary Temp
     AdoConnObj.Execute StrInsert
         
        
        ''''' GenGLDayBokk Table columns
        strflds = "Branchcode,CurrencyCode,Moduleid,GLcode,GLNarration,Total1,Total3,Total5,GTotal1," & _
              "Total2,Total4,Total6,GTotal2,Effect"
        
        ''''' Query columns of GenSupplementaryTemp
        ''''' It includes dr grand total and cr grand total
        qryflds = "branchcode,currencycode,Moduleid,Glcode,GLNarration," & _
               "nvl(sum(drcash),0),nvl(sum(drtran),0),nvl(sum(drclg),0)," & _
               "nvl(sum(drcash),0)+nvl(sum(drtran),0)+" & _
               "nvl(sum(drclg),0)," & _
               "nvl(sum(crcash),0),nvl(sum(crtran),0),nvl(sum(crclg),0)," & _
               "nvl(sum(crcash),0)+nvl(sum(crtran),0)+nvl(sum(crclg),0)," & _
               "(nvl(sum(drcash),0)+nvl(sum(drtran),0)+nvl(sum(drclg),0))+" & _
               "(nvl(sum(crcash),0)+nvl(sum(crtran),0)+nvl(sum(crclg),0))"
        
        ''''' Query table name
        qrytable = "RepSupplementaryTemp"
        
        ''''' Query condition
        ''''' This is a constant condition based on which the inserted records will
        ''''' be queried and deleted after insertion
        qrycondition = "repno=999 and upper(userid)='CHANDANA' " & _
                    "group by branchcode,moduleid,glcode,currencycode,glnarration"
        
        strQuery = "Select " & qryflds & ",'" & appDate & "'  from " & qrytable & " where " & qrycondition
        
        ''if no row is available in GenGLDayBook then insert or update the existing row kishroe
        StrInsert = "Insert into GenGLDayBook( " & strflds & ",Applicationdate ) " & strQuery
                            
        result = StrInsert
        
        AdoConnObj.Execute StrInsert
        
        ''''''' Update Closing Balance
        
        StrInsert = "Update GenGlDayBook a set ClosingBalance=Effect+nvl((" & _
                    " select ClosingBalance from GenGlDayBook where applicationdate=" & _
                    " (select max(applicationdate) from GenGlDayBook where " & _
                    " applicationdate<'" & appDate & "' and glcode=a.glcode " & _
                    " and branchcode='" & BrCode & "' and currencycode=a.currencycode ) " & _
                    " and glcode=a.glcode  and currencycode=a.currencycode and branchcode='" & BrCode & "' ),0), " & _
                    " OpeningBalance=nvl((" & _
                    " select ClosingBalance from GenGlDayBook where applicationdate=" & _
                    " (select max(applicationdate) from GenGlDayBook where " & _
                    " applicationdate<'" & appDate & "' and glcode=a.glcode  " & _
                    " and branchcode='" & BrCode & "' and currencycode=a.currencycode ) " & _
                    " and glcode=a.glcode  and currencycode=a.currencycode and branchcode='" & BrCode & "'),0) " & _
                    " where applicationdate='" & appDate & "' and currencycode='" & CRCode & "'" & _
                    " and branchcode='" & BrCode & "'"
                    
        result = StrInsert
        
        AdoConnObj.Execute StrInsert
        
        ''''' Delete records from temporary table
        StrTabName = "RepSupplementaryTemp"
        StrCondition = "repno=999 and upper(userid)='CHANDANA' "
        StrDelete = "Delete from " & StrTabName & " Where " & StrCondition
       
        result = StrDelete
        
        AdoConnObj.Execute StrDelete
            
        result = "Records Inserted.."
            
        DayBook = result
    
        Exit Function
    
myErr:
    result = result & "    " & Err.Description
    DayBook = result
    
End Function

Public Function GLDayWiseBalance(BranchCode As String, CurrencyCode As String, ApplicationDate As String)
On Error GoTo myErr
    
    Dim appDate As String
    Dim BrCode As String
    Dim CRCode As String
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    CRCode = CurrencyCode

''''' Createing Instances of  recordsets
                   
    ''if row is present then update or insert
    StrInsert = "Insert into GlDayWiseBalance(BranchCode,CurrencyCode,ModuleId," & _
                " GlCode,ApplicationDate,Dayeffect)  " & _
                " Select BranchCode,CurrencyCode,ModuleId,GlCode,'" & appDate & _
                "',dayEffect+nvl((Select Effect from genGlDaybook where " & _
                " ApplicationDate='" & appDate & "' and a.Glcode=Glcode and " & _
                " BranchCode='" & BrCode & "' and currencycode='" & CRCode & "'" & _
                "),0) from GlDaywisebalance a where ApplicationDate=" & _
                "(Select Max(ApplicationDate) from glDayWiseBalance where " & _
                " BranchCode= '" & BrCode & "' and currencycode='" & CRCode & "') and branchcode='" & BrCode & _
                "'and currencycode='" & CRCode & "'"
                
    
    
    AdoConnObj.Execute StrInsert
    result = "Records Inserted.."
    GLDayWiseBalance = result
    
    Exit Function
myErr:
    result = StrInsert & "  " & Err.Description
    GLDayWiseBalance = result


End Function

Public Function BalanceUpdation(BranchCode As String, ApplicationDate As String)
 On Error GoTo myErr
    Dim appDate As String
    Dim BrCode As String
    
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    
''''' Createing Instances of  recordsets
    Set recMstTabs = CreateObject("adodb.recordset")
    Set recAccno = CreateObject("adodb.recordset")


''''''' select all Modules where Master table is not null
    Set recMstTabs = AdoConnObj.Execute("Select Moduleid from GenModuleMst " & _
                                        "where balancetable is not null")
    
    If Not recMstTabs.EOF And Not recMstTabs.BOF Then
    '''''' updation of balances branch wise
        Do While Not recMstTabs.EOF
            
            
            
            '''''''' Updation of all PrevCurBal with  CurBal and PrevClearBal with ClearBal
             result = "Update " & recMstTabs(0) & "Balance " & _
                                "Set PrevCurBal=CurBal, PrevClearBal=clearbal," & _
                                " applicationdate='" & appDate & "' where " & _
                                "BranchCode='" & BrCode & "'"
             
            AdoConnObj.Execute ("Update " & recMstTabs(0) & "Balance " & _
                                "Set PrevCurBal=CurBal, PrevClearBal=clearbal," & _
                                " applicationdate='" & appDate & "' where " & _
                                "BranchCode='" & BrCode & "'")
            
          
            '''''''' Select Amounts from gentranslog for the particular module
                               
              result = "Select nvl(Amount,0),Accno,Batchno,Tranno " & _
                                "from GenTransLog where Moduleid='" & recMstTabs(0) & "'" & _
                                " and branchcode='" & BrCode & "' and accno IS NOT NULL  order by accno,batchno,tranno"
                                
             Set recAccno = AdoConnObj.Execute("Select nvl(Amount,0),Accno,Batchno,Tranno,glcode " & _
                                "from GenTransLog where Moduleid='" & recMstTabs(0) & "'" & _
                                " and branchcode='" & BrCode & "' and accno IS NOT NULL order by accno,batchno,tranno")
            
            
            '''''' Update DayendBalances for that particular module transactions
            '''''' dayendbalance=curbal of balance table + amount from gentranslog for every tranno
            '''''  accno wise
             If Not recAccno.EOF And Not recAccno.BOF Then
                
                recAccno.MoveFirst
                Do While Not recAccno.EOF And Not recAccno.BOF
                   result = "Update GenTransLog  a SET dayendbal=NVL((" & _
                            " Select curbal FROM " & recMstTabs(0) & "Balance  WHERE accno=a.accno and  " & _
                            " glcode=a.glcode AND BranchCode='" & BrCode & "' ),0)+ " & _
                            " NVL((SELECT SUM(NVL(amount,0)) FROM gentranslog " & _
                            " WHERE accno=a.accno ND glcode=a.glcode AND BranchCode='" & BrCode & "' AND  tranno<=" & _
                            recAccno(3) & " A),0)  WHERE tranno='" & recAccno(3) & "' AND batchno='" & recAccno(2) & _
                            "' AND accno='" & recAccno(1) & "' and BranchCode='" & BrCode & "'"
                    
                    
                    AdoConnObj.Execute (result)
                                
                     result = "Update " & recMstTabs(0) & "TranDay  a  SET dayendbal=NVL((" & _
                            " Select curbal FROM " & recMstTabs(0) & "Balance  WHERE accno=a.accno and  glcode=a.glcode " & _
                            " AND BranchCode='" & BrCode & "' ),0)+ " & _
                            " NVL((SELECT SUM(NVL(amount,0)) FROM gentranslog " & _
                            " WHERE accno=a.accno AND glcode=a.glcode AND BranchCode='" & BrCode & "' AND  tranno<=" & _
                            recAccno(3) & " ),0)  WHERE tranno='" & recAccno(3) & "' AND batchno='" & recAccno(2) & _
                            "' AND accno='" & recAccno(1) & "' and BranchCode='" & BrCode & "'"
                     
                    AdoConnObj.Execute (result)
                                             
                    recAccno.MoveNext
            
                Loop
            End If
            
            
            '''''''''' Update curbal of balacne table
            ''''''''' curbal=last transactions amount of that accno
            ''add application date change tranno with mstno kishore
            result = "Update " & recMstTabs(0) & "Balance a" & _
                                " Set CurBal=nvl((select dayendbal from GenTransLog" & _
                                " where tranno=(Select max(Tranno)" & _
                                " from GentransLog where accno=a.accno and glcode=a.glcode and branchcode='" & BrCode & _
                                 "' and moduleid='" & recMstTabs(0) & "') and  glcode=a.glcode and " & _
                                "BranchCode='" & BrCode & "' and moduleid='" & recMstTabs(0) & "' ),Curbal), " & _
                                 " ClearBal=curbal-nvl((select sum(Amount) " & _
                                 " from GenUnClearBalanceDtls where accno=a.accno and glcode=a.glcode and " & _
                                 " BranchCode='" & BrCode & "' and moduleid='" & recMstTabs(0) & "'),0) " & _
                                 "where  branchcode='" & BrCode & "' and " & _
                                 " (GLCODE, ACCNO) in (select distinct GLCODE, ACCNO from GenTransLog where  branchcode='" & BrCode & _
                                 "' and moduleid='" & recMstTabs(0) & "')"
                                             
            AdoConnObj.Execute (result)
            
''            result = "Update " & recMstTabs(0) & "Balance a" & _
''                                " Set CurBal=nvl((select dayendbal from GenTransLog" & _
''                                " where moduleid='" & recMstTabs(0) & "' and  glcode=a.glcode and " & _
''                                "BranchCode='" & BrCode & "' and tranno=(Select max(Tranno)" & _
''                                " from GentransLog where accno=a.accno and moduleid='" & _
''                                 recMstTabs(0) & "' and branchcode='" & BrCode & _
''                                 "' and glcode=a.glcode )),Curbal) where branchcode='" & BrCode & "'"
''
''
''            AdoConnObj.Execute (result)
''
''            '''''''' updation of clearbal of balance table
''            '''''''' clearbal=curbal of balance table - sum of amount of genunclearbalacnedtls
''            ''''''' for that accno
''
''            ''skip this clearing update kishore
''             result = "Update " & recMstTabs(0) & "Balance a" & _
''                                " Set ClearBal=curbal-nvl((select sum(Amount) from GenUnClearBalanceDtls" & _
''                                " where moduleid='" & recMstTabs(0) & "' and  " & _
''                                "BranchCode='" & BrCode & "' and accno=a.accno " & _
''                                " and glcode=a.glcode),0) " & _
''                                "where  branchcode='" & BrCode & "'"
''
''
''            AdoConnObj.Execute (result)
                        
            recMstTabs.MoveNext
        Loop
    End If
    
    '''''' Update CashBalance from CashVaultMSt
            ''check at execution time kishore
            result = "Insert Into cashbalance (BRANCHCODE, CURRENCYCODE," & _
                                "APPLICATIONDATE,  OPENINGBAL,D1, D2, D3, D4, D5, D6," & _
                                " D7, D8, D9, D10, D11, D12, D13, D14, D15, D16, D17, D18," & _
                                " D19, D20, D21, D22, D23, D24, D25, D26, D27, D28, D29," & _
                                " D30, D31, D32, D33, D34, D35, D36, D37, D38, D39, D40, " & _
                                " D41, D42, D43, D44, D45, D46, D47, D48, D49, D50, CLOSINGBAL)" & _
                                " SELECT BRANCHCODE, CURRENCYCODE, '" & appDate & "', " & _
                                "(SELECT CLOSINGBAL FROM cashbalance WHERE " & _
                                " BRANCHCODE=a.BRANCHCODE AND CURRENCYCODE=a.CURRENCYCODE " & _
                                " And applicationdate=( SELECT MAX(applicationdate) FROM cashbalance))," & _
                                " D1, D2, D3, D4, D5, D6, D7, D8, D9,D10, D11, D12, " & _
                                "D13, D14, D15, D16, D17, D18, D19, D20, D21, D22, D23, " & _
                                "D24, D25, D26,D27, D28, D29, D30, D31, D32, D33, D34, " & _
                                " D35, D36, D37, D38, D39, D40, D41, D42, D43," & _
                                "D44, D45, D46, D47, D48, D49, D50, TOTAMOUNT FROM " & _
                                " cashvaultmst a WHERE branchcode='" & BrCode & "'"
            
            AdoConnObj.Execute ("Insert Into cashbalance (BRANCHCODE, CURRENCYCODE," & _
                                "APPLICATIONDATE,  OPENINGBAL,D1, D2, D3, D4, D5, D6," & _
                                " D7, D8, D9, D10, D11, D12, D13, D14, D15, D16, D17, D18," & _
                                " D19, D20, D21, D22, D23, D24, D25, D26, D27, D28, D29," & _
                                " D30, D31, D32, D33, D34, D35, D36, D37, D38, D39, D40, " & _
                                " D41, D42, D43, D44, D45, D46, D47, D48, D49, D50, CLOSINGBAL)" & _
                                " SELECT BRANCHCODE, CURRENCYCODE, '" & appDate & "', " & _
                                "(SELECT CLOSINGBAL FROM cashbalance WHERE " & _
                                " BRANCHCODE=a.BRANCHCODE AND CURRENCYCODE=a.CURRENCYCODE " & _
                                " And applicationdate=( SELECT MAX(applicationdate) FROM cashbalance))," & _
                                " D1, D2, D3, D4, D5, D6, D7, D8, D9,D10, D11, D12, " & _
                                "D13, D14, D15, D16, D17, D18, D19, D20, D21, D22, D23, " & _
                                "D24, D25, D26,D27, D28, D29, D30, D31, D32, D33, D34, " & _
                                " D35, D36, D37, D38, D39, D40, D41, D42, D43," & _
                                "D44, D45, D46, D47, D48, D49, D50, TOTAMOUNT FROM " & _
                                " cashvaultmst a WHERE branchcode='" & BrCode & "'")
           
            
    
    ''''''''' Update loanmst opbal column with the first transaction of that accno
    '''''''' where opbal is null
    ''skip loans kishore
    result = "Select a.accno,a.amount,a.glcode, a.branchcode from  loantranday a, loanmst b" & _
                                    " Where b.accno = a.accno And b.opbal Is Null " & _
                                    " and a.modeoftran=3 and a.glcode=b.glcode " & _
                                    " and a.branchcode=b.branchcode and a.branchcode='" & BranchCode & "'  order by a.systemdate"
    
    Set recAccno = AdoConnObj.Execute("Select a.accno,a.amount,a.glcode, a.branchcode from  loantranday a, loanmst b" & _
                                    " Where b.accno = a.accno And b.opbal Is Null " & _
                                    " and a.modeoftran=3 and a.glcode=b.glcode and a.branchcode=b.branchcode" & _
                                    " and a.branchcode='" & BranchCode & "' order by a.systemdate")
    
    If Not recAccno.EOF And Not recAccno.BOF Then
        Do While Not recAccno.EOF
                result = "Update Loanmst set opbal=" & recAccno(1) & _
                                    " Where accno='" & recAccno(0) & _
                                    "' and glcode='" & recAccno(2) & _
                                    "' and branchcode='" & recAccno(3) & "'"
                
                AdoConnObj.Execute ("Update Loanmst set opbal=" & recAccno(1) & _
                                    " Where accno='" & recAccno(0) & _
                                    "' and glcode='" & recAccno(2) & _
                                    "' and branchcode='" & recAccno(3) & "'")
                                    
                recAccno.MoveNext
        Loop
    End If
    '''''''''''''''''' Select Modules and Balance Tables which are implemented
    '''''''''''''''''' for the selected Branch code
    ''skip FX kishore
    result = "Select moduleid,(select balancetable FROM GenModuleMst " & _
                " where moduleid=a.moduleid and balancetable is not null)" & _
                " from Genmoduletypesmst  a where " & _
                " substr(moduleid,1,2)='FX' AND branchcode='" & BrCode & "' " & _
                " and moduleid<>'FX' AND implementedyn='Y' "
    
    Set recAccno = AdoConnObj.Execute(result)
                                        
    If Not recAccno.EOF And Not recAccno.BOF Then
    
    ''''''''''''''''' To Update FCurBal of Forex Balance tables
        Do While Not recAccno.EOF
            result = "Update " & recAccno(1) & " a Set fcurbal=NVL(fcurbal,0)+ " & _
                    "NVL((Select Sum(famount) FROM GENTRANSLOG Where moduleid='" & _
                    recAccno(0) & "' And  glcode=a.glcode And  branchcode='" & BrCode & "' " & _
                    "And tranno=(select MAX(tranno) FROM GENTRANSLOG Where " & _
                    "accno=a.accno And moduleid='" & recAccno(0) & "' " & _
                    "And branchcode='" & BrCode & "' And glcode=a.glcode )),0)" & _
                    " where branchcode='" & BrCode & "'"
                    
            AdoConnObj.Execute (result)
            recAccno.MoveNext
        Loop
    
    End If
    
    '''''''''''' Put a record in GenCustAccountsLnk table where a new account is opened
    '''''''''''' or any account is closed
    ''skip this account link kishore
    '''''''''''' query Master tables and relative modules
    result = " Select moduleid,mastertable from GenModuleMst  Where " & _
             " moduleid in(Select moduleid From GenModuleTypesmst Where " & _
            " branchcode='" & BrCode & "' and implementedyn='Y' ) " & _
            " and mastertable is not null and dummymasteryn='N'"
    
    Set recAccno = AdoConnObj.Execute(result)
    
    
    If Not recAccno.EOF And Not recAccno.BOF Then
    
       Do While Not recAccno.EOF
                 
            '''''''''''''''' If Opdate is not updated, update with applicationdate
            
            result = "Update " & recAccno(1) & " set opdate=applicationdate where opdate is null"
            
            AdoConnObj.Execute (result)
            
            ''''''''''''''''''' Insert records , newly opened
            result = " Insert into GenCustAccountsLnk (branchcode,currencycode,moduleid," & _
                " glcode,accno,customerid,name,opdate,applicationdate,userid,machineid,status)" & _
                " Select branchcode,currencycode,'" & recAccno(0) & "',glcode,accno," & _
                " customerid,name,opdate,applicationdate,userid,machineid,status " & _
                " from " & recAccno(1) & " a  where  status='R' " & _
                " and accno not in(Select accno From GenCustAccountsLnk  " & _
                " where glcode=a.glcode and branchcode=a.branchcode and " & _
                " currencycode=a.currencycode and moduleid='" & recAccno(0) & "') " & _
                " and status='R' and opdate='" & appDate & "'"
            
            AdoConnObj.Execute (result)
            
            If Left(recAccno(0), 2) = "FX" Then
                cldate = "Closeddate"
            Else
                cldate = "Closedate"
            End If
            
            '''''''''''''''' Update records, set status to 'C', which are closed
            result = "Update GenCustAccountsLnk a set status='C', applicationdate='" & appDate & _
                    "' where accno in(Select to_char(accno) From " & recAccno(1) & " where " & _
                    " glcode=a.glcode and branchcode=a.branchcode and " & _
                    " currencycode=a.currencycode and status='C' and " & _
                     cldate & "='" & appDate & "') and status='R' and branchcode='" & BrCode & "'"
            
            AdoConnObj.Execute (result)
            
            '''''''''''''''''' Push closed records to History table
            result = "Insert Into GenCustAccountsLnkHist select * from GenCustAccountsLnk a" & _
                    " where branchcode='" & BrCode & "' and moduleid='" & recAccno(0) & "' " & _
                    " and status='C' and applicationdate='" & appDate & "'"

            AdoConnObj.Execute (result)

            '''''''''''''''''  Delete cosed records from link table
            result = "Delete from GenCustAccountsLnk " & _
                    " where branchcode='" & BrCode & "' and moduleid='" & recAccno(0) & "' " & _
                    " and status='C' and applicationdate='" & appDate & "'"

            AdoConnObj.Execute (result)
            recAccno.MoveNext
        Loop
    End If
    
    result = "Proceed"
    BalanceUpdation = "Proceed"
    Exit Function
                      
myErr:
    result = result & " " & Err.Description
    BalanceUpdation = result


End Function

Public Function ALMProcedures(BranchCode As String, ApplicationDate As String)
On Error GoTo myErr
    Dim appDate As String
    Dim BrCode As String
    
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    
''''' Createing Instances of  recordsets
    Set recMstTabs = CreateObject("adodb.recordset")
    Set recAccno = CreateObject("adodb.recordset")
    
    result = "SELECT nvl(IMPLEMENTEDYN,'N')  IMPLEMENTEDYN FROM GENMODULETYPESMST WHERE moduleid='ALM' " & _
    " and branchcode='" & BranchCode & "'"
    Set recMod = AdoConnObj.Execute(result)
    
    If Not recMod.EOF Or Not recMod.BOF Then
        If recMod(0) = "N" Then
            ALMProcedures = "Proceed"
            Exit Function
        End If
    Else
            ALMProcedures = "Proceed"
            Exit Function
    End If

''''''' Delete from AlmDepositDtls and ALmDepositMstTemp for that branch code
    result = "Delete from AlmDepositDtls  where branchcode='" & BrCode & "'"
    AdoConnObj.Execute ("Delete from AlmDepositDtls  where branchcode='" & BrCode & "'")
    
    result = "Delete from AlmDepositMstTemp  where branchcode='" & BrCode & "'"
    AdoConnObj.Execute ("Delete from AlmDepositMstTemp  where branchcode='" & BrCode & "'")
    
''''' Insert records into AlmDepositMstTemp table for furthur insertions into dtls table
'''' Insert null values for resiudalbucketcode and originalbucketcode for later updations
    
    result = " Insert into AlmDepositMstTemp " & _
                        " Select a.branchcode,a.currencycode,a.glcode,a.accno," & _
                        " a.maturitydate-a.opdate,a.maturitydate-to_date('" & appDate & "')," & _
                        " a.opbal,b.curbal,a.maturityvalue,'','',a.applicationdate,sysdate" & _
                        " from depmst a, depbalance b" & _
                        " where a.status='R' and a.glcode=b.glcode and a.accno=b.accno" & _
                        " and a.branchcode='" & BrCode & "' " & _
                        " order by branchcode,currencycode,glcode,accno"
    AdoConnObj.Execute (result)
                        
 ''''''' Update residual and original periods to 1 where they are less than 1
    result = "Update almdepositmsttemp a set residualperiod=1 where " & _
                        " residualperiod<1"
    AdoConnObj.Execute (result)
    
    result = "Update almdepositmsttemp a set originalperiod=1 where " & _
                        " originalperiod<1"
    AdoConnObj.Execute (result)
                        
'''''' Update original bucketcode and residual bucket codes of AlmDepositMstTemp

    result = "Update almdepositmsttemp a set originalbucketcode=" & _
                        " (select bucketcode from almtimebucketsmst  where " & _
                        " a.originalperiod <= decode(totimeperiodtype,'M',totimeperiod * 30 ," & _
                        " 'Y',totimeperiod*365,totimeperiod)  and " & _
                        " a.originalperiod >= decode(fromtimeperiodtype,'M',fromtimeperiod * 30 , " & _
                        " 'Y',fromtimeperiod*365,fromtimeperiod) and " & _
                        " currencycode=a.currencycode and rownum<2  )," & _
                        " residualbucketcode=" & _
                        " (select bucketcode from almtimebucketsmst  where " & _
                        " a.residualperiod <= decode(totimeperiodtype,'M',totimeperiod * 30 ," & _
                        " 'Y',totimeperiod*365,totimeperiod)  and " & _
                        " a.residualperiod >= decode(fromtimeperiodtype,'M',fromtimeperiod * 30 , " & _
                        " 'Y',fromtimeperiod*365,fromtimeperiod) and " & _
                        " currencycode=a.currencycode and rownum<2  )"
    AdoConnObj.Execute (result)
                        
'''''' Insert into AlmDepositDtls for Analysistype residual

    result = "Insert into almdepositdtls (BRANCHCODE,CURRENCYCODE,GLCODE," & _
                        " NOOFACCOUNTS,ANALYSISTYPE,OPBAL,CURBAL,MATURITYVALUE," & _
                        " Bucketcode,applicationdate,systemdate) " & _
                        " Select branchcode,currencycode,glcode,count(accno),'R'," & _
                        " Sum(opbal),sum(curbal),sum(maturityval),residualbucketcode," & _
                        "'" & appDate & "',sysdate From almdepositmsttemp " & _
                        " group by branchcode,currencycode,glcode,residualbucketcode "
    AdoConnObj.Execute (result)

'''''' Insert into AlmDepositDtls for Analysistype Original
    result = "Insert into almdepositdtls (BRANCHCODE,CURRENCYCODE,GLCODE," & _
                        " NOOFACCOUNTS,ANALYSISTYPE,OPBAL,CURBAL,MATURITYVALUE," & _
                        " Bucketcode,applicationdate,systemdate) " & _
                        " Select branchcode,currencycode,glcode,count(accno),'O'," & _
                        " Sum(opbal),sum(curbal),sum(maturityval),originalbucketcode," & _
                        "'" & appDate & "',sysdate From almdepositmsttemp " & _
                        " group by branchcode,currencycode,glcode,originalbucketcode "
    AdoConnObj.Execute (result)

    
    ''''''' Delete from AlmDepositDtls and ALmDepositMstTemp for that branch code
    result = "Delete from AlmLoanDtls  where branchcode='" & BrCode & "'"
    AdoConnObj.Execute (result)
    
    result = "Delete from AlmLoansMstTemp  where branchcode='" & BrCode & "'"
    AdoConnObj.Execute (result)
    
    result = "Delete from AlmLoanRecoveryTemp  where branchcode='" & BrCode & "'"
    AdoConnObj.Execute (result)
    
''''' Insert records into AlmDepositMstTemp table for furthur insertions into dtls table
'''' Insert null values for resiudalbucketcode and originalbucketcode for later updations
    
    result = "Insert into AlmLoansMstTemp Select a.branchcode," & _
                        " a.currencycode,a.glcode,a.accno,a.duedate-a.opdate," & _
                        " a.duedate-to_date('" & appDate & "'), a.opbal,b.curbal," & _
                        "'','','',a.applicationdate,sysdate from Loanmst a, Loanbalance b" & _
                        " where a.status='R' and a.glcode=b.glcode and a.accno=b.accno " & _
                        " and a.branchcode='" & BrCode & "' and a.branchcode=b.branchcode  order by branchcode,currencycode," & _
                        " glcode,accno "
    AdoConnObj.Execute (result)
                                
 ''''''' Update residual and original periods to 1 where they are less than 1
    result = "Update almloansmsttemp a set residualperiod=1 where " & _
                        " residualperiod<1"
    AdoConnObj.Execute (result)
    
    result = "Update almloansmsttemp a set originalperiod=1 where " & _
                        " originalperiod<1"
    AdoConnObj.Execute (result)
                        
                        
'''''' Update original bucketcode and residual bucket codes of AlmDepositMstTemp
    result = "Update almloansmsttemp a set originalbucketcode=" & _
                        "(select bucketcode from almtimebucketsmst  where " & _
                        " a.originalperiod <= decode(totimeperiodtype,'M',totimeperiod * 30 ," & _
                        " 'Y',totimeperiod*365,totimeperiod)  and " & _
                        " a.originalperiod >= decode(fromtimeperiodtype,'M',fromtimeperiod * 30 , " & _
                        " 'Y',fromtimeperiod*365,fromtimeperiod) and " & _
                        " currencycode=a.currencycode and rownum<2  )," & _
                        " residualbucketcode=" & _
                        "(select bucketcode from almtimebucketsmst  where " & _
                        " a.residualperiod <= decode(totimeperiodtype,'M',totimeperiod * 30 ," & _
                        " 'Y',totimeperiod*365,totimeperiod)  and " & _
                        " a.residualperiod >= decode(fromtimeperiodtype,'M',fromtimeperiod * 30 , " & _
                        " 'Y',fromtimeperiod*365,fromtimeperiod) and " & _
                        " currencycode=a.currencycode and rownum<2  )"
    AdoConnObj.Execute (result)
                        
'''''' Insert into AlmLoanDtls for Analysistype residual
    result = "Insert into almloandtls (BRANCHCODE,CURRENCYCODE,GLCODE," & _
                        " NOOFACCOUNTS,ANALYSISTYPE,OPBAL,CURBAL," & _
                        " Bucketcode,applicationdate,systemdate) " & _
                        " Select branchcode,currencycode,glcode,count(accno),'R'," & _
                        " Sum(opbal),sum(curbal),residualbucketcode," & _
                        "'" & appDate & "',sysdate From almloansmsttemp " & _
                        " group by branchcode,currencycode,glcode,residualbucketcode "
    AdoConnObj.Execute (result)

'''''' Insert into AlmLoanDtls for Analysistype Original
    result = "Insert into almloandtls (BRANCHCODE,CURRENCYCODE,GLCODE," & _
                        " NOOFACCOUNTS,ANALYSISTYPE,OPBAL,CURBAL," & _
                        " Bucketcode,applicationdate,systemdate) " & _
                        " Select branchcode,currencycode,glcode,count(accno),'O'," & _
                        " Sum(opbal),sum(curbal),originalbucketcode," & _
                        "'" & appDate & "',sysdate From almloansmsttemp " & _
                        " group by branchcode,currencycode,glcode,originalbucketcode "
    AdoConnObj.Execute (result)
    
    
    ''''''' Insert values into Loanrecovertemp
    result = "Insert into almloanrecoverytemp " & _
                        " Select branchcode,currencycode,glcode,accno, " & _
                        " INSTALMENTAMT*(select count(*) from loanscheduledtls " & _
                        " where accno=a.accno and glcode=a.glcode  and repayduedate>= " & _
                        " to_date('" & appDate & "') and branchcode=a.branchcode)," & _
                        " duedate-to_date('" & appDate & "') ," & _
                        "'','" & appDate & "',sysdate from loanmst a where a.branchcode='" & _
                        BrCode & "'"
    AdoConnObj.Execute (result)
    
    
    result = "Update almloanrecoverytemp a set RESIDUALBUCKETCODE =" & _
                        " (select bucketcode from almtimebucketsmst  where " & _
                        " a.residualperiod <= decode(totimeperiodtype,'M',totimeperiod * 30 ," & _
                        " 'Y',totimeperiod*365,totimeperiod)  and" & _
                        " a.residualperiod >= decode(fromtimeperiodtype,'M',fromtimeperiod * 30 ," & _
                        " 'Y',fromtimeperiod*365,fromtimeperiod) and" & _
                        " currencycode=a.currencycode and rownum<2  )"
    AdoConnObj.Execute (result)

  
  ''''''' Update residual and original periods to 1 where they are less than 1
    result = "Update almloanrecoverytemp a set residualperiod=1 where " & _
                        " residualperiod<1"
    AdoConnObj.Execute (result)


    '''''' Insert into AlmLoanDtls for Analysistype Original
    result = "Insert into almloanrecoverydtls (BRANCHCODE,CURRENCYCODE,GLCODE," & _
                        " NOOFACCOUNTS,bucketcode,recoverybal,applicationdate,systemdate) " & _
                        " Select branchcode,currencycode,glcode,count(accno), " & _
                        " residualbucketcode,sum(recoverybal),'" & appDate & "'," & _
                        " sysdate From almloanrecoverytemp group by branchcode," & _
                        " currencycode,glcode,RESIDUALBUCKETCODE"
    AdoConnObj.Execute (result)

    ALMProcedures = "Proceed"
    Exit Function
myErr:
ALMProcedures = result & "  " & Err.Description

End Function

Public Function ProductUpdation(BranchCode As String, ApplicationDate As String)
On Error GoTo myErr
    Dim appDate As String
    Dim BrCode As String
    
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    
    Set recGL = CreateObject("adodb.recordset")
    Set recAccno = CreateObject("adodb.recordset")
   
   result = "Insert into loanproductsdtls (branchcode,currencycode," & _
                        "moduleid,glcode,accno,productdate,applicationdate,systemdate) " & _
                        " select branchcode,currencycode,'LOAN',glcode,accno," & _
                        "'" & appDate & "','" & appDate & "',sysdate from loanmst " & _
                        " where status='R' and branchcode='" & BrCode & "'"
   
    '''''''' Insert records into loanproductdtls for dayend date
    AdoConnObj.Execute ("Insert into loanproductsdtls (branchcode,currencycode," & _
                        "moduleid,glcode,accno,productdate,applicationdate,systemdate) " & _
                        " select branchcode,currencycode,'LOAN',glcode,accno," & _
                        "'" & appDate & "','" & appDate & "',sysdate from loanmst " & _
                        " where status='R' and branchcode='" & BrCode & "'")
    
    
    ''''''''' updating dayend balance, dayendbalance below limit, dayendbalance above limit
    '''''''''' where dayend balance is >=0, set abovelimit and belowlomit to 0
    
    result = "Update LoanProductsDtls b set dayendbal=" & _
        " (select dayendbal from loantranday a where accno=b.accno" & _
        " and branchcode=b.branchcode and glcode=b.glcode and tranno=(" & _
        " select max(tranno) from loantranday where" & _
        " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)) ," & _
        " DAYENDBALBELOWLIMIT =0, DAYENDBALaboveLIMIT = 0 " & _
        " where branchcode='" & BrCode & "' and " & _
        " (select dayendbal from loantranday a where accno=b.accno " & _
        " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
        " select max(tranno) from loantranday where " & _
        " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode))>=0" & _
        " and applicationdate='" & appDate & "'"
    
    AdoConnObj.Execute ("Update LoanProductsDtls b set dayendbal=" & _
        " (select dayendbal from loantranday a where accno=b.accno" & _
        " and branchcode=b.branchcode and glcode=b.glcode and tranno=(" & _
        " select max(tranno) from loantranday where" & _
        " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)) ," & _
        " DAYENDBALBELOWLIMIT =0, DAYENDBALaboveLIMIT = 0 " & _
        " where branchcode='" & BrCode & "' and " & _
        " (select dayendbal from loantranday a where accno=b.accno " & _
        " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
        " select max(tranno) from loantranday where " & _
        " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode))>=0" & _
        " and applicationdate='" & appDate & "'")
                        
    ''''''''' updating dayend balance, dayendbalance below limit, dayendbalance above limit
    '''''''''' where dayend balance is <0 and sanction amount >= dayend balance
    '''''''''' set abovelimit to 0 and belowlimit to dayend balance
    
    result = "Update LoanProductsDtls b set dayendbal= " & _
            " (select dayendbal from loantranday a where accno=b.accno " & _
            " and branchcode=b.branchcode and glcode=b.glcode and tranno=(" & _
            " select max(tranno) from loantranday where" & _
            " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)) ," & _
            " DAYENDBALBELOWLIMIT =  (select dayendbal from loantranday a " & _
            " where accno=b.accno and branchcode=b.branchcode " & _
            " and glcode=b.glcode and tranno=(" & _
            " select max(tranno) from loantranday where" & _
            " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)) ," & _
            " DAYENDBALaboveLIMIT = 0" & _
            " where branchcode='" & BrCode & "' and (select dayendbal from " & _
            " loantranday a where accno=b.accno " & _
            " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
            " select max(tranno) from loantranday where " & _
            " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode))<0 " & _
            " and abs((select SANCTIONEDAMT from loanmst " & _
            " where glcode=b.glcode and accno=b.accno and branchcode=b.branchcode ))" & _
            " >=abs((select dayendbal from loantranday a where accno=b.accno" & _
            " and branchcode=b.branchcode and glcode=b.glcode and tranno=(" & _
            " select max(tranno) from loantranday where " & _
            " accno=a.accno and branchcode=a.branchcode " & _
            " and glcode=a.glcode))) and applicationdate='" & appDate & "'"
            
    
    AdoConnObj.Execute (result)

    ''''''''' updating dayend balance, dayendbalance below limit, dayendbalance above limit
    '''''''''' where dayend balance is <0 and sanction amount < dayend balance
    '''''''''' set abovelimit to sanction amount - dayend balance
    '''''''''' and belowlimit to -1 * sanction amount

    result = "Update LoanProductsDtls b set dayendbal= " & _
            " (select dayendbal from loantranday a where accno=b.accno " & _
            " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
            " select max(tranno) from loantranday where " & _
            " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)) ," & _
            " DAYENDBALBELOWLIMIT = -1* (select SANCTIONEDAMT from loanmst " & _
            " where glcode=b.glcode and accno=b.accno and branchcode=b.branchcode )," & _
            " DAYENDBALaboveLIMIT = abs((select SANCTIONEDAMT from loanmst " & _
            " where glcode=b.glcode and accno=b.accno and branchcode=b.branchcode ))-" & _
            " abs( (select dayendbal from loantranday a where accno=b.accno" & _
            " and branchcode=b.branchcode and glcode=b.glcode and tranno=(" & _
            " select max(tranno) from loantranday where " & _
            " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode)))" & _
            " where branchcode='" & BrCode & "' and " & _
                " (select dayendbal from loantranday a where accno=b.accno " & _
                " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
                " select max(tranno) from loantranday where " & _
                " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode))<0 " & _
            " and abs((select SANCTIONEDAMT from loanmst where glcode=b.glcode " & _
                "and accno=b.accno and branchcode=b.branchcode ))< " & _
            "abs((select dayendbal from loantranday a where accno=b.accno " & _
                " and branchcode=b.branchcode and glcode=b.glcode and tranno=( " & _
                "select max(tranno) from loantranday where " & _
                " accno=a.accno and branchcode=a.branchcode and glcode=a.glcode))) " & _
                " and applicationdate='" & appDate & "'"
    
                        
    AdoConnObj.Execute (result)
                        
    ''''''''' updating dayend clear balance, dayend clear balance below limit,
    ''''''''' dayend clear balance above limit
    '''''''''' where dayend clear balance is >=0, set clear abovelimit and clear belowlomit to 0
                   
    result = "Update LoanProductsDtls b set " & _
            " dayendclearbal= b.dayendbal-(select amount from " & _
            " genunclearbalancedtls where applicationdate='" & appDate & "' " & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno), " & _
            " dayendclearbalbelowlimit=0, " & _
            " dayendclearbalabovelimit =0 where branchcode='" & BrCode & "' " & _
            " and  (b.dayendbal-(select amount from " & _
            " genunclearbalancedtls where applicationdate='" & appDate & "' " & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno))>=0 " & _
            " and applicationdate='" & appDate & "' and branchcode='" & BrCode & "'"
                   
                   
      AdoConnObj.Execute (result)
                   
    ''''''''' updating dayend clear balance, dayend clear balance below limit,
    ''''''''' dayend clear balance above limit
    '''''''''' where dayend clear balance is <0 and sanction amount >= dayend clear balance
    '''''''''' set clear abovelimit to 0 and clear belowlimit to dayend clear balance
                   
    result = "Update LoanProductsDtls b set dayendclearbal= b.dayendbal-" & _
            " (select amount from GenUnClearBalanceDtls where " & _
            " applicationdate='" & appDate & "' and branchcode=b.branchcode " & _
            " and glcode=b.glcode and moduleid=b.moduleid and accno=b.accno)," & _
            " dayendclearbalbelowlimit=b.dayendbal-(select amount from " & _
            " GenUnClearBalanceDtls where applicationdate='" & appDate & "'" & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno), dayendclearbalabovelimit = 0" & _
            " where branchcode='" & BrCode & "' and (b.dayendbal-(select amount from " & _
            " GenUnClearBalanceDtls where applicationdate='" & appDate & "' " & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno))<0 " & _
            " and abs((select SANCTIONEDAMT from loanmst where glcode=b.glcode " & _
            " and accno=b.accno and branchcode=b.branchcode ))>=abs((b.dayendbal-(select amount from " & _
            " GenUnClearBalanceDtls where applicationdate='" & appDate & "'" & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno))) and applicationdate='" & appDate & "'"
                   
    AdoConnObj.Execute (result)
               
               
     ''''''''' updating dayend clear balance, dayend clear balance below limit,
     ''''''''' dayend clear balance above limit
    '''''''''' where dayend clear balance is <0 and sanction amount < dayend clear balance
    '''''''''' set clear above limit to sanction amount - dayend clear balance
    '''''''''' and clear below limit to -1 * sanction amount
               
    result = "Update LoanProductsDtls b set dayendclearbal= b.dayendbal-" & _
            " (select amount from genunclearbalancedtls where " & _
            " applicationdate='" & appDate & "' and branchcode=b.branchcode " & _
            " and glcode=b.glcode and moduleid=b.moduleid and accno=b.accno), " & _
            " dayendclearbalbelowlimit=-1* (select SANCTIONEDAMT from loanmst " & _
            " where glcode=b.glcode and accno=b.accno and branchcode=b.branchcode ),dayendclearbalabovelimit=" & _
            " abs((select SANCTIONEDAMT from loanmst where glcode=b.glcode " & _
            " and accno=b.accno and branchcode=b.branchcode ))-abs((b.dayendbal-(select amount from " & _
            " genunclearbalancedtls where applicationdate='" & appDate & "' " & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno)))" & _
            " where branchcode='" & BrCode & "' and (b.dayendbal-(select amount from " & _
            " genunclearbalancedtls where applicationdate='" & appDate & "' " & _
            " and branchcode=b.branchcode and glcode=b.glcode and " & _
            " moduleid=b.moduleid and accno=b.accno))<0 and abs((select SANCTIONEDAMT " & _
            " from loanmst where glcode=b.glcode and accno=b.accno and branchcode=b.branchcode )) " & _
            " <abs((b.dayendbal-(select amount from  genunclearbalancedtls " & _
            " where applicationdate='" & appDate & "' and branchcode=b.branchcode " & _
            " and glcode=b.glcode and moduleid=b.moduleid and accno=b.accno)))" & _
            "and applicationdate='" & appDate & "' "
 

    AdoConnObj.Execute (result)
               
               
               
    ''''''' update dayend balance where dayend balance is null for day end date
   
   result = "Update LoanProductsDtls a set dayendbal=(select dayendbal from " & _
            " loanproductsdtls where applicationdate=(select max(applicationdate)" & _
            " from loanproductsdtls where applicationdate<'" & appDate & "') and " & _
            " branchcode='" & BrCode & "' and a.glcode=glcode and a.accno=accno)," & _
            " DAYENDBALABOVELIMIT=(select DAYENDBALABOVELIMIT from loanproductsdtls " & _
            " where applicationdate=(select max(applicationdate) from loanproductsdtls " & _
            " where applicationdate<'" & appDate & "') and branchcode='" & BrCode & "'" & _
            " and a.glcode=glcode and a.accno=accno),DAYENDBALBELOWLIMIT=(select " & _
            " DAYENDBALBELOWLIMIT from loanproductsdtls where applicationdate=(select " & _
            " max(applicationdate) from loanproductsdtls where applicationdate<'" & appDate & _
            "') and branchcode='" & BrCode & "' and a.glcode=glcode and a.accno=accno)," & _
            " DAYENDCLEARBAL=(select DAYENDCLEARBAL from loanproductsdtls where " & _
            " applicationdate=(select max(applicationdate) from loanproductsdtls where " & _
            " applicationdate<'" & appDate & "') and branchcode='" & BrCode & "' and a.glcode=" & _
            " glcode and a.accno=accno),DAYENDCLEARBALABOVELIMIT=(select DAYENDCLEARBALABOVELIMIT from " & _
            " loanproductsdtls where applicationdate=(select max(applicationdate) from " & _
            " loanproductsdtls where applicationdate<'" & appDate & "') and branchcode='" & BrCode & "' " & _
            " and a.glcode=glcode and a.accno=accno), DAYENDCLEARBALBELOWLIMIT=(select " & _
            " DAYENDCLEARBALBELOWLIMIT from loanproductsdtls where applicationdate=" & _
            " (select max(applicationdate) from loanproductsdtls where applicationdate<'" & _
            appDate & "') and branchcode='" & BrCode & "' and a.glcode=glcode and " & _
            " a.accno=accno) where branchcode='" & BrCode & "' and dayendbal is null"
   
   AdoConnObj.Execute (result)


    '''''''''''''''''''''''''''''SB min Balance ''''''''''''''''''''''''''''''''
    
    ''''''' Check for Minimum balance cutoff day glwise
    
    result = "Select  Glcode,Monthlyminbalday," & _
                        " to_char(to_date('" & appDate & "'),'MON') from sbtypemst " & _
                        " where to_number(to_char(to_date('" & appDate & "'),'DD'))>=" & _
                        " monthlyminbalday "
                        
    Set recGL = AdoConnObj.Execute("Select  Glcode,Monthlyminbalday," & _
                        " to_char(to_date('" & appDate & "'),'MON') from sbtypemst " & _
                        " where to_number(to_char(to_date('" & appDate & "'),'DD'))>=" & _
                        " monthlyminbalday ")
    
    ''''' if cutoff day on that month
   If Not recGL.EOF And Not recGL.BOF Then
     ''''''' get the month as column name to update in SBminBalProductMst table
     ColName = recGL(2)
     ''''''' each gl wise
     Do While Not recGL.EOF
        '''''' Check any new account is opened for particular GL
        result = "Select accno from sbbalance where accno not in( " & _
                        " Select accno from sbmonminbalproductmst where glcode='" & recGL(0) & _
                        "' and branchcode='" & BrCode & "') and glcode='" & recGL(0) & _
                        "' and branchcode='" & BrCode & "'"
                        
        Set recAccno = AdoConnObj.Execute("Select accno from sbbalance where accno not in( " & _
                        " Select accno from sbmonminbalproductmst where glcode='" & recGL(0) & _
                        "' and branchcode='" & BrCode & "') and glcode='" & recGL(0) & _
                        "' and branchcode='" & BrCode & "'")
            ''''''' If new accounts found insert a row into SbminBalProductMSt table
            If Not recAccno.EOF And Not recAccno.BOF Then
            
                result = " Insert into SBMonMinBalProductMst(" & _
                                " Branchcode,Currencycode,Glcode,Accno,Year,Applicationdate)" & _
                                " select branchcode,currencycode,glcode,accno," & _
                                " to_char(applicationdate,'YYYY'),applicationdate from" & _
                                " sbbalance where accno not in(select accno from " & _
                                " SbMonMinBalProductMst where glcode='" & recGL(0) & "'" & _
                                " and branchcode='" & BrCode & "')" & _
                                " and applicationdate='" & appDate & "' and glcode='" & _
                                recGL(0) & "' and branchcode='" & BrCode & "'"
                                
                AdoConnObj.Execute ("Insert into SBMonMinBalProductMst(" & _
                                " Branchcode,Currencycode,Glcode,Accno,Year,Applicationdate)" & _
                                " select branchcode,currencycode,glcode,accno," & _
                                " to_char(applicationdate,'YYYY'),applicationdate from" & _
                                " sbbalance where accno not in(select accno from " & _
                                " SbMonMinBalProductMst where glcode='" & recGL(0) & "'" & _
                                " and branchcode='" & BrCode & "')" & _
                                " and applicationdate='" & appDate & "' and glcode='" & _
                                recGL(0) & "' and branchcode='" & BrCode & "'")
            End If
           
           ''''''''''' Update minimum balance for all account numbers for particular GL
           
           result = " Update sbmonminbalproductmst a set " & ColName & "=" & _
                                " nvl((select min(clearbal) from sbbalance where " & _
                                " applicationdate='" & appDate & "' and a.branchcode=" & _
                                " branchcode and glcode=a.glcode and currencycode=" & _
                                " a.currencycode and accno=a.accno),0), applicationdate='" & _
                                appDate & "' where glcode='" & recGL(0) & "' and branchcode='" & _
                                BrCode & "'"
                                
           AdoConnObj.Execute (" Update sbmonminbalproductmst a set " & ColName & "=" & _
                                " nvl((select min(clearbal) from sbbalance where " & _
                                " applicationdate='" & appDate & "' and a.branchcode=" & _
                                " branchcode and glcode=a.glcode and currencycode=" & _
                                " a.currencycode and accno=a.accno),0), applicationdate='" & _
                                appDate & "' where glcode='" & recGL(0) & "' and branchcode='" & _
                                BrCode & "'")
            
            
            recGL.MoveNext
     Loop

   End If

    result = "Proceed"
    ProductUpdation = result
    Exit Function

myErr:
    result = result & " " & Err.Description
    ProductUpdation = result

End Function
Public Function Initialization(BranchCode As String)
On Error GoTo myErr
  Dim BrCode As String
    
    '''''' Reading parameters
    BrCode = BranchCode
 
 ''''''''''''''' Delete rows from GenautoMax table where initilization is at Day level
 Condition = " MAXAUTOTABLENAME=(SELECT MAXAUTOTABLENAME FROM GENAUTONUMBERPMT" & _
            " WHERE MAXAUTOTABLENAME=a.MAXAUTOTABLENAME AND " & _
            " MAXAUTOFIELDNAME =a.MAXAUTOFIELDNAME  AND " & _
            " INITIALISEPERIODYHQMD='D')" & _
            " AND MAXAUTOFIELDNAME=(SELECT  MAXAUTOFIELDNAME  FROM GENAUTONUMBERPMT " & _
            " WHERE MAXAUTOFIELDNAME =a.MAXAUTOFIELDNAME  AND " & _
            " MAXAUTOTABLENAME=a.MAXAUTOTABLENAME AND " & _
            " INITIALISEPERIODYHQMD='D') and branchcode='" & BrCode & "'"

            StrDelete = "Delete from GenAutonumMax  a where " & Condition
            
            result = StrDelete
            
            AdoConnObj.Execute StrDelete
            
            result = "Proceed"
            
            Initialization = result
            Exit Function
            

myErr:
    Initialization = result & "  " & Err.Description

End Function

Public Function AbnormalBalanceUpdation(BranchCode As String, ApplicationDate As String)
On Error GoTo myErr
    Dim appDate As String
    Dim BrCode As String
    Dim Condition As String
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    
''''' Createing Instances of  recordsets
    Set recMstTabs = CreateObject("adodb.recordset")
    Set recAccno = CreateObject("adodb.recordset")

''''''' select all Modules where Master table is not null
    Set recMstTabs = AdoConnObj.Execute("Select Moduleid,AbnormalBaltable from GenModuleMst " & _
                                        "where AbnormalBaltable is not null")
    
    If Not recMstTabs.EOF And Not recMstTabs.BOF Then
    '''''' updation of abnormal balances branch wise
        Do While Not recMstTabs.EOF
            If UCase(recMstTabs(0)) <> "CC" Then
                Condition = "Curbal<0"
            Else
                Condition = "Curbal>0"
            End If
           
            ''''''' Insert records which has abnormal balance
            result = "Insert into " & recMstTabs(1) & "(Branchcode,Currencycode,Glcode," & _
                        " Accno,Abnormalbal,Applicationdate) " & _
                        " select Branchcode,Currencycode,Glcode,Accno,Curbal,Applicationdate " & _
                        " from " & recMstTabs(0) & "Balance where " & Condition & " and Branchcode='" & BrCode & "' "
            AdoConnObj.Execute (result)
            recMstTabs.MoveNext
        Loop
    End If
 
    result = "Proceed"
    AbnormalBalanceUpdation = "Proceed"
    Exit Function
                      
myErr:
    result = result & " " & Err.Description
    AbnormalBalanceUpdation = result


End Function

Public Function ABBUpdations(BranchCode As String, CurrencyCode As String, ApplicationDate As String)
On Error GoTo myErr
    Dim appDate As String
    Dim BrCode As String
    Dim CRCode As String
    Dim Condition As String
    Dim Modid As String
    Dim ModeofTran As String
    Dim GlCode As String
    Dim strBrBatchno As String, strABBBatchNo As String, strABBTranNo As String
    Dim recABBTemp As ADODB.Recordset, TranAmt As Double
    
    '''''' Reading parameters
    appDate = ApplicationDate
    BrCode = BranchCode
    CRCode = CurrencyCode
    
    ''''' Createing Instances of  recordsets
    Set recClg = CreateObject("adodb.recordset")
    Set recTrans = CreateObject("adodb.recordset")
    Set recCash = CreateObject("adodb.recordset")
    Set recMod = CreateObject("adodb.recordset")
    
    result = "SELECT nvl(IMPLEMENTEDYN,'N')  IMPLEMENTEDYN FROM GENMODULETYPESMST WHERE moduleid='ABB' " & _
    " and branchcode='" & BranchCode & "'"
    Set recMod = AdoConnObj.Execute(result)
    
    If Not recMod.EOF Or Not recMod.BOF Then
        
        If recMod(0) = "N" Then
                ABBUpdations = "Proceed"
                Exit Function
        End If
    Else
        ABBUpdations = "Proceed"
        Exit Function
    End If
    
    result = "select abbmoduleid,abbglcode from genBankParm"
    Set recMod = AdoConnObj.Execute(result)
    
    If recMod.EOF Or recMod.BOF Then
        result = "ABB Moduleid and ABB GL code is not specified in GenBankParm table." & _
                "Day End is aborted"
        GoTo myErr
    ElseIf IsNull(recMod(0)) = True Or IsNull(recMod(1)) = True Then
        result = "ABB Moduleid and ABB GL code is not specified in GenBankParm table." & _
                "Day End is aborted"
        GoTo myErr
    Else
        Modid = recMod(0).Value
        GlCode = recMod(1).Value
    End If
    Set recMod = Nothing
    
    'Code added by Radhika on 10 July 2008
    result = "SELECT modeoftran, nvl(SUM(nvl(amount,0)),0) FROM GENTRANSLOG" & _
        " WHERE branchcode = '" & BrCode & "' AND abbbranchcode IS NOT NULL" & _
        " and currencycode='" & CRCode & "'" & _
        " GROUP BY modeoftran"
        
    Set recTrans = AdoConnObj.Execute(result)
    If recTrans.EOF = False Then
                                        
        strBrBatchno = "99" & Trim(Format(CDate(appDate), "ddmmyy"))
        
        Do While Not recTrans.EOF
            TranAmt = IIf(IsNull(recTrans(1)), 0, recTrans(1))
            TranAmt = Abs(TranAmt)
            ModeofTran = recTrans(0)
            
            If ModeofTran = 1 Or ModeofTran = 3 Or ModeofTran = 5 Then
                ModeofTran = ModeofTran + 1
            ElseIf ModeofTran = 2 Or ModeofTran = 4 Or ModeofTran = 6 Then
                ModeofTran = ModeofTran - 1
                TranAmt = -1 * TranAmt
            Else
                result = "Invalid Mode of Tran (" & ModeofTran & ") found while doing ABB Transactions." & _
                    "Day End is aborted"
                GoTo myErr
            End If
          
            Set recABBTemp = AdoConnObj.Execute("select SEQTRANNOABB.nextVAL FROM dual")
            If recABBTemp.EOF = True Then
                result = "Unable to get Tran Number for doing ABB Transactions." & _
                        "Day End is aborted"
                GoTo myErr
            End If
            strABBTranNo = recABBTemp(0).Value
            Set recABBTemp = Nothing
            
            result = " Insert into GenTransLog (branchcode,currencycode,moduleid,glcode,batchno," & _
                    "tranno,amount,modeoftran,effectivedate,systemgeneratedyn, " & _
                    "serviceid,transtatus,abbbranchcode,applicationdate,userid,machineid) values (" & _
                    "'" & BrCode & "','" & CRCode & "','" & Modid & "','" & GlCode & _
                    "'," & strBrBatchno & "," & strABBTranNo & "," & TranAmt & "," & _
                    ModeofTran & ",'" & appDate & "','Y',1,'A','" & BrCode & "','" & appDate & "','SYSTEM','SYSTEM')"
            
            AdoConnObj.Execute (result)
            
            result = " Insert into ABBTranDay (branchcode,currencycode,moduleid,glcode,batchno," & _
                    "tranno,amount,modeoftran,effectivedate,systemgeneratedyn, " & _
                    "serviceid,transtatus,abbbranchcode,applicationdate,userid,machineid) values (" & _
                    "'" & BrCode & "','" & CRCode & "','" & Modid & "','" & GlCode & _
                    "'," & strBrBatchno & "," & strABBTranNo & "," & TranAmt & "," & _
                    ModeofTran & ",'" & appDate & "','Y',1,'A','" & BrCode & "','" & appDate & "','SYSTEM','SYSTEM')"
            
            AdoConnObj.Execute (result)
            
            recTrans.MoveNext
        Loop
    End If
    Set recTrans = Nothing
    
    ABBUpdations = "Proceed"
    
    Exit Function
                      
myErr:
    result = result & " " & Err.Description
    ABBUpdations = result
End Function



'Public Function SecCoupanDateUpdate(BranchCode As String, ApplicationDate As String)
'On Error GoTo myerr
'
'Dim cptype As String
'Dim dayenddate As String
'Dim daybegindate As String
'Dim begindate As String
'
'Set recTrans = CreateObject("adodb.recordset")
'
'  BRCode = BranchCode
'  dayenddate = ApplicationDate
'  'daybegindate = "30-Jun-2001"
'
'  begindate = dayenddate
' nofdays = DateDiff("D", dayenddate, daybegindate)
'
'
'For i = 1 To nofdays
'
'        If nofdays > 1 Then
'               begindate = Format(DateAdd("d", 1, begindate), "dd-mmm-yyyy")
'            Else
'                begindate = daybegindate
'        End If
'      Set recTrans = SingleRecordSet("TMSECSLRMST", "Securitycode,branchcode," & _
'        " to_char(Lastcoupandate,'dd-Mon-yyyy')lstcpndt," & _
'        " to_char(nextcoupandate,'dd-Mon-yyyy')nxtcpndt, to_char(MATURITYDATE,'dd-Mon-yyyy')matdate, COUPANDAY1,COUPANMONTH1,COUPANDAY2," & _
'        " COUPANMONTH2,COUPANDAY3,COUPANMONTH3,COUPANDAY4,COUPANMONTH4,SHUTPERIOD," & _
'        " INTFREQUENCY,INTBASIS,COUPANTYPE,INTFREQUENCY,INTBASIS", _
'        " branchcode='" & BRCode & "' and status='R'and transtatus='A'and " & _
'        " nextcoupandate is not null and to_char(nextcoupandate,'dd-Mon-yyyy')='" & _
'        begindate & "'", "securitycode")
'
'
'If recTrans.RecordCount > 0 Then
'
'  For j = 0 To recTrans.RecordCount - 1
'        cptype = Format(recTrans!COUPANTYPE)
'        freq = Format(recTrans!INTFREQUENCY)
'        nxcpndt = (recTrans!nxtcpndt)
'        mon = Format(nxcpndt, "mm")
'        dd = Format(nxcpndt, "dd")
'         seccode = Format(recTrans!securitycode)
'
'  If (cptype = "C") Or (cptype = "F") Then
'            If (freq = "Q") Then
'                   If Val(mon) = Val(Format(recTrans!COUPANMONTH1)) Then
'                          cpndd = Val(Format(recTrans!COUPANDAY2))
'                          cpnmm = Val(Format(recTrans!COUPANMONTH2))
'                     ElseIf Val(mon) = Val(Format(recTrans!COUPANMONTH2)) Then
'                           cpndd = Val(Format(recTrans!COUPANDAY3))
'                           cpnmm = Val(Format(recTrans!COUPANMONTH3))
'                    ElseIf Val(mon) = Val(Format(recTrans!COUPANMONTH3)) Then
'                          cpndd = Val(Format(recTrans!COUPANDAY4))
'                          cpnmm = Val(Format(recTrans!COUPANMONTH4))
'                    ElseIf Val(mon) = Format(recTrans!COUPANMONTH4) Then
'                         cpndd = Val(Format(recTrans!COUPANDAY1))
'                         cpnmm = Val(Format(recTrans!COUPANMONTH1))
'
'                 End If
'                yr = Format(nxcpndt, "yyyy")
'                    If Val(cpnmm) >= Val(mon) Then
'                         yr = yr
'                    ElseIf Val(cpnmm) < Val(mon) Then
'                        yr = yr + 1
'                    End If
'
'   ElseIf (freq = "H") Then
'
'                  If Val(mon) = Val(Format(recTrans!COUPANMONTH1)) Then
'                       cpndd = Val(Format(recTrans!COUPANDAY2))
'                       cpnmm = Val(Format(recTrans!COUPANMONTH2))
'                    ElseIf Val(mon) = Val(Format(recTrans!COUPANMONTH2)) Then
'                       cpndd = Val(Format(recTrans!COUPANDAY1))
'                      cpnmm = Val(Format(recTrans!COUPANMONTH1))
'                  End If
'                 yr = Format(nxcpndt, "yyyy")
'                    If Val(cpnmm) >= Val(mon) Then
'                         yr = yr
'                    ElseIf Val(cpnmm) < Val(mon) Then
'                        yr = yr + 1
'                    End If
'
'  ElseIf (freq = "Y") Then
'                       cpndd = Val(Format(recTrans!COUPANDAY1))
'                      cpnmm = Val(Format(recTrans!COUPANMONTH1))
'                      yr = Format(nxcpndt, "yyyy")
'                      yr = yr + 1
'  End If
'          recalnxtdt = Format(cpndd & "-" & cpnmm & "-" & yr, "dd-mmm-yyyy")
'
'
'      If DateDiff("d", Format(recTrans!matdate, "dd-mmm-yyyy"), Format(recalnxtdt, "dd-mmm-yyyy")) < 0 Then
'      result = "Update TMSECSLRMST set Lastcoupandate='" & (recTrans!nxtcpndt) & "',nextcoupandate='" & recalnxtdt & _
'               "'where Securitycode='" & (recTrans!securitycode) & "'"
'
'          AdoConnObj.Execute "Update TMSECSLRMST set Lastcoupandate='" & (recTrans!nxtcpndt) & "',nextcoupandate='" & recalnxtdt & _
'               "'where Securitycode='" & (recTrans!securitycode) & "' and branchcode='" & (recTrans!BranchCode) & " '", raff
'
'        If raff > 0 Then
'         Else
'         GoTo myerr
'        End If
'
'      End If
' End If
'    recTrans.MoveNext
'   Next j
'  End If
'  Next i
'
'  result = "completed"
'SecCoupanDateUpdate = result
'    Exit Function
'
'myerr:
'    result = result & " " & Err.Description
'    SecCoupanDateUpdate = result
'
'End Function
'
'Public Function BoookingsUpdate(BranchCode As String, ApplicationDate As String)
'
'On Error GoTo myerr
'
'Dim cptype As String
'Dim dayenddate As String
'Dim daybegindate As String
'Dim begindate As String
'
'Set recTrans = CreateObject("adodb.recordset")
'
'  BRCode = BranchCode
'  dayenddate = ApplicationDate
'  'daybegindate = "01-May-2001"
'
'  begindate = dayenddate
' nofdays = DateDiff("D", dayenddate, daybegindate)
' '=================================================================
' If nofdays > 1 Then
' result = "Update TMTRNBOOKINGS set maturitystatus='C' where " & _
'           " branchcode= '" & BRCode & "'   and to_char(duedate,'dd-Mon-yyyy') > '" & _
'           dayenddate & "' and to_char(duedate,'dd-Mon-yyyy')  < '" & daybegindate & "' "
'
'
'          AdoConnObj.Execute "Update TMTRNBOOKINGS set maturitystatus='" & matstatus & "' where " & _
'           " branchcode= '" & BRCode & "' and to_char(duedate,'dd-Mon-yyyy')> '" & _
'           dayenddate & "'  and to_char(duedate,'dd-Mon-yyyy')<'" & daybegindate & "'"
'End If
' '======================================================================
'For i = 1 To nofdays
'
'        If nofdays > 1 Then
'               begindate = Format(DateAdd("d", 1, begindate), "dd-mmm-yyyy")
'            Else
'                begindate = daybegindate
'
'        End If
'      Set recTrans = SingleRecordSet("TMTRNBOOKINGS", "glcode,branchcode,maturitystatus," & _
'      " to_char(applicationdate,'dd-Mon-yyyy'),accno,to_char(duedate,'dd-Mon-yyyy')duedate", " branchcode= '" & BRCode & _
'      "' and status='R'and transtatus='A'and maturitystatus<>'C' and " & _
'        " to_char(Duedate,'dd-Mon-yyyy')>='" & begindate & "'", "accno")
'
'    If recTrans.RecordCount > 0 Then
'     dtdiff = DateDiff("D", begindate, recTrans!duedate)
'
'         If Val(dtdiff) = 0 Then       '    C
'                matstatus = "C"
'             ElseIf Val(dtdiff) = 1 Then 'T
'                    matstatus = "T"
'                ElseIf Val(dtdiff) = 2 Then 's
'                    matstatus = "S"
'                   ElseIf Val(dtdiff) > 2 And Val(dtdiff) < 31 Then '1
'                        matstatus = "1"
'                    ElseIf Val(dtdiff) > 30 And Val(dtdiff) < 61 Then '2
'                           matstatus = "2"
'                  ElseIf Val(dtdiff) > 60 And Val(dtdiff) < 91 Then '3
'                        matstatus = "3"
'                ElseIf Val(dtdiff) > 90 And Val(dtdiff) < 121 Then '4
'                        matstatus = "4"
'             ElseIf Val(dtdiff) > 120 And Val(dtdiff) < 151 Then '5
'                    matstatus = "5"
'           ElseIf Val(dtdiff) > 150 Then '6
'                matstatus = "6"
'       End If
'           result = "Update TMTRNBOOKINGS set maturitystatus='" & matstatus & "' where " & _
'           " branchcode= '" & (recTrans!BranchCode) & "' and glcode= '" & _
'           (recTrans!GlCode) & "' and accno='" & (recTrans!AccNo) & "'"
'
'
'          AdoConnObj.Execute "Update TMTRNBOOKINGS set maturitystatus='" & matstatus & "' where " & _
'           " branchcode= '" & (recTrans!BranchCode) & "' and glcode= '" & _
'           (recTrans!GlCode) & "' and accno='" & (recTrans!AccNo) & "'", raff
'
'        If raff > 0 Then
'         Else
'         GoTo myerr
'        End If
'
'  End If
'Next i
''Exit Function
'myerr:
'    result = result & " " & Err.Description
'    SecCoupanDateUpdate = result
'
'
'End Function
'
'Public Function BoookingsUpdateNew(BranchCode As String, ApplicationDate As String)
'
'On Error GoTo myerr
'Dim cptype As String
'Dim dayenddate As String
'Dim daybegindate As String
'Dim begindate As String
'
'  BRCode = BranchCode
'  dayenddate = ApplicationDate
' ' daybegindate = "03-Apr-2001"
' ' begindate = dayenddate
'
' nofdays = DateDiff("D", dayenddate, daybegindate)
'
' '=================================================================
' If nofdays > 1 Then
'   endduedate = Format(DateAdd("d", 1, dayenddate), "dd-mmm-yyyy")
'   beginduedate = Format(DateAdd("d", -1, daybegindate), "dd-mmm-yyyy")
'
' result = "Update TMTRNBOOKINGS set maturitystatus='C',duedate= '" & daybegindate & "' where " & _
'           " branchcode= '" & BRCode & "'   and to_char(duedate,'dd-Mon-yyyy') > '" & _
'           dayenddate & "' and to_char(duedate,'dd-Mon-yyyy')  < '" & daybegindate & "' "
'
' AdoConnObj.Execute "Update TMTRNBOOKINGS set maturitystatus='C', duedate= '" & daybegindate & "' where " & _
'           " branchcode= '" & BRCode & "' and to_char(duedate,'dd-Mon-yyyy')" & _
'           " BETWEEN  to_date('" & endduedate & "','dd-Mon-yyyy') and " & _
'             " to_date('" & beginduedate & "','dd-Mon-yyyy')", raff
'
'
'End If
' '======================================================================
'
'For i = 1 To nofdays
'
'        If nofdays > 1 Then
'               begindate = Format(DateAdd("d", 1, begindate), "dd-mmm-yyyy")
'            Else
'                begindate = daybegindate
'
'        End If
'
'        result = "update tmtrnbookings set maturitystatus='C' where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))=0"
'
'            AdoConnObj.Execute "update tmtrnbookings set maturitystatus='C' where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))=0", raff
'
'            '--------------------
'
'        result = "update tmtrnbookings set maturitystatus='T' where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate -  to_date('" & begindate & "','dd-Mon-yyyy'))=1"
'
'             AdoConnObj.Execute "update tmtrnbookings set maturitystatus='T' where" & _
'                 " branchcode= '" & BRCode & "'and maturitystatus<>'C' and " & _
'                 " (duedate -  to_date('" & begindate & "','dd-Mon-yyyy'))=1", raff
'
'            '------------------------
'
'        result = "update tmtrnbookings set maturitystatus='S' where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))=2"
'            AdoConnObj.Execute "update tmtrnbookings set maturitystatus='S' where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))=2", raff
'
'             '-----------------------
'
'        result = "update tmtrnbookings set maturitystatus=1 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>2 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<31"
'
'            AdoConnObj.Execute "update tmtrnbookings set maturitystatus=1 where" & _
'                 " branchcode='" & BRCode & "'  and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>2 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<31", raff
'
'            '--------------------------
'
'        result = "update tmtrnbookings set maturitystatus=2 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>30 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<61"
'
'                AdoConnObj.Execute "update tmtrnbookings set maturitystatus=2 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>30 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<61", raff
'              '---------------------------
'
'        result = "update tmtrnbookings set maturitystatus=3 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>60 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<91"
'
'
'                 AdoConnObj.Execute "update tmtrnbookings set maturitystatus=3 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>60 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<91", raff
'
'                 '-------------------------------
'
'        result = "update tmtrnbookings set maturitystatus=4 where" & _
'                 " branchcode='" & BRCode & "'and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>90 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<121"
'
'                AdoConnObj.Execute "update tmtrnbookings set maturitystatus=4 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>90 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<121", raff
'
'                 '---------------------------
'
'        result = "update tmtrnbookings set maturitystatus=5 where" & _
'                 " branchcode= '" & BRCode & "'and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>120 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<151"
'
'
'                AdoConnObj.Execute "update tmtrnbookings set maturitystatus=5 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>120 and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))<151", raff
'             '-------------------------------
'
'        result = "update tmtrnbookings set maturitystatus=6 where" & _
'                 " branchcode= '" & BRCode & "'and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>151 "
'
'              AdoConnObj.Execute "update tmtrnbookings set maturitystatus=6 where" & _
'                 " branchcode= '" & BRCode & "' and maturitystatus<>'C' and " & _
'                 " (duedate - to_date('" & begindate & "','dd-Mon-yyyy'))>151 ", raff
'
'        '--------------------------------
'
'Next i
' result = "completed"
'BoookingsUpdateNew = result '
'Exit Function
'
'myerr:
'    result = result & " " & Err.Description
'    BoookingsUpdateNew = result
'
'End Function
'Public Function CurrencywiseLimit(BranchcCode As String, ApplicationDate As String)
'On Error GoTo myerr
'Dim recchkhist As New ADODB.Recordset
'Dim recq As New ADODB.Recordset
'Dim recr As New ADODB.Recordset
'Dim recs As New ADODB.Recordset
'Dim reclimitcur As New ADODB.Recordset
'Dim reccur As New ADODB.Recordset
'Dim AdoConnObj As New ADODB.Connection
'Dim reccrncy As New ADODB.Recordset
'Dim recstatcts As New ADODB.Recordset
'
'Dim xsl As String
'Dim uid As String
'Dim dayenddate As String
'Dim daybegindate As String
'Dim begindate As String
'
'    BRCode = BranchCode
'    dayenddate = ApplicationDate
'    'daybegindate = "03-Apr-2001"
'
'
'
'    xsl = "Select branchcode,basecurrency currencycode,maturitystatus,prodpurchaseorsell," & _
'        " sum(dealamount)psamt  from tmtrnbookings Where " & _
'        " to_char(duedate,'dd-Mon-yyyy')>='" & dayenddate & "' and " & _
'        " (prodpurchaseorsell='Purchase' or prodpurchaseorsell='Sale') " & _
'        " group by  basecurrency,maturitystatus,prodpurchaseorsell,branchcode " & _
'        " Union " & _
'        " Select  branchcode,crosscurrency currencycode,maturitystatus,prodpurchaseorsell,sum(CROSSCURAMOUNT)psamt from " & _
'        " tmtrnbookings Where " & _
'        " to_char(duedate,'dd-Mon-yyyy')>='" & dayenddate & "' and " & _
'        " (prodpurchaseorsell='Purchase' or prodpurchaseorsell='Sale') " & _
'        " group by  crosscurrency,maturitystatus,prodpurchaseorsell,branchcode" & _
'        " order by currencycode, maturitystatus,prodpurchaseorsell"
'
'
'Set reccur = AdoConnObj.Execute(xsl, , adCmdText)
'
'
'
'If reccur.RecordCount > 0 Then
'
'       Set recchkhist = AdoConnObj.Execute("select count(*) recnt from TMREPCURLIMITMSTHIST " & _
'            " where  to_char(applicationdate,'dd-Mon-yyyy')='" & daybegindate & "'")
'
'        If recchkhist!recnt = 0 Then
'            AdoConnObj.Execute "insert into  TMREPCURLIMITMSTHIST select *  from TMREPCURLIMITMST "
'
'            AdoConnObj.Execute "delete from TMREPCURLIMITMST "
'        Else
'            result = " Day begin already completed"
'            Exit Function
'        End If
'
' For i = 1 To reccur.RecordCount - 1
'        If Format(reccur!prodpurchaseorsell) = "Purchase" Then
'            limitamt = Val(reccur!psamt)
'        ElseIf Format(reccur!prodpurchaseorsell) = "Sale" Then
'            limitamt = Val(reccur!psamt) * -1
'        End If
'        AdoConnObj.Execute " insert into  TMREPCURLIMITMST (BRANCHCODE,CURRENCYCODE," & _
'                " MATURITYSTATUS,LIMIT,PURCHASEORSELL,USERID,APPLICATIONDATE,SYSTEMDATE) values " & _
'                " ('" & reccur!BranchCode & "','" & reccur!CurrencyCode & "', '" & reccur!maturitystatus & _
'                "','" & limitamt & "', '" & reccur!prodpurchaseorsell & "','" & uid & "','" & daybegindate & _
'                "',sysdate)"
'        reccur.MoveNext
' Next i
' '-----------------
' Set recstatcts = AdoConnObj.Execute("select branchcode,currencycode,sum(limit)lamt,maturitystatus from " & _
'            " TMREPCURLIMITMST   where  maturitystatus in('C','S','T')" & _
'            " group by branchcode,currencycode,maturitystatus")
'
'
' If recstatcts.RecordCount > 0 Then
'    For j = 1 To recstatcts.RecordCount - 1
'        AdoConnObj.Execute "update TMCURRENCYWISELIMIT set UTOMSPOT='" & recstatcts!lamt & _
'            "' where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'            recstatcts!CurrencyCode & "'"
'    Next j
' End If
'
'     Set reclimitcur = AdoConnObj.Execute("select currencycode,sum(limit)lamt,maturitystatus from " & _
'        " TMREPCURLIMITMST   where  maturitystatus  not in('C','S','T')" & _
'        " group by branchcode,currencycode,maturitystatus")
'
'
' If reclimitcur.RecordCount > 0 Then
'
'   For k = 1 To reclimitcur.RecordCount - 1
'
'           If (reclimitcur!maturitystatus) = "1" Then
'            sql = " update TMCURRENCYWISELIMIT set UMONTH1='" & reclimitcur!lamt & _
'            "'  where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'
'            ElseIf (reclimitcur!maturitystatus) = "2" Then
'            sql = " update TMCURRENCYWISELIMIT set UMONTH2='" & reclimitcur!lamt & _
'            "'  where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'
'            ElseIf (reclimitcur!maturitystatus) = "3" Then
'            sql = " update TMCURRENCYWISELIMIT set UMONTH3='" & reclimitcur!lamt & _
'            "'  where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'            ElseIf (reclimitcur!maturitystatus) = "4" Then
'           sql = " update TMCURRENCYWISELIMIT set UMONTH4='" & reclimitcur!lamt & _
'            "'  where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'
'            ElseIf (reclimitcur!maturitystatus) = "5" Then
'           sql = " update TMCURRENCYWISELIMIT set UMONTH5='" & reclimitcur!lamt & _
'            "'  where branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'
'            ElseIf (reclimitcur!maturitystatus) = "6" Then
'
'            sql = " update TMCURRENCYWISELIMIT set UMONTH6='" & reclimitcur!lamt & _
'            "'  w0here branchcode='" & recstatcts!BranchCode & "' and currencycode='" & _
'                 reclimitcur!CurrencyCode & "'"
'
'         End If
'             Set reclmtupdt = AdoConnObj.Execute(sql, raff, adCmdText)
'reclimitcur.MoveNext
'Next k
'
'End If
'    Else
'    result = "No Records found"
'    Exit Function
'End If
' '-------------------
'result = "completed"
'
'CurrencywiseLimit = result '
'Exit Function
'
'myerr:
'    result = Err.Description
'    CurrencywiseLimit = result '
'
'End Function
'
'Public Function TMProcedures(BranchCode As String, ApplicationDate As String)
'On Error GoTo myerr
'
'
'Dim rslt As String
'
'rslt = CurrencywiseLimit(BranchCode, ApplicationDate)
'If rslt <> "completed" Then
'    GoTo myerr
'End If
'
'rslt = SecCoupanDateUpdate(BranchCode, ApplicationDate)
'If rslt <> "completed" Then
'    GoTo myerr
'End If
'rslt = BoookingsUpdateNew(BranchCode, ApplicationDate)
'If rslt <> "completed" Then
'    GoTo myerr
'End If
'
'TMProcedures = "Proceed"
'Exit Function
'
'myerr:
'    TMProcedures = rslt
'End Function

