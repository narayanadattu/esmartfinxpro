VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "DailyReports"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String
Dim objfetch As Object
Dim objTrans As Object
Dim ObjContext As ObjectContext
Dim recSupplement  As Recordset
Dim newtemp As Recordset
Dim recTemp  As Recordset
Dim recRepno As Recordset
Dim recBranch As Recordset
Dim recTrans As Object
Dim objQuery As Object
Dim objMstTrans As Object
Dim ConsRepno As Integer
Dim rsgnbnkp As Recordset

Public Function ProfitNLoss(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String, Optional Currency2 As String, Optional Currency3 As String)
                             

On Error GoTo ErrHand

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As Integer
Dim StrCondition As String
    
    AppDate = UCase(ApplicationDate)
    BrCode = UCase(BranchCode)
    UserId = UCase(UserId)
 
    If Currency2 = "" Then Currency2 = "XX"
    If Currency3 = "" Then Currency3 = "YY"
    
    
     ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set newtemp = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    ''''''' Query fields
 
    QryFlds = " distinct a.glcode,a.gldescription,b.moduleid,decode(b.glacctype,4,'Rs',3,'Ls')," & _
              "nvl(b.glcategory,'A'),to_number(b.titleprintorder||b.printorder)"
            
    ''''' Query Tables
    QryTable = "GLOpenBalanceMst a,GenGlMastMst b, genglsheetmst c"
  
    '''''' Query condition
    QryCondition = "a.branchcode = c.branchcode and a.glcode = b.glcode " & _
                " and a.glcode=c.glcode and a.branchcode='" & Trim(BrCode) & "' and " & _
                " (b.glacctype=3 or b.glacctype=4) and " & _
                " a.openbaldate<=to_date('" & UCase(AppDate) & "','dd-MON-yyyy') " & _
                " and b.titlegl is not null and b.glcategory='A' and a.currencycode='" & Currency1 & _
                "' Order By to_number(b.titleprintorder||" & _
                " b.printorder)"
    
    RepNo = 1
    
    Set recTemp = objfetch.singlerecordset("RepProfitNLossTemp", "nvl(max(nvl(repno,0)),0)+1")
    If Not recTemp.EOF And Not recTemp.BOF Then RepNo = recTemp(0)

    If ConsRepno > 0 Then RepNo = ConsRepno
    
    ''''''' Query Gentranslog Table
    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
    
        
     '''' If mathcing records found
        If Not recTemp.EOF And Not recTemp.BOF Then
                   
            ''''' Temp Table name
            StrTabName = "RepProfitNLossTemp"
    
            ''''' Field names to temp table
            StrFlds = "BRANCHCODE,GLCODE,Narration,MODULEID,CATEGORY,titleyn," & _
                        "printorder,APPLICATIONDATE,REPNO,USERID"
            '''' Formate record values into array
            rcnt = 0
            ReDim DataArray(0, 4)
            
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To 4
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & "," & recTemp(5) & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            reccount = rcnt
            StrMainString = Mid(StrMainString, 2)
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Update Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & "23" & "   " & StrMainString
                GoTo ErrHand
            End If
            
            QryFlds = " distinct a.glcode,a.gldescription,a.moduleid,decode(a.glacctype,4,'Rs',3,'Ls')," & _
              "nvl(a.glcategory,'A'),to_number(a.titleprintorder||a.printorder)"
            
            QryTable = "GenGlMastMst a"
  
            '''''' Query condition
            QryCondition = " (a.glacctype=3 OR a.glacctype=4) AND " & _
                            "( glcategory='C' OR glcategory='B') ORDER BY " & _
                            " to_number(a.titleprintorder||a.printorder)"
           
            ''''''' Query GenGLMastMSt Table for titles and sub totals
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
           
            
            StrMainString = ""
            
            If Not recTemp.EOF And Not recTemp.BOF Then
                   
                ''''' Temp Table name
                StrTabName = "RepProfitNLossTemp"
        
                ''''' Field names to temp table
                StrFlds = "BRANCHCODE,GLCODE,Narration,MODULEID,CATEGORY,titleyn," & _
                            "printorder,APPLICATIONDATE,REPNO,USERID"
                '''' Formate record values into array
                rcnt = 0
                ReDim DataArray(0, 4)
                
                Do While Not recTemp.EOF
                    
                    StrString = "'" & BrCode & "'"
                    For icnt = 0 To 4
                        StrString = StrString & ",'" & recTemp(icnt) & "'"
                    Next
                    StrMainString = StrMainString & "|" & StrString & "," & recTemp(5) & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                    rcnt = rcnt + 1
                    recTemp.MoveNext
                Loop
                reccount = rcnt
                StrMainString = Mid(StrMainString, 2)
                DataArray(0, 0) = "I"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = CStr(StrFlds)
                DataArray(0, 3) = CStr(StrMainString)
                DataArray(0, 4) = ""
          
                ''''' Update Records
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & "11"
                    GoTo ErrHand
                End If
            End If
            
                    
            ''''' Updating amounts for First currency type
            
            QryFlds = "distinct glcode,nvl(openbalamount,0)"
            QryTable = "glopenbalancemst"
            QryCondition = "branchcode='" & BrCode & "' and " & _
                        "  currencycode='" & Currency1 & "' and openbaldate<= " & _
                        " to_date('" & UCase(AppDate) & "','dd-MON-yyyy') " & _
                        "  and (glaccttype=3 or glaccttype=4)"
            
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
            '''' Formate record values into array
                       
            rcnt = 0
            StrFlds = "Amount"
            StrMainString = ""
            StrUpCondition = ""
           If Not recTemp.EOF And Not recTemp.BOF Then
              Do While Not recTemp.EOF
                  StrMainString = StrMainString & "|" & recTemp(1)
                  
                  'code corrected by Radhika on 30 aug 2008
                  'Reason: if we are not using br code in condition it is cumulating data
                  'of other branches (especially when we are calling this method from
                  'ConsolidationPL method)
                  '*********original code
                  'StrUpCondition = StrUpCondition & "|" & "upper(glcode)='" & UCase(Trim(CStr(recTemp(0)))) & "' and repno='" & RepNo & "'"
                  
                  '*********modified code
                  StrUpCondition = StrUpCondition & "|" & "upper(glcode)='" & _
                  UCase(Trim(CStr(recTemp(0)))) & "' and repno='" & RepNo & "'" & _
                  " and branchcode='" & Trim(BrCode) & "'"
                  'End of modified code on 30 aug 2008
                  
                  rcnt = rcnt + 1
                  recTemp.MoveNext
              Loop
             
              '''''' update closing balances of effected gls
              StrUpCondition = Mid(StrUpCondition, 2)
              StrMainString = Mid(StrMainString, 2)
              DataArray(0, 0) = "U"
              DataArray(0, 1) = CStr(StrTabName)
              DataArray(0, 2) = CStr(StrFlds)
              DataArray(0, 3) = CStr(StrMainString)
              DataArray(0, 4) = CStr(StrUpCondition)
            
              ''''' Update Records
              Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
              
              If Mid(Result, 1, 11) <> "Transaction" Then
                  Result = Result & " 1"
                  GoTo ErrHand
              End If
            End If
            
            ''''''''' Updating amounts of Effected GLs for Currency 1

            QryFlds = "distinct a.glcode,nvl(b.closingbalance,0)"
            QryTable = "glopenbalancemst a,gengldaybook b"
            QryCondition = " a.branchcode = b.branchcode and a.glcode = b.glcode " & _
                        " and a.branchcode='" & BrCode & "' and " & _
                        " a.currencycode='" & Currency1 & "' " & _
                        " and a.currencycode=b.currencycode " & _
                        " and openbaldate<=to_date('" & UCase(AppDate) & "','dd-MON-yyyy') " & _
                        " and b.Currencycode='" & Currency1 & "'" & _
                        "  and (a.glaccttype=3 or a.glaccttype=4) and b.applicationdate=" & _
                        " (select to_char(max(applicationdate),'dd-MON-yyyy')" & _
                        " from gengldaybook where applicationdate<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
                        " and glcode=b.glcode and branchcode=b.branchcode and currencycode=b.currencycode) "
                        
            recTemp.Close
            ''''''' Query Gentranslog Table
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
            
            '''' Formate record values into array
             
            rcnt = 0
            StrFlds = "Amount"
            'ReDim StrValues(recTemp.RecordCount - 1)
            StrMainString = ""
            StrUpCondition = ""
           If Not recTemp.EOF And Not recTemp.BOF Then
              Do While Not recTemp.EOF
                  StrMainString = StrMainString & "|" & recTemp(1)
                  'code modified by radhika on 30 aug 2008
                  'StrUpCondition = StrUpCondition & "|" & "upper(glcode)='" & UCase(Trim(CStr(recTemp(0)))) & "' and repno='" & RepNo & "'"
                  StrUpCondition = StrUpCondition & "|" & "upper(glcode)='" & _
                  UCase(Trim(CStr(recTemp(0)))) & "' and repno='" & RepNo & "'" & _
                  " and branchcode ='" & Trim(BrCode) & "'"
                  'end of code modified by radhika on 30 aug 2008
                  
                  rcnt = rcnt + 1
                  recTemp.MoveNext
              Loop
             
              '''''' update closing balances of effected gls
              StrUpCondition = Mid(StrUpCondition, 2)
              StrMainString = Mid(StrMainString, 2)
              DataArray(0, 0) = "U"
              DataArray(0, 1) = CStr(StrTabName)
              DataArray(0, 2) = CStr(StrFlds)
              DataArray(0, 3) = CStr(StrMainString)
              DataArray(0, 4) = CStr(StrUpCondition)
            
              ''''' Update Records
              Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
              
             
             
              If Mid(Result, 1, 11) <> "Transaction" Then
                  Result = Result & " 4"
                  GoTo ErrHand
              End If
           End If
            
        ''''''' updation of Subtotals to Subtotal GLS
        
        QryFlds = "b.subtotalatgl,nvl(sum(nvl(a.amount,0)),0),nvl(sum(nvl(a.amount1,0)),0)," & _
                    "nvl(sum(nvl(a.amount2,0)),0)"
            
        ''''' Query Tables
        QryTable = "RepProfitNLossTemp a,GenGlMastMst b"
  
        '''''' Query condition
        QryCondition = "a.glcode = b.glcode and b.subtotalatgl is not null " & _
                       " and a.branchcode='" & Trim(BrCode) & "'" & _
                       " and a.repno=" & RepNo & " group by b.subtotalatgl "
      
        Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
          
                 
        '''' Formate record values into array
            rcnt = 0
            StrUpCondition = ""
            StrMainString = ""
            StrFlds = "Amount,Amount1,Amount2"
            
                       
            If Not recTemp.EOF And Not recTemp.BOF Then
              Do While Not recTemp.EOF
                  StrMainString = StrMainString & "|" & recTemp(1) & "~" & Abs(recTemp(2)) & "~" & _
                                   Abs(recTemp(3))
                  StrUpCondition = StrUpCondition & "|" & "glcode='" & recTemp(0) & _
                  "' and repno=" & RepNo & " and branchcode='" & Trim(BrCode) & "'"
                  rcnt = rcnt + 1
                  recTemp.MoveNext
              Loop
              StrUpCondition = Mid(StrUpCondition, 2)
              StrMainString = Mid(StrMainString, 2)
              DataArray(0, 0) = "U"
              DataArray(0, 1) = CStr(StrTabName)
              DataArray(0, 2) = CStr(StrFlds)
              DataArray(0, 3) = CStr(StrMainString)
              DataArray(0, 4) = CStr(StrUpCondition)
            
              '''''' update closing balances of effected gls
              Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                          
              If Mid(Result, 1, 11) <> "Transaction" Then
                  Result = Result & "  " & StrTabName & "   " & StrFlds & "   " & StrMainString & "    " & StrUpCondition
                  GoTo ErrHand
              End If
            End If
        
        
        '''''''' Checking balance of profit and loss
               
        QryFlds = "(select nvl(sum(nvl(amount,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Ls' and titleyn='C')+" & _
                    "(select nvl(sum(nvl(amount,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Rs' and titleyn='C')," & _
                    "(select nvl(sum(nvl(amount1,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Ls' and titleyn='C')+" & _
                    "(select nvl(sum(nvl(amount1,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Rs' and titleyn='C')," & _
                    "(select nvl(sum(nvl(amount2,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Ls' and titleyn='C')+" & _
                    "(select nvl(sum(nvl(amount2,0)),0) from repprofitnlosstemp where branchcode='" & Trim(BrCode) & "' and repno=" & RepNo & _
                    " and category='Rs' and titleyn='C')"
     
        ''''' Query Tables
        QryTable = "RepProfitNLossTemp"
  
        '''''' Query condition
        QryCondition = "rownum<2"
        
        Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
        
        '''' Formate record values into array
           ReDim DataArray(1, 4)
           rcnt = reccount + 1
           StrMainString = ""
           amount1 = recTemp(0)
           amount2 = recTemp(1)
           amount3 = recTemp(2)
           
           If IsNull(amount1) Or amount1 > 0 Then
                rsmainstring = 0
                lsmainstring = amount1 * -1
           Else
                rsmainstring = amount1 * -1
                lsmainstring = 0
           End If
            
           
           If IsNull(amount2) Or amount2 < 0 Then
                rsmainstring = rsmainstring & "," & 0
                lsmainstring = lsmainstring & "," & Abs(amount2)
           Else
                rsmainstring = rsmainstring & "," & Abs(amount2)
                lsmainstring = lsmainstring & "," & 0
           End If
           
           If IsNull(amount3) Or amount3 < 0 Then
                rsmainstring = rsmainstring & "," & 0
                lsmainstring = lsmainstring & "," & Abs(amount3)
           Else
                rsmainstring = rsmainstring & "," & Abs(amount3)
                lsmainstring = lsmainstring & "," & 0
           End If
           
           
           Set recTemp = objfetch.singlerecordset("GenBankParm", "ProfitGl,ProfitGLDesc,LossGL,LossGLDesc")
                   
            StrTabName = "RepProfitNLossTemp"
            StrFlds = "branchcode,category,Glcode,Narration,amount,amount1,amount2," & _
                      "titleyn,printorder,applicationdate,repno,userid"
            
                    StrMainString = "'" & BrCode & "','Ls','" & recTemp(0) & "','" & recTemp(1) & _
                            "'," & lsmainstring & ",'X',999999 ,'" & AppDate & _
                            "'," & RepNo & ",'" & UserId & "'"
            
                    DataArray(0, 0) = "I"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = ""
            
                    reccount = reccount + 1
                    StrMainString = "'" & BrCode & "','Rs','" & recTemp(2) & "','" & recTemp(3) & _
                            "'," & rsmainstring & ",'X',999999,'" & AppDate & _
                            "'," & RepNo & ",'" & UserId & "'"
            
                    DataArray(1, 0) = "I"
                    DataArray(1, 1) = CStr(StrTabName)
                    DataArray(1, 2) = CStr(StrFlds)
                    DataArray(1, 3) = CStr(StrMainString)
                    DataArray(1, 4) = ""
          
                    ''''' Insert Records
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 7"
                        GoTo ErrHand
                    End If

               
        '''''''' Updation of Grand totals
        
        QryFlds = "category,nvl(sum(nvl(amount,0)),0),nvl(sum(nvl(abs(amount1),0)),0)," & _
                    "nvl(sum(nvl(abs(amount2),0)),0)"
        ''''' Query Tables
        QryTable = "RepProfitNLossTemp"
  
        '''''' Query condition
        QryCondition = "(titleyn='C' or titleyn='X') and repno=" & RepNo & _
        " and branchcode='" & Trim(BrCode) & "' group by category "
        Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
        
        '''' Formate record values into array
          ReDim DataArray(0, 4)
           rcnt = reccount + 1
           StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'G'," & rcnt & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            
            StrTabName = "RepProfitNLossTemp"
            StrFlds = "branchcode,category,amount,amount1,amount2," & _
                "titleyn,printorder,applicationdate,repno,userid"
            StrMainString = Mid(StrMainString, 2)
            
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 8"
                GoTo ErrHand
            End If

           
        End If
    
    ProfitNLoss = Result
   
Exit Function

ErrHand:
  
    
    If Err.Number <> 0 Then
       ProfitNLoss = Err.Number & Err.Description
    Else
       ProfitNLoss = Result
    End If

    
End Function


Public Function BranchDayEnd(BranchCode As String)
On Error GoTo myerr
Dim BrCode As String
Dim Message As String
ReDim DataArray(0, 4)
Set objQuery = CreateObject("Queryrecordsets.Fetchrecordsets")
Set recTrans = CreateObject("adodb.recordset")
Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
BrCode = BranchCode

''''''''''''''''''''''''''''''' Transactions Checking ''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'Code commented by Radhika on 03-mar-2008
'reason: For few transactions, machine id is missing. Because of that day end process is
'getting aborted.
''''''''''''' Checking the complete transaction is Gentranslog
'    Set recTrans = objQuery.singlerecordset("Gentranslog", "Batchno", _
'                "(userid is null or machineid is null or approvedby is null " & _
'                " or approvedmachine is null) and branchcode='" & BrCode & "'")
'    If Not recTrans.EOF And Not recTrans.BOF Then
'        Message = "Some Transactions are not Completed. Day end is aborted..!"
'        GoTo myerr
'    End If



''''''''''''' Checking if any records are there in  GenTempTranslog
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("GenTempTranslog", "Batchno", "branchcode='" & _
'                    BrCode & "' and transtatus<>'D' ")
    Set recTrans = objQuery.singlerecordset("GenTempTranslog", "Batchno", _
        "(   (BranchCode='" & BrCode & "' and abbYN<>'Y') " & _
        " or (ABBBranchcode='" & BrCode & "' and abbYN='Y') )" & _
        " and transtatus<>'D' ")
    'end of Code corrected by Radhika on 24 May 2008

    If Not recTrans.EOF And Not recTrans.BOF Then
        'Message = "Some Transactions Found in GENTEMPTRANSLOG. Day end is aborted..!"
        Message = "Some Transactions Found in Temporary Transaction Log." & _
        " Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Checking if any records are there in  GenDisposalDtlsTemp
    Set recTrans = objQuery.singlerecordset("GenDisposalDtlsTemp", "Moduleid", "branchcode='" & _
                    BrCode & "' and transtatus<>'D'")

    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Transactions Found in GENDISPOSALDTLSTEMP. Day end is aborted..!"
        GoTo myerr
    End If
    
    
''''''''''''' Checking whehter any transaction is in pending
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("Gentranslog", "Batchno", _
'                "transtatus='P' and branchcode='" & BrCode & "'")
    Set recTrans = objQuery.singlerecordset("Gentranslog", "Batchno", _
        "transtatus='P' and " & _
        "(   (BranchCode='" & BrCode & "' and abbYN<>'Y') " & _
        " or (ABBBranchcode='" & BrCode & "' and abbYN='Y') )")
    'end of Code corrected by Radhika on 24 May 2008
    
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Transactions are not Approved. Day end is aborted..!"
        GoTo myerr
    End If

''''''''''''' if service id  =2, Accno should not be null
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("Gentranslog", "accno", _
'                "serviceid=2 and accno is null  and branchcode='" & BrCode & "'")
    Set recTrans = objQuery.singlerecordset("Gentranslog", "accno", _
        "serviceid=2 and accno is null  and " & _
        "(   (BranchCode='" & BrCode & "' and abbYN<>'Y') " & _
        " or (ABBBranchcode='" & BrCode & "' and abbYN='Y') )")
    'end of Code corrected by Radhika on 24 May 2008
    
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some new accounts are to be opened. Day end is aborted..!"
        GoTo myerr
    End If


'''''''''''' Checking whether any Normal batches are not tallied in  gentranslog
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("gentranslog", " batchno", "branchcode='" & _
'                    BrCode & "' GROUP BY batchno HAVING NVL(SUM(NVL(amount,0)),0) <> 0 ")
    Set recTrans = objQuery.singlerecordset("gentranslog", " batchno", "branchcode='" & _
                    BrCode & "' and abbyn <> 'Y' and abbbranchcode is null " & _
                    " GROUP BY batchno HAVING NVL(SUM(NVL(amount,0)),0) <> 0 ")
    'end of Code corrected by Radhika on 24 May 2008
    
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some of the Batches were not Tallied. Day end is aborted..!"
        GoTo myerr
    End If

    'New Code added by Radhika on 24 May 2008
'''''''''''' Checking whether any ABB batches are not tallied in  gentranslog
    Set recTrans = objQuery.singlerecordset("gentranslog", " batchno", _
            "ABBbranchcode='" & BrCode & "' and abbyn = 'Y' " & _
            " GROUP BY batchno HAVING NVL(SUM(NVL(amount,0)),0) <> 0 ")
                    
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some of the ABB Batches were not Tallied. Day end is aborted..!"
        GoTo myerr
    End If
    'end of Code added by Radhika on 24 May 2008
    
'''''''''''''''''''''''''''''''''''' Cash Transactions ''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



''''''''''''' Checking whehter cashierid is null for mode of tran 1 and 2 (cash transactions)
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("Gentranslog", "Batchno", _
'                "cashierid is null and modeoftran in(1 ,2) and branchcode='" & _
'                    BrCode & "' and upper(moduleid)<>'CASH' ")
    Set recTrans = objQuery.singlerecordset("Gentranslog", "Batchno", _
            "cashierid is null and modeoftran in(1 ,2) and " & _
            "(   (BranchCode='" & BrCode & "' and abbYN<>'Y') " & _
            " or (ABBBranchcode='" & BrCode & "' and abbYN='Y') )" & _
            " and upper(moduleid)<>'CASH' ")
    'end of Code corrected by Radhika on 24 May 2008
                        
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Cashier Id is null for some Cash Transactions. Day end is aborted..!"
        GoTo myerr
    End If

''''''''''''' Checking All cashiers should refund cash and accepted by vault
 '''''''''''''  No transfers between cash counter and cash refund should be pending
    Set recTrans = objQuery.singlerecordset("CashCountermst ", "counterstatus", _
                "counterstatus<>'C' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Transfers between Cash Counter and Cash Refund are pending." & _
                    "Day end is aborted..!"
        GoTo myerr
    End If
    

''''''''''''' Checking if any exceptional transactions is not verified
    'Code commented and rewritten by Radhika on 24 May 2008
    'Reason: ABB Transactions not handled properly
'    Set recTrans = objQuery.singlerecordset("Gentranslog a,GenExceptionaltranday b   ", _
'        "a.verifiedby", "(a.verifiedby is null or b.verifiedby is null) and " & _
'        "a.branchcode='" & BrCode & "' and " & _
'        " a.branchcode=b.branchcode and a.batchno=b.batchno " & _
'        " and a.exceptionyn='Y'  ")

Set rsgnbnkp = CreateObject("adodb.recordset")

    Set rsgnbnkp = objQuery.singlerecordset("genbankparm", "EXCEPAPPREQYN")
    If Not rsgnbnkp.EOF And Not rsgnbnkp.BOF Then
    
     If rsgnbnkp(0) = "Y" Then

    Set recTrans = objQuery.singlerecordset("Gentranslog a,GenExceptionaltranday b   ", _
        "a.verifiedby", "(a.verifiedby is null or b.verifiedby is null) and " & _
        "(   (a.BranchCode='" & BrCode & "' and a.abbYN<>'Y') " & _
        " or (a.ABBBranchcode='" & BrCode & "' and a.abbYN='Y') )" & _
        " and a.branchcode=b.branchcode and a.batchno=b.batchno " & _
        " and a.exceptionyn='Y' and  CLGRATETYPE is null")
    'end of Code corrected by Radhika on 24 May 2008
    
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Exceptional Transactions are not verified. Day end is aborted..!"
        GoTo myerr
    End If
    Else
End If
End If


'''''''''''''''''''''''''''''' Clearing Checking ''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'''''''''''''Check all outward clearing batches which are having lodgment date is
'''''''''''' less than or equal to application date  are closed

    'This code was commented by Radhika on 05-DEC-2007
    'Reason: Here these 2 tables were not joined properly
'    Set recTrans = objQuery.singlerecordset("ClgLodgementVoucherDtls a,ClgBatchDtls b", _
'                "a.status", "a.clearingtype=b.clearingcode and a.lodgementdate<= " & _
'                "(select applicationdate from GenApplicationDateMst where branchcode='" & _
'                 BrCode & "') and b.status<>'C' and b.branchcode='" & BrCode & "'")

    'Note: Here "applicationdate" is nothing but Lodgement Date
    Set recTrans = objQuery.singlerecordset("ClgBatchDtls", _
                "status", "branchcode='" & BrCode & "' and status<>'C' and " & _
                " TO_DATE(TO_CHAR(applicationdate,'dd-mon-yyyy'),'dd-mon-yyyy')<= " & _
                "(select TO_DATE(TO_CHAR(applicationdate,'dd-mon-yyyy'),'dd-mon-yyyy') " & _
                " from GenApplicationDateMst where branchcode='" & BrCode & "') ")
                
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some of the Outward Clearing Batches are not closed. Day end is aborted..!"
        GoTo myerr
    End If

 
 
 ''''''''''''' Check  Clearing regularization dates check for completion
 
    'Set recTrans = objQuery.singlerecordset("ClgLodgementVoucherDtls", "regularisationdate", _
     '           " regularisationdate Is Null and branchcode='" & BrCode & "'")
    'If Not recTrans.EOF And Not recTrans.BOF Then
     '   Message = "Regularization is in pending. Day end is aborted..!"
      '  GoTo myerr
   ' End If

 '''''''''''''Check all inward clearing batches are closed
 
    Set recTrans = objQuery.singlerecordset("ClgInwardBatchDtls", "status", _
                " status<>'C' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some of the inward clearing batches are not closed. Day end is aborted..!"
        GoTo myerr
    End If


''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''' General Checking ''''''''''''''''''''''''''''''''''''
     
     
''''''''''''' Checking any amendment is pendiing for any module
    Set recTrans = objQuery.singlerecordset("GenMasterAmendmentTemp", _
                "moduleid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Amendments are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Checking any security is pendiing for any module
    Set recTrans = objQuery.singlerecordset("GenSecurityMst", _
                "securityid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Securities are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
'''''''''''' Checking any Limit is pendiing for any module
    Set recTrans = objQuery.singlerecordset("GenLimitMst", _
                "limitid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Limits are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Checking any Stock Security is pendiing for any module
    Set recTrans = objQuery.singlerecordset("GenStockMst", _
                "limitid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Securities(Stock) are not approved. Day end is aborted..!"
        GoTo myerr
    End If


    
''''''''''''' Checking any Stock Security is pendiing for any module
    Set recTrans = objQuery.singlerecordset("Gensecuritylnk", _
                "Securityid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Linked Securities are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Checking any Stock Security is pendiing for any module
    Set recTrans = objQuery.singlerecordset("GenLimitlnk", _
                "Limitid", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Linked Limits are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    

''''''''''''' Check Cheque book issued must be approved
    Set recTrans = objQuery.singlerecordset("GenChequeDtls", _
                "Accno", "status='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Cheque Books Issued to customer are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Check Instruments issued  to Department must be approved
    Set recTrans = objQuery.singlerecordset("GenDeptCustInstrStockDtls", _
                "Accno", "transstatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Cheque Books Issued to department are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
''''''''''''' Check Instruments issued  to Customer must be approved
    Set recTrans = objQuery.singlerecordset("GenInstrumentStockDtls", _
                "IssuedTo", "TranStatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Cheque Books Received in stock are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
    
''''''''''''' Check Stop payments must be approved
    Set recTrans = objQuery.singlerecordset("GenStopPayMst", _
                "stopno", "status='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Stop Payments are not approved. Day end is aborted..!"
        GoTo myerr
    End If

''''''''''''' Check Stop Pay Cancellations must be approved
    Set recTrans = objQuery.singlerecordset("GENSTOPCANCELMST", _
                "Accno", "status='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Stop Payment Cancellations are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
'''''''''''''' Check whether any Remitance Issuals are in pending
    Set recTrans = objQuery.singlerecordset("remparticulartrn", _
                "accno", "issuestatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some of the Remitances are not Issued. Day end is aborted..!"
        GoTo myerr
    End If


'''''''''''''''''''''''''''' Module Checking '''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

'''''''''''''' Check SB whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("SBMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some SB Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check CA whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("CAMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some CA Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check LOANs whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("LOANMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Loan Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check CC whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("CCMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some CC Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check Deposits whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("DEPMst", _
                "accno", "transtatus in ('P','T') and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Deposit Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check LC whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("LCMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some LC Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
'''''''''''''' Check LG whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("LGMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some LG Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If

'''''''''''''' Check Bills whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("BILLSMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Bills Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
    '''''''''''''' Check Lockers whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("LockerMst", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Locker Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
    '''''''''''''' Check Bank Account whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("INVMST", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Bank Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
    '''''''''''''' Check Pigmy Agent whether any accounts are in pending
    Set recTrans = objQuery.singlerecordset("PIGMYMST", _
                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = "Some Daily Deposit Agent Accounts are not approved. Day end is aborted..!"
        GoTo myerr
    End If
    
    'Check whether Daily Deposits (i.e PIGMY) moule was implemented or not.
    'If Yes, check whether any transactions are pending or not.
    Set recTrans = objQuery.singlerecordset("GENMODULETYPESMST", _
            "moduleid", "branchcode='" & BrCode & "'" & _
            " AND moduleid='PIGMY' AND implementedYN='Y'")
    
    If Not recTrans.EOF And Not recTrans.BOF Then
    
        'Now check any A/C level transactions are pending or not
        Set recTrans = objQuery.singlerecordset("PIGMYACCTRANDAY", _
                "moduleid", "branchcode='" & BrCode & "'" & _
                " AND transtatus ='P'")
        If Not recTrans.EOF And Not recTrans.BOF Then
            Message = "Some Pigmy Account Level Transactions are not approved. Day end is aborted..!"
            GoTo myerr
        End If
        
    End If

  '''''''''''''' Check any ABB Transactions are in pending
     Set recTrans = objQuery.singlerecordset("gentranslog", _
                "accno,ABBBRANCHCODE", "abbyn = 'Y' and transtatus='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = " Some ABB Transactions are not approved at " & recTrans(1).Value & " branch . Day end is aborted..!"
        GoTo myerr
    End If

'''' check deleted transactions pending approval
  
 Set recTrans = objQuery.singlerecordset("gendeletedtranslog", _
                "accno,BRANCHCODE", "DELETEDTRANSTATUS='P' and branchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = Message & " Some Deleted Transactions Are Not Approved " & recTrans(1).Value & " branch . Day end is aborted..!"
         GoTo myerr
    End If
    
     '''''''''''''' Check any ABB Transactions Deletion are in pending
  Set recTrans = objQuery.singlerecordset("gendeletedtranslog", _
                "accno,ABBBRANCHCODE", "abbyn = 'Y' and DELETEDTRANSTATUS='P' and abbbranchcode='" & BrCode & "'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = Message & " Some ABB Deleted Transactions Are Not Approved At " & recTrans(1).Value & " branch . Day end is aborted..!"
        GoTo myerr
    End If


     '''''''''''''' Check any FORM15GH Tracking Details
  Set recTrans = objQuery.singlerecordset("FORM15GHTRACKINGDTLS", _
                "accno", "submitdate IS NOT NULL AND " & _
                "TO_DATE(TO_CHAR(SUBMITDATE,'dd-mon-yyyy'),'dd-mon-yyyy') = " & _
                " (select TO_DATE(TO_CHAR(applicationdate,'dd-mon-yyyy'),'dd-mon-yyyy') from " & _
                " GenApplicationDateMst where branchcode='" & BrCode & "') AND TRANSTATUS = 'P' " & _
                " AND status != 'D' AND branchcode = '" & BrCode & "' AND currencycode = 'INR'")
    If Not recTrans.EOF And Not recTrans.BOF Then
        Message = Message & " Some FORM15GH Tracking Details Are Not Approved  . Day end is aborted..!"
        GoTo myerr
    End If



''*********************************TM BRANCH DAYEND ***********************************
''
''    Set recTrans = objQuery.singlerecordset("TMTRNCALLMONEY", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Local Money Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNFXMONEY", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Foreign Money Open Transactions are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNFXMONEYCLOSE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''        If Not recTrans.EOF And Not recTrans.BOF Then
''            Message = "Some Foreign Money Close  Transactions are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''
''    Set recTrans = objQuery.singlerecordset("TMTRNCPPURCHASE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Commercial Paper Purchase Transactions are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''
''    Set recTrans = objQuery.singlerecordset("TMTRNCPSALE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Commercial Paper Sale Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSHAREPURCHASE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Share Purchase Transactions are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSHARESELL", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Share Sale Transactions are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNNONSLRPURCHASE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some NonSLR Purchase Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNNONSLRSALE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some NonSLR  Sale Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSLRPURCHASE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some SLR Purchase Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSLRSALE", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some  SLR Sale Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSLRREPO", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some SLR  Repo Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNSLRCONVERTION", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some SLR  Conversion Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNBOOKINGS", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Booking  Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNREALIZATION", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Realization Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRNREVERSAL", _
''                "accno", "transtatus='P' and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Reversal Transactions  are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMBROKERMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some  Broker Master Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMSHAREMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Share Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMTRUSTMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Trust Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMSECSLRMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Security SLR Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMSECNONSLRMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Security NonSLR Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMGENSECISSUERGOVTMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') ")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Issuer Govt Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMGENSECISSUEROTHERMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') ")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Issuer Other Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMCORRESPONDENTMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Correspondent Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMCOUNTERPARTYBANKMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some CounterParty Bank Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMCOUNTERPARTYOTHERMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some CounterParty Other Master Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMGROUPMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Group Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMCPCURWISECORRMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some CounterParty Currencywise Correspondent Master  Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If
''
''    Set recTrans = objQuery.singlerecordset("TMOURCURWISECORRMST", _
''                "transtatus", "(transtatus='P' or transtatus='M') and branchcode='" & BrCode & "'")
''    If Not recTrans.EOF And Not recTrans.BOF Then
''        Message = "Some Our CurrencyWise Correspondent Master Accounts are not approved. Day end is aborted..!"
''        GoTo myerr
''    End If

''******************************** TM BRANCH DAYEND ******************************************

      BranchDayEnd = "Completed"
Exit Function
myerr:
    If Message = "" Then
        BranchDayEnd = Err.Number & "    " & Err.Description
    Else
        BranchDayEnd = Message
    End If

End Function




Public Function BalanceSheet(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String)
                             
On Error GoTo ErrHand

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As String
Dim StrCondition As String
Dim pnlcheck As String
    
    AppDate = UCase(ApplicationDate)
    BrCode = UCase(BranchCode)
    UserId = UCase(UserId)
      
      
    Result = ProfitNLoss(BrCode, AppDate, UserId, Currency1)
    
    If Left(Result, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
    
    If Result = "" Then pnlcheck = "N"

        
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    RepNo = 1
                
       
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
    
    Result = "RepBalanceSheetTemp  " & "  nvl(max(nvl(repno,0)),0)+1"
    
    If Not recTemp.EOF And Not recTemp.BOF Then RepNo = recTemp(0)
    
    If ConsRepno > 0 Then RepNo = ConsRepno
    
    
'Code commented by Radhika on 3-dec-2007
'Reason: Performance Tuning
'    QryFlds = " distinct a.glcode,a.gldescription,b.moduleid," & _
'                " decode(b.glacctype,1,'Rs',2,'Ls',3,'Rs',4,'Ls',5,'Rs',6," & _
'                "'Ls',7,'Rs',8,'Ls',9,'Rs'),nvl(b.glcategory,'A'),to_number(" & _
'                " b.titleprintorder||b.printorder),nvl((Select ClosingBalance " & _
'                " from GenGldaybook b where applicationdate=" & _
'                " (Select Max(Applicationdate) from GenGlDayBook where " & _
'                " applicationdate<='" & AppDate & "'  and glcode=b.glcode" & _
'                " and currencycode='" & Currency1 & "' and branchcode='" & BrCode & _
'                "') and closingbalance is not null and branchcode='" & BrCode & "' " & _
'                " and c.glcode=b.glcode  and currencycode='" & Currency1 & "' ),0)"
'
'    QryTable = "GLOpenBalanceMst a,GenGlMastMst b, gengldaybook c, genglsheetmst d"
'
'    QryCondition = "  a.glcode = d.glcode " & _
'                    " and a.glcode=c.glcode and c.glcode=b.glcode " & _
'                    " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
'                    " a.openbaldate<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
'                    " and b.glacctype not in(3,4,5) and a.Currencycode='" & Currency1 & "'  and a.currencycode=c.currencycode" & _
'                    " and a.branchcode=c.branchcode  and d.branchcode=a.branchcode and a.glcode=d.glcode " & _
'                    " order by to_number(b.titleprintorder||b.printorder) "
    
    '' New code is
    QryFlds = " b.glcode,b.gldescription,b.moduleid," & _
                " decode(b.glacctype,1,'Rs',2,'Ls',3,'Rs',4,'Ls',5,'Rs',6," & _
                "'Ls',7,'Rs',8,'Ls',9,'Rs'),nvl(b.glcategory,'A'),to_number(" & _
                " b.titleprintorder||b.printorder),NVL(c.ClosingBalance,0)"
    
    QryTable = "GENGLDAYBOOK c, GENGLMASTMST b"
    
    'Code altered by Radhika on 17th June 2008
    'Reason: While fetching max(applicationdate) from Day book table, don't check for
    '        closingbalance <>0 condition.Because of it, query is returning previous
    '        transaction balance, when the last transaction closing balance is zero.
    
'    QryCondition = " c.branchcode='" & BrCode & "' and c.Currencycode='" & Currency1 & "'" & _
'        " AND (c.glcode,c.applicationdate) IN " & _
'        "( SELECT glcode,MAX(applicationdate) FROM GENGLDAYBOOK x " & _
'        " WHERE branchcode='" & BrCode & "' AND Currencycode='" & Currency1 & "'" & _
'        " AND applicationdate<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
'        " AND CLOSINGBALANCE IS NOT NULL AND CLOSINGBALANCE <> 0 " & _
'        " GROUP BY glcode) " & _
'        " AND c.glcode = b.glcode  AND  b.titlegl IS NOT NULL " & _
'        " AND b.glacctype NOT IN(3,4,5) ORDER BY TO_NUMBER(b.titleprintorder||b.printorder)"
    
    QryCondition = " c.branchcode='" & BrCode & "' and c.Currencycode='" & Currency1 & "'" & _
        " AND (c.glcode,c.applicationdate) IN " & _
        "( SELECT glcode,MAX(applicationdate) FROM GENGLDAYBOOK x " & _
        " WHERE branchcode='" & BrCode & "' AND Currencycode='" & Currency1 & "'" & _
        " AND applicationdate<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
        " GROUP BY glcode) " & _
        " AND c.glcode = b.glcode  AND  b.titlegl IS NOT NULL " & _
        " AND b.glacctype NOT IN(3,4,5) ORDER BY TO_NUMBER(b.titleprintorder||b.printorder)"
        
    'end of Code altered by Radhika on 17th June 2008
    
    ''''''' Query Gentranslog Table
    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
    
        
         '''' If mathcing records found
        If Not recTemp.EOF And Not recTemp.BOF Then
                   
                       
                ''''' Temp Table name
                StrTabName = "RepBalanceSheetTemp"
        
                ''''' Field names to temp table
                StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                    " Printorder,Amount,ApplicationDate,RepNo,UserId"
                '''' Formate record values into array
                ReDim DataArray(0, 4)
                StrMainString = ""
                Do While Not recTemp.EOF
                    
                    StrString = "'" & BrCode & "'"
                    For icnt = 0 To recTemp.Fields.Count - 1
                        StrString = StrString & ",'" & recTemp(icnt) & "'"
                    Next
                    StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                    recTemp.MoveNext
                Loop
                
                StrMainString = Mid(StrMainString, 2)
                DataArray(0, 0) = "I"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = CStr(StrFlds)
                DataArray(0, 3) = CStr(StrMainString)
                DataArray(0, 4) = ""
              
                ''''' Insert Records
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 1"
                    GoTo ErrHand
                End If
                
                '*****  Delete Zero Balance GL Code deatils *******
                
            QryCondition = " branchcode='" & BrCode & "' AND repno=" & RepNo & _
                " AND ApplicationDate='" & AppDate & "' and UserId='" & UserId & "'" & _
                " and nvl(Amount,0)=0"
                
                DataArray(0, 0) = "D"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = ""
                DataArray(0, 3) = ""
                DataArray(0, 4) = QryCondition
              
                Result = ""
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                Result = ""
                'This code was commented because, If no of rows deleted were = 0,
                'then component will throw an error
'                If Mid(Result, 1, 11) <> "Transaction" Then
'                    Result = Result & " 1.2"
'                    GoTo ErrHand
'                End If
                
                
                  QryFlds = " Distinct b.glcode,b.gldescription,b.moduleid," & _
                            " decode(b.glacctype,1,'Rs',2,'Ls',6, " & _
                            " 'Ls',7,'Rs',8,'Ls',9,'Rs'),'A',to_number( " & _
                            " b.titleprintorder||b.printorder),0"
                QryTable = " GenGlMastMst b "
                
                QryCondition = " b.glcode in (select a.abnormalgl from repbalancesheettemp b," & _
                                " genglmastmst a where abnormalgl Is Not Null And " & _
                                " a.glcode = b.glcode and repno=" & RepNo & ") and " & _
                                " b.titlegl is not null " & _
                                " and b.glacctype not in(3,4,5) and b.glcategory='D' order by " & _
                                " to_number(b.titleprintorder||b.printorder)"
                
                
                ''''''' Query GenGLMastMSt Table for Opposit GLS
                Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
                   
                   
                '''' If mathcing records found
                If Not recTemp.EOF And Not recTemp.BOF Then
                       ''''' Temp Table name
                    StrTabName = "RepBalanceSheetTemp"
            
                    ''''' Field names to temp table
                    StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                        " Printorder,Amount,ApplicationDate,RepNo,UserId"
                    '''' Formate record values into array
                    ReDim DataArray(0, 4)
                    StrMainString = ""
                    Do While Not recTemp.EOF
                        
                        StrString = "'" & BrCode & "'"
                        For icnt = 0 To recTemp.Fields.Count - 1
                            StrString = StrString & ",'" & recTemp(icnt) & "'"
                        Next
                        StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                        recTemp.MoveNext
                    Loop
                    
                    StrMainString = Mid(StrMainString, 2)
                    DataArray(0, 0) = "I"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = ""
                  
                    ''''' Insert Records
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                    
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 2"
                       ' GoTo ErrHand
                    End If
                    
                    StrTabName = "RepBalanceSheetTemp a"
                    StrFlds = "Amount "
                    StrMainString = "(select Amount from RepBalanceSheetTemp where glcode=" & _
                                    "(select glcode from genglmastmst where abnormalgl=a.glcode and repno=" & RepNo & _
                                    ") and amount>0 and category='Rs' and repno=" & RepNo & ")"
                                    
                     StrCondition = " glcode=(select b.abnormalgl from genglmastmst b," & _
                                    " RepBalanceSheetTemp c where c.glcode=b.abnormalgl and c.branchcode='" & BrCode & "' " & _
                                    " and c.glcode=a.glcode and repno=" & RepNo & " ) and Repno=" & RepNo & _
                                    " and moduleid not in('SB','CA','CC') and branchcode='" & BrCode & "'  and repno=" & RepNo
                                    
                    DataArray(0, 0) = "U"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = CStr(StrCondition)
              
                    ''''' Update Amount of abnormal GL
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 3"
                      '  GoTo ErrHand
                    Else
                    
                          StrTabName = "RepBalanceSheetTemp"
                          StrFlds = "Amount "
                          StrMainString = "0"
                          StrCondition = " glcode in(select Distinct b.glcode from GenGlMastMst b " & _
                                  " where b.glcode in (select a.glcode from repbalancesheettemp b, " & _
                                  " genglmastmst a where abnormalgl Is Not Null And " & _
                                  " a.glcode = b.glcode and repno=" & RepNo & " and normalbalance='DR' " & _
                                  " and b.amount>0 and b.branchcode='" & BrCode & "') and " & _
                                  " b.titlegl is not null and b.glacctype not in(3,4,5)) " & _
                                  " and moduleid not in('SB','CA','CC') and branchcode='" & BrCode & "' and repno=" & RepNo
                              
                          DataArray(0, 0) = "U"
                          DataArray(0, 1) = CStr(StrTabName)
                          DataArray(0, 2) = CStr(StrFlds)
                          DataArray(0, 3) = CStr(StrMainString)
                          DataArray(0, 4) = CStr(StrCondition)
                    
                          ''''' Update Amount of GL where it has abnormal amounts
                          Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                      
                          If Mid(Result, 1, 11) <> "Transaction" Then
                             Result = Result & StrCondition
                        '      GoTo ErrHand
                          End If
                    
                    End If
                End If
                
        
                '''''''' Updating Abnormal Gls on CR side
                
                QryFlds = " Distinct b.glcode,b.gldescription,b.moduleid," & _
                        " decode(b.glacctype,1,'Rs',2,'Ls',6," & _
                        "'Ls',7,'Rs',8,'Ls',9,'Rs'),'A',to_number( " & _
                        " b.titleprintorder||b.printorder),0 "
                
                QryTable = " GenGlMastMst b "
                
                QryCondition = " b.glcode in (select a.abnormalgl from repbalancesheettemp b," & _
                               " genglmastmst a where abnormalgl Is Not Null And " & _
                               " a.glcode = b.glcode and repno=" & RepNo & " and normalbalance='CR'" & _
                               " and b.amount<0) and  " & _
                               " b.titlegl is not null and b.glacctype not in(3,4,5) " & _
                               " and b.glcategory='D' order by " & _
                               " to_number(b.titleprintorder||b.printorder) "
                               
                
                
                   
                ''''''' Query GenGLMastMSt Table for Opposit GLS
                Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
                   
                   
                '''' If mathcing records found
                If Not recTemp.EOF And Not recTemp.BOF Then
                       ''''' Temp Table name
                    StrTabName = "RepBalanceSheetTemp"
            
                    ''''' Field names to temp table
                    StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                        " Printorder,Amount,ApplicationDate,RepNo,UserId"
                    '''' Formate record values into array
                    ReDim DataArray(0, 4)
                    StrMainString = ""
                    Do While Not recTemp.EOF
                        
                        StrString = "'" & BrCode & "'"
                        For icnt = 0 To recTemp.Fields.Count - 1
                            StrString = StrString & ",'" & recTemp(icnt) & "'"
                        Next
                        StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                        recTemp.MoveNext
                    Loop
                    
                    StrMainString = Mid(StrMainString, 2)
                    DataArray(0, 0) = "I"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = ""
                  
                    ''''' Insert Records
                 '   Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                    
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 5"
                     '   GoTo ErrHand
                    End If
                                
                    StrTabName = "RepBalanceSheetTemp a"
                    StrFlds = "Amount "
                    StrMainString = "(select Amount from RepBalanceSheetTemp where glcode=" & _
                                    "(select glcode from genglmastmst where abnormalgl=a.glcode and repno=" & RepNo & _
                                    ") and amount<0  and branchcode='" & BrCode & "' and  category='Ls' and repno=" & RepNo & ")"
                                    
                   StrCondition = " glcode=(select b.abnormalgl from genglmastmst b," & _
                                    " RepBalanceSheetTemp c where c.glcode=b.abnormalgl " & _
                                    " and c.glcode=a.glcode and c.branchcode='" & BrCode & "' and repno=" & _
                                    RepNo & " and c.branchcode='" & BrCode & "') and repno=" & RepNo & _
                                    " and branchcode='" & BrCode & "' and moduleid not in('SB','CA','CC')"
                    
                    DataArray(0, 0) = "U"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = CStr(StrCondition)
              
                    ''''' Update Amount of abnormal GL
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 6"
                       ' GoTo ErrHand
                    End If
                
                    StrTabName = "RepBalanceSheetTemp"
                    StrFlds = "Amount "
                    StrMainString = "0"
                    StrCondition = " glcode in(select Distinct b.glcode from GenGlMastMst b " & _
                            " where b.glcode in (select a.glcode from repbalancesheettemp b, " & _
                            " genglmastmst a where abnormalgl Is Not Null And " & _
                            " a.glcode = b.glcode and repno=" & RepNo & " and normalbalance='CR' " & _
                            " and b.amount<0 and b.branchcode='" & BrCode & "')  and " & _
                            " b.titlegl is not null and b.glacctype not in(3,4,5))" & _
                            " and moduleid not in('SB','CA','CC') and branchcode='" & BrCode & "'"
                        
                    DataArray(0, 0) = "U"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = CStr(StrCondition)
              
                    ''''' Update Amount of GL where it has abnormal amounts
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 7"
                    '    GoTo ErrHand
                    End If
                            
                End If
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''' Update abnormal gls of SB,CA,CC
                
                StrTabName = "RepBalanceSheetTemp a"
                   
                   
                   StrFlds = "Amount "
                   Dim stModule As String
                   For i = 1 To 3
                         
                        If i = 1 Then stModule = "SB"
                        If i = 2 Then stModule = "CA"
                        If i = 3 Then stModule = "CC"
                         
                        StrMainString = "nvl((select sum(AbnormalBal) from " & stModule & "abnormalbalance " & _
                                " where glcode=(select glcode from genglmastmst where " & _
                                " abnormalgl=a.glcode) and currencycode='" & Currency1 & "' and applicationdate=" & _
                                " (select max(applicationdate) from " & stModule & _
                                "abnormalbalance where applicationdate='" & AppDate & _
                                "' and branchcode='" & BrCode & "' and currencycode='" & Currency1 & "'" & _
                                " ) and branchcode='" & BrCode & "'),0) "
                
                        StrCondition = " glcode=(select distinct b.abnormalgl from " & _
                                " genglmastmst b, RepBalanceSheetTemp c where " & _
                                " c.glcode=b.abnormalgl and repno=" & RepNo & " and b.moduleid ='" & stModule & "' " & _
                                " and c.glcode=a.glcode and c.branchcode='" & BrCode & "' ) and repno=" & RepNo & _
                                " and moduleid ='" & stModule & "' and branchcode='" & BrCode & "' "
                                
                        DataArray(0, 0) = "U"
                        DataArray(0, 1) = CStr(StrTabName)
                        DataArray(0, 2) = CStr(StrFlds)
                        DataArray(0, 3) = CStr(StrMainString)
                        DataArray(0, 4) = CStr(StrCondition)
              
                        ''''' Update Amount of abnormal GL
                        Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                        'If Mid(Result, 1, 11) <> "Transaction" Then
                          '  Result = Result & " 28"
                         '   GoTo ErrHand
                        'End If
                    
                        StrMainString = "amount+(-1*" & _
                                        "nvl((select sum(AbnormalBal) from " & _
                                        stModule & "abnormalbalance b,repbalancesheettemp a " & _
                                        " where b.glcode=(select glcode from genglmastmst " & _
                                        " where abnormalgl=a.glcode) and b.branchcode='" & BrCode & "' and  b.currencycode='" & Currency1 & "' and " & _
                                        " a.branchcode=b.branchcode and b.applicationdate=" & _
                                        " (select max(applicationdate) from " & stModule & "abnormalbalance where applicationdate='" & AppDate & _
                                        "' and branchcode='" & BrCode & "' and currencycode='" & Currency1 & "')" & _
                                        " and repno=" & RepNo & " ),0)) "
                                        
                        StrCondition = " glcode=( select glcode from genglmastmst where " & _
                                        " abnormalgl=( select glcode from repbalancesheettemp a " & _
                                        " where glcode=(select distinct b.abnormalgl from " & _
                                        " genglmastmst b, RepBalanceSheetTemp c" & _
                                        " where c.glcode=b.abnormalgl and repno=" & RepNo & _
                                        " and b.moduleid ='" & stModule & "' " & _
                                        " and c.glcode=a.glcode and c.branchcode='" & BrCode & "') " & _
                                        " and repno=" & RepNo & " and moduleid ='" & stModule & _
                                        "' and branchcode='" & BrCode & "') and a.glcode=glcode" & _
                                        " and branchcode='" & BrCode & "') and branchcode='" & BrCode & _
                                        "' and repno=" & RepNo
    
                        
                        DataArray(0, 0) = "U"
                        DataArray(0, 1) = CStr(StrTabName)
                        DataArray(0, 2) = CStr(StrFlds)
                        DataArray(0, 3) = CStr(StrMainString)
                        DataArray(0, 4) = CStr(StrCondition)
              
                        ''''' Update Amount of abnormal GL
                        Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                        If Mid(Result, 1, 11) <> "Transaction" Then
                           Result = Result & StrMainString & "  " & StrCondition
                          '  GoTo ErrHand
                        End If
                    
                    Next
     
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                
                
                '''''' Inserting Sub Total GLS and Title GLs
                
                QryFlds = " distinct a.glcode,a.gldescription,a.moduleid," & _
                        " decode(a.glacctype,1,'Rs',2,'Ls',3,'Rs',4,'Ls',5,'Rs',6," & _
                        "'Ls',7,'Rs',8,'Ls',9,'Rs'),nvl(a.glcategory,'A'),to_number(" & _
                        " a.titleprintorder||a.printorder)"
                
                QryTable = "GenGlMastMst a"
      
                '''''' Query condition
                QryCondition = " a.glacctype not in(3,4,5 ) and " & _
                                "( glcategory='C' OR glcategory='B') " & _
                                " Order By To_Number(" & _
                                " a.titleprintorder||a.printorder)"
               
                ''''''' Query GenGLMastMSt Table for titles and sub totals
                Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
                   
                '''' If mathcing records found
                If Not recTemp.EOF And Not recTemp.BOF Then
                       
                       
                    ''''' Temp Table name
                    StrTabName = "RepBalanceSheetTemp"
        
                    ''''' Field names to temp table
                    StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                        " Printorder,ApplicationDate,RepNo,UserId"
                    '''' Formate record values into array
                    ReDim DataArray(0, 4)
                    StrMainString = ""
                    Do While Not recTemp.EOF
                    
                        StrString = "'" & BrCode & "'"
                        For icnt = 0 To recTemp.Fields.Count - 1
                            StrString = StrString & ",'" & recTemp(icnt) & "'"
                        Next
                        StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                        recTemp.MoveNext
                    Loop
                
                    StrMainString = Mid(StrMainString, 2)
                    DataArray(0, 0) = "I"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = ""
              
                    ''''' Insert Records
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 8"
                        GoTo ErrHand
                    End If
                End If
                   
                ''''''' updation of Subtotals to Subtotal GLS
            
                QryFlds = "b.subtotalatgl,nvl(sum(nvl(a.amount,0)),0)"
                
                ''''' Query Tables
                QryTable = "RepBalanceSheetTemp a,GenGlMastMst b"
      
                '''''' Query condition
                QryCondition = "a.glcode = b.glcode and b.subtotalatgl is not null " & _
                             " and a.repno=" & RepNo & " and a.branchcode='" & BrCode & "' group by b.subtotalatgl "
                
                
                Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
           
                       
                    ''''' Temp Table name
                    StrTabName = "RepBalanceSheetTemp"
        
                '''' Formate record values into array
                rcnt = 0
                StrUpCondition = ""
                StrMainString = ""
                StrFlds = "Amount"
                
                '''' If mathcing records found
              
              If Not recTemp.EOF And Not recTemp.BOF Then
                Do While Not recTemp.EOF
                    StrMainString = StrMainString & "|" & recTemp(1)
                    StrUpCondition = StrUpCondition & "|" & "glcode='" & recTemp(0) & _
                                      "' and branchcode='" & BrCode & "' and repno=" & RepNo
                    rcnt = rcnt + 1
                    recTemp.MoveNext
                Loop
                StrUpCondition = Mid(StrUpCondition, 2)
                StrMainString = Mid(StrMainString, 2)
                DataArray(0, 0) = "U"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = CStr(StrFlds)
                DataArray(0, 3) = CStr(StrMainString)
                DataArray(0, 4) = CStr(StrUpCondition)
              
                '''''' update closing balances of effected gls
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & "  " & StrTabName & "   " & StrFlds & "   " & StrMainString & "    " & StrUpCondition
                    Result = Result & "9"
                    GoTo ErrHand
                End If
              
              End If
                
                
                    ''''''' Inserting Profit and Loss
                    
                If pnlcheck <> "N" Then
                    
                    'code modified by Radhika on 30 aug 2008
                    'Set recTemp = objfetch.singlerecordset("RepProfitNLossTemp", "nvl(max(nvl(repno,0)),0)")
                    Set recTemp = objfetch.singlerecordset("RepProfitNLossTemp", "nvl(max(nvl(repno,0)),0)", _
                    " branchcode='" & Trim(BrCode) & "'")
                    'end of code modified by Radhika on 30 aug 2008
                    PlRepNo = recTemp(0)
                    
                    QryFlds = "glcode,narration,category,(nvl(amount,0) *-1)"
                    ''''' Query Tables
                    QryTable = "RepProfitNLossTemp"
                    
                    
                    
                    '''''' Query condition
                    QryCondition = "titleyn='X' and repno=" & PlRepNo & " and amount <> 0" & _
                    " and branchcode='" & Trim(BrCode) & "'"
                    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
                       
                
                    '''' Formate record values into array
                    ReDim DataArray(0, 4)
                    rcnt = reccount + 1
                    StrMainString = ""
                    Do While Not recTemp.EOF
                        
                        StrString = "'" & BrCode & "'"
                        For icnt = 0 To recTemp.Fields.Count - 1
                            StrString = StrString & ",'" & recTemp(icnt) & "'"
                        Next
                        StrMainString = StrMainString & "|" & StrString & ",'X', 999998 ,'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                        rcnt = rcnt + 1
                        recTemp.MoveNext
                    Loop
                    
                    StrTabName = "RepBalanceSheetTemp"
                    StrFlds = "branchcode,glcode,narration,category,amount," & _
                        "titleyn,printorder,applicationdate,repno,userid"
                    StrMainString = Mid(StrMainString, 2)
                    
                    DataArray(0, 0) = "I"
                    DataArray(0, 1) = CStr(StrTabName)
                    DataArray(0, 2) = CStr(StrFlds)
                    DataArray(0, 3) = CStr(StrMainString)
                    DataArray(0, 4) = ""
                  
                    ''''' Insert Records
                    Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                    
                    If Mid(Result, 1, 11) <> "Transaction" Then
                        Result = Result & " 10"
                        GoTo ErrHand
                    End If
                End If
                        
                
            '''''''' Updation of Grand totals
        
            QryFlds = "category,nvl(sum(nvl(amount,0)),0)"
            ''''' Query Tables
            QryTable = "RepBalanceSheetTemp"
  
            '''''' Query condition
            QryCondition = "(titleyn='C' or titleyn='X') and repno=" & RepNo & " and branchcode='" & BrCode & "'  group by category "
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
        
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            rcnt = reccount + 1
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'G',9999,'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            
            StrTabName = "RepBalanceSheetTemp"
            StrFlds = "branchcode,category,amount," & _
                        "titleyn,printorder,applicationdate,repno,userid"
            StrMainString = Mid(StrMainString, 2)
            
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 11"
                GoTo ErrHand
            End If
            
            'New code added by Radhika on 21-sep-2007
            'Reason: To delete zero balance GL codes, if exists
            StrTabName = "RepBalanceSheetTemp"
            QryCondition = " branchcode='" & BrCode & "' and repno=" & RepNo & _
            " AND (amount =0 or amount is null) and (titleyn='A' or titleyn='C')"
            
            Set recTemp = objfetch.singlerecordset(CStr(StrTabName), _
                "glcode,amount", CStr(QryCondition))
            If recTemp.EOF = False And recTemp.BOF = False Then
                DataArray(0, 0) = "D"
                DataArray(0, 1) = StrTabName
                DataArray(0, 2) = ""
                DataArray(0, 3) = ""
                DataArray(0, 4) = QryCondition
                
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 12"
                    GoTo ErrHand
                End If
            End If
            
            'Update Titlegl for all transaction GL's
            QryCondition = " branchcode='" & BrCode & "' and repno=" & RepNo & " and TITLEYN='A'"
              Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", _
                "glcode", CStr(QryCondition))
        If recTemp.EOF = False And recTemp.BOF = False Then
                  
            DataArray(0, 0) = "U"
            DataArray(0, 1) = "RepBalanceSheetTemp a"
            DataArray(0, 2) = "TITLEYN,TITLEGL"
            DataArray(0, 3) = "'A'~(SELECT titlegl FROM GENGLMASTMST WHERE glcode=a.glcode)"
            DataArray(0, 4) = QryCondition
            
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 13"
                GoTo ErrHand
            End If
            End If
            Set recTemp = Nothing
            'New code added by Radhika on 02-oct-2007
            'Reason: To delete Title GL's for which there is no transaction GL's exist
            StrTabName = "RepBalanceSheetTemp a"
            QryCondition = "branchcode='" & BrCode & "' AND repno=" & RepNo & _
                " AND titlegl IS NULL AND titleyn='B'" & _
                " AND 0=(SELECT DISTINCT NVL(COUNT(*),0) FROM REPBALANCESHEETTEMP b" & _
                " WHERE branchcode='" & BrCode & "' AND repno=" & RepNo & " AND b.titlegl=a.glcode)"

            Set recTemp = objfetch.singlerecordset(CStr(StrTabName), _
                "glcode", CStr(QryCondition))
            If recTemp.EOF = False And recTemp.BOF = False Then
                DataArray(0, 0) = "D"
                DataArray(0, 1) = "RepBalanceSheetTemp a"
                DataArray(0, 2) = ""
                DataArray(0, 3) = ""
                DataArray(0, 4) = QryCondition

                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")

                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 14"
                    GoTo ErrHand
                End If
            End If
            Set recTemp = Nothing
            
         Else
             Result = ""
        End If
    
   
          
    BalanceSheet = Result
    
Exit Function

ErrHand:
          
    If Err.Number <> 0 Then
       BalanceSheet = "Error: " & Result & "   " & Err.Number & Err.Description
       
    Else
       BalanceSheet = "Error: " & Result
    End If
    
End Function

Public Function ContraBalanceSheet(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String)
                             
On Error GoTo ErrHand

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As String
Dim StrCondition As String
    
    AppDate = UCase(ApplicationDate)
    BrCode = UCase(BranchCode)
    UserId = UCase(UserId)
      
       
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    
                
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
    
    RepNo = recTemp(0)
    
    QryFlds = " distinct a.glcode,a.gldescription,b.moduleid," & _
                " decode(b.moduleid,'GL','Ls','Rs')," & _
                "nvl(b.glcategory,'A'),to_number(b.glacctype||" & _
                " b.titleprintorder||b.printorder),nvl((Select ClosingBalance " & _
                " from GenGldaybook b where applicationdate=" & _
                " (Select Max(Applicationdate) from GenGlDayBook where " & _
                " applicationdate<='" & AppDate & "'  and glcode=b.glcode " & _
                " and currencycode='" & Currency1 & "' ) and closingbalance is not null " & _
                " and c.glcode=b.glcode  and currencycode='" & Currency1 & "' ),0)"
    
    QryTable = "GLOpenBalanceMst a,GenGlMastMst b, gengldaybook c , genglsheetmst d"
    
    QryCondition = " a.BranchCode = d.BranchCode And a.glcode = b.glcode " & _
                " and a.glcode=c.glcode and c.glcode=b.glcode " & _
                " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
                " openbaldate<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
                " and a.branchcode=c.branchcode and b.glacctype=5 and a.currencycode=c.currencycode and a.glcode=d.glcode  " & _
                " order by to_number(b.glacctype||b.titleprintorder||b.printorder)"
    
    
    ''''''' Query Gentranslog Table
    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
    
        
         '''' If mathcing records found
        If Not recTemp.EOF And Not recTemp.BOF Then
                   
                   
            ''''' Temp Table name
            StrTabName = "RepBalanceSheetTemp"
    
            ''''' Field names to temp table
            StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                " Printorder,Amount,ApplicationDate,RepNo,UserId"
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                recTemp.MoveNext
            Loop
            
            StrMainString = Mid(StrMainString, 2)
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 1"
                GoTo ErrHand
            End If
            
            
            QryFlds = " Distinct b.glcode,b.gldescription,b.moduleid," & _
                    " decode(b.moduleid,'GL','Ls','Rs')," & _
                    " 'A',to_number(b.glacctype|| " & _
                    " b.titleprintorder||b.printorder),0 "
            
            QryTable = " GenGlMastMst b "
            
            QryCondition = " b.glcode in (select a.abnormalgl from repbalancesheettemp b," & _
                           " genglmastmst a where abnormalgl Is Not Null And " & _
                           " a.glcode = b.glcode and repno=" & RepNo & " and normalbalance='DR'" & _
                           " and b.amount>0)  and  " & _
                           " b.titlegl is not null and b.glacctype=5 " & _
                           " and b.glcategory='D' order by " & _
                           " to_number(b.glacctype||b.titleprintorder||b.printorder)"
            
            
            ''''''' Query GenGLMastMSt Table for Opposit GLS
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
               
               
            '''' If mathcing records found
            If Not recTemp.EOF And Not recTemp.BOF Then
                   ''''' Temp Table name
                StrTabName = "RepBalanceSheetTemp"
        
                ''''' Field names to temp table
                StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                    " Printorder,Amount,ApplicationDate,RepNo,UserId"
                '''' Formate record values into array
                ReDim DataArray(0, 4)
                StrMainString = ""
                Do While Not recTemp.EOF
                    
                    StrString = "'" & BrCode & "'"
                    For icnt = 0 To recTemp.Fields.Count - 1
                        StrString = StrString & ",'" & recTemp(icnt) & "'"
                    Next
                    StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                    recTemp.MoveNext
                Loop
                
                StrMainString = Mid(StrMainString, 2)
                DataArray(0, 0) = "I"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = CStr(StrFlds)
                DataArray(0, 3) = CStr(StrMainString)
                DataArray(0, 4) = ""
              
                ''''' Insert Records
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 2"
                    GoTo ErrHand
                End If
            End If
            
    

            
            '''''' Inserting Sub Total GLS and Title GLs
            
            QryFlds = " distinct a.glcode,a.gldescription,a.moduleid," & _
                    " decode(a.moduleid,'GL','Ls','Rs')," & _
                    "nvl(a.glcategory,'A'),to_number(a.glacctype||" & _
                    " a.titleprintorder||a.printorder)"
            
            QryTable = "GenGlMastMst a"
  
            '''''' Query condition
            QryCondition = " a.glacctype =5 and " & _
                            "( glcategory='C' OR glcategory='B') " & _
                            " Order By To_Number(a.glacctype||" & _
                            " a.titleprintorder||a.printorder)"
           
            ''''''' Query GenGLMastMSt Table for titles and sub totals
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
               
            '''' If mathcing records found
            If Not recTemp.EOF And Not recTemp.BOF Then
                   
                   
                ''''' Temp Table name
                StrTabName = "RepBalanceSheetTemp"
    
                ''''' Field names to temp table
                StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                    " Printorder,ApplicationDate,RepNo,UserId"
                '''' Formate record values into array
                ReDim DataArray(0, 4)
                StrMainString = ""
                Do While Not recTemp.EOF
                
                    StrString = "'" & BrCode & "'"
                    For icnt = 0 To recTemp.Fields.Count - 1
                        StrString = StrString & ",'" & recTemp(icnt) & "'"
                    Next
                    StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                    recTemp.MoveNext
                Loop
            
                StrMainString = Mid(StrMainString, 2)
                DataArray(0, 0) = "I"
                DataArray(0, 1) = CStr(StrTabName)
                DataArray(0, 2) = CStr(StrFlds)
                DataArray(0, 3) = CStr(StrMainString)
                DataArray(0, 4) = ""
          
                ''''' Insert Records
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 8"
                    GoTo ErrHand
                End If
            End If
               
            ''''''' updation of Subtotals to Subtotal GLS
        
            QryFlds = "b.subtotalatgl,nvl(sum(nvl(a.amount,0)),0)"
            
            ''''' Query Tables
            QryTable = "RepBalanceSheetTemp a,GenGlMastMst b"
  
            '''''' Query condition
            QryCondition = "a.glcode = b.glcode and b.subtotalatgl is not null " & _
                         " and a.repno=" & RepNo & " group by b.subtotalatgl "
            
            
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
          
            
            
                   
                   
                ''''' Temp Table name
                StrTabName = "RepBalanceSheetTemp"
    
            '''' Formate record values into array
            rcnt = 0
            StrUpCondition = ""
            StrMainString = ""
            StrFlds = "Amount"
            
            '''' If mathcing records found
            
            If Not recTemp.EOF And Not recTemp.BOF Then
              Do While Not recTemp.EOF
                  StrMainString = StrMainString & "|" & recTemp(1)
                  StrUpCondition = StrUpCondition & "|" & "glcode='" & recTemp(0) & "' and repno=" & RepNo
                  rcnt = rcnt + 1
                  recTemp.MoveNext
              Loop
              StrUpCondition = Mid(StrUpCondition, 2)
              StrMainString = Mid(StrMainString, 2)
              DataArray(0, 0) = "U"
              DataArray(0, 1) = CStr(StrTabName)
              DataArray(0, 2) = CStr(StrFlds)
              DataArray(0, 3) = CStr(StrMainString)
              DataArray(0, 4) = CStr(StrUpCondition)
            
              '''''' update closing balances of effected gls
              Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
          
              If Mid(Result, 1, 11) <> "Transaction" Then
                  Result = Result & "  " & StrTabName & "   " & StrFlds & "   " & StrMainString & "    " & StrUpCondition
                  Result = Result & "9"
                  GoTo ErrHand
              End If
            
            End If
                
            
'            StrTabName = "RepBalanceSheetTemp"
'            StrFlds = "branchcode,glcode,narration,category,amount," & _
'                "titleyn,printorder,applicationdate,repno,userid"
'            StrMainString = Mid(StrMainString, 2)
'
'            DataArray(0, 0) = "I"
'            DataArray(0, 1) = CStr(StrTabName)
'            DataArray(0, 2) = CStr(StrFlds)
'            DataArray(0, 3) = CStr(StrMainString)
'            DataArray(0, 4) = ""
'
'            ''''' Insert Records
'            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
'
'            If Mid(Result, 1, 11) <> "Transaction" Then
'                Result = Result & " 10"
'                GoTo ErrHand
'            End If
    
                
                
            '''''''' Updation of Grand totals
        
            QryFlds = "category,nvl(sum(nvl(amount,0)),0)"
            ''''' Query Tables
            QryTable = "RepBalanceSheetTemp"
  
            '''''' Query condition
            QryCondition = "(titleyn='C' or titleyn='X') and repno=" & RepNo & " group by category "
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
        
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            rcnt = reccount + 1
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'G',9999,'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            
            StrTabName = "RepBalanceSheetTemp"
            StrFlds = "branchcode,category,amount," & _
                        "titleyn,printorder,applicationdate,repno,userid"
            StrMainString = Mid(StrMainString, 2)
            
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 11"
                GoTo ErrHand
            End If
    
        
        End If
            
       
    ContraBalanceSheet = Result
   
Exit Function

ErrHand:
  
    
    If Err.Number <> 0 Then
       ContraBalanceSheet = Result & "   " & Err.Number & Err.Description
    Else
       ContraBalanceSheet = Result
    End If
    
End Function


Public Function GL(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String)
                             
On Error GoTo ErrHand

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As String
Dim StrCondition As String
    
    AppDate = UCase(ApplicationDate)
    BrCode = UCase(BranchCode)
    UserId = UCase(UserId)
      
    'Set ObjContext = GetObjectContext
    ''''' Creating Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    
                
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
    
    Result = "RepBalanceSheetTemp  " & "  nvl(max(nvl(repno,0)),0)+1"
    RepNo = recTemp(0)
    If ConsRepno > 0 Then RepNo = ConsRepno
    
    QryFlds = " distinct a.glcode,a.gldescription,b.moduleid," & _
                " decode(b.glacctype,1,'Rs',2,'Ls',3,'Rs',4,'Ls',5,'Rs',6," & _
                "'Ls',7,'Rs',8,'Ls',9,'Rs'),nvl(b.glcategory,'A'),to_number(a.glcode),nvl((Select ClosingBalance " & _
                " from GenGldaybook b where applicationdate=" & _
                " (Select Max(Applicationdate) from GenGlDayBook where " & _
                " applicationdate<='" & AppDate & "'  and glcode=b.glcode" & _
                " and currencycode='" & Currency1 & "' and branchcode='" & BrCode & "') and closingbalance is not null " & _
                " and c.glcode=b.glcode  and currencycode='" & Currency1 & "' and branchcode='" & BrCode & "' ),0)"
    
    QryTable = "GLOpenBalanceMst a,GenGlMastMst b, gengldaybook c, genglsheetmst d"
    
    'Code commented and modified by Radhika on 12 sep 2008
'    QryCondition = " a.glcode = d.glcode " & _
'                    " and a.glcode=c.glcode and c.glcode=b.glcode " & _
'                    " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
'                    " to_date(openbaldate,'dd-MON-yyyy')<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
'                    " and  a.Currencycode='" & Currency1 & "'  and a.currencycode=c.currencycode" & _
'                    " and a.glcode=d.glcode and d.branchcode=a.branchcode " & _
'                    " order by to_number(a.glcode) "
    
    QryCondition = " a.glcode = d.glcode " & _
                    " and a.glcode=c.glcode and c.glcode=b.glcode " & _
                    " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
                    " openbaldate <='" & AppDate & "' " & _
                    " and  a.Currencycode='" & Currency1 & "'  and a.currencycode=c.currencycode" & _
                    " and a.glcode=d.glcode and d.branchcode=a.branchcode " & _
                    " order by to_number(a.glcode) "
    'end of Code corrections done by Radhika on 12 sep 2008
      
    Result = QryFlds & "    " & QryTable & "       " & QryCondition
    
    ''''''' Query Gentranslog Table
    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
    
        
         '''' If mathcing records found
        If Not recTemp.EOF And Not recTemp.BOF Then
                   
                   
            ''''' Temp Table name
            StrTabName = "RepBalanceSheetTemp"
    
            ''''' Field names to temp table
            StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                " Printorder,Amount,ApplicationDate,RepNo,UserId"
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                recTemp.MoveNext
            Loop
            
            StrMainString = Mid(StrMainString, 2)
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 1"
                GoTo ErrHand
            End If
            
             '''''''' Updation of Grand totals
        
            QryFlds = "category,nvl(sum(nvl(amount,0)),0)"
            ''''' Query Tables
            QryTable = "RepBalanceSheetTemp"
  
            '''''' Query condition
            QryCondition = "repno=" & RepNo & " group by category "
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
            
         
        
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            rcnt = reccount + 1
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'G',9999,'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            
            
            StrTabName = "RepBalanceSheetTemp"
            StrFlds = "branchcode,category,amount," & _
                        "titleyn,printorder,applicationdate,repno,userid"
            StrMainString = Mid(StrMainString, 2)
            
                        
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 11"
                GoTo ErrHand
            End If
    
            'New code added by Radhika on 21-sep-2007
            'Reason: To delete zero balance GL codes, if exists
            StrTabName = "RepBalanceSheetTemp"
            QryCondition = " branchcode='" & BrCode & "' and repno=" & RepNo & " AND amount =0"
            
            Set recTemp = objfetch.singlerecordset(CStr(StrTabName), _
                "glcode,amount", CStr(QryCondition))
            If recTemp.EOF = False And recTemp.BOF = False Then
                DataArray(0, 0) = "D"
                DataArray(0, 1) = StrTabName
                DataArray(0, 2) = ""
                DataArray(0, 3) = ""
                DataArray(0, 4) = QryCondition
                
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 12"
                    GoTo ErrHand
                End If
            End If
                  
        End If
            
    GL = Result & StrMainString & QryCondition & " chandana'" & recTemp.RecordCount
   Set recTemp = Nothing
   
Exit Function

ErrHand:
  
    
    If Err.Number <> 0 Then
        GL = Result & "   " & Err.Number & Err.Description
    Else
        GL = Result & "error:"
    End If
    
End Function

Public Function GLConBr(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String)
                             
On Error GoTo ErrHand

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As String
Dim StrCondition As String
    
    AppDate = UCase(ApplicationDate)
    BrCode = UCase(BranchCode)
    UserId = UCase(UserId)
      
    'Set ObjContext = GetObjectContext
    ''''' Creating Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    
                
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
    
    Result = "RepBalanceSheetTemp  " & "  nvl(max(nvl(repno,0)),0)+1"
    RepNo = recTemp(0)
    If ConsRepno > 0 Then RepNo = ConsRepno
    
    QryFlds = " distinct a.glcode,a.gldescription,b.moduleid," & _
                " decode(b.glacctype,1,'Rs',2,'Ls',3,'Rs',4,'Ls',5,'Rs',6," & _
                "'Ls',7,'Rs',8,'Ls',9,'Rs'),nvl(b.glcategory,'A'),to_number(a.glcode),nvl((Select ClosingBalance " & _
                " from GenGldaybook b where applicationdate=" & _
                " (Select Max(Applicationdate) from GenGlDayBook where " & _
                " applicationdate<='" & AppDate & "'  and glcode=b.glcode" & _
                " and currencycode='" & Currency1 & "' and branchcode='" & BrCode & "') and closingbalance is not null " & _
                " and c.glcode=b.glcode  and currencycode='" & Currency1 & "' and branchcode='" & BrCode & "' ),0)"
    
    QryTable = "GLOpenBalanceMst a,GenGlMastMst b, gengldaybook c, genglsheetmst d"
    
    'Code commented and modified by Radhika on 12 sep 2008
'    QryCondition = " a.glcode = d.glcode " & _
'                    " and a.glcode=c.glcode and c.glcode=b.glcode " & _
'                    " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
'                    " to_date(openbaldate,'dd-MON-yyyy')<=to_date('" & AppDate & "','dd-MON-yyyy') " & _
'                    " and  a.Currencycode='" & Currency1 & "'  and a.currencycode=c.currencycode" & _
'                    " and a.glcode=d.glcode and d.branchcode=a.branchcode " & _
'                    " order by to_number(a.glcode) "
    
    QryCondition = " a.glcode = d.glcode " & _
                    " and a.glcode=c.glcode and c.glcode=b.glcode " & _
                    " and a.branchcode='" & BrCode & "' and  b.titlegl is not null and " & _
                    " openbaldate <='" & AppDate & "' " & _
                    " and  a.Currencycode='" & Currency1 & "'  and a.currencycode=c.currencycode" & _
                    " and a.glcode=d.glcode and d.branchcode=a.branchcode " & _
                    " order by to_number(a.glcode) "
    'end of Code corrections done by Radhika on 12 sep 2008
      
    Result = QryFlds & "    " & QryTable & "       " & QryCondition
    
    ''''''' Query Gentranslog Table
    Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
    
        
         '''' If mathcing records found
        If Not recTemp.EOF And Not recTemp.BOF Then
                   
                   
            ''''' Temp Table name
            StrTabName = "RepBalanceSheetTemp"
    
            ''''' Field names to temp table
            StrFlds = "BranchCode,GlCode,Narration,Moduleid,Category,TitleYN," & _
                " Printorder,Amount,ApplicationDate,RepNo,UserId"
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                recTemp.MoveNext
            Loop
            
            StrMainString = Mid(StrMainString, 2)
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 1"
                GoTo ErrHand
            End If
            
             '''''''' Updation of Grand totals
        
            QryFlds = "category,nvl(sum(nvl(amount,0)),0)"
            ''''' Query Tables
            QryTable = "RepBalanceSheetTemp"
  
            '''''' Query condition
            QryCondition = "repno=" & RepNo & " AND titleyn = 'A' and BRANCHCODE='" & BrCode & "' group by category "
            Set recTemp = objfetch.singlerecordset(CStr(QryTable), CStr(QryFlds), CStr(QryCondition))
                        
        
            '''' Formate record values into array
            ReDim DataArray(0, 4)
            rcnt = reccount + 1
            StrMainString = ""
            Do While Not recTemp.EOF
                
                StrString = "'" & BrCode & "'"
                For icnt = 0 To recTemp.Fields.Count - 1
                    StrString = StrString & ",'" & recTemp(icnt) & "'"
                Next
                StrMainString = StrMainString & "|" & StrString & ",'G',9999,'" & AppDate & "'," & RepNo & ",'" & UserId & "'"
                rcnt = rcnt + 1
                recTemp.MoveNext
            Loop
            
            
            StrTabName = "RepBalanceSheetTemp"
            StrFlds = "branchcode,category,amount," & _
                        "titleyn,printorder,applicationdate,repno,userid"
            StrMainString = Mid(StrMainString, 2)
            
                        
            DataArray(0, 0) = "I"
            DataArray(0, 1) = CStr(StrTabName)
            DataArray(0, 2) = CStr(StrFlds)
            DataArray(0, 3) = CStr(StrMainString)
            DataArray(0, 4) = ""
          
            ''''' Insert Records
            Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
            
            If Mid(Result, 1, 11) <> "Transaction" Then
                Result = Result & " 11"
                GoTo ErrHand
            End If
    
            'New code added by Radhika on 21-sep-2007
            'Reason: To delete zero balance GL codes, if exists
            StrTabName = "RepBalanceSheetTemp"
            QryCondition = " branchcode='" & BrCode & "' and repno=" & RepNo & " AND amount =0"
            
            Set recTemp = objfetch.singlerecordset(CStr(StrTabName), _
                "glcode,amount", CStr(QryCondition))
            If recTemp.EOF = False And recTemp.BOF = False Then
                DataArray(0, 0) = "D"
                DataArray(0, 1) = StrTabName
                DataArray(0, 2) = ""
                DataArray(0, 3) = ""
                DataArray(0, 4) = QryCondition
                
                Result = objMstTrans.DataTransactions(DataArray, , , , , "N")
                
                If Mid(Result, 1, 11) <> "Transaction" Then
                    Result = Result & " 12"
                    GoTo ErrHand
                End If
            End If
                  
        End If
            
    GLConBr = Result & StrMainString & QryCondition & " chandana'" & recTemp.RecordCount
   Set recTemp = Nothing
   
Exit Function

ErrHand:
  
    
    If Err.Number <> 0 Then
        GLConBr = Result & "   " & Err.Number & Err.Description
    Else
        GLConBr = Result & "error:"
    End If
    
End Function

Public Function ConsolidatedBalanceSheet(ApplicationDate As String, UserId As String, _
                             Currency1 As String)

                           
On Error Resume Next

Dim StrUpCondition As String
Dim StrMainString As String
Dim StrValues()
Dim StrTabName As String
Dim StrFlds As String
Dim QryFlds As String
Dim QryCondition As String
Dim QryTable As String
Dim Result As String

Dim AppDate As String
Dim BrCode As String
Dim RepNo As String
Dim StrCondition As String
Dim pnlcheck As String
    ReDim DataArray(0, 4)
    AppDate = UCase(ApplicationDate)
    UserId = UCase(UserId)
    
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recBranch = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    
    
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
                   
    RepNo = recTemp(0)
    ConsRepno = RepNo
    
    'Code commented and corrected by Radhika on 30 Aug 2008
    'Reason: To get branch codes which are really implemented
    'Set recBranch = objfetch.singlerecordset("genbankbranchmst", "branchcode", _
    "status='R' order by branchcode")
    
    Set recBranch = objfetch.singlerecordset("GENBANKBRANCHMST a,GENBRANCHPMT b", _
    " a.branchcode", " a.status='R' and BRANCHTYPE<>'HO' and a.branchcode=b.branchcode order by a.branchcode")
       
    If Not recBranch.EOF And Not recBranch.BOF Then
        Do While Not recBranch.EOF
        
            Result = BalanceSheet(recBranch(0), AppDate, UserId, Currency1)
            If Mid(Result, 1, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
            
            recBranch.MoveNext
        Loop
    Else
        Result = "No Branch Found..."
        GoTo ErrHand
    End If
    
       ConsolidatedBalanceSheet = "Transaction Successful."
    Exit Function

ErrHand:
    
    If Err.Number <> 0 Then
       ConsolidatedBalanceSheet = Err.Number & Err.Description
    Else
       ConsolidatedBalanceSheet = Result
    End If
    
End Function

Public Function BalanceSheetExtCntr(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String)

                           
On Error Resume Next

Dim Result As String
Dim AppDate As String
Dim RepNo As String

    ReDim DataArray(0, 4)
    AppDate = UCase(ApplicationDate)
    UserId = UCase(UserId)
    
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recBranch = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
                   
    RepNo = recTemp(0)
    ConsRepno = RepNo
    
    'Here we are joining both branch and its param tables, to get branch codes which
    'are really implemented
    Set recBranch = objfetch.singlerecordset("GENBANKBRANCHMST a,GENBRANCHPMT b", _
    "DISTINCT a.branchcode", _
    "(a.IMMHIGHLEVELBRCODE='" & Trim(BranchCode) & "' OR a.branchcode='" & Trim(BranchCode) & "') " & _
    " AND a.status='R' and a.branchcode=b.branchcode order by a.branchcode")
       
    If Not recBranch.EOF And Not recBranch.BOF Then
        Do While Not recBranch.EOF
            
            Result = BalanceSheet(recBranch(0), AppDate, UserId, Currency1)
            If Mid(Result, 1, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
            
             recBranch.MoveNext
        Loop
    Else
        Result = "No Branch Found..."
        GoTo ErrHand
    End If
    Set recBranch = Nothing
    
    BalanceSheetExtCntr = "Transaction Successful."
    Exit Function

ErrHand:
    
    If Err.Number <> 0 Then
       BalanceSheetExtCntr = Err.Number & Err.Description
    Else
       BalanceSheetExtCntr = Result
    End If
    
End Function

Public Function ProfitNLossExtCntr(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String, Optional Currency2 As String, Optional Currency3 As String)

                           
On Error Resume Next

Dim Result As String
Dim AppDate As String
Dim RepNo As String

    ReDim DataArray(0, 4)
    AppDate = UCase(ApplicationDate)
    UserId = UCase(UserId)
    
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recBranch = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    Set recTemp = objfetch.singlerecordset("RepProfitNLossTemp", "nvl(max(nvl(repno,0)),0)+1")
                   
    RepNo = recTemp(0)
    ConsRepno = RepNo
    
    'Here we are joining both branch and its param tables, to get branch codes which
    'are really implemented
    Set recBranch = objfetch.singlerecordset("GENBANKBRANCHMST a,GENBRANCHPMT b", _
    "DISTINCT a.branchcode", _
    "(a.IMMHIGHLEVELBRCODE='" & Trim(BranchCode) & "' OR a.branchcode='" & Trim(BranchCode) & "') " & _
    " AND a.status='R' and a.branchcode=b.branchcode order by a.branchcode")
       
    If Not recBranch.EOF And Not recBranch.BOF Then
        Do While Not recBranch.EOF
            
            Result = ProfitNLoss(recBranch(0), AppDate, UserId, Currency1, Currency2, Currency3)
            If Mid(Result, 1, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
            
            recBranch.MoveNext
        Loop
    Else
        Result = "No Branch Found..."
        GoTo ErrHand
    End If
    Set recBranch = Nothing
    
    ProfitNLossExtCntr = "Transaction Successful."
    Exit Function

ErrHand:
    
    If Err.Number <> 0 Then
       ProfitNLossExtCntr = Err.Number & Err.Description
    Else
       ProfitNLossExtCntr = Result
    End If
    
End Function

Public Function ProfitNLossConsolidated(BranchCode As String, ApplicationDate As String, UserId As String, _
                             Currency1 As String, Optional Currency2 As String, Optional Currency3 As String)

                           
On Error Resume Next

Dim Result As String
Dim AppDate As String
Dim RepNo As String

    ReDim DataArray(0, 4)
    AppDate = UCase(ApplicationDate)
    UserId = UCase(UserId)
    
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recBranch = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    Set recTemp = objfetch.singlerecordset("RepProfitNLossTemp", "nvl(max(nvl(repno,0)),0)+1")
                   
    RepNo = recTemp(0)
    ConsRepno = RepNo
    
    'Here we are joining both branch and its param tables, to get branch codes which
    'are really implemented
    Set recBranch = objfetch.singlerecordset("GENBANKBRANCHMST a,GENBRANCHPMT b", _
    " a.branchcode", " a.status='R' and a.branchcode=b.branchcode and BRANCHTYPE<>'HO' order by a.branchcode")
       
    If Not recBranch.EOF And Not recBranch.BOF Then
        Do While Not recBranch.EOF
            
            Result = ProfitNLoss(recBranch(0), AppDate, UserId, Currency1, Currency2, Currency3)
            If Mid(Result, 1, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
            
            recBranch.MoveNext
        Loop
    Else
        Result = "No Branch Found..."
        GoTo ErrHand
    End If
    Set recBranch = Nothing
    
    ProfitNLossConsolidated = "Transaction Successful."
    Exit Function

ErrHand:
    
    If Err.Number <> 0 Then
       ProfitNLossConsolidated = Err.Number & Err.Description
    Else
       ProfitNLossConsolidated = Result
    End If
    
End Function


Public Function GLConsolidated(ApplicationDate As String, UserId As String, _
                             Currency1 As String) As String
On Error Resume Next

Dim Result As String
Dim AppDate As String
Dim RepNo As String

    ReDim DataArray(0, 4)
    AppDate = UCase(ApplicationDate)
    UserId = UCase(UserId)
    
    ''''' Createing Instances of components
    Set recTemp = CreateObject("adodb.recordset")
    Set recBranch = CreateObject("adodb.recordset")
    Set recRepno = CreateObject("adodb.recordset")
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objMstTrans = CreateObject("generaltransactions.dbtransactions")
    
    Set recTemp = objfetch.singlerecordset("RepBalanceSheetTemp", "nvl(max(nvl(repno,0)),0)+1")
                   
    RepNo = recTemp(0)
    ConsRepno = RepNo
    
    'Here we are joining both branch and its param tables, to get branch codes which
    'are really implemented
    Set recBranch = objfetch.singlerecordset("GENBANKBRANCHMST a,GENBRANCHPMT b", _
    " a.branchcode", " a.status='R' and a.branchcode=b.branchcode and BRANCHTYPE<>'HO' order by a.branchcode")
       
    If Not recBranch.EOF And Not recBranch.BOF Then
        Do While Not recBranch.EOF
            
            Result = GLConBr(recBranch(0), AppDate, UserId, Currency1)
            If Mid(Result, 1, 11) <> "Transaction" And Result <> "" Then GoTo ErrHand
        
            recBranch.MoveNext
        Loop
    Else
        Result = "No Branch Found..."
        GoTo ErrHand
    End If
    Set recBranch = Nothing
    
    GLConsolidated = "Transaction Successful." & ConsRepno
    ''GLConsolidated = ConsRepno
    Exit Function

ErrHand:
    
    If Err.Number <> 0 Then
       GLConsolidated = Err.Number & Err.Description
    Else
       GLConsolidated = Result
    End If
    
End Function

