Attribute VB_Name = "ModGen"
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public strUserid As String
Public strDataSource As String
Public strSupreUserPassword As String
Public AdoConnObj As ADODB.Connection
Public ConnError As String


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With

''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
    ''If AdoScConnObj.State = 1 Then AdoScConnObj.Close
    ''Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:

'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserid = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "QueryRecordsets", "DBConnection" & strLineno, Err.Number, Err.Description

   
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objErrlog.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Public Function VerifyConnectionWithV3(strDS As String, strUid As String, strSupreUserPassword As String) As Boolean
On Error GoTo errh
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
    
    With AdoConnObj

        If .State = 1 Then .Close

           .ConnectionString = "user id=" & strUid & ";password=" & strSupreUserPassword & _
           ";data source=" & strDS
           .CursorLocation = adUseClient
           .Provider = "MSDAORA"
           .Open

    End With
VerifyConnectionWithV3 = True


Exit Function
errh:
VerifyConnectionWithV3 = False
End Function

