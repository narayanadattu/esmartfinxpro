VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "MSFLXGRD.OCX"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3090
   ClientLeft      =   240
   ClientTop       =   1935
   ClientWidth     =   8490
   LinkTopic       =   "Form1"
   ScaleHeight     =   3090
   ScaleWidth      =   8490
   Begin MSFlexGridLib.MSFlexGrid ms 
      Height          =   1695
      Left            =   480
      TabIndex        =   1
      Top             =   1080
      Width           =   7695
      _ExtentX        =   13573
      _ExtentY        =   2990
      _Version        =   393216
      AllowUserResizing=   3
   End
   Begin VB.CommandButton Command2 
      Caption         =   "SI"
      Height          =   495
      Left            =   2520
      TabIndex        =   0
      Top             =   120
      Width           =   2295
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim st As String
'Public Rdint As MaturityValueCalc.MatValue
'Private Sub Command1_Click()
'On Error GoTo errh
'Set Rdint = New MaturityValueCalc.MatValue
'st = Rdint.RDInterestAmount("999", "INR", "104111", "702", "500", _
'             "8.50", "23-FEB-2007", "Y")
'MsgBox st
'Exit Sub
'errh:
'MsgBox Err.Description, vbInformation
'End Sub

Private Sub Command2_Click()
On Error GoTo errh
Dim StrMsg
Dim si As StandInstrCalc.StandInstr
Set si = New StandInstrCalc.StandInstr
Form1.ms.Rows = 1
ms.Cols = 15
ms.FormatString = "|<glcode   |<Dep no   |<Name               |<CredityType   |<Cr Mod Id|" & _
                " <CrGlCode  |<Cr A/c No  |<Payment Mode|<Int Amount|<Payable Bank " & _
                " |<Payable Branch |<Favouring   |<Cr.Name        |<IntApplied Date "

'StrMsg = si.PopulateStandingInstructions("999", "INR", "104112", "", "23-MAY-2007", "23-MAY-2007", "", "")

StrMsg = si.PopulateStandingInstructions(CStr("104"), CStr("INR"), _
                CStr("104113"), "", CStr("13-SEP-2007"), CStr("13-SEP-2007"), "", "")
'MsgBox StrMsg

Exit Sub
errh:
MsgBox Err.Description
End Sub
