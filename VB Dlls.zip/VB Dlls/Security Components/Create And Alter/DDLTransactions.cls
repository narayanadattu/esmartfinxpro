VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "DDLTransactions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim AdoConnObj As New ADODB.Connection   ' Connection Object
Dim CmdText As String 'Command Text
'Dim objinsert As Object
'Dim objcontext As ObjectContext
Public Function CreateUser(BranchCode As String, UsrName As String, UsrID As String, _
                             Password As String, PasswordLifeTime As Integer, _
                             PasswordLockTime As Integer, PasswordGraceTime As Integer, _
                             FailedLoginAttempts As Integer, Biometrics As String, _
                             GroupID As String, GroupName As String) As String
Dim strLevel As Integer
Dim PwdLockTime As Integer
Dim PwdLifeTime As Integer
Dim PwdGraceTime As Integer
Dim FailLogAttempts As Integer
Dim UsId As String
Dim Pwd As String
Dim strGroupId As String
Dim strGroupName As String
Dim strResult As String
Dim strTable As String
Dim strFields As String
Dim FldVals(0) As String
Dim strBrCode As String
Dim strBiometrics As String
Dim strUsrName As String
Set AdoConnObj = CreateObject("ADODB.Connection")
On Error GoTo myerr
    UsId = UsrID
    Pwd = Password
    PwdLockTime = PasswordLockTime
    PwdLifeTime = PasswordLifeTime
    PwdGraceTime = PasswordGraceTime
    FailLogAttempts = FailedLoginAttempts
    strGroupId = GroupID
    strGroupName = GroupName
    strBrCode = BranchCode
    strBiometrics = Biometrics
    strUsrName = UsrName
    
    AdoConnObj.CursorLocation = adUseClient
    
    ''''--------- If the object type is profile then connect to SYS user
    AdoConnObj.Open "Provider=MSDAORA.1;data source=orcl;Password=change_on_install;User ID=sys"

    
    ''''---------- Creation of User Profile
        
     'CmdText = "Create profile " & UsId & "profile limit sessions_per_user 1 password_verify_function check_password password_reuse_time 18000 password_reuse_max unlimited Password_lock_time " & PwdLockTime & " password_grace_time " & PwdGraceTime & " password_life_time " & PwdLifeTime & " failed_login_attempts " & FailLogAttempts
     CmdText = "Create profile " & UsId & "profile limit sessions_per_user 1  password_reuse_time 18000 password_reuse_max unlimited Password_lock_time " & PwdLockTime & " password_grace_time " & PwdGraceTime & " password_life_time " & PwdLifeTime & " failed_login_attempts " & FailLogAttempts
    AdoConnObj.Execute CmdText
   
    strLevel = 1
    '''''-------------Creation of User
    CmdText = "Create user " & UsId & " identified by " & Pwd & "  profile " & UsId & "profile"
    AdoConnObj.Execute CmdText
    strLevel = 2
    
    ''''' ---------- Granting Roles to New User
    CmdText = "Grant Resource,connect to " & UsId
    AdoConnObj.Execute CmdText
    
    '''------Return Result
    CreateUser = "User Created Successfully...!"
    Exit Function

myerr:
    
    If strLevel = 1 Then ''---------------if Profile is created and an error is raised at User creation
        CmdText = "drop profile " & UsrID & "profile"
        AdoConnObj.Execute CmdText
    ElseIf strLevel = 2 Then '''------------if error is raised after user creation
        CmdText = "drop user " & UsrID & " cascade "
        AdoConnObj.Execute CmdText
        CmdText = "drop profile " & UsrID & "profile"
        AdoConnObj.Execute CmdText
    End If
    CreateUser = Err.Number & " " & Err.Description
    CreateUser = Replace(CreateUser, Chr(10), "")
    CreateUser = Replace(CreateUser, Chr(13), "")

End Function

Public Function AlterUserPassword(UsrID As String, Pasword As String) As String
Dim UsId As String
Dim Pwd As String
On Error GoTo myerr
    UsId = UsrID
    Pwd = Pasword
    Set AdoConnObj = CreateObject("ADODB.Connection")
    AdoConnObj.CursorLocation = adUseClient
   
    '''''-------------If the connection is established then close it
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    AdoConnObj.Open "Provider=MSDAORA.1;data source=orcl;Password=change_on_install;User ID=sys"
    
    '''''------------- Changing the Password
    CmdText = "Alter user " & UsId & " identified by " & Pwd
    AdoConnObj.Execute CmdText
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    '''''------------- If password is changed successfully then open that connection
    AdoConnObj.Open "Provider=MSDAORA.1;data source=orcl;Password=" & Pasword & ";User ID=" & UsrID
    AlterUserPassword = "User Altered....!"
    AdoConnObj.Close
    Exit Function

myerr:
    AlterUserPassword = Err.Description
    AlterUserPassword = Replace(AlterUserPassword, Chr(10), "")
    AlterUserPassword = Replace(AlterUserPassword, Chr(13), "")

End Function




Public Function DropUser(UserName As String)


Dim UsId As String
On Error GoTo myerr
    UsId = UserName
    Set AdoConnObj = CreateObject("ADODB.Connection")
    AdoConnObj.CursorLocation = adUseClient
   
    '''''-------------If the connection is established then close it
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    AdoConnObj.Open "Provider=MSDAORA.1;data source=orcl;Password=change_on_install;User ID=sys"
    
    '''''------------- Drop the User
    CmdText = "Drop user " & UsId & " Cascade "
    AdoConnObj.Execute CmdText
    
    '''''------------- Drop the User Profile
    CmdText = "Drop Profile " & UsId & "Profile "
    AdoConnObj.Execute CmdText
    
    AdoConnObj.Close
    Exit Function

myerr:
    DropUser = Err.Description
    DropUser = Replace(DropUser, Chr(10), "")
    DropUser = Replace(DropUser, Chr(13), "")

End Function
