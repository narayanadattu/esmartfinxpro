VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "Login"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim StrTabName As String
Dim StrFlds As String
Dim objUserFetch As Object
Dim objUserTrans As Object
Dim obj As Object
'Dim ObjContext As ObjectContext
Dim Result As String
Dim StrValues(0) As Variant
Dim DBConnection As New ADODB.Connection
Dim recgenusermst  As Recordset
Dim recgenwork As Recordset
Dim comalteruser As New ADODB.Command

Public Function Login(UsrId As String, Pasword As String, Biometrics As String) As String
Dim UsId As String
Dim Pwd As String
Dim Bio As String
    On Error GoTo myerr
    UsId = UsrId
    Pwd = Pasword
    Bio = Biometrics
    '----- Checking for the validity of userid and password
   
    Set DBConnection = Nothing
    DBConnection.ConnectionString = "provider=msdaora.1;data source=orcl;user id=" & _
                                    UsId & ";password=" & Pwd
    DBConnection.Open
    '------Calling queryrecordsets componenet
       
   Set recgenusermst = CreateObject("adodb.recordset")
   Set objUserFetch = CreateObject("QueryRecordsets.FetchRecordsets")
   Set recgenusermst = objUserFetch.SingleRecordSet("Genusermst", "userid,status", "upper(userid)='" & _
                                                    UCase(UsId) & "' and upper(biometrics)='" & UCase(Bio) & "'")
        
    '---------Checking  the validity of password
        
    If Not recgenusermst.EOF And Not recgenusermst.BOF Then
        If UCase(recgenusermst(0)) = UCase(UsId) Then
            If recgenusermst(1) = "A" Then
               '----------------------If valid then note the login time----------------
                Result = ""
                Result = "Trans Completed"
                If Result <> "Trans Completed" Then GoTo myerr
                Login = "Successfully Loged in"
            Else
                Login = UCase(UsId) & " is not approved user..."
            End If
        End If
    Else
        Login = UCase(UsId) & " is not this application user ......"
    End If
   
Exit Function

myerr:
If Len(Result) > 0 Then
    Login = Result
    Login = Replace(Login, Chr(10), "")
    Login = Replace(Login, Chr(13), "")
Else
    If Err.Number = -2147467259 Then
        Login = UsId & " Connection failure or Oracle is not available.."
        Login = Replace(Login, Chr(10), "")
        Login = Replace(Login, Chr(13), "")
    Else
        Login = Err.Number & "   " & Err.Description
        Login = Replace(Login, Chr(10), "")
        Login = Replace(Login, Chr(13), "")
    End If
End If
End Function


Public Function ChangePassword(UsrId As String, oldpassword As String, NewPassword As String, ConfirmPassword As String, Biometrics As String) As String
Dim UsId As String
Dim OldPwd As String
Dim NewPwd As String
Dim ConPwd As String
Dim Bio As String
    On Error GoTo myerr
    UsId = UsrId
    OldPwd = oldpassword
    NewPwd = NewPassword
   'NewPwd = "v3user#4"
    ConPwd = ConfirmPassword
    Bio = Biometrics
    'OldPwd = "v3user#3"
    Set DBConnection = Nothing
    DBConnection.ConnectionString = "provider=msdaora.1;data source=orcl;user id=" & _
                                UsId & ";password=" & OldPwd
    DBConnection.Open
    ''''----------------Checking the equality fo new password/biometrics and confirm password/confirm biometrics

    If (NewPwd = ConPwd) Then
    
    ''''------------ If equal then change the password using ALTER
    'Set objContext = GetObjectContext
    Set objUserTrans = CreateObject("CreateAndAlterUser.DDLTransactions")
    Result = objUserTrans.AlterUserPassword(UsId, NewPwd)
        If Result = "User Altered....!" Then
            ChangePassword = UsId & "  Password is Changed..."
            ChangePassword = Replace(ChangePassword, Chr(10), "")
            ChangePassword = Replace(ChangePassword, Chr(13), "")
        Else
            ChangePassword = "Password change failed due to " & Result
            ChangePassword = Replace(ChangePassword, Chr(10), "")
            ChangePassword = Replace(ChangePassword, Chr(13), "")
        End If
    Else
        ChangePassword = "Confirm Password is not matched with New..."
        Exit Function
    End If
    Exit Function

myerr:
    If Len(Result) > 0 Then
          ChangePassword = Result
          ChangePassword = Replace(ChangePassword, Chr(10), "")
          ChangePassword = Replace(ChangePassword, Chr(13), "")
    Else
        ChangePassword = Err.Number & "  " & Err.Description
        ChangePassword = Replace(ChangePassword, Chr(10), "")
        ChangePassword = Replace(ChangePassword, Chr(13), "")
    End If
End Function

