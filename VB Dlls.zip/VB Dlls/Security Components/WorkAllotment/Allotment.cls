VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "Allotment"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim objfetch As Object


Public Function UserWorkAllotment(Mode As String, UserID As String, Moduleid As String, BranchCode As String _
                               ) As Variant

''''----------------------Variable Declaration
Dim tCount As Integer
Dim ICount As Integer
Dim Rcount As Integer
Dim lcount As Integer
Dim GroupID As String
Dim strModId As String
Dim strMode As String
Dim strBrCode As String
Dim strUsrId As String
Dim strFileds As String
Dim strTabname As String
Dim strWhere As String
Dim strCmp As String
Dim recWork As Recordset
Dim recWork1 As Recordset
Dim recWork2 As Recordset
Dim recwork3 As Recordset
Dim records()


    On Error GoTo myerr
    ''''---------------------- Arguments to Local variables
    ICount = 0
    strMode = UCase(Mode)
    strModule = UCase(Moduleid)
    strBrCode = UCase(BranchCode)
    strUsrId = UCase(UserID)
    strModId = UCase(Moduleid)

    '''''---------------- Creation of Objects
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recWork = CreateObject("Adodb.Recordset")

    ''''---------------------- Checking the existance of user and _
                                groupcode assigned to that user
    strTabname = "GENUSERMST"
    strFileds = "upper(groupid)"
    strWhere = "upper(branchcode)='" & strBrCode & "' and upper(userid)='" & strUsrId & "'"
    Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)


        If recWork.EOF = False And recWork.BOF = False Then

            ''''------- If User and Group Found then select the forms _
                        which are not assigned to the given group from the given module
            GroupID = recWork(0)
            strFileds = "distinct(upper(forms)),narration,FormsId"
            strTabname = "GENMODULEIDFORMSMST"
'            'Code commented by Radhika on 12 May 2008
'            'Reason: Don't look for Branch code while quring gengroupformsmst table
''            strWhere = " moduleid='" & strModId & _
''                        "' and FormsId not in(select FormsId from gengroupformsmst" & _
''                        " where upper(groupcode)='" & GroupID & "' and branchcode='" & BranchCode & "') or FormsId in " & _
''                        "(select FormsId from genuseridformsmst where upper(userid)='" & strUsrId & _
''                        "'  and addoreliminate='E' and upper(moduleid)='" & strModId & "')"
'
'            strWhere = " moduleid='" & strModId & _
'                        "' and FormsId not in(select FormsId from gengroupformsmst" & _
'                        "  where upper(groupcode)='" & GroupID & "' and moduleid='" & _
'                           strModId & "' and (transtatus='A' OR transtatus='N' ) ) " & _
'                        " or FormsId in " & _
'                        "(select FormsId from genuseridformsmst where upper(userid)='" & strUsrId & _
'                        "'  and addoreliminate='E' and upper(moduleid)='" & strModId & "')"
'
'            Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)


        Else

            ''''-------- If not found the return the error message
            ReDim records(0, 0)
            records(0, 0) = "User not assigned any group"
            UserWorkAllotment = records
            Exit Function
        End If

    ''''---------------If allotment mode is ADD then
    If UCase(strMode) = "ADD" Then

'        strWhere = "upper(moduleid)='" & strModId & "' and FormsId NOT in " & _
'        "(select FormsId from genuseridformsmst Where upper(userid)='" & strUsrId & "'" & _
'        "and addoreliminate='A' and upper(moduleid)='" & strModId & "') AND " & _
'        "FormsId not in(select FormsID from gengroupformsmst " & _
'        "where groupcode='" & GroupID & "' and moduleid='" & strModId & "' and branchcode='" & BranchCode & "')" & _
'        "Or FormsID in(select FormsID from genuseridformsmst where " & _
'        "upper(userid)='" & strUsrId & "' and addoreliminate='E' and " & _
'        "upper(moduleid)='" & strModId & "')"

        strWhere = "upper(moduleid)='" & strModId & "' and (moduleid,FormsId) NOT in " & _
        "(select moduleid,FormsId from genuseridformsmst Where upper(userid)='" & strUsrId & "'" & _
        "and addoreliminate='A' and upper(moduleid)='" & strModId & "') AND " & _
        " (moduleid,FormsId) not in(select moduleid,FormsID from gengroupformsmst " & _
        "where groupcode='" & GroupID & "' and moduleid='" & strModId & "')" & _
        " Or (moduleid,FormsID) in(select moduleid,FormsID from genuseridformsmst where " & _
        " upper(userid)='" & strUsrId & "' and addoreliminate='E' and " & _
        " upper(moduleid)='" & strModId & "')"
        
        Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)

        Do While Not recWork.EOF
            ICount = ICount + 1
            recWork.MoveNext
        Loop

        If ICount = 0 Then

        ''''-------------- if forms are not alloted to that Group
            ReDim records(0, 0)
            records(0, 0) = "No more to add.. "
            UserWorkAllotment = records
            Exit Function

        Else

       '''''-------------Return Result
            ReDim records(ICount, 2)
            recWork.MoveFirst
            For i = 0 To ICount - 1
                records(i, 0) = recWork(1)
                records(i, 1) = recWork(2)
                recWork.MoveNext
            Next
        End If

    
    ElseIf UCase(strMode) = "DELETE" Or UCase(strMode) = "QUERY" Then

        '''''------------------- If mode is delete or query display records


        '''''------------------- select all the added forms holding the given user

        strTabname = "GENUSERIDFORMSMST"
        strFileds = "distinct(Forms),narration,FormsID"
        strWhere = "upper(Userid)='" & strUsrId & "' and moduleid='" & strModId & _
            "' and addoreliminate='A' and transtatus='A'"
        Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)


        Do While Not recWork.EOF
            recWork.MoveNext
            ICount = ICount + 1
        Loop

        '''''----------------- select all the forms from GENGROUPFORMSMST _
                                    for the given user group and given module
        strTabname = "GENGROUPFORMSMST"
        strFileds = "distinct(Forms),narration,FormsID"
        strWhere = "upper(groupcode)='" & GroupID & "' and upper(moduleid)='" & _
                    strModId & "' and (moduleid,FormsId) not in(select moduleid,FormsID from genuseridformsmst " & _
                    "where upper(userid)='" & strUsrId & "' and upper(moduleid)='" & _
                    strModId & "' and transtatus='A') and transtatus='A'"
                    'and branchcode='" & BranchCode & "'"

        Set recWork1 = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)

        Do While Not recWork1.EOF
            recWork1.MoveNext
            Rcount = Rcount + 1
        Loop

        If ICount > 0 Then recWork.MoveFirst
        If Rcount > 0 Then recWork1.MoveFirst

        ''''-------- Declare array with the record count of above declare recordsets
        ReDim records(ICount + Rcount, 2)

        ''''----------- Return the values to single dim array
        If UBound(records) > 0 Then
            For i = 0 To ICount - 1
                records(i, 0) = recWork(1)
                records(i, 1) = recWork(2)
                recWork.MoveNext
            Next
            For j = 0 To Rcount - 1
                records(i, 0) = recWork1(1)
                records(i, 1) = recWork1(2)
                recWork1.MoveNext
                i = i + 1
            Next
        Else
            ReDim records(0, 0)
            If UCase(strMode) = "QUERY" Then
                records(0, 0) = "No Forms to Query...!"
            ElseIf UCase(strMode) = "DELETE" Then
                records(0, 0) = "No Forms to Delete...!"
            End If

        End If
    End If

    ''''----------------- Return the result to function as array
    UserWorkAllotment = records

    Exit Function

myerr:
    UserWorkAllotment = Err.Description
    UserWorkAllotment = Replace(UserWorkAllotment, Chr(10), "")
    UserWorkAllotment = Replace(UserWorkAllotment, Chr(13), "")

End Function
Public Function GroupWorkAllotment(Mode As String, GroupID As String, Moduleid As String, BranchCode As String) As Variant
''''----------------------Variable Declaration
Dim ICount As Integer
Dim Rcount As Integer
Dim strMode As String
Dim strModule As String
Dim strBrCode As String
Dim strUsrId As String
Dim strFileds As String
Dim strTabname As String
Dim strWhere As String
Dim recWork As Recordset
Dim recAllot As Recordset
Dim records()

    On Error GoTo myerr
    
    ''''------------------ Arguments to variables
    ICount = 0
    strMode = UCase(Mode)
    strModule = UCase(Moduleid)
    strBrCode = UCase(BranchCode)
    strUsrId = UCase(GroupID)
    
    ''''----------------- Defining values for select query
    strTabname = "GENGROUPFORMSMST"
    strFileds = "distinct(Forms),narration,FormsId"
    'code corrected by Radhika on 12 May 2008
    'Reason: Don't look for Branch Code
    'strWhere = "moduleid='" & strModule & "'  and groupcode='" & strUsrId & "' and branchcode='" & BranchCode & "'"
    strWhere = "moduleid='" & strModule & "'  and groupcode='" & strUsrId & "'"
    
   '''''---------------- creation of objects
    Set objfetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recWork = CreateObject("Adodb.Recordset")
    
    ''''---------------If allotment mode is ADD then
    If UCase(strMode) = "ADD" Then
        
        Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)

        Do While Not recWork.EOF
            ICount = ICount + 1
            recWork.MoveNext
        Loop
        
        If ICount = 0 Then
        ''''-------------- if forms are not alloted to that user
            strWhere = "moduleid='" & strModule & "'"
        Else
        ''''-------------- if already alloted and some more to be added
            strWhere = "moduleid='" & strModule & "' and (moduleid,FormsId) not in" & _
                        "(select moduleid,FormsId from gengroupformsmst where  moduleid='" & _
                        strModule & "' and groupcode='" & strUsrId & "' and " & _
                        "(transtatus='A' or transtatus='N' ) )"
                        'and branchcode='" & BranchCode & "')"
        End If
        
        ''''------------- Calling forms from GenModuleIDFormsMst table
        Set recWork = Nothing
        strTabname = "GENMODULEIDFORMSMST"
        strFileds = "distinct(Forms),narration,FormsId"
        
        Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)
        ICount = 0
        Do While Not recWork.EOF
            ICount = ICount + 1
            recWork.MoveNext
        Loop
        If ICount > 0 Then
            recWork.MoveFirst
            ReDim records(ICount, 2)
            For i = 0 To ICount - 1
                records(i, 0) = recWork(1)
                records(i, 1) = recWork(2)
                recWork.MoveNext
            Next
        Else
            ReDim records(0, 0)
            records(0, 0) = "No Form is found.."
        End If
        
    ElseIf UCase(strMode) = "DELETE" Or UCase(strMode) = "QUERY" Then
        
        '''''------------------- if mode is delete or query display records
        
        strWhere = strWhere & " and transtatus='A'"
        Set recWork = objfetch.SingleRecordSet(strTabname, strFileds, strWhere)
        
        Do While Not recWork.EOF
            ICount = ICount + 1
            recWork.MoveNext
        Loop
       
        If ICount > 0 Then
            recWork.MoveFirst
            ReDim records(ICount, 2)
            For i = 0 To ICount - 1
                records(i, 0) = recWork(1)
                records(i, 1) = recWork(2)
                recWork.MoveNext
            Next
        Else
            ReDim records(0, 0)
            records(0, 0) = "Forms not available...."
        End If
    End If
    
    ''''----------------- Return the result to function as array
      
        GroupWorkAllotment = records
   Exit Function

myerr:

    ' Return Error Description
    ReDim records(0, 0)
    
    records(0, 0) = Err.Description
    records(0, 0) = Replace(records(0, 0), Chr(10), "")
    records(0, 0) = Replace(records(0, 0), Chr(13), "")
    
    GroupWorkAllotment = records

End Function



