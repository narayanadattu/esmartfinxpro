VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "Transactions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim objContext As ObjectContext
Dim objTrans As Object
Dim objQuery As Object
Dim ObjFetchRec As Object
Dim TransResult As String
Dim RsDenom As ADODB.Recordset
Dim AdoRsQuery As ADODB.Recordset
Dim RecDenomMst As Recordset
Dim recDenom As Recordset
Dim RecCash As Recordset
Dim objInsUpd As Object






Public Function CashTRNInserts(TRNTableName As String, _
                                    TRNGenFields As String, _
                                    TRNGenValues As String, _
                                    CurrencyCode As String, _
                                    DenomValuesPieces As Variant, _
                                    Optional BranchCode As String, _
                                    Optional UserId As String, _
                                    Optional MachineID As String, _
                                    Optional ApplicationDate As String, _
                                    Optional CounterStatus As String, _
                                    Optional CashierId As String, _
                                    Optional CounterNo As String) As String

Dim StrTabName As String, strFldnames As String, strfldvalues(0) As Variant
Dim arrDenom As Variant, strqueryflds As String, StrCurrency As String
Dim StrCondition As String, strquerytab As String, strorder As String
Dim ICount As Integer, ArrTrnInsValues() As Variant
Dim StrVltVal(0) As Variant
Dim StrCounterVal(0) As Variant
Dim SplitValues As Variant
Dim strbrcode As String
Dim varFld As Variant
Dim xvar As Variant

Set objContext = GetObjectContext
On Error GoTo errhand
StrTabName = Trim(TRNTableName)
strFldnames = Trim(TRNGenFields)
strfldvalues(0) = Trim(TRNGenValues)
StrCurrency = UCase(Trim(CurrencyCode))
arrDenom = DenomValuesPieces
strqueryflds = ""
StrCondition = ""

If StrCurrency = "" Then
    CashTRNInserts = "Transaction Canceled, Please Pass Currency Code Value To check Your Denominations."
    CashTRNInserts = Replace(CashTRNInserts, Chr(10), "")
    CashTRNInserts = Replace(CashTRNInserts, Chr(13), "")
    Exit Function
End If

          If UCase(Trim(StrTabName)) = "CASHVAULTMST" Then
                    SplitValues = Split(strfldvalues(0), ",", -1)
                StrVltVal(0) = ""
                varFld = Split(strFldnames, ",", -1)
                
                 For ICount = 0 To UBound(SplitValues)
                    'xvar = Split(SplitValues(Icount), "'", -1)
                    If UCase(varFld(ICount)) = "BRANCHCODE" Then
                        strbrcode = UCase(Trim(SplitValues(ICount)))
                     End If
                                                
                                                
'                        If UBound(xvar) > 0 Then
'                            StrVltVal(0) = StrVltVal(0) & "~" & xvar(1)
'                        Else
'                            StrVltVal(0) = StrVltVal(0) & "~" & xvar(0)
'                        End If
                    
                    
                
                 Next ICount
                 StrVltVal(0) = Mid(Trim(StrVltVal(0)), 2)
            End If

    Set RsDenom = CreateObject("ADODB.Recordset")

    Dim rsBankParam As ADODB.Recordset
    Dim bCashDenomRequired As Boolean
    
    bCashDenomRequired = False
    
    Set rsBankParam = CreateObject("ADODB.Recordset")
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsBankParam = objQuery.SingleRecordSet("GenBankParm", "nvl(CashDenomyn,'N')", _
        "")
    If rsBankParam.EOF = False And rsBankParam.BOF = False Then
        If IIf(IsNull(rsBankParam(0).Value), "N", rsBankParam(0).Value) = "Y" Then
            bCashDenomRequired = True
        End If
    End If
    Set rsBankParam = Nothing

    strquerytab = "CashDenominationMst"
    strqueryflds = " Denominationvalue,Denominationcode,denominationtype "
    StrCondition = " upper(Currencycode)='" & UCase(StrCurrency) & "'"
    strorder = " substr(denominationtype,1,1) desc, substr(denominationtype,2,1) , " _
            & " to_number( denominationvalue) desc"

    Set RsDenom = CreateObject("ADODB.Recordset")

    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")

    If bCashDenomRequired = True Then
        Set RsDenom = objQuery.SingleRecordSet(strquerytab, strqueryflds, StrCondition, strorder)

        TransResult = objQuery.ConnError
        Set objQuery = Nothing

        If RsDenom.EOF And RsDenom.BOF Then
            CashTRNInserts = "No Denominations for this Query."
            Exit Function
        End If
    
        For ICount = 0 To UBound(arrDenom)

            RsDenom.Filter = "Denominationvalue='" & Trim(arrDenom(ICount, 0)) & "' and " & _
                            UCase("denominationtype='") & _
                            UCase(Trim(arrDenom(ICount, 2))) & "'"
            If Not RsDenom.EOF Then

                If Trim(arrDenom(ICount, 1)) <> "" Then
                    strFldnames = strFldnames & "," & RsDenom!Denominationcode
                    strfldvalues(0) = strfldvalues(0) & "," & arrDenom(ICount, 1)
                    'If UCase(Trim(StrTabName)) = "CASHVAULTMST" Then
                        'StrVltVal(0) = StrVltVal(0) & "~" & RsDenom!denominationcode & "+" & ArrDenom(Icount, 1)
                    'End If
                End If

            End If
        Next ICount
    End If

''''''ReDim ArrTrnInsValues(0, 0) As Variant
''''''ArrTrnInsValues(0, 0) = strfldvalues
TransResult = ""
If UCase(Trim(StrTabName)) = "CASHVAULTMST" Then
          
        ''''' Checking If any Row Present at cashvaultmst for a branch based on currencycode
        
        Set AdoRsQuery = CreateObject("ADODB.Recordset")

        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        
        '''''''SingleRecordSet
        TransResult = ""
        StrCondition = " upper(trim(currencycode))='" & UCase(Trim(StrCurrency)) & "' and upper(trim(branchcode))=" & strbrcode
        Set AdoRsQuery = objQuery.SingleRecordSet("Cashvaultmst", "*", StrCondition)
            TransResult = objQuery.ConnError
        
        
            If AdoRsQuery.EOF And AdoRsQuery.BOF Then
               TransResult = ""
                '''' IF VAULT IS EMPTY THEN CREATE A NEW ROW
                strFldnames = strFldnames & ",systemdate"
                 strfldvalues(0) = strfldvalues(0) & ",sysdate"
                
                Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
                TransResult = objTrans.InsertRecord(StrTabName, strFldnames, strfldvalues, _
                                                    BranchCode, UserId, MachineID, ApplicationDate)
                
            Else
            
                '''' UPDATE THE EXISTING ROW WITH THE VALUES
                
                
              CashTRNInserts = "Transaction Canceled. You are Trying to Insert Duplicate Values Into Vault"
              CashTRNInserts = Replace(CashTRNInserts, Chr(10), "")
              CashTRNInserts = Replace(CashTRNInserts, Chr(13), "")
                 Exit Function
''''''                 Exit Function
''''''                strFldnames = strFldnames & ",systemdate,applicationdate"
''''''                 StrVltVal(0) = StrVltVal(0) & "~to_date(to_char(sysdate,'dd-Mon-yy HH24:mi:ss'),'dd-Mon-yy HH24:mi:ss')" _
''''''                 & "~to_date(to_char(" & App & ",'dd-Mon-yy HH24:mi:ss'),'dd-Mon-yy HH24:mi:ss')"
''''''
''''''
''''''                Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
''''''                TransResult = objTrans.UpdateRecord(StrTabName, strFldnames, StrVltVal, strcondition)

            
            
            End If
                    
            
Else

        
Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
TransResult = objTrans.InsertRecord(StrTabName, strFldnames, strfldvalues)
Set RsDenom = CreateObject("ADODB.Recordset")

End If

    ''' checking if it is las refund of the cashier then close the counter.
If TransResult = "Trans Completed" Then

    If (UCase(Trim(StrTabName)) = "CASHREFUNDSTRN" And UCase(Trim(CounterStatus)) = "C") Or _
        (UCase(Trim(StrTabName)) = "CASHALLOTMENTSTRN" And UCase(Trim(CounterStatus)) = "O") Then
        TransResult = ""
        'MsgBox "Hello"
        StrCondition = " Branchcode='" & BranchCode & "' and CURRENCYCODE='" & StrCurrency _
                    & "' and cashierid='" & CashierId & "' and counterno='" & CounterNo & "'"
        StrCounterVal(0) = "'" & UCase(Trim(CounterStatus)) & "'"
        
        TransResult = objTrans.UpdateRecord("CASHCOUNTERMST", "COUNTERSTATUS", _
                        StrCounterVal, StrCondition, BranchCode, _
                        UserId, MachineID)
    End If

End If
    
If TransResult = "Trans Completed" Then
        objContext.SetComplete
        Set objTrans = Nothing
        Set objContext = Nothing
        CashTRNInserts = "Transaction Successful"
        Exit Function
       
Else
        objContext.SetAbort
        Set objTrans = Nothing
        Set objContext = Nothing
        objQuery = Nothing
        CashTRNInserts = TransResult
        CashTRNInserts = Replace(CashTRNInserts, Chr(10), "")
        CashTRNInserts = Replace(CashTRNInserts, Chr(13), "")
End If

errhand:


    CashTRNInserts = Err.Number & " : " & Err.Description & ". " & TransResult
    CashTRNInserts = Replace(CashTRNInserts, Chr(10), "")
    CashTRNInserts = Replace(CashTRNInserts, Chr(13), "")

End Function



''''' Method for updating the tables cashallotmentstrn,cashcashierposmst,cashvaultmst after
''''' acceptance of the cash allotment.
Public Function CashAllotAcceptance(BranchCode As String, CurrencyCode As String, _
                                            ApplicationDate As String, _
                                            AllotedCashierid As String, _
                                            AcceptedCashierID As String, _
                                            AllotmentNo As String, _
                                            MachineID As String, _
                                            Optional AcceptedCounterNo As String) As String

Dim BrCode As String, CurrCode As String, AppDate As String
Dim strCashier As String, strCounter As String, AllotNo As String
Dim QryCondition As String, strvalues() As Variant, StrCondition As String
Dim CashPosCondition As String, CashPosValues() As Variant
Dim CashVltValues() As Variant, CashVltCondition As String
Dim StrFields As String, CashPosFlds As String, CashVltFlds As String
Dim DenomCount As Integer, TotAmount As Double, CashPosInsVal() As Variant
Dim StrInsCounter As String

ReDim CashPosValues(0) As Variant
ReDim CashPosInsVal(0) As Variant
ReDim strvalues(0) As Variant
ReDim CashVltValues(0) As Variant

BrCode = UCase(Trim(BranchCode))
CurrCode = UCase(Trim(CurrencyCode))
AppDate = IIf(IsNull(ApplicationDate), "", Format(ApplicationDate, "dd-mmm-yy"))
strCashier = UCase(Trim(AcceptedCashierID))
strCounter = IIf(IsNull(UCase(Trim(AcceptedCounterNo))), "", UCase(Trim(AcceptedCounterNo)))
AllotNo = UCase(Trim(AllotmentNo))
CashPosFlds = "" '''''' for concantinating the fields.

StrFields = "AmountAlloted Amount,nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50, Counterno "

QryCondition = " upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(AllotmentNo))='" & AllotNo & "' and trim(status)='P' and " _
& " upper(trim(Alloteduserid))='" & UCase(AllotedCashierid) & "' and upper(trim(Cashierid))='" & strCashier & "'"

''''' Querying the values alloted from CashAllotmentsTrn
Set AdoRsQuery = CreateObject("ADODB.Recordset")
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set AdoRsQuery = objQuery.SingleRecordSet("CashAllotmentsTrn", StrFields, QryCondition)

If objQuery.ConnError <> "Connected" Then
    CashAllotAcceptance = objQuery.ConnError
    CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(10), "")
    CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(13), "")
    Set objQuery = Nothing
    Exit Function
End If

Set objQuery = Nothing
If AdoRsQuery.EOF And AdoRsQuery.BOF Then
CashAllotAcceptance = "Cash Allotment is not done to the " & strCashier & " Please Check"
Exit Function
End If

TotAmount = AdoRsQuery!Amount

StrFields = "Status,AcceptedUserId,AcceptedMachineid,Accepteddate"
strvalues(0) = "'A'~'" & strCashier & "'~'" & MachineID & "'~ '" & AppDate & "'"


CashPosFlds = "TOTAmount,"
CashVltFlds = "TOTAmount,"
CashPosValues(0) = "TotAmount" & "+" & AdoRsQuery!Amount & "~"
CashPosInsVal(0) = TotAmount & ","
CashVltValues(0) = "TotAmount" & "-" & AdoRsQuery!Amount & "~"
StrInsCounter = IIf(IsNull(UCase(Trim(AdoRsQuery!CounterNo))), "", UCase(Trim(AdoRsQuery!CounterNo)))
For DenomCount = 1 To 50
        If AdoRsQuery.Fields(DenomCount).Value > 0 Then
       
            CashPosFlds = CashPosFlds & AdoRsQuery.Fields(DenomCount).Name & ","
            CashVltFlds = CashVltFlds & AdoRsQuery.Fields(DenomCount).Name & ","
            '**** Addition of Pieces Transfered  To cashier from Vault**********
            
            CashPosValues(0) = CashPosValues(0) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) + " & AdoRsQuery.Fields(DenomCount).Value & "~"
            
            '*****nserting a new row from cashierposmst if cashierid not present
            CashPosInsVal(0) = CashPosInsVal(0) & AdoRsQuery.Fields(DenomCount).Value & ","
            '**** Subtraction of  Pieces Transfered  From vault to cashier **********
            
            CashVltValues(0) = CashVltValues(0) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) - " & AdoRsQuery.Fields(DenomCount).Value & "~"
    
        End If
   
    
   
    
Next DenomCount

''''Updating the systemdate with time and applicationdate into cashvaultmst
 CashVltFlds = CashVltFlds & " systemdate,applicationdate"
 CashVltValues(0) = CashVltValues(0) & " sysdate" _
 & "~'" & AppDate & "'"
 
 CashVltFlds = CashVltFlds & ",UserId,Machineid"

 
'''''CashVltFlds = IIf(IsNull(Trim(MachineID)), CashVltFlds & ",UserId", CashVltFlds _
'''''                & ",UserId,Machineid")


CashVltValues(0) = CashVltValues(0) & "~'" & strCashier & "'~'" & MachineID & "'"


'''''CashVltValues(0) = IIf(IsNull(Trim(MachineID)), CashVltValues(0) & "~ '" & strCashier & "'", _
'''''                    CashVltValues(0) & "~'" & strCashier & "'~'" & MachineID & "'")

CashPosFlds = CashPosFlds & "UserId,Machineid,AllotmentNo"

 
'''''CashPosFlds = IIf(IsNull(Trim(MachineID)), CashPosFlds & "UserId,AllotmentNo", CashPosFlds _
'''''                & "UserId,Machineid,AllotmentNo")

CashPosValues(0) = CashPosValues(0) & "'" & strCashier & "'~'" & MachineID & "'~'" & AllotNo & "'"


''''CashPosValues(0) = IIf(IsNull(Trim(MachineID)), CashPosValues(0) & "'" & strCashier & "'~'" _
''''& AllotNo & "'", CashPosValues(0) & "'" & strCashier & "'~'" & MachineID & "'~'" & AllotNo & "'")

CashPosInsVal(0) = CashPosInsVal(0) & "'" & strCashier & "','" & MachineID & "','" & AllotNo & "'"

''''''CashPosInsVal(0) = IIf(IsNull(Trim(MachineID)), CashPosInsVal(0) & "'" & strCashier & "','" _
''''''& AllotNo & "'", CashPosInsVal(0) & "'" & strCashier & "','" & MachineID & "','" & AllotNo & "'")

'''' CONDITION FOR CASHCASIERPOSMST FOR UPDATE
CashPosCondition = "upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(cashierid))='" & strCashier & "' and applicationdate= '" & AppDate & "'"


'''' CONDITION FOR CASHVAULTMST FOR UPDATE
CashVltCondition = "upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "'"



'''''checking for the existance of the given cashier in cashcashierposmst
If AdoRsQuery.State = 1 Then AdoRsQuery.Close



Set AdoRsQuery = CreateObject("ADODB.Recordset")
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set AdoRsQuery = objQuery.SingleRecordSet("cashcashierposmst", "cashierid", CashPosCondition)
If objQuery.ConnError <> "Connected" Then
    
   CashAllotAcceptance = objQuery.ConnError
   CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(10), "")
   CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(13), "")
   Set objQuery = Nothing
   Exit Function
End If
Set objQuery = Nothing



'''''' To remove the last 1 char("," "~") from the following string variables
''''
''''''CashVltFlds = Left(CashVltFlds, Len(CashVltFlds) - 1)
''''''CashVltValues(0) = Left(CashVltValues(0), Len(CashVltValues(0)) - 1)

Set objContext = GetObjectContext
Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
StrCondition = QryCondition
' updating the status of from cashier of CashTransBTCashierstrn
TransResult = objTrans.UpdateRecord("CashAllotmentstrn", StrFields, strvalues, StrCondition, _
                                        BrCode, strCashier, MachineID, AppDate)


'' updating the row of cashvaultmst
If TransResult = "Trans Completed" Then
TransResult = objTrans.UpdateRecord("CashVaultMst", CashVltFlds, CashVltValues, _
                                    CashVltCondition, BrCode, strCashier, MachineID, AppDate)
Else: GoTo errhand
End If

'Udating the row of TO Cashier of CashCashierposmst
If TransResult = "Trans Completed" Then
        If AdoRsQuery.EOF And AdoRsQuery.BOF Then
            CashPosFlds = CashPosFlds & ",Cashierid,counterno,ApplicationDate,Branchcode,currencycode,systemdate"
            
            CashPosInsVal(0) = CashPosInsVal(0) & ",'" & strCashier & "','" & strCounter _
            & "','" & AppDate & "','" _
            & BrCode & "','" & CurrCode & "'," _
            & "sysdate"
            
           '''if cashierid not present in CashCashierposmst then insert a new row in for that cashier
            TransResult = objTrans.InsertRecord("CashCashierposmst", CashPosFlds, _
                                    CashPosInsVal, BrCode, strCashier, MachineID, AppDate)
                                                
        Else
            '''if cashierid present in CashCashierposmst then update row  for that cashier
            TransResult = objTrans.UpdateRecord("CashCashierposmst", CashPosFlds, _
            CashPosValues, CashPosCondition, BrCode, strCashier, MachineID, AppDate)
        End If
        If TransResult <> "Trans Completed" Then GoTo errhand
                                                
Else: GoTo errhand
End If

objContext.SetComplete
Set objTrans = Nothing
CashAllotAcceptance = "Transaction Completed"
Exit Function


errhand:
objContext.SetAbort
Set objTrans = Nothing
If TransResult <> "" Then
    CashAllotAcceptance = TransResult
    CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(10), "")
   CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(13), "")
Else
    CashAllotAcceptance = Err.Number & " : " & Err.Description
    CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(10), "")
    CashAllotAcceptance = Replace(CashAllotAcceptance, Chr(13), "")
   
End If


End Function

''''' Method for updating the tables cashrefundstrn,cashcashierposmst,cashvaultmst after
''''' acceptance of the cash TRANSFER.
Public Function CashRefundAcceptance(BranchCode As String, CurrencyCode As String, _
                                            ApplicationDate As String, _
                                            REFUNDACCEPTEDUSERID As String, _
                                            REFUNDEDUSERID As String, _
                                            RefundNo As String, _
                                            MachineID As String, _
                                            Optional CounterNo As String) As String

Dim BrCode As String, CurrCode As String, AppDate As String
Dim strCashier As String, strCounter As String, AllotNo As String
Dim QryCondition As String, strvalues() As Variant, StrCondition As String
Dim CashPosCondition As String, CashPosValues() As Variant
Dim CashVltValues() As Variant, CashVltCondition As String
Dim StrFields As String, CashPosFlds As String, CashVltFlds As String
Dim DenomCount As Integer, TotAmount As Double


ReDim CashPosValues(0) As Variant
ReDim strvalues(0) As Variant
ReDim CashVltValues(0) As Variant

BrCode = UCase(Trim(BranchCode))
CurrCode = UCase(Trim(CurrencyCode))
AppDate = Format(ApplicationDate, "dd-MMM-yyyy")
strCashier = UCase(Trim(REFUNDACCEPTEDUSERID)) ''' Cashierid who accepts the refund
strCounter = IIf(IsNull(Trim(CounterNo)), "", UCase(Trim(CounterNo))) ''' counter of Cashierid who accepts the refund
CashPosFlds = "" '''''' for concantinating the fields.

StrFields = "nvl(REFUNDAMOUNT,0) Amount,nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50"

QryCondition = " upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(RefundNo))='" & RefundNo & "' and upper(trim(status))='P' " _
& " and upper(trim(REFUNDEDUSERID ))='" & REFUNDEDUSERID & "'"
''' and upper(trim(Cashierid))='" & strCashier & "'"


''''' Querying the values alloted from CashAllotmentsTrn
Set AdoRsQuery = CreateObject("ADODB.Recordset")
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set AdoRsQuery = objQuery.SingleRecordSet("CashRefundsTrn", StrFields, QryCondition)
If objQuery.ConnError <> "Connected" Then
   CashRefundAcceptance = objQuery.ConnError
   CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(10), "")
   CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(13), "")
   Set objQuery = Nothing
   Exit Function
End If
    If AdoRsQuery.EOF And AdoRsQuery.BOF Or AdoRsQuery.State = 0 Then
        CashRefundAcceptance = "Cash Refund is not done to the Vault By The Following " _
        & strCashier & " Please Check !"
        CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(10), "")
        CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(13), "")
   
    
    Exit Function
    End If

TotAmount = AdoRsQuery!Amount

StrFields = "status,REFUNDACCEPTEDMACID,REFUNDACCEPTEDUSERID,REFUNDACCEPTEDDATE"

strvalues(0) = "'A'~'" & MachineID & "'~'" & strCashier & _
 "'~'" & AppDate & "'"

CashPosFlds = "TOTAmount,"
CashVltFlds = "TOTAmount,"
CashPosValues(0) = "TotAmount" & "-" & TotAmount & "~"
CashVltValues(0) = "nvl(TotAmount,0)" & "+" & TotAmount & "~"
For DenomCount = 1 To 50

    If AdoRsQuery(DenomCount).Value > 0 Then
    
    CashPosFlds = CashPosFlds & AdoRsQuery.Fields(DenomCount).Name & ","
    CashVltFlds = CashVltFlds & AdoRsQuery.Fields(DenomCount).Name & ","
    '**** Addition of Pieces to Vault**********
    
    CashPosValues(0) = CashPosValues(0) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) - " & AdoRsQuery.Fields(DenomCount).Value & "~"
    
    
    '**** Subtraction of  Pieces  From  cashier **********
    
    CashVltValues(0) = CashVltValues(0) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) + " & AdoRsQuery.Fields(DenomCount).Value & "~"
    
    
   
    
    End If
    
Next DenomCount

''''Updating the systemdate and applicationdate,machineid,userid into cashvaultmst
 CashVltFlds = CashVltFlds & " systemdate,applicationdate,UserId,Machineid"
 CashVltValues(0) = CashVltValues(0) & " sysdate" _
                    & "~'" & AppDate & "'~'" & strCashier & "'~'" & MachineID & "'"
 


''''Updating the systemdate and applicationdate,UserId,Machineid,RefundNo into cashcashierposmst
 CashPosFlds = CashPosFlds & " systemdate,applicationdate,UserId,Machineid,RefundNo"
 CashPosValues(0) = CashPosValues(0) & " sysdate" & "~'" & AppDate & "'~'" & strCashier _
                & "'~'" & MachineID & "'~'" & RefundNo & "'" _

'''' CONDITION FOR CASHCASIERPOSMST FOR UPDATE
CashPosCondition = "upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(cashierid))='" & Trim(UCase(REFUNDEDUSERID)) _
& "' and applicationdate= '" & AppDate & "'"


'''' CONDITION FOR CASHVAULTMST FOR UPDATE
CashVltCondition = "upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "'"



'''''' To remove the last 1 char("," "~") from the following string variables
''''
''''''CashVltFlds = Left(CashVltFlds, Len(CashVltFlds) - 1)
''''''CashVltValues(0) = Left(CashVltValues(0), Len(CashVltValues(0)) - 1)

Set objContext = GetObjectContext
Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
StrCondition = QryCondition
' updating the status of from cashier of CashTransBTCashierstrn
TransResult = objTrans.UpdateRecord("Cashrefundstrn", StrFields, strvalues, StrCondition, _
                                        BrCode, strCashier, MachineID, AppDate)


'' updating the row of cashvaultmst
If TransResult = "Trans Completed" Then
TransResult = objTrans.UpdateRecord("CashVaultMst", CashVltFlds, CashVltValues, _
                                    CashVltCondition, BrCode, strCashier, MachineID, AppDate)
Else: GoTo errhand
End If

'Udating the row of TO Cashier of CashCashierposmst
If TransResult = "Trans Completed" Then
TransResult = objTrans.UpdateRecord("CashCashierposmst", CashPosFlds, CashPosValues, _
                                    CashPosCondition, BrCode, strCashier, MachineID, AppDate)
Else: GoTo errhand
End If

objContext.SetComplete
Set objTrans = Nothing
CashRefundAcceptance = "Transaction Completed"
Exit Function


errhand:
If TransResult <> "" Then
objContext.SetAbort
Set objTrans = Nothing
CashRefundAcceptance = TransResult
CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(10), "")
CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(13), "")
Else
CashRefundAcceptance = Err.Number & " : " & Err.Description
CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(10), "")
CashRefundAcceptance = Replace(CashRefundAcceptance, Chr(13), "")
End If


End Function


''''' Method for updating the tables cashtransbtcashierstrn,cashcashierposmst after
''''' acceptance of the cash transfer between cashiers.
Public Function CashTransferAcceptance(BranchCode As String, _
                                            CurrencyCode As String, _
                                            ApplicationDate As String, _
                                            ToCashierID As String, _
                                            FromCashierID As String, _
                                            TransferNo As String, _
                                            MachineID As String, _
                                            Optional ToCounterNo As String, _
                                            Optional FromCounterNo As String) As String
                                             
On Error GoTo errhand
Dim BrCode As String, CurrCode As String, AppDate As String, TransNo As String
Dim ToCashier As String, FromCashier As String, ToCounter As String, FromCounter As String
Dim QryCondition As String, strvalues() As Variant, StrCondition As String
Dim CashPosCondition As String, CashPosValues() As Variant
Dim FromCondition As String, FromValues() As Variant
Dim StrFields As String, CashPosFlds As String
Dim DenomCount As Integer
Dim CashPosInsVal() As Variant

'''' for updating two rows for cashcashierposmst of to cashier and from cahier.

ReDim CashPosValues(1) As Variant
ReDim strvalues(0) As Variant
ReDim CashPosInsVal(0) As Variant
BrCode = UCase(Trim(BranchCode))
CurrCode = UCase(Trim(CurrencyCode))
AppDate = Format(ApplicationDate, "dd-MMM-yyyy")
ToCashier = UCase(Trim(ToCashierID))
FromCashier = UCase(Trim(FromCashierID))
ToCounter = IIf(IsNull(Trim(ToCounterNo)), "", UCase(Trim(ToCounterNo)))
FromCounter = IIf(IsNull(Trim(FromCounterNo)), "", UCase(Trim(FromCounterNo)))
TransNo = TransferNo
CashPosFlds = "" '''''' for concantinating the fields.

StrFields = "nvl(Amount,0) Amount,nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50,Tocounterno"

QryCondition = " upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(fromcashierid))='" & FromCashier & "'" _
& " and upper(trim(tocashierid))='" & ToCashier & "' and upper(trim(status))='P' " _
& " and cashtransferno=" & TransNo


Set AdoRsQuery = CreateObject("ADODB.Recordset")
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set AdoRsQuery = objQuery.SingleRecordSet("CashTransbtCashierstrn", StrFields, QryCondition)
Set objQuery = Nothing
If AdoRsQuery.EOF And AdoRsQuery.BOF Then
CashTransferAcceptance = "Cash Transfer is not done to the " & ToCashier & " Please Check"
CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(10), "")
CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(13), "")
Exit Function
End If


StrFields = IIf(IsNull(Trim(MachineID)), "Status,UserId", "status,UserId,Machineid")
strvalues(0) = IIf(IsNull(Trim(MachineID)), "'A'~'" & ToCashier & "'~", "'A'~'" & ToCashier & "'~'" & MachineID & "'~")

CashPosFlds = "TotAmount,"
CashPosValues(0) = AdoRsQuery!Amount & "+ nvl(TotAmount,0) ~"
CashPosValues(1) = " nvl(TotAmount,0)-" & AdoRsQuery!Amount & "~"
CashPosInsVal(0) = AdoRsQuery!Amount & ","
ToCounter = IIf(IsNull(AdoRsQuery!ToCounterNo), "", AdoRsQuery!ToCounterNo)
For DenomCount = 1 To 50

    If AdoRsQuery(DenomCount).Value > 0 Then
    
    CashPosFlds = CashPosFlds & AdoRsQuery.Fields(DenomCount).Name & ","
    
    ''''****  Pieces Transfered Values To cashier**********
    
    CashPosValues(0) = CashPosValues(0) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) + " & AdoRsQuery.Fields(DenomCount).Value & "~"
    
    
    
    '''''*****  Pieces Transfered Values From cashier******
    
    CashPosValues(1) = CashPosValues(1) & " nvl( " & AdoRsQuery.Fields(DenomCount).Name _
            & ",0) - " & AdoRsQuery.Fields(DenomCount).Value & "~"
    
    CashPosInsVal(0) = CashPosInsVal(0) & AdoRsQuery.Fields(DenomCount).Value & ","
    End If
    
Next DenomCount
  
CashPosFlds = CashPosFlds & "UserId,Machineid,cashtransferno"

CashPosValues(0) = CashPosValues(0) & "'" & ToCashier & "'~'" & MachineID & "'~'" & TransNo & "'"

CashPosValues(1) = CashPosValues(1) & "'" & ToCashier & "'~'" & MachineID & "'~'" & TransNo & "'"

CashPosInsVal(0) = CashPosInsVal(0) & "'" & ToCashier & "','" & MachineID & "','" & TransNo & "'"

''''CashPosFlds = Left(CashPosFlds, Len(CashPosFlds) - 1)
''''CashPosValues(0) = Left(CashPosValues(0), Len(CashPosValues(0)) - 1)
''''CashPosValues(1) = Left(CashPosValues(1), Len(CashPosValues(1)) - 1)

'''''******condition for updating the ToCashier position
StrCondition = QryCondition

CashPosCondition = "upper(trim(Branchcode))='" & BrCode _
                    & "' and upper(trim(currencycode))='" _
                    & CurrCode & "' and upper(trim(cashierid))='" _
                    & ToCashier & "' and applicationdate= '" & AppDate & "'"

''''******condition for updating the FromCashier position
CashPosCondition = CashPosCondition & "| upper(trim(Branchcode))='" & BrCode _
                    & "' and upper(trim(currencycode))='" _
                    & CurrCode & "' and upper(trim(cashierid))='" _
                    & FromCashier & "' and applicationdate= '" & AppDate & "'"

If AdoRsQuery.State = 1 Then AdoRsQuery.Close


StrCondition = " upper(trim(Branchcode))='" & BrCode & "' and upper(trim(currencycode))='" _
& CurrCode & "' and upper(trim(cashierid))='" & ToCashier & "'"

Set AdoRsQuery = CreateObject("ADODB.Recordset")
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set AdoRsQuery = objQuery.SingleRecordSet("cashcashierposmst", "cashierid", StrCondition)
If objQuery.ConnError <> "Connected" Then
    
   CashTransferAcceptance = objQuery.ConnError
   CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(10), "")
   CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(13), "")
   Set objQuery = Nothing
   Exit Function
End If
Set objQuery = Nothing

Set objContext = GetObjectContext
Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
StrCondition = QryCondition
' updating the status of from cashier of CashTransBTCashierstrn
TransResult = objTrans.UpdateRecord("CashTransBTCashierstrn", "status", strvalues, _
                                QryCondition, BrCode, ToCashier, MachineID, AppDate)



' updating of two rows of CashCashierposmst
If TransResult = "Trans Completed" Then

     ''''first checking the existence of the to cashier in cashcashierposmst
     ''''If present then updating the Row or Inserting a New row for ToCashier
     
    If AdoRsQuery.EOF And AdoRsQuery.BOF Then
    Dim FromCashierValUpd() As Variant
    ReDim FromCashierValUpd(0) As Variant
    FromCashierValUpd(0) = CashPosValues(1)
    CashPosCondition = " upper(trim(Branchcode))='" & BrCode _
        & "' and upper(trim(currencycode))='" & CurrCode _
        & "' and upper(trim(cashierid))='" & FromCashier _
        & "' and applicationdate= '" & AppDate & "'"
        ''' and upper(trim(counterno))='" & FromCounter & "'"
        '''' and applicationdate= to_date('" & Format(AppDate, "dd-mmm-yy") & "','dd-mon-yy') "

    
    TransResult = objTrans.UpdateRecord("CashCashierposmst", CashPosFlds, FromCashierValUpd, _
                                    CashPosCondition, BrCode, ToCashier, MachineID, AppDate)
    
    If TransResult = "Trans Completed" Then
        CashPosFlds = CashPosFlds & ",Cashierid,counterno,ApplicationDate,Branchcode,currencycode"
                    
        CashPosInsVal(0) = CashPosInsVal(0) & ",'" & ToCashier & "','" & ToCounter _
        & "','" & AppDate & "','" & BrCode & "','" & CurrCode & "'"
        
        TransResult = objTrans.InsertRecord("CashCashierposmst", CashPosFlds, CashPosInsVal, _
                                            BrCode, ToCashier, MachineID, AppDate)
    End If
    
    Else
    TransResult = objTrans.UpdateRecord("CashCashierposmst", CashPosFlds, CashPosValues, _
                                    CashPosCondition, BrCode, ToCashier, MachineID, AppDate)
    End If
    If TransResult <> "Trans Completed" Then GoTo errhand
Else: GoTo errhand
End If

'Udating the row of TO Cashier of CashCashierposmst
'If TransResult = "Trans Completed" Then
'TransResult = objTrans.UpdateRecord("CashCashierposmst", CashPosFlds, CashPosValues, CashPosCondition)
'Else: GoTo ErrHand
'End If

objContext.SetComplete
Set objTrans = Nothing
CashTransferAcceptance = "Transaction Completed"
Exit Function



errhand:
objContext.SetAbort
Set objTrans = Nothing
If TransResult <> "" Then
CashTransferAcceptance = TransResult
CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(10), "")
CashTransferAcceptance = Replace(CashTransferAcceptance, Chr(13), "")
End If

End Function



'''''Mehtod for Exchange of notes . It updates cashcashierposmst and inserts a row
'''''into cashexchangetrn
Public Function CashExchange(TableName As String, BranchCode As String, _
        CashierId As String, CurrencyCode As String, CounterNo As String, _
        ExSno As Integer, AppDate As Date, UserId As String, _
        MachineID As String, ExcAmt As Long, ArrDenomPieces As Variant, _
        SysDate As String, Nartion As String, Mobil As String, Pan As String, Aadhar As String) As String
Dim TableNm As String
Dim BrCode As String
Dim CashID As String
Dim Curcode As String
Dim CntNo As String
Dim ExcSno As String
Dim AppDt As String
Dim SDate As Date
Dim Narr As String
Dim UsrId As String
Dim MachID As String
Dim ArrPieces As Variant
Dim ExAmt As Long
Dim StrQrytab As String
Dim StrQryFlds As String
Dim StrQryCondition As String
Dim StrQryOrder As String
Dim StrFlds As String
Dim strDenomFldnames As String
Dim strvalues As String
Dim StrInsValues(0) As Variant
Dim StrUpFlds As String
Dim StrUpValues(0) As Variant
Dim StrWhereCondition As String
Dim TransResult As String
Dim ICount As Integer
Dim StrNar As String
Dim strMob As String
Dim strPan As String
Dim strAadar As String


On Error GoTo errhand
'''******* Assiging the Arguments to the variables *********

TableNm = UCase(Trim(TableName))
BrCode = UCase(Trim(BranchCode))
CashID = UCase(Trim(CashierId))
Curcode = UCase(Trim(CurrencyCode))
ExcSno = Trim(ExSno)
AppDt = Format(AppDate, "dd-mmm-yyyy")
SDate = Format(SysDate, "dd-mmm-yyyy")
CntNo = Trim(CounterNo)
'Narr = Narration
UsrId = UCase(Trim(UserId))
MachID = UCase(Trim(MachineID))
ArrPieces = ArrDenomPieces
ExAmt = ExcAmt
StrNar = UCase(Trim(Nartion))
strMob = UCase(Trim(Mobil))
strPan = UCase(Trim(Pan))
strAadar = UCase(Trim(Aadhar))

''''******* storing fields,values,whereconditon,orderby clause of the CashDenominationMst
''''                                   table into the variables


StrQrytab = "CashDenominationMst"
StrQryFlds = " Denominationvalue,Denominationcode,denominationtype "
StrQryCondition = " upper(Currencycode)='" & Curcode & "'"
StrQryOrder = " denominationtype desc,to_number(denominationvalue) desc"

'''''*******Calling the component for fetching the denominationcode respective to the
                ''''currencycode
Set objContext = GetObjectContext

 Set recDenom = CreateObject("ADODB.Recordset")
 Set RecCash = CreateObject("ADODB.Recordset")
 Set RecDenomMst = CreateObject("ADODB.Recordset")
 
 
 Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
 
 Set recDenom = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                        StrQryCondition, StrQryOrder)
                                        
Set ObjFetchRec = Nothing
StrFlds = "BranchCode,currencycode,counterno,cashierid,ApplicationDate,Exsno,NARRATION, MOBILE, PANNO, AADHARNO, userid," & _
            "machineid,exchangeamount,systemdate"
            
strvalues = "'" & BrCode & "','" & Curcode & "','" & CntNo & "','" & CashID & _
            "',to_date('" & AppDt & "','dd/mm/yyyy')," & ExSno & ",'" & StrNar & "','" & strMob & "','" & strPan & "','" & strAadar & "','" & UsrId & _
            "','" & MachID & "'," & ExAmt & ",sysdate"
            
StrWhereCondition = "branchcode='" & BrCode & "' and cashierid='" & CashID & _
                "' and CurrencyCode='" & Curcode & "'"
                
'''-----------------------------------------------------------------------------------------
'''''******** setting the denomination values for inserting and updating  ************
'''''ArrPieces(ICount,0)=Denominations
'''''ArrPieces(ICount,1)=RecievedPieces
'''''ArrPieces(ICount,2)=PaidPieces
'''''ArrPieces(ICount,3)=AvailablePieces
'''''ArrPieces(ICount,4)=Denominationtype
'''-----------------------------------------------------------------------------------------

For ICount = 1 To UBound(ArrPieces)
    recDenom.MoveFirst
    recDenom.Find "denominationtype='" & Trim(ArrPieces(ICount, 4)) & "'"
    recDenom.Find "Denominationvalue='" & Trim(ArrPieces(ICount, 0)) & "'" ' and denominationtype='" & Trim(ArrPieces(Icount, 4)) & "'"
     If Not recDenom.EOF Then
       If (Len(ArrPieces(ICount, 1)) = 0 And Len(ArrPieces(ICount, 2)) <> 0) Then
            strDenomFldnames = strDenomFldnames & recDenom!Denominationcode & ","
        '''***************checking enter pieces are exceeding the available pieces************
           If Val(ArrPieces(ICount, 2)) <= Val(ArrPieces(ICount, 3)) Then
                StrInsValues(0) = StrInsValues(0) & "-" & Trim(ArrPieces(ICount, 2)) & ","
                StrUpValues(0) = StrUpValues(0) & "nvl(" & recDenom(1) & ",0)-" & Trim(ArrPieces(ICount, 2)) & "~"
            Else
                CashExchange = "Record Couldn't Update Due To Enter Exceeding Pieces Than The Available Pieces"
                Exit Function
            End If
        ElseIf (Len(ArrPieces(ICount, 1)) <> 0 And Len(ArrPieces(ICount, 2)) = 0) Then
            strDenomFldnames = strDenomFldnames & recDenom!Denominationcode & ","
            StrInsValues(0) = StrInsValues(0) & "+" & Trim(ArrPieces(ICount, 1)) & ","
            StrUpValues(0) = StrUpValues(0) & "nvl(" & recDenom(1) & ",0)+" & Trim(ArrPieces(ICount, 1)) & "~"
        End If
 End If
Next ICount

'''''''' ******* concatinating the paramerised fieldvalues to the denomination values******

     StrFlds = StrFlds & "," & Left(strDenomFldnames, Len(strDenomFldnames) - 1)
     StrInsValues(0) = strvalues & "," & Left(StrInsValues(0), Len(StrInsValues(0)) - 1)
     StrUpFlds = strDenomFldnames & "userid,machineId"
     StrUpValues(0) = StrUpValues(0) & "'" & UsrId & "'" & "~" & "'" & MachID & "'"
     
     

     '''************calling the general insert update component for updating and inserting
     
   Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    
    '''' ''''********Transaction Started***************
    TransResult = objTrans.InsertRecord(TableNm, StrFlds, StrInsValues)
        If Trim(TransResult) <> "Trans Completed" Then GoTo errhand
    TransResult = objTrans.UpdateRecord("cashcashierposmst", StrUpFlds, StrUpValues, StrWhereCondition)
            
 If Trim(TransResult) <> "Trans Completed" Then GoTo errhand
objContext.SetComplete
Set objTrans = Nothing
CashExchange = "Transaction Sucessful."
Exit Function
errhand:
objContext.SetAbort
Set objTrans = Nothing
Set objContext = Nothing
If Trim(TransResult) <> "" Then
'*************Connection Failed************
    CashExchange = TransResult
    CashExchange = Replace(CashExchange, Chr(10), "")
    CashExchange = Replace(CashExchange, Chr(13), "")
    Exit Function
 Else
    CashExchange = Err.Number & " : " & Err.Description
    CashExchange = Replace(CashExchange, Chr(10), "")
    CashExchange = Replace(CashExchange, Chr(13), "")
 End If

End Function

''''Method  for cash CashPayments. it updates cashcashierposmst,Gentranslog and inserts into
''''Cashpaymentstrn

Public Function CashPayments(BranchCode As String, CurrencyCode As String, _
       ModuleId As String, GLCode As String, AccNo As String, TokenNo As String, _
       CashierId As String, ScrollNo As Double, Amount As Double, Narration As String, _
       Status As String, UserId As String, MachineID As String, VerifiedBy As String, _
       VerifiedMachine As String, ApprovedBy As String, ApprovedMachine As String, _
       ApplicationDate As String, BatchNo As Double, TranNo As Double, _
       ChqNo As String, arrDenom As Variant) As String
    
   '---------------------------------------------------------------
    Dim objInsUpd As Object
    Dim strquerytab As String
    Dim strqueryflds  As String
    Dim StrCondition As String
    Dim strorder As String
    Dim ICount As Integer
    Dim StrTabName As String
    Dim strFldnms As String
    Dim strFldIns As String
    Dim strFldUpd As String
    Dim strfldUpdTrans As String
    Dim strDenomval As String
    Dim strDenupd As String
    Dim strnegden As String
    Dim strFinal As String
    Dim strtemp As String
    Dim arrInsPay(0) As String
    Dim arrUpdCash(0) As String
    Dim arrUpdTrans(0) As String
    Dim strWhereCondCash As String
    Dim strWhereCondTran As String
    Dim strWhereCondTran1 As String
    Dim recDenom As ADODB.Recordset, recAcc As ADODB.Recordset
    Dim recTeller As ADODB.Recordset
    Dim StrInsUpd As String, AccHolderName As String, AccHolderBrCode As String
    Dim strTellerYN As String
    
    On Error GoTo errhand
    StrInsUpd = ""
    '--------------Querying DenominationMst to get Denominations----------------------
    strquerytab = "CashDenominationMst"
    strqueryflds = " Denominationvalue,Denominationcode,denominationtype "
    StrCondition = " upper(trim(Currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & "'"
    strorder = " substr(denominationtype,1,1) desc, substr(denominationtype,2,1) , " _
                 & " to_number( denominationvalue) desc"
     
    
    Set recDenom = CreateObject("ADODB.Recordset")
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set recDenom = objQuery.SingleRecordSet(strquerytab, strqueryflds, _
                                        StrCondition, strorder)
           
     
    If objQuery.ConnError <> "Connected" Then
            
            CashPayments = objQuery.ConnError
            CashPayments = Replace(CashPayments, Chr(10), "")
            CashPayments = Replace(CashPayments, Chr(13), "")
            objQuery = Nothing
            Exit Function
    End If
    'StrInsUpd = objQuery.connerror
    '''Set objQuery = Nothing
    '--------------Finding DenominationCode from DenominationMst, using DenominationValue _
     and DenominationType
   
    For ICount = 0 To UBound(arrDenom)
          
        recDenom.MoveFirst
        recDenom.Filter = "Denominationvalue='" & Trim(arrDenom(ICount, 0)) & "' and " & UCase("denominationtype='") & UCase(Trim(arrDenom(ICount, 3))) & "'"
        
    '--------------Concatinating Denomination Code and Denomination Values to insert and _
     update tables
       
       If Not recDenom.EOF Then
              strFldnms = strFldnms & "," & recDenom!Denominationcode
         
              strFldUpd = recDenom!Denominationcode
         
              strDenomval = strDenomval & "," & Val(arrDenom(ICount, 1)) - _
                            Val(arrDenom(ICount, 2))
         
              strDenupd = Val(arrDenom(ICount, 1))
         
    '-------------If User accepts any denominations from customer then.....
     
              If Val(arrDenom(ICount, 2)) > 0 Then
          
                    strnegden = (Val(arrDenom(ICount, 1)) - Val(arrDenom(ICount, 2)))
          
                    If Val(arrDenom(ICount, 1)) > Val(arrDenom(ICount, 2)) Then
                       'strFinal = "NVL(" & strFldUpd & ",0)" & "-" & Abs(strnegden)
                       strFinal = "NVL(" & strFldUpd & ",0)" & "+" & Abs(strnegden)
                    Else
                       'strFinal = "NVL(" & strFldUpd & ",0)" & "+" & Abs(strnegden)
                       strFinal = "NVL(" & strFldUpd & ",0)" & "-" & Abs(strnegden)
          
                    End If
                       
              Else
                    'strFinal = "NVL(" & strFldUpd & ",0)" & "-" & strDenupd
                     strFinal = "NVL(" & strFldUpd & ",0)" & "+" & strDenupd
              End If
                 
              strFinal = strtemp & "~" & strFinal
              strtemp = strFinal
          
     End If
   Next ICount
     
   '-------------Storing field names and values for inserting into cashpaymentstrn-----------------
       
    'Code altered and added on 22 May 2008
    'Reason: Get Name and Branch code of A/C holder to whom money was being paid
    
    Set recAcc = CreateObject("ADODB.Recordset")
    Set recAcc = objQuery.SingleRecordSet("GENTRANSLOG", "branchcode,nvl(name,'')", _
        "( (branchcode='" & BranchCode & "' AND abbyn <> 'Y') OR (abbbranchcode='" & _
        BranchCode & "' AND abbyn='Y') ) AND batchno=" & BatchNo & _
        " AND tranno = " & TranNo)
            
    If objQuery.ConnError <> "Connected" Then
        CashPayments = objQuery.ConnError
        CashPayments = Replace(CashPayments, Chr(10), "")
        CashPayments = Replace(CashPayments, Chr(13), "")
        objQuery = Nothing
        Exit Function
    ElseIf recAcc.EOF = True Then
        CashPayments = "Unable to get details of given Batch " & BatchNo & _
        " and Transaction " & TranNo & " from its Log"
        CashPayments = Replace(CashPayments, Chr(10), "")
        CashPayments = Replace(CashPayments, Chr(13), "")
        objQuery = Nothing
        Exit Function
    End If
    AccHolderBrCode = IIf(IsNull(recAcc(0).Value), BranchCode, recAcc(0).Value)
    AccHolderName = IIf(IsNull(recAcc(1).Value), "", recAcc(1).Value)
   
'    strFldIns = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,TOKENNO,CASHIERID," & _
'                  "PAYMENTSCROLLNO,AMOUNT,NARRATION,STATUS,UserId,MachineID," & _
'                  "VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
'                  "APPLICATIONDATE,SYSTEMDATE,TRANNO,CHQNO" & strFldnms
'
'      arrInsPay(0) = "'" & BranchCode & "','" & CurrencyCode & "','" & ModuleId & "','" & _
'                     GLCode & "','" & AccNo & "','" & TokenNo & "','" & CashierId & _
'                     "','" & ScrollNo & "','" & Amount & "','" & Narration & "','" & _
'                     Status & "','" & UserId & "','" & MachineID & "','" & _
'                     VerifiedBy & "','" & VerifiedMachine & "','" & ApprovedBy & "','" & _
'                     ApprovedMachine & "','" & Format(CDate(ApplicationDate), "dd-mmm-yyyy") & _
'                     "',sysdate,'" & TranNo & "','" & ChqNo & "'" & strDenomval
                 
    strFldIns = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,TOKENNO,CASHIERID," & _
                  "PAYMENTSCROLLNO,AMOUNT,NARRATION,STATUS,UserId,MachineID," & _
                  "VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                  "APPLICATIONDATE,SYSTEMDATE,TRANNO,CHQNO,NAME, ACCBRANCHCODE" & strFldnms
              
      arrInsPay(0) = "'" & BranchCode & "','" & CurrencyCode & "','" & ModuleId & "','" & _
                     GLCode & "','" & AccNo & "','" & TokenNo & "','" & CashierId & _
                     "','" & ScrollNo & "','" & Amount & "','" & Narration & "','" & _
                     Status & "','" & UserId & "','" & MachineID & "','" & _
                     VerifiedBy & "','" & VerifiedMachine & "','" & ApprovedBy & "','" & _
                     ApprovedMachine & "','" & Format(CDate(ApplicationDate), "dd-mmm-yyyy") & _
                     "',sysdate,'" & TranNo & "','" & ChqNo & "'" & _
                     ",'" & AccHolderName & "','" & AccHolderBrCode & "'" & strDenomval
    'End of altered code added on 22 May 2008
    '---------------------------------------------------------------
   
    '-------------Storing field names and values for updating Cashcashierposmst------------------------
                      
      strFldUpd = "BranchCode,CurrencyCode,CashierId," & _
                  "UserId,MachineID,VerifiedBy,VerifiedMachine,ApprovedBy," & _
                  "ApprovedMachine,ApplicationDate,SystemDate,Narration,TOTAMOUNT" & _
                   strFldnms
            
      arrUpdCash(0) = "'" & BranchCode & "'~'" & CurrencyCode & "'~'" & _
                     CashierId & "'~'" & UserId & "'~'" & MachineID & "'~'" & VerifiedBy & "'~'" & _
                     VerifiedMachine & "'~'" & ApprovedBy & "'~'" & ApprovedMachine & _
                     "'~'" & Format(CDate(ApplicationDate), "dd-mmm-yyyy") & _
                     "'~sysdate~'" & Narration & "'~" & "nvl(totamount,0)-" & Amount & _
                     strtemp
                          
             
      strWhereCondCash = "trim(branchcode)='" & CStr(Trim(BranchCode)) & "' and upper(trim(currencycode))='" & _
                     CStr(UCase(Trim(CurrencyCode))) & "' and upper(trim(cashierid))='" & CStr(UCase(Trim(CashierId))) & "'"
      
      
   '---------------------------------------------------------------
   
   '-------------Storing field names and values for Updating gentranslog------------------------------
                 
      'strfldUpdTrans = "cashpaidyn,cashierid,userid,MachineID"
      strfldUpdTrans = "cashpaidyn,cashierid"
      
      'code commented and written by Radhika on 22 May 2008
      'Reason: ABB Transactions were not handled properly
'      strWhereCondTran1 = " trim(branchcode)='" & CStr(Trim(BranchCode)) & _
'                         "' and upper(trim(currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & _
'                         "' and trim(batchno)='" & Trim(CDbl(BatchNo)) & "'"
      
      
      'mahender add tran no
      'strWhereCondTran1 = " ( (branchcode='" & Trim(BranchCode) & "' AND abbyn <> 'Y') " & _
      '                  " OR (abbbranchcode='" & Trim(BranchCode) & "' AND abbyn='Y') )" & _
      '                 " and upper(trim(currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & _
      '                "' and trim(batchno)='" & Trim(CDbl(BatchNo)) & "'"
      
      strWhereCondTran1 = " ( (branchcode='" & Trim(BranchCode) & "' AND abbyn <> 'Y') " & _
                         " OR (abbbranchcode='" & Trim(BranchCode) & "' AND abbyn='Y') )" & _
                         " and upper(trim(currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & _
                         "' and trim(batchno)='" & Trim(CDbl(BatchNo)) & "' and trim(tranno)='" & Trim(CDbl(TranNo)) & "'"
      'end of code commented and written by Radhika on 22 May 2008


      'code commented and written by Radhika on 22 May 2008
      'Reason: ABB Transactions were not handled properly
'      strWhereCondTran = " trim(branchcode)='" & CStr(Trim(BranchCode)) & _
'                         "' and upper(trim(currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & _
'                         "' and trim(batchno)='" & Trim(CDbl(BatchNo)) & _
'                         "' and trim(tranno)='" & Trim(CDbl(TranNo)) & "'"
                         
      strWhereCondTran = " ( trim(branchcode)='" & CStr(Trim(BranchCode)) & "'" & _
                         " or trim(branchcode)='" & CStr(Trim(AccHolderBrCode)) & "' )" & _
                         " and upper(trim(currencycode))='" & CStr(UCase(Trim(CurrencyCode))) & _
                         "' and trim(batchno)='" & Trim(CDbl(BatchNo)) & _
                         "' and trim(tranno)='" & Trim(CDbl(TranNo)) & "'"
      'end of code commented and written by Radhika on 22 May 2008
                         
      'strWhereCondTran = " trim(branchcode)='" & CStr(Trim(BranchCode)) & "' and upper(trim(currencycode))='" & _
                         CStr(UCase(Trim(CurrencyCode))) & _
                         "' and to_char(applicationdate,'DD-Mon-YYYY')=" & _
                         "to_date('" & Format(ApplicationDate, "dd-mmm-yyyy") & "','DD-Mon-YYYY')" & _
                         " and trim(tranno)='" & Trim(CDbl(TranNo)) & "'"
      
      'arrUpdTrans(0) = "'Y'~'" & CStr(CashierId) & "'~'" & CStr(UserId) & "'~'" & _
                       CStr(MachineID) & "'"
       arrUpdTrans(0) = "'Y'~'" & CStr(CashierId) & "'"
      
   '---------------------------------------------------------------
  
      strTellerYN = "N"
      strquerytab = "CASHTELLERPAYMENTSTRANDAY"
      strqueryflds = "batchno"
      Set recTeller = CreateObject("ADODB.Recordset")
      Set recTeller = objQuery.SingleRecordSet(strquerytab, strqueryflds, strWhereCondTran)
    
            If objQuery.ConnError <> "Connected" Then
                  CashPayments = objQuery.ConnError
                  CashPayments = Replace(CashPayments, Chr(10), "")
                  CashPayments = Replace(CashPayments, Chr(13), "")
                  objQuery = Nothing
                  Exit Function
            End If
            If recTeller.RecordCount > 0 Then
               strTellerYN = "Y"
            End If
            Set objQuery = Nothing
   '---------------------------------------------------------------
      Set objContext = GetObjectContext
      
      Set objInsUpd = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
      
      StrInsUpd = objInsUpd.InsertRecord("CASHPAYMENTSTRN", strFldIns, arrInsPay)
      
                  If StrInsUpd <> "Trans Completed" Then
                     GoTo errhand
                  End If
      
      StrInsUpd = objInsUpd.UpdateRecord("CASHCASHIERPOSMST", strFldUpd, arrUpdCash, strWhereCondCash)
      
                 If StrInsUpd <> "Trans Completed" Then
                    GoTo errhand
                 End If
                 
      StrInsUpd = objInsUpd.UpdateRecord("GENTRANSLOG", strfldUpdTrans, _
                              arrUpdTrans, strWhereCondTran1)
      
                  If StrInsUpd <> "Trans Completed" Then
                     GoTo errhand
                  End If
      
      If strTellerYN = "Y" Then
            StrInsUpd = objInsUpd.UpdateRecord("CASHTELLERPAYMENTSTRANDAY", strfldUpdTrans, _
                              arrUpdTrans, strWhereCondTran)
      
                  If StrInsUpd <> "Trans Completed" Then
                     GoTo errhand
                  End If
      End If
      objContext.SetComplete
   '---------------------------------------------------------------
      
      
      Set objInsUpd = Nothing
      Set objContext = Nothing
      CashPayments = "Transaction No : " & TranNo & " Completed "
      Exit Function
     
errhand:
''        If StrInsUpd <> "Connected" Then
''            CashPayments = objQuery.connerror
''            objQuery = Nothing
''            Exit Function
       
        
        If StrInsUpd <> "" Then
            objContext.SetAbort
            Set objContext = Nothing
            CashPayments = StrInsUpd
        Else
            
            CashPayments = Err.Number & " : " & Err.Description
            CashPayments = Replace(CashPayments, Chr(10), "")
            CashPayments = Replace(CashPayments, Chr(13), "")
            
        End If
        
        
        
End Function




