VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "Queries"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim DataLink As String
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection  ' Connection Object
Dim Rstemp As ADODB.Recordset
Dim ICount As Integer
Dim objtrans As Object
Dim ObjFetchRec As Object
Dim rsdenom As ADODB.Recordset
Dim intres() As String
Dim strCashDenomFlds As String
Dim ObjQuery As Object
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim ArrError As Variant
Dim objError As Object

Public Function CashAcceptancePending(BranchCode As String, CurrencyCode As String, _
                                      Applicationdate As String, StatusOF As String, _
                                      MachineID As String, Optional CashierID As String, _
                                      Optional CounterNo As String) As ADODB.Recordset
                                      
Dim StrQuery As String, strUserQry As String, StrPendingQry As String
Dim strBRCode As String, strCurrency As String, strCashierID As String
Dim strCounterNo As String, dtAppDate As String, strtabname As String
Dim FldCashier As String, FldCounter As String, fldAcceptTRNno As String

On Error GoTo errhand
Call DBConnection
If ConnError <> "Connected" Then Exit Function

strBRCode = Trim(BranchCode)
strCurrency = Trim(CurrencyCode)
strCashierID = Trim(CashierID)
strCounterNo = Trim(CounterNo)
dtAppDate = Applicationdate

If Trim(UCase(StatusOF)) = "ACCEPTANCE" Then
        strtabname = "CASHALLOTMENTSTRN"
        FldCashier = "cashierid"
        FldCounter = "CounterNo"
        fldAcceptTRNno = "ALLOTMENTNO"
        
ElseIf Trim(UCase(StatusOF)) = "TRANSFER" Then
        strtabname = "CASHTRANSBTCASHIERSTRN"
        FldCashier = "TOCASHIERID"
        FldCounter = "TOCOUNTERNO"
        fldAcceptTRNno = "CASHTRANSFERNO"
        
ElseIf Trim(UCase(StatusOF)) = "REFUND" Then
        strtabname = "CASHREFUNDSTRN"
        FldCashier = "REFUNDEDUSERID"
        FldCounter = "COUNTERNO"
        fldAcceptTRNno = "REFUNDNO"
End If

''StrQuery = "select cash." & FldCashier & " CASHIERID, cash." & FldCounter & " COUNTERNO, " _
& " count(cash." & fldAcceptTRNno & ") PENDINGTRANSCOUNT, genuser.Name CASHIERNAME from " _
& strtabname & DataLink & " cash, genusermst" & DataLink & " genuser where genuser.userid in " _
& "(select userid from genusermst" & DataLink & " where userid=cash." & FldCashier _
& " and upper(trim(branchcode))='" & strBRCode & "') and upper(trim(cash.status))='P'" _
& " and upper(trim(cash.branchcode))='" & strBRCode & "' and upper(trim(cash.currencycode))='" _
& strCurrency & "' group by cash." & FldCashier & ", cash." & FldCounter & ", genuser.Name"

StrQuery = "select cash." & FldCashier & " CASHIERID, cash." & FldCounter & " COUNTERNO, " _
& " count(cash." & fldAcceptTRNno & ") PENDINGTRANSCOUNT, genuser.Name CASHIERNAME,cash.STATUS status from " _
& strtabname & DataLink & " cash, genusermst" & DataLink & " genuser where genuser.userid in " _
& "(select userid from genusermst" & DataLink & " where userid=cash." & FldCashier _
& " and upper(trim(branchcode))='" & strBRCode & "') " _
& " and upper(trim(cash.branchcode))='" & strBRCode & "' and upper(trim(cash.currencycode))='" _
& strCurrency & "' group by cash." & FldCashier & ", cash." & FldCounter & ", genuser.Name, " _
& " cash.STATUS ORDER BY cash.STATUS DESC"

Set Rstemp = CreateObject("Adodb.Recordset")
Set Rstemp = AdoConnObj.Execute(StrQuery)

Set CashAcceptancePending = Rstemp
Rstemp.ActiveConnection = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
Exit Function

errhand:

ConnError = Err.Number & " : " & Err.Description

LogError "CashAcceptancePending", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
End Function

''Private Sub DBConnection()
''
''Dim objdblink As Object
''
''Dim ArrLink As Variant
''
'''************Oppening the connection to dblink*************
''On Error GoTo errhand
'''''' calling shared property manager for dblink
''
''Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''DataLink = objdblink.GetDBLink
''Set objdblink = Nothing
''ArrLink = Split(DataLink, ",", -1)
''If UBound(ArrLink) < 2 Then
''    ConnError = ArrLink(0)
''    Exit Sub
''ElseIf UBound(ArrLink) = 2 Then
''    DataLink = ""
''ElseIf UBound(ArrLink) = 3 Then
''    DataLink = Trim(ArrLink(3))
''End If
''
''ConnError = ""
''Set AdoConnObj = CreateObject("Adodb.Connection")
''AdoConnObj.CursorLocation = adUseClient
''AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''''''AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=v3;User ID=v3"
''If AdoConnObj.State = 1 Then ConnError = "Connected"
''Exit Sub
''
''errhand:
''ConnError = "Connection Failed." & Err.Number & Err.Description
''End Sub


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With
''
''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
LogError "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub


Public Function CashDenominationsAsArray(CashTableName As String, BranchCode As String, _
                                            CurrencyCode As String, _
                                            Optional Applicationdate As String, _
                                            Optional CashieridVal As String, _
                                            Optional CounternoVal As String, _
                                            Optional TransNoVal As String, _
                                            Optional AllDenomsYN As String, _
                                            Optional PipeLineTranYN As String) As Variant
                                  
Dim StrQuery As String, strDenomQry As String, StrPendingQry As String
Dim strBRCode As String, strCurrency As String, strCashierID As String
Dim strCounterNo As String, dtAppDate As String, CashTable As String
Dim rsdenom As ADODB.Recordset, StrFlds As String, StrTables As String
Dim strcondition As String, strOrder As String
Dim StrDenomValue As String, RowCnt As Integer
Dim VarDenomValue() As Variant, strcashflds As String
Dim ObjContext As ObjectContext, strCashCondition As String
Dim CashierFldName As String
Dim CounterFldName As String
Dim ArrCashPieces As Variant
Dim Arrtemp() As Variant
Dim strTransNo As String

'Call DBConnection
'If ConnError <> "Connected" Then Exit Function
On Error GoTo errhand

CashTable = UCase(Trim(CashTableName))
strBRCode = UCase(Trim(BranchCode))
strCurrency = UCase(Trim(CurrencyCode))
strCashierID = IIf(IsNull(CashieridVal), "", CashieridVal)
strCounterNo = IIf(IsNull(CounternoVal), "", CounternoVal)
dtAppDate = IIf(IsNull(Applicationdate), " ", Format(Applicationdate, "dd-mmm-yy"))
strDenomQry = ""
StrQuery = ""
If Trim(TransNoVal) <> "" Then strTransNo = Trim(TransNoVal)

''''' database collumn names of counterno and cashierid for retrieving denominations
''''' from cash transaction tables (TRN tables), for acceptance screens
 
 
 
 
If CashTable = "" Then
    ReDim VarDenomValue(0, 0) As Variant
    VarDenomValue(0, 0) = "Please Enter Tablename. CashierID or CounterNo required for any table " _
    & " other than CASHVAULTMST for Setting Denominations"
    CashDenominationsAsArray = VarDenomValue
    Exit Function
End If

'strDenomQry = "select Denominationvalue,denominationcode,denominationtype from cashdenominationmst" & DataLink & " where " _
'& " upper(currencycode)='" & strCurrency & "' order by substr(denominationtype,1,1) desc, substr(denominationtype,2,1) " _
'& " desc,to_number(denominationvalue) desc"
    
''''' Extracting denominationcodes and denominationvalues from cashdenominationsmst
    
StrTables = "CashDenominationMst CashDenom,GenCurrencytypeMst CurrencyMst"

StrFlds = "CashDenom.Denominationvalue Denominationvalue," _
& "CashDenom.denominationcode denominationcode," _
& "CashDenom.denominationtype denominationtype," _
& "Currencymst.precision PreCIsion"

strcondition = " upper(cashdenom.currencycode)='" & strCurrency _
& "' and upper(currencymst.currencycode)='" & strCurrency & "'"

strOrder = " substr(denominationtype,1,1) desc, substr(denominationtype,2,1) , " _
& " to_number( denominationvalue) desc"


Set ObjContext = GetObjectContext
Set rsdenom = CreateObject("Adodb.Recordset")
''Set Rstemp = CreateObject("Adodb.Recordset")
Set ObjQuery = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")


Set rsdenom = ObjQuery.singlerecordset(StrTables, StrFlds, strcondition, strOrder)
If ObjQuery.ConnError <> "Connected" Then
    ReDim VarDenomValue(0, 0) As Variant
    VarDenomValue(0, 0) = ObjQuery.ConnError
    Set ObjQuery = Nothing
    CashDenominationsAsArray = VarDenomValue
    
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    ''If Rstemp.State = 1 Then Rstemp.Close
    ''Set Rstemp = Nothing
    Exit Function
End If

If rsdenom.EOF And rsdenom.BOF Then
    ReDim VarDenomValue(0, 0) As Variant
    VarDenomValue(0, 0) = "No Denominations For This Currency"
    CashDenominationsAsArray = VarDenomValue
    
    Set ObjQuery = Nothing
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    ''If Rstemp.State = 1 Then Rstemp.Close
    ''Set Rstemp = Nothing
    Exit Function
    End If
    
 Set ObjQuery = Nothing
 
''''' common collumn from cashtable like vault,Cashcasierposmst,all cash transaction tables.
strCashDenomFlds = ""
rsdenom.MoveFirst

'''' concantinating the collumn names like (D1,D2,D3,.....D50) for any cash tables based on
'''' the values of denominationcode collumn of the cashdenominationmst table

Do While Not rsdenom.EOF

    strCashDenomFlds = strCashDenomFlds & ",nvl(sum(" & rsdenom!denominationcode & "),0) " _
                        & rsdenom!denominationcode & " "
    
    rsdenom.MoveNext

Loop

strCashDenomFlds = Mid(strCashDenomFlds, 2)


If CashTable = "CASHVAULTMST" Then          '''' Start of first IF loop

    ''''''finding denomination pieces from vault table
    ArrCashPieces = CashInVault(strBRCode, strCurrency, dtAppDate)



ElseIf CashTable = "CASHCASHIERPOSMST" Then

    ''''''finding denomination pieces from cashcashierposmst table
    If Trim(PipeLineTranYN) = "" Then  ''''consider pipeline transactions
        ArrCashPieces = CashInCashierPosition(strBRCode, strCurrency, strCashierID, "Y")
    ElseIf Trim(PipeLineTranYN) = "N" Then  ''''do not consider pipeline transactions
        ArrCashPieces = CashInCashierPosition(strBRCode, strCurrency, strCashierID, "N")
    ElseIf Trim(PipeLineTranYN) = "Y" Then  ''''consider pipeline transactions
        ArrCashPieces = CashInCashierPosition(strBRCode, strCurrency, strCashierID, "Y")
    End If
''''''finding denomination pieces from CASHALLOTMENTSTRN table
ElseIf CashTable = "CASHALLOTMENTSTRN" Then
        If TransNoVal = "" Then
            ReDim VarDenomValue(0, 0) As Variant
            VarDenomValue(0, 0) = "Please Send AllotmentNo."
            CashDenominationsAsArray = VarDenomValue
            
            If rsdenom.State = 1 Then rsdenom.Close
            Set rsdenom = Nothing
            ''If Rstemp.State = 1 Then Rstemp.Close
            ''Set Rstemp = Nothing
            
            Exit Function
        End If
    ArrCashPieces = CashInAllotmentsTRN(strBRCode, strCurrency, strCashierID, strTransNo)

''''''finding denomination pieces from CASHREFUNDSTRN table
ElseIf CashTable = "CASHREFUNDSTRN" Then
        If TransNoVal = "" Then
            ReDim VarDenomValue(0, 0) As Variant
            VarDenomValue(0, 0) = "Please Send RefundNo."
            CashDenominationsAsArray = VarDenomValue
            
            If rsdenom.State = 1 Then rsdenom.Close
            Set rsdenom = Nothing
            ''If Rstemp.State = 1 Then Rstemp.Close
            ''Set Rstemp = Nothing
            
            Exit Function
        End If
    ArrCashPieces = CashInRefundsTRN(strBRCode, strCurrency, strCashierID, strTransNo)


''''''finding denomination pieces from CASHTRANSBTCASHIERSTRN table

ElseIf CashTable = "CASHTRANSBTCASHIERSTRN" Then
        If TransNoVal = "" Then
            ReDim VarDenomValue(0, 0) As Variant
            VarDenomValue(0, 0) = "Please Send AllotmentNo."
            CashDenominationsAsArray = VarDenomValue
                                    
            If rsdenom.State = 1 Then rsdenom.Close
            Set rsdenom = Nothing
            ''If Rstemp.State = 1 Then Rstemp.Close
            ''Set Rstemp = Nothing
            
            Exit Function
        End If
    ArrCashPieces = CashInTransfersTRN(strBRCode, strCurrency, strCashierID, strTransNo)
        



End If          '''''end of 1st if loop

If UBound(ArrCashPieces) > 0 Then

    ReDim VarDenomValue(UBound(ArrCashPieces), 3)
    rsdenom.MoveFirst
RowCnt = 0

        For ICount = 0 To UBound(ArrCashPieces) - 1
            If UCase(Trim(AllDenomsYN)) = "Y" Then
                VarDenomValue(ICount, 0) = rsdenom!denominationtype
                VarDenomValue(ICount, 1) = rsdenom!denominationvalue
                VarDenomValue(ICount, 2) = ArrCashPieces(ICount, 1)
                VarDenomValue(ICount, 3) = rsdenom!Precision
            Else
                If Trim(ArrCashPieces(ICount, 1)) > 0 Then
              
        
                      VarDenomValue(RowCnt, 0) = rsdenom!denominationtype
                      VarDenomValue(RowCnt, 1) = rsdenom!denominationvalue
                      VarDenomValue(RowCnt, 2) = ArrCashPieces(ICount, 1)
                      VarDenomValue(RowCnt, 3) = rsdenom!Precision
                      RowCnt = RowCnt + 1
         
                End If
                            
            End If
                rsdenom.MoveNext
        Next ICount

Else

    ReDim VarDenomValue(0, 0) As Variant
    VarDenomValue(0, 0) = ArrCashPieces(0, 0)
    
End If

CashDenominationsAsArray = VarDenomValue

            
If rsdenom.State = 1 Then rsdenom.Close
Set rsdenom = Nothing
''If Rstemp.State = 1 Then Rstemp.Close
''Set Rstemp = Nothing
            
Exit Function

errhand:
ReDim VarDenomValue(0, 0) As Variant

VarDenomValue(0, 0) = Err.Number & " : " & Err.Description


CashDenominationsAsArray = VarDenomValue
            
LogError "CashDenominationsAsArray", Err.Number, Err.Description

If rsdenom.State = 1 Then rsdenom.Close
Set rsdenom = Nothing
''If Rstemp.State = 1 Then Rstemp.Close
''Set Rstemp = Nothing
            

End Function

Public Function CashDenominationsAsString(CashTableName As String, BranchCode As String, _
                                  CurrencyCode As String, Optional Applicationdate As String, _
                                  Optional CashierID As String, Optional CounterNo As String) As String
                                  
Dim StrQuery As String, strDenomQry As String, StrPendingQry As String
Dim strBRCode As String, strCurrency As String, strCashierID As String
Dim strCounterNo As String, dtAppDate As String, CashTable As String
Dim rsdenom As ADODB.Recordset
Dim StrDenomValue As String, RowCnt As Integer
Dim VarDenomValue() As Variant

Call DBConnection
If ConnError <> "Connected" Then Exit Function
On Error GoTo errhand
CashTable = UCase(Trim(CashTableName))
strBRCode = UCase(Trim(BranchCode))
strCurrency = UCase(Trim(CurrencyCode))
strCashierID = Trim(CashierID)
strCounterNo = Trim(CounterNo)
dtAppDate = Applicationdate
strDenomQry = ""
StrQuery = ""
If CashTable = "" Then
    CashDenominationsAsString = "Please Enter Tablename. CashierID or CounterNo required for any table " _
    & " other than CASHVAULTMST for Setting Denominations"
    
    CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(10), "")
    CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(13), "")
    
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
    Exit Function
Else
strDenomQry = "select Denominationvalue,denominationcode,denominationtype from cashdenominationmst" & DataLink & " where " _
& " upper(currencycode)='" & strCurrency & "' order by denominationtype desc,to_number(denominationvalue) desc"


    If CashTable = "CASHVAULTMST" Then

StrQuery = "select nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50 from Cashvaultmst" & DataLink & " where upper(currencycode)='" _
& strCurrency & "' and upper(branchcode)='" & strBRCode & "'"
'and to_date(applicationdate,'dd-mon-yy'='to_date('" _
'& Format(dtAppDate, "dd-mmm-yy") & "','dd-mon-yy')"



    ElseIf strCashierID <> "" Then
        If CashTable = "" Then
        CashDenominationsAsString = "Please Enter Tablename, CashierID or CounterNo for Setting Denominations"
        CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(10), "")
        CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(13), "")
        
        If rsdenom.State = 1 Then rsdenom.Close
        Set rsdenom = Nothing
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
    
        Exit Function
        End If
StrQuery = "select nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50 from " _
& Trim(CashTable) & Trim(DataLink) & " where upper(currencycode)='" _
& strCurrency & "' and upper(branchcode)='" & strBRCode & "' and upper(counterno)='" _
& strCounterNo & "'"
'and to_date(applicationdate,'dd-mon-yy'='to_date('" _
'& Format(dtAppDate, "dd-mmm-yy") & "','dd-mon-yy')"




ElseIf strCounterNo <> "" Then

    If CashTable = "" Then
        CashDenominationsAsString = "Please Enter Tablename, CashierID or CounterNo for Setting Denominations"
        CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(10), "")
        CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(13), "")
        
                
        If rsdenom.State = 1 Then rsdenom.Close
        Set rsdenom = Nothing
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
    
        Exit Function
    End If

StrQuery = "select nvl(D1,0) D1,nvl(D2,0) D2,nvl(D3,0) D3,nvl(D4,0) D4,nvl(D5,0) D5,nvl(D6,0) D6,nvl(D7,0) D7," _
& "nvl(D8,0) D8,nvl(D9,0) D9,nvl(D10,0) D10,nvl(D11,0) D11,nvl(D12,0) D12,nvl(D13,0) D13,nvl(D14,0) D14,nvl(D15,0) D15," _
& "nvl(D16,0) D16,nvl(D17,0) D16,nvl(D18,0) D18,nvl(D19,0) D19,nvl(D20,0) D20,nvl(D21,0) D21,nvl(D22,0) D22,nvl(D23,0) D23," _
& "nvl(D24,0) D24,nvl(D25,0) D25,nvl(D26,0) D26,nvl(D27,0) D27,nvl(D28,0) D28,nvl(D29,0) D29,nvl(D30,0) D30,nvl(D31,0) D31," _
& "nvl(D32,0) D32,nvl(D33,0) D33,nvl(D34,0) D34,nvl(D35,0) D35,nvl(D36,0) D36,nvl(D37,0) D37,nvl(D38,0) D38," _
& "nvl(D39,0) D39,nvl(D40,0) D40,nvl(D41,0) D41,nvl(D42,0) D42,nvl(D43,0) D43 ,nvl(D44,0) D44,nvl(D45,0) D45,nvl(D46,0) D46," _
& "nvl(D47,0) D47,nvl(D48,0) D48,nvl(D49,0) D49 ,nvl(D50,0) D50 from " _
& Trim(CashTable) & Trim(DataLink) & " where upper(currencycode)='" _
& strCurrency & "' and upper(branchcode)='" & strBRCode & "' and upper(cashierid)='" _
& strCashierID & "'"
'and to_date(applicationdate,'dd-mon-yy'='to_date('" _
'& Format(dtAppDate, "dd-mmm-yy") & "','dd-mon-yy')"

End If

End If
Set Rstemp = CreateObject("Adodb.Recordset")
Rstemp.Open StrQuery, AdoConnObj, adOpenDynamic
Set rsdenom = CreateObject("Adodb.Recordset")
rsdenom.Open strDenomQry, AdoConnObj, adOpenDynamic
Set AdoConnObj = Nothing
For ICount = 0 To 49
rsdenom.MoveFirst
If Rstemp.Fields(ICount).Value > 0 Then
  rsdenom.Find "DenominationCode='" & UCase(Rstemp.Fields(ICount).Name) & "'"
  If Not rsdenom.EOF Then
  'VarDenomValue(RowCnt, 0) = Rsdenom!denominationtype
  'VarDenomValue(RowCnt, 1) = Rsdenom!denominationvalue
  'VarDenomValue(RowCnt, 2) = Rstemp.Fields(ICount).Value
  StrDenomValue = StrDenomValue & rsdenom!denominationtype & ", " & rsdenom!denominationvalue & "|" & Rstemp.Fields(ICount).Value & "&"
  'RowCnt = RowCnt + 1
  End If
End If
Next ICount
CashDenominationsAsString = StrDenomValue
CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(10), "")
CashDenominationsAsString = Replace(CashDenominationsAsString, Chr(13), "")

        
If rsdenom.State = 1 Then rsdenom.Close
Set rsdenom = Nothing
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    
Exit Function

errhand:
        
LogError "CashDenominationsAsString", Err.Number, Err.Description

If rsdenom.State = 1 Then rsdenom.Close
Set rsdenom = Nothing
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing


'CashDenominationsAsString = Err.Number & " : " & Err.Description
End Function


Public Function CashInEachBranch _
    (BranchCode As String, CurrencyCode As String) As Variant
    '/*---varaible declaration---*/
    Dim StrFields As String
    Dim strfields1 As String
    Dim intcount As Integer
    Dim intfcount As Integer
    Dim strcondition As String
    Dim intval As Double
    Dim inttemp(50, 5) As Variant
    
    Dim inttemp1(50, 5) As Variant
    Dim rscashposmst As Recordset
    Dim rscashvalt As Recordset
    Dim rsprec As Recordset
    Dim StrDenomValue As String
    Dim ICount As Integer
    Dim intval1 As Variant
    Dim StrQryFld As String
    Dim StrQryTabNam As String
    Dim StrQrycond As String
    Dim strQryOrd As String
    Dim resstring As String
    On Error GoTo errhand
    
    '/*---checking that the parameters are passed correctly---*/
    If Len(Trim(BranchCode)) < 1 Or Len(Trim(CurrencyCode)) < 1 Then
        inttemp(0, 0) = "Data Does Not Exist For This Query"
        CashInEachBranch = inttemp
        CashInEachBranch = Replace(CashInEachBranch, Chr(10), "")
        CashInEachBranch = Replace(CashInEachBranch, Chr(13), "")
        Exit Function
    End If
    
    Set rsdenom = CreateObject("adodb.recordset")
    
    StrQryFld = "denommst.denominationcode denomcode," _
    & "denommst.denominationvalue denomval," _
    & "denommst.denominationtype denomtype" _
    & ",curtype.precision prec"
    
    StrQryTabNam = "cashdenominationmst denommst,gencurrencytypemst curtype"
    
    StrQrycond = "denommst.currencycode=curtype.currencycode and  " _
    & "denommst.currencycode='" & CurrencyCode & "'"
    
    strQryOrd = " substr(denomtype,1,1) desc," _
    & " substr(denomtype,2,1),to_number(denommst.denominationvalue) desc"
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsdenom = ObjFetchRec.singlerecordset(StrQryTabNam, StrQryFld, StrQrycond, strQryOrd)
    Set ObjFetchRec = Nothing
    
    StrFields = ""
    strfields1 = ""
    
    '/*---all the denomination codes that are there in the cashdenominationmst
    'are conconated to the strfields and strfields1
    
    Do While Not rsdenom.EOF
       StrFields = StrFields & "nvl(" & rsdenom(0) & "," & 0 & ")" & " " & rsdenom(0) & ","
       strfields1 = strfields1 & "sum(nvl(" & rsdenom(0) & "," & 0 & "))" & " " & rsdenom(0) & ","
       rsdenom.MoveNext
    Loop
    
    StrFields = Mid(StrFields, 1, (Len(StrFields) - 1))
    strfields1 = Mid(strfields1, 1, (Len(strfields1) - 1))
    
    '/*---query condition for the cashcashierposmst and cashvaultmst---*/
    
    strcondition = "Branchcode='" & BranchCode & "' and currencycode='" & CurrencyCode & "'"
    
    Set rscashvalt = CreateObject("adodb.recordset")
    Set rscashposmst = CreateObject("adodb.recordset")
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rscashvalt = ObjFetchRec.singlerecordset _
    ("cashvaultmst", StrFields, strcondition)
    
    Set rscashposmst = ObjFetchRec.singlerecordset _
    ("cashcashierposmst", strfields1, strcondition)
    Set ObjFetchRec = Nothing
            
    '/*-----checking that the recordcound is not zero----*/
'    If rscashvalt.RecordCount > 0 And rscashposmst.RecordCount < 1 Then
'
'    ElseIf rscashvalt.RecordCount < 1 And rscashposmst.RecordCount > 0 Then
    
    If (rscashvalt.EOF And rscashvalt.BOF) And (rscashposmst.EOF And rscashposmst.BOF) Then
        inttemp(0, 0) = "Data Does Not Exist For This Query"
        CashInEachBranch = inttemp
        CashInEachBranch = Replace(CashInEachBranch, Chr(10), "")
        CashInEachBranch = Replace(CashInEachBranch, Chr(13), "")
        
        If rsdenom.State = 1 Then rsdenom.Close
        Set rsdenom = Nothing
        If rscashvalt.State = 1 Then rscashvalt.Close
        Set rscashvalt = Nothing
        If rscashposmst.State = 1 Then rscashposmst.Close
        Set rscashposmst = Nothing
        
        Exit Function
    End If
        
    '/*---Finding the number of pieces in the vault for each denomination _
    and the value of denomination and adding it to inttemp array---*/
    
    
    If Not rsdenom.EOF Or Not rsdenom.BOF Then
        rsdenom.MoveFirst
        ICount = 0
       Do While Not rsdenom.EOF
       
            If Not IsNull(rsdenom!denomtype) Then
                '/*---checking the precision and calculating denimination value---*/
                If rsdenom!denomtype <> "CP" Then
                    intval = Val(Format(rsdenom!denomval))
                Else
                    intval = Val(Format(rsdenom!denomval)) / Val(Format(rsdenom!prec))
                End If
            End If
            
            inttemp(ICount, 0) = intval
            
            '/*---getting the number of pieces in each denomination---*/
            If Val(Format(rscashvalt(ICount))) > 0 Then
                inttemp(ICount, 1) = Val(Format(rscashvalt(ICount)))
            Else
                inttemp(ICount, 1) = 0
            End If
            
            inttemp(ICount, 2) = Val(Format(intval)) * Val(Format(inttemp(ICount, 1)))
            rsdenom.MoveNext
            ICount = ICount + 1
        Loop
    End If
    

    intval = 0
    
    '/*---Finding the number of pieces in the cashcashierposmst for each _
    denomination and the value of denomination and adding it to inttemp array---*/
    
    If Not rsdenom.EOF Or Not rsdenom.BOF Then
    rsdenom.MoveFirst
    ICount = 0
         Do While Not rsdenom.EOF
            If Not IsNull(rsdenom!denomtype) Then
                '/*---checking the precision and calculating denimination value---*/
                If rsdenom!denomtype <> "CP" Then
                    intval = Val(Format(rsdenom!denomval))
                Else
                    intval = Val(Format(rsdenom!denomval)) / Val(Format(rsdenom!prec))
                End If
            End If
            '/*---getting the number of pieces in each denomination---*/
            If Val(Format(rscashposmst(ICount))) > 0 Then
                inttemp(ICount, 3) = Val(Format(rscashposmst(ICount)))
            Else
                inttemp(ICount, 3) = 0
            End If
            '/*--calculating the total value of cash in the cashcashierposmt---*/
            inttemp(ICount, 4) = Val(Format(intval)) * Val(Format(inttemp(ICount, 3)))
            '/*--calculating the total value of cash in the cashvault and _
            cash in the cashcashierposmt
            inttemp(ICount, 5) = Val(inttemp(ICount, 2)) + Val(inttemp(ICount, 4))
            rsdenom.MoveNext
            ICount = ICount + 1
        Loop
    End If
    
    CashInEachBranch = inttemp
    
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    If rscashvalt.State = 1 Then rscashvalt.Close
    Set rscashvalt = Nothing
    If rscashposmst.State = 1 Then rscashposmst.Close
    Set rscashposmst = Nothing
        
    Exit Function
   
   
errhand:
    Set ObjFetchRec = Nothing
    inttemp(0, 0) = "Data Does Not Exist For This Query"
    CashInEachBranch = inttemp
    CashInEachBranch = Replace(CashInEachBranch, Chr(10), "")
    CashInEachBranch = Replace(CashInEachBranch, Chr(13), "")
        
    LogError "CashInEachBranch", Err.Number, Err.Description

    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    If rscashvalt.State = 1 Then rscashvalt.Close
    Set rscashvalt = Nothing
    If rscashposmst.State = 1 Then rscashposmst.Close
    Set rscashposmst = Nothing
        
    Exit Function
    
End Function


Public Function CashInAllBranches _
    (CurrencyCode As String) As Variant
    
    '/---* varaible declaration---/*
    Dim ICount As Integer
    Dim inttemp(50, 2) As Variant
    Dim StrFields As String
    Dim strfields1 As String
    Dim count As Integer
    Dim rsbranch As Recordset
    Dim rsvault As Recordset
    Dim rsdenom As Recordset
    Dim rscashpos As Recordset
    Dim StrQryFld As String
    Dim StrQryTabNam As String
    Dim StrQrycond As String
    Dim strQryOrd As String
    Dim introws As Integer
    On Error GoTo errhand
    
    Set rsbranch = CreateObject("adodb.recordset")
    Set rsvault = CreateObject("adodb.recordset")
    Set rsdenom = CreateObject("adodb.recordset")
    Set rscashpos = CreateObject("adodb.recordset")
    
    StrQryFld = "denommst.denominationcode denomcode," _
    & "denommst.denominationvalue denomval," _
    & "denommst.denominationtype denomtype" _
    & ",curtype.precision prec"
    
    StrQryTabNam = "cashdenominationmst denommst,gencurrencytypemst curtype"
    
    StrQrycond = "denommst.currencycode=curtype.currencycode and  " _
    & "denommst.currencycode='" & CurrencyCode & "'"
    
    strQryOrd = " substr(denomtype,1,1) desc," _
    & " substr(denomtype,2,1),to_number(denommst.denominationvalue) desc"
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsdenom = ObjFetchRec.singlerecordset(StrQryTabNam, StrQryFld, StrQrycond, strQryOrd)
    Set ObjFetchRec = Nothing
    
    StrFields = ""
    strfields1 = ""
    
    StrFields = "branchcode,"
    strfields1 = "branchcode,"
    
    '/*---all the denomination codes that are there in the cashdenominationmst
    'are conconated to the strfields and strfields1
    Do While Not rsdenom.EOF
       StrFields = StrFields & "nvl(" & rsdenom(0) & "," & 0 & ")" & " " & rsdenom(0) & ","
       strfields1 = strfields1 & "sum(nvl(" & rsdenom(0) & "," & 0 & "))" & " " & rsdenom(0) & ","
       rsdenom.MoveNext
    Loop
    
    StrFields = Mid(StrFields, 1, (Len(StrFields) - 1))
    strfields1 = Mid(strfields1, 1, (Len(strfields1) - 1))
          
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
        Set rsbranch = ObjFetchRec.singlerecordset("genbankbranchmst", "branchcode", , "to_number(branchcode)")
        Set rsvault = ObjFetchRec.singlerecordset("cashvaultmst", StrFields, "currencycode='" & CurrencyCode & "'")
        Set rscashpos = ObjFetchRec.singlerecordset("cashcashierposmst", strfields1, "currencycode='" & CurrencyCode & "' group by branchcode")
    Set ObjFetchRec = Nothing
    
    '/*---checking that the record count is not zero---*/
    If rsbranch.BOF And rsbranch.EOF Then
        inttemp(0, 0) = "Data Does Not Exist For This Query"
        CashInAllBranches = inttemp
        
        If rsbranch.State = 1 Then rsbranch.Close
        Set rsbranch = Nothing
        If rsvault.State = 1 Then rsvault.Close
        Set rsvault = Nothing
        If rsdenom.State = 1 Then rsdenom.Close
        Set rsdenom = Nothing
        If rscashpos.State = 1 Then rscashpos.Close
        Set rscashpos = Nothing
        
        Exit Function
    End If
    
    '/*---all the branch codes are added to the inttep array---*/
    ICount = 0
    Do While Not rsbranch.EOF
        inttemp(ICount, 0) = rsbranch!BranchCode
        rsbranch.MoveNext
        ICount = ICount + 1
    Loop
    
    introws = (ICount - 1)
    
    '/*---checking that the record exist or not in cashvaultmst and cashcashierposmt----*/
    
    If (rsvault.EOF And rsvault.BOF) And (rscashpos.EOF And rscashpos.BOF) Then
        inttemp(0, 0) = "Data Does Not Exist For This Query"
        CashInAllBranches = inttemp
        
        If rsbranch.State = 1 Then rsbranch.Close
        Set rsbranch = Nothing
        If rsvault.State = 1 Then rsvault.Close
        Set rsvault = Nothing
        If rsdenom.State = 1 Then rsdenom.Close
        Set rsdenom = Nothing
        If rscashpos.State = 1 Then rscashpos.Close
        Set rscashpos = Nothing
        
        Exit Function
    End If
    
    Dim icount2 As Integer
    Dim intval As Double
    Dim totval As Double
    
    '/*--Calculating the total cash in the vault and adding it to inttemp array--*/
    For ICount = 0 To introws
        If Not rsvault.EOF Then
            rsvault.MoveFirst
        
            rsvault.Find "branchcode='" & inttemp(ICount, 0) & "'"
            rsdenom.MoveFirst
            For icount2 = 1 To rsdenom.RecordCount
                If Not rsvault.EOF Then
            
                    If rsdenom!denomtype <> "CP" Then
                        intval = Val(Format(rsdenom!denomval)) * Val(Format(rsvault(icount2)))
                    Else
                        intval = (Val(Format(rsdenom!denomval)) / Val(Format(rsdenom!prec))) * Val(Format(rsvault(icount2)))
                    End If
                End If
                totval = totval + intval
                rsdenom.MoveNext
            Next
            inttemp(ICount, 1) = totval
            totval = 0
            intval = 0
        End If
    Next
    
    totval = 0
    intval = 0
    
    '/*--Calculating the total cash in the cashcashierposmst and adding it to _
    inttemp array--*/
    For ICount = 0 To introws
        If Not rscashpos.EOF Then
            rscashpos.MoveFirst
            rscashpos.Find "branchcode='" & inttemp(ICount, 0) & "'"
            rsdenom.MoveFirst
            For icount2 = 1 To rsdenom.RecordCount
                If Not rscashpos.EOF Then
            
                    If rsdenom!denomtype <> "CP" Then
                        intval = Val(Format(rsdenom!denomval)) * Val(Format(rscashpos(icount2)))
                    Else
                        intval = (Val(Format(rsdenom!denomval)) / Val(Format(rsdenom!prec))) * Val(Format(rscashpos(icount2)))
                    End If
                End If
                totval = totval + intval
                rsdenom.MoveNext
            Next
            inttemp(ICount, 2) = totval
            totval = 0
            totval = 0
        End If
    Next
    
    CashInAllBranches = inttemp
    
    If rsbranch.State = 1 Then rsbranch.Close
    Set rsbranch = Nothing
    If rsvault.State = 1 Then rsvault.Close
    Set rsvault = Nothing
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    If rscashpos.State = 1 Then rscashpos.Close
    Set rscashpos = Nothing
        
    Exit Function
    
errhand:
    inttemp(0, 0) = "Data Does Not Exist For This Query"
    CashInAllBranches = inttemp
    CashInAllBranches = Replace(CashInAllBranches, Chr(10), "")
    CashInAllBranches = Replace(CashInAllBranches, Chr(13), "")
    Set ObjFetchRec = Nothing
    
    LogError "CashInAllBranches", Err.Number, Err.Description
    
    If rsbranch.State = 1 Then rsbranch.Close
    Set rsbranch = Nothing
    If rsvault.State = 1 Then rsvault.Close
    Set rsvault = Nothing
    If rsdenom.State = 1 Then rsdenom.Close
    Set rsdenom = Nothing
    If rscashpos.State = 1 Then rscashpos.Close
    Set rscashpos = Nothing
        
End Function

'''' To find the cash in vault after checking the cash in CashAllotmentstrn where status is "P"

Private Function CashInVault(BranchCode As String, CurrencyCode As String, Optional Applicationdate As String) As Variant

Dim strCashCondition As String
Dim strCurrency As String
Dim StrBranch As String
Dim Arrtemp() As Variant
Dim AdoRSAllot As ADODB.Recordset
Dim strQryRes As String  '''''' To check where the Error has occured
Dim StrVltTable As String
strCurrency = UCase(Trim(CurrencyCode))
StrBranch = UCase(Trim(BranchCode))
strCashCondition = ""
  Set AdoRSAllot = CreateObject("Adodb.Recordset")
On Error GoTo errhand
If Trim(Applicationdate) = "" Or Format(Applicationdate, "dd-mmm-yy") = Format(Now, "dd-mmm-yy") Then
    StrVltTable = "CASHVAULTMST"
    strCashCondition = " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
    & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) & "'"

        strQryRes = "Vault"
        Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set Rstemp = ObjQuery.singlerecordset(StrVltTable, strCashDenomFlds, strCashCondition)
        
        If ObjQuery.ConnError <> "Connected" Then
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = ObjQuery.ConnError & " : Denominations At Vault"
                CashInVault = Arrtemp
                CashInVault = Replace(CashInVault, Chr(10), "")
                CashInVault = Replace(CashInVault, Chr(13), "")
                Set ObjQuery = Nothing
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                Exit Function
        End If
        
        If Rstemp.EOF And Rstemp.BOF Then
        
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = " No Cashh In the Vault for this Currency."
                CashInVault = Arrtemp
                CashInVault = Replace(CashInVault, Chr(10), "")
                CashInVault = Replace(CashInVault, Chr(13), "")
                Set ObjQuery = Nothing
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                Exit Function
        
        End If
        
        '''' Finding the cash pieces at allotmentstrn where the status is Pending
        strQryRes = "Allotment"
        strCashCondition = strCashCondition & " and upper(trim(status))='P'"
      
        Set AdoRSAllot = ObjQuery.singlerecordset("CashAllotmentstrn", strCashDenomFlds, strCashCondition)
        
        
        If ObjQuery.ConnError <> "Connected" Then
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = ObjQuery.ConnError & " : Denominations At AllotmntsTRN"
                Set ObjQuery = Nothing
                CashInVault = Arrtemp
                CashInVault = Replace(CashInVault, Chr(10), "")
                CashInVault = Replace(CashInVault, Chr(13), "")
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                If AdoRSAllot.State = 1 Then AdoRSAllot.Close
                Set AdoRSAllot = Nothing
                Exit Function
        End If
        
        ReDim Arrtemp(Rstemp.Fields.count, 1)
        Set ObjQuery = Nothing
        
        If AdoRSAllot.EOF And AdoRSAllot.BOF Then
            
            For ICount = 0 To UBound(Arrtemp) - 1
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
            Next ICount
            
        Else
        
            For ICount = 0 To UBound(Arrtemp) - 1
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value) - (AdoRSAllot.Fields(ICount).Value)
                                  
            Next ICount
            
        End If
Else
    Dim strOrder As String
    StrVltTable = "CASHVAULTMSTHIST"
    strCashCondition = " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
    & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) _
    & "' and applicationdate='" & Applicationdate & "'" _
    & " and systemdate= (select max(systemdate) from CASHVAULTMSTHIST where " _
    & " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
    & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) _
    & "' and applicationdate<='" & Applicationdate & "')" _
    
    
    strOrder = " to_Char(systemdate,'dd-Mon-yy HH24:mi:ss')"
    
    strQryRes = "VaultHist"
        Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set Rstemp = ObjQuery.singlerecordset(StrVltTable, strCashDenomFlds, strCashCondition, strOrder)
        
        If ObjQuery.ConnError <> "Connected" Or (Rstemp.EOF And Rstemp.BOF) Then
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = ObjQuery.ConnError & " : OR No Denominations At Vault For This Date"
                CashInVault = Arrtemp
                Set ObjQuery = Nothing
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                If AdoRSAllot.State = 1 Then AdoRSAllot.Close
                Set AdoRSAllot = Nothing
                
                Exit Function
        End If
        
        Set ObjQuery = Nothing
        Rstemp.MoveLast
        ReDim Arrtemp(Rstemp.Fields.count, 1)
        
            For ICount = 0 To UBound(Arrtemp) - 1
            
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
            
            Next ICount
End If

CashInVault = Arrtemp

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoRSAllot.State = 1 Then AdoRSAllot.Close
Set AdoRSAllot = Nothing
                
Exit Function

errhand:

ReDim Arrtemp(0, 0) As Variant
Arrtemp(0, 0) = Err.Number & " : " & Err.Description
        
LogError "CashInVault", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoRSAllot.State = 1 Then AdoRSAllot.Close
Set AdoRSAllot = Nothing

End Function


'''''''''''''''' To find the cash in vault after checking the cash in CashTransferTRN and
'''''''''''''''' cashrefundsTRN where status is "P"

Private Function CashInCashierPosition(BranchCode As String, CurrencyCode As String, _
                                        CashierID As String, _
                                        Optional PipeLineTranYN As String) As Variant

Dim strCashCondition As String
Dim strCurrency As String
Dim StrBranch As String
Dim StrCashier As String
Dim Arrtemp() As Variant
Dim AdoRSRefund As ADODB.Recordset
Dim AdoRSTransfer As ADODB.Recordset
Dim strQryRes As String  '''''' To check where the Error has occured
Dim BlnDenom As Boolean
On Error GoTo errhand
StrCashier = UCase(Trim(CashierID))
strCurrency = UCase(Trim(CurrencyCode))
StrBranch = UCase(Trim(BranchCode))
strCashCondition = ""


strCashCondition = " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
                    & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) & "'" _
                    & " and upper(trim(CASHIERID))='" & StrCashier & "'"

strQryRes = "CashierPosition"
Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set Rstemp = ObjQuery.singlerecordset("CashCashierposmst", strCashDenomFlds, strCashCondition)

If ObjQuery.ConnError <> "Connected" Then
        ReDim Arrtemp(0, 0) As Variant
        Arrtemp(0, 0) = ObjQuery.ConnError & " : Denominations At CashierPosition"
        CashInCashierPosition = Arrtemp
        Set ObjQuery = Nothing
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        Exit Function
End If

BlnDenom = False
For ICount = 0 To Rstemp.Fields.count - 1
    If Rstemp(ICount) > 0 Then
        BlnDenom = True
        Exit For
    Else
        BlnDenom = False
    End If
Next ICount

If BlnDenom = False Then
        ReDim Arrtemp(0, 0) As Variant
        Arrtemp(0, 0) = "No Cash for this cashier"
        CashInCashierPosition = Arrtemp
        Set ObjQuery = Nothing
        
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        Exit Function
End If

ReDim Arrtemp(Rstemp.Fields.count, 1) As Variant
If UCase(Trim(PipeLineTranYN)) = "Y" Then
        ''''**** Finding the cash pieces at CashRefundsTrn where the status is Pending
        strQryRes = "Refund"
        strCashCondition = " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
                            & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) & "'" _
                            & " and upper(trim(REFUNDEDUSERID))='" & StrCashier & "'" _
                            & " and upper(trim(status))='P'"
        
        Set AdoRSRefund = CreateObject("Adodb.Recordset")
        Set AdoRSRefund = ObjQuery.singlerecordset("CashRefundsTrn", strCashDenomFlds, strCashCondition)
        
        If ObjQuery.ConnError <> "Connected" Then
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = ObjQuery.ConnError & " : Denominations At RefundsTRN"
                CashInCashierPosition = Arrtemp
                Set ObjQuery = Nothing
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                If AdoRSRefund.State = 1 Then AdoRSRefund.Close
                Set AdoRSRefund = Nothing
                Exit Function
        End If
        
        ''''**** Finding the cash pieces at cashtransbtcashierstrn where the status is Pending
        strQryRes = "Transfer"
        strCashCondition = " Upper(trim(Branchcode))='" & UCase(Trim(StrBranch)) & "' and " _
                            & " Upper(trim(currencycode))='" & UCase(Trim(strCurrency)) & "'" _
                            & " and upper(trim(FromCashierid))='" & StrCashier & "'" _
                            & " and upper(trim(status))='P'"
                            
        Set AdoRSTransfer = CreateObject("Adodb.Recordset")
        Set AdoRSTransfer = ObjQuery.singlerecordset("cashtransbtcashierstrn", strCashDenomFlds, strCashCondition)
        
        If ObjQuery.ConnError <> "Connected" Then
                ReDim Arrtemp(0, 0) As Variant
                Arrtemp(0, 0) = ObjQuery.ConnError & " : Denominations At TransfersTRN"
                CashInCashierPosition = Arrtemp
                Set ObjQuery = Nothing
                
                If Rstemp.State = 1 Then Rstemp.Close
                Set Rstemp = Nothing
                If AdoRSRefund.State = 1 Then AdoRSRefund.Close
                Set AdoRSRefund = Nothing
                If AdoRSTransfer.State = 1 Then AdoRSTransfer.Close
                Set AdoRSTransfer = Nothing
                Exit Function
        End If
        
        Set ObjQuery = Nothing
        
        ''''' 1st collumn = Denomination code eg D1,D2,D3...
        ''''' 2nd collumn=No of Pieces in CashierPosMst Minus
        ''''''(No of Pieces in refundstrn for that particular cashier Plus No of Pieces in transfertrn for that particular cashier)
                
            For ICount = 0 To UBound(Arrtemp) - 1
                
            
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value) _
                    - ((AdoRSTransfer.Fields(ICount).Value) + (AdoRSRefund.Fields(ICount).Value))
                
            Next ICount
Else

            For ICount = 0 To UBound(Arrtemp) - 1
                        
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
                   
            Next ICount
End If

CashInCashierPosition = Arrtemp

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoRSRefund.State = 1 Then AdoRSRefund.Close
Set AdoRSRefund = Nothing
If AdoRSTransfer.State = 1 Then AdoRSTransfer.Close
Set AdoRSTransfer = Nothing
Exit Function

errhand:

        ReDim Arrtemp(0, 0) As Variant
        Arrtemp(0, 0) = Err.Number & " : " & Err.Description

LogError "CashInCashierPosition", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If AdoRSRefund.State = 1 Then AdoRSRefund.Close
Set AdoRSRefund = Nothing
If AdoRSTransfer.State = 1 Then AdoRSTransfer.Close
Set AdoRSTransfer = Nothing

End Function

Private Function CashInAllotmentsTRN(BranchCode As String, CurrencyCode As String, _
                                     CashierID As String, AllotmentNo As String) As Variant
                                        


Dim strCashCondition As String
Dim Arrtemp() As Variant

On Error GoTo errhand
            strCashCondition = "upper(currencycode)='" & CurrencyCode _
            & "' and upper(branchcode)='" & BranchCode & "'  and allotmentno=" _
            & Trim(AllotmentNo) & " and upper(trim(Cashierid))='" & CashierID & "'"

        Set Rstemp = CreateObject("ADODB.Recordset")
        Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set Rstemp = ObjQuery.singlerecordset("CASHALLOTMENTSTRN", strCashDenomFlds, strCashCondition)

                        If ObjQuery.ConnError <> "Connected" Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = ObjQuery.ConnError
                            Set ObjQuery = Nothing
                            CashInAllotmentsTRN = Arrtemp
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                            
                        End If
                        
                        If Rstemp.EOF And Rstemp.BOF Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = "No Cash For This Query"
                            Set ObjQuery = Nothing
                            CashInAllotmentsTRN = Arrtemp
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                        End If
        Set ObjQuery = Nothing
        ReDim Arrtemp(Rstemp.Fields.count, 1) As Variant

        For ICount = 0 To UBound(Arrtemp) - 1
            
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
        
        Next ICount

        CashInAllotmentsTRN = Arrtemp
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        Exit Function
        
errhand:

ReDim Arrtemp(0, 0) As Variant
Arrtemp(0, 0) = "No Cash For This Query"
CashInAllotmentsTRN = Arrtemp

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing

LogError "CashInAllotmentsTRN", Err.Number, Err.Description
    
End Function


Private Function CashInRefundsTRN(BranchCode As String, CurrencyCode As String, _
                                     CashierID As String, RefundNo As String) As Variant
                                        


Dim strCashCondition As String
Dim Arrtemp() As Variant

On Error GoTo errhand
            strCashCondition = "upper(currencycode)='" & CurrencyCode _
            & "' and upper(branchcode)='" & BranchCode & "'  and Refundno=" _
            & Trim(RefundNo) & " and upper(trim(refundeduserid))='" & CashierID & "' and status='P'"

        Set Rstemp = CreateObject("ADODB.Recordset")
        Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set Rstemp = ObjQuery.singlerecordset("CASHREFUNDSTRN", strCashDenomFlds, strCashCondition)

                        If ObjQuery.ConnError <> "Connected" Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = ObjQuery.ConnError
                            Set ObjQuery = Nothing
                            CashInRefundsTRN = Arrtemp
                            CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(10), "")
                            CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(13), "")
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                            
                        End If
                        
                        If Rstemp.EOF And Rstemp.BOF Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = "No Cash For This Query"
                            Set ObjQuery = Nothing
                            CashInRefundsTRN = Arrtemp
                            CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(10), "")
                            CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(13), "")
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                        End If
        Set ObjQuery = Nothing
        ReDim Arrtemp(Rstemp.Fields.count, 1) As Variant

        For ICount = 0 To UBound(Arrtemp) - 1
            
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
        
        Next ICount

        CashInRefundsTRN = Arrtemp
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        Exit Function
        
errhand:

ReDim Arrtemp(0, 0) As Variant
Arrtemp(0, 0) = Err.Number & Err.Description
CashInRefundsTRN = Arrtemp
CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(10), "")
CashInRefundsTRN = Replace(CashInRefundsTRN, Chr(13), "")

LogError "CashInRefundsTRN", Err.Number, Err.Description
    
If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
End Function



Private Function CashInTransfersTRN(BranchCode As String, CurrencyCode As String, _
                                     CashierID As String, TransferNo As String) As Variant
                                        


Dim strCashCondition As String
Dim Arrtemp() As Variant

On Error GoTo errhand
            strCashCondition = "upper(currencycode)='" & CurrencyCode _
            & "' and upper(branchcode)='" & BranchCode & "'  and CashTransferNo=" _
            & Trim(TransferNo) & " and upper(trim(TOcashierid))='" & CashierID & "'"

        Set Rstemp = CreateObject("ADODB.Recordset")
        Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set Rstemp = ObjQuery.singlerecordset("CASHTRANSBTCASHIERSTRN", strCashDenomFlds, strCashCondition)

                        If ObjQuery.ConnError <> "Connected" Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = ObjQuery.ConnError
                            Set ObjQuery = Nothing
                            CashInTransfersTRN = Arrtemp
                            CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(10), "")
                            CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(13), "")
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                            
                        End If
                        
                        If Rstemp.EOF And Rstemp.BOF Then
                            ReDim Arrtemp(0, 0) As Variant
                            Arrtemp(0, 0) = "No Cash For This Query"
                            Set ObjQuery = Nothing
                            CashInTransfersTRN = Arrtemp
                            CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(10), "")
                            CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(13), "")
                            
                            If Rstemp.State = 1 Then Rstemp.Close
                            Set Rstemp = Nothing
                            Exit Function
                        End If
        Set ObjQuery = Nothing
        ReDim Arrtemp(Rstemp.Fields.count, 1) As Variant

        For ICount = 0 To UBound(Arrtemp) - 1
            
                Arrtemp(ICount, 0) = Rstemp.Fields(ICount).Name
                Arrtemp(ICount, 1) = (Rstemp.Fields(ICount).Value)
        
        Next ICount

        CashInTransfersTRN = Arrtemp
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = Nothing
        Exit Function
        
errhand:

ReDim Arrtemp(0, 0) As Variant
Arrtemp(0, 0) = "No Cash For This Query"
CashInTransfersTRN = Arrtemp
CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(10), "")
CashInTransfersTRN = Replace(CashInTransfersTRN, Chr(13), "")

LogError "CashInTransfersTRN", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
End Function

Public Function CheckCashLimit(BranchCode As String, CurrencyCode As String, _
                                Applicationdate As String, CashierID As String, _
                                CounterNo As String, Amount As Double, _
                                Optional TransferRefund As String, _
                                Optional TranNo As String) As String

Dim StrQuery As String
Dim strBRCode As String, strCurrency As String, strCashierID As String
Dim strCounterNo As String, dtAppDate As String, StrFlds As String, StrTables As String
Dim strcondition As String, strOrder As String
Dim strTransNo As String, TransRefund As String
Dim CashPosAmt As Double
Dim CashAllotAmt As Double
Dim CashTransAmt As Double
Dim CashRefAmt As Double
Dim CashAmt As Double
Dim MaxCashLimit As Double
Dim TotCashAmt As Double
'Call DBConnection
'If ConnError <> "Connected" Then Exit Function
On Error GoTo errhand

strBRCode = UCase(Trim(BranchCode))
strCurrency = UCase(Trim(CurrencyCode))
strCashierID = IIf(IsNull(CashierID), "", CashierID)
strCounterNo = IIf(IsNull(CounterNo), "", CounterNo)
dtAppDate = IIf(IsNull(Applicationdate), " ", Format(Applicationdate, "dd-mmm-yy"))
TransRefund = IIf(IsNull(TransferRefund), "", UCase(TransferRefund))
strTransNo = IIf(IsNull(TranNo), "", TranNo)
CashAmt = Amount
StrQuery = ""

Set Rstemp = CreateObject("Adodb.Recordset")
Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
& "' and CASHIERID='" & strCashierID & "' and COUNTERNO ='" & strCounterNo _
& "' and APPLICATIONDATE='" & dtAppDate & "'"

'''''''''retrieving maxcashlimit
Set Rstemp = ObjQuery.singlerecordset("CASHCOUNTERMST", "MAXCASHLIMIT", _
                        strcondition, , strBRCode, strCashierID, , dtAppDate)

If ObjQuery.ConnError <> "Connected" Then
    Set ObjQuery = Nothing
    CheckCashLimit = ObjQuery.ConnError
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    Exit Function
ElseIf Not Rstemp.EOF And Not Rstemp.BOF Then
    MaxCashLimit = Rstemp!MaxCashLimit
Else
    CheckCashLimit = "Counter or Cashier not available."
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing

    Set ObjQuery = Nothing
    Exit Function
End If

    If Rstemp.State = 1 Then Rstemp.Close
    
    
''''''' tot amount from cashcashierposmst
Set Rstemp = ObjQuery.singlerecordset("CASHCASHIERPOSMST", "TOTAMOUNT", _
                        strcondition, , strBRCode, strCashierID, , dtAppDate)

If ObjQuery.ConnError <> "Connected" Then
   Set ObjQuery = Nothing
    CheckCashLimit = ObjQuery.ConnError
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    
    Exit Function
ElseIf Not Rstemp.EOF And Not Rstemp.BOF Then
    CashPosAmt = Rstemp!TotAmount
Else
    CashPosAmt = 0
    
End If

    If Rstemp.State = 1 Then Rstemp.Close
    

''''''sum of the amount for current cashier in pending status from CASHALLOTMENTSTRN
strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
& "' and CASHIERID='" & strCashierID & "' and COUNTERNO ='" & strCounterNo _
& "' and APPLICATIONDATE='" & dtAppDate & "' and status='P'"

Set Rstemp = ObjQuery.singlerecordset("CASHALLOTMENTSTRN", " nvl(sum(AMOUNTALLOTED),0) Amount", _
                        strcondition, , strBRCode, strCashierID, , dtAppDate)

If ObjQuery.ConnError <> "Connected" Then
    Set ObjQuery = Nothing
    Set Rstemp = Nothing
    CheckCashLimit = ObjQuery.ConnError
    Exit Function
ElseIf Not Rstemp.EOF And Not Rstemp.BOF Then
    CashAllotAmt = Rstemp!Amount
Else
    CashAllotAmt = 0
End If

    If Rstemp.State = 1 Then Rstemp.Close

''''''''''sum of amount pending for cashier in CASHTRANSBTCASHIERSTRN
If TransRefund = "TRANSFER" And TranNo <> "" Then
    strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
    & "' and TOCASHIERID='" & strCashierID & "' and TOCOUNTERNO ='" & strCounterNo _
    & "' and APPLICATIONDATE='" & dtAppDate & "' and status='P' and TRANNO not in (" _
    & TranNo & ")"

Else
    strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
    & "' and TOCASHIERID='" & strCashierID & "' and TOCOUNTERNO ='" & strCounterNo _
    & "' and APPLICATIONDATE='" & dtAppDate & "' and status='P'"

End If

Set Rstemp = ObjQuery.singlerecordset("CASHTRANSBTCASHIERSTRN", " nvl(sum(AMOUNT),0) Amount", _
                        strcondition, , strBRCode, strCashierID, , dtAppDate)

If ObjQuery.ConnError <> "Connected" Then
    Set ObjQuery = Nothing
    Set Rstemp = Nothing
    CheckCashLimit = ObjQuery.ConnError
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
    Exit Function
ElseIf Not Rstemp.EOF And Not Rstemp.BOF Then
    CashTransAmt = Rstemp!Amount
Else
    CashTransAmt = 0
End If

    If Rstemp.State = 1 Then Rstemp.Close
        

''''''''''sum of amount pending for cashier in CASHREFUNDSTRN


If TransRefund = "REFUND" And TranNo <> "" Then
    strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
    & "' and userid='" & strCashierID & "' and COUNTERNO ='" & strCounterNo _
    & "' and APPLICATIONDATE='" & dtAppDate & "' and status='P' and REFUNDNO not in (" _
    & TranNo & ")"

Else
    strcondition = "BRANCHCODE='" & strBRCode & "' and  CURRENCYCODE='" & strCurrency _
    & "' and userid='" & strCashierID & "' and COUNTERNO ='" & strCounterNo _
    & "' and APPLICATIONDATE='" & dtAppDate & "' and status='P'"

End If

Set Rstemp = ObjQuery.singlerecordset("CASHREFUNDSTRN", " nvl(sum(REFUNDAMOUNT),0) Amount", _
                        strcondition, , strBRCode, strCashierID, , dtAppDate)

If ObjQuery.ConnError <> "Connected" Then
    Set ObjQuery = Nothing
    Set Rstemp = Nothing
    CheckCashLimit = ObjQuery.ConnError
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
    
    If Rstemp.State = 1 Then Rstemp.Close
    Set Rstemp = Nothing
    Exit Function
ElseIf Not Rstemp.EOF And Not Rstemp.BOF Then
    CashRefAmt = Rstemp!Amount
Else
    CashRefAmt = 0
End If

If Rstemp.State = 1 Then Rstemp.Close
TotCashAmt = (CashAmt + CashPosAmt + CashAllotAmt) - (CashTransAmt + CashRefAmt)

If TotCashAmt > MaxCashLimit Then
    CheckCashLimit = "Cash is exceeding the Maximum Cash Limit for the cashier."
    CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
    CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")
Else
    CheckCashLimit = "YES"
End If

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing

Exit Function
errhand:
CheckCashLimit = Err.Description
CheckCashLimit = Replace(CheckCashLimit, Chr(10), "")
CheckCashLimit = Replace(CheckCashLimit, Chr(13), "")

LogError "CheckCashLimit", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing

End Function

Sub LogError(ProcName$, ErrNum&, ErrorMsg$)
  On Error GoTo ErrHandler
  
  If blnDebug = True Then
    Dim nUnit As Integer
    nUnit = FreeFile
    ' This assumes write access to the directory containing the program '
    ' You will need to choose another directory if this is not possible '
    Open "C:\Inetpub\wwwroot\eSmartdotnet\errorlog\" & App.EXEName & ".log" For Append As nUnit
    Print #nUnit, "Error in " & ProcName
    Print #nUnit, "  " & ErrNum & ", " & ErrorMsg
    
    Print #nUnit, "  " & Format$(Now)
    Print #nUnit, ""
    Close nUnit
  End If
  Exit Sub

ErrHandler:
  'Failed to write log for some reason.'
  'Show MsgBox so error does not go unreported '
  MsgBox "Error in " & ProcName & vbNewLine & _
    ErrNum & ", " & ErrorMsg
End Sub

