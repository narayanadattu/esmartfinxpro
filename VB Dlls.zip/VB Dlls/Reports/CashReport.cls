VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 3  'UsesTransaction
END
Attribute VB_Name = "CashReport"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim objFetch As Object
Dim i As Integer, j As Integer
Dim curval As Double
Dim totamt As Double
Dim cnt As Integer
Dim valAmt As Double
Dim StrDiv As String

Public Function GetReportData(TabName As String, Columns As String, FromDate As String, ToDate As String, BranchCode As String, CurrencyCode As String) As Variant

''''-------------------Variable Declaration

Dim StrTabname As String
Dim StrTabname1 As String
Dim StrColumns As String
Dim StrFromDate As String
Dim StrToDate As String
Dim StrBrCode As String
Dim StrCurCode As String
Dim StrWhere As String
Dim StrGlCode As String
Dim BoolSend As Boolean
Dim RecCash As Object
Dim RecOldCash As Object
Dim RecTest As Object
Dim ArrResult()
Dim Icount As Integer
Dim Jcount As Integer
Dim RecCount As Integer
Dim Lcount As Integer
Dim RecOldCount As Integer
Dim StrOldTable As String

    On Error GoTo myerr
    
    ''''-------------------- Arguments to Local Variables
    
    StrTabname = TabName
    StrColumns = Columns
    StrFromDate = Format(FromDate, "dd-MMM-yyyy")
    StrToDate = Format(ToDate, "dd-MMM-yyyy")
    If CDate(FromDate) = CDate(ToDate) = Date Or CDate(FromDate) = Date Then
        StrTabname = TabName
    ElseIf CDate(ToDate) < Date Then
        StrTabname = TabName & "Hist"
    ElseIf CDate(FromDate) < Date And CDate(ToDate) >= Date Then
        StrOldTable = StrTabname & "Hist"
    End If
    
       
    StrBrCode = UCase(BranchCode)
    StrCurCode = UCase(CurrencyCode)
    StrWhere = "trim(upper(BranchCode))='" & StrBrCode & "' and trim(upper(CurrencyCode))='" & StrCurCode & "' and applicationdate between to_date('" & StrFromDate & "','dd-mon-yyyy') and to_date('" & StrToDate & "','dd-mon-yyyy') or upper(to_char(applicationdate,'dd-mon-yyyy'))='" & UCase(StrToDate) & "'" & "  order by Glcode"
    RecCount = 0
    Icount = 0
    Jcount = 0

    '''-----------------Object Creation of Fetch Recordset
    
       
        Set objFetch = CreateObject("Queryrecordsets.Fetchrecordsets")
        Set RecCash = CreateObject("Adodb.Recordset")
        Set RecOldCash = CreateObject("Adodb.Recordset")
        Set RecTest = CreateObject("Adodb.Recordset")
        If StrOldTable <> "" Then
            Set RecOldCash = objFetch.SingleRecordSet(StrOldTable, StrColumns, StrWhere)
            If RecOldCash.BOF = True Or RecOldCash.EOF = True Then '''------ If No data found then
                RecOldCount = 0
            Else
                Do While Not RecOldCash.EOF                      ''''------ Getting Record Count
                    RecOldCount = RecOldCount + 1
                    RecOldCash.MoveNext
                Loop
            RecOldCash.MoveFirst
            End If
        End If
        
        
        Set RecCash = objFetch.SingleRecordSet(StrTabname, StrColumns, StrWhere)
         
        If RecCash.BOF = True Or RecCash.EOF = True Then '''------ If No data found then
            RecCount = 0
        Else
                                     ''''----- If Data Found then
            Do While Not RecCash.EOF                      ''''------ Getting Record Count
                RecCount = RecCount + 1
                RecCash.MoveNext
            Loop
            RecCash.MoveFirst
        End If
        If RecCount + RecOldCount = 0 Then
            ReDim ArrResult(0, 0)
            ArrResult(0, 0) = " No Match Found for the Given Dates....!"
            GetReportData = ArrResult
            Exit Function
        Else

            If RecCount > 0 Then
                Set RecTest = objFetch.SingleRecordSet(StrTabname, "count(Distinct(glcode))", StrWhere)
                RecCount = RecCount + RecTest(0)
            End If
            If RecOldCount > 0 Then
                Set RecTest = objFetch.SingleRecordSet(StrOldTable, "count(Distinct(glcode))", StrWhere)
                RecOldCount = RecOldCount + RecTest(0)
            End If
            
            ReDim ArrResult(RecCount + RecOldCount + 3, 0)                ''''----- Redim Array with the record count
            
            For Icount = 0 To RecCash.Fields.Count - 4
                StrDiv = StrDiv & ","
            Next
            StrDiv = StrDiv & "Total" & ",,"
            Icount = 0
            Do While Not RecCash.EOF
            
                
                If StrGlCode <> RecCash!glcode Then     ''''------ If The Glcode matches to the
                                                        ''''-----  the BoolSend variable to false
                                                        ''''-----  previous Glcode the make
                    If Icount <> 0 Then
                    
                    ArrResult(Icount, 0) = StrDiv & valAmt
                    valAmt = 0
                    Icount = Icount + 1
                    End If
                    StrGlCode = RecCash!glcode
                    BoolSend = True
                Else
                    BoolSend = False
                End If
                     
                For Jcount = 0 To RecCash.Fields.Count - 1
            
                '''---- If Boolsend is true for Glcode column then only take the value
            
                    If UCase(RecCash.Fields(Jcount).Name) = "GLCODE" Then
                        If BoolSend = True Then
                            ArrResult(Icount, 0) = ArrResult(Icount, 0) & "," & RecCash(Jcount)
                        Else
                            ArrResult(Icount, 0) = ArrResult(Icount, 0) & ","
                        End If
                    Else
                        '''---- If it is other Column, accept the value
                        If UCase(RecCash(Jcount).Name) = "AMOUNT" Then
                            valAmt = valAmt + RecCash(Jcount)
                        End If
                        ArrResult(Icount, 0) = ArrResult(Icount, 0) & "," & RecCash(Jcount)
                    End If
                    
                Next
                ArrResult(Icount, 0) = Right(ArrResult(Icount, 0), Len(ArrResult(Icount, 0)) - 1)
                RecCash.MoveNext
            Icount = Icount + 1
            Loop
            If valAmt > 0 Then
            ArrResult(Icount, 0) = StrDiv & valAmt
            Icount = Icount + 1
            End If
            valAmt = 0
            StrGlCode = ""
            Jcount = 0
            If RecOldCash.State = 1 Then
            Do While Not RecOldCash.EOF
                        
                If StrGlCode <> RecOldCash!glcode Then     ''''------ If The Glcode matches to the
                                                      ''''-----  previous Glcode the make
                                                      ''''-----  the BoolSend variable to false
                    If Jcount <> 0 Then
                    ArrResult(Icount + Jcount, 0) = StrDiv & valAmt
                    valAmt = 0
                    Jcount = Jcount + 1
                    End If
                    
                    
                    StrGlCode = RecOldCash!glcode
                    BoolSend = True
                Else
                    BoolSend = False
                End If
                     
                For Lcount = 0 To RecOldCash.Fields.Count - 1
            
                '''---- If Boolsend is true for Glcode column then only take the value
            
                    If UCase(RecOldCash.Fields(Lcount).Name) = "GLCODE" Then
                        If BoolSend = True Then
                            ArrResult(Icount + Jcount, 0) = ArrResult(Icount + Jcount, 0) & "," & RecOldCash(Lcount)
                           
                        Else
                            
                            ArrResult(Icount + Jcount, 0) = ArrResult(Icount + Jcount, 0) & ","
                        End If
                    Else
                        '''---- If it is other Column, accept the value
                        If UCase(RecOldCash(Lcount).Name) = "AMOUNT" Then
                            valAmt = valAmt + RecOldCash(Lcount)
                        End If
                        ArrResult(Icount + Jcount, 0) = ArrResult(Icount + Jcount, 0) & "," & RecOldCash(Lcount)
                    End If
                Next
                ArrResult(Icount + Jcount, 0) = Right(ArrResult(Icount + Jcount, 0), Len(ArrResult(Icount + Jcount, 0)) - 1)
                RecOldCash.MoveNext
            Jcount = Jcount + 1
            Loop
            End If
        End If
        If valAmt > 0 Then
        ArrResult(Icount + Jcount, 0) = StrDiv & valAmt
        Icount = Icount + 1
        End If
        Icount = Icount + Jcount
        
        ''''---------------- Querying Denomination values to calculate the opening balance and totals of cash receipts and cash payments
        StrColumns = "nvl(TotAmount,0)"
        StrWhere = " trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "' and systemdate=(select max(systemdate) from cashvaultmsthist where systemdate < to_date('" & StrFromDate & "','dd-mon-yyyy')  and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "')"
        Set RecCash = objFetch.SingleRecordSet("cashvaultmsthist", StrColumns, StrWhere)
        If Not RecCash.EOF Or Not RecCash.BOF Then
            ArrResult(Icount, 0) = RecCash(0)
        Else
            ArrResult(Icount, 0) = 0
        End If
              
        Icount = Icount + 1
        
        ''''----------------- Total Amount of Cash Receipts
                
        If LCase(Right(StrTabname, 4)) = "hist" Then
            StrTabname = "CashreceiptstrnHist"
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "' and applicationdate between to_date('" & StrFromDate & "','DD-MON-YY') and to_date('" & StrToDate & "','DD-MON-YY')"
        Else
            StrTabname = "Cashreceiptstrn"
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "'"
        End If
        
        StrColumns = "sum(nvl(Amount,0))"
                      
        Set RecCash = objFetch.SingleRecordSet(StrTabname, StrColumns, StrWhere)
        
        curval = 0
        Do While Not RecCash.EOF
            If IsNull(RecCash(0)) = True Then
                curval = curval + 0
            Else
                curval = curval + RecCash(0)
            End If
                
            RecCash.MoveNext
        Loop
          
        If Len(StrOldTable) > 2 Then
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "' and applicationdate>='" & StrFromDate & "' and applicationdate <='" & StrToDate & "'"
            Set RecCash = objFetch.SingleRecordSet(StrOldTable, StrColumns, StrWhere)
            Do While Not RecCash.EOF
                If IsNull(RecCash(0)) = True Then
                    curval = curval + 0
                Else
                    curval = curval + RecCash(0)
                End If
                RecCash.MoveNext
            Loop
        End If
        
         ArrResult(Icount, 0) = curval
        
        ''''----------------- Total Amount of Cash Payments
        
        Icount = Icount + 1
        If LCase(Right(StrTabname, 4)) = "hist" Then
            StrTabname = "CashpaymentstrnHist"
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "' and applicationdate between to_date('" & StrFromDate & "','DD-MON-YY') and to_date('" & StrToDate & "','DD-MON-YY')"
        Else
            StrTabname = "Cashpaymentstrn"
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "'"
        End If

        
        Set RecCash = objFetch.SingleRecordSet(StrTabname, StrColumns, StrWhere)
               
        curval = 0
        Do While Not RecCash.EOF
            If IsNull(RecCash(0)) = True Then
                curval = curval + 0
            Else
                curval = curval + RecCash(0)
            End If
            RecCash.MoveNext
        Loop
          
        If Len(StrOldTable) > 2 Then
            StrOldTable = "Cashpaymentstrnhist"
            StrWhere = " status='A' and trim(upper(branchcode))='" & StrBrCode & "' and trim(upper(currencycode))='" & StrCurCode & "' and applicationdate between to_date('" & StrFromDate & "','DD-MON-YY') and to_date('" & StrToDate & "','DD-MON-YY')"
            Set RecCash = objFetch.SingleRecordSet(StrOldTable, StrColumns, StrWhere)
            Do While Not RecCash.EOF
                If IsNull(RecCash(0)) = True Then
                    curval = curval + 0
                Else
                    curval = curval + RecCash(0)
                End If
                RecCash.MoveNext
            Loop
        End If
        ArrResult(Icount, 0) = curval
                  
    '''---- Return the result
    GetReportData = ArrResult
    Exit Function

myerr:
'''------ Return the error
ReDim ArrResult(0, 0)
ArrResult(0, 0) = "Unable to Return the Data Due to  " & Err.Number & "  " & Err.Description
ArrResult(0, 0) = Replace(ArrResult(0, 0), Chr(10), "")
ArrResult(0, 0) = Replace(ArrResult(0, 0), Chr(13), "")
GetReportData = ArrResult
End Function
