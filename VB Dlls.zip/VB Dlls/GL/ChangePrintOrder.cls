VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "ChangePrintOrder"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim StrTable As String
Dim StrQryFlds As String
Dim StrUpdtFlds As String
Dim StrVals(0) As String
Dim StrWhere As String
Dim RecGl As Recordset
'Dim ObjFetch As New FetchRecordsets
'Dim ObjTrans As New TransactionMethods
Dim ObjFetch As Object
Dim ObjTrans As Object
Dim Result As String
Dim objContext As ObjectContext

Public Function PrintOrder(AccountType As String, Orderlevel As String, OrderCode As String, POrder As Variant)
Dim StrAccType As String
Dim StrOrderLevel As String
Dim StrOrderCode As String
Dim StrPorder As Variant
Dim UpdVal As String

    StrAccType = AccountType
    StrOrderLevel = Orderlevel
    StrOrderCode = OrderCode
    StrPorder = POrder
    
    StrTable = "GenGLMastMst"
    If StrOrderLevel = "0" Then
        StrQryFlds = "Substr(levelcode,1,3)"
        StrWhere = "GlAccType=" & StrAccType & "  and length(levelcode)=3 order by levelcode"
    ElseIf StrOrderLevel = "1" Then
        StrQryFlds = "Substr(levelcode,4,2)"
        StrWhere = "GlAccType=" & StrAccType & " and Level1='" & StrOrderCode & "'" & "  and length(levelcode)=5 order by levelcode"
    ElseIf StrOrderLevel = "2" Then
        StrQryFlds = "Substr(levelcode,6,2)"
        StrWhere = "GlAccType=" & StrAccType & " and Level2='" & StrOrderCode & "'" & "  and length(levelcode)=7 order by levelcode"
    End If
    
    Set objContext = GetObjectContext
    Set ObjFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set RecGl = ObjFetch.SingleRecordSet(StrTable, StrQryFlds, StrWhere)
    Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    StrUpdtFlds = "Templevelcode"
         
For i = 0 To UBound(StrPorder)
        If StrOrderLevel = "0" Then
            If Len(StrPorder(i)) = 1 Then
                UpdVal = "10" & StrPorder(i)
            ElseIf Len(StrPorder(i)) = 2 Then
                UpdVal = "1" & StrPorder(i)
            Else
                UpdVal = StrPorder(i)
            End If
            StrVals(0) = UpdVal & "|| substr(levelcode,4)"
            StrWhere = "Glacctype=" & StrAccType & " and length(levelcode)>3 and substr(levelcode,1,3)='" & RecGl(0) & "'"
        ElseIf StrOrderLevel = "1" Then
            If Len(StrPorder(i)) = 1 Then
                UpdVal = "0" & StrPorder(i)
            Else
                UpdVal = StrPorder(i)
            End If
            StrVals(0) = "substr(levelcode,1,3)||'" & UpdVal & "'||substr(levelcode,6)"
            StrWhere = "Glacctype=" & StrAccType & " and length(levelcode)>5 and substr(levelcode,4,2)='" & RecGl(0) & "' and level1='" & StrOrderCode & "'"
        End If
        Result = ObjTrans.UpdateRecord(StrTable, StrUpdtFlds, StrVals, StrWhere)
        RecGl.MoveNext
    Next
        StrUpdtFlds = "LevelCode"
        StrVals(0) = "TempLevelCode"
        StrWhere = "templevelcode is not null"
        Result = ObjTrans.UpdateRecord(StrTable, StrUpdtFlds, StrVals, StrWhere)
        StrUpdtFlds = "TempLevelCode"
        StrVals(0) = "''"
        StrWhere = "templevelcode is not null"
        Result = ObjTrans.UpdateRecord(StrTable, StrUpdtFlds, StrVals, StrWhere)
        PrintOrder = "Updation Successful"
        objContext.SetComplete
End Function


