VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "cDepositInterest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public ConnError As String 'error object

Private objDBConn As ADODB.Connection

Public Function CalcIntForADepositAcc(ByVal i_BranchCode As String, _
    ByVal i_CurrencyCode As String, ByVal i_GLCode As String, _
    ByVal i_CalcIntFromDate As Date, ByVal i_CalcIntUpToDate As Date, _
    ByVal i_ApplicationDate As Date, _
    Optional ByVal i_AccNo As String = "", _
    Optional ByVal i_IsItPreMatureAcc As Boolean = False, _
    Optional ByVal i_ROI As Double = 0) As Variant
'Desc:  This method is used to calculate interest for a Deposit account
'       of types Simple Interest, Compound Interest and Interest for RD A/C's
'Inputs :
'   i_CalcIntFromDate = Do Interest Calculation from this date
'   i_CalcIntUpToDate = Do Interest Calculation upto this date
'   i_AccNo = This is optional parameter. If it does not had any value, then
'             interest calculations will be done for all all A/C's of given deposit GL
'   i_IsItPreMatureAcc = If we want to calculate interest for premature account(s),
'             send TRUE value for this parameter. So that system will calculate
'             interest from effective date of a/c to given TO Date by appying given i_ROI
'   i_ROI = Rate of interest to apply.
'           When i_IsItPreMatureAcc = TRUE, then user should send this value.
'Outputs :
'   DepAccInfoArray(i,0) = Deposit A/C number
'   DepAccInfoArray(i,1) = Calculated Interest
'   DepAccInfoArray(i,2) = Actual date FROM which Interest was calculated
'   DepAccInfoArray(i,3) = Actual date UPTO which Interest was calculated
'   DepAccInfoArray(i,4) = Rate of Interest applied
'   DepAccInfoArray(i,5) = A/C balance at the time of calculating interest
'   DepAccInfoArray(i,6) = Error description, if any thing occurs w.r.t. the present a/c
'   DepAccInfoArray(i,7) = Maturity Date
'   DepAccInfoArray(i,8) = Maturity Amount

    On Error GoTo ErrHandler
    
    'Variable Declaration part
    Dim DepAccInfoArray() As Variant
    Dim rs As Object, rsAcc As Object
    Dim AccMaturityAmt As Currency, AccMaturityDate As Date
    Dim bCompoundInterest As Boolean, sCompoundFreq As String
    Dim bRecurringDeposit As Boolean, RoundOffTo As Double
    Dim tmpDate As Date, bFixedCmpDates As Boolean
    Dim CalculatedInterest As Currency
    Dim IntCalculatedFromDate As Date, IntCalculatedUptoDate As Date
    Dim AccROI As Currency, AccBalance As Currency
    Dim ArrIdx As Long, objFetch As Object
    Dim AccObj As Object, str As String, TempArr(), TempIdx As Long
    Dim strFlds As String, strWhereCond As String
    Dim sArr() As String, ErrMsg As String

    'Intialization of Variables. Set Class level variable "ConnError" to blank
    ConnError = ""
   
    'Step 1: Validate given input data
    If DoDataValidations(i_BranchCode, i_CurrencyCode, i_GLCode, i_CalcIntFromDate, _
    i_CalcIntUpToDate) = False Then
        GoTo ErrHandler
    End If
    
    'Step 1.1: ROI is mandatory for PreMature Interest Calculation
    If i_IsItPreMatureAcc = True And i_ROI <= 0 Then
        ConnError = "ROI should be specified, when you are choosing Pre Mature Interest Calculation."
        GoTo ErrHandler
    End If
       
    'Step 2: Get details of given Deposit GL, to know which type of calculation
    '        method is to follow. NOTE: Don't include checking of status parameters
    Set rs = CreateObject("adodb.recordset")
    strFlds = "NVL(intcompoundyn,'N') intcompoundyn,nvl(DATESFIXEDFORCOMPOUNDINGYN,'Y') FixedCmpDates, " & _
        " NVL(introundoffto,2) introundoffto, NVL(instsyn,'N') instsyn "
    strWhereCond = "moduleid='DEP' AND UPPER(trim(glcode))='" & _
        UCase(Trim(i_GLCode)) & "'"
    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rs = objFetch.SingleRecordSet("DEPTYPEMST", strFlds, strWhereCond)
    If rs.EOF = True Or rs.BOF = True Then
        ConnError = "Unable to retrieve details of given GL Code"
        GoTo ErrHandler
    End If
    
    If UCase(Trim(rs!FixedCmpDates)) = "N" Then
        bFixedCmpDates = False
    Else
        bFixedCmpDates = True
    End If
    If UCase(Trim(rs!intcompoundyn)) = "N" Then
        'i.e. Simple Interest Calculation Mode
        bCompoundInterest = False
        sCompoundFreq = ""
    Else
        'i.e. Compound Interest Calculation Mode
        'Posiible values are M = Monthly compounding; Q = Quarterly compounding;
        'H = Half Yearly COmpounding;  Y = Yearly Compounding
        bCompoundInterest = True
        sCompoundFreq = UCase(Trim(rs!intcompoundyn))
    End If
    If UCase(Trim(rs!instsyn)) = "Y" Then
        'Given Deposit is a Recurring Deposit
        bRecurringDeposit = True
        
        'Change Given "From date" to "its 1st day of given month" and
        ' "To Date" to "its Last day of given month"
        i_CalcIntFromDate = CDate(Format("01-" & Month(i_CalcIntFromDate) & "-" & Year(i_CalcIntFromDate), "dd-mm-yyyy"))

        i_CalcIntUpToDate = DateAdd("m", 1, i_CalcIntUpToDate)   'add one month to the given date
        i_CalcIntUpToDate = CDate(Format("01-" & Month(i_CalcIntUpToDate) & "-" & Year(i_CalcIntUpToDate), "dd-mm-yyyy"))
        i_CalcIntUpToDate = DateAdd("d", -1, i_CalcIntUpToDate) 'subtract one day from the given date
        
    Else
        'Given Deposit is a NON Recurring Deposit
        bRecurringDeposit = False
    End If
    RoundOffTo = rs!introundoffto
    
    If bCompoundInterest = True And Trim(sCompoundFreq) <> "M" And Trim(sCompoundFreq) <> "Q" _
       And Trim(sCompoundFreq) <> "H" And Trim(sCompoundFreq) <> "Y" Then
    
        ConnError = "Invalid Compound Frequency mode : " & sCompoundFreq
        GoTo ErrHandler
    
    End If
    Set rs = Nothing
    
    'Step 3: Get A/C's information (like Maturity Value, Maturity Date and ROI etc.)
    '        of a given Deposit GL, according to parameters
    strFlds = "AccNo,roi, maturitydate, maturityvalue,EFFDATE,opbal"
    strWhereCond = "UPPER(trim(branchcode))='" & UCase(Trim(i_BranchCode)) & _
        "' AND UPPER(trim(currencycode))='" & UCase(Trim(i_CurrencyCode)) & _
        "' AND UPPER(trim(glcode))='" & UCase(Trim(i_GLCode)) & _
        "' and status in ('R','r') and TranStatus in ('A','a') " & _
        "  and EFFDATE <='" & Format(i_CalcIntUpToDate, "dd-mmm-yyyy") & "'"
        '"  and maturitydate >='" & Format(i_CalcIntFromDate, "dd-mmm-yyyy") & "'"
        
    If Trim(i_AccNo) <> "" Then
        strWhereCond = strWhereCond & " AND trim(accno)='" & Trim(i_AccNo) & "'"
    End If

    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsAcc = CreateObject("adodb.recordset")
    Set rsAcc = objFetch.SingleRecordSet("DEPMST", strFlds, strWhereCond)
    If rsAcc.EOF = True Or rsAcc.BOF = True Then
        'ConnError = "A/C details not found for the given Deposit GL according to parameters"
        If Trim(i_AccNo) = "" Then
            'ConnError = "No A/C's are opened before given To Date (OR) All A/C's are matured before given From Date (OR) Check status of Account(s) once again."
            ConnError = "Unable to get A/C details of given Deposit because of any one of the following reasons." & vbCrLf & vbCrLf & _
            "# No A/C exist which is opened before To Date " & vbCrLf & _
            "# All A/C's are matured before given From Date" & vbCrLf & _
            "# No Accounts exists with Running and Approval Status."
        Else
            'ConnError = "This A/C might opened after To Date (OR) A/C might matured before given From Date (OR) Check status of Account once again."
            ConnError = "Unable to get details of given A/C because of any one of the following reasons." & vbCrLf & vbCrLf & _
            "# A/C opened after To Date " & vbCrLf & _
            "# A/C matured before given From Date" & vbCrLf & _
            "# Account not in Running and Approval Status."
        End If
        GoTo ErrHandler
    End If
    
    'Step 4: Process each account individually, to get its interest for the given period
    ArrIdx = 0
    ReDim DepAccInfoArray(rsAcc.RecordCount, 9)
    While rsAcc.EOF = False
        
        'Step 4.1: Intialize all a/c related variables
        DepAccInfoArray(ArrIdx, 6) = "" 'Error w.r.t. the present a/c
        CalculatedInterest = 0
        IntCalculatedFromDate = i_CalcIntFromDate
        IntCalculatedUptoDate = i_CalcIntUpToDate
        AccROI = 0
        AccBalance = 0
        
        'Step 4.2: Verification for required parameters of an a/c
        If i_IsItPreMatureAcc = False Then
            If IsNull(rsAcc!ROI) = True Or rsAcc!ROI = 0 Then
                DepAccInfoArray(ArrIdx, 6) = "Rate of Interest should not be Null and Zero"
                GoTo EndOfLoop
            ElseIf IsNull(rsAcc!maturitydate) = True Then
                DepAccInfoArray(ArrIdx, 6) = "Maturity Date of given Deposit A/C should not be Null"
                GoTo EndOfLoop
            ElseIf IsNull(rsAcc!maturityvalue) = True Then
                DepAccInfoArray(ArrIdx, 6) = "Maturity Value of given Deposit A/C should not be Null"
                GoTo EndOfLoop
            End If
        Else
            If IsNull(rsAcc!EFFDATE) = True Then
                DepAccInfoArray(ArrIdx, 6) = "Effective Date of given Deposit A/C should not be Null"
                GoTo EndOfLoop
            ElseIf IsNull(rsAcc!opbal) = True Or rsAcc!opbal <= 0 Then
                DepAccInfoArray(ArrIdx, 6) = "Opening Balance of given Deposit A/C should not be Null and Zero."
                GoTo EndOfLoop
            End If
        End If
        
        If i_IsItPreMatureAcc = True Then
            AccROI = i_ROI
        Else
            AccROI = rsAcc!ROI
            AccMaturityAmt = rsAcc!maturityvalue
            AccMaturityDate = rsAcc!maturitydate
        End If
   
        'Step 4.3: Get Last Interest Applied date of given deposit a/c, if it is not
        ' interest calculation of a pre matured a/c
        If i_IsItPreMatureAcc = False Then
            strFlds = "max(LastInterestAppliedDate) LastInterestAppliedDate"
            strWhereCond = "UPPER(trim(branchcode))='" & UCase(Trim(i_BranchCode)) & _
                "' AND UPPER(trim(currencycode))='" & UCase(Trim(i_CurrencyCode)) & _
                "' AND UPPER(trim(glcode))='" & UCase(Trim(i_GLCode)) & _
                "' AND trim(accno)='" & Trim(rsAcc!accno) & "'"
            
            Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
            Set rs = CreateObject("adodb.recordset")
            Set rs = objFetch.SingleRecordSet("DEPINTCALCULATIONDTLS", strFlds, strWhereCond)
            If rs.EOF = True Or rs.BOF = True Then
                DepAccInfoArray(ArrIdx, 6) = "Unable to get Last Interest applied date of given Deposit A/C"
                GoTo EndOfLoop
            ElseIf IsNull(rs!LastInterestAppliedDate) = True Then
                ConnError = "Last Interest applied date of given Deposit A/C should not be NULL"
                GoTo EndOfLoop
            End If
        End If
        
        'Step 4.4: Get A/C Balance, based on parameter
        Set AccObj = CreateObject("AccountDetails.AccDetails")
        If i_IsItPreMatureAcc = False Then
            str = ""
            str = AccObj.GetBalance(i_BranchCode, i_CurrencyCode, "DEP", i_GLCode, rsAcc!accno)
            If Mid(Trim(str), 1, 5) = "ERROR" Then
                ConnError = str
                GoTo EndOfLoop
            Else
                AccBalance = CCur(str)
            End If
            Set AccObj = Nothing
        Else
            AccBalance = rsAcc!opbal
        End If
        
        'Step 4.5: Finalize "From date" and "To Date" to calculate interest of present A/C
        'Interest calculated from date = Last interest applied date + 1 day
        
        If i_IsItPreMatureAcc = True Then
        
            IntCalculatedFromDate = rsAcc!EFFDATE
            IntCalculatedUptoDate = i_CalcIntUpToDate
            
            If bRecurringDeposit = True Then
                IntCalculatedFromDate = DateAdd("m", 1, rsAcc!EFFDATE)
                IntCalculatedFromDate = CDate(Format("01-" & Month(IntCalculatedFromDate) & "-" & Year(IntCalculatedFromDate), "dd-mm-yyyy"))
            End If
        Else
            IntCalculatedFromDate = DateAdd("d", 1, rs!LastInterestAppliedDate)
            Set rs = Nothing
        
            'Finalize "Interest calculated UpTo Date" based on Maturity Date
            If AccMaturityDate < i_CalcIntUpToDate Then
                IntCalculatedUptoDate = AccMaturityDate
            Else
                IntCalculatedUptoDate = i_CalcIntUpToDate
            End If
            
            'Do Validations on "From" & "To" dates of interest calculation
            If AccBalance <= 0 Then
                DepAccInfoArray(ArrIdx, 6) = "Interest can't be calculated. Because A/C balance is <=0"
                GoTo EndOfLoop
            ElseIf AccBalance >= AccMaturityAmt Then
                DepAccInfoArray(ArrIdx, 6) = "A/C balance is already crossed its maturity value"
                GoTo EndOfLoop
            ElseIf AccBalance < AccMaturityAmt And AccMaturityDate < IntCalculatedFromDate Then
                IntCalculatedUptoDate = i_CalcIntUpToDate
                CalculatedInterest = AccMaturityAmt - AccBalance
                CalculatedInterest = Round(CalculatedInterest, RoundOffTo)
                GoTo EndOfLoop
            End If
            If IntCalculatedFromDate > IntCalculatedUptoDate Then
                If IntCalculatedUptoDate = AccMaturityDate Then
                    DepAccInfoArray(ArrIdx, 6) = "Interest calculated upto its Maturity date"
                Else
                    DepAccInfoArray(ArrIdx, 6) = "Interest already calculated for this a/c for the given period"
                End If
                GoTo EndOfLoop
            End If
            If IntCalculatedFromDate <= AccMaturityDate And AccMaturityDate <= IntCalculatedUptoDate Then
                CalculatedInterest = 0
                If AccBalance > 0 Then
                    CalculatedInterest = AccMaturityAmt - AccBalance
                    If CalculatedInterest < 0 Then
                        CalculatedInterest = 0
                    End If
                    CalculatedInterest = Round(CalculatedInterest, RoundOffTo)
                End If
                GoTo EndOfLoop
            End If
        End If
        
        'Step 4.6: Calculate interest based on Parameters
        If bRecurringDeposit = True Then
           'Step 4.6.1: Calculating interest of an RD (Recurring Deposit) A/C
            
            'Take 1st day of given From date
            IntCalculatedFromDate = CDate(Format("01-" & Month(IntCalculatedFromDate) & "-" & Year(i_CalcIntFromDate), "dd-mm-yyyy"))

            'Take Last day of given ToDate
            IntCalculatedUptoDate = DateAdd("m", 1, IntCalculatedUptoDate)  'add one month to the given date
            IntCalculatedUptoDate = CDate(Format("01-" & Month(IntCalculatedUptoDate) & "-" & Year(IntCalculatedUptoDate), "dd-mm-yyyy"))
            IntCalculatedUptoDate = DateAdd("d", -1, IntCalculatedUptoDate) 'subtract one day from the given date
            
            ErrMsg = ""
            CalculatedInterest = GetRDInterest(i_BranchCode, i_CurrencyCode, i_GLCode, rsAcc!accno, _
            AccROI, IntCalculatedFromDate, IntCalculatedUptoDate, sCompoundFreq, i_ApplicationDate, ErrMsg)
                
            If Trim(ErrMsg) <> "" Then
                DepAccInfoArray(ArrIdx, 6) = ErrMsg
                GoTo EndOfLoop
            Else
                If i_IsItPreMatureAcc = False Then
                    'Always (Interest Amount + principle Amount) should not cross Maturity Amount
                    If ((CalculatedInterest + AccBalance) > AccMaturityAmt) Then
                        CalculatedInterest = AccMaturityAmt - AccBalance
                    End If
                End If
            End If
        
        Else
        'Step 4.6.2: Calculating interest for other than Cumulative (OR) RD(Recurring Deposit) A/C
        
            If bCompoundInterest = False Then
                'i.e. Simple Interest
                CalculatedInterest = GetSimpleInterest(AccBalance, _
                    AccROI, IntCalculatedFromDate, IntCalculatedUptoDate)
            ElseIf bCompoundInterest = True Then
                'i.e. Compound Interest
                CalculatedInterest = GetCompoundInterest(AccBalance, AccROI, _
                    IntCalculatedFromDate, IntCalculatedUptoDate, sCompoundFreq, bFixedCmpDates)
                    
                If i_IsItPreMatureAcc = False Then
                    'Always (Interest Amount + principle Amount) should not cross Maturity Amount
                    If ((CalculatedInterest + AccBalance) > AccMaturityAmt) Then
                        CalculatedInterest = AccMaturityAmt - AccBalance
                    End If
                End If
            End If
        End If
        
        'Step 4.6.3: Round off Interest, according to parameter
        CalculatedInterest = Round(CalculatedInterest, RoundOffTo)
        
EndOfLoop:
        'Step 4.6.4: Assigning obtained values into an array w.r.t. present a/c
        DepAccInfoArray(ArrIdx, 0) = rsAcc!accno 'Deposit A/C Number
        DepAccInfoArray(ArrIdx, 1) = CalculatedInterest 'Calculated Interest
        DepAccInfoArray(ArrIdx, 2) = IntCalculatedFromDate 'Actual date FROM which Interest was calculated
        DepAccInfoArray(ArrIdx, 3) = IntCalculatedUptoDate 'Actual date UPTO which Interest was calculated
        DepAccInfoArray(ArrIdx, 4) = AccROI  'Rate of Interest applied
        DepAccInfoArray(ArrIdx, 5) = AccBalance 'A/C balance at the time of calculating interest
        If i_IsItPreMatureAcc = False Then
            DepAccInfoArray(ArrIdx, 7) = AccMaturityDate 'Maturity date of present A/C
            DepAccInfoArray(ArrIdx, 8) = AccMaturityAmt 'Maturity Amount of present A/C
        Else
            DepAccInfoArray(ArrIdx, 7) = ""
            DepAccInfoArray(ArrIdx, 8) = ""
        End If
        
        ArrIdx = ArrIdx + 1
        rsAcc.MoveNext
    Wend
    
    'Return array to caller function
    CalcIntForADepositAcc = DepAccInfoArray
    
    Exit Function
ErrHandler:
    If Err.Number <> 0 Then
        ConnError = Err.Description
    End If
    CalcIntForADepositAcc = DepAccInfoArray
End Function

Private Function GetLastMonthDate(i_GivenDate As Date) As Date
'Desc: Return Last month end date for the given date

    Dim tmpDate As Date
    
    tmpDate = CDate(Format("01-" & Month(i_GivenDate) & "-" & Year(i_GivenDate), "dd-mm-yyyy"))
    tmpDate = DateAdd("d", -1, tmpDate)
    
    GetLastMonthDate = tmpDate

End Function

Private Function GetSimpleInterest(ByVal i_PrincipleAmt As Currency, _
ByVal i_ROI As Currency, ByVal i_FromDt As Date, ByVal i_ToDt As Date) As Currency

    
    Dim NoOfMonths As Integer, NoOfDays As Integer
    Dim TempDate As Date, InterestAmt As Currency
    Dim rs As Object, objFetch As Object
    
    'Get Date Difference between given 2 dates as "No Of Months" and "No of Days"
    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rs = CreateObject("ADODB.Recordset")
    Set rs = objFetch.SingleRecordSet("dual", "months_between('" & _
            Trim(Format(i_ToDt, "dd-mmm-yyyy")) & "','" & _
            Trim(Format(i_FromDt, "dd-mmm-yyyy")) & "') DiffMOnths", "1=1")
    NoOfMonths = Int(rs!DiffMOnths)
    If NoOfMonths > 0 Then
        TempDate = DateAdd("m", NoOfMonths, i_FromDt)
    Else
        TempDate = i_FromDt
    End If
    NoOfDays = DateDiff("d", TempDate, i_ToDt) + 1
    
    'Calculate Simple Interest
    InterestAmt = 0
    If NoOfMonths > 0 Then
        InterestAmt = (i_PrincipleAmt * NoOfMonths * i_ROI) / (1200)
    End If
    If NoOfDays > 0 Then
        InterestAmt = InterestAmt + ((i_PrincipleAmt * NoOfDays * i_ROI) / (36500))
    End If
    Set objFetch = Nothing
    Set rs = Nothing

    'Return the Result
    GetSimpleInterest = InterestAmt
    
End Function

Private Function GetCompoundInterest(ByVal i_PrincipleAmt As Currency, _
ByVal i_ROI As Currency, ByVal i_FromDt As Date, ByVal i_ToDt As Date, _
ByVal i_CompoundFreq As String, ByVal i_bFixedCmpDates As Boolean) As Currency
'Inputs:
'   i_CompoundFreq = Compounding Frequency like M = Monthly,
'       Q = Quarterly; H = Half Yearly; Y = Yearly;
'   i_bFixedCmpDates = TRUE, when we take compound dates like 31-mar-year, 30-sep-year etc.
'       False, when we take 1st compound date = Given from date + Compound months( ex: 3 when CmpMode = Quarterly)
    
    Dim InterestAmt As Currency, bResult As Boolean
    Dim ArrCmpDates() As Variant, intIdx As Integer, NoOfCompoundPeriods As Integer
    Dim tmpInterest As Currency, tmpPrincipleAmt As Currency
    
    'Ex: 3 when Quarterly compound, 1 when MOnthly compound, 6 for Half year, 12 for Yearly compound
    Dim NoOfMonthsInACompoundPeriod As Integer, Denominator As Long
    
    If UCase(Trim(i_CompoundFreq)) = "M" Then
        Denominator = 1200
    ElseIf UCase(Trim(i_CompoundFreq)) = "Q" Then
        Denominator = 400
    ElseIf UCase(Trim(i_CompoundFreq)) = "H" Then
        Denominator = 200
    ElseIf UCase(Trim(i_CompoundFreq)) = "Y" Then
        Denominator = 100
    Else
        Err.Raise "999", , "Invalid Compound Frequency mode : " & UCase(Trim(i_CompoundFreq))
    End If
    
    If i_bFixedCmpDates = True Then
    'i.e. Compounding Months are fixed irrespective of given From Date & To Date
    'Ex: If i_CompoundFreq ="Q" then Compounding months are March,June, September,December
        bResult = GetCompoundDates(i_FromDt, i_ToDt, i_CompoundFreq, ArrCmpDates)
    Else
    'i.e. Compounding Months will depend on given From Date & To Date
    'Ex: If i_CompoundFreq ="Q" then Compounding Months are From date + 3 months and so on.
        bResult = GetFloatingCompoundDates(i_FromDt, i_ToDt, i_CompoundFreq, ArrCmpDates)
    End If
    
    If bResult = False Then
        'i.e. there is no compound dates, between given 2 dates.
        'So, apply simple interest
        InterestAmt = GetSimpleInterest(i_PrincipleAmt, i_ROI, i_FromDt, i_ToDt)
    Else
        'Compound interest will be calculated in 3 steps
        'step A: Apply Simple interest for the period between "given From date"
        '        and "first compound date"
        'Step B: Apply Compound Interest formula for the period between
        '        "First compound date + 1" and "Last Compound date"
        'Step C: Again apply Simple Interest for the period between
        '        "Last Compound date +1 " and "Given To Date"
        
        'Applying "Step A" process
        InterestAmt = 0
        InterestAmt = GetSimpleInterest(i_PrincipleAmt, i_ROI, i_FromDt, ArrCmpDates(0))
        tmpPrincipleAmt = i_PrincipleAmt + InterestAmt
        
        'Applying "Step B" process
        intIdx = 1
        If (UBound(ArrCmpDates)) > 1 Then
            'Apply compound Interest formula :
            'Interest = [p(1 + (r/100) ) to the power of n] - p
            NoOfCompoundPeriods = UBound(ArrCmpDates) - 1
            tmpInterest = (1 + (i_ROI / Denominator)) ^ NoOfCompoundPeriods
            tmpInterest = (tmpInterest * tmpPrincipleAmt) - tmpPrincipleAmt
            
            InterestAmt = InterestAmt + tmpInterest
            tmpPrincipleAmt = tmpPrincipleAmt + tmpInterest
        End If
        
        'Applying "Step C" process
        intIdx = UBound(ArrCmpDates) - 1
        If ArrCmpDates(intIdx) < i_ToDt Then
        'i.e. If Last Compound date < Interest calculate upto date
            tmpInterest = GetSimpleInterest(tmpPrincipleAmt, i_ROI, _
                ArrCmpDates(intIdx) + 1, i_ToDt)
                
            InterestAmt = InterestAmt + tmpInterest
        End If
    End If

    'Return the Result
    GetCompoundInterest = InterestAmt
    
End Function

Private Function GetCompoundDates(ByVal i_FromDt As Date, ByVal i_ToDt As Date, _
ByVal i_CompoundFreq As String, ByRef o_ArrCmpDates() As Variant) As Boolean
'Desc: Return all the compounding dates between 2 given dates.
    'On Error GoTo EH

    Dim StartDt As Date, EndDt As Date
    Dim StMonth As Integer, EndMonth As Integer
    Dim intIdx As Integer, TempDt As Date
    Dim TempStartDt As Date, TempEndDt As Date
    Dim ArrTmp() As Variant, ArrIdx As Integer
    Dim bFlag As Boolean
    
    StartDt = i_FromDt 'DateAdd("d", -noofdays, ProductDt)
    EndDt = i_ToDt ' ProductDt
    
    TempStartDt = StartDt
    intIdx = 0
    ArrIdx = 0
    Do While Year(TempStartDt) <= Year(EndDt)
        If Year(TempStartDt) < Year(EndDt) Then
            TempEndDt = CDate("31-12-" & Year(TempStartDt))
        Else
            TempEndDt = EndDt
        End If
        
        Select Case UCase(Trim(i_CompoundFreq))
            Case "Y": '31-Mar-year
                
                'i.e. TempStartDate <= 31-mar-year <= TempendDate
                If TempStartDt <= CDate("31-03-" & Year(TempStartDt)) And _
                CDate("31-03-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("31-03-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
                
            Case "H": '31-Mar-year, 30-Sep-year
                            
                'i.e. TempStartDate <= 31-mar-year <= TempendDate
                If TempStartDt <= CDate("31-03-" & Year(TempStartDt)) And _
                CDate("31-03-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("31-03-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
                
                'i.e. TempStartDate <= 30-Sep-year <= TempendDate
                If TempStartDt <= CDate("30-09-" & Year(TempStartDt)) And _
                CDate("30-09-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("30-09-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
                            
            Case "Q": '31-Mar-year, 30-June-year, 30-Sep-year, 31-Dec-year
                
                'i.e. TempStartDate <= 31-mar-year <= TempendDate
                If TempStartDt <= CDate("31-03-" & Year(TempStartDt)) And _
                CDate("31-03-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("31-03-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
                
                'i.e. TempStartDate <= 30-June-year <= TempendDate
                If TempStartDt <= CDate("30-06-" & Year(TempStartDt)) And _
                CDate("30-06-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("30-06-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
            
                'i.e. TempStartDate <= 30-Sep-year <= TempendDate
                If TempStartDt <= CDate("30-09-" & Year(TempStartDt)) And _
                CDate("30-09-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("30-09-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
            
                'i.e. TempStartDate <= 31-Dec-year <= TempendDate
                If TempStartDt <= CDate("31-12-" & Year(TempStartDt)) And _
                CDate("31-12-" & Year(TempStartDt)) <= TempEndDt Then
                    ReDim Preserve ArrTmp(ArrIdx + 1)
                    ArrTmp(ArrIdx) = CDate("31-12-" & Year(TempEndDt))
                    ArrIdx = ArrIdx + 1
                End If
            
            Case "M":
                StMonth = Month(TempStartDt):   EndMonth = Month(TempEndDt)
                bFlag = False
                
                For intIdx = StMonth To EndMonth
                    Select Case intIdx
                        Case 1, 3, 5, 7, 8, 10, 12:  'day = 31
                            If intIdx = EndMonth Then
                                If Day(TempEndDt) = 31 Then
                                    bFlag = True
                                    TempDt = CDate("31-" & intIdx & "-" & Year(TempEndDt))
                                End If
                            Else
                                bFlag = True
                                TempDt = CDate("31-" & intIdx & "-" & Year(TempEndDt))
                            End If
                        Case 4, 6, 9, 11:  'day = 30
                            If intIdx = EndMonth Then
                                If Day(TempEndDt) = 30 Then
                                    bFlag = True
                                    TempDt = CDate("30-" & intIdx & "-" & Year(TempEndDt))
                                End If
                            Else
                                bFlag = True
                                TempDt = CDate("30-" & intIdx & "-" & Year(TempEndDt))
                            End If
                        Case 2:  'day = 28 or 29
                            If (Year(TempEndDt) Mod 4 = 0 And Year(TempEndDt) Mod 100 <> 0) Or Year(TempEndDt) Mod 400 = 0 Then
                                If intIdx = EndMonth Then
                                    If Day(TempEndDt) = 29 Then
                                        bFlag = True
                                        TempDt = CDate("29-" & intIdx & "-" & Year(TempEndDt))
                                    End If
                                Else
                                    bFlag = True
                                    TempDt = CDate("29-" & intIdx & "-" & Year(TempEndDt))
                                End If
                             Else
                                If intIdx = EndMonth Then
                                    If Day(TempEndDt) = 28 Then
                                        bFlag = True
                                        TempDt = CDate("28-" & intIdx & "-" & Year(TempEndDt))
                                    End If
                                Else
                                    bFlag = True
                                    TempDt = CDate("28-" & intIdx & "-" & Year(TempEndDt))
                                End If
                             End If
                    End Select
                    
                    If bFlag = True Then
                        ReDim Preserve ArrTmp(ArrIdx + 1)
                        ArrTmp(ArrIdx) = TempDt
                        ArrIdx = ArrIdx + 1
                    End If
                    bFlag = False
                Next
        End Select
        
        'If Year(TempStartDt) <= Year(EndDt) Then
        TempStartDt = CDate("01-01-" & Year(TempStartDt) + 1)
        'End If
    Loop

    
    o_ArrCmpDates = ArrTmp
    If ArrIdx = 0 Then
        GetCompoundDates = False
    Else
        GetCompoundDates = True
    End If
'    Exit Function
'EH:
'    'MsgBox Err.Number & vbTab & Err.Description, vbCritical, App.Title
'    ConnError = Err.Number & ";" & Err.Description
'    GetCompoundDates = False
End Function

Private Sub SetDBConnection()
    
    Set objDBConn = New ADODB.Connection
    objDBConn.ConnectionString = "data source=ver3;user id=v3; password=esmart123;"
    objDBConn.CursorLocation = adUseClient
    objDBConn.Provider = "MSDAORA"
    objDBConn.Open
        
    If objDBConn.State <> 1 Then Err.Raise "999", "", "DB Connection was not established"
        
End Sub

Private Function DoDataValidations(ByVal i_BranchCode As String, _
    ByVal i_CurrencyCode As String, ByVal i_GLCode As String, _
    ByVal i_CalcIntFromDate As Date, ByVal i_CalcIntUpToDate As Date) As Boolean
    
    ConnError = ""
    
    If Trim(i_BranchCode) = "" Then
        ConnError = "Branch code should not be empty"
    ElseIf Trim(i_CurrencyCode) = "" Then
        ConnError = "Currency code should not be empty"
    ElseIf Trim(i_GLCode) = "" Then
        ConnError = "Deposit GL code should not be empty"
    ElseIf i_CalcIntFromDate > i_CalcIntUpToDate Then
        ConnError = "Interest Calculate From date should not be greater than Interest Calculate To Date"
    End If
    
    If Trim(ConnError) = "" Then
        DoDataValidations = True
    Else
        DoDataValidations = False
    End If

End Function

Private Function GetFloatingCompoundDates(ByVal i_FromDt As Date, ByVal i_ToDt As Date, _
ByVal i_CompoundFreq As String, ByRef o_ArrCmpDates() As Variant) As Boolean
'Desc: Return all the compounding dates between 2 given dates, using
'      the method like from date + compounding frquency months,
'      Instead of fixed compound dates like 31-Mar-2004, 30-sep-2004 etc.
'      Ex:  i_FromDt= '20-sep-2004'; i_CompoundFreq = 3 months
'         Then first compound date = i_fromdt + 3 months
    'On Error GoTo EH

    Dim StartDt As Date, EndDt As Date
    Dim StMonth As Integer, EndMonth As Integer
    Dim intIdx As Integer, TempDt As Date
    Dim TempStartDt As Date, TempEndDt As Date
    Dim ArrTmp() As Variant, ArrIdx As Integer
    Dim bFlag As Boolean
    Dim MonthsToAdd As Integer
    
    Select Case UCase(Trim(i_CompoundFreq))
        Case "M":
                MonthsToAdd = 1
        Case "Q":
                MonthsToAdd = 3
        Case "H":
                MonthsToAdd = 6
        Case "Y":
                MonthsToAdd = 12
        Case Default:
            GetFloatingCompoundDates = False
            Exit Function
    End Select
    
    StartDt = i_FromDt
    EndDt = i_ToDt

    TempStartDt = StartDt
    intIdx = 0
    ArrIdx = 0
    
    TempStartDt = DateAdd("m", MonthsToAdd, TempStartDt)
    TempStartDt = TempStartDt - 1
    
    Do While TempStartDt < EndDt
        ReDim Preserve ArrTmp(ArrIdx + 1)
        ArrTmp(ArrIdx) = TempStartDt
        ArrIdx = ArrIdx + 1
        
        TempStartDt = DateAdd("m", MonthsToAdd, TempStartDt)
        TempStartDt = TempStartDt - 1
    Loop
    
    o_ArrCmpDates = ArrTmp
    If ArrIdx = 0 Then
        GetFloatingCompoundDates = False
    Else
        GetFloatingCompoundDates = True
    End If
'    Exit Function
'EH:
'    'MsgBox Err.Number & vbTab & Err.Description, vbCritical, App.Title
'    ConnError = Err.Number & ";" & Err.Description
'    GetFloatingCompoundDates = False
End Function

Private Function GetRDInterest(ByVal i_BranchCode As String, ByVal i_CurrencyCode As String, _
ByVal i_GLCode As String, ByVal i_AccNo As String, ByVal i_ROI As Currency, _
ByVal i_FromDt As Date, ByVal i_ToDt As Date, ByVal i_CompoundFreq As String, _
ByVal i_ApplicationDate As Date, ByRef o_ErrMsg As String) As Currency
'Inputs:
'   i_CompoundFreq = Compounding Frequency like M = Monthly,
'       Q = Quarterly; H = Half Yearly; Y = Yearly;
    
    Dim InterestAmt As Currency, bResult As Boolean
    Dim ArrCmpDates() As Variant, intIdx As Integer, NoOfCompoundPeriods As Integer
    Dim tmpInterest As Currency, tmpPrincipleAmt As Currency
    Dim AccBalance As Currency, LastMonthDate As Date
    Dim objFetch As Object, rs As Object, NoOfMonths As Long, NoOfDays As Integer
    Dim idx As Long, AccObj As Object, TempArr(), sArr() As String
    Dim TotalCompoundInt As Currency, PresentMonthInt As Currency, SumOfIntToAdd As Currency
   
    'Get all compound dates between given from date & to date
    bResult = False
    If Trim(i_CompoundFreq) <> "" Then
        bResult = GetCompoundDates(i_FromDt, i_ToDt, i_CompoundFreq, ArrCmpDates)
    End If
    
    'Find no. of Months between given 2 dates as "No Of Months" and "No of Days"
    Set objFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rs = CreateObject("ADODB.Recordset")
    Set rs = objFetch.SingleRecordSet("dual", "months_between('" & _
        Trim(Format(i_ToDt, "dd-mmm-yyyy")) & "','" & _
        Trim(Format(i_FromDt, "dd-mmm-yyyy")) & "') DiffMOnths", "1=1")
    NoOfMonths = Int(rs!DiffMOnths) + 1
    Set objFetch = Nothing
    Set rs = Nothing
    
    'Calculate interest of every month between given from date & to date
    LastMonthDate = i_FromDt
    TotalCompoundInt = 0: SumOfIntToAdd = 0
    For idx = 1 To NoOfMonths
    
        'For the Recurring Deposit A/C, get Last Month End balance, for every month
        LastMonthDate = DateAdd("m", idx - 1, i_FromDt)
        LastMonthDate = GetLastMonthDate(LastMonthDate)
        
        'Then get balance on Last Month end date
        Set AccObj = CreateObject("AccountDetails.AccDetails")
        
        TempArr = AccObj.GetBackDatedBalance(i_BranchCode, i_CurrencyCode, "DEP", _
            i_GLCode, Format(LastMonthDate, "dd-mmm-yyyy"), _
            Format(i_ApplicationDate, "dd-mmm-yyyy"), i_AccNo)
        
        Set AccObj = Nothing
        If Trim(TempArr(0)) = "No Records" Then
            'Err.Raise "999", , TempArr(0)
            o_ErrMsg = "Unable to retrieve RD A/C balance on Date : " & LastMonthDate
            GetRDInterest = 0
            Exit Function
        Else
            sArr = Split(TempArr(0), "*")
            AccBalance = CCur(sArr(2))
        End If
        AccBalance = AccBalance + TotalCompoundInt
        
        'Then calculate interest of that month (interest = pnr/100)
        PresentMonthInt = (AccBalance * 1 * i_ROI) / 1200
        SumOfIntToAdd = SumOfIntToAdd + PresentMonthInt
        
        'Check whether the last month date is the compounding date or not
        If bResult = True Then 'i.e. Compound dates are existed between given i/p dates
            If IsItACompoundingDate(ArrCmpDates, LastMonthDate) = True Then
                TotalCompoundInt = TotalCompoundInt + SumOfIntToAdd
                SumOfIntToAdd = 0
            End If
        End If
        
    Next idx

    'Return the Result
    GetRDInterest = TotalCompoundInt + SumOfIntToAdd
    
End Function

Private Function IsItACompoundingDate(ByRef i_CmpDates() As Variant, ByVal i_DateToCheck As Date) _
As Boolean
    
    Dim idx As Long
    
    IsItACompoundingDate = False
    
    For idx = 0 To (UBound(i_CmpDates) - 1)
    
        If i_DateToCheck = i_CmpDates(idx) Then
            IsItACompoundingDate = True
            Exit For
        ElseIf i_DateToCheck < i_CmpDates(idx) Then
            Exit For
        End If
        
    Next idx
    
End Function

