VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   615
      Left            =   2760
      TabIndex        =   0
      Top             =   2760
      Width           =   2535
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim ObjFetchRec As New Fetchrecordset
Dim ObjTrans As New TransactionMethods
Dim RecInstr As Recordset
Dim RecInst As Recordset
Public Function InstrTransaction(Branchcode As String, _
                                 InstCode As String, InstName As String, _
                                 BookLeafYn As String, SeriesNo As String, _
                                 NoOfBookLeaf As Long, status As String, _
                                BookLeafStno As Long, BookLeafEndno As Long, _
                                 StockRecDate As String, _
                                AppDate As String, UserId As String, MachineId As String, _
                                Optional Leafperbook As Long) As String
 ''declaring variables
 Dim StrUpdate As String
Dim StrTabName As String
Dim StrInsert As String
Dim StrInsFldNames  As String
Dim StrInsFldValues(0)  As String
Dim StrDelete As String
Dim StrDelCondition As String
Dim StrUpFldValues(0) As Variant
Dim StrPrevUpdate As String
Dim strPrevUpFldNames As String
Dim StrPrevUpFldValues() As String
Dim StrPrevCondition As String
Dim BrCode As String
Dim InstrCode As String
Dim BkLfYn As String
Dim serno As String
Dim NoofbkLf As Long
Dim BkLfStno As Long
Dim BkLfEndNo As Long
Dim LfPerBk As Long
Dim LfNo As Long
Dim InstrName As String
Dim St As String
Dim StockRecDt As String
Dim AppDt As String
Dim UsrId As String
Dim MachId As String
Dim BkSt As Long
Dim BkEd As Long
'' storing arguments in variables

     BrCode = UCase(Trim(Branchcode))
     InstrCode = UCase(Trim(InstCode))
     BkLfYn = UCase(Trim(BookLeafYn))
     serno = UCase(Trim(SeriesNo))
     NoofbkLf = Trim(NoOfBookLeaf)
     BkLfStno = Trim(BookLeafStno)
     BkLfEndNo = Trim(BookLeafEndno)
     LfPerBk = Trim(Leafperbook)
     InstrName = UCase(Trim(InstName))
     St = UCase(Trim(status))
     StockRecDt = StockRecDate
     AppDt = AppDate
     UsrId = UserId
     MachId = MachineId
        Set RecInstr = CreateObject("adodb.recordset")
        Set RecInst = CreateObject("adodb.recordset")
        StrTabName = "GENINSTRUMENTSTOCKDTLS"
        'Set ObjFetchRec = CreateObject("queryrecordsets.fetchrecordsets")

    On Error GoTo ErrHnd
        If BkLfYn = "B" Then

             StrDelCondition = "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookseriesno))='" & serno & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "trim(bookstartno)=" & BkLfStno & " and " & _
                            "trim(bookendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'"
             
               
            Set RecInstr = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
                            "leavesperbook,noofbooks", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookseriesno))='" & serno & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "trim(bookstartno)=" & BkLfStno & " and " & _
                            "trim(bookendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
            
            If Not RecInstr.EOF Then
        
        
                Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "bookstartno,bookendno,noofbooks", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "upper(trim(bookseriesno))='" & serno & "' and " & _
                            "upper(trim(leavesperbook))='" & RecInstr(0) & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(bookstartno)>" & Val(BkLfStno) & "", "Bookstartno")
        
                
                Bsno = BkLfStno
                    If Not RecInst.EOF Then
                    ReDim StrPrevUpFldValues(RecInst.RecordCount - 1)
                        Do Until RecInst.EOF
                           Beno = Bsno + Val(RecInstr(0)) * Val(RecInst(2)) - 1
                            StrPrevUpFldValues(icnt) = "" & Bsno & "~" & Beno & ""
                            Bsno = Val(Beno) + 1
                            icnt = icnt + 1
                            StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & serno & "' and " & _
                                        "upper(trim(leavesperbook))='" & RecInstr(0) & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInst(2) & "' and " & _
                                         "Trim(bookstartno) = " & RecInst(0) & " and " & _
                                        "trim(bookendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
           
                        RecInst.MoveNext
                        Loop
                        strPrevUpFldNames = "bookstartno,bookendno"
                StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
                    If StrPrevUpdate <> "Trans Completed" Then
                        InstrTransaction = "update failed in  " & StrTabName
                        Exit Function
                    End If
                    
                End If
            Else
                InstrTransaction = "no records in " & StrTabName
                Exit Function
            End If

    
    Set RecInst = Nothing
    StrDelete = ObjTrans.DeleteRecord(StrTabName, StrDelCondition)
                If StrDelete <> "Trans Completed" Then
                        InstrTransaction = "Record not Deleted in GENINSTRUMENTSTOCKDTLS "
                        Exit Function
                End If
        'Insert the update record as new record into database
        'Dim RecInst As Recordset
        
        Set RecInst = CreateObject("adodb.recordset")
        
        Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(bookendno),0)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(bookseriesno))='" & serno & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "upper(trim(leavesperbook))='" & LfPerBk & "' group by bookseriesno")
        
            If Not RecInst.EOF Then
                BkSt = Val(RecInst(0)) + 1
                BkEd = Val(BkSt) + Val(LfPerBk) * Val(NoofbkLf) - 1
            Else
                BkSt = 1
                BkEd = Val(BkSt) + Val(LfPerBk) * Val(NoofbkLf) - 1
            End If

            StrInsFldNames = "BRANCHCODE,INSTRCODE,BOOKYESNO,LEAVESPERBOOK,noofbooks," & _
                            "BOOKSERIESNO,BOOKSTARTNO,BOOKENDNO,STATUS, " & _
                            "STOCKRECEIVEDDATE,APPLICATIONDATE,INSTRNAME, " & _
                            "USERID,MACHINEID"
            StrInsFldValues(0) = "'" & BrCode & "','" & InstrCode & "','Y'," & _
                                "'" & LfPerBk & "','" & NoofbkLf & "', " & _
                                "'" & serno & "'," & _
                                "'" & BkSt & "','" & BkEd & "'," & _
                                "'" & St & "',to_date('" & StockRecDt & "','dd-mm-yyyy')," & _
                                "to_date('" & AppDate & "','dd-mm-yyyy')," & _
                                "'" & InstrName & "','" & UsrId & "'," & _
                                "'" & MachId & "'"

        StrInsert = ObjTrans.InsertRecord(StrTabName, StrInsFldNames, StrInsFldValues)
            If StrInsert <> "Trans Completed" Then
                    InstrTransaction = "Insert failed in " & StrTabName
                    Exit Function
            End If
  

ElseIf BkLfYn = "L" Then
            StrDelCondition = "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "upper(trim(leafseriesno))='" & serno & "' and " & _
                            "trim(leafstartno)=" & BkLfStno & " and " & _
                            "trim(leafendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'"
             
               

  Set RecInstr = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
             "leafstartno,leafendno", _
             "upper(trim(branchcode))='" & BrCode & "' and " & _
             "upper(trim(instrcode))='" & InstrCode & "' and " & _
             "upper(trim(leafseriesno))='" & serno & "' and " & _
             "upper(trim(leafyesno))='Y' and " & _
             "trim(leafstartno)=" & BkLfStno & " and " & _
             "trim(leafendno)=" & BkLfEndNo & " and " & _
             "upper(trim(status))='STOCK'")
            
    If Not RecInstr.EOF Then
        
           Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "leafstartno,leafendno,noofleaves", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(leafseriesno))='" & serno & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(leafstartno)>" & Val(BkLfStno) & "", "leafstartno")
        
                
                Bsno = BkLfStno
                    If Not RecInst.EOF Then
                    ReDim StrPrevUpFldValues(RecInst.RecordCount - 1)
                        Do Until RecInst.EOF
                           Beno = Val(Bsno) + Val(RecInst(2)) - 1
                            StrPrevUpFldValues(icnt) = "" & Bsno & "~" & Beno & ""
                            Bsno = Val(Beno) + 1
                            icnt = icnt + 1
                            StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & serno & "' and " & _
                                        "upper(trim(noofleaves))='" & RecInst(2) & "' and " & _
                                        "Trim(leafstartno) = " & RecInst(0) & " and " & _
                                        "trim(leafendno)=" & RecInst(1) & " and " & _
                                        "upper(trim(status))='STOCK'"
                        RecInst.MoveNext
                        Loop
                         strPrevUpFldNames = "bookstartno,bookendno"
        StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
            If StrPrevUpdate <> "Trans Completed" Then
                InstrTransaction = "update failed in  " & StrTabName
                Exit Function
            End If
        
                        
        End If
      Else
        InstrTransaction = "no records in " & StrTabName
        Exit Function
    End If
      
    
        StrDelete = ObjTrans.DeleteRecord(StrTabName, StrDelCondition)
                If StrDelete <> "Trans Completed" Then
                        InstrTransaction = "Record not Deleted in GENINSTRUMENTSTOCKDTLS "
                        Exit Function
                End If
        
    Set RecInst = Nothing
        'Insert the update record as new record into database
        'Dim RecInst As Recordset
        
        Set RecInst = CreateObject("adodb.recordset")
        
        Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(leafendno),0)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(leafyesno))='Y' and " & _
                    "upper(trim(leafseriesno))='" & serno & "'" & _
                     " group by leafseriesno")
        
            If Not RecInst.EOF Then
                BkSt = Val(RecInst(0)) + 1
                BkEd = Val(BkSt) + Val(NoofbkLf) - 1
            Else
                BkSt = 1
                BkEd = Val(BkSt) + Val(NoofbkLf) - 1
            End If
        
            StrInsFldNames = "BRANCHCODE,INSTRCODE,leafYESNO,noofleaves," & _
                            "LEAFSERIESNO,LEAFSTARTNO,LEAFENDNO,STATUS, " & _
                            "STOCKRECEIVEDDATE,APPLICATIONDATE,INSTRNAME, " & _
                            "USERID,MACHINEID"
            StrInsFldValues(0) = "'" & BrCode & "','" & InstrCode & "','Y'," & _
                                "'" & NoofbkLf & "','" & serno & "'," & _
                                "'" & BkSt & "','" & BkEd & "'," & _
                                "'" & St & "',to_date('" & StockRecDt & "','dd-mm-yyyy')," & _
                                "to_date('" & AppDate & "','dd-mm-yyyy')," & _
                                "'" & InstrName & "','" & UsrId & "'," & _
                                "'" & MachId & "'"

        StrInsert = ObjTrans.InsertRecord(StrTabName, StrInsFldNames, StrInsFldValues)
            If StrInsert <> "Trans Completed" Then
                    InstrTransaction = "Insert failed in " & StrTabName
                    Exit Function
            End If
  

   
End If
InstrTransaction = "Transaction Successful"
Exit Function
ErrHnd:
InstrTransaction = Err.Number & Err.Description

End Function

Private Sub Command1_Click()
Dim Str As String
'str = InstrTransaction("0001", "CHQ", "Cheque", "B", "ABC", "10", "STOCK", "1001", "2200", "12-09-2001", "12-09-2001", "U001", "M001", "20")
Str = InstrTransaction("0001", "CHQ", "Cheque", "L", "LABC", "60", "STOCK", "121", "170", "12-09-2001", "12-09-2001", "U001", "M001")
MsgBox Str
End Sub
Public Function leaf()
 
 
    
End Function

