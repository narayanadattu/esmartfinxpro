VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Form2"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form2"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   255
      Left            =   720
      TabIndex        =   0
      Top             =   1200
      Width           =   2415
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'Dim ObjFetchRec As Object
'Dim ObjTrans As Object
Dim ObjFetchRec As New Fetchrecordset
Dim ObjTrans As New TransactionMethods

Public Function DeptModifyTran(Branchcode As String, IssuedTo As String, _
                                Moduleid As String, _
                                InstCode As String, BookYesNo As String, Bookleafseriesno As String, LeavesperBook As Long, _
                                PreNoofBooks As Long, AftNoofBooks As Long, BookLeafStartNo As Long, _
                                ChqStNo As Variant, PreChqStNo As Variant, Applicationdate As String, UserId As String, _
                                MachineId As String) As String
Dim BrCode As String
Dim IssueTo As String
Dim Moduelcode As String
Dim InstrCode As String
Dim BookYn As String
Dim serno As String
Dim LfPerBk As Long
Dim PreNoOfBk As Long
Dim AftNoOfBk As Long
Dim BkLfStno As Long
Dim BkLfEndNo As Long
Dim ChqSno As Variant
Dim AppDate As String
Dim UsrId As String
Dim MachId As String
Dim PreChqSno As Variant
Dim StrInsUpTabName As String
Dim StrUpTabName As String
Dim StrInsUpFldValues As Variant
Dim StrInsUpFldNames As String
Dim StrInsert As String
Dim modulecode As String
Dim StrInsUpCondition As String
Dim StrInsFldValues() As Variant
Dim StrInsFldNames As String
Dim Insbookstartno As Long
Dim Insbookendno As Long
Dim BookStNo As Long
Dim BookEndNo As Long
Dim PreCheQueStNo As Long
Dim PreChequeEndNo As Long
Dim AftCheQueStNo As Long
Dim AftChequeEndNo As Long
Dim StrStkUpdate As String
Dim StrStkUpFldNames As String
Dim StrStkUpFldValues As Variant
Dim StrStkUpCondition As String
Dim ccnt As Long
Dim RecIns As Recordset
Dim NoOfBk As Long
Dim jcnt As Long
Dim p As Long
Dim t As Long

BrCode = UCase(Trim(Branchcode))
IssueTo = UCase(Trim(IssuedTo))
modulecode = UCase(Trim(Moduleid))
InstrCode = UCase(Trim(InstCode))
BookYn = UCase(Trim(BookYesNo))
serno = UCase(Trim(Bookleafseriesno))
LfPerBk = Trim(LeavesperBook)
PreNoOfBk = Trim(PreNoofBooks)
AftNoOfBk = Trim(AftNoofBooks)
BkLfStno = Trim(BookLeafStartNo)
ChqSno = ChqStNo
PreChqSno = PreChqStNo
AppDate = Format(Applicationdate, "dd-mm-yyyy")
UsrId = UCase(Trim(UserId))
MachId = UCase(Trim(MachineId))
On Error GoTo ErrHnd

StrInsUpTabName = "GENDEPTCUSTINSTRSTOCKDTLS"
StrUpTabName = "GENINSTRUMENTSTOCKDTLS"

''''' updation in GENDEPTCUSTINSTRSTOCKDTLS if userid only modified remaining all are same

BookStNo = BkLfStno

If UCase(Trim(InstrCode)) = "DD" Then
    If Val(PreNoOfBk) <= Val(AftNoOfBk) Then
        Dim icnt As Long
        StrInsUpFldNames = "BRANCHCODE,ISSUEDTO," & _
                               "APPLICATIONDATE" & _
                               "USERID,MACHINEID,BOOKCHQSTNO,BOOKCHQENDNO "
        ReDim StrInsUpFldValues(Val(PreNoOfBk) - 1)
        For icnt = 0 To Val(PreNoOfBk) - 1
        '''' for where condition
            PreCheQueStNo = PreChqSno(icnt)
            PreChequeEndNo = Val(PreCheQueStNo) + Val(LfPerBk) - 1
        '' fro modified values
            AftCheQueStNo = ChqSno(icnt)
            AftChequeEndNo = Val(AftCheQueStNo) + Val(LfPerBk) - 1
            BookEndNo = Val(BookStNo) + Val(LfPerBk) - 1
            
            
            StrInsUpFldValues(icnt) = "'" & BrCode & "'~'" & IssueTo & "'~" & _
                                      "'" & AppDate & "'~'" & UsrId & "'~" & _
                                      "'" & MachId & "'~'" & AftCheQueStNo & "'~" & _
                                      "'" & AftChequeEndNo & "'"
            
            StrInsUpCondition = StrInsUpCondition & "Ucase(trim(BranchCode))='" & BrCode & "' and " & _
                                "upper(trim(moduleid))='" & modulecode & "' and " & _
                                "upper(trim(instrcode)='" & InstrCode & "' and " & _
                                "upper(trim(bookseriesno))='" & serno & "' and " & _
                                "bookstartno=" & BookStNo & " and " & _
                                "bookendno=" & BookEndNo & "  and " & _
                                "bookchqstno=" & PreCheQueStNo & " and " & _
                                "trim(leavesperbook)=" & LfPerBk & " and " & _
                                "bookchqendno=" & PreChequeEndNo & " and " & _
                                "Upper(trim(bookyesno))='Y'" & "|"
                              
            BookStNo = Val(BookEndNo) + 1
                 
        Next
        StrInsUpCondition = Left(StrInsUpCondition, Len(StrInsUpCondition) - 1)
  '''---------------------------------- complete updation in
  ''''' -------for insert of newly added rows
  
        
        ''For Insert
        Set RecIns = CreateObject("adodb.recordset")
        
        Set RecIns = ObjFetchRec.SingleRecordSet("GENDEPTCUSTINSTRSTOCKDTLS", "max(to_number(bookendno))", "BRANCHCODE='" & BrCode & "'" & _
                     "and INSTRCODE='" & InstrCode & "' and BOOKYESNO='Y' and LEAVESPERBOOK='" & LfPerBk & "'" & _
                     "and BOOKSERIESNO='" & serno & "'", "Bookseriesno,Bookstartno")
        
        If Not RecIns.EOF Then
           Insbookstartno = Val(RecIns(0)) + 1
        End If
             
        
        If Val(PreNoOfBk) < Val(AftNoOfBk) Then
        
        p = Val(AftNoOfBk) - Val(PreNoOfBk)
        t = Val(AftNoOfBk) - p
        
        StrInsFldNames = "BRANCHCODE,ISSUEDTO,MODULEID,INSTRCODE,BOOKYESNO," & _
                         "LEAVESPERBOOK,BOOKSERIESNO,BOOKSTARTNO,BOOKENDNO," & _
                         "STATUS,BOOKCHQSTNO,BOOKCHQENDNO,USERID,APPLICATIONDATE," & _
                         "MACHINEID"
                         ReDim StrInsFldValues(Val(p) - 1)
            For jcnt = 0 To p - 1
                Dim InsChqStNo As Long
                Dim InsChqEdNo As Long
                
                Insbookendno = Val(Insbookstartno) + Val(LfPerBk) - 1
                InsChqStNo = ChqSno(t - 1)
                
                InsChqEdNo = Val(InsChqStNo) + Val(LfPerBk) - 1
                               
                StrInsFldValues(jcnt) = "'" & BrCode & "','" & IssueTo & "'," & _
                                      "'" & modulecode & "','" & InstrCode & "'," & _
                                      "'Y','" & LfPerBk & "','" & serno & "'," & _
                                      "'" & Insbookstartno & "','" & Insbookendno & "'," & _
                                      "'ISSUABLE','" & InsChqStNo & "'," & _
                                      "'" & InsChqEdNo & "','" & UsrId & "'," & _
                                      "'" & AppDate & "','" & MachId & "'"
                t = t + 1
                Insbookstartno = Val(Insbookendno) + 1
            Next
        End If
    
    End If
    ''''Set ObjTrans = CreateObject("")
    Dim StrInsUpdate As String
     StrInsUpdate = ObjTrans.UpdateRecord(StrInsUpTabName, _
                    StrInsUpFldNames, StrInsUpFldValues, _
                    StrInsUpCondition)
                    
If StrInsUpdate <> "Trans Completed" Then
DeptModifyTran = "Record is not update in " & StrInsUpTabName
Exit Function
End If

StrInsert = ObjTrans.InsertRecord(StrInsUpTabName, StrInsFldNames, StrInsFldValues)
If StrInsert <> "Trans Completed" Then
    DeptModifyTran = "Record is not insert  in " & StrInsUpTabName
    Exit Function
End If

'''''--------------------------complete insertion new records
''''------------------updation of stock


ReDim StrStkUpFldValues(Val(p))

If Val(PreNoOfBk) <> Val(AftNoOfBk) Then
Set RecIns = CreateObject("adodb.recordset")
Set RecIns = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", "NOOFBOOKS,nvl(NOBOOKISSUED,0),BOOKSTARTNO,BOOKENDNO", _
                                    "bookyesno='Y' and bookseriesno='" & serno & "' and " & _
                                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                    "trim(leavesperbook)=" & LfPerBk & " and " & _
                                    "status<>'ISSUED'", "bookseriesno,bookstartno")
         
         ccnt = 0
       If Not RecIns.EOF Then
        Do Until RecIns.EOF
        
            If Val(RecIns(0)) - Val(RecIns(1)) >= Val(p) Then
               If Val(PreNoOfBk) < Val(AftNoOfBk) Then
                NoOfBk = Val(RecIns(1)) - Val(p)
               ElseIf Val(PreNoOfBk) > Val(AftNoOfBk) Then
                NoOfBk = Val(RecIns(1)) - Val(p)
               End If
               
            Else
                If Val(PreNoOfBk) < Val(AftNoOfBk) Then
                    NoOfBk = Val(RecIns(1)) - (Val(RecIns(0)) - Val(RecIns(1)))
                ElseIf Val(PreNoOfBk) > Val(AftNoOfBk) Then
                    NoOfBk = Val(RecIns(1)) - (Val(RecIns(0)) - Val(RecIns(1)))
                
            End If
            p = Val(p) - Val(NoOfBk)
                StrStkUpFldValues(ccnt) = "" & NoOfBk & ""
            End If
            StrStkUpCondition = StrStkUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                              " upper(trim(branchcode))='" & BrCode & "' and " & _
                              "upper(trim(instrcode))='" & InstrCode & "' and " & _
                              "upper(trim(bookseriesno))='" & serno & "' and " & _
                              "upper(trim(bookyesno))='Y' and " & _
                              "trim(leavesperbook)=" & LfPerBk & " and " & _
                              "trim(bookstartno))=" & RecIns(2) & " and " & _
                              "trim(bookendno))=" & RecIns(3) & "" & "|"
                              
            RecIns.MoveNext
            
            Loop
            StrStkUpCondition = Left(StrStkUpCondition, Len(StrStkUpCondition) - 1)
       End If
StrStkUpFldNames = "NOBOOKISSUED"
StrStkUpdate = ObjTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", _
                    StrStkUpFldNames, StrStkUpFldValues, StrStkUpCondition)
 


                    
End If
'''----------------------------complete stock updation

''''----------Delete Stock
Dim DelBkStno As Long
Dim DelEndNo As Long
DelBkStno = Val(BkLfStno) + Val(AftNoOfBk) * Val(LfPerBk)



  If Val(PreNoOfBk) > Val(AftNoOfBk) Then
    Dim StrDelete As String
    Dim StrDelCondition As String
    Dim kcnt As Long
    For kcnt = 0 To (Val(PreNoOfBk) - Val(AftNoOfBk)) - 1
    DelEndNo = Val(DelBkStno) * Val(LfPerBk) - 1
    StrDelCondition = StrDelCondition & "branchcode='" & BrCode & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookseriesno))='" & serno & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "BOOKstartno=" & DelBkStno & " and " & _
                    "trim(leavesperbook)=" & LfPerBk & " and " & _
                    "bookendno=" & DelEndNo & "" & "|"
                    
    
    DelBkStno = Val(DelEndNo) + 1
    Next
End If
    StrDelete = ObjTrans.DeleteRecord(StrInsUpTabName, StrDelCondition)
    If StrDelete <> "Trans Completed" Then
    DeptModifyTran = "Record not deleted in " & StrInsUpTabName
    Exit Function
    End If
    '''''----------------------
 ''''' updation previousseries in dept table
    Dim StrSerUpdate As String
    Dim StrSerUpFldNames As String
    Dim StrSerUpFldValues As Variant
    Dim StrSerUpCondition As String
    Dim RecDept As Recordset
    Dim UpStNo As Long
    Dim UpEndNo As Long
    Dim cnt As Long
    cnt = 0
    UpStNo = Val(BkLfStno) + Val(AftNoOfBk) * Val(LfPerBk)
    Dim ConStNo As Long
    ConStNo = Val(BkLfEndNo) + Val(AftNoOfBk) * Val(LfPerBk)
    Set RecDept = CreateObject("adodb.recordset")
    Set RecDept = ObjFetchRec.SingleRecordSet(StrInsUpTabName, _
                "noofbook,leavesperbook,bookstartno,bookendno", _
                "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(instrcode))='" & InstrCode & "' and " & _
                "upper(trim(bookseriesno))='" & serno & "' and " & _
                "upper(trim(bookyesno))='Y' and " & _
                "trim(leavesperbook)=" & LfPerBk & " and " & _
                "trim(bookendno)>" & ConStNo & "", "bookseriesno,bookstartno")
                If Not RecDept.EOF Then
                ReDim StrSerUpFldValues(RecDept.RecordCount - 1)
                Do Until RecDept.EOF
                UpEndNo = Val(UpStNo) + Val(RecDept(0)) * Val(RecDept(1)) - 1
                    StrSerUpFldValues(cnt) = "" & UpStNo & "~" & UpEndNo & ""
                    UpStNo = Val(UpEndNo) + 1
                    cnt = cnt + 1
                    
                   
                 StrSerUpCondition = StrSerUpCondition & "branchcode='" & BrCode & "' and" & _
                                "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                "upper(trim(bookseriesno))='" & serno & "' and " & _
                                "upper(trim(bookywesno))='Y' and " & _
                                "trim(leavesperbook)=" & LfPerBk & " and " & _
                                "trim(bookstartno)=" & RecDept(2) & " and " & _
                                "trim(bookendno)=" & RecDept(3) & "" & "|"
                                
                RecDept.MoveNext
                Loop
                StrSerUpCondition = Left(StrSerUpCondition, Len(StrSerUpCondition) - 1)
                StrSerUpdate = ObjTrans.UpdateRecord(StrInsUpTabName, StrSerUpFldNames, _
                                    StrSerUpFldValues, StrSerUpCondition)
                 If StrSerUpdate <> "Trans Completed" Then
                 DeptModifyTran = "Record not updated in " & StrInsUpTabName
                 Exit Function
                 End If
                
                
                End If

  End If
    
    
    
'''''----------------------
Exit Function
ErrHnd:
DeptModifyTran = Err.Number & Err.Description
End Function


Private Sub Command1_Click()
        Dim str As String
        Dim Stno(5) As Variant
        Dim PreStno(5) As Variant
        Dim EdNo As Variant
        
        Stno(0) = "1234"
        Stno(1) = "4567"
        Stno(2) = "8910"
        Stno(3) = "9101"
        Stno(4) = "101112"
        Stno(5) = "111213"
        
        PreStno(0) = "46436"
        PreStno(1) = "788787"
        PreStno(2) = "9998"
        PreStno(3) = "9876"
        
        str = DeptModifyTran("0001", "ANUPAMA", "REM", "DD", "Y", "DABC", "20", "4", "6", "61", Stno, PreStno, "12-jan-00", "nynika", "C099")
End Sub
