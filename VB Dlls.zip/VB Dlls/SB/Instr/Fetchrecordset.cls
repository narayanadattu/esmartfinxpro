VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "Fetchrecordset"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim AdoRs() As ADODB.Recordset   '    Multiple Recordset Objects
Dim Rstemp As ADODB.Recordset
Dim ICount As Integer
Public Function RecordsetCollection(ArrRecRS As Variant) As Variant
Dim TempArr As Variant
Dim StrQuery As String
'************Oppening the connection to dblink*************
On Error GoTo errhand
ConnError = ""
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=com;Password=v3user;User ID=v3user"
If AdoConnObj.State = 1 Then ConnError = "Connected"
  '*************Connection oppened Sucessfully*************
   
  '***Fetching the multiple Recordsets.*******
  TempArr = ArrRecRS
  
  
  ReDim AdoRs(UBound(TempArr)) As ADODB.Recordset
       For ICount = 0 To UBound(TempArr)
          StrQuery = ""
          Set AdoRs(ICount) = CreateObject("adodb.recordset")
          StrQuery = "Select " & TempArr(ICount, 1) & " from  " & TempArr(ICount, 0) _
                   & "@lnNew " & " where " & TempArr(ICount, 2)
          AdoRs(ICount).Open StrQuery, AdoConnObj, adOpenDynamic, adLockOptimistic
          
       Next ICount
       
       RecordsetCollection = AdoRs
        Exit Function


errhand:
If ConnError = "" Then
'*************Connection Failed************
ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else
ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
End If

Exit Function


End Function



'************    Function to return a Single Recordset.   *************************

Public Function SingleRecordSet(TabName As String, FldNames As String, Optional WhereCondition As String, _
                                 Optional OrderClause As String) As ADODB.Recordset

Dim StrQuery As String
'************Oppening the connection to dblink*************
On Error GoTo errhand

Set AdoConnObj = CreateObject("Adodb.Connection")
'Set Rstemp = CreateObject("adodb.recordset")
ConnError = ""
AdoConnObj.CursorLocation = adUseClient
'AdoConnObj.Open "Provider=MSDAORA.1;data source=com;Password=v3user;User ID=v3user"
AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=v3;User ID=v3"
If AdoConnObj.State = 1 Then ConnError = "Connected"
  '*************Connection oppened Sucessfully*************

  '*************Forming the sql select query*************
          Set Rstemp = CreateObject("adodb.recordset")
          StrQuery = ""
          If Trim(WhereCondition) <> "" And Trim(OrderClause) <> "" Then
            
            StrQuery = "Select " & FldNames & " from  " & TabName _
                & " where " & WhereCondition & " order by " & OrderClause
                 ''    & "@lnNew where " & WhereCondition & " order by " & OrderClause
                     
          ElseIf Trim(OrderClause) <> "" And Trim(WhereCondition) = "" Then
            StrQuery = "Select " & FldNames & " from  " & TabName _
                      & " order by " & OrderClause
                      
          ElseIf Trim(WhereCondition) <> "" And Trim(OrderClause) = "" Then
            StrQuery = "Select " & FldNames & " from  " & TabName _
                      & " where " & WhereCondition
           
                      
          ElseIf Trim(WhereCondition) = "" And Trim(OrderClause) = "" Then
            StrQuery = "Select " & FldNames & " from  " & TabName _
                      & "@lnNew "
          End If
          
  '*************Opening the Recordset.*************
  
          Rstemp.Open StrQuery, AdoConnObj, adOpenDynamic, adLockOptimistic
          ''MsgBox Rstemp(0)
          '**********Closing the connection ****************
          
          Set AdoConnObj = Nothing
          
        If Rstemp.State = 1 Then Set SingleRecordSet = Rstemp
            
        '*************Returned a Recordset to the Client Application*************
        
        Exit Function
        
errhand:
If ConnError = "" Then
'*************Connection Failed************
    ConnError = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else

'*************RecordSet Not oppened************
    ConnError = "Records Could Not Be Retrieved Due to : " & Err.Number & " : " & Err.Description
    MsgBox ConnError
End If

Exit Function


End Function





