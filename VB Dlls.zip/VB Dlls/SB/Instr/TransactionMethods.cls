VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "TransactionMethods"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim ICount As Integer

Public Function InsertRecord(TableName As String, FldNames As String, ArrValues As Variant) As String
Dim ArrTempValues As Variant
Dim StrInsert As String, StrTabName As String, StrFields As String, StrArrValues As String
Dim BrCode As String, MachineID As String, UserId As String
'************Oppening the connection to dblink*************
On Error GoTo errhand
ConnError = ""
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=asp;Password=v3;User ID=v3"
If AdoConnObj.State = 1 Then ConnError = "Connected"
  '*************Connection oppened Sucessfully*************
ArrTempValues = ArrValues

StrTabName = Trim(TableName): StrFields = FldNames

For ICount = 0 To UBound(ArrTempValues)
'MsgBox StrFields
'MsgBox ArrTempValues(Icount)
  'StrInsert = "insert into " & Trim(StrTabName) & "@lnnew (" & StrFields & ") "
   StrInsert = "insert into " & Trim(StrTabName) & " (" & StrFields & ") " _
                & " values (" & ArrTempValues(ICount) & ")"
   AdoConnObj.Execute StrInsert
   StrInsert = ""
Next ICount
Set AdoConnObj = Nothing
InsertRecord = "Trans Completed"
Exit Function


errhand:
If ConnError = "" Then
'*************Connection Failed************
InsertRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else
Dim arrerr As Variant, errobj As Object
'Set errobj = CreateObject("TrapError.ErrorDescription")
'arrerr = errobj.ErrorProcess(Err.Number, Err.Description, "Error Occured During Inserting Records", _
'            "DataBaseTransactions", BRCode, UserId, MachineID)
InsertRecord = "Records Could Not Be Inserted Due to : " & Err.Number & " : " & Err.Description
End If
MsgBox InsertRecord
End Function
Public Function UpdateRecord(TableName As String, FldNames As String, _
                ArrValues As Variant, WhereCondition As String) As String

Dim Rstemp As ADODB.Recordset
Dim ArrTempValues As Variant, ArrRowValue As Variant, ArrFlds As Variant, StrQuery As String
Dim StrUpdate As String, StrInsert As String, ColCnt As Integer, RowCnt As Integer
Dim strUpdateRow As String, strcondition As Variant, StrTabName As String, StrFields As String
'************Oppening the connection to dblink*************
On Error GoTo errhand
ConnError = ""
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=asp;Password=V3;User ID=V3"
If AdoConnObj.State = 1 Then ConnError = "Connected"

  '*************Connection oppened Sucessfully*************
Set Rstemp = CreateObject("Adodb.Recordset")
ArrTempValues = ArrValues
StrTabName = Trim(TableName)
StrFields = FldNames

strcondition = Split(WhereCondition, "|", -1)

For RowCnt = 0 To UBound(ArrTempValues)
If Trim(strcondition(RowCnt)) <> "" Then

    If Right(Trim(StrTabName), 3) = "MST" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST select * from " _
        & StrTabName & " Where " & strcondition(RowCnt)
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "DEM select * from " _
        & StrTabName & " Where " & strcondition(RowCnt)
    Else
        StrInsert = ""
    End If
    
   ' StrQuery = "select " & StrFields & " from " & Trim(StrTabName) & "@lnnew where "
   ' StrQuery = "select " & StrFields & " from " & Trim(StrTabName) & "@lnnew" & " where " _
   ' & strcondition(RowCnt) & " for update"
   StrQuery = "select " & StrFields & " from " & Trim(StrTabName) & " where " _
   & strcondition(RowCnt)
    
    
Else
    
    If Right(Trim(StrTabName), 3) = "MST" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST select * from " _
        & StrTabName
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
         StrInsert = "Insert into " & Trim(StrTabName) & "DEM@lnnew select * from " _
        & StrTabName & "@lnnew"
    Else
        StrInsert = ""
    End If
    
    'StrQuery = "select " & StrFields & " from " & Trim(StrTabName) & "@lnnew for update"
    'StrQuery = "select " & StrFields & " from " & Trim(StrTabName) & "@lnnew" & " for update"
    StrQuery = "select " & StrFields & " from " & Trim(StrTabName)
    
   
    
End If

If Trim(StrInsert) <> "" Then AdoConnObj.Execute StrInsert

AdoConnObj.Execute StrQuery

ArrFlds = Split(StrFields, ",", -1)
    
ArrRowValue = Split(ArrTempValues(RowCnt), "~", -1)
        
    For ColCnt = 0 To UBound(ArrFlds)
        
 
       strUpdateRow = strUpdateRow & ArrFlds(ColCnt) & "=" & ArrRowValue(ColCnt) & ","
    
    Next ColCnt
    'MsgBox strUpdateRow
    If strcondition(RowCnt) <> "" Then
      
      ' Strupdate = "update " & StrTabName & "@lnnew set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1)
       StrUpdate = "update " & StrTabName & " set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1) _
                    & " where " & strcondition(RowCnt)
       
    Else
    
        'Strupdate = "update " & StrTabName & "@lnnew set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1)
        StrUpdate = "update " & StrTabName & " set " & Mid(strUpdateRow, 1, Len(strUpdateRow) - 1)
    
    End If
    
         AdoConnObj.Execute StrUpdate
         StrUpdate = ""
         strUpdateRow = ""
Next RowCnt

Set AdoConnObj = Nothing
UpdateRecord = "Trans Completed"
Exit Function

errhand:
If ConnError = "" Then


'*************Connection Failed************
UpdateRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else
UpdateRecord = "Records Could Not Be Updated Due to : " & Err.Number & " : " & Err.Description
MsgBox UpdateRecord
End If
End Function
Public Function DeleteRecord(TableName As String, WhereCondition As String) As String
Dim StrDelete As String, StrTabName As String
Dim strcondition As Variant, StrInsert As String
'************Oppening the connection to dblink*************
On Error GoTo errhand
ConnError = ""
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=asp;Password=v3;User ID=v3"
If AdoConnObj.State = 1 Then ConnError = "Connected"
  '*************Connection oppened Sucessfully*************
 StrDelete = ""
 StrTabName = ""
 strcondition = ""
 
 StrTabName = Trim(TableName)
 strcondition = Split(WhereCondition, "|", -1)
  
  For ICount = 0 To UBound(strcondition)
 StrInsert = ""
 If Trim(strcondition(ICount)) <> "" Then
    If Right(Trim(StrTabName), 3) = "MST" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST select * from " _
        & Trim(StrTabName) & "Where " & strcondition(ICount)
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "DEM@lnnew select * from " _
        & Trim(StrTabName) & "@lnnew Where " & strcondition(ICount)
    End If
        
        StrDelete = "Delete from  " & Trim(StrTabName) & " where " & strcondition(ICount)
     
    
 Else
    If Right(Trim(StrTabName), 3) = "MST" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "HIST@lnnew select * from " _
        & Trim(StrTabName)
    ElseIf Right(Trim(StrTabName), 3) = "LOG" Then
        StrInsert = "Insert into " & Trim(StrTabName) & "DEM@lnnew select * from " _
        & Trim(StrTabName) & "@lnnew"
    End If
    
    StrDelete = "Delete from  " & Trim(StrTabName)
     

End If

If StrInsert <> "" Then AdoConnObj.Execute StrInsert
AdoConnObj.Execute StrDelete
Next ICount
Set AdoConnObj = Nothing
DeleteRecord = "Trans Completed"
Exit Function
  
  
  
errhand:
If ConnError = "" Then
'*************Connection Failed************
DeleteRecord = "Connection Failed Due to : " & Err.Number & " : " & Err.Description
Else
DeleteRecord = "Records Could Not Be Deleted Due to : " & Err.Number & " : " & Err.Description
End If

End Function



