VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   585
      Left            =   120
      TabIndex        =   0
      Top             =   630
      Width           =   2505
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Obj As Object


Private Sub Command1_Click()
Set ObjCUST = CreateObject("GenCustChqInsert.CustChqInsert")
Dim strmsg As String
'strmsg = ObjCust.CustInstrInsert(CStr(curcode), CStr(brcode),
'CStr(modcode), CStr(glcode), CStr(accno),
'CStr(customercode), CStr(inscode), CStr(session("Applicationdate")),
'"B", CStr(serno), CStr(startno), CStr(EndNo), CStr(nlpb), CStr(nobooks),
'Stno, Edno)
Dim stno(2)
Dim edno(2)
stno(0) = 221
stno(1) = 241
stno(2) = 261
edno(0) = 221
edno(1) = 241
edno(2) = 261
strmsg = ObjCUST.CustInstrInsert("INR", "0001", "SB", "SB0001", "2", "000160100000003", "CHQ", "01-04-2001", "B", "ABC", "221", "280", "20", "3", stno, edno)
MsgBox strmsg
End Sub
