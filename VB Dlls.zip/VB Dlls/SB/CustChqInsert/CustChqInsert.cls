VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "CustChqInsert"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim ObjTrans As Object
Dim ObjFetchRec As Object
Dim RecCust As Recordset
Public Function CustInstrInsert(CurrencyCode As String, BranchCode As String, _
         Moduleid As String, GlCode As String, Accno As String, CustCode As String, InstrCode As String, _
         AppDate As String, BookYesNo As String, SeriesNo As String, StartNo As String, _
         EndNo As String, LeafperBook As String, NoOfBl As String, ChqSno As Variant, _
         ChqEno As Variant, UserId As String, MachineId As String) As String
         
Dim TableNm As String
Dim CurCode As String
Dim BrCode As String
Dim InstCode As String
Dim CustId As String
Dim AppDt As String
Dim Modulecode As String
Dim GlId As String
Dim AccntNo As String
Dim BookYN As String
Dim SerNo As String
Dim Stno As String
Dim Eno As String
Dim UStno As String
Dim UEdNo As String
Dim LeafperBk As String
Dim UsrId As String
Dim MachId As String
UsrId = UCase(Trim(UserId))
MachId = UCase(Trim(MachineId))
Dim NoBl As String
Dim ObjStatus As String
Dim ChqStNo
Dim ChqEdNo
Dim chqno As String
Dim UpStatus As String
Dim StrQrytab As String
Dim StrQryFlds As String
Dim StrQryCondition As String
Dim StrQryOrder As String
Dim StrInsTabName As String
Dim StrInsFldNames As String
Dim StrInsValues() As Variant
Dim UpStrTabName As String
Dim StrUpFlds As String
Dim StrUpValues() As Variant
Dim StrUpCondition As String
Dim StrInstrCondition As String
Dim DeptUpStrTabName As String
Dim DeptStrUpFlds As String
Dim DeptStrUpValues() As Variant
Dim DeptStrUpCondition As String

Dim TransResult As String
TransResult = ""
Dim Icount As Integer
Dim InsStatus As String
Dim t As Long
Dim u As Long
Dim n As Long
Dim j As Integer
Dim BkNo As Long
Dim FreeBooks As Long
On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********
CurCode = UCase(Trim(CurrencyCode))
BrCode = UCase(Trim(BranchCode))
CustId = UCase(Trim(CustCode))
InstCode = UCase(Trim(InstrCode))
AppDt = Format(AppDate, "dd/mm/yyyy")
Modulecode = UCase(Trim(Moduleid))
GlId = UCase(Trim(GlCode))
AccntNo = UCase(Trim(Accno))
BookYN = UCase(Trim(BookYesNo))
SerNo = UCase(Trim(SeriesNo))
Stno = UCase(Trim(StartNo))
Eno = UCase(Trim(EndNo))
LeafperBk = Trim(LeafperBook)
NoBl = Trim(NoOfBl)
InsStatus = "P"
 UStno = UCase(Trim(StartNo))
 UEdNo = UCase(Trim(EndNo))


'''------------------------inserting into genchequedtls table--------------------------

 ChqStNo = ChqSno
 ChqEdNo = ChqEno

StrInsTabName = "genchequedtls"
StrInsFldNames = "Currencycode,BranchCode,Moduleid,GlCode,Accno,Status,CHEQUENO," & _
                    "BOOKLEAF,userid,machineid,ApplicationDate"
 If BookYN = "B" Then

chqno = ChqSno(0)
t = 0
n = Val(NoBl) * Val(LeafperBk)
ReDim StrInsValues(n - 1)
For u = 0 To NoBl - 1
chqno = ChqStNo(LBound(ChqStNo) + Val(u))
    For j = 0 To Val(LeafperBk) - 1
        StrInsValues(t) = "'" & CurCode & "','" & BrCode & "','" & Modulecode & "'," & _
        "'" & GlId & "','" & Accno & "','" & InsStatus & "'," & _
        "'" & chqno & "','" & BookYN & "', " & _
        "'" & UsrId & "','" & MachId & "',to_date('" & AppDate & "','dd-mm-yyyy')"
        chqno = chqno + 1
        t = t + 1
    Next
Next

ElseIf BookYN = "L" Then
n = Val(NoBl)
chqno = ChqSno(0)

ReDim StrInsValues(n - 1)
For u = 0 To NoBl - 1
    chqno = ChqStNo(LBound(ChqStNo) + Val(u))
    StrInsValues(u) = "'" & CurCode & "','" & BrCode & "','" & Modulecode & "'," & _
    "'" & GlId & "','" & Accno & "','" & InsStatus & "'," & _
    "'" & chqno & "','" & BookYN & "'," & _
        "'" & UsrId & "','" & MachId & "',to_date('" & AppDate & "','dd-mm-yyyy')"
Next
End If



''----------------------------------------------------------------------------------------

''------------Update in GENDEPTCUSTINSTRSTOCKDTLS table-----------------------------------
Dim k As Integer
UpStatus = "P"
UpStrTabName = "GENDEPTCUSTINSTRSTOCKDTLS"
StrUpFlds = "BOOKCHQSTNO,BOOKCHQENDNO,status,accno,glcode,CUSTOMERID,userid,machineid"
ReDim StrUpValues(NoBl - 1)

'''------------------For Books
If BookYN = "B" Then
 For k = 0 To Val(NoBl) - 1
    ChqEdNo(k) = Val(ChqStNo(k)) + Val(LeafperBook) - 1
    StrUpValues(k) = "'" & ChqStNo(k) & "'~'" & ChqEdNo(k) & "'~'" & UpStatus & "'~" & _
    "'" & AccntNo & "'~'" & GlId & "'~'" & CustId & "'~'" & InstCode & "'~" & _
    "'" & UsrId & "'~'" & MachId & "'"
    Eno = Val(Stno) + Val(LeafperBook) - 1
    StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & Modulecode & "'  and upper(trim(bookyesno))='Y' and " & _
                "bookstartno='" & ChqStNo(k) & "' and BookEndNo ='" & ChqEdNo(k) & "' and " & _
                "UPPER(TRIM(INSTRCODE))='" & InstCode & "'" & "|"
   'Stno = Val(Eno) + 1
 Next
''''----------------------For Leaves
ElseIf BookYN = "L" Then
 For k = 0 To Val(NoBl) - 1
     StrUpValues(k) = "'" & ChqStNo(k) & "'~'" & ChqEdNo(k) & "'~'" & UpStatus & "'~" & _
     "'" & AccntNo & "'~'" & GlId & "'~'" & CustId & "'~'" & InstCode & "'~" & _
     "'" & UsrId & "'~'" & MachId & "'"
     StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & Modulecode & "' and upper(trim(leafyesno))='Y' and " & _
                "leafnumber='" & ChqStNo(k) & "'AND UPPER(TRIM(INSTRCODE))='" & InstCode & "'" & "|"
     'Stno = Val(Stno) + 1
 Next
  
End If
 StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
'''----------------------------------------------------------------------

''--------------Querying for date in genbankparm table


Set objContext = GetObjectContext
    Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
ObjStatus = "YES"

If BookYN = "B" Then
    StrInstrCondition = ""
         For kcnt = 0 To Val(NoBl) - 1
            StrInstrCondition = StrInstrCondition & "bookstartno=" & ChqStNo(kcnt) & " or "
         Next
         StrInstrCondition = Left(StrInstrCondition, Len(StrInstrCondition) - 3)
    StrQrytab = "GENDEPTCUSTINSTRSTOCKDTLS a,genbankparm p"
    StrQryFlds = " count(*)"
    StrQryCondition = "(" & StrInstrCondition & ")" & "  and " & _
    "a.applicationdate > p.yearstartdt and " & _
    "upper(trim(branchcode))='" & BrCode & "' and " & _
    "upper(trim(moduleid))='" & Modulecode & "' AND " & _
    "UPPER(TRIM(INSTRCODE))='" & InstCode & "'"
    
   

    Set RecCust = CreateObject("ADODB.Recordset")
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
 
    Set RecCust = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                        StrQryCondition, StrQryOrder)
  If RecCust.RecordCount > 0 Then
    BkNo = RecCust(0)
  Else
  CustInstrInsert = "No Data Found In GENDEPTCUSTINSTRSTOCKDTLS For Querying"
Exit Function
  End If
 Set RecCust = Nothing
 StrQrytab = ""
 StrQryFlds = ""
 StrQryCondition = ""
 StrQrytab = "GENCHARGESMST"
 StrQryFlds = "CHQISSUECHARGESEXEMPT,CHQISSUECHARGES"
 ''''"upper(trim(branchcode))='" & BrCode & "' and "
 StrQryCondition = "upper(trim(moduleid))='" & Modulecode & "' and " & _
                    "upper(trim(glcode))='" & GlId & "' and " & _
                    "upper(trim(CHQISSUEFREQ))='SPOT'"
 Dim bkcharges As String
 Dim m As Long
 
 '-----using querycomponent for querying  charges for chequebook in GenChargespmt table
 
 Set RecCust = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                        StrQryCondition, StrQryOrder)
   If Not RecCust.EOF And Not RecCust.BOF Then
        FreeBooks = RecCust(0)
        bkcharges = RecCust(1)
    
   
 Set RecCust = Nothing
 Set ObjFetchRec = Nothing
 
  '''************calling the general insert update component for updating and inserting
  
    
DeptUpStrTabName = "GENDEPTCUSTINSTRSTOCKDTLS"
DeptStrUpFlds = "CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE,userid,machineid"

If Val(BkNo) > Val(FreeBooks) Then
    ReDim DeptStrUpValues(BkNo - 1)
    For m = 0 To FreeBooks - 1
        DeptStrUpValues(m) = "'F'~''~to_date('" & AppDt & "','dd-mm-yyyy')~" & _
        "'" & UsrId & "'~'" & MachId & "'"
        ChqEdNo(m) = Val(ChqStNo(m)) + Val(LeafperBook) - 1
        'UEdNo = Val(UStno) + Val(LeafperBook) - 1
        DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & Modulecode & "' and " & _
                "upper(trim(bookyesno))='Y' and " & _
                "bookstartno='" & ChqStNo(m) & "' and BookEndNo ='" & ChqEdNo(m) & "'|"
        'UStno = Val(UEdNo) + 1
    Next
    For m = Val(FreeBooks) To Val(BkNo) - 1
        DeptStrUpValues(m) = "'Y'~'" & bkcharges & "'~to_date('" & AppDt & "','dd-mm-yyyy')~" & _
        "'" & UsrId & "'~'" & MachId & "'"
        'UEdNo = Val(UStno) + Val(LeafperBook) - 1
        ChqEdNo(m) = Val(ChqStNo(m)) + Val(LeafperBook) - 1
        DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & Modulecode & "' and " & _
                "upper(trim(bookyesno))='Y' and " & _
                "bookstartno='" & ChqStNo(m) & "' and BookEndNo ='" & ChqEdNo(m) & "'|"
        'UStno = Val(UEdNo) + 1
    Next
    
ElseIf Val(BkNo) <= Val(FreeBooks) Then
    ReDim DeptStrUpValues(BkNo - 1)
    For m = 0 To Val(BkNo) - 1
        DeptStrUpValues(m) = "'F'~''~TO_DATE('" & AppDt & "','dd-mm-yyyy')~" & _
        "'" & UsrId & "'~'" & MachId & "'"
        ChqEdNo(m) = Val(ChqStNo(m)) + Val(LeafperBook) - 1
        'UEdNo = Val(UStno) + Val(LeafperBook) - 1
        DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & Modulecode & "' and " & _
                 "bookyesno='Y' and " & _
                "bookstartno='" & ChqStNo(m) & "' and BookEndNo ='" & ChqEdNo(m) & "'|"
        'UStno = Val(UEdNo) + 1
    Next
    
End If
DeptStrUpCondition = Left(DeptStrUpCondition, Len(DeptStrUpCondition) - 1)
''''-------------------------calling update method from General transactions component

TransResult = ObjTrans.UpdateRecord(DeptUpStrTabName, DeptStrUpFlds, DeptStrUpValues, DeptStrUpCondition)

   End If
End If
'''----------------------------------
   
    
    '''' ''''********Transaction Started***************
    If TransResult = "Trans Completed" Or TransResult = "" Then
    TransResult = ObjTrans.InsertRecord(StrInsTabName, StrInsFldNames, _
    StrInsValues, CStr(BrCode), CStr(UsrId), CStr(MachId), CStr(AppDt))
    End If
    If TransResult = "Trans Completed" Then
    TransResult = ObjTrans.UpdateRecord(UpStrTabName, StrUpFlds, StrUpValues, StrUpCondition)
    End If
      
 If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
  
    objContext.SetComplete
Set ObjTrans = Nothing
    CustInstrInsert = "Transaction Successful."
   
 Exit Function
ErrHand:
If ObjStatus = "YES" Then
objContext.SetAbort
Set objContext = Nothing
End If
Set ObjTrans = Nothing

If Trim(TransResult) <> "" Then
'''*************Connection Failed************
    CustInstrInsert = TransResult
    CustInstrInsert = Replace(CustInstrInsert, Chr(10), "")
    CustInstrInsert = Replace(CustInstrInsert, Chr(13), "")
 Else
    CustInstrInsert = Err.Number & " : " & Err.Description
    CustInstrInsert = Replace(CustInstrInsert, Chr(10), "")
    CustInstrInsert = Replace(CustInstrInsert, Chr(13), "")
 End If

End Function



