VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "SBQueries"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
    Dim objtrans As Object
    Dim ObjFetchRec As Object
Public Function chequebookissuequerybook(branchcode As String, _
    instrumentcode As String, series As String, _
    leavesperbook As String _
    ) As Variant
    
    Dim strbrcode As String
    Dim strinstcode As String
    Dim strseries As String
    Dim intleavesperbook As Double
    Dim intnoofbooks As Double
    Dim strcondition As String
    Dim strcondition1 As String
    Dim intcount As Integer
    Dim strresult As String
    Dim rsgenstockmst As Recordset
    Dim rscuststockdtls As Recordset
    Dim temp1() As Variant
    Dim arrvalues() As Variant
    strbrcode = UCase(Trim(branchcode))
    strinstcode = UCase(Trim(instrumentcode))
    strseries = UCase(Trim(series))
    intleavesperbook = Val(Trim(leavesperbook))

    Dim count As Integer
      
    On Error GoTo errhand

    strcondition = "branchcode='" & strbrcode & "' and instrcode='" & strinstcode _
    & "' and bookseriesno='" & strseries & "' and leavesperbook='" & intleavesperbook _
    & "' and Bookyesno='Y'" & " and status<>'ISSUED'"

    strcondition1 = "branchcode='" & strbrcode & "' and instrcode='" & strinstcode _
    & "' and bookseriesno='" & strseries & "' and leavesperbook='" & intleavesperbook & "'"

    Set rsgenstockmst = CreateObject("adodb.recordset")
    Set rscuststockdtls = CreateObject("adodb.recordset")
    
    '/*---checking that the series exist or not in the geninstrumentsstockdtls---*/
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsgenstockmst = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", "bookendno,Bookstartno", strcondition, "to_number(bookstartno),to_number(bookendno)")
    Set ObjFetchRec = Nothing
    
    If rsgenstockmst.BOF And rsgenstockmst.EOF Then
        ReDim arrvalues(0, 0) As Variant
        arrvalues(0, 0) = "Series Does Not Exist"
        chequebookissuequerybook = arrvalues
        Exit Function
    End If

    intnoofbooks = 0
    
    Do While Not rsgenstockmst.EOF
        intnoofbooks = intnoofbooks + (Val(rsgenstockmst!bookendno) - Val(rsgenstockmst!Bookstartno) + 1) / intleavesperbook
        rsgenstockmst.MoveNext
    Loop
    
    '/*---creating the series with bookstartno,bookendnumber,leavesperbook and _
    adding it to array----*/
    ReDim arrres(intnoofbooks, 2)
         
    Dim intstartno As Double
    Dim intcount1 As Double
    rsgenstockmst.MoveFirst
    Do While Not rsgenstockmst.EOF
        intstartno = Val(rsgenstockmst!Bookstartno)
        For intcount = 0 To (((Val(rsgenstockmst!bookendno) - Val(rsgenstockmst!Bookstartno) + 1) / intleavesperbook) - 1)
            arrres(intcount1, 0) = intstartno
            arrres(intcount1, 1) = intstartno + intleavesperbook - 1
            intstartno = arrres(intcount1, 1) + 1
            intcount1 = intcount1 + 1
        Next
        rsgenstockmst.MoveNext
    Loop
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rscuststockdtls = ObjFetchRec.SingleRecordSet("gendeptcustinstrstockdtls", "Bookstartno,bookendno", strcondition1)
    Set ObjFetchRec = Nothing
    
    
    '/*---checking that the series has been issued or not---*/
    
    If Not rscuststockdtls.BOF And Not rscuststockdtls.EOF Then
        Do While Not rscuststockdtls.EOF
            For intcount = 0 To (intnoofbooks - 1)
                If Val(rscuststockdtls!Bookstartno) = arrres(intcount, 0) And _
                    Val(rscuststockdtls!bookendno) = arrres(intcount, 1) Then
                    arrres(intcount, 2) = "I"
                    count = count + 1
                End If
            Next
            rscuststockdtls.MoveNext
        Loop
    Else
        
    End If
    
    '/*---series that has not been issued are added to the array---*/
    ReDim temp1((intnoofbooks - count), 1)
    count = 0
    
    For intcount = 0 To (UBound(arrres) - 1)
        If arrres(intcount, 2) <> "I" Then
            temp1(count, 0) = arrres(intcount, 0)
            temp1(count, 1) = arrres(intcount, 1)
            count = count + 1
        End If
    Next
    
    Dim intfr As Double
    Dim intto As Double
    strresult = ""
        
    ReDim arrvalues((UBound(temp1) - 1), 1)
    Dim counter As Integer
    
    For intcount = 0 To (UBound(temp1) - 1)
        
        If intcount = 0 Then
            intfr = temp1(0, 0)
        End If
            
        If temp1((intcount + 1), 0) - temp1(intcount, 1) > 1 Then
            intto = temp1(intcount, 1)
            arrvalues(counter, 0) = intfr
            arrvalues(counter, 1) = intto
            intfr = temp1((intcount + 1), 0)
            counter = counter + 1
        End If
            
         If intcount = (count - 1) Then
            intto = temp1((count - 1), 1)
            arrvalues(counter, 0) = intfr
            arrvalues(counter, 1) = intto
        End If
    Next
    
    chequebookissuequerybook = arrvalues
    Exit Function
            
errhand:
    ReDim arrvalues(0, 0) As Variant
    arrvalues(0, 0) = "error in data"
    chequebookissuequerybook = arrvalues
    Set ObjFetchRec = Nothing

End Function
Public Function chequebookissuequeryleaf(branchcode As String, _
    instrumentcode As String, series As String, noofleaes As String) As Variant

    Dim strbrcode As String
    Dim strinstcode As String
    Dim strseries As String
    Dim strnoofleaf As String
    Dim strcondition As String
    Dim strcondition1 As String
    Dim intcount As Integer
    Dim intstartno As Double
    Dim intendno As Double
    Dim intcount1 As Double
    Dim temp As Boolean
    Dim temp1() As Variant
    Dim arrresult() As Variant
    Dim counter As Integer
    
    Dim rsgenstockmst As Recordset
    Dim rscuststockdtls As Recordset
    
    strbrcode = UCase(Trim(branchcode))
    strinstcode = UCase(Trim(instrumentcode))
    strseries = UCase(Trim(series))
    strnoofleaf = Val(Trim(noofleaes))

    On Error GoTo errhand
    
    '/*---query condition for genistrumentsstockdtls----*
    strcondition = "branchcode='" & strbrcode & "' and instrcode='" & strinstcode _
    & "' and leafseriesno='" & strseries & "' and noofleaves='" & strnoofleaf _
    & "' and Leafyesno='Y'" & " and status<>'ISSUED'"

    '/*---query condition for gendeptcustinstrstockdtls----*
    strcondition1 = "branchcode='" & strbrcode & "' and instrcode='" & strinstcode _
    & "' and leafseriesno='" & strseries & "' and leafyesno='Y'"

    Set rsgenstockmst = CreateObject("adodb.recordset")
    Set rscuststockdtls = CreateObject("adodb.recordset")
    
    '/*---checking that the series exist or not in the geninstrumentsstockdtls---*/
    
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rsgenstockmst = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", "leafstartno,leafendno", strcondition, "to_number(leafstartno),to_number(leafendno)")
    Set ObjFetchRec = Nothing
    
    
    '/*---checking that the series exist or not in the geninstrumentsstockdtls---*/
    If rsgenstockmst.BOF And rsgenstockmst.EOF Then
        ReDim arrresult(0, 0) As Variant
        arrresult(0, 0) = "Series Does Not Exist"
        chequebookissuequeryleaf = arrresult
        Exit Function
    End If

    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rscuststockdtls = ObjFetchRec.SingleRecordSet("gendeptcustinstrstockdtls", "leafnumber", strcondition1)
    Set ObjFetchRec = Nothing
    
    rsgenstockmst.MoveFirst
    
    '/*--checking weather any instrument have been issued in the series or not--*/
    If rscuststockdtls.BOF And rscuststockdtls.EOF Then
        Do While Not rsgenstockmst.EOF
            counter = counter + 1
            rsgenstockmst.MoveNext
        Loop
        
        rsgenstockmst.MoveFirst
        ReDim arrresult((counter - 1), 1)
        
        For counter = 0 To counter - 1
            intstartno = rsgenstockmst!leafstartno
            intendno = rsgenstockmst!leafendno
            arrresult(counter, 0) = intstartno
            arrresult(counter, 1) = intendno
            rsgenstockmst.MoveNext
        Next
        chequebookissuequeryleaf = arrresult
        Exit Function
    End If
    
    
    '/*--finding the number of issuable instruments---*/
    rsgenstockmst.MoveFirst
    counter = 0
    Do While Not rsgenstockmst.EOF
        counter = counter + (rsgenstockmst!leafendno) - (rsgenstockmst!leafstartno) + 1
        rsgenstockmst.MoveNext
    Loop
    
    rscuststockdtls.MoveFirst
    
    Do While Not rscuststockdtls.EOF
        counter = counter - 1
        rscuststockdtls.MoveNext
    Loop
    '/*---end of finding the number of issuable instruments---*/
    
    '/*---checking the instruments in the series that are not issued and _
    adding it to the temp1 array---*/
    
    ReDim temp1(counter, 0)
    temp = False
    counter = 0
    rsgenstockmst.MoveFirst
    rscuststockdtls.MoveFirst
    Do While Not rsgenstockmst.EOF
        intstartno = Val(rsgenstockmst!leafstartno)
        intendno = Val(rsgenstockmst!leafendno)
        For intcount = intstartno To intendno
            Do While Not rscuststockdtls.EOF
                If intcount = Val(rscuststockdtls!leafnumber) Then
                    temp = True
                    Exit Do
                End If
                rscuststockdtls.MoveNext
            Loop
            rscuststockdtls.MoveFirst
            If temp = False Then
                temp1(counter, 0) = intcount
                counter = counter + 1
            Else
             temp = False
            End If
        Next
        rsgenstockmst.MoveNext
    Loop
    
    '/*---end of checking the instruments in the series that are not issued and _
    adding it to the temp1 array---*/
    
    Dim intfr As Double
    Dim intto As Double
    
    
    '/*---creating the series for the instruments that can be issued---/*
    
    counter = 0
    ReDim arrresult(UBound(temp1), 1)
    For intcount = 0 To (UBound(temp1)) - 1

        If intcount = 0 Then
            intfr = temp1(0, 0)
        End If

        If temp1((intcount + 1), 0) - temp1(intcount, 0) > 1 Then
            intto = temp1(intcount, 0)
            arrresult(counter, 0) = intfr
            arrresult(counter, 1) = intto
            intfr = temp1((intcount + 1), 0)
            counter = counter + 1
        End If

         If intcount = (UBound(temp1) - 1) Then
            intto = temp1((UBound(temp1) - 1), 0)
            arrresult(counter, 0) = intfr
            arrresult(counter, 1) = intto
        End If
     Next
    
    '/*---end of creating the series for the instruments that can be issued---/*
    chequebookissuequeryleaf = arrresult
    Exit Function
        
errhand:
    ReDim arrresult(0, 0) As Variant
    arrresult(0, 0) = "Series Does Not Exist"
    chequebookissuequeryleaf = arrresult
    Set ObjFetchRec = Nothing
    Exit Function
End Function


