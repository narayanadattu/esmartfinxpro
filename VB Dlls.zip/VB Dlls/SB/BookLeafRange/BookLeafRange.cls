VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "BookLeafRange"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim ObjFetchRec As Object
Dim RecSer As Recordset
Public Function BookRange(BranchCode As String, MODULEID As String, _
                        Seriesno As String, leavesperbook As String, _
                        InstrCode As String, st As String, Accountno As String) As Variant
Dim BrCode As String
Dim NoOfLeaves As Integer
Dim ModuleCode As String
Dim SerNo As String
Dim AccNo As String
Dim Num As String
Dim Arr() As Variant
Dim counter
On Error GoTo ErrHand
BrCode = BranchCode
ModuleCode = MODULEID
SerNo = Seriesno
AccNo = UCase(Trim(Accountno))
NoOfLeaves = leavesperbook
Set RecSer = CreateObject("Adodb.recordset")
RecSer.CursorLocation = adUseClient
Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
If st = "ADD" Then
Set RecSer = ObjFetchRec.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS", "BOOKSTARTNO,BOOKENDNO", _
            "upper(trim(branchcode))='" & UCase(Trim(BrCode)) & "' and " & _
            "upper(trim(moduleid)) ='" & UCase(Trim(ModuleCode)) & "' and " & _
            "BOOKSERIESNO='" & SerNo & "' and LEAVESPERBOOK='" & NoOfLeaves & "' and " & _
            "instrcode='" & InstrCode & "' and upper(trim(status))='ISSUABLE' and " & _
            "upper(trim(transstatus))='A'", "to_number(BOOKSTARTNO)")
ElseIf st = "MODIFY" Then
Set RecSer = ObjFetchRec.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS", "BOOKSTARTNO,BOOKENDNO", _
            "upper(trim(branchcode))='" & UCase(Trim(BrCode)) & "' and " & _
            "upper(trim(moduleid)) ='" & UCase(Trim(ModuleCode)) & "' and " & _
            "BOOKSERIESNO='" & SerNo & "' and LEAVESPERBOOK=" & NoOfLeaves & " and " & _
            "instrcode='" & InstrCode & "' and upper(trim(status))='P' and " & _
            "Upper(trim(Accno))='" & AccNo & "' and " & _
            "accno is not null", "to_number(BOOKSTARTNO)")
End If
    If ObjFetchRec.connerror = "Connected" Then
        If Not RecSer.EOF Then
            Cnt = RecSer.RecordCount
            Num = ""
            i = 0
            counter = 0
            ReDim Preserve Arr(Cnt, 1)
            RecSer.MoveFirst
            Do Until RecSer.EOF
                If i = 0 Then
                    Num = RecSer(0)
                    num1 = RecSer(1)
                    Arr(counter, 0) = Num
                Else
                    Num = Val(Num) + Val(NoOfLeaves)
                    num1 = Val(num1)
                    If Num <> RecSer(0) Then
                    Arr(counter, 1) = num1
                    counter = counter + 1
                    Arr(counter, 0) = RecSer(0)
                    Num = RecSer(0)
                    num1 = RecSer(1)
                End If
        End If
        Num = Num
        num1 = RecSer(1)
        i = i + 1
        RecSer.MoveNext
            If RecSer.EOF Then
                Arr(counter, 1) = num1
            End If
        Loop
        BookRange = Arr
        Exit Function
    Else
      ReDim Arr(0, 0) As Variant
      Arr(0, 0) = "No BookSeries"
      BookRange = Arr
      Exit Function
    End If
  Else
    ReDim Arr(0, 0) As Variant
    Arr(0, 0) = "Connection Error"
    BookRange = Arr
    Exit Function
  End If
ErrHand:
ReDim Arr(0, 0) As Variant
Arr(0, 0) = "BookSeries Range not formed due to " & Err.Number & Err.Description
Arr(0, 0) = Replace(Arr(0, 0), Chr(10), "")
Arr(0, 0) = Replace(Arr(0, 0), Chr(13), "")
BookRange = Arr
End Function
Public Function LeafRange(BranchCode As String, MODULEID As String, _
                        Seriesno As String, InstrCode As String, _
                        st As String, Accountno As String) As Variant
Dim BrCode As String
Dim ModuleCode As String
Dim SerNo As String
Dim Num As String
Dim AccNo As String
Dim Arr() As Variant
Dim counter
BrCode = UCase(Trim(BranchCode))
ModuleCode = UCase(Trim(MODULEID))
SerNo = UCase(Trim(Seriesno))
AccNo = UCase(Trim(Accountno))
On Error GoTo ErrHand
Set RecSer = CreateObject("Adodb.recordset")
RecSer.CursorLocation = adUseClient
Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
If st = "ADD" Then
Set RecSer = ObjFetchRec.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS", _
                "LEAFNUMBER", "upper(trim(branchcode))='" & UCase(Trim(BrCode)) & "' and " & _
                "upper(trim(MODULEID))='" & ModuleCode & "' AND LEAFSERIESNO='" & SerNo & "' and " & _
                "instrcode='" & InstrCode & "' and upper(trim(status))='ISSUABLE' and " & _
                "upper(trim(transstatus))='A'", "to_number(LEAFNUMBER)")
ElseIf st = "MODIFY" Then
    Set RecSer = ObjFetchRec.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS", _
                "LEAFNUMBER", "upper(trim(branchcode))='" & UCase(Trim(BrCode)) & "' and " & _
                "upper(trim(MODULEID))='" & ModuleCode & "' AND LEAFSERIESNO='" & SerNo & "' and " & _
                "instrcode='" & InstrCode & "' and upper(trim(status))='P' and " & _
                "Upper(trim(Accno))='" & AccNo & "' and " & _
                "trim(accno) is not null", "to_number(LEAFNUMBER)")
End If
   If ObjFetchRec.connerror = "Connected" Then
    If Not RecSer.EOF Then
        Cnt = RecSer.RecordCount
        Num = ""
        i = 0
        counter = 0
        ReDim Preserve Arr(Cnt, 1)
        RecSer.MoveFirst
        Do Until RecSer.EOF
            If i = 0 Then
                Num = RecSer(0)
                Arr(counter, 0) = Num
            Else
                Num = Val(Num) + 1
                    If Num <> RecSer(0) Then
                        Arr(counter, 1) = Num - 1
                        counter = counter + 1
                        Arr(counter, 0) = RecSer(0)
                        Num = RecSer(0)
                    End If
            End If
         Num = Num
         i = i + 1
         RecSer.MoveNext
          If RecSer.EOF Then
            Arr(counter, 1) = Num
          End If
       Loop
       LeafRange = Arr
       Exit Function
   Else
    ReDim Arr(0, 0) As Variant
    Arr(0, 0) = "No Leafs"
    LeafRange = Arr
    Exit Function
   End If
 Else
  ReDim Arr(0, 0) As Variant
  Arr(0, 0) = "Connection Error"
  LeafRange = Arr
 End If
ErrHand:
 ReDim Arr(0, 0) As Variant
 Arr(0, 0) = "Leaf Range not formed due to " & Err.Number & Err.Description
 Arr(0, 0) = Replace(Arr(0, 0), Chr(10), "")
 Arr(0, 0) = Replace(Arr(0, 0), Chr(13), "")
 LeafRange = Arr
 Exit Function
End Function



