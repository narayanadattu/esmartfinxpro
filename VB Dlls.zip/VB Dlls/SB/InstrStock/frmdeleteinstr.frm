VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   5325
   ClientLeft      =   240
   ClientTop       =   1935
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   ScaleHeight     =   5325
   ScaleWidth      =   6585
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   405
      Left            =   2190
      TabIndex        =   0
      Top             =   1140
      Width           =   1665
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim ObjContext As objectcontext
'Dim ObjTrans As Object
'Dim ObjFetchRec As Object
Dim ObjFetchRec As New FetchRecordsets
Dim ObjTrans As New TransactionMethods
Dim RecInstr As Recordset
Dim RecInst As Recordset
Dim RecInstb As Recordset
Public Function InstrDeleteTran(BranchCode As String, _
                                 InstCode As String, _
                                 BookLeafYn As String, SeriesNo As String, _
                                 NoOfBookLeaf As Long, status As String, _
                                BookLeafStno As Long, BookLeafEndno As Long, _
                                Optional Leafperbook As Long) As String




''decaring variables

Dim BrCode As String
Dim InstrCode As String
Dim BkLfYn As String
Dim SerNo As String
Dim NoofbkLf As Long
Dim BkLfStNo As Long
Dim BkLfEndNo As Long
Dim LfPerBk As Long
Dim BkLf As String
Dim BsNo As Long
Dim BeNo As Long
Dim StrTabName As String
Dim StrUpdate As String
Dim StrUpFldNames As String
Dim StrUpFldvalues()
Dim StrUpCondition As String
Dim StrDelete As String
Dim icnt As Long
'''storing parametarised arguments in variables

    BrCode = UCase(Trim(BranchCode))
     InstrCode = UCase(Trim(InstCode))
     BkLfYn = UCase(Trim(BookLeafYn))
     SerNo = UCase(Trim(SeriesNo))
     NoofbkLf = Trim(NoOfBookLeaf)
     BkLfStNo = Trim(BookLeafStno)
     BkLfEndNo = Trim(BookLeafEndno)
     LfPerBk = Trim(Leafperbook)
     BkLf = UCase(Trim(BookLeafYn))
    Set RecInstr = CreateObject("adodb.recordset")
    Set RecInst = CreateObject("adodb.recordset")
    Set RecInstb = CreateObject("adodb.recordset")
    StrTabName = "GENINSTRUMENTSTOCKDTLS"
    'Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set ObjContext = GetObjectContext
   ' Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    On Error GoTo errhnd
        icnt = 0
        If BkLfYn = "B" Then
                   
            
            StrDelete = ObjTrans.DeleteRecord(StrTabName, _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "trim(bookstartno)=" & BkLfStNo & " and " & _
                            "trim(bookendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
            If StrDelete <> "Trans Completed" Then
            InstrDeleteTran = "Record Not deleted in " & StrTabName & " due to false condition"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            
            Exit Function
            End If
            
           
            
                Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(bookendno),0)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                    "bookstartno<'" & BkLfStNo & "' group by bookseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
             Else
             BsNo = 0
             End If
            
            Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "bookstartno,bookendno,noofbooks,leavesperbook", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(bookstartno)>" & Val(BkLfStNo) & "", "Bookstartno")
                    If Not RecInst.EOF Then
                        ReDim StrUpFldvalues(RecInst.recordcount - 1)
                        Do Until RecInst.EOF
                           If Val(BsNo) = 0 Then
                            BsNo = RecInst(0)
                           End If
                        BeNo = Val(BsNo) + Val(RecInst(2)) * Val(RecInst(3)) - 1
                        StrUpFldvalues(icnt) = "" & BsNo & "~" & BeNo & ""
                            BsNo = Val(BeNo) + 1
                            icnt = icnt + 1
                            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInst(2) & "' and " & _
                                         "Trim(bookstartno) = " & RecInst(0) & " and " & _
                                        "trim(bookendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                           
                        RecInst.movenext
                        Loop
                        StrUpFldNames = "Bookstartno,bookendno"
                        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
                        StrUpdate = ObjTrans.UpdateRecord(StrTabName, _
                                    StrUpFldNames, StrUpFldvalues, StrUpCondition)
                        
                        If StrUpdate <> "Trans Completed" Then
                            InstrDeleteTran = "Records Not Modified in " & StrTabName
                            Set ObjContext = Nothing
                            Set ObjFetchRec = Nothing
                            Set ObjTrans = Nothing
                            
                            Exit Function
                        End If
                        
                    End If
           
            
                                    
                            


        ElseIf BkLf = "L" Then
                
            Dim StrDelete As String
            StrDelete = ObjTrans.DeleteRecord(StrTabName, _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "trim(leafstartno)=" & BkLfStNo & " and " & _
                            "trim(leafendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
            If StrDelete <> "Trans Completed" Then
            InstrDeleteTran = "Record Not deleted in " & StrTabName & " due to false condition"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            Set RecInstr = Nothing
            Exit Function
            End If
             Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(leafendno),0)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(leafyesno))='Y' and " & _
                    "leafstartno<'" & BkLfStNo & "' group by leafseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
             Else
             BsNo = 0
             End If
                 Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "leafstartno,leafendno,noofleaves", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(leafstartno)>" & Val(BkLfStNo) & "", "leafstartno")
                    If Not RecInst.EOF Then
                        ReDim StrUpFldvalues(RecInst.recordcount - 1)
                        Do Until RecInst.EOF
                           If Val(BsNo) = 0 Then
                            BsNo = RecInst(0)
                           End If
                        BeNo = Val(BsNo) + Val(RecInst(2)) - 1
                        StrUpFldvalues(icnt) = "" & BsNo & "~" & BeNo & ""
                            BsNo = Val(BeNo) + 1
                            icnt = icnt + 1
                            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInst(2) & "' and " & _
                                         "Trim(leafstartno) = " & RecInst(0) & " and " & _
                                        "trim(leafendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                           
                        RecInst.movenext
                        Loop
                        StrUpFldNames = "leafstartno,leafendno"
                        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
                        StrUpdate = ObjTrans.UpdateRecord(StrTabName, _
                                    StrUpFldNames, StrUpFldvalues, StrUpCondition)
                        
                        If StrUpdate <> "Trans Completed" Then
                            InstrDeleteTran = "Records Not Modified in " & StrTabName
                            Set ObjContext = Nothing
                            Set ObjFetchRec = Nothing
                            Set ObjTrans = Nothing
                            Set RecInstr = Nothing
                            Exit Function
                        End If
                        
                    End If
           
     End If
         'ObjContext.setcomplete
          InstrDeleteTran = "Transacion Successful"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            Set RecInstr = Nothing
            Exit Function
errhnd:
ObjContext.SetAbort
Set ObjFetchRec = Nothing
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set RecInstr = Nothing
Set RecInst = Nothing
InstrDeleteTran = Err.Number & Err.Description

End Function


Private Sub Command1_Click()
Dim str As String
str = InstrDeleteTran("0001", "CHQ", "L", "ABC", "30", "STOCK", "1", "300", "10")
MsgBox str
End Sub

