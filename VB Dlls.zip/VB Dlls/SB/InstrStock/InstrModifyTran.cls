VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "InstrModifyTran"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim ObjContext As ObjectContext
Dim ObjTrans As Object
'''Dim ObjTrans As New TransactionMethods
Dim ObjFetchRec As Object
Dim RecInstr As Recordset
Dim RecInst As Recordset
Dim RecInstb As Recordset
Public Function InstrTransaction(BranchCode As String, _
                                 InstCode As String, InstName As String, _
                                 BookLeafYn As String, SeriesNo As String, _
                                 NoOfBookLeaf As Long, status As String, _
                                BookLeafStno As Long, BookLeafEndno As Long, _
                                 StockRecDate As String, _
                                AppDate As String, UserId As String, MachineID As String, _
                                Optional Leafperbook As Long) As String
 ''declaring variables
 
 Dim Strupdate As String
Dim StrTabName As String
Dim StrInsert As String
Dim StrInsFldNames  As String
Dim StrInsFldValues(0)  As String
Dim StrDelete As String
Dim StrDelCondition As String
Dim StrUpFldvalues(0) As Variant
Dim StrPrevUpdate As String
Dim strPrevUpFldNames As String
Dim StrPrevUpFldValues() As Variant
Dim StrPrevCondition As String
Dim BRCode As String
Dim InstrCode As String
Dim BkLfYn As String
Dim SerNo As String
Dim NoofbkLf As Long
Dim BkLfStNo As Long
Dim BkLfEndNo As Long
Dim LfPerBk As Long
Dim LfNo As Long
Dim InstrName As String
Dim St As String
Dim StockRecDt As String
Dim AppDt As String
Dim UsrId As String
Dim MachId As String
Dim BkSt As Long
Dim BkEd As Long
Dim BsNo As Long
Dim BeNo As Long
Dim icnt As Long
BsNo = 0
BeNo = 0
BkSt = 0
BkEd = 0
strPrevUpFldNames = ""
StrTabName = ""
StrPrevCondition = ""
'' storing arguments in variables

     BRCode = UCase(Trim(BranchCode))
     InstrCode = UCase(Trim(InstCode))
     BkLfYn = UCase(Trim(BookLeafYn))
     SerNo = UCase(Trim(SeriesNo))
     NoofbkLf = Trim(NoOfBookLeaf)
     BkLfStNo = Trim(BookLeafStno)
     BkLfEndNo = Trim(BookLeafEndno)
     LfPerBk = Trim(Leafperbook)
     InstrName = UCase(Trim(InstName))
     St = UCase(Trim(status))
     StockRecDt = StockRecDate
     AppDt = AppDate
     UsrId = UserId
     MachId = MachineID
    
        Set RecInstr = CreateObject("adodb.recordset")
        Set RecInst = CreateObject("adodb.recordset")
        Set RecInstb = CreateObject("adodb.recordset")

        StrTabName = "GENINSTRUMENTSTOCKDTLS"
        Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set ObjContext = GetObjectContext
    Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    On Error GoTo errhnd
        
        If BkLfYn = "B" Then

                        
               
            Set RecInstr = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
                            "leavesperbook,noofbooks", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "trim(bookstartno)=" & BkLfStNo & " and " & _
                            "trim(bookendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
                           
            
            If Not RecInstr.EOF Then
               Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(bookendno),0)", _
                    "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "trim(bookendno)<" & BkLfEndNo & " and " & _
                    "upper(trim(leavesperbook))='" & LfPerBk & "' group by bookseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
                BeNo = Val(BsNo) + Val(LfPerBk) * Val(NoofbkLf) - 1
            Else
                
                BsNo = 1
                BeNo = Val(BsNo) + Val(LfPerBk) * Val(NoofbkLf) - 1
            End If
               
                
                
                                         
                Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "bookstartno,bookendno,noofbooks", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leavesperbook))='" & RecInstr(0) & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(bookstartno)>" & Val(BkLfStNo) & "", "Bookstartno")
        
               
                
                    If Not RecInst.EOF Then
                    ReDim StrPrevUpFldValues(RecInst.RecordCount)
                        
                        StrPrevUpFldValues(0) = "" & BsNo & "~" & BeNo & "~" & NoofbkLf & "~" & LfPerBk & ""
                        StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInstr(1) & "' and " & _
                                        "Trim(bookstartno) = " & BkLfStNo & " and " & _
                                        "trim(bookendno)=" & BkLfEndNo & " and " & _
                                        "trim(leavesperbook)=" & RecInstr(0) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                    icnt = 1
                    
                        Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(to_number(bookendno)),0)", _
                    "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "trim(to_number(bookstartno))<" & Val(BkLfStNo) & " and " & _
                    "upper(trim(leavesperbook))=" & RecInstr(0) & " group by bookseriesno")
        
                        If Not RecInstb.EOF Then
                                BsNo = Val(RecInstb(0)) + 1
                        Else
                                BsNo = 1
                
                    End If
                    
                    
                    
                        Do Until RecInst.EOF
                                       
                            'BsNo = Val(RecInst(1)) + 1
                            BeNo = Val(BsNo) + Val(RecInstr(0)) * Val(RecInst(2)) - 1
                            StrPrevUpFldValues(icnt) = "" & BsNo & "~" & BeNo & "~" & RecInst(2) & "~" & RecInstr(0) & ""
                            BsNo = Val(BeNo) + 1
                            icnt = icnt + 1
                            StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(leavesperbook))=" & RecInstr(0) & " and " & _
                                        "upper(trim(noofbooks))='" & RecInst(2) & "' and " & _
                                         "Trim(bookstartno) = " & RecInst(0) & " and " & _
                                        "trim(bookendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                        
                        RecInst.MoveNext
                        Loop
                        StrPrevCondition = Left(StrPrevCondition, Len(StrPrevCondition) - 1)
                        
                        strPrevUpFldNames = "bookstartno,bookendno,noofbooks,leavesperbook"
                         StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
                    If StrPrevUpdate <> "Trans Completed" Then
                        InstrTransaction = "update failed in  " & StrTabName
                        Set ObjFetchRec = Nothing
                        Set ObjTrans = Nothing
                        Set ObjContext = Nothing
                        Set RecInstr = Nothing
                        Set RecInst = Nothing
                        Exit Function
                    End If
                 Else
                 ReDim StrPrevUpFldValues(0)
                 StrPrevUpFldValues(0) = "" & BsNo & "~" & BeNo & "~" & NoofbkLf & "~" & LfPerBk & ""
                StrPrevCondition = "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInstr(1) & "' and " & _
                                        "Trim(bookstartno) = " & BkLfStNo & " and " & _
                                        "trim(bookendno)=" & BkLfEndNo & " and " & _
                                        "trim(leavesperbook)=" & RecInstr(0) & " and " & _
                                         "upper(trim(status))='STOCK'"
                                         
                strPrevUpFldNames = "bookstartno,bookendno,noofbooks,leavesperbook"
                StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
                    If StrPrevUpdate <> "Trans Completed" Then
                        InstrTransaction = "update failed in  " & StrTabName
                        Set ObjFetchRec = Nothing
                        Set ObjTrans = Nothing
                        Set ObjContext = Nothing
                        Set RecInstr = Nothing
                        Set RecInst = Nothing
                        Exit Function
                    End If
                End If
            Else
                InstrTransaction = "no records in " & StrTabName
                Set ObjFetchRec = Nothing
                Set ObjTrans = Nothing
                Set ObjContext = Nothing
                Set RecInstr = Nothing
                Set RecInst = Nothing
                Exit Function
            End If

    
 
ElseIf BkLfYn = "L" Then
      Set RecInstr = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
                            "noofleaves", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "trim(leafstartno)=" & BkLfStNo & " and " & _
                            "trim(leafendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
                           
            
            If Not RecInstr.EOF Then
                Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(to_number(leafendno)),0)", _
                    "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(leafyesno))='Y' and " & _
                    "to_number(leafendno)<" & Val(BkLfStNo) & "" & _
                    " group by leafseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
                BeNo = Val(BsNo) + Val(NoofbkLf) - 1
            Else
                BsNo = 1
                BeNo = Val(BsNo) + Val(NoofbkLf) - 1
            End If
  
  
             Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "leafstartno,leafendno,noofleaves", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(leafstartno)>" & Val(BkLfStNo) & "", "leafstartno")
        
               
                
                    If Not RecInst.EOF Then
                        ReDim StrPrevUpFldValues(RecInst.RecordCount)
                        
                        StrPrevUpFldValues(0) = "" & BsNo & "~" & BeNo & "~" & NoofbkLf & ""
                        StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofleaves))='" & RecInstr(0) & "' and " & _
                                        "Trim(leafstartno) = " & BkLfStNo & " and " & _
                                        "trim(leafendno)=" & BkLfEndNo & " and " & _
                                       "upper(trim(status))='STOCK'" & "|"
                    icnt = 1
           
              Do Until RecInst.EOF
                                       
                            BsNo = Val(BeNo) + 1
                            BeNo = Val(BsNo) + Val(RecInst(2)) - 1
                            StrPrevUpFldValues(icnt) = "" & BsNo & "~" & BeNo & "~" & RecInst(2) & ""
                            icnt = icnt + 1
                            StrPrevCondition = StrPrevCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofleaves))= " & RecInst(2) & "  and " & _
                                         "Trim(leafstartno) = " & RecInst(0) & " and " & _
                                        "trim(leafendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                        
                        RecInst.MoveNext
                        Loop
                        StrPrevCondition = Left(StrPrevCondition, Len(StrPrevCondition) - 1)
                        
                        
                        strPrevUpFldNames = "leafstartno,leafendno,noofleaves"
                StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
                    If StrPrevUpdate <> "Trans Completed" Then
                        InstrTransaction = "update failed in  " & StrTabName
                        Set ObjFetchRec = Nothing
                        Set ObjTrans = Nothing
                        Set ObjContext = Nothing
                        Set RecInstr = Nothing
                        Set RecInst = Nothing
                        Exit Function
                                          
                        
                    End If
                  Else
                 ReDim StrPrevUpFldValues(0)
                 strPrevUpFldNames = "leafstartno,leafendno,noofleaves"
                 StrPrevUpFldValues(0) = "" & BsNo & "~" & BeNo & "~" & NoofbkLf & ""
                StrPrevCondition = "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(noofleaves))=" & RecInstr(0) & " and " & _
                                        "Trim(leafstartno) = " & BkLfStNo & " and " & _
                                        "trim(leafendno)=" & BkLfEndNo & " and " & _
                                       "upper(trim(status))='STOCK'"
                                         
                
                StrPrevUpdate = ObjTrans.UpdateRecord(StrTabName, strPrevUpFldNames, _
                                    StrPrevUpFldValues, StrPrevCondition)
                    If StrPrevUpdate <> "Trans Completed" Then
                        InstrTransaction = "update failed in  " & StrTabName
                        Set ObjFetchRec = Nothing
                        Set ObjTrans = Nothing
                        Set ObjContext = Nothing
                        Set RecInstr = Nothing
                        Set RecInst = Nothing
                        Exit Function
                    End If
                End If
            Else
                InstrTransaction = "no records in " & StrTabName
                Set ObjFetchRec = Nothing
                Set ObjTrans = Nothing
                Set ObjContext = Nothing
                Set RecInstr = Nothing
                Set RecInst = Nothing
                Exit Function
            End If

   
End If
ObjContext.SetComplete
InstrTransaction = "Transaction Successful"
Set ObjFetchRec = Nothing
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set RecInstr = Nothing
Set RecInst = Nothing
Set RecInstb = Nothing
Exit Function
errhnd:
ObjContext.SetAbort
Set ObjFetchRec = Nothing
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set RecInstr = Nothing
Set RecInst = Nothing
InstrTransaction = Err.Number & Err.Description
InstrTransaction = Replace(InstrTransaction, Chr(10), "")
InstrTransaction = Replace(InstrTransaction, Chr(13), "")
End Function

'''--------------------------------------------------------------------------------

''''------ this is a method for deleting a row in GENINSTRUMENTSTOCKDTLS and updating
''''' the order of the book or leaf startno,endno sequence

'''--------------------------------------------------------------------------
Public Function InstrDeleteTran(BranchCode As String, _
                                 InstCode As String, _
                                 BookLeafYn As String, SeriesNo As String, _
                                 NoOfBookLeaf As Long, status As String, _
                                BookLeafStno As Long, BookLeafEndno As Long, _
                                Optional Leafperbook As Long) As String




''decaring variables

Dim BRCode As String
Dim InstrCode As String
Dim BkLfYn As String
Dim SerNo As String
Dim NoofbkLf As Long
Dim BkLfStNo As Long
Dim BkLfEndNo As Long
Dim LfPerBk As Long
Dim BkLf As String
Dim BsNo As Long
Dim BeNo As Long
Dim StrTabName As String
Dim Strupdate As String
Dim StrUpFldNames As String
Dim StrUpFldvalues()
Dim StrUpCondition As String
Dim StrDelete As String
Dim icnt As Long
'''storing parametarised arguments in variables

    BRCode = UCase(Trim(BranchCode))
     InstrCode = UCase(Trim(InstCode))
     BkLfYn = UCase(Trim(BookLeafYn))
     SerNo = UCase(Trim(SeriesNo))
     NoofbkLf = Trim(NoOfBookLeaf)
     BkLfStNo = Trim(BookLeafStno)
     BkLfEndNo = Trim(BookLeafEndno)
     LfPerBk = Trim(Leafperbook)
     BkLf = UCase(Trim(BookLeafYn))
    Set RecInstr = CreateObject("adodb.recordset")
    Set RecInst = CreateObject("adodb.recordset")
    Set RecInstb = CreateObject("adodb.recordset")
    StrTabName = "GENINSTRUMENTSTOCKDTLS"
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
    Set ObjContext = GetObjectContext
    Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    On Error GoTo errhnd
        icnt = 0
        If BkLfYn = "B" Then
                   
            
            StrDelete = ObjTrans.DeleteRecord(StrTabName, _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "trim(bookstartno)=" & BkLfStNo & " and " & _
                            "trim(bookendno)=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
            If StrDelete <> "Trans Completed" Then
            InstrDeleteTran = "Record Not deleted in " & StrTabName & " due to false condition"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            
            Exit Function
            End If
            
           
            
                Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(bookendno),0)", _
                    "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(bookyesno))='Y' and " & _
                    "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                    "bookstartno<'" & BkLfStNo & "' group by bookseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
             Else
             BsNo = 0
             End If
            
            Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "bookstartno,bookendno,noofbooks,leavesperbook", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(bookyesno))='Y' and " & _
                            "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(bookstartno)>" & Val(BkLfStNo) & "", "Bookstartno")
                    If Not RecInst.EOF Then
                        ReDim StrUpFldvalues(RecInst.RecordCount - 1)
                        Do Until RecInst.EOF
                           If Val(BsNo) = 0 Then
                            BsNo = Val(BkLfStNo)
                           End If
                        BeNo = Val(BsNo) + Val(RecInst(2)) * Val(RecInst(3)) - 1
                        StrUpFldvalues(icnt) = "" & BsNo & "~" & BeNo & ""
                            BsNo = Val(BeNo) + 1
                            icnt = icnt + 1
                            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(bookyesno))='Y' and " & _
                                        "upper(trim(bookseriesno))='" & SerNo & "' and " & _
                                        "upper(trim(leavesperbook))='" & LfPerBk & "' and " & _
                                        "upper(trim(noofbooks))='" & RecInst(2) & "' and " & _
                                         "Trim(bookstartno) = " & RecInst(0) & " and " & _
                                        "trim(bookendno)=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                           
                        RecInst.MoveNext
                        Loop
                        StrUpFldNames = "Bookstartno,bookendno"
                        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
                        Strupdate = ObjTrans.UpdateRecord(StrTabName, _
                                    StrUpFldNames, StrUpFldvalues, StrUpCondition)
                        
                        If Strupdate <> "Trans Completed" Then
                            InstrDeleteTran = "Records Not Modified in " & StrTabName
                            Set ObjContext = Nothing
                            Set ObjFetchRec = Nothing
                            Set ObjTrans = Nothing
                            
                            Exit Function
                        End If
                        
                    End If
           
            
                                    
                            


        ElseIf BkLf = "L" Then
                
            
            StrDelete = ObjTrans.DeleteRecord(StrTabName, _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "trim(to_number(leafstartno))=" & BkLfStNo & " and " & _
                            "trim(to_number(leafendno))=" & BkLfEndNo & " and " & _
                            "upper(trim(status))='STOCK'")
            If StrDelete <> "Trans Completed" Then
            InstrDeleteTran = "Record Not deleted in " & StrTabName & " due to false condition"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            Set RecInstr = Nothing
            Exit Function
            End If
             Set RecInstb = ObjFetchRec.SingleRecordSet(StrTabName, _
                    "nvl(Max(to_number(leafendno)),0)", _
                    "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                    "upper(trim(instrcode))='" & InstrCode & "' and " & _
                    "upper(trim(leafyesno))='Y' and " & _
                    "to_number(leafstartno)<" & BkLfStNo & " group by leafseriesno")
        
            If Not RecInstb.EOF Then
                BsNo = Val(RecInstb(0)) + 1
             Else
             BsNo = 0
             End If
                 Set RecInst = ObjFetchRec.SingleRecordSet(StrTabName, _
                            "leafstartno,leafendno,noofleaves", _
                            "upper(trim(branchcode))='" & BRCode & "' and " & _
                            "upper(trim(instrcode))='" & InstrCode & "' and " & _
                            "upper(trim(leafyesno))='Y' and " & _
                            "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                            "upper(trim(status))='STOCK' and " & _
                            "trim(leafstartno)>" & Val(BkLfStNo) & "", "leafstartno")
                    If Not RecInst.EOF Then
                        ReDim StrUpFldvalues(RecInst.RecordCount - 1)
                        Do Until RecInst.EOF
                           If Val(BsNo) = 0 Then
                            BsNo = RecInst(0)
                           End If
                        BeNo = Val(BsNo) + Val(RecInst(2)) - 1
                        StrUpFldvalues(icnt) = "" & BsNo & "~" & BeNo & ""
                            BsNo = Val(BeNo) + 1
                            icnt = icnt + 1
                            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BRCode & "' and " & _
                                        "upper(trim(instrcode))='" & InstrCode & "' and " & _
                                        "upper(trim(leafyesno))='Y' and " & _
                                        "upper(trim(leafseriesno))='" & SerNo & "' and " & _
                                        "trim(noofleaves)=" & RecInst(2) & " and " & _
                                         "Trim(to_number(leafstartno)) = " & RecInst(0) & " and " & _
                                        "trim(to_number(leafendno))=" & RecInst(1) & " and " & _
                                         "upper(trim(status))='STOCK'" & "|"
                           
                        RecInst.MoveNext
                        Loop
                        StrUpFldNames = "leafstartno,leafendno"
                        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
                        Strupdate = ObjTrans.UpdateRecord(StrTabName, _
                                    StrUpFldNames, StrUpFldvalues, StrUpCondition)
                        
                        If Strupdate <> "Trans Completed" Then
                            InstrDeleteTran = "Records Not Modified in " & StrTabName
                            Set ObjContext = Nothing
                            Set ObjFetchRec = Nothing
                            Set ObjTrans = Nothing
                            Set RecInstr = Nothing
                            Exit Function
                        End If
                        
                    End If
           
     End If
         ObjContext.SetComplete
          InstrDeleteTran = "Transacion Successful"
            Set ObjContext = Nothing
            Set ObjFetchRec = Nothing
            Set ObjTrans = Nothing
            Set RecInstr = Nothing
            Exit Function
errhnd:
ObjContext.SetAbort
Set ObjFetchRec = Nothing
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set RecInstr = Nothing
Set RecInst = Nothing
InstrDeleteTran = Err.Number & Err.Description
InstrDeleteTran = Replace(InstrDeleteTran, Chr(10), "")
InstrDeleteTran = Replace(InstrDeleteTran, Chr(13), "")

End Function
