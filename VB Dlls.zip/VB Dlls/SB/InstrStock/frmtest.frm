VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   5325
   ClientLeft      =   240
   ClientTop       =   1935
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   ScaleHeight     =   5325
   ScaleWidth      =   6585
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   525
      Left            =   2730
      TabIndex        =   0
      Top             =   2430
      Width           =   1245
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Obj As Object
Private Sub Command1_Click()
Dim str As String
Set Obj = CreateObject("Instrstockmodify.instrmodifytran")
'str = Obj.InstrTransaction("0001", "CHQ", "Cheque", "B", "ABC", "30", "STOCK", "401", "1000", "12-09-2001", "12-09-2001", "U001", "M001", "10")
''str = InstrTransaction("0001", "CHQ", "Cheque", "L", "LABC", "10", "STOCK", "21", "50", "12-09-2001", "12-09-2001", "U001", "M001")

str = Obj.InstrDeleteTran("0001", "chq", "L", "LABC", "70", "stock", "111", "180")

MsgBox str
End Sub

