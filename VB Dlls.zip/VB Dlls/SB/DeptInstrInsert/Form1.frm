VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4935
   ClientLeft      =   240
   ClientTop       =   2325
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   ScaleHeight     =   4935
   ScaleWidth      =   6585
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   255
      Left            =   1920
      TabIndex        =   0
      Top             =   1080
      Width           =   735
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Obj As Object

Private Sub Command1_Click()
Set Obj = CreateObject("DeptInstrInsert.BookLeafDeptInsert")
Dim str As String



str = Obj.custinstruments("gendeptcustinstrstockdtls", "9999", "SB", "ANUPAMA", "10-10-2001", "10-10-2001", "CHQ", _
                    "B", "10", "PQR", "1", "20", "", "", "", "", "2", "", "yyy", "uuu")
                    
End Sub
