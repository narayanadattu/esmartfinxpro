VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "BookLeafDeptInsert"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'''************************************************************************************
''''' This componenet is used to issue the stock to Department
'''' this Component is used to insert the values into DeptInstrStockDtls Table and
''''' update the stock i.e update the values in GenInstrStockDtls table
'''*******************************************************************************
'Implements ObjectControl
Option Explicit
Dim ObjContext As ObjectContext
Dim ObjTrans As Object
Dim ObjFetchRec As Object
Dim RecGen As Recordset
Dim RecDeptInstr As Recordset

Public Function CustInstruments(TableName As String, BranchCode As String, _
        ModuleCode As String, IssuedTo As String, _
        AppDate As String, DeptrecDate As String, InsCode As String, _
        BookYN As String, LeavesperBook As String, BookSeriesno As String, _
        BookStNo As String, BookEndNo As String, LeafYN As String, LeafSeriesNo As String, _
        LeafStNo As String, LeafEndNo As String, NoOfBks As String, NoOfLeaves As String, _
        UsrId As String, MachID As String, Optional ChqSno As Variant) As String
        
'''declaring the variables
Dim objStatus As String
Dim TableNm As String
Dim BRCode As String
Dim Moduleid As String
Dim InsStatus As String
Dim IssueTo As String
Dim AppDt As String
Dim DeptDt As String
Dim InstrCode As String
Dim BookYesNo As String
Dim LeavesperBk As String
Dim BookSeries As String
Dim BkStNo As String
Dim BKEndNo As String
Dim LeafYesNo As String
Dim LeafSerNo As String
Dim LfNo As String
Dim LfEndNo As String
Dim UsId As String
Dim Macid As String
Dim NoOfbk As String
Dim NoOflf As String
Dim Status As String
Dim UpStatus As String
Dim StrFlds As String
Dim StrValues As String
Dim StrInsValues() As Variant
Dim StrUpFlds As String
Dim StrUp
Dim StrWhere As String
Dim Strupdate
Dim StrWhereCondition As String
Dim StrQrytab As String
Dim StrQryFlds As String
Dim TotBook As String
Dim TotLeaf As String
Dim TransResult As String
Dim ICount As Integer
Dim StrInTabName As String
Dim StrInFldNames As String
Dim StrInFldValues() As String
Dim t As Double
Dim n As Double
Dim u As Double
Dim TransSt As String
Dim chqno As Long
Dim ChqStNo
Dim tBook As Double
On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********
TableNm = UCase(Trim(TableName))
BRCode = UCase(Trim(BranchCode))
Moduleid = UCase(Trim(ModuleCode))
IssueTo = UCase(Trim(IssuedTo))
AppDt = Format(AppDate, "dd/mm/yyyy")
DeptDt = Format(DeptrecDate, "dd/mm/yyyy")
InstrCode = UCase(Trim(InsCode))
BookYesNo = UCase(Trim(BookYN))
LeavesperBk = UCase(Trim(LeavesperBook))
BookSeries = UCase(Trim(BookSeriesno))
BkStNo = UCase(Trim(BookStNo))
BKEndNo = UCase(Trim(BookEndNo))
LeafYesNo = UCase(Trim(LeafYN))
LeafSerNo = UCase(Trim(LeafSeriesNo))
LfNo = Trim(LeafStNo)
LfEndNo = Trim(LeafEndNo)
UsId = UCase(Trim(UsrId))
Macid = UCase(Trim(MachID))
NoOfbk = Trim(NoOfBks)
NoOflf = Trim(NoOfLeaves)
ChqStNo = ChqSno
Status = "ISSUABLE"
TransSt = "P"
If LeavesperBk = "" Then
LeavesperBk = ""
End If
If BookSeries = "" Then
BookSeries = ""
End If
If BookYesNo = "" Then
BookYesNo = ""
End If
If BkStNo = "" Then
BkStNo = ""
End If
If BKEndNo = "" Then
BKEndNo = ""
End If
If LeafYesNo = "" Then
LeafYesNo = ""
End If
If LeafSerNo = "" Then
LeafSerNo = ""
Else
End If
If LfNo = "" Then
LfNo = ""
End If
If NoOfbk = "" Then
NoOfbk = 0
End If
If NoOflf = "" Then
NoOflf = 0
End If
InsStatus = "P"
'''' calling general queryrecordset componenet to set the Recordsets
Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
Dim j As Long
j = 0
Dim RecInst As Recordset
 Set RecInst = CreateObject("adodb.recordset")
 Set RecDeptInstr = CreateObject("adodb.recordset")
'''' checking the instrumentcode is CHEQue and others
If InstrCode <> "DD" Then

StrFlds = "BranchCode,MODULEID,IssuedTo,APPLICATIONDATE,DEPTRECEIVEDDATE," & _
            "INSTRCODE,BookYesNo,LeavesperBook,BookSeriesno,BOOKSTARTNO,BookEndNo,LeafYesNo," & _
            "LeafSeriesNo,LEAFnumber,UserId,MachineID,Status,TRANSSTATUS,systemdate"
'''' checking the instrumentcode is DD
ElseIf InstrCode = "DD" Or InstrCode = "PO" Or InstrCode = "MT" Or InstrCode = "BC" Then

StrFlds = "BranchCode,MODULEID,IssuedTo,APPLICATIONDATE,DEPTRECEIVEDDATE," & _
            "INSTRCODE,BookYesNo,LeavesperBook,BookSeriesno,BOOKSTARTNO,BookEndNo,LeafYesNo," & _
            "LeafSeriesNo,LEAFnumber,UserId,MachineID,Status,BOOKCHQSTNO,BOOKCHQENDNO,TRANSSTATUS,systemdate"
End If
'''' if the series is Book---------
 If LeafYesNo = "" Then
 
 ''''' set the recordset for bookstartno,bookendno in stock table
 ''''   this recordset is used when bookseries sequence is changed
 Set RecInst = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
                "nvl(BOOKSTARTNO,0),nvl(BOOKENDNO,0)," & _
                "nvl(noofbooks,0)-nvl(NOBOOKISSUED,0)," & _
                "nvl(NOBOOKISSUED,0)", "branchcode='" & BRCode & "' and " & _
                "upper(trim(bookyesno))='Y' and " & _
                "upper(trim(Status))<>'ISSUED' and " & _
                "upper(trim(TranStatus))='A' and " & _
                "leavesperbook=" & LeavesperBk & " and " & _
                "upper(trim(BOOKSERIESNO))='" & BookSeries & "'", "to_number(bookstartno)")
    If Not RecInst.EOF And Not RecInst.BOF Then
    j = 0
    
    ReDim StrInsValues(NoOfbk - 1)
        Do While Not RecInst.EOF
   
   If Val(BkStNo) = 0 Then
        BkStNo = RecInst(0) & ""
   End If
 '''''redimentioning the array varaiable which is used in child dmloperations component
        
 

Do While j <= Val(NoOfbk)
'For j = 0 To Val(NoOfbk) - 1
      '''comparing startno with startno in department
 Set RecDeptInstr = ObjFetchRec.SingleRecordSet("GENDEPTCUSTINSTRSTOCKDTLS", _
    "to_number(bookstartno)", _
    "upper(trim(branchcode))='" & BRCode & "' and " & _
    "upper(trim(bookyesno))='Y' and " & _
    "LeavesperBook=" & LeavesperBk & " and " & _
    "upper(trim(BOOKSERIESNO))='" & BookSeries & "' and " & _
    "to_number(bookstartno)=" & BkStNo & "", _
    "to_number(bookstartno)")
   
     If Not RecDeptInstr.EOF And Not RecDeptInstr.BOF Then
        
     Else
         If Val(BkStNo) >= Val(RecInst(0)) And Val(BkStNo) <= Val(RecInst(1)) Then
         Else
            Exit Do
         End If
         BKEndNo = Val(BkStNo) + Val(LeavesperBk) - 1
        ''' if instrCode is CHEQUE and others
            If InstrCode <> "DD" Then
        
                StrInsValues(j) = "'" & BRCode & "','" & Moduleid & "','" & IssueTo & _
                    "',to_date('" & AppDt & "','dd-mm-yyyy'),to_date('" & DeptDt & "','dd-mm-yyyy'),'" & InstrCode & _
                    "','" & BookYesNo & "','" & LeavesperBk & "','" & BookSeries & "','" & BkStNo & _
                    "','" & BKEndNo & "','" & LeafYesNo & "','" & LeafSerNo & "','" & LfNo & _
                    "', '" & UsId & "','" & Macid & "','" & Status & "','P',sysdate"
                   
        ''' if instrCode is DD
           ElseIf InstrCode = "DD" Or InstrCode = "PO" Or InstrCode = "BC" Or InstrCode = "MT" Then
                chqno = ChqStNo(LBound(ChqStNo) + Val(j))
                StrInsValues(j) = "'" & BRCode & "','" & Moduleid & "','" & IssueTo & _
                    "',to_date('" & AppDt & "','dd-mm-yyyy'),to_date('" & DeptDt & "','dd-mm-yyyy'),'" & InstrCode & _
                    "','" & BookYesNo & "','" & LeavesperBk & "','" & BookSeries & "','" & BkStNo & _
                    "','" & BKEndNo & "','" & LeafYesNo & "','" & LeafSerNo & "','" & LfNo & _
                    "', '" & UsId & "','" & Macid & "','" & Status & "','" & chqno & "','" & Val(chqno) + Val(LeavesperBk) - 1 & "','P',sysdate"
                    
           End If
       j = j + 1
       End If
 
If Val(BkStNo) >= Val(RecInst(1)) Then Exit Do
If Val(j) = Val(NoOfbk) Then Exit Do
BkStNo = Val(BkStNo) + Val(LeavesperBk)
Loop
RecInst.MoveNext
If Val(j) = Val(NoOfbk) Then Exit Do
BkStNo = 0
Loop
Else
CustInstruments = "no Records in GENINSTRUMENTSTOCKDTLS "
Exit Function

End If
If Val(j) <> Val(NoOfbk) Then
    CustInstruments = "Entered Books are not suffiecient in stock"
    Exit Function
End If
''if DD or PO or MT then storing values in remmittddtls table
If InstrCode = "DD" Or InstrCode = "PO" Or InstrCode = "BC" Or InstrCode = "MT" Then
    StrInTabName = "REMITDDDTLS"
    StrInFldNames = "BranchCode,Moduleid,Status,TRANSTATUS,DDNO,DDSERIESNO,APPLICATIONDATE," & _
                    "SYSTEMDATE,instrcode,USERID,MACHINEID"
    chqno = ChqSno(0)
    t = 0
    n = Val(NoOfbk) * Val(LeavesperBk)
    ReDim StrInFldValues(n - 1)
    For u = 0 To NoOfbk - 1
        chqno = ChqStNo(LBound(ChqStNo) + Val(u))
        '''storing insertable values in array variable which is used in child componenet
            For j = 0 To Val(LeavesperBk) - 1
                StrInFldValues(t) = "'" & BRCode & "','" & ModuleCode & "'," & _
                "'" & InsStatus & "','P','" & chqno & "','" & BookSeries & "'," & _
                "to_date('" & AppDt & "','dd-mm-yyyy')," & _
                "to_date('" & AppDt & "','dd-mm-yyyy'),'" & InstrCode & "','" & UsId & "','" & Macid & "'"
                chqno = chqno + 1
                t = t + 1
           Next
   Next
End If
'''' if the series is Leaf
ElseIf BookYesNo = "" Then
''''' set the recordset for bookstartno,bookendno in stock table
 ''''   this recordset is used when bookseries sequence is changed
 
Set RecInst = ObjFetchRec.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
                "nvl(leafSTARTNO,0),nvl(leafENDNO,0),nvl(noofleaves,0)-nvl(NOLEAFISSUED,0)," & _
                "nvl(NOLEAFISSUED,0)", "branchcode='" & BRCode & "' and " & _
                "upper(trim(leafyesno))='Y' and " & _
                "upper(trim(Status))<>'ISSUED' and " & _
                "upper(trim(TranStatus))='A' and " & _
                "upper(trim(leafSERIESNO))='" & LeafSerNo & "'", "to_number(leafstartno)")
If Not RecInst.EOF Then
 j = 0
 ReDim StrInsValues(NoOflf - 1)
Do While Not RecInst.EOF
    If Val(LfNo) = 0 Then
        LfNo = RecInst(0) & ""
   End If
     '''''redimentioning the array varaiable which is used in child dmloperations component

Do While j <= Val(NoOflf)
  '''comparing startno with startno in department
    Set RecDeptInstr = ObjFetchRec.SingleRecordSet("GENDEPTCUSTINSTRSTOCKDTLS", _
       "to_number(LEAFNUMBER)", _
       "upper(trim(branchcode))='" & BRCode & "' and " & _
       "upper(trim(LEAFYESNO))='Y' and " & _
       "upper(trim(LEAFSERIESNO))='" & LeafSerNo & "' and " & _
       "to_number(LEAFNUMBER)=" & LfNo & "", _
       "to_number(LEAFNUMBER)")
   
     If Not RecDeptInstr.EOF And Not RecDeptInstr.BOF Then
        
     Else
        If Val(LfNo) >= Val(RecInst(0)) And Val(LfNo) <= Val(RecInst(1)) Then
         Else
            Exit Do
         End If
        StrInsValues(j) = "'" & BRCode & "','" & Moduleid & "','" & IssueTo & _
                "',to_date('" & AppDt & "','dd-mm-yyyy'),to_date('" & DeptDt & "','dd-mm-yyyy'),'" & InstrCode & _
                "','" & BookYesNo & "','" & LeavesperBk & "','" & BookSeries & "','" & BkStNo & _
                "','" & BKEndNo & "','" & LeafYesNo & "','" & LeafSerNo & "','" & LfNo & _
                "', '" & UsId & "','" & Macid & "','" & Status & "','P',sysdate"
        j = j + 1
    End If
    If Val(LfNo) >= Val(RecInst(1)) Then Exit Do
    If Val(j) = Val(NoOflf) Then Exit Do
        LfNo = Val(LfNo) + 1
Loop
RecInst.MoveNext
If Val(j) = Val(NoOflf) Then Exit Do
LfNo = 0
Loop
Else
CustInstruments = "no Records in GENINSTRUMENTSTOCKDTLS "
Exit Function
End If
If Val(j) <> Val(NoOflf) Then
    CustInstruments = "Entered Leaves are not suffiecient in stock"
    Exit Function
End If
''if DD storing values in remmittddtls table
If InstrCode = "DD" Or InstrCode = "PO" Or InstrCode = "BC" Or InstrCode = "MT" Then
    StrInTabName = "REMITDDDTLS"
    StrInFldNames = "BranchCode,Moduleid,Status,TRANSTATUS,DDNO,DDSERIESNO,APPLICATIONDATE," & _
                    "USERID,MACHINEID,SYSTEMDATE,instrcode"
    chqno = LeafStNo
  '  t = 0
   ' n = Val(NoOfbk) * Val(LeavesperBk)
    ReDim StrInFldValues(CDbl(NoOflf) - 1)
    For u = 0 To CDbl(NoOflf) - 1
        'chqno = ChqStNo(LBound(ChqStNo) + Val(u))
        '''storing insertable values in array variable which is used in child componenet
            
                StrInFldValues(t) = "'" & BRCode & "','" & ModuleCode & "'," & _
                "'P','P','" & chqno & "','" & LeafSerNo & "'," & _
                "to_date('" & AppDt & "','dd-mm-yyyy')," & _
                "'" & UsId & "','" & Macid & "',to_date('" & AppDt & "','dd-mm-yyyy'), " & _
                "'" & InstrCode & "'"
                chqno = CDbl(chqno) + 1
                t = t + 1
           
   Next
End If
End If

'''' updating ,NOBOOKISSUED,status in stock(GENINSTRUMENTSTOCKDTLS table)
'''''when issue to department(inserting values into gendeptinstrstocktable)
StrQrytab = "GENINSTRUMENTSTOCKDTLS"
''' if the series is book
If LeafYesNo = "" Then
StrQryFlds = "NoOfBooks,nvl(NOBOOKISSUED,0),bookstartno,bookendno"
StrWhereCondition = "branchcode='" & BRCode & "' and INSTRCODE='" & InstrCode & "' and  BOOKSERIESNO='" & BookSeries & "' and LEAVESPERBOOK='" & LeavesperBk & "' and status<>'ISSUED' and transtatus='A' order by to_number(bookstartno)"
''' if the series is leaf
ElseIf BookYesNo = "" Then
StrQryFlds = "NOOFLEAVES,nvl(NOLEAFISSUED,0),LEAFSTARTNO,leafendno"
StrWhereCondition = "branchcode='" & BRCode & "' AND INSTRCODE='" & InstrCode & "' and   LeafSERIESNO='" & LeafSerNo & "' and status<>'ISSUED' and transtatus='A' order by to_number(Leafstartno)"
End If

Set RecGen = CreateObject("ADODB.Recordset")
''setting a recordset for fetching NoOfBooks,NOBOOKISSUED,bookstartno,bookendno
''' NOOFLEAVES,NOLEAFISSUED,LEAFSTARTNO,leafendno from
'''' GENINSTRUMENTSTOCKDTLS table
     Set RecGen = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                        StrWhereCondition)
     
     
If Not RecGen.EOF Then
   If LeafYesNo = "" Then
        RecGen.MoveFirst
        ''' if sending noofbooks >0
        Do While Val(NoOfbk) > 0
    ''' checking if nooofbooks in recordset <= noofbooksissued in recordset + sending noofbooks
    ''' update the noofbooksissued and issue status in stock(GENINSTRUMENTSTOCKDTLS)
        If RecGen(0) <= Val(RecGen(1) & "") + Val(NoOfbk) Then
            If IsNull(RecGen(1)) Or RecGen(1) = 0 Or RecGen(0) <= Val(RecGen(1) & "") + Val(NoOfbk) Then
                TotBook = Val(RecGen(0))
                tBook = Val(RecGen(0)) - Val(RecGen(1))
            Else
                TotBook = Val(RecGen(0)) - Val(RecGen(1))
                tBook = Val(RecGen(0)) - Val(RecGen(1))
            End If
                UpStatus = "'ISSUED'"
        ElseIf RecGen(0) > Val(NoOfbk) Then
            ''''TotBook = Val(RecGen(1) & "") + Val(NoOfbk)
            TotBook = Val(RecGen(1) & "") + Val(NoOfbk)
            tBook = Val(RecGen(1) & "") + Val(NoOfbk)
            UpStatus = "'ISSUABLE'"
        End If
         NoOfbk = Val(NoOfbk) - Val(tBook)
         StrUp = StrUp & "|" & TotBook & "~" & UpStatus & "~" & "'" & UsId & "'~'" & Macid & "'"
         StrWhere = StrWhere & "|" & "LEAVESPERBOOK='" & LeavesperBk & "' and BOOKSERIESNO='" & BookSeries & "' and " & RecGen(2).Name & " = " & RecGen(2) & " And " & RecGen(3).Name & " = " & RecGen(3)
         TotBook = 0
         RecGen.MoveNext
       Loop
       StrUpFlds = "NOBookISSUED,status,userid,machineid"
   ElseIf BookYesNo = "" Then
  
        Do While Val(NoOflf) > 0
       
        If RecGen(0) <= Val(RecGen(1) & "") + Val(NoOflf) Then
            If IsNull(RecGen(1)) Or RecGen(1) = 0 Or RecGen(0) <= Val(RecGen(1) & "") + Val(NoOflf) Then
                TotBook = Val(RecGen(0)) & ""
              tBook = Val(RecGen(0)) - Val(RecGen(1))
            Else
                TotBook = Val(RecGen(0) & "") - Val(RecGen(1) & "")
                tBook = Val(RecGen(0)) - Val(RecGen(1))
            End If
            UpStatus = "'ISSUED'"
        ElseIf RecGen(0) > Val(NoOflf) Then
            TotBook = Val(RecGen(1) & "") + Val(NoOflf)
            tBook = Val(RecGen(1) & "") + Val(NoOflf)
            UpStatus = "'ISSUABLE'"
        End If
         NoOflf = Val(NoOflf) - Val(tBook)
         StrUp = StrUp & "|" & TotBook & "~" & UpStatus & "~" & "'" & UsId & "'~'" & Macid & "'"
         StrWhere = StrWhere & "|" & " LEAFSERIESNO='" & LeafSerNo & "' and  " & RecGen(2).Name & " = " & RecGen(2) & " And " & RecGen(3).Name & " = " & RecGen(3)
         TotBook = 0
        RecGen.MoveNext
        Loop
        StrUpFlds = "NOLEAFISSUED,status,userid,machineid"
  End If
  Else
    CustInstruments = "No data found...to update in the GENINSTRUMENTSTOCKDTLS table"
    Exit Function
End If
    StrUp = Right(StrUp, Len(StrUp) - 1)
    Strupdate = Split(StrUp, "|")
    StrWhere = Right(StrWhere, Len(StrWhere) - 1)
    
Set RecGen = Nothing



     '''************calling the general insert update component for updating and inserting
     Set ObjContext = GetObjectContext
    Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    objStatus = "YES"
    '''' ''''********Transaction Started***************
    If InstrCode = "DD" Or InstrCode = "PO" Or InstrCode = "BC" Or InstrCode = "MT" Then
         TransResult = ObjTrans.InsertRecord(StrInTabName, StrInFldNames, StrInFldValues)
          If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
          
    End If
    
    TransResult = ObjTrans.InsertRecord(TableNm, StrFlds, StrInsValues)
    If TransResult = "Trans Completed" Then
        TransResult = ObjTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", StrUpFlds, Strupdate, StrWhere)
    End If
    
 If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
ObjContext.SetComplete
Set ObjTrans = Nothing
Set ObjFetchRec = Nothing
CustInstruments = "Transaction Sucessful."
Exit Function
ErrHand:
If objStatus = "YES" Then
    ObjContext.SetAbort
End If
Set ObjTrans = Nothing
Set ObjContext = Nothing
Set ObjFetchRec = Nothing
If Trim(TransResult) <> "" Then
'*************Connection Failed************
    CustInstruments = TransResult
    CustInstruments = Replace(CustInstruments, Chr(10), "")
    CustInstruments = Replace(CustInstruments, Chr(13), "")
 Else
    CustInstruments = Err.Number & " : " & Err.Description
    CustInstruments = Replace(CustInstruments, Chr(10), "")
    CustInstruments = Replace(CustInstruments, Chr(13), "")
 End If

End Function







