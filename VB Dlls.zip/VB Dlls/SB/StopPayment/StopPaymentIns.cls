VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "StopPaymentIns"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim ObjContext As ObjectContext
Dim ObjTrans As Object
Dim ObjFetchRec As Object
'Dim ObjTrans As New TransactionMethods
'Dim ObjFetchRec As New FetchRecordsets
Dim RecCust As Recordset

Public Function StopPayInsert(BranchCode As String, CurrencyCode As String, _
         Moduleid As String, GlCode As String, Accno As String, _
          BookYesNo As String, SeriesNo As String, StartNo As String, _
         EndNo As String, StopNo As String, StopCustRefNo As String, StopDate As String, StopEffDate As String, _
         Stopreason As String, StopusrId As String, StopMachId As String, Status As String, StopStatus As String) As String
         
         
    Dim TableNm As String
    Dim CurCode As String
    Dim BrCode As String
    Dim ModuleCode As String
    Dim GlId As String
    Dim AccntNo As String
    Dim BookYN As String
    Dim SerNo As String
    Dim StNo As String
    Dim Eno As String
    Dim UStno As String
    Dim UEdNo As String
    Dim LeafperBk As String
    Dim NoBl As String
    'Dim ChqStNo
    'Dim ChqEdNo
     Dim StGl As String
    
    Dim StpNo As String
    Dim StCustRefNo As String
    Dim StopDt As String
    Dim StopEffDt As String
    Dim StReason As String
    Dim StUsr As String
    Dim StMach As String
    Dim Sts As String
    Dim StStatus As String
    Dim UpStatus As String
    Dim StrQrytab As String
    Dim StrQryFlds As String
    Dim StrQryCondition As String
    Dim StrQryOrder As String
    Dim StrInsTabName As String
    Dim StrInsFldNames As String
    Dim StrInsValues(0) As Variant
    Dim UpStrTabName As String
    Dim StrUpFlds As String
    Dim StrUpValues() As Variant
    Dim StrUpCondition As String
    Dim ObjStatus As String
    Dim DeptUpStrTabName As String
    Dim DeptStrUpFlds As String
    Dim DeptStrUpValues() As Variant
    Dim DeptStrUpCondition As String
    
    Dim TransResult As String
    Dim Icount As Integer
    Dim InsStatus As String
    Dim n As Integer
    Dim j As Integer
    Dim BkNo As Long
    Dim FreeBooks As Long
    On Error GoTo ErrHand

    '''******* Assiging the Arguments to the variables *********
    CurCode = UCase(Trim(CurrencyCode))
    BrCode = UCase(Trim(BranchCode))
    
    ModuleCode = UCase(Trim(Moduleid))
    GlId = UCase(Trim(GlCode))
    AccntNo = UCase(Trim(Accno))
    BookYN = UCase(Trim(BookYesNo))
    SerNo = UCase(Trim(SeriesNo))
    StNo = UCase(Trim(StartNo))
    Eno = UCase(Trim(EndNo))
    'LeafperBk = Trim(leafperbook)
    InsStatus = "P"
    UStno = UCase(Trim(StartNo))
    UEdNo = UCase(Trim(EndNo))
    StpNo = UCase(Trim(StopNo))
    StCustRefNo = UCase(Trim(StopCustRefNo))
    StopDt = Format(StopDate, "dd/mm/yyyy")
    StopEffDt = Format(StopEffDate, "dd/mm/yyyy")
    StReason = UCase(Trim(Stopreason))
    StUsr = UCase(Trim(StopusrId))
    StMach = UCase(Trim(StopMachId))
    Sts = UCase(Trim(Status))
    StStatus = UCase(Trim(StopStatus))



    '''------------------------inserting into genstoppaymst table--------------------------

    StrInsTabName = "genstoppaymst"
    StrInsFldNames = "branchcode,CURRENCYCODE,MODULEID,GLCODE,ACCNO,BOOKLEAF,CHQSERIESNO,FROMCHQNO," & _
            "TOCHQNO,STOPNO,STOPCUSTREFNO,STOPDATE,STOPEFFECTDATE,STOPREASON," & _
            "STOPUSERID,STOPMACHINEID,STATUS,STOPSTATUS"
 
'    StrInsValues(0) = "'" & BrCode & "','" & CurCode & "','" & ModuleCode & "','" & GlCode & "'," & _
'    "" & AccntNo & ",'" & BookYN & "','" & SerNo & "','" & StNo & "','" & Eno & "','" & StpNo & "'," & _
'    "'" & StCustRefNo & "',to_date('" & StopDt & "','dd-mm-yyyy'),to_date('" & StopEffDt & "','dd-mm-yyyy')," & _
'    "'" & StReason & "','" & StUsr & "','" & StMach & "','" & Sts & "','" & StStatus & "'"

    StrInsValues(0) = "'" & BrCode & "','" & CurCode & "','" & ModuleCode & "','" & GlCode & "'," & _
    "" & AccntNo & ",'" & BookYN & "',null,'" & StNo & "','" & Eno & "','" & StpNo & "'," & _
    "'" & StCustRefNo & "',to_date('" & StopDt & "','dd-mm-yyyy'),to_date('" & StopEffDt & "','dd-mm-yyyy')," & _
    "'" & StReason & "','" & StUsr & "','" & StMach & "','" & Sts & "','" & StStatus & "'"



    ''----------------------------------------------------------------------------------------

    ''------------Update in GenChequeDtls table-----------------------------------
    NoBl = Val(Eno) - Val(StNo)
    If NoBl = 0 Then
    NoBl = 0
    End If
    Dim k As Integer
    UpStatus = "P"
    UpStrTabName = "genchequedtls"
    StrUpFlds = "stopstatus,userid,machineid,systemdate"
    ReDim StrUpValues(NoBl)

    '''------------------For Books
    If BookYN = "B" Then
        For k = 0 To Val(NoBl)
        
            StrUpValues(k) = "'" & UpStatus & "'~'" & StUsr & "'~'" & StMach & "'~sysdate"
               
'            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and currencycode='" & CurCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
'                        "CHEQUENO='" & StNo & "'  and CHQSERIESNO='" & SerNo & "'" & "|"
               
            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and currencycode='" & CurCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
                        "CHEQUENO='" & StNo & "' " & "|"
            StNo = Val(StNo) + 1
        Next
 
        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
        ''''----------------------For Leaves
    ElseIf BookYN = "L" Then
        For k = 0 To Val(NoBl)
            StrUpValues(k) = "'" & UpStatus & "'~'" & StUsr & "'~'" & StMach & "'~sysdate"
            
'            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                "upper(trim(moduleid))='" & ModuleCode & "' and currencycode='" & CurCode & "' and " & _
'                "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
'                "CHEQUENO='" & StNo & "'  and " & _
'                "CHQSERIESNO='" & SerNo & "'" & "|"

            StrUpCondition = StrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(moduleid))='" & ModuleCode & "' and currencycode='" & CurCode & "' and " & _
                "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
                "CHEQUENO='" & StNo & "' " & "|"

            StNo = Val(StNo) + 1
        Next
        StrUpCondition = Left(StrUpCondition, Len(StrUpCondition) - 1)
    End If
    '''----------------------------------------------------------------------

    ''--------------Querying for date in genbankparm table

    StrQrytab = "genchequedtls a,genbankparm p"
    StrQryFlds = " count(*)"
    
    'Code altered by Radhika on 06-sep-2007
    'Reason: Don't consider series number.
    If BookYN = "L" Then
        'StrQryCondition = "a.applicationdate > p.yearstartdt and upper(trim(accno))='" & AccntNo & "' and upper(trim(branchcode))='" & BrCode & "' and upper(trim(moduleid))='" & ModuleCode & "' and upper(trim(CHQSERIESNO))='" & SerNo & "' and upper(trim(bookleaf))='L' and (to_number(chequeno) >= '" & UStno & "' and to_number(chequeno) <= '" & UEdNo & "')"
        StrQryCondition = "a.applicationdate > p.yearstartdt and upper(trim(accno))='" & AccntNo & "' and upper(trim(branchcode))='" & BrCode & "' and upper(trim(moduleid))='" & ModuleCode & "' and upper(trim(bookleaf))='L' and (to_number(chequeno) >= '" & UStno & "' and to_number(chequeno) <= '" & UEdNo & "')"
    ElseIf BookYN = "B" Then
        'StrQryCondition = "a.applicationdate > p.yearstartdt and upper(trim(accno))='" & AccntNo & "' and upper(trim(branchcode))='" & BrCode & "' and upper(trim(moduleid))='" & ModuleCode & "' and upper(trim(CHQSERIESNO))='" & SerNo & "' and upper(trim(bookleaf))='B' and (to_number(chequeno) >= '" & UStno & "' and to_number(chequeno) <= '" & UEdNo & "')"
        StrQryCondition = "a.applicationdate > p.yearstartdt and upper(trim(accno))='" & AccntNo & "' and upper(trim(branchcode))='" & BrCode & "' and upper(trim(moduleid))='" & ModuleCode & "' and upper(trim(bookleaf))='B' and (to_number(chequeno) >= '" & UStno & "' and to_number(chequeno) <= '" & UEdNo & "')"
    End If
    Set RecCust = CreateObject("ADODB.Recordset")
    Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
 
    Set RecCust = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                        StrQryCondition, StrQryOrder)
    If Not RecCust.EOF Then
        BkNo = RecCust(0)
    Else
        StopPayInsert = "no data found in  Gencheqdtls which is greaterthan yearStartdate of genBankParm table "
        StopPayInsert = Replace(StopPayInsert, Chr(10), "")
        StopPayInsert = Replace(StopPayInsert, Chr(13), "")
        Exit Function
    End If
  
    Set RecCust = Nothing
    Set RecCust = CreateObject("ADODB.Recordset")
    StrQrytab = ""
    StrQryFlds = ""
    StrQryCondition = ""
    StrQrytab = "GENCHARGESMST"
    StrQryFlds = "STOPPAYCHARGESEXEMPT,STOPPAYCHARGES,STOPPAYGLCODE"
    ''''"upper(trim(branchcode))='" & BrCode & "' and "
    StrQryCondition = "upper(trim(moduleid))='" & ModuleCode & "' and  upper(trim(STOPPAYFREQ))='SPOT'"
    Dim bkcharges As String
    Dim m As Long
    '-----using querycomponent for querying  charges for chequebook in GenChargespmt table
    
    Set ObjContext = GetObjectContext
    Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    ObjStatus = "YES"
    
    Set RecCust = ObjFetchRec.SingleRecordSet(StrQrytab, StrQryFlds, _
                                           StrQryCondition, StrQryOrder)
    If Not RecCust.EOF And Not RecCust.BOF Then
        FreeBooks = RecCust(0)
        bkcharges = RecCust(1)
        StGl = RecCust(2) & ""
    
   
   
        Set RecCust = Nothing
        Set ObjFetchRec = Nothing
 
        '''************calling the general insert update component for updating and inserting
  
'        Set ObjContext = GetObjectContext
'        Set ObjTrans = ObjContext.CreateInstance("DataBaseTransactions.TransactionMethods")
'        ObjStatus = "YES"
        DeptUpStrTabName = "genchequedtls"
        DeptStrUpFlds = "CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE,userid,machineid,systemdate"

        If Val(BkNo) > Val(FreeBooks) Then
            ReDim DeptStrUpValues(BkNo)
            For m = 0 To FreeBooks - 1
                DeptStrUpValues(m) = "'F'~''~to_date('" & StopDt & "','dd-mm-yyyy')~" & _
                "'" & StUsr & "'~'" & StMach & "'~sysdate"
                If BookYN = "L" Then
'                   DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"
                 
                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"
                 
                 ElseIf BookYN = "B" Then
'                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"
                
                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"
                    
                    UStno = Val(UStno) + 1
               End If
            Next
            For m = Val(FreeBooks) To Val(BkNo)
                DeptStrUpValues(m) = "'Y'~'" & bkcharges & "'~to_date('" & StopDt & "','dd-mm-yyyy')~" & _
                "'" & StUsr & "'~'" & StMach & "'~sysdate"
                
                 If BookYN = "L" Then
'                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"
                 
                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"
                 
                 ElseIf BookYN = "B" Then
                 
'                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"
                        
                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"
                        
                UStno = Val(UStno) + 1
              End If
            Next
    
        ElseIf Val(BkNo) <= Val(FreeBooks) Then
            ReDim DeptStrUpValues(BkNo - 1)
            For m = 0 To Val(BkNo) - 1
                DeptStrUpValues(m) = "'F'~''~to_date('" & StopDt & "','dd-mm-yyyy')~" & _
                    "'" & StUsr & "'~'" & StMach & "'~sysdate"
        
                If BookYN = "L" Then
'                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"

                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='L' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"

                ElseIf BookYN = "B" Then
'                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
'                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
'                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
'                        "CHEQUENO='" & UStno & "'  and " & _
'                        "CHQSERIESNO='" & SerNo & "'" & "|"

                    DeptStrUpCondition = DeptStrUpCondition & "upper(trim(branchcode))='" & BrCode & "' and " & _
                        "upper(trim(moduleid))='" & ModuleCode & "' and " & _
                        "accno='" & AccntNo & "' and upper(trim(bookleaf))='B' and " & _
                        "CHEQUENO='" & UStno & "' " & "|"

                    UStno = Val(UStno) + 1
                End If
            Next
            DeptStrUpCondition = Left(DeptStrUpCondition, Len(DeptStrUpCondition) - 1)
        End If

        ''''-------------------------calling update method from General transactions component

        TransResult = ObjTrans.UpdateRecord(DeptUpStrTabName, DeptStrUpFlds, DeptStrUpValues, DeptStrUpCondition)

   End If

    '''----------------------------------
   
    
    '''' ''''********Transaction Started***************
    TransResult = ObjTrans.InsertRecord(StrInsTabName, StrInsFldNames, StrInsValues)
    TransResult = ObjTrans.UpdateRecord(UpStrTabName, StrUpFlds, StrUpValues, StrUpCondition)
            
    If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
    
    ObjContext.SetComplete
    Set ObjTrans = Nothing
    StopPayInsert = "Transaction Sucessful" & "*" & FreeBooks & "*" & StGl
    
    Exit Function
    
ErrHand:
    If ObjStatus = "YES" Then
        ObjContext.SetAbort
    End If

    Set ObjTrans = Nothing
    Set ObjContext = Nothing

    If Trim(TransResult) <> "" Then
        '*************Connection Failed************
        StopPayInsert = TransResult
        StopPayInsert = Replace(StopPayInsert, Chr(10), "")
        StopPayInsert = Replace(StopPayInsert, Chr(13), "")
     Else
        StopPayInsert = Err.Number & " : " & Err.Description
        StopPayInsert = Replace(StopPayInsert, Chr(10), "")
        StopPayInsert = Replace(StopPayInsert, Chr(13), "")
     End If

End Function

