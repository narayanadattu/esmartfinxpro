VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "dept1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Dim StrTabName As String
Dim StrFlds As String
Dim StrWhere As String
Dim objStockFetch As Object
Dim objInstrTrans As Object
'Dim objStockFetch As New FetchRecordsets
'Dim objInstrTrans As New TransactionMethods
Dim obj As Object
Dim objContext As ObjectContext
Dim Result As String
Dim StrValues(0) As Variant
Dim dbconnection As New ADODB.Connection
'Dim recBookDtls  As New Recordset
'Dim recUpdate As New Recordset
Dim recBookDtls  As Recordset
Dim recUpdate As Recordset
Dim comalteruser As New ADODB.Command

Public Function DeptInstrCancel(BranchCode As String, Moduleid As String, InstrCode As String, _
                                BookSeriesNo As String, NoOfLeavesPerBook As String, NoOfBooks As String)
                                
Dim strBranchCode As String
Dim strModuleid As String
Dim strInstrCode As String
Dim strBookSeriesNo As String
Dim strNoOfLeavesPerBook As String
Dim strNoOfBooks As String
Dim total(0)
Dim arrval(0)
    strBranchCode = BranchCode
    strModuleid = Moduleid
    strInstrCode = InstrCode
    strBookSeriesNo = BookSeriesNo
    strNoOfLeavesPerBook = NoOfLeavesPerBook
    strOfBooks = NoOfBooks
    
    Set objContext = GetObjectContext
    Set objUserTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    Set objStockFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    
    
    
    
    StrTabName = "GENDEPTCUSTINSTRSTOCKDTLS"
    StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and MODULEID='" & strModuleid & "' and instrcode='" & strInstrCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and status='ISSUABLE' and transstatus='P' and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook
                
    StrFlds = "count(nvl(bookendno,0))"
      
    Set recBookDtls = objStockFetch.SingleRecordSet(StrTabName, StrFlds, StrWhere)
    total(0) = Val(recBookDtls(0))
    StrTabName = "GENINSTRUMENTSTOCKDTLS"
    StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                "and status<>'STOCK'  and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook & "  order by status desc"
    StrFlds = "nobookissued,status"
     
    Set recUpdate = objStockFetch.SingleRecordSet(StrTabName, StrFlds, StrWhere)
    
    If Not recBookDtls.EOF And Not recBookDtls.BOF And Not recUpdate.EOF And Not recUpdate.BOF Then
        Do While Not recUpdate.EOF
            
            If recUpdate(1) = "ISSUED" Then
                StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                "and status='ISSUED'  and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook
                arrval(0) = "0"
                Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "nobookissued", arrval, StrWhere)
                total(0) = total(0) - recUpdate(0)
            End If
            If recUpdate(1) = "ISSUABLE" Then
                StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                "and status='ISSUABLE'  and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook
                If total(0) > recUpdate(0) Then
                    total(0) = total(0) - recUpdate(0)
                Else
                    total(0) = "0"
                End If
                Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "nobookissued", total, StrWhere)
                    
            End If
        
           
            recUpdate.MoveNext
        Loop
            If Result = "Trans Completed" Then
                objContext.setcomplete
            Else
                objContext.setabort
            End If
    End If
       
DeptInstrCancel = "Transaction Completed..."
End Function
