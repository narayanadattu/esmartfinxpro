VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "DeptCancel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
 Dim StrTabName As String
Dim StrFlds As String
Dim StrWhere As String
Dim objStockFetch As Object
Dim objInstrTrans As Object
Dim obj As Object
Dim objContext As ObjectContext
Dim Result As String
Dim StrValues(0) As Variant
Dim recBookDtls  As Recordset
Dim recUpdate As Recordset

Public Function DeptInstrCancel(BranchCode As String, Moduleid As String, InstrCode As String, _
                                BookSeriesNo As String, NoOfLeavesPerBook As String, NoOfBooks As String, _
                                BookStartNo As String, BookEndNo As String, BookYesNo As String, UsrId As String)
                                
Dim strBranchCode As String
Dim strModuleid As String
Dim strInstrCode As String
Dim strBookSeriesNo As String
Dim strNoOfLeavesPerBook As String
Dim strNoOfBooks As String
Dim strBookStartNo As String
Dim strBookEndNo As String
Dim strBookYesNo As String
Dim strUserid As String
Dim total(0)
Dim arrval(0)
    
    strBranchCode = BranchCode
    strModuleid = Moduleid
    strInstrCode = InstrCode
    strBookSeriesNo = BookSeriesNo
    strNoOfLeavesPerBook = NoOfLeavesPerBook
    strOfBooks = NoOfBooks
    strBookStartNo = BookStartNo
    strBookEndNo = BookEndNo
    strBookYesNo = BookYesNo
    strUserid = UsrId
    Set objContext = GetObjectContext
    Set objStockFetch = CreateObject("QueryRecordsets.FetchRecordsets")
    Set objInstrTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    
    
    
    
    
    StrTabName = "GENDEPTCUSTINSTRSTOCKDTLS"
    
    If strBookYesNo = "Y" Then
        StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and MODULEID='" & strModuleid & "' and instrcode='" & strInstrCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and status='ISSUABLE' " & _
                " and to_number(BOOKSTARTNO)>=" & strBookStartNo & " and to_number(BOOKENDNO)<=" & strBookEndNo & " " & _
                "and issuedto='" & strUserid & "' and transstatus='P' and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook
                StrFlds = "count(nvl(bookendno,0))"
    Else
        StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and MODULEID='" & strModuleid & "' and instrcode='" & strInstrCode & "'" & _
                " and   LEAFSERIESNO='" & strBookSeriesNo & _
                "' and to_number(LEAFNUMBER)>=" & strBookStartNo & " and to_number(LEAFNUMBER)<=" & strBookEndNo & " " & _
                " and issuedto='" & strUserid & "' " & _
                " and status='ISSUABLE' and transstatus='P' "
                StrFlds = "count(nvl(leafnumber,0))"
    End If
                
    
      
    Set recBookDtls = objStockFetch.SingleRecordSet(StrTabName, StrFlds, StrWhere)
    total(0) = Val(recBookDtls(0))
    StrTabName = "GENINSTRUMENTSTOCKDTLS"
    If strBookYesNo = "Y" Then
        StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                "and status<>'STOCK'  and LEAVESPERBOOK=" & _
                strNoOfLeavesPerBook & "  order by status desc"
        StrFlds = "nobookissued,status"
    Else
        StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                " and   LEAFSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                "and status<>'STOCK' order by status desc"
        StrFlds = "noleafissued,status"
    End If
    Set recUpdate = objStockFetch.SingleRecordSet(StrTabName, StrFlds, StrWhere)
    
    If Not recBookDtls.EOF And Not recBookDtls.BOF And Not recUpdate.EOF And Not recUpdate.BOF Then
        Do While Not recUpdate.EOF
            If total(0) = 0 Then Exit Do
            If recUpdate(1) = "ISSUED" Then
                If strBookYesNo = "Y" Then
                     StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                        " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                        "and status='ISSUED' and LEAVESPERBOOK=" & _
                        strNoOfLeavesPerBook
                    arrval(0) = "0~'ISSUABLE'"
                    Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "nobookissued,status", arrval, StrWhere)
                Else
                    StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                        " and  LEAFSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                        "and status='ISSUED' "
                    arrval(0) = "0~'ISSUABLE'"
                    Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "noleafissued,status", arrval, StrWhere)
                End If
                total(0) = total(0) - recUpdate(0)
            End If
            If recUpdate(1) = "ISSUABLE" Then
                If strBookYesNo = "Y" Then
                    StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                        " and   BOOKSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                        "and status='ISSUABLE' and nvl(transtatus,'l')<>'P' and LEAVESPERBOOK=" & _
                        strNoOfLeavesPerBook
                        total(0) = Abs(total(0) - recUpdate(0))
                        Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "nobookissued", total, StrWhere)
                Else
                  StrWhere = "BRANCHCODE='" & strBranchCode & "'" & _
                        " and   LEAFSERIESNO='" & strBookSeriesNo & "' and instrcode='" & strInstrCode & "'" & _
                        "and status='ISSUABLE' and nvl(transtatus,'l')<>'P' "
                         total(0) = Abs(total(0) - recUpdate(0))
                        Result = objInstrTrans.UpdateRecord("GENINSTRUMENTSTOCKDTLS", "noleafissued", total, StrWhere)
                
                End If
            End If
            recUpdate.MoveNext
        Loop
                  
            If Result = "Trans Completed" Then
                If strBookYesNo = "Y" Then
                    Result = objInstrTrans.DeleteRecord("GENDEPTCUSTINSTRSTOCKDTLS", "to_number(Bookendno)>" & CLng(strBookStartNo) & " and to_number(BookStartno)<" & CLng(strBookEndNo))
                Else
                    Result = objInstrTrans.DeleteRecord("GENDEPTCUSTINSTRSTOCKDTLS", "to_number(leafnumber) between " & CLng(strBookStartNo) & " and " & CLng(strBookEndNo))
                End If
                
                If Result = "Trans Completed" Then
                  objContext.SetComplete
                Else
                  objContext.SetAbort
                  GoTo Myerr
                End If
            Else
                 objContext.SetAbort
                 GoTo Myerr
            End If
    End If
       
DeptInstrCancel = "Transaction Completed..."

Myerr:
DeptInstrCancel = Result
DeptInstrCancel = Replace(DeptInstrCancel, Chr(10), "")
DeptInstrCancel = Replace(DeptInstrCancel, Chr(13), "")
End Function
