VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "SBInterestcal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Public ConnError As String 'error object
Dim ICount As Integer
'Dim objContext As ObjectContext
Dim ObjTrans As New DBTransactions
Dim objquery As New FetchRecordsets
Dim strInsDel As String
Dim strRec As String
Dim ArrTrans(0, 4) As Variant



Public Function SBFinalInterest(BRCode As String, CurrencyCode As String, Moduleid As String, _
                            MonthlyMinBalanceDay As String, GLcode As String, _
                            FromDate As String, ToDate As String, _
                            Optional Accno As String) As String
                            
    
    
Dim strMonthlyMinBalanceDay As String, strGLCode As String
Dim strAccno As String, strBranchCode As String
Dim strcurrencycode As String, strfromdate As String, month As Integer
Dim strtodate As String, strmoduleid As String
Dim strdatediff As Integer
Dim rsSBmst As New ADODB.Recordset
Dim rsMinBalbet10and30 As New ADODB.Recordset
Dim rsMinbalon10th As New ADODB.Recordset
Dim rsBalBefore1st As New ADODB.Recordset
Dim rsReportID As New ADODB.Recordset
Dim Rslastdate As ADODB.Recordset
Dim rsIntrate As ADODB.Recordset
Dim rsIntvalues As ADODB.Recordset
Dim intmonth As Double
Dim intamt As Double
Dim intyear As Double
Dim LASTDATE As String
Dim dblsbcount As Double
Dim strAccCon As String
Dim strCutoffDate As String
Dim strlastDate As String
Dim strIntTab As String, strIntFld As String
Dim strmonthdiff As Double
Dim strIntVal As String
Dim j As Double
Dim I As Double
Dim strMonfirstDate As String
On Error GoTo ErrHand


Dim curBalafter10th As Currency 'stores min bal of the account between 10th and 30th
Dim curBalon10th As Currency 'stores balance as on 10th for the account
Dim curMinBal As Currency 'Stores the Minimum balance for the account for the
                                      'the month
strMonthlyMinBalanceDay = Trim(MonthlyMinBalanceDay)
strGLCode = Trim(UCase(GLcode))
strmoduleid = Trim(UCase(Moduleid))
strBranchCode = Trim(UCase(BRCode))
strAccno = Trim(Accno)
strcurrencycode = Trim(UCase(CurrencyCode))
strfromdate = Format(FromDate, "dd-MMM-yyyy")
strtodate = Format(ToDate, "dd-MMM-yyyy")
strmonthdiff = DateDiff("M", strfromdate, strtodate)

    'Set objContext = GetObjectContext
    'Set objTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    'Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
 
    'Set ObjTrans = CreateObject("GeneralTransactions.DBTransactions")
    Dim objquery As New FetchRecordsets
    
strCutoffDate = FromDate
'get all the running accounts for a given gl or a entered single account
If strAccno <> "" Then
    strAccCon = " and accno='" & strAccno & "'"
Else
    strAccCon = ""
End If

    Set rsReportID = objquery.SingleRecordSet("GENINTERESTTEMP", "nvl(max(REPORTID),0)")
                If objquery.ConnError <> "Connected" Then
                    SBFinalInterest = objquery.ConnError
                    Exit Function
                End If
    Set rsIntvalues = objquery.SingleRecordSet("SBTRAN A", "APPLICATIONDATE,GLCODE,ACCNO,nvl(SUM(DAYENDBAL),0)", "TRANNO=(SELECT MAX(TRANNO) FROM " & _
        "SBTRAN WHERE BRANCHCODE=A.BRANCHCODE AND GLCODE=A.GLCODE AND " & _
        "ACCNO=A.ACCNO AND APPLICATIONDATE=A.APPLICATIONDATE and currencycode=a.currencycode) AND " & _
        "BRANCHCODE='" & strBranchCode & "' AND GLCODE='" & strGLCode & "' and " & _
        "currencycode='" & strcurrencycode & "'GROUP BY APPLICATIONDATE,GLCODE,ACCNO " & _
        "ORDER BY APPLICATIONDATE,GLCODE,ACCNO")
    
                If objquery.ConnError <> "Connected" Then
                    SBFinalInterest = objquery.ConnError
                    Exit Function
                End If
                
    Dim strInttempTab As String, strInttempFld As String
            Dim strInttempVal As String
            If Not rsIntvalues.EOF And Not rsIntvalues.BOF Then
                For j = 0 To (rsIntvalues.RecordCount) - 1
                    strInttempTab = "GENINTERESTTEMP"
                    strInttempFld = "branchcode,currencycode,moduleid,glcode,accno,AMOUNT,BALDATE,REPORTID"
                    strInttempVal = strInttempVal & "'" & strBranchCode & "','" & strcurrencycode & "','" & strmoduleid & "','" & strGLCode & "','" & rsIntvalues(2) & "','" & rsIntvalues(3) & "','" & Format(rsIntvalues(0), "dd-mmm-yyyy") & "','" & CInt(rsReportID(0)) + 1 & "'|"
                    'strInsDel = objTrans.InsertRecord(strInttempTab, strInttempFld, strInttempVal)
                    rsIntvalues.MoveNext
                Next
                
                strInttempVal = Left(strInttempVal, CDbl(Len(strInttempVal) - 1))
            ArrTrans(0, 0) = "I"
            ArrTrans(0, 1) = strInttempTab
            ArrTrans(0, 2) = strInttempFld
            ArrTrans(0, 3) = strInttempVal
            ArrTrans(0, 4) = ""
             strstr = ObjTrans.DataTransactions(ArrTrans)
                If strstr <> "Transaction Sucessful." Then
                   GoTo ErrHand
                End If
            Else
                    GoTo ErrHand
                    Exit Function
            End If
            
               'If strInsDel <> "Trans Completed" Then
                  'GoTo errhand
               'End If
    Set rsSBmst = objquery.SingleRecordSet("SBMST", "accno,name", "branchcode='" & strBranchCode & "'and glcode='" & strGLCode & "'and status='R' and transtatus='A'" & strAccCon)
            If objquery.ConnError <> "Connected" Then
                SBFinalInterest = objquery.ConnError
                Exit Function
            End If
    'loop through each month between from and to dates selected
    For I = 0 To CInt(strmonthdiff) - 1
    
        strCutoffDate = MonthlyMinBalanceDay & Format(strCutoffDate, "-MMM-YYYY")
        strMonfirstDate = "01" & Format(strCutoffDate, "-MMM-YYYY")
        intmonth = Format(strCutoffDate, "mm")
        intyear = Format(strCutoffDate, "yyyy")
        
        'get Minimum balances of each account between 10th and last day of the month
        
        Set rsMinBalbet10and30 = objquery.SingleRecordSet("GENINTERESTTEMP", _
                        "nvl(min(nvl(amount,0)),0) curbalance , accno ", _
                        "BALDATE > to_date('" & strCutoffDate & "')" & _
                        "AND BALDATE<= last_day(to_date('" & strCutoffDate & "')) " & _
                        " and branchcode='" & strBranchCode & "' and " & _
                        "glcode='" & strGLCode & "'  and currencycode='" & _
                        strcurrencycode & "' and REPORTID='" & _
                        CInt(rsReportID(0)) + 1 & "'" & strAccCon & " group by accno ")
                     If objquery.ConnError <> "Connected" Then
                        SBFinalInterest = objquery.ConnError
                        Exit Function
                    End If
                        
                        
        'get balance as on 10th for all the accounts
        Set rsMinbalon10th = objquery.SingleRecordSet("GENINTERESTTEMP", _
                    "min(nvl(amount,0)),accno ", _
                    "BALDATE <=to_date('" & strCutoffDate & "') and BALDATE>=to_date('" & _
                    strMonfirstDate & "') and branchcode='" & strBranchCode & "' and " & _
                    " glcode='" & strGLCode & "' and REPORTID='" & CInt(rsReportID(0)) + 1 & _
                    " ' and currencycode='" & strcurrencycode & "'" & _
                    strAccCon & " group by accno ")
      
                        If objquery.ConnError <> "Connected" Then
                            SBFinalInterest = objquery.ConnError
                            Exit Function
                        End If
        
        rsSBmst.MoveFirst
        'get the minimum balacne for each account and insert into sbmonintprod table for each
        'month
        If Not rsSBmst.EOF And Not rsSBmst.BOF Then
            
           Do While Not rsSBmst.EOF
            curBalafter10th = 0
            curBalon10th = 0
            curMinBal = 0
            intamt = 0
            
            
        
            If Not rsMinBalbet10and30.EOF And Not rsMinBalbet10and30.BOF Then
            'store min balance(between 10th and 30th) for the account for the month
                rsMinBalbet10and30.MoveFirst
                Do While Not rsMinBalbet10and30.EOF
                    If rsMinBalbet10and30(1) = rsSBmst!Accno Then
                        curBalafter10th = rsMinBalbet10and30!curbalance
                        
                    End If
                    rsMinBalbet10and30.MoveNext
                Loop
                rsMinBalbet10and30.MoveFirst
            Else
                curBalafter10th = 0
            End If
            
            'store balance of the account as on 10th of the month
            
            If Not rsMinbalon10th.EOF And Not rsMinbalon10th.BOF Then
                rsMinbalon10th.MoveFirst
                
                Do While Not rsMinbalon10th.EOF
                    If rsMinbalon10th(1) = rsSBmst!Accno Then
                        curBalon10th = rsMinbalon10th(0)
                        
                    End If
                    rsMinbalon10th.MoveNext
                Loop
                rsMinbalon10th.MoveFirst
                If curBalon10th = 0 Then
                Set rsBalBefore1st = objquery.SingleRecordSet("GENINTERESTTEMP", "min(nvl(amount,0))", "BALDATE=(select max(BALDATE) from GENINTERESTTEMP where " & _
                            " branchcode='" & strBranchCode & "' and BALDATE<=to_date('" & strMonfirstDate & "')" & _
                            " and glcode='" & strGLCode & "' and REPORTID='" & CInt(rsReportID(0)) + 1 & "' and currencycode='" & strcurrencycode & "' and accno='" & _
                            rsSBmst!Accno & "') and branchcode='" & strBranchCode & "'and " & _
                            "glcode='" & strGLCode & "' and REPORTID='" & CInt(rsReportID(0)) + 1 & "' and currencycode='" & strcurrencycode & "' " & _
                            " and accno='" & rsSBmst!Accno & "'")
                            
                            If objquery.ConnError <> "Connected" Then
                                SBFinalInterest = objquery.ConnError
                                Exit Function
                            End If
                    If Not rsBalBefore1st.EOF And Not rsBalBefore1st.BOF Then
                        curBalon10th = Val(Format(rsBalBefore1st(0)))
                        
                    Else
                        curBalon10th = 0
                    End If
                
                    
                End If
            Else
                curBalon10th = 0
            End If
            'store the Minbalance which ever is less
            

            If curBalafter10th < curBalon10th Then
                curMinBal = curBalafter10th
            Else
                curMinBal = curBalon10th
            End If
            
            
            Set Rslastdate = objquery.SingleRecordSet("DUAL", "LAST_DAY(TO_DATE('" & _
                    strCutoffDate & "','DD-Mon-yyyy'))")
                    
            strlastDate = Format(Rslastdate(0), "dd-MMM-yyyy")
                        If objquery.ConnError <> "Connected" Then
                                SBFinalInterest = objquery.ConnError
                                Exit Function
                            End If
            Set rsIntrate = objquery.SingleRecordSet("SBINTRATES", "INTRATE", "SYSTEMYEAR='" & intyear & "' AND MONTH='" & intmonth & "'and " & _
                    "currencycode='" & strcurrencycode & "' and glcode='" & strGLCode & "'")
                        If objquery.ConnError <> "Connected" Then
                                SBFinalInterest = objquery.ConnError
                                Exit Function
                            End If
            
            
            If curMinBal <= 0 Then
            curMinBal = 0
            End If
            
            
            intamt = Round((CDbl(curMinBal) * CDbl(rsIntrate(0)) / 100) / 365, 2)
            
            'If CDbl(intamt) > 0 Then
            strIntTab = "SBINTERESTTEMP"
            strIntFld = "branchcode,currencycode,moduleid,glcode,accno,name,curbal,fromdate,todate,intrate,intamt,REPORTID"
            strIntVal = strIntVal & "'" & strBranchCode & "','" & strcurrencycode & "','" & strmoduleid & "','" & strGLCode & "','" & rsSBmst(0) & "','" & rsSBmst(1) & "','" & curMinBal & "','" & strCutoffDate & "','" & strlastDate & "','" & rsIntrate(0) & "','" & intamt & "','" & CInt(rsReportID(0)) + 1 & "'|"
            'strInsDel = objTrans.InsertRecord(strIntTab, strIntFld, strIntVal)
            'End If
            
              ' If strInsDel <> "Trans Completed" Then
                  'GoTo errhand
              ' End If
            
            rsSBmst.MoveNext
          Loop
        End If
        strCutoffDate = DateAdd("M", 1, CDate(strCutoffDate))
  
  Next
        'If strIntVal <> "" Then
        strIntVal = Left(strIntVal, CDbl(Len(strIntVal) - 1))
            ArrTrans(0, 0) = "I"
            ArrTrans(0, 1) = strIntTab
            ArrTrans(0, 2) = strIntFld
            ArrTrans(0, 3) = strIntVal
            ArrTrans(0, 4) = ""
            strstr = ObjTrans.DataTransactions(ArrTrans)
       ' End If
                If strstr <> "Transaction Sucessful." Then
                   GoTo ErrHand
                End If
                'objContext.SetComplete
               SBFinalInterest = "SB Interest Calculation completed."
  
                Set ObjContext = Nothing
                Set objquery = Nothing
                Set ObjTrans = Nothing
                Exit Function
  
ErrHand:

      'objContext.SetAbort
   
            If objquery.ConnError <> "Connected" Then
               SBFinalInterest = objquery.ConnError
            End If
            
            Set ObjContext = Nothing
            Set objquery = Nothing
            Set ObjTrans = Nothing
     
            If Err.Number <> "0" Then
               SBFinalInterest = Err.Number & " : " & Err.Description
            'ElseIf strInsDel <> "Trans Completed" Then
               'SBFinalInterest = strInsDel
            End If
    
End Function


