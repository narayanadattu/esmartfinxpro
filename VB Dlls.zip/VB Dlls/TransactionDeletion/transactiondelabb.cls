VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "transactiondelabb"
Attribute VB_GlobalNameSpace = True
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'This Component is used to delete Transactions
Option Explicit
Dim objContext As ObjectContext
Dim ObjTrans As Object
Dim objQuery As Object
Dim strInsDel As String
Dim strRec As String
Dim strDelType As String
Dim StrClRentab As String
Dim StrClRenFlds As String
Dim StrClRenCond As String
Dim strUpd As String
'------------------------------------------------------------------------------------------
'Global Variables declaration
Dim BRCode, curcode, BatchNo, tranno, ModuleId, GlCode, AccNo, ServiceId, ModeOfTran, _
    SysGenYN, ExcpYN, ChqSrs, ChqNo, LinkModId, ApplDate, CashierId, CashAmt, _
    LinkGlCode, LinkAccNo, LinkAccType
    
Dim pstrabbbrcd As String

Dim StrTabName As String, strWhrCondTrn As String, strWhrCondMst As String, _
    strWhrCondGen As String, strWhrCondAdd As String, StrFldNames As String, _
    arrFldVal(0) As Variant, modOrDelText As String

Dim recTrnTab As ADODB.Recordset

Dim AccLastIntApplDt As String
Dim DepAccOpAmt As Double, DepAccMaturityAmt As Double
Dim ActivityId As String

Dim recTrnTab1 As ADODB.Recordset
Dim strwhrcondrempayrgty As String
Dim strwhrcndgntrnlg As String
'Array of Values Consisting of Batchno,TranNo...come as a parameter to this function
Public Function TranDeleteabb(arrgrid As Variant, modOrDel As String, strabbbrcd As String, _
Optional frmname As String, Optional Cashiercode As String, Optional userid As String, Optional machineid As String) As String

Dim recDel As ADODB.Recordset, recModTypes As ADODB.Recordset, recUpd As ADODB.Recordset, _
strCashPYN As String, strDel As String, strTrnsLog As String, _
strTrnTab As String, strMstTab As String, strTrnFld As String, strTrnWhCond As String, _
introws As Integer, strTnameMod As String, strFldMod As String, _
strWhCndMod As String, strFldTrn As String, arrFldVal(0) As Variant, strTrnsTab As String, _
strTransFld As String, arrTransVal(0) As Variant

Dim rsGen As ADODB.Recordset
Dim strWhrCondDispTemp As String, strWhrCondToDel As String
'--------------------------------------------------------------------------------------------

    On Error GoTo errhand

    If modOrDel = "MOD" Then
       modOrDelText = " Modified."
    ElseIf modOrDel = "DEL" Then
       modOrDelText = " Deleted."
       strDelType = "DEL"
    End If
    
    CashierId = Trim(UCase(Cashiercode))
    strTrnsTab = "GENTRANSLOG"
    
    strTransFld = "BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,MODULEID,batchno,TRANNO,GLCODE," & _
                  "ACCNO,NAME,CUSTOMERID,AMOUNT,TOKENNO,MODEOFTRAN,ENTEREDTIMEBAL,APPROVEDTIMEBAL," & _
                  "DAYENDBAL,TRANSTATUS,SERVICEID,REMARKS,CASHPAIDYN,CASHIERID,USERID," & _
                  "MACHINEID,APPROVEDBY,APPROVEDMACHINE,VERIFIEDBY," & _
                  "VERIFIEDMACHINE,SYSTEMDATE,CHQNO,CHQSERIESNO,CHQFVG,CHQDATE," & _
                  "SYSTEMGENERATEDYN,EFFECTIVEDATE,CLGRATETYPE,RATE,FCURRENCYCODE," & _
                  "FAMOUNT,LINKMODULEID,LINKGLCODE,LINKACCNO,LINKACCTYPE,EXCEPTIONYN," & _
                  "RESPONDINGBANKCODE,RATEREFCODE"
                  
 
    Set objContext = GetObjectContext
    Set ObjTrans = objContext.CreateInstance("DataBaseTransactions.TransactionMethods")
    pstrabbbrcd = strabbbrcd
    '-------------------------------------------
    For introws = 0 To UBound(arrgrid) - 1
    
        BRCode = Trim(arrgrid(introws, 0))
        curcode = Trim(arrgrid(introws, 1))
        BatchNo = Trim(arrgrid(introws, 2))
        tranno = Trim(arrgrid(introws, 3))
        ModuleId = Trim(arrgrid(introws, 4))
        GlCode = Trim(arrgrid(introws, 5))
        AccNo = Trim(arrgrid(introws, 7))
        ServiceId = Trim(arrgrid(introws, 10))
        ModeOfTran = Trim(arrgrid(introws, 12))
        SysGenYN = Trim(arrgrid(introws, 16))
        ExcpYN = Trim(arrgrid(introws, 17))
        ChqSrs = Trim(arrgrid(introws, 18))
        ChqNo = Trim(arrgrid(introws, 19))
        LinkModId = Trim(arrgrid(introws, 20))
        strCashPYN = Trim(arrgrid(introws, 23))
        ApplDate = Trim(arrgrid(introws, 24))
        CashAmt = Trim(arrgrid(introws, 9))
      
        'Get Required Data from GENTEMPTRANSLOG Table
        Set rsGen = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    
        Set rsGen = objQuery.SingleRecordSet("GENTRANSLOG", _
        "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE", _
        "(   ( trim(upper(branchcode))='" & UCase(BRCode) & "' AND nvl(abbyn,'N') = 'N') " & _
        " OR ( abbbranchcode='" & UCase(strabbbrcd) & "' AND nvl(abbyn,'N')='Y') ) " & _
        " and CURRENCYCODE='" & curcode & "' and " & _
        " GLCODE='" & GlCode & "' and ACCNO='" & AccNo & "' and " & _
        " BATCHNO='" & BatchNo & "' and TRANNO='" & tranno & "'")
        
        LinkModId = ""
        LinkGlCode = ""
        LinkAccNo = ""
        LinkAccType = ""
        
        If rsGen.EOF = False Then
            LinkModId = UCase(Trim(IIf(IsNull(rsGen!LINKMODULEID), "", rsGen!LINKMODULEID)))
            LinkGlCode = IIf(IsNull(rsGen!LinkGlCode), "", rsGen!LinkGlCode)
            LinkAccNo = IIf(IsNull(rsGen!LinkAccNo), "", rsGen!LinkAccNo)
            LinkAccType = IIf(IsNull(rsGen!LinkAccType), "", rsGen!LinkAccType)
        End If
        Set rsGen = Nothing
        
        
        Set rsGen = objQuery.SingleRecordSet("GENTEMPTRANSLOG", "C61,SERVICEID,c100,c88,c89", _
        "((trim(upper(branchcode))='" & UCase(BRCode) & "' AND nvl(abbyn,'N') = 'N') " & _
        " OR ( abbbranchcode='" & UCase(strabbbrcd) & "' AND nvl(abbyn,'N')='Y') ) " & _
        " and CURRENCYCODE='" & curcode & "' and " & _
        " GLCODE='" & GlCode & "' and ACCNO='" & AccNo & "' and " & _
        " BATCHNO='" & BatchNo & "' and TRANNO='" & tranno & "'")
        
        AccLastIntApplDt = ""
        DepAccOpAmt = 0
        DepAccMaturityAmt = 0
        ActivityId = ""
    
        If objQuery.ConnError = "Connected" Then
            If rsGen.EOF = False Then
                If IsNull(rsGen!C61) = False And Trim(rsGen!ServiceId) = "4" Then
                    'This is nothing but Last Int Appl Date
                    AccLastIntApplDt = Format(rsGen!C61, "dd-mmm-yyyy")
                End If
                If IsNull(rsGen!C100) = False And Trim(rsGen!ServiceId) = "4" Then
                    If UCase(Trim(rsGen!C100)) = "UDC" Then
                        'UDC = Unit Deposit Closing
                        DepAccOpAmt = IIf(IsNull(rsGen!c88), 0, rsGen!c88)
                        DepAccMaturityAmt = IIf(IsNull(rsGen!c89), 0, rsGen!c89)
                        ActivityId = UCase(Trim(rsGen!C100))
                    End If
                End If
                
                ActivityId = IIf(IsNull(rsGen!C100), "", rsGen!C100)
                ActivityId = UCase(Trim(ActivityId))
                
                If ActivityId = "PIC" Then
                'PIC = Pigmy Interest Calculation
                    If IsNull(rsGen!C61) = True Then
                        TranDeleteabb = "Pigmy Account Last Interest Calculation Date" & _
                        " not mentioned in Column C61"
                        objContext.SetAbort
                        Exit Function
                    Else
                        AccLastIntApplDt = Format(rsGen!C61, "dd-mmm-yyyy")
                    End If
                End If
            End If
        End If
        Set rsGen = Nothing
      
        'Where condition to delete data from disposalDtlsTemp table
        strWhrCondDispTemp = "trim(upper(branchcode))='" & UCase(BRCode) & _
                "' and trim(upper(currencycode))='" & UCase(curcode) & "' and " & _
                "trim(batchno)='" & CDbl(Trim(BatchNo)) & "' and trim(tranno)='" & _
                CDbl(Trim(tranno)) & "'"
      
        'Where Condition for Updating Rows based on BatchNo and TranNo
        strWhrCondTrn = "trim(upper(branchcode))='" & UCase(BRCode) & _
                "' and trim(upper(currencycode))='" & UCase(curcode) & "' and " & _
                "trim(batchno)='" & CDbl(Trim(BatchNo)) & "' and trim(tranno)='" & _
                CDbl(Trim(tranno)) & "'"

        'code added by Radhika on 22 may 2008
        'Reason: ABB Transactions deleteion not handled properly
        strWhrCondToDel = "" & _
            "(   ( trim(upper(branchcode))='" & UCase(BRCode) & "' AND nvl(abbyn,'N') ='N') " & _
            " OR ( abbbranchcode='" & UCase(strabbbrcd) & "' AND nvl(abbyn,'N')='Y') ) " & _
            " and trim(upper(currencycode))='" & UCase(curcode) & "' and " & _
            "trim(batchno)='" & CDbl(Trim(BatchNo)) & "' and trim(tranno)='" & _
            CDbl(Trim(tranno)) & "'"
        'end of code added by Radhika on 22 may 2008
    
        'Where Condition for Deleting Rows based on ModuleId,GLCode,AccNo
        strWhrCondMst = "upper(branchcode)='" & UCase(BRCode) & "' and upper(currencycode)='" & _
                     UCase(curcode) & "' and upper(ModuleId)='" & UCase(ModuleId) & "' and " & _
                     "upper(glcode)='" & UCase(GlCode) & "' and upper(accno)='" & _
                     UCase(AccNo) & "'"
                 
        'Where Condition for Deleting Rows based on ModuleId,GLCode,AccNo

        strWhrCondGen = "trim(upper(branchcode))='" & UCase(BRCode) & _
                    "' and trim(upper(currencycode))='" & UCase(curcode) & "'"
    
        strTrnTab = "GENMODULEMST"
        strTrnFld = "trandaytable,mastertable"
        strTrnWhCond = "upper(moduleid)='" & UCase(Trim(ModuleId)) & "'"
  
        '-------Deleting or Modifying rows from gentemptranslog based on condition
        strTrnsLog = "GENTEMPTRANSLOG"
 
        If UCase(modOrDel) = "DEL" Then
            'strInsDel = ObjTrans.DeleteRecord(strTrnsLog, strWhrCondTrn)
            strInsDel = ObjTrans.DeleteRecord(strTrnsLog, strWhrCondToDel)
     
            'Code added by Radhika on 19 nov 2008
            'Reason: Don't consider whether row(s) are deleted from gentemptranslog or not.
            strInsDel = "Trans Completed"
     
        ElseIf UCase(modOrDel) = "MOD" Then
            strFldTrn = "transtatus"
            arrTransVal(0) = "'P'"
            '     strInsDel = ObjTrans.UpdateRecord(strTrnsLog, strFldTrn, arrTransVal(), _
            '                  strWhrCondTrn)
            strInsDel = ObjTrans.UpdateRecord(strTrnsLog, strFldTrn, arrTransVal(), _
                         strWhrCondToDel)
  
            If strInsDel <> "Trans Completed" Then
               GoTo errhand
            End If
        End If
             
 
        '--------Getting tranday,master table based on moduleid
 
        Set recTrnTab = CreateObject("ADODB.Recordset")
        Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
        Set recTrnTab = objQuery.SingleRecordSet(strTrnTab, strTrnFld, strTrnWhCond)
        
        If objQuery.ConnError <> "Connected" Then
           GoTo errhand
        End If
        
        If recTrnTab.RecordCount > 0 Then
           strTrnTab = recTrnTab(0)
           strMstTab = UCase(Format(recTrnTab!mastertable))
        Else
           TranDeleteabb = "Table does not exist"
           objContext.SetAbort
           Exit Function
        End If


        '--------Deleting from gentranslog and respective tranday tables
        
        'strInsDel = ObjTrans.DeleteRecord(strTrnsTab, strWhrCondTrn)
        strInsDel = ObjTrans.DeleteRecordGen(strTrnsTab, strWhrCondToDel, , userid, machineid)
        If strInsDel <> "Trans Completed" Then
           GoTo errhand
        End If
        
        'strInsDel = ObjTrans.DeleteRecord(strTrnTab, strWhrCondTrn)
        strInsDel = ObjTrans.DeleteRecord(strTrnTab, strWhrCondToDel)
     
        If strInsDel <> "Trans Completed" Then
           GoTo errhand
        End If
               
               
        '--------Exception Transaction Deletion
        If ExcpYN = "Y" Then
            Dim ExcpTran As String
            ExcpTran = DelRecord("GENEXCEPTIONALTRANDAY")
            If ExcpTran <> "Sucessfully Completed" Then
               strInsDel = ExcpTran
               GoTo errhand
            End If
        End If
               
        '--------Deleting Cheque Details
        'Code commented by Radhika on 04-aug-2007
        'Reason: Cheque series number is not a mandatory column
        'If ChqSrs <> "" And ChqNo <> "" And ServiceId <> "8" Then
        If ModuleId = "SB" Or ModuleId = "CA" Or ModuleId = "SCHOOL" Or ModuleId = "CC" Then
            If ChqNo <> "" And ServiceId <> "8" Then
                strRec = ChequeDetails
                If strRec <> "Sucessfully Completed" Then
                   strInsDel = strRec
                   GoTo errhand
                End If
            End If
        End If
        '--------------------------------------------------------------------------------------------
        'For Non Disposal Transactions i.e Ordinary Transactions directly done from Transactions Scrren
        If SysGenYN = "N" Or SysGenYN = "Y" Then

            If ServiceId = "1" Then
                
                'For Clearing
                If ModeOfTran = "5" Or ModeOfTran = "6" Then
                    If ModeOfTran = "5" Then
                        strRec = CLGInwardReturn()
                        If strRec <> "Sucessfully Completed" Then
                          strInsDel = strRec
                          GoTo errhand
                        End If
                    End If
                Else
                    ''For Others
                    '
                    'If UCase(Trim(ModuleId)) = "CASH" And ModeOfTran = "1" Then
                    '
                    '   strRec = Receipts(arrDenoms)
                    '
                    '   If strRec <> "Sucessfully Completed" Then
                    '      strInsDel = strRec
                    '      GoTo errhand
                    '   End If
                    'End If
           
                    If ModeOfTran = "1" Then
                        If UCase(strCashPYN) = "Y" Then
                        'Cash Paid Transaction can be Delete Cashiers Only.
                        '(from Cash Transaction Deletion form only).
                        
                            If UCase(frmname) <> "CASHTRANSACTIONDELETION" Then
                                strInsDel = "Cash already Paid...Transaction Cannot be " & _
                                modOrDelText
                                GoTo errhand
                            End If
                        Else
                            
                            strRec = TellerPayments()
                            If strRec <> "Sucessfully Completed" Then
                                strInsDel = strRec
                                GoTo errhand
                            End If
                        End If
                    End If
                    ''''--------------------

                    If UCase(Trim(ModuleId)) = "REM" Then
                       strRec = Remittance(ModuleId, ModeOfTran)
                       If strRec <> "Sucessfully Completed" Then
                          strInsDel = strRec
                          GoTo errhand
                       End If
                    End If

                    If (UCase(Trim(ModuleId)) = "FXREM" And _
                    (ModeOfTran = "4" Or ModeOfTran = "2")) Then
                    
                        strRec = DelRecord("FXREMPENDINGINSTRTEMP")
                        If strRec <> "Sucessfully Completed" Then
                            strInsDel = strRec
                            GoTo errhand
                        End If
                       
                    End If

                    '--------------------
                    'Suspence
                    If UCase(Trim(ModuleId)) = "SCR" Then
                        strRec = Suspence()
                        If strRec <> "Sucessfully Completed" Then
                            strInsDel = strRec
                            GoTo errhand
                        End If
                    End If
                    '---------------------

                    'if loans then fill interest charges
                    If UCase(Trim(ModuleId)) = "LOAN" Then
                        strRec = DelRecord("LOANRECOVERYDAYDTLS")
                        'code commented by radhika on 24 nov 2008
                        'If strRec <> "Sucessfully Completed" Then
                        '   strInsDel = strRec
                        '   GoTo errhand
                        'End If
                        strRec = "Sucessfully Completed"
                    End If

                    '---------------------------------------------------------------------
                    'This code is Added by T.Ramakrishna on 28/06/2007 1.11 pm
                    'Cash Transaction Deletion (Cash Payments or Cash Receipts
                    
                    'If UCase(Trim(ModuleId)) = "CASH" Then
                    If ModeOfTran = "1" And CashierId <> "" Then
                        strRec = DeleteReceipts(ModuleId, ModeOfTran)
                        If strRec <> "Sucessfully Completed" Then
                            strInsDel = strRec
                            GoTo errhand
                        End If
                    End If

                    '--------------------------------------------------------------------
                End If
            End If 'end of ServiceId = "1" code
            
            ''''-------------------------------------------------------------------------------------------
            If ServiceId = "2" Or ServiceId = "3" Or ServiceId = "4" Then
                strRec = AccountOpenRen()
                If strRec <> "Sucessfully Completed" Then
                    strInsDel = strRec
                    GoTo errhand
                End If

                '''If UCase(Trim(ModuleId)) = "CASH" And ModeOfTran = "1" Then
                '''
                '''    strRec = Receipts(arrDenoms)
                '''
                '''    If strRec <> "Sucessfully Completed" Then
                '''       strInsDel = strRec
                '''       GoTo errhand
                '''    End If
                '''End If
            End If
            
            ''''-------------------------------------------------------------------------------------------
            If ServiceId = "3" Then
                strRec = AccountOpenRen()
                If strRec <> "Sucessfully Completed" Then
                    strInsDel = strRec
                    GoTo errhand
                End If
            End If

            ''''-------------------------------------------------------------------------------------------
            'for clearing outwardReturns calling a function to do transactions
            If ServiceId = "8" Then
                strRec = DelRecord("CLGOUTWARDRETURNDTLS")
                   If strRec <> "Sucessfully Completed" Then
                      strInsDel = strRec
                      GoTo errhand
                   End If
            End If
            ''''-------------------------------------------------------------------------------------------
            '''
            'for Remittance Cancellation.
            If ServiceId = "9" Then
                If UCase(Trim(ModuleId)) = "REM" Then
                   strRec = Remittance(ModuleId, ModeOfTran)
                   If strRec <> "Sucessfully Completed" Then
                      strInsDel = strRec
                      GoTo errhand
                   End If
                End If
            End If
            
            '''---------------------------------------------------------------------------------------
            ''
            If LinkModId <> "" And UCase(SysGenYN) <> "Q" Then
                strRec = DelRecord("GENDISPOSALDTLS")
            
                'code commented by Radhika on 19 nov 2008
                ''If strRec <> "Sucessfully Completed" Then
                ''   strInsDel = strRec
                ''   GoTo errhand
                ''End If

                'New code is
                strRec = "Sucessfully Completed"
            End If

            If UCase(ModuleId) = "DEP" Then
                strRec = DelRecord("DEPSTATEMENTDTLS")
                If strRec <> "Sucessfully Completed" Then
                   strInsDel = strRec
                   GoTo errhand
                End If
            End If

        End If

               If ModeOfTran = "1" Or ModeOfTran = "2" Then
                    strRec = DelRecord("GENDISPOSALDTLS")
            
                
                    strRec = "Sucessfully Completed"
                End If
        '======================
        '-------Deleting records from GENDISPOSALDTLSTEMP- modified by ramakrishna on 10/08/2007------
        StrTabName = "GENDISPOSALDTLSTEMP"
        'strRec = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)
        strRec = ObjTrans.DeleteRecord(StrTabName, strWhrCondDispTemp)
        
        'code added by Radhika on 19 nov 2008
        strRec = "Trans Completed"

        '===========================================================================================
        'Disposals
        If UCase(SysGenYN) = "Q" Then
   
            strRec = Disposals()
            'If strRec <> "Sucessfully Completed" Then
            '   strInsDel = strRec
            '   GoTo errhand
            'End If
            strRec = "Sucessfully Completed"

            If ServiceId = "1" Then
            '---------------------  'And lockerPaiddate <> "" And lockerNextduedate <> "" Then
            'For Lockers
                If UCase(LinkModId) = "LOCKER" And UCase(ModuleId) = "PL" Then '-- Condition to be changed
                '-- Above Condition should be changed
                    
                    strRec = DelRecord("LOCKERRENTDTLS")
     
                    If strRec <> "Sucessfully Completed" Then
                       strInsDel = strRec
                       GoTo errhand
                    End If
                End If
            End If
        End If
        
        '===========================================================================================

         '''   Else
         '''   GoTo ErrHand
         '''   End If
         '''Else
         '''GoTo ErrHand
         '''End If
         
        'Code written by Radhika on 02 Dec 2008
        If ActivityId = "BILLMARGINPOSTED" And LinkModId = "BILLS" Then
             
            'Check whether Margin payment was done or not. If done, then that
            'transaction is to be deleted first.
            Set rsGen = objQuery.SingleRecordSet("BILLSMST", "MARGINPAIDDATE", _
            " trim(upper(branchcode))='" & UCase(BRCode) & "' and " & _
            " upper(glcode)='" & UCase(LinkGlCode) & "' and " & _
            " trim(ACCNO)='" & LinkAccNo & "' and MARGINPAIDDATE is null")
            
            If rsGen.EOF = True Then
                strInsDel = "Bill Margin Payment Transaction is to be deleted" & _
                " first, before deleting this transaction."
                Set rsGen = Nothing
                GoTo errhand
            End If
            
            arrTransVal(0) = "null~null~null~null~null"
            
            'update margin related columns to null in Billsmst
            strInsDel = ObjTrans.UpdateRecord("BILLSMST", _
            "MARGINPERCENTAGE, MARGINAMT, INTRATE, NOOFDAYS, INTAMT", _
            arrTransVal(), _
            " trim(upper(branchcode))='" & UCase(BRCode) & "' and " & _
            " upper(glcode)='" & UCase(LinkGlCode) & "' and " & _
            " trim(ACCNO)='" & LinkAccNo & "'")
             
            If strInsDel <> "Trans Completed" Then
               GoTo errhand
            End If
            
        ElseIf ActivityId = "BILLMARGINREVERSED" And LinkModId = "BILLS" Then
             
            arrTransVal(0) = "null~null~null~null~null~null"
             
            'update margin related columns to null in Billsmst
            strInsDel = ObjTrans.UpdateRecord("BILLSMST", _
            "MARGINPAIDDATE, MARGINPAIDBATCHNO, MARGINPAIDTRANNO, " & _
            "MARGINPAIDBRANCH, MARGINPAIDUSERID, MARGINPAIDMACHINEID", _
            arrTransVal(), _
            " trim(upper(branchcode))='" & UCase(BRCode) & "' and " & _
            " upper(glcode)='" & UCase(LinkGlCode) & "' and " & _
            " trim(ACCNO)='" & LinkAccNo & "'")
             
            If strInsDel <> "Trans Completed" Then
               GoTo errhand
            End If

        End If
        'end of Code written by Radhika on 02 Dec 2008
        
        'Code written by Radhika on 27 Jan 2009
        If ActivityId = "PIC" And LinkModId = "PIGMY" And AccLastIntApplDt <> "" Then
        'PIC = Pigmy Interest Calculation
             
            arrTransVal(0) = "'" & AccLastIntApplDt & "'"
            
            'update margin related columns to null in Billsmst
            strInsDel = ObjTrans.UpdateRecord("PIGMYACCOUNTSMST", _
            "LASTINTCALCDATE", arrTransVal(), _
            " trim(upper(BRANCHCODE))='" & UCase(BRCode) & "' and " & _
            " upper(CURRENCYCODE)='" & UCase(curcode) & "' and " & _
            " upper(glcode)='" & UCase(LinkGlCode) & "' and " & _
            " trim(ACCNO)='" & Trim(LinkAccNo) & "' and " & _
            " trim(agentcode)='" & Trim(LinkAccType) & "'")
             
            If strInsDel <> "Trans Completed" Then
               GoTo errhand
            End If
            
        End If
        'End of Code written by Radhika on 27 Jan 2009
         
        'Delete data from side tables blindly
        strRec = DoBlindDeletion(ModuleId, BRCode, curcode, GlCode, AccNo, BatchNo, ApplDate)
        If strRec <> "Sucessfully Completed" Then
           strInsDel = strRec
           GoTo errhand
        End If
  
   Next introws
   
  
  
            If introws = UBound(arrgrid) Then
               objContext.SetComplete
               If modOrDel = "DEL" Then
                  TranDeleteabb = "Batch No : " & BatchNo & modOrDelText
               ElseIf modOrDel = "MOD" Then
                  TranDeleteabb = "Batch No : " & BatchNo & " has been set for Modification"
               End If
            Else
               GoTo errhand
            End If
     
            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
            Exit Function
     
     
'------------------------------------------------------------------------------------------

errhand:
     
            objContext.SetAbort
     
            If objQuery.ConnError <> "Connected" Then
               TranDeleteabb = objQuery.ConnError
               TranDeleteabb = Replace(TranDeleteabb, Chr(10), "")
               TranDeleteabb = Replace(TranDeleteabb, Chr(13), "")

            End If
            
            Set objContext = Nothing
            Set objQuery = Nothing
            Set ObjTrans = Nothing
     
            If Err.Number <> "0" Then
               TranDeleteabb = Err.Number & " : " & Err.Description
               TranDeleteabb = Replace(TranDeleteabb, Chr(10), "")
               TranDeleteabb = Replace(TranDeleteabb, Chr(13), "")
            ElseIf strInsDel <> "Trans Completed" Then
               TranDeleteabb = strInsDel
               TranDeleteabb = Replace(TranDeleteabb, Chr(10), "")
               TranDeleteabb = Replace(TranDeleteabb, Chr(13), "")
            End If
   
End Function

Private Function DoBlindDeletion(ByVal i_ModuleId As String, ByVal i_BranchCd As String, _
ByVal i_CurrencyCode As String, ByVal i_GlCode As String, ByVal i_AccNo As String, _
ByVal i_BatchNo As String, ByVal i_ApplDt As Date) As String

'DESC : Get Table Names of given Module ID, from which data is to be deleted blindly
    
    Dim rs As ADODB.Recordset, sCondition As String
    Dim rsLink As ADODB.Recordset, sBatchNos As String
    
    sCondition = "moduleid='" & Trim(i_ModuleId) & "'"
    
    Set rs = objQuery.SingleRecordSet("GENBLINDDELDTLS", "tablename", sCondition)
    If rs.EOF = True Then
        DoBlindDeletion = "Sucessfully Completed"
        Exit Function
    End If
    
    'Get Linked Batch Numbers too
    sCondition = "Branchcode='" & i_BranchCd & "' and " & _
        " applicationdate='" & Format(i_ApplDt, "dd-mmm-yyyy") & "'" & _
        " AND (parentbatchno = " & i_BatchNo & " OR parentbatchno IN " & _
        " (SELECT parentbatchno FROM GENLINKBATCHTEMP WHERE " & _
        "  childbatchno = " & i_BatchNo & _
        "  and Branchcode='" & i_BranchCd & "' )) "
        
        
    Set rsLink = objQuery.SingleRecordSet("GENLINKBATCHTEMP", _
        "parentbatchno,childbatchno", sCondition)
    
    sBatchNos = ""
    If rsLink.EOF = False Then
        sBatchNos = rsLink(0).Value
        Do While rsLink.EOF = False
            sBatchNos = sBatchNos & "," & rsLink(1).Value
            rsLink.MoveNext
        Loop
    Else
        sBatchNos = i_BatchNo
    End If
    Set rsLink = Nothing
    
    rs.MoveFirst
    Do While rs.EOF = False
        
        sCondition = "BRANCHCODE='" & Trim(i_BranchCd) & "' and " & _
            " CURRENCYCODE='" & Trim(i_CurrencyCode) & "' and " & _
            " GLCODE='" & Trim(i_GlCode) & "' and " & _
            " ACCNO='" & Trim(i_AccNo) & "' and " & _
            " BATCHNO in (" & Trim(sBatchNos) & ") and " & _
            " APPLICATIONDATE='" & Format(i_ApplDt, "dd-mmm-yyyy") & "'"
        
        'If data exists, below statement will delete that
        strInsDel = ObjTrans.DeleteRecord(rs(0).Value, sCondition)
                    
        'Don't check whether data is deleted or not

        rs.MoveNext
    Loop
    Set rs = Nothing

    DoBlindDeletion = "Sucessfully Completed"
    Exit Function
    
End Function

Public Function Remittance(ByVal ModuleId As String, ByVal ModeOfTran As String) As String
If ModeOfTran = "3" Or ModeOfTran = "1" Then
     StrTabName = "REMITTPAYREGMST"
     
     strwhrcondrempayrgty = strWhrCondTrn & " and applicationdate " & _
     " = '" & Format(ApplDate, "dd-mmm-yyyy") & "'"
     Set recTrnTab1 = objQuery.SingleRecordSet(StrTabName, "batchno,tranno", strwhrcondrempayrgty)
     
     If recTrnTab1.RecordCount > 0 Then
     
     'this code is written by T.Ramakrishna on 21/06/2007 5.40 pm
        If ServiceId <> 9 Then
            Dim remBranch As String
            Set recTrnTab = objQuery.SingleRecordSet(StrTabName, "ISSUEDBYBRANCH", strwhrcondrempayrgty)
            If recTrnTab.RecordCount > 0 Then
                remBranch = recTrnTab(0)
            End If
            strWhrCondGen = "trim(upper(branchcode))='" & UCase(remBranch) & _
                "' and trim(upper(currencycode))='" & UCase(curcode) & "'"
        End If
    'code ended here.
     
     strInsDel = ObjTrans.DeleteRecord(StrTabName, strwhrcondrempayrgty)

                If strInsDel <> "Trans Completed" Then
                   Remittance = strInsDel
                   Exit Function
                End If

        StrTabName = "REMITISSUEMST"
        StrFldNames = "PAIDBATCHNO,PAIDTRANNO,PAIDBRANCHCODE,PaidDate,INSTRCANCELYN"
        arrFldVal(0) = "''~''~''~''~''"
        strWhrCondAdd = " and paidbatchno='" & BatchNo & "' and paidtranno='" & tranno & _
            "' and paiddate='" & Format(ApplDate, "dd-mmm-yyyy") & "'" & _
            " and PAIDBRANCHCODE='" & Trim(BRCode) & "'"
        
        strWhrCondAdd = strWhrCondGen & strWhrCondAdd
        

        strInsDel = ObjTrans.UpdateRecord(StrTabName, StrFldNames, arrFldVal(), _
                    strWhrCondAdd)
      
                If strInsDel <> "Trans Completed" Then
                   Remittance = strInsDel
                   Exit Function

                End If
End If '' recTrnTab1
ElseIf ModeOfTran = "4" Or ModeOfTran = "2" Then

    StrTabName = "REMPARTICULARTRN"
    StrFldNames = "INSTRSTATUS,ISSUESTATUS"
    strwhrcondrempayrgty = strWhrCondTrn & " and applicationdate = '" & Format(ApplDate, "dd-mmm-yyyy") & "'"
    
    strwhrcndgntrnlg = strWhrCondTrn & " and glcode = '" & GlCode & "'"
    
    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strwhrcondrempayrgty)
        
        If objQuery.ConnError <> "Connected" Then
           Remittance = "Connection Problem"
           Exit Function
        End If
      
        If recTrnTab.RecordCount > 0 Then
           If UCase(recTrnTab!INSTRSTATUS) = "I" Or UCase(recTrnTab!ISSUESTATUS) = "Y" Then
'              Remittance = "Instrument has been Issued for this Transaction..." & _
'                              "Cannot be" & modOrDelText

                
                strInsDel = ObjTrans.DeleteRecord("REMITISSUEMST", strwhrcondrempayrgty)
               If strInsDel <> "Trans Completed" Then
                  Remittance = strInsDel
                  Exit Function
               End If
               
                strInsDel = ObjTrans.DeleteRecord(StrTabName, strwhrcondrempayrgty)
               If strInsDel <> "Trans Completed" Then
                  Remittance = strInsDel
                  Exit Function
               End If
               
              strInsDel = ObjTrans.DeleteRecordOnly("GENTRANSLOGDEM", strwhrcndgntrnlg)
               If strInsDel <> "Trans Completed" Then
                  Remittance = strInsDel
                  Exit Function
               End If
               
              
           Else
              strInsDel = ObjTrans.DeleteRecord(StrTabName, strwhrcondrempayrgty)
               If strInsDel <> "Trans Completed" Then
                  Remittance = strInsDel
                  Exit Function
               End If
           End If ''UCase(recTrnTab!INSTRSTATUS) = "I" Or UCase(recTrnTab!ISSUESTATUS) = "Y"
        End If ''recTrnTab.RecordCount
 
End If ''ModeOfTran

Remittance = "Sucessfully Completed"

End Function

Public Function DeleteReceipts(ByVal ModuleId As String, ByVal ModeOfTran As String) As String
'-------------------------------------Variables
Dim strCashMst As String, strCashMstFldnms As String, strCashMstVal(0) As String, _
strCashMstWhCond As String, strCashTrn As String, strCashTrnFld As String, _
strCashTrnVal(0) As String, strTrans As String, strTransFld As String, strTransVal(0) As String, _
strCshTrnDay As String, strCshTrnDayFld As String, strCshTrnDayVal(0) As String, _
strSbTrnDay As String, strSbTrnFld As String, strSbTrnVal(0) As String, strTempTrans As String, _
strTempTranWhCnd As String, systemdate As Date, strVal(0) As String, strWhereCond As String, _
strquerytab As String, strorder As String, ICount As Integer, strFldnms As String, _
strFldupd As String, strDenomval As String, strDenupd As String, strFinal As String, _
strnegden  As String, strtemp As String, strqueryflds As String, rec As ADODB.Recordset, _
TotalAmt As Double, strCashWhrCondTrn As String
'---------------------------------------------------------------------------------
 '  On Error GoTo ErrHand
    strInsDel = ""
'----------Querying cashcashierposmst to get Total Amount--------------------------
    strCashMst = "CASHCASHIERPOSMST"
    strCashMstFldnms = "TOTAMOUNT"
    'strCashMstVal(0) = "nvl(totamount, 0) -" & Abs(Amount)
    If pstrabbbrcd <> "" Then
    strCashMstWhCond = "upper(trim(branchcode))='" & UCase(Trim(pstrabbbrcd)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                      "' and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & "'"
    Else
    strCashMstWhCond = "upper(trim(branchcode))='" & UCase(Trim(BRCode)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                      "' and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & "'"
    End If
    Set rec = CreateObject("ADODB.Recordset")
    Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
    Set rec = objQuery.SingleRecordSet(strCashMst, strCashMstFldnms, strCashMstWhCond)
    
    If objQuery.ConnError <> "Connected" Then
        DeleteReceipts = objQuery.ConnError
        DeleteReceipts = Replace(DeleteReceipts, Chr(10), "")
        DeleteReceipts = Replace(DeleteReceipts, Chr(13), "")
        Exit Function
    End If
    If Not rec.EOF Then
        TotalAmt = rec!TotAmount
    Else
        DeleteReceipts = "User Cannot Delete This Transaction"
        Exit Function
    End If
    '-------------Updating TotAmount in cashcashierposmst----------------

    If ModeOfTran = 1 And UCase(Trim(ModuleId)) = "CASH" Then
        strCashMstVal(0) = CDbl(TotalAmt) - CDbl(Abs(CashAmt))
    ElseIf ModeOfTran = 1 And UCase(Trim(ModuleId)) <> "CASH" Then
        strCashMstVal(0) = CDbl(TotalAmt) + CDbl(Abs(CashAmt))
    End If
    
    '------Deleteing record in CASHRECEIPTSTRN or CASHPAYMENTSTRN----------------------
    If ModeOfTran = 1 And UCase(Trim(ModuleId)) = "CASH" Then
        strCashTrn = "CASHRECEIPTSTRN"
    ElseIf ModeOfTran = 1 And UCase(Trim(ModuleId)) <> "CASH" Then
        strCashTrn = "CASHPAYMENTSTRN"
    End If
     If pstrabbbrcd <> "" Then
     strCashWhrCondTrn = "upper(trim(branchcode))='" & UCase(Trim(pstrabbbrcd)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                      "' and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & _
                      "' and Tranno=" & tranno
     Else
     strCashWhrCondTrn = "upper(trim(branchcode))='" & UCase(Trim(BRCode)) & _
                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
                      "' and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & _
                      "' and Tranno=" & tranno
     End If
    '----------------------------------------------------------------------------------------

   strInsDel = ObjTrans.UpdateRecord(strCashMst, strCashMstFldnms, strCashMstVal, _
               strCashMstWhCond)

               If strInsDel <> "Trans Completed" Then
                  DeleteReceipts = strInsDel
                  DeleteReceipts = Replace(DeleteReceipts, Chr(10), "")
                  DeleteReceipts = Replace(DeleteReceipts, Chr(13), "")
                    Exit Function
               End If
   
    strInsDel = ObjTrans.DeleteRecord(strCashTrn, strCashWhrCondTrn)
               If strInsDel <> "Trans Completed" Then
                  DeleteReceipts = strInsDel
                  DeleteReceipts = Replace(DeleteReceipts, Chr(10), "")
                  DeleteReceipts = Replace(DeleteReceipts, Chr(13), "")
                  Exit Function
               End If
   '-----------------------------------------------------------------------------
         DeleteReceipts = "Sucessfully Completed"
         Exit Function

'ErrHand:

End Function


'''Public Function Receipts(arrDenom As Variant) As String
''''-------------------------------------Variables
'''Dim strCashMst As String, strCashMstFldnms As String, strCashMstVal(0) As String, _
'''strCashMstWhCond As String, strCashTrn As String, strCashTrnFld As String, _
'''strCashTrnVal(0) As String, strTrans As String, strTransFld As String, strTransVal(0) As String, _
'''strCshTrnDay As String, strCshTrnDayFld As String, strCshTrnDayVal(0) As String, _
'''strSbTrnDay As String, strSbTrnFld As String, strSbTrnVal(0) As String, strTempTrans As String, _
'''strTempTranWhCnd As String, systemdate As Date, strVal(0) As String, strWhereCond As String, _
'''strquerytab As String, strorder As String, ICount As Integer, strFldnms As String, _
'''strFldupd As String, strDenomval As String, strDenupd As String, strFinal As String, _
'''strnegden  As String, strtemp As String, strqueryflds As String, recdenom As ADODB.Recordset
''''--------------------------------------------------------------------------------------------
''' ' On Error GoTo ErrHand
'''  strInsDel = ""
''''--------------Querying DenominationMst to get Denominations---------------------------------
'''
'''  strquerytab = "CashDenominationMst"
'''  strqueryflds = " Denominationvalue,Denominationcode,denominationtype "
'''  strWhereCond = " upper(Currencycode)='" & curcode & "'"
'''  strorder = " substr(denominationtype,1,1) desc, substr(denominationtype,2,1) , " _
'''             & " to_number( denominationvalue) desc"
'''
'''  Set recdenom = CreateObject("ADODB.Recordset")
'''
'''  Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
'''  Set recdenom = objQuery.SingleRecordSet(strquerytab, strqueryflds, _
'''                                            strWhereCond, strorder)
'''  If objQuery.ConnError <> "Connected" Then
'''     Receipts = objQuery.ConnError
'''     Exit Function
'''  End If
'''
'''  If recdenom.RecordCount <= 0 Then
'''     Receipts = "No Denominations Found"
'''     Exit Function
'''  End If
'''  Set objQuery = Nothing
''''---Finding DenominationCode from DenominationMst, using DenominationValue and DenominationType
'''
'''    For ICount = 0 To UBound(arrDenom)
'''        recdenom.MoveFirst
'''
'''        recdenom.Filter = "Denominationvalue='" & Trim(arrDenom(ICount, 0)) & "' and " & _
'''                     UCase("denominationtype='") & UCase(Trim(arrDenom(ICount, 3))) & "'"
'''
''''--------------Concatinating Denomination Code and Denomination Values to insert and Update tables
'''
'''    If Not recdenom.EOF Then
'''
'''       strFldnms = strFldnms & "," & recdenom!Denominationcode
'''       strFldupd = recdenom!Denominationcode
'''       strDenomval = strDenomval & "," & Val(arrDenom(ICount, 1)) - Val(arrDenom(ICount, 2))
'''       strDenupd = Val(arrDenom(ICount, 1))
'''
''''-------------If User gives any denominations to the customer then.....
'''
'''    If Val(arrDenom(ICount, 2)) > 0 Then
'''       strnegden = (Val(arrDenom(ICount, 1)) - Val(arrDenom(ICount, 2)))
'''
'''           If Val(arrDenom(ICount, 1)) > Val(arrDenom(ICount, 2)) Then
'''              strFinal = "NVL(" & strFldupd & ",0)" & "+" & Abs(strnegden)
'''           Else
'''              strFinal = "NVL(" & strFldupd & ",0)" & "-" & Abs(strnegden)
'''           End If
'''    Else
'''       strFinal = "NVL(" & strFldupd & ",0)" & "+" & strDenupd
'''    End If
'''
'''       strFinal = strtemp & "~" & strFinal
'''       strtemp = strFinal
'''    End If
'''    Next ICount
'''
'''    'ApplDate = Format(ApplDate, "dd-mmm-yyyy")
'''
'''    '-------------Storing field names and values to update cashcashierposmst----------------
'''
'''    strCashMst = "CASHCASHIERPOSMST"
'''    strCashMstFldnms = "BranchCode,CurrencyCode,CashierId,UserId,MachineID," & _
'''                       "ApplicationDate,systemdate,Narration,TOTAMOUNT" & strFldnms
'''
'''    strCashMstVal(0) = "'" & brcode & "'~'" & curcode & "'~'" & CashierId & "'~'" & _
'''                  EnteredBy & "'~'" & EnteredMC & "'~'" & Format(ApplDate, "dd-mmm-yyyy") & _
'''                  "'~sysdate~'" & Narration & "'~" & _
'''                  "nvl(totamount, 0) +" & Abs(Amount) & strtemp
'''
'''    strCashMstWhCond = "upper(trim(branchcode))='" & UCase(Trim(brcode)) & _
'''                       "' and upper(trim(currencycode))='" & UCase(Trim(curcode)) & _
'''                       "'and upper(trim(cashierid))='" & UCase(Trim(CashierId)) & "'"
'''
'''    '------Storing field names and values for inserting into cashpaymentstrn----------------
'''
'''   strCashTrn = "CASHRECEIPTSTRN"
'''   strCashTrnFld = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CASHIERID," & _
'''                   "RECEIPTSCROLLNO,AMOUNT,NARRATION,STATUS,UserId,MachineID," & _
'''                   "APPLICATIONDATE,SYSTEMDATE,TRANNO,COUNTERNO" & strFldnms
'''
'''   strCashTrnVal(0) = "'" & brcode & "','" & curcode & "','" & LinkModId & "','" & _
'''                 LinkGLCode & "','" & LinkAccNo & "','" & CashierId & "','" & ScrollNo & _
'''                 "','" & Abs(Amount) & "','" & Narration & "','P" & "','" & EnteredBy & _
'''                 "','" & EnteredMC & "','" & Format(ApplDate, "dd-mmm-yyyy") & _
'''                 "',sysdate,'" & tranno & "','" & CounterNo & "'" & strDenomval
'''
''''----------------------------------------------------------------------------------------
'''
'''   strInsDel = ObjTrans.UpdateRecord(strCashMst, strCashMstFldnms, strCashMstVal, _
'''               strCashMstWhCond)
'''
'''               If strInsDel <> "Trans Completed" Then
'''                  Receipts = strInsDel
'''                  Exit Function
'''               End If
'''   strInsDel = ObjTrans.InsertRecord(strCashTrn, strCashTrnFld, strCashTrnVal)
'''
'''               If strInsDel <> "Trans Completed" Then
'''                  Receipts = strInsDel
'''                  Exit Function
'''               End If
'''   '-----------------------------------------------------------------------------
'''         Receipts = "Sucessfully Completed"
'''         Exit Function
'''
''''ErrHand:
'''
'''End Function

Public Function Suspence() As String

Dim strOrgBatchNo As String
Dim strOrgTranNo As String
Dim strContraComp As String, strOrgdate As String
Dim strWhrContra As String
                    
                    
          ''''''' Checking whether the selected Transaction for deletion is Contra
          ''''''' or Original
                    
    StrTabName = "SCRCONTRADTLS"
    StrFldNames = "ORIGINATINGBATCHNO,ORIGINATINGTRANNO,to_char(ORIGINATINGDATE,'dd-Mon-yy')"
    
    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrCondTrn)
        
        If objQuery.ConnError <> "Connected" Then
           Suspence = "Connection Problem"
           Exit Function
        End If
         
      '''''''''''''''' if contra then
        If recTrnTab.RecordCount > 0 Then
                   strOrgBatchNo = recTrnTab!originatingbatchno
                   strOrgTranNo = recTrnTab!originatingtranno
                   strOrgdate = recTrnTab(2).Value
                   
                   strWhrCondAdd = " and trim(originatingbatchno)='" & CDbl(Trim(strOrgBatchNo)) & _
                                  "' and trim(originatingtranno)='" & CDbl(Trim(strOrgTranNo)) & "'" & _
                                  " and ORIGINATINGDATE='" & Trim(strOrgdate) & "'"
                                  
                   strWhrContra = strWhrCondGen & strWhrCondAdd
            
                    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrContra)
            
            
                    ''''' delete from Master table
                   strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)
                
                    If strInsDel <> "Trans Completed" Then
                      Suspence = strInsDel
                      Exit Function
                    End If
                    
                   ''''' delete from Details table
                   StrTabName = "SCRDTLS"
                   StrFldNames = "CONTRACOMPLETE"
                  
                   strWhrCondAdd = " and trim(batchno)='" & CDbl(Trim(strOrgBatchNo)) & _
                                  "' and trim(tranno)='" & CDbl(Trim(strOrgTranNo)) & "'" & _
                                  " and opdate='" & Trim(strOrgdate) & "'"
                                  
                   strWhrContra = strWhrCondGen & strWhrCondAdd
                   
                    If recTrnTab.RecordCount = 1 Then
                        arrFldVal(0) = "'N'"
                    ElseIf recTrnTab.RecordCount > 1 Then
                        arrFldVal(0) = "'P'"
                    End If
                     
                    
                    ''''' Mark Deletion in SCRDTLS Table (Contra Entry)
                                      
                   strInsDel = ObjTrans.UpdateRecord(StrTabName, StrFldNames, arrFldVal(), _
                               strWhrContra)
            
                   If strInsDel <> "Trans Completed" Then
                      Suspence = strInsDel
                      Exit Function
                   End If
        Else
        
        
            ''''''''''''''' if it is Original Entry
           StrTabName = "SCRDTLS"
           
            ''''' Check whether Contra is posted for this transaction or not
            Set recTrnTab = objQuery.SingleRecordSet(StrTabName, "CONTRACOMPLETE", strWhrCondTrn)
            
            '''''''''''' if transaction posted (ContraComplete is not "N") then
            ''''''''''''' (may be "F" or "P")
            If recTrnTab(0) <> "N" Then
                ''''' then raise an exception
                Suspence = "Contra is already Posted for this Entry. Please Delete Contra to delete Main Entry.."
                Suspence = Replace(Suspence, Chr(10), "")
                Suspence = Replace(Suspence, Chr(13), "")
                Exit Function
            End If
           
           
           ''''''' If "N" then delete
           strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)
      
           If strInsDel <> "Trans Completed" Then
              Suspence = strInsDel
              Exit Function
           End If
            
        End If

        Suspence = "Sucessfully Completed"
        Exit Function

End Function

Public Function AccountOpenRen() As String
Dim strOpenRen As String
Dim strUpdval(0) As Variant
            
        StrTabName = "GENOPENRENTEMP"
        StrFldNames = "nvl(MASTERCOMPLETEDYN,'N') masterYN"
        
        Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrCondTrn)
        
        If objQuery.ConnError <> "Connected" Then
           AccountOpenRen = "Connection Problem"
           Exit Function
        End If
      
        If recTrnTab.RecordCount > 0 Then
         
           If UCase(recTrnTab!masterYN) = "Y" Then
                If ServiceId = "2" Then
                   strOpenRen = "Opened"
                ElseIf ServiceId = "3" Then
                   strOpenRen = "Renewed"
                End If
              AccountOpenRen = "Account " & strOpenRen & " for this Transaction... " & _
                               "Cannot be" & modOrDelText
            AccountOpenRen = Replace(AccountOpenRen, Chr(10), "")
            AccountOpenRen = Replace(AccountOpenRen, Chr(13), "")
                               
              Exit Function
           Else
              strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)
                    If strInsDel <> "Trans Completed" Then
                       AccountOpenRen = strInsDel
                       AccountOpenRen = Replace(AccountOpenRen, Chr(10), "")
                       AccountOpenRen = Replace(AccountOpenRen, Chr(13), "")
                       Exit Function
                    End If
           End If
       End If
       
     If UCase(ModuleId) = "DEP" And strDelType = "DEL" And _
             (ServiceId = "3" Or ServiceId = "4") And UCase(Trim(ActivityId)) <> "UDC" Then
             
            StrClRentab = "GENCLOSEDACCOUNTSMST"
            StrClRenFlds = ""
            StrClRenCond = "upper(trim(branchcode))='" & BRCode & "' and " & _
                    "upper(trim(currencycode))='" & curcode & "' and " & _
                    "upper(trim(moduleid))='" & ModuleId & "' and " & _
                    "upper(trim(glcode))='" & GlCode & "' and accno='" & AccNo & "'"
            strUpd = ObjTrans.DeleteRecord(StrClRentab, StrClRenCond)
             
             StrClRentab = "DEPMST"
             StrClRenFlds = "STATUS,TRANSTATUS,CLOSEDATE"
             strUpdval(0) = "'R'~'A'~null"
             
             If Trim(AccLastIntApplDt) <> "" Then
                 StrClRenFlds = StrClRenFlds & ",LASTINTCALCDATE"
                 strUpdval(0) = strUpdval(0) & "~'" & Trim(AccLastIntApplDt) & "'"
             End If
             
             StrClRenCond = "upper(trim(branchcode))='" & BRCode & "' and " & _
                     "upper(trim(currencycode))='" & curcode & "' and " & _
                     "upper(trim(glcode))='" & GlCode & "' and accno='" & AccNo & "'"
             strUpd = ObjTrans.UpdateRecord(StrClRentab, StrClRenFlds, strUpdval, StrClRenCond)
    End If
               
     'Unit Deposit Closing
     If UCase(ModuleId) = "DEP" And strDelType = "DEL" And _
             (ServiceId = "3" Or ServiceId = "4") And UCase(Trim(ActivityId)) = "UDC" Then
             
        StrClRentab = "DEPMST"
        StrClRenFlds = "OPBAL,MATURITYVALUE"
        strUpdval(0) = DepAccOpAmt & "~" & DepAccMaturityAmt
        
        StrClRenCond = "upper(trim(branchcode))='" & BRCode & "' and " & _
                "upper(trim(currencycode))='" & curcode & "' and " & _
                "upper(trim(glcode))='" & GlCode & "' and accno='" & AccNo & "'"
        strUpd = ObjTrans.UpdateRecord(StrClRentab, StrClRenFlds, strUpdval, StrClRenCond)
        
    End If
       
       AccountOpenRen = "Sucessfully Completed"
       
End Function
''------------------------------------------------------------------------------------------
''' this function is used to do transactions for clearing presentation
'''''' for updating status as 'P' in clglodgementvoucherdtls table
''''' for inserting records into genunclearbalancedtls table
'''''---------------------------------------------------------------------------------------
Public Function CLGInwardReturn() As String

    Dim recTrnTab As Object

    StrTabName = "CLGLODGEMENTINSTRUMENTDTLS"
    StrFldNames = "status,CHQRETURNDATE,CHQRETURNBATCHNO,CHQRETURNTRANNO," & _
                        "VERIFIEDBY,VERIFIEDMACHINE"
       
    arrFldVal(0) = "''~''~''~''~''~''"
    strWhrCondAdd = "upper(trim(CLGACCTBRCODE))='" & BRCode & "' and " & _
                        "upper(trim(currencycode))='" & curcode & "' and " & _
                    "CHQRETURNDATE= to_date('" & ApplDate & "','dd-mm-yyyy') and " & _
                    "trim(CHQRETURNBATCHNO)='" & BatchNo & "' and " & _
                    "trim(CHQRETURNTRANNO)='" & tranno & "'"

    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrCondAdd)
    
    If objQuery.ConnError <> "Connected" Then
       CLGInwardReturn = objQuery.ConnError
       CLGInwardReturn = Replace(CLGInwardReturn, Chr(10), "")
       CLGInwardReturn = Replace(CLGInwardReturn, Chr(13), "")
       Exit Function
    End If
    
    If recTrnTab.EOF = False And recTrnTab.BOF = False Then
    'i.e if any rows exists in CLGLODGEMENTINSTRUMENTDTLS table,
    ' then only make data updations

        '''' calling transaction component update method
        strInsDel = ObjTrans.UpdateRecord(StrTabName, StrFldNames, _
                        arrFldVal(), strWhrCondAdd)
    
        '''if updation is not successfull goto errorhandle
        If strInsDel <> "Trans Completed" Then
           CLGInwardReturn = strInsDel
           CLGInwardReturn = Replace(CLGInwardReturn, Chr(10), "")
           CLGInwardReturn = Replace(CLGInwardReturn, Chr(13), "")
            Exit Function
        End If
    End If
    CLGInwardReturn = "Sucessfully Completed"

End Function


Public Function DelRecord(TableName As String) As String
 
       strInsDel = ObjTrans.DeleteRecord(TableName, strWhrCondTrn)

               If strInsDel <> "Trans Completed" Then
                  DelRecord = strInsDel
                  Exit Function
               End If

       DelRecord = "Sucessfully Completed"
       Exit Function
  

End Function

Public Function Disposals() As String
    
    'StrTabName = "GENDISPOSALDTLSTEMP"
    'StrFldNames = "transtatus,batchno,tranno"
    'arrFldVal(0) = "'P'~''~''"
    'strInsDel = ObjTrans.UpdateRecord(StrTabName, StrFldNames, arrFldVal(), strWhrCondTrn)
    '           If strInsDel <> "Trans Completed" Then
    '               Disposals = strInsDel
    '               Exit Function
    '            End If
    
    StrTabName = "GENDISPOSALDTLS"
    strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)
                If strInsDel <> "Trans Completed" Then
                   Disposals = strInsDel
                   Exit Function
                End If
    
    Disposals = "Sucessfully Completed"

End Function

Public Function ChequeDetails() As String

    StrTabName = "GENCHEQUEPAIDDTLS"
        
    strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondTrn)

    If strInsDel <> "Trans Completed" Then
       ChequeDetails = strInsDel
       ChequeDetails = Replace(ChequeDetails, Chr(10), "")
       ChequeDetails = Replace(ChequeDetails, Chr(13), "")
       Exit Function
    End If
    
    If UCase(ExcpYN) = "Y" Then
       StrTabName = "GENEXCEPTIONALTRANDAY"
       StrFldNames = "EXCEPTIONCODE"
       Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, _
        strWhrCondTrn & " and EXCEPTIONCODE='4'")
    
           If objQuery.ConnError <> "Connected" Then
              ChequeDetails = objQuery.ConnError
              ChequeDetails = Replace(ChequeDetails, Chr(10), "")
              ChequeDetails = Replace(ChequeDetails, Chr(13), "")
              Exit Function
           End If
           If recTrnTab.RecordCount > 0 Then
              ' if Cheque payment is exceptional one
              If recTrnTab!exceptioncode = "4" Then
                 ChequeDetails = "Sucessfully Completed"
                 Exit Function
              End If
              
           End If
        
    End If
    
'Code commented by Radhika on 04 Mar 2008
'Reason: Cheque details storage process was changed in the database
'        Now we were saving From cheque number and To Cheque Number in a single row
'        We were not saving each cheque number individually
    
'    StrTabName = "GENCHEQUEDTLS"
'    StrFldNames = "status"
'    arrFldVal(0) = "'A'"
'
'    'Code modified by Radhika on 04-aug-2007
'    'Reason: Cheque series number is not mandatory column
'    If Trim(ChqSrs) <> "" Then
'        strWhrCondMst = strWhrCondMst & " and chqseriesno='" & Trim(ChqSrs) & _
'                    "' and chequeno='" & Trim(ChqNo) & "'"
'    Else
'        strWhrCondMst = strWhrCondMst & " and chequeno='" & Trim(ChqNo) & "'"
'    End If
'
'    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrCondTrn)
'
'    strInsDel = ObjTrans.UpdateRecord(StrTabName, StrFldNames, arrFldVal(), strWhrCondMst)
'
'              If strInsDel <> "Trans Completed" Then
'                 ChequeDetails = strInsDel
'                 ChequeDetails = Replace(ChequeDetails, Chr(10), "")
'                 ChequeDetails = Replace(ChequeDetails, Chr(13), "")
'                 Exit Function
'              End If


    ChequeDetails = "Sucessfully Completed"
    Exit Function


End Function
Public Function TellerPayments()
    
    StrTabName = "CASHTELLERPAYMENTSTRANDAY"
    StrFldNames = "batchno"
    strWhrCondAdd = " and batchno='" & BatchNo & "'"
    strWhrCondGen = strWhrCondGen & strWhrCondAdd
    Set recTrnTab = objQuery.SingleRecordSet(StrTabName, StrFldNames, strWhrCondGen)
    
        If objQuery.ConnError <> "Connected" Then
           TellerPayments = objQuery.ConnError
           TellerPayments = Replace(TellerPayments, Chr(10), "")
           TellerPayments = Replace(TellerPayments, Chr(13), "")
            Exit Function
        End If
        
        If recTrnTab.RecordCount > 0 Then
           strInsDel = ObjTrans.DeleteRecord(StrTabName, strWhrCondGen)
             
             If strInsDel <> "Trans Completed" Then
                 TellerPayments = strInsDel
                 Exit Function
             End If
             TellerPayments = "Sucessfully Completed"
             Exit Function
        Else
             TellerPayments = "Sucessfully Completed"
             Exit Function
        End If

End Function


