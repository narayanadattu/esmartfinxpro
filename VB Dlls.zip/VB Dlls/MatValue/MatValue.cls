VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 2  'RequiresTransaction
END
Attribute VB_Name = "MatValue"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim objErrlog As Object
Dim Maturityvalue As Double
Dim Strmsg As String, Tilldate As String
Dim BreakDate  As String, DateTill As String, DiffMonths As Double, NewROI As Double
Dim NoOfQuarters As Double, DblDays As Double
Dim Factor As Double
Dim TERM As String
Dim Prd As Integer, Year As Double, Mon As Double, Day As Double
Dim PrincipalAmount As Double, Chkstr As Integer
Dim Count, i, SimIntDays, Strperiod As Double
Dim TotQuarters, intcount, RemainingDays, Intamt
Dim dblNoOfDaysPerYear, InMonths, Monstr
Public ConnError As String 'error object
Public AdoConnObj As ADODB.Connection ' Connection Object
Dim objdblink As Object
Dim ArrLink As Variant
Dim objError As Object
Dim ArrError As Variant
Const blnDebug As Boolean = True
Dim ErrNum As String
Dim errDesc As String
Dim strComponent As String
Dim lngdiffdays As Long
Dim lngdiffdays1 As Long
Dim strCompoundType As String
Dim intDivPer As Integer

    Public Function GetMaturityvalue(Period As String, EffDate As String, _
    MatDate As String, Amount As Double, CompoundTerm As String, _
    InstalmentsYN As String, ROI As Double, Optional strpremat As String, Optional PayType As String) As Variant

    Dim Prddtls
    On Error GoTo errhand
    
    Call DBConnection
    If ConnError <> "Connected" Then GoTo errhand
    
    dblNoOfDaysPerYear = 36500
    If Period = "" Then
        If EffDate = "" Or MatDate = "" Then
            GetMaturityvalue = "Error  ! Please send required parameters"
            Exit Function
        End If
    End If
'----Either two dates or period can be given as input for Mat value Calculation---

    If EffDate <> "" And MatDate <> "" Then
        Tilldate = CDate(MatDate)
        BreakDate = CDate(EffDate)
    End If
    
    If Period <> "" Then
        Prddtls = Split(Period, "|")
        Year = Trim(Prddtls(0))
        Mon = Trim(Prddtls(1))
        Day = Trim(Prddtls(2))
        If IsNull(Year) Then
            Year = 0
        End If
        If IsNull(Mon) Then
            Mon = 0
        End If
        If IsNull(Day) Then
            Day = 0
        End If
        
        If InstalmentsYN = "N" And (CompoundTerm = "" Or CompoundTerm = "N") Then
            'Do Simple int calculation based on given periodicity
            Dim dblTempInt As Double
            
            dblTempInt = 0
            
            If Year > 0 Then
                dblTempInt = (Amount * Year * ROI) / 100
            End If
            
            If Mon > 0 Then
                dblTempInt = dblTempInt + ((Amount * Mon * ROI) / 1200)
            End If
            
            If Day > 0 Then
                dblTempInt = dblTempInt + ((Amount * Day * ROI) / 36500)
            End If
            
            'Maturity value = Principal + calculated Interest
            GetMaturityvalue = Amount + dblTempInt
            
            Exit Function
        End If
        
    '------------------If period is send as input then-----------------------
    '------------BreakDate is assumed as this date for reference only--------
        BreakDate = CDate("1-jan-2000")
        Tilldate = DateAdd("YYYY", Year, BreakDate)
        Tilldate = DateAdd("M", Mon, Tilldate)
        Tilldate = DateAdd("D", Day, Tilldate)
        Tilldate = CDate(Tilldate)
    End If
    
    NewROI = ROI
    PrincipalAmount = Amount
    DblDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
    Count = 0
    DateTill = CDate(BreakDate)
    DateTill = CDate(DateTill)
 '--------Finding exact number of full months between two periods---------------
'    For i = 1 To 1000
'        DateTill = DateAdd("M", 1, CDate(DateTill))
'        If CDate(DateTill) > CDate(Tilldate) Then
'            Exit For
'        End If
'        Count = Count + 1
'    Next
'    DiffMonths = Count

'Original Code commented by Radhika on 31 Mar 2008
'DiffMonths = Fix(DateDiff("M", BreakDate, Tilldate))
 ''code commented on 06oct2021
 ''DiffMonths = GetMonthsDiff(BreakDate, Tilldate)
DiffMonths = GetMonthsDiff(BreakDate, Tilldate, strpremat)

'' simple removed diffdays condition
If PayType = "M" And (CompoundTerm = "" Or CompoundTerm = "N") Then



        BreakDate = DateAdd("M", DiffMonths, BreakDate)
        RemainingDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        If RemainingDays > 0 Then
        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * CDbl(NewROI) * DiffMonths) / (1200 + CDbl(NewROI)) + (CDbl(PrincipalAmount) * RemainingDays * CDbl(NewROI) / 36500)
            Else
            PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * CDbl(NewROI) * DiffMonths) / (1200 + CDbl(NewROI))
        End If
    
        GetMaturityvalue = CDbl(PrincipalAmount)
        Exit Function


Else

    If strpremat = "Y" Then
    If CompoundTerm = "" Then
        lngdiffdays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        'If lngdiffdays < 365 Then
            lngdiffdays1 = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
            
                    Strperiod = lngdiffdays1 / 365
              
            PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
            GetMaturityvalue = CDbl(PrincipalAmount)
            Exit Function
       ' End If
       '' compound
       Else
       lngdiffdays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        If lngdiffdays < 365 Then
            lngdiffdays1 = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
            
                    Strperiod = lngdiffdays1 / 365
              
            PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
            GetMaturityvalue = CDbl(PrincipalAmount)
            Exit Function
        End If
       End If
    End If ''PayType = "M"
'-----------------------Simple Int calc------------------------------------------
'----------If Compound term is null component calculates Simple Interest---------


        If CompoundTerm = "" And InstalmentsYN = "N" Or CompoundTerm = "N" And InstalmentsYN = "N" Then
        
        Strperiod = DiffMonths / 12
        BreakDate = DateAdd("M", DiffMonths, BreakDate)
        RemainingDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        If RemainingDays > 0 Then
            Strperiod = Strperiod + (RemainingDays / 365)
        End If
        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
        GetMaturityvalue = CDbl(PrincipalAmount)
        Exit Function
    End If
    End If
    '-----------------------Simple Int Calc Ends----------------------------------
    
    If InstalmentsYN = "Y" Then  'For Recurring Deposits
       GetMaturityvalue = CDbl(getRDMaturityValue(CDate(MatDate), CDate(EffDate), Amount, CDbl(ROI)))
    Else
        '-----------------------Compound Int Calc Starts------------------------------
        Select Case CompoundTerm
            Case "Q"    'Quarterly
            If DiffMonths >= 3 Then
                NoOfQuarters = DiffMonths / 3
                Factor = 0.0025
                TERM = "Q"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                'GetMaturityvalue = "Error  ! Period does not satisfy one Quarter"
                  PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                  GetMaturityvalue = CDbl(Round(PrincipalAmount))
            End If
            Case "M"    'Monthly
            If DiffMonths >= 1 Then
                NoOfQuarters = DiffMonths
                Factor = 1 / 1200
                TERM = "M"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                'GetMaturityvalue = "Error  ! Period does not satisfy one Month"
                  PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                  GetMaturityvalue = CDbl(Round(PrincipalAmount))
            End If
            Case "H"    'Half Yearly
            If DiffMonths >= 6 Then
                NoOfQuarters = DiffMonths / 6
                Factor = 0.005
                TERM = "Q"
                Prd = 2
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                'GetMaturityvalue = "Error  ! Period does not satisfy one Halfyear"
                  PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                  GetMaturityvalue = CDbl(Round(PrincipalAmount))
            End If
            Case "Y"    'Yearly
            If DiffMonths >= 12 Then
                NoOfQuarters = DiffMonths / 12
                Factor = 0.01
                TERM = "YYYY"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                'GetMaturityvalue = "Error  ! Period does not satisfy one Year"
                  PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                  GetMaturityvalue = CDbl(Round(PrincipalAmount))
            End If
        End Select
    End If
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
  Exit Function
errhand:
objErrlog.LogError "MaturityValueCalc", "GetMaturityvalue", Err.Number, Err.Description

If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
    

GetMaturityvalue = "Error  !" & Err.Number & " : " & Err.Description
GetMaturityvalue = Replace(GetMaturityvalue, Chr(10), "")
GetMaturityvalue = Replace(GetMaturityvalue, Chr(13), "")

End Function

Private Sub CompCalculation(Fact As Double, Quarters As Double, TERM As String, Prd As Integer)
   
  '-------------Full period calculation------------------------------------------
    dblNoOfDaysPerYear = 36500
    For intcount = 1 To Quarters
        BreakDate = DateAdd(TERM, Prd, CDate(BreakDate))
        Intamt = CDbl(PrincipalAmount) * CDbl(NewROI) * Fact
        PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
    Next
  '-------------Remaining Months calculation--------------------------------------
    Count = 0
    DateTill = BreakDate
    For i = 1 To 1000
        DateTill = DateAdd("M", 1, DateTill)
        If CDate(DateTill) > CDate(Tilldate) Then
            Exit For
        End If
        Count = Count + 1
    Next
    InMonths = Count
    BreakDate = DateAdd("M", InMonths, BreakDate)
    PrincipalAmount = CDbl(PrincipalAmount) + ((CDbl(PrincipalAmount) * (InMonths / 12) * CDbl(NewROI)) / 100)
  '-------------Remaining Days calculation----------------------
  
    RemainingDays = DateDiff("D", BreakDate, Tilldate)
    If RemainingDays > 0 Then
        Intamt = (CDbl(PrincipalAmount) * CDbl(NewROI) * _
                       CDbl(RemainingDays)) / CDbl(dblNoOfDaysPerYear)
        PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
    End If
    
End Sub


Private Function getRDMaturityValue(MaturityDate As Date, _
                                   IntEffectiveDate As Date, _
                                   InstalmentAmt As Double, _
                                   ROI As Single) As Double
Dim NoOfQuarters As Integer
Dim FirstQuarterAmt As Double
Dim RemainingDays As Integer
'If Not IsDate(MaturityDate) Or Not IsDate(IntEffectiveDate) Then
'MsgBox "Either Maturity date or Interest Effective Date is null." & Chr(13) & _
'       "System cannot calculate Maturity Amount", vbInformation
'Exit Function
'End If
'New formula is Introduced on 18-01-2003 don't change this formula without informing to the project manager
    'Code altered by Radhika on 29 Mar 2008
    'Reason: Date difference in Months not giving correct value
    'NoOfQuarters = Fix(DateDiff("M", IntEffectiveDate, MaturityDate) / 3)
    
    '''THIS CODE ADDED BY VINOD FOR RECURRING DEPOSIT CALCULATION
    
    Dim rsTmp As ADODB.Recordset
'    Dim strCompoundType As String
    Dim intPer As Integer
    'Dim intDivPer As Integer
    ''condition and glcode != 104270  added on  30-Nov-2019 CH Narayana Dattu
    Set rsTmp = AdoConnObj.Execute("SELECT NVL(INTCOMPOUNDYN,'N') COMYN FROM DEPTYPEMST WHERE INSTSYN='Y' and glcode != 104270", , adCmdText)
        
   If rsTmp.RecordCount = 0 Then
        Err.Raise 999, , "Unable to Get Compound Yes or No."
   End If
        
   strCompoundType = rsTmp!COMYN
   
   If rsTmp.State = 1 Then rsTmp.Close
   Set rsTmp = Nothing
   
   If strCompoundType = "M" Then
        intPer = 1
        intDivPer = 1200
   ElseIf strCompoundType = "Q" Then
        intPer = 3
        intDivPer = 400
   ElseIf strCompoundType = "H" Then
        intPer = 6
        intDivPer = 200
   ElseIf strCompoundType = "Y" Then
        intPer = 12
        intDivPer = 100
   End If
   
   '''THIS CODE ADDED BY VINOD FOR RECURRING DEPOSIT CALCULATION CODE ENDED HERE
    
    Dim intMonths As Integer

    intMonths = GetMonthsDiff(IntEffectiveDate, MaturityDate)
    NoOfQuarters = Fix(intMonths / intPer)
    
    RemainingDays = DateDiff("D", DateAdd("M", NoOfQuarters * intPer, IntEffectiveDate), MaturityDate)
    FirstQuarterAmt = InstalmentAmt * (intPer + ROI / intDivPer)
    
    If strCompoundType = "M" Then
        getRDMaturityValue = getRDCompundedValue(NoOfQuarters, FirstQuarterAmt, ROI)
    Else
        getRDMaturityValue = RDCompoundCalculation(intMonths, strCompoundType, InstalmentAmt, ROI)
    End If
    
    'If RemainingDays > 0 Then
    'getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * 31 * ROI / 36500)
    'End If
    
    'If RemainingDays > 31 Then
     '   getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * (RemainingDays - 31) * ROI / 36500)
    'End If
    
    'After Quarter, Calculate Simple Interest and add it.
    
    
    
'New formula Ends here
End Function

Private Function RDCompoundCalculation(Months As Integer, perType As String, Amount As Double, ROI As Single) As Double

Dim subAmount As Double
Dim dblInstlAmt As Double
Dim dblInt As Double
Dim intInstallments As Integer
Dim intAddInstal As Integer

intAddInstal = 0
If perType = "Q" Then
    intInstallments = 3
    intAddInstal = 3
ElseIf perType = "H" Then
    intInstallments = 6
    intAddInstal = 6
ElseIf perType = "Y" Then
    intInstallments = 12
    intAddInstal = 12
End If

dblInstlAmt = 0
dblInt = 0

For i = 1 To Months

    dblInstlAmt = dblInstlAmt + Amount
    
    If i = Months And (Months Mod intAddInstal) <> 0 Then
        dblInt = (dblInstlAmt * (1 / 12) * ROI) / 100
    Else
        dblInt = dblInt + (dblInstlAmt * (1 / 12) * ROI) / 100
    End If
    
    If i = intInstallments And i < Months Then
        dblInstlAmt = dblInstlAmt + dblInt + Amount
        dblInt = (dblInstlAmt * (1 / 12) * ROI) / 100
        intInstallments = intInstallments + intAddInstal
        i = i + 1
    End If
    
Next

RDCompoundCalculation = dblInstlAmt + dblInt
End Function
Private Function getRDCompundedValue(Quarter As Integer, _
                                    InstalmentAmt As Double, _
                                    ROI As Single) As Double
Dim SubTotal As Double
If Quarter <= 0 Then getRDCompundedValue = 0: Exit Function
SubTotal = InstalmentAmt * (1 + ROI / intDivPer) ^ (Quarter - 1) + _
           getRDCompundedValue(Quarter - 1, InstalmentAmt, ROI)
getRDCompundedValue = SubTotal
End Function

Public Function GetInterestAmount(PrincipalAmount As Double, CompoundYesNo As String, _
    CompoundTerm As String, ROI As Double, IntPeriodicity As String) As Variant
    Dim Prddtls
    On Error GoTo errhand
    dblNoOfDaysPerYear = 36500
    Dim IntAmount As Double
    Dim Period As Integer
    
    ''''''''''''''''''''''''''''' Mandatory Check ''''''''''''''''''''''''''''''
    If PrincipalAmount <= 0 Or (CompoundTerm = "" And CompoundYesNo = "Y") Or ROI <= 0 Or IntPeriodicity = "" Then
        
            GetInterestAmount = "Error ! Required Input Parameters are not sent."
            Exit Function
        
    End If
    ''''''''''''''''''''''''''''End of Mandatory Check ''''''''''''''''''''''''''''
        
     
    
    ''''''''''''''''''''' Interest Calculation'''''''''''''''''''''''''''''''''''
        
    If CompoundYesNo = "N" Then
    ''''''''''''''''''''''''''' Simple Interest Calculation '''''''''''''''''''''
SimpleInterest:


        ''''  Set value for Interst Calculation Period in months based on Periodicity
        If IntPeriodicity = "M" Then
            Period = 1
        ElseIf IntPeriodicity = "Q" Then
            Period = 3
        ElseIf IntPeriodicity = "H" Then
            Period = 6
        ElseIf IntPeriodicity = "Y" Then
            Period = 12
        End If
        IntAmount = (PrincipalAmount * Period * ROI) / 1200
        ''''''''''''''''''''''End of Simple Interst Calculation ''''''''''''''''''''''''
    
    Else
        
        If IntPeriodicity = CompoundTerm Then
        ''''''''' If Interest Payment Periodicity and Compounding Periodicity is same
        '''''''' then Simple Interest can be applied
            GoTo SimpleInterest
        Else
            ''''''''''''''''''''''''''' Compound Interest Calculation '''''''''''''''''''''
          ''''  Set value for Interst Calculation Period in months based on Periodicity
          '''' if Interest Periodicity is less than Compounding term then divert it
          '''' to simple interest calculation
          If CompoundTerm = "M" Then
               
               If IntPeriodicity = "Q" Then
                    Period = 3
               ElseIf IntPeriodicity = "H" Then
                    Period = 6
                ElseIf IntPeriodicity = "Y" Then
                    Period = 12
                End If
                 ROI = ROI / 1200
            ElseIf CompoundTerm = "Q" Then
                
               If IntPeriodicity = "M" Then
                    GoTo SimpleInterest
               ElseIf IntPeriodicity = "H" Then
                    Period = 2
               ElseIf IntPeriodicity = "Y" Then
                    Period = 4
                End If
                ROI = ROI / 400
            ElseIf CompoundTerm = "H" Then
               
                If IntPeriodicity = "M" Or IntPeriodicity = "Q" Then
                    GoTo SimpleInterest
                ElseIf IntPeriodicity = "Y" Then
                    Period = 2
                End If
                 ROI = ROI / 200
            End If
            
           IntAmount = (PrincipalAmount * (1 + (ROI)) ^ (Period)) - PrincipalAmount
                        
        '''''''''''''''''''''''''''End of Compound Interest Calculation '''''''''''''''''''''
        End If
        
        
    End If
    
    GetInterestAmount = IntAmount

    ''''''''''''''''''End of Interest Calculation ''''''''''''''''''''''''''''''
  Exit Function
errhand:
objErrlog.LogError "MaturityValueCalc", "GetInterestAmount", Err.Number, Err.Description

GetInterestAmount = "Error  !" & Err.Number & " : " & Err.Description
GetInterestAmount = Replace(GetInterestAmount, Chr(10), "")
GetInterestAmount = Replace(GetInterestAmount, Chr(13), "")

End Function


''Private Sub DbConnection()
''Dim DataLink As String
''
''''''' calling shared property manager for dblink
''Set objDBlink = CreateObject("SharedStaticValues.AcceptDBLink")
''DataLink = objDBlink.GetDBLink
''Set objDBlink = Nothing
''ArrLink = Split(DataLink, ",", -1)
''If UBound(ArrLink) < 2 Then
''    ConnError = ArrLink(0)
''    Exit Sub
''ElseIf UBound(ArrLink) = 2 Then
''    DataLink = ""
''ElseIf UBound(ArrLink) = 3 Then
''    DataLink = Trim(ArrLink(3))
''End If
''
''
''ConnError = ""
''Set AdoConnObj = CreateObject("ADODB.Connection")
''AdoConnObj.CursorLocation = adUseClient
'''AdoConnObj.Open "Provider=MSDAORA.1;data source=v3;Password=esmart;User ID=v3"
''AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''If AdoConnObj.State = 1 Then ConnError = "Connected"
''End Sub



Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
Dim strComponent As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With

''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "MaturityValueCalc", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Public Function RDInterestAmount(StrBrCode As String, StrCurCode As String, _
            StrGL As String, StrDepNo As String, DblOpBal As Double, _
            DblNewRate As Double, StrAppDate As String, StrPrematureYN As String) As Variant
On Error GoTo errhand

    Call DBConnection
    If ConnError <> "Connected" Then GoTo errhand

    Dim dtLastDayOfMonth As Date, MatDate As Date, PrevInstBalance As Double
    Dim intcount As Double, NoOfMonths As Integer
    Dim intInstalmentNo As Double
    Dim TERM As Double
    Dim PENAL As Double
    Dim MONTH As Double
    Dim StrDet As String
    Dim StrCond As String
    Dim RecLast As New ADODB.Recordset
    Dim RecCurBal  As New ADODB.Recordset
    Dim recfdtran As New ADODB.Recordset
    Dim RESMON As New ADODB.Recordset
    Dim intRecfdCount As Integer
    Dim intAmtInst As Integer
    Dim intAmtInstCnt As Integer
    Dim FromDt As Date
    Dim ToDt As Date
    Dim EffDate As Date
    Dim DblBalAmt As Double
    Dim DblIntAmt As Double
    Dim DblPenalInt As Double
    Dim PrevEffDt As Date
    Dim DueDt As Date
    Dim DblOpAmt As Double
    Dim Months As Integer
    Dim Balance As Double
    Dim intMonths As Integer
    Dim DblTotAmt As Double
    Dim DtCalUpto As Date
    Dim recmst As Recordset
    PrevEffDt = "09-09-1009"
    
    StrCond = "branchcode='" & Trim(StrBrCode) & "' " & _
             " and glcode ='" & Trim(StrGL) & "' and accno=" & _
            Trim(StrDepNo)
            
    Set recmst = AdoConnObj.Execute("select accno,glcode,name," _
        & "opdate depdate,roi,opbal,MATURITYDATE, MATURITYVALUE, " _
        & "status from depmst where " & StrCond & "")
    
''    Set RsPenal = AdoConnObj.Execute("Select * from DEPPENALINTDTLS where applicationdate<='" & _
''                Format(StrAppDate, "DD-MMM-YYYY") & "'")
            
    If recmst.RecordCount > 0 Then
            ''code commented on 06oct2021
'        Months = GetMonthsDiff(recmst!depdate, recmst!MaturityDate)
'        TERM = GetMonthsDiff(recmst!depdate, recmst!MaturityDate)
         Months = GetMonthsDiff(recmst!depdate, recmst!MaturityDate, StrPrematureYN)
         TERM = GetMonthsDiff(recmst!depdate, recmst!MaturityDate, StrPrematureYN)
        PrevEffDt = recmst!depdate
        intInstalmentNo = 1
        dtLastDayOfMonth = recmst!depdate
        
        If CDate(Format(StrAppDate, "DD-MM-YYYY")) <= CDate(Format(recmst!MaturityDate, "DD-MM-YYYY")) Then
            DtCalUpto = Format(StrAppDate, "DD-MM-YYYY")
        Else
            DtCalUpto = Format(recmst!MaturityDate, "DD-MM-YYYY")
        End If
        
                
        If StrPrematureYN = "Y" Then
        ''code commented on 06oct2021
         ''   NoOfMonths = GetMonthsDiff(recmst!depdate, DtCalUpto)
            NoOfMonths = GetMonthsDiff(recmst!depdate, DtCalUpto, StrPrematureYN)

            DblIntAmt = recmst!opbal * Val(DblNewRate) * NoOfMonths / 1200
            DblIntAmt = Format(Round(DblIntAmt, 2), "0.00")
            DblTotAmt = DblIntAmt
        
            StrDet = intInstalmentNo & "~" & Format(recmst!depdate, "dd-MM-YYYY") & "~" & _
            DtCalUpto & "~" & Format(recmst!opbal, "0.00") & "~" & NoOfMonths & "~" & DblIntAmt & "~0.00"
        Else
            StrDet = intInstalmentNo & "~" & Format(recmst!depdate, "dd-MM-YYYY") & "~" & _
            Format(recmst!depdate, "dd-MM-YYYY") & "~" & _
            Format(recmst!opbal, "0.00") & "~" & Format(recmst!opbal, "0.00") & "~0.00~0.00"
        End If
               
        dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
        
        Set RecLast = AdoConnObj.Execute("select last_day('" & _
            Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
            dtLastDayOfMonth = Format(RecLast!LastDate)

        Set RecCurBal = AdoConnObj.Execute("select DAYENDBAL balance from " & _
            " DEPtran where " & StrCond & " AND " & _
            " applicationdate =(select max(applicationdate) from deptran where " & _
            " " & StrCond & " and applicationdate<= to_date('" & _
            Format(dtLastDayOfMonth, "DD-MMM-YYYY") & "','dd-Mon-yyyy'))")
                
        If RecCurBal.RecordCount > 0 Then
             Balance = Val(Format(RecCurBal!Balance))
        Else
             Balance = Val(DblOpBal)
        End If
        
        DueDt = Format(recmst!depdate)
        
        
        'PreMature RD A/C Int Calculation
        If StrPrematureYN = "Y" Then
            
            dtLastDayOfMonth = recmst!depdate
            DueDt = Format(recmst!MaturityDate)
            MatDate = Format(recmst!MaturityDate)
            PrevEffDt = recmst!depdate
            
            Balance = Val(DblOpBal)
            PrevInstBalance = Balance 'Val(DblOpBal)
            
            Set recfdtran = AdoConnObj.Execute("select sum(amount) amount,applicationdate" _
                 & " from deptran where " & StrCond & " and applicationdate" _
                 & " > '" & Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "'" _
                 & "and applicationdate<='" & Format(MatDate, "dd-MMM-YYYY") & "'" _
                 & " group by applicationdate order by applicationdate", , adCmdText)
    

            If recfdtran.RecordCount > 0 Then
                           
                For intRecfdCount = 0 To recfdtran.RecordCount - 1
                                
                    intInstalmentNo = intInstalmentNo + 1
                    'intAmtInst = (recfdtran!Amount / DblOpBal)
                            
                    Balance = Balance + recfdtran!Amount
                    EffDate = Format(recfdtran!ApplicationDate, "dd-MM-yyyy")
                    
                    DblOpAmt = Format(DblOpBal, "0.00")
                    Balance = Format(Balance, "0.00")
                    'NoOfMonths = GetMonthsDiff(PrevEffDt, EffDate)
                     ''code commented on 06oct2021
                    'NoOfMonths = GetMonthsDiff(EffDate, DtCalUpto)
                     NoOfMonths = GetMonthsDiff(EffDate, DtCalUpto, StrPrematureYN)
                    
                    'DblIntAmt = Format(Round((Balance - DblOpBal) * Val(DblNewRate) / 1200, 2), "0.00") 'interest
                    DblIntAmt = recfdtran!Amount * Val(DblNewRate) * NoOfMonths / 1200
                    DblIntAmt = Format(Round(DblIntAmt, 2), "0.00")
                            
                    StrDet = StrDet & "|" & intInstalmentNo & "~" & EffDate & "~" _
                        & DtCalUpto & "~" & Format(recfdtran!Amount, "0.00") & "~" & _
                        NoOfMonths & "~" & Format(DblIntAmt, "0.00") & "~" & "0.00"

                    'PrevEffDt = EffDate
                    'PrevInstBalance = Balance
                    DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                    
                    recfdtran.MoveNext
                        
                Next intRecfdCount
            End If
            
            intInstalmentNo = intInstalmentNo + 1
            StrDet = StrDet & "|" & intInstalmentNo & "~~~~~" & Format(DblTotAmt, "0.00") & "~" & "0.00"
        
        End If 'end if Pre Matured RD A/C Int Calculation
        
        If StrPrematureYN = "N" Then

            For intcount = 2 To Months

                Set recfdtran = AdoConnObj.Execute("select sum(amount) amount,applicationdate" _
                     & " from deptran where " & StrCond & " and applicationdate" _
                     & ">=to_date('" & "1-" & _
                     Format(dtLastDayOfMonth, "MMM-YYYY") & "'," _
                     & "'dd-mon-yyyy') and applicationdate" _
                     & "<=to_date('" _
                     & Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "'," _
                     & "'dd-mon-yyyy') group by applicationdate", , adCmdText)
    

                If recfdtran.RecordCount > 0 Then
                           
                    For intRecfdCount = 0 To recfdtran.RecordCount - 1
                                
                        intAmtInst = (recfdtran!Amount / DblOpBal)
                        
                        For intAmtInstCnt = 1 To intAmtInst
                                        
                            intInstalmentNo = intInstalmentNo + 1
                            Balance = Balance + (Val(Format(recfdtran!Amount)) / intAmtInst)
                            EffDate = Format(recfdtran!ApplicationDate, "dd-MM-yyyy")
                            If Format(PrevEffDt, "dd-mm-yyyy") = "09-09-1009" Then
                               PrevEffDt = EffDate
                               DueDt = Format(DateAdd("M", 1, PrevEffDt))
                            Else
                                DueDt = Format(DateAdd("M", 1, DueDt))
                            End If
                            'OpBal
                            DblOpAmt = Format(DblOpBal, "0.00")
                            'DueDt = Format(DateAdd("M", 1, PrevEffDt))
                            Balance = Format(Balance, "0.00") 'balance
                            DblIntAmt = Format(Round((Balance - DblOpBal) * Val(DblNewRate) / 1200, 2), "0.00") 'interest

                            StrDet = StrDet & "|" & intInstalmentNo & "~" & EffDate & "~" _
                                & DueDt & "~" & Format(DblOpAmt, "0.00") & "~" & Format(Balance, "0.00") & "~" & Format(DblIntAmt, "0.00") & "~" & "0.00"
                            
                            PrevEffDt = EffDate
                            DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                                        
                        Next intAmtInstCnt
                        
                        recfdtran.MoveNext
                    Next intRecfdCount
                End If
                    
                dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
                
                Set RecLast = AdoConnObj.Execute("select last_day('" & _
                    Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
                
                dtLastDayOfMonth = Format(RecLast!LastDate)
                
            Next intcount
                
                
            If StrPrematureYN = "Y" Then
                If CDate(Format(StrAppDate, "DD-MM-YYYY")) <= CDate(Format(recmst!MaturityDate, "DD-MM-YYYY")) Then
                    DtCalUpto = Format(StrAppDate, "DD-MM-YYYY")
                Else
                    DtCalUpto = Format(recmst!MaturityDate, "DD-MM-YYYY")
                End If
               Set RESMON = AdoConnObj.Execute("SELECT MONTHS_BETWEEN(to_date('" & _
                    Format(StrAppDate, "DD-MM-YYYY") & "','DD-MM-YYYY'), to_date('" & _
                    Format(PrevEffDt, "DD-MM-YYYY") & "','DD-MM-YYYY')) MONTHS FROM DUAL", , adCmdText)

                    intMonths = Fix(RESMON!Months)
                    
                If intMonths > 0 Then
                    intInstalmentNo = intInstalmentNo + 1
                    DblIntAmt = Format(Round((Balance * Val(DblNewRate) * intMonths) / 1200, 2), "0.00")  'interest
                    
'                    StrDet = StrDet & "|" & intInstalmentNo & "~~" _
'                                             & Format(DtCalUpto, "dd-mm-yyyy") & "~~" & Format(Balance, "0.00") & "~" & Format(DblIntAmt, "0.00") & "~" & "0"

                    StrDet = StrDet & "|" & intInstalmentNo & "~" _
                        & Format(DtCalUpto, "dd-mm-yyyy") & "~~~" & Format(Balance, "0.00") & "~" & Format(DblIntAmt, "0.00") & "~" & "0"
                   
                End If
            End If
            DblTotAmt = Format(Val(DblTotAmt) + Val(DblIntAmt), "0.00")
        End If 'end if Matured RD A/C Int Calculation
        
    End If
    
    RDInterestAmount = StrDet & "$" & intInstalmentNo & "$" & _
    Format(Round(Val(DblTotAmt)), "0.00") & "$" & StrPrematureYN
    
    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If recmst.State = 1 Then recmst.Close
    Set recmst = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
           
Exit Function
errhand:
RDInterestAmount = "Error  !" & Err.Number & " : " & Err.Description
    
objErrlog.LogError "MaturityValueCalc", "RDInterestAmount", Err.Number, Err.Description

    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If recmst.State = 1 Then recmst.Close
    Set recmst = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    

End Function

Private Function GetMonthsDiff(ByVal i_FromDt As Date, ByVal i_ToDt As Date, Optional ByVal strpremat As String) As Integer

    Dim rsTmp As ADODB.Recordset
    
    GetMonthsDiff = 0
    
    If i_FromDt > i_ToDt Then
        Err.Raise 999, , "To Date Should be greater than From Date to get Months Difference"
    End If
    
    If strpremat = "Y" Then
   Set rsTmp = AdoConnObj.Execute("Select floor(months_between('" & _
        Format(i_ToDt, "dd-mmm-yyyy") & "', '" & Format(i_FromDt, "dd-mmm-yyyy") _
        & "')) mon from dual", , adCmdText)
 Else
   Set rsTmp = AdoConnObj.Execute("Select round(months_between('" & _
        Format(i_ToDt, "dd-mmm-yyyy") & "', '" & Format(i_FromDt, "dd-mmm-yyyy") _
        & "')) mon from dual", , adCmdText)
     End If
   If rsTmp.RecordCount = 0 Then
        Err.Raise 999, , "Unable to Get Months Difference between given Dates"
   End If
        
   GetMonthsDiff = rsTmp!Mon
   
   If rsTmp.State = 1 Then rsTmp.Close
   Set rsTmp = Nothing

End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
