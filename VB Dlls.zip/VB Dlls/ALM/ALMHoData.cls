VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "ALMHoData"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim ObjCont As ObjectContext
Dim ConnError
Dim AdoConnObj As New ADODB.Connection
Dim intLineNumber As Integer
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim ArrError As Variant
Dim objErrlog As Object

Private Function SingleRecordSet(sTab As Variant, sFlds As Variant, scond As Variant, _
Optional sorder As String = "1") As ADODB.Recordset
    Dim rs As New ADODB.Recordset
    
    Set rs = AdoConnObj.Execute("select " & sFlds & " from " & sTab & " where " & scond & " order by " & sorder)
    Set SingleRecordSet = rs
    
    
End Function

''Private Sub DBConnection()
''    Dim objdblink As Object
''    Dim ArrLink As Variant
''
'''************Oppening the connection to dblink*************
''On Error GoTo ErrHand
'''''' calling shared property manager for dblink
''
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
''
''    ConnError = ""
''    Set AdoConnObj = CreateObject("Adodb.Connection")
''    AdoConnObj.CursorLocation = adUseClient
''
''    'AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=esmart123;User ID=v3"
''
''    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''
''    If AdoConnObj.State = 1 Then ConnError = "Connected"
''
''Exit Sub
''
''ErrHand:
''ConnError = "Connection Failed Due To : " & Err.Number & " : " & Err.Description
''End Sub


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With

''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing
objErrlog.LogError "AML", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub


Public Function PrepareALMHOData(ByVal i_CurrencyCd As String, ByVal i_almdt As Date, _
ByVal i_UserId As String, ByVal i_MachineId As String, _
ByVal i_ApplicationDate As Date) As String

    On Error GoTo ErrHandler
    Dim ErrMsg As String, sQuery As String
    Dim sApplicationDt As String, sSSLDt As String
    Dim HOBranchCd As String
    Dim rs As New ADODB.Recordset
    Dim strMsg As String
    Dim almdate As Date
    
    Dim recBucketObj As New ADODB.Recordset, recCatgObj As New ADODB.Recordset
    Dim recGLObj As New ADODB.Recordset, recRepObj As Object
    Dim bIsDataInserted As Boolean, bTransBegin As Boolean, RowsEffected As Long
    Dim RepNo As Long, dblSumOfDayBalance As Double
    Dim sTableName As String
    
    i_CurrencyCd = UCase(Trim(i_CurrencyCd))
    i_UserId = UCase(Trim(i_UserId))
    i_MachineId = Trim(i_MachineId)
    sApplicationDt = Format(i_ApplicationDate, "dd-mmm-yyyy")
    almdate = Format(i_almdt, "dd-mmm-yyyy")
    ConnError = ""
    
    intLineNumber = 1
    Call DBConnection
    If ConnError <> "Connected" Then
        Err.Raise 999, "", ConnError
    End If
    
    'First Get HO Branch code
    intLineNumber = 2
    Set rs = SingleRecordSet("GENBANKPARM", "bankcode,bankname", "1=1")
    If rs.EOF = True Or rs.BOF = True Then
        Err.Raise 999, , "Unbale to get Head Office Branch Code"
    End If
    HOBranchCd = rs!BankCode
    Set rs = Nothing
    
    intLineNumber = 3
    Set ObjCont = GetObjectContext
    bTransBegin = True
    
    'Delete data from Below tables w.r.t. HO branch
    sQuery = "delete from ALMLOANDTLS where branchcode='" & HOBranchCd & "'" & _
    " and currencycode='" & i_CurrencyCd & "'"
    
    intLineNumber = 4
    AdoConnObj.Execute sQuery, RowsEffected
    
    sQuery = "delete from ALMDEPOSITDTLS where branchcode='" & HOBranchCd & "'" & _
    " and currencycode='" & i_CurrencyCd & "'"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    sQuery = "delete from GLDAYWISEBALANCE where branchcode='" & HOBranchCd & "'" & _
    " and currencycode='" & i_CurrencyCd & "'"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    sQuery = "delete from ALMLOANRECOVERYDTLS where branchcode='" & HOBranchCd & "'" & _
    " and currencycode='" & i_CurrencyCd & "'"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    
    'Then sum data of all the branches and then insert that with HO branch code
    
    sQuery = "INSERT INTO ALMLOANDTLS(BRANCHCODE, CURRENCYCODE, GLCODE, BUCKETCODE," & _
    " NOOFACCOUNTS, AMOUNT, OPBAL, CURBAL, ANALYSISTYPE, APPLICATIONDATE, SYSTEMDATE)" & _
    " SELECT '" & HOBranchCd & "',currencycode,glcode,bucketcode," & _
    " NVL(SUM(NVL(noofaccounts,0)),0),NVL(SUM(NVL(amount,0)),0), " & _
    " NVL(SUM(NVL(opbal,0)),0),NVL(SUM(NVL(curbal,0)),0)," & _
    " analysistype,APPLICATIONDATE,SYSDATE  From ALMLOANDTLS" & _
    " WHERE currencycode='" & i_CurrencyCd & "' " & _
    " GROUP BY currencycode,glcode,bucketcode,analysistype,APPLICATIONDATE"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    sQuery = "INSERT INTO ALMDEPOSITDTLS(BRANCHCODE, CURRENCYCODE, GLCODE, BUCKETCODE," & _
    " NOOFACCOUNTS, AMOUNT, OPBAL, CURBAL, ANALYSISTYPE, MATURITYVALUE, APPLICATIONDATE, SYSTEMDATE)" & _
    " SELECT '" & HOBranchCd & "',currencycode,glcode,bucketcode," & _
    " NVL(SUM(NVL(noofaccounts,0)),0),NVL(SUM(NVL(amount,0)),0), " & _
    " NVL(SUM(NVL(opbal,0)),0),NVL(SUM(NVL(curbal,0)),0),analysistype," & _
    " NVL(SUM(NVL(MATURITYVALUE,0)),0),APPLICATIONDATE,SYSDATE From ALMDEPOSITDTLS" & _
    " WHERE currencycode='" & i_CurrencyCd & "' " & _
    " GROUP BY currencycode,glcode,bucketcode,analysistype,APPLICATIONDATE"
    
    AdoConnObj.Execute sQuery, RowsEffected

    sQuery = "INSERT INTO GLDAYWISEBALANCE(BRANCHCODE, CURRENCYCODE, MODULEID," & _
    "GLCODE, DAYEFFECT, NOOFACCOUNTS, APPLICATIONDATE, SYSTEMYEAR)" & _
    " SELECT '" & HOBranchCd & "', CURRENCYCODE,MODULEID, GLCODE, " & _
    "NVL(SUM(NVL(DAYEFFECT,0)),0),NVL(SUM(NVL(NOOFACCOUNTS,0)),0), " & _
    "APPLICATIONDATE,SYSTEMYEAR From GLDAYWISEBALANCE " & _
    " WHERE currencycode='" & i_CurrencyCd & "'" & _
    " GROUP BY CURRENCYCODE,MODULEID, GLCODE,SYSTEMYEAR,APPLICATIONDATE"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    sQuery = "INSERT INTO ALMLOANRECOVERYDTLS(BRANCHCODE, CURRENCYCODE, GLCODE," & _
    "NOOFACCOUNTS, BUCKETCODE,RECOVERYBAL, APPLICATIONDATE,USERID,MACHINEID, SYSTEMDATE)" & _
    " SELECT '" & HOBranchCd & "', CURRENCYCODE,GLCODE,NVL(SUM(NVL(NOOFACCOUNTS,0)),0), " & _
    "BUCKETCODE,NVL(SUM(NVL(RECOVERYBAL,0)),0), " & _
    "APPLICATIONDATE,USERID,MACHINEID, SYSTEMDATE From ALMLOANRECOVERYDTLS " & _
    " WHERE currencycode='" & i_CurrencyCd & "'" & _
    " GROUP BY CURRENCYCODE,GLCODE,BUCKETCODE,APPLICATIONDATE,USERID,MACHINEID, SYSTEMDATE"
    
    AdoConnObj.Execute sQuery, RowsEffected
    
    ''Prepare ALMSSL Data
    intLineNumber = 5
    strMsg = PrepareALMSSLData(i_CurrencyCd, almdate, i_UserId, i_MachineId, sApplicationDt)
    If strMsg <> "Data Prepared Successfully" Then
        ObjCont.SetAbort
        'PrepareALMHOData = intLineNumber & " " & strMsg
        PrepareALMHOData = strMsg
        
        If recBucketObj.State = 1 Then recBucketObj.Close
        Set recBucketObj = Nothing
        If recCatgObj.State = 1 Then recCatgObj.Close
        Set recCatgObj = Nothing
        If recGLObj.State = 1 Then recGLObj.Close
        Set recGLObj = Nothing
        If recRepObj.State = 1 Then recRepObj.Close
        Set recRepObj = Nothing
        If rs.State = 1 Then rs.Close
        Set rs = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing

        Exit Function
    End If
    ''Prepare ALMIRS Data
    intLineNumber = 6
    strMsg = PrepareALMIRSData(i_CurrencyCd, almdate, i_UserId, i_MachineId, sApplicationDt)
    If strMsg <> "Data Prepared Successfully" Then
        ObjCont.SetAbort
        'PrepareALMHOData = intLineNumber & " " & strMsg
        PrepareALMHOData = strMsg
        
        If recBucketObj.State = 1 Then recBucketObj.Close
        Set recBucketObj = Nothing
        If recCatgObj.State = 1 Then recCatgObj.Close
        Set recCatgObj = Nothing
        If recGLObj.State = 1 Then recGLObj.Close
        Set recGLObj = Nothing
        If recRepObj.State = 1 Then recRepObj.Close
        Set recRepObj = Nothing
        If rs.State = 1 Then rs.Close
        Set rs = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
        
        Exit Function
    End If
    strMsg = almBckp(almdate)
    If strMsg <> "ALM Operations Closed Successfully" Then
        ObjCont.SetAbort
        PrepareALMHOData = strMsg
        
        If recBucketObj.State = 1 Then recBucketObj.Close
        Set recBucketObj = Nothing
        If recCatgObj.State = 1 Then recCatgObj.Close
        Set recCatgObj = Nothing
        If recGLObj.State = 1 Then recGLObj.Close
        Set recGLObj = Nothing
        If recRepObj.State = 1 Then recRepObj.Close
        Set recRepObj = Nothing
        If rs.State = 1 Then rs.Close
        Set rs = Nothing
        If AdoConnObj.State = 1 Then AdoConnObj.Close
        Set AdoConnObj = Nothing
        Exit Function
    End If
    
    intLineNumber = 625
    ObjCont.SetComplete
    Set ObjCont = Nothing
    bTransBegin = False
    
    PrepareALMHOData = "Data Prepared Successfully"
    
    If recBucketObj.State = 1 Then recBucketObj.Close
    Set recBucketObj = Nothing
    If recCatgObj.State = 1 Then recCatgObj.Close
    Set recCatgObj = Nothing
    If recGLObj.State = 1 Then recGLObj.Close
    Set recGLObj = Nothing
    If recRepObj.State = 1 Then recRepObj.Close
    Set recRepObj = Nothing
    If rs.State = 1 Then rs.Close
    Set rs = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    Exit Function
ErrHandler:
    
    ErrMsg = "ERROR:" & Err.Number & " " & Err.Description
    ErrMsg = Replace(ErrMsg, Chr(10), " ")
    ErrMsg = Replace(ErrMsg, Chr(13), " ")
    
    On Error Resume Next
    If bTransBegin = True Then
        ObjCont.SetAbort
    End If
    
    'PrepareALMHOData = intLineNumber & " " & ErrMsg
    PrepareALMHOData = ErrMsg
    
    objErrlog.LogError "AML", "PrepareALMHOData" & strLineno, Err.Number, Err.Description
    
    If recBucketObj.State = 1 Then recBucketObj.Close
    Set recBucketObj = Nothing
    If recCatgObj.State = 1 Then recCatgObj.Close
    Set recCatgObj = Nothing
    If recGLObj.State = 1 Then recGLObj.Close
    Set recGLObj = Nothing
    If recRepObj.State = 1 Then recRepObj.Close
    Set recRepObj = Nothing
    If rs.State = 1 Then rs.Close
    Set rs = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

End Function

Private Function PrepareALMSSLData(ByVal i_CurrencyCd As String, ByVal i_SSLDate As Date, _
ByVal i_UserId As String, ByVal i_MachineId As String, _
ByVal i_ApplicationDate As Date) As String

    On Error GoTo ErrHandler
    Dim ErrMsg As String, sQuery As String
    Dim sApplicationDt As String, sSSLDt As String
    Dim recBucketObj As New ADODB.Recordset, recCatgObj As New ADODB.Recordset
    Dim recGLObj As New ADODB.Recordset, recRepObj As Object
    Dim bIsDataInserted As Boolean, bTransBegin As Boolean, RowsEffected As Long
    Dim RepNo As Long, dblSumOfDayBalance As Double
    Dim sTableName As String
    Dim recBranchObj As New ADODB.Recordset, BranchCd As String
    
 '   Set adoconn = New ADODB.Connection
  '  adoconn.Open "Provider=MSDAORA.1;data source=v3b5;Password=esmart;User ID=v3"
    
    i_CurrencyCd = UCase(Trim(i_CurrencyCd))
    i_UserId = UCase(Trim(i_UserId))
    i_MachineId = Trim(i_MachineId)
    sApplicationDt = Format(i_ApplicationDate, "dd-mmm-yyyy")
    sSSLDt = Format(i_SSLDate, "dd-mmm-yyyy")
    
    'ConnError = ""
    
    'Open a Recordset with all the branchs
    Set recBranchObj = AdoConnObj.Execute("SELECT branchcode FROM GENBANKBRANCHMST" & _
        " WHERE status='R' ORDER BY branchcode")
        
    If recBranchObj.EOF = True And recBranchObj.BOF = True Then
        Err.Raise 999, "", "No Branch Codes were found to prepare SSL Report Data"
    End If
    
    'AdoConnObj.BeginTrans
    'bTransBegin = True
    
    Do While Not recBranchObj.EOF
        'Step 1: Get Max Report Number from "ALMSSLTEMP" table
        
        BranchCd = UCase(Trim(recBranchObj!BranchCode))
    
        Set recRepObj = CreateObject("ADODB.Recordset")
        Set recRepObj = SingleRecordSet("ALMSSLTEMP", _
            "NVL(MAX(TO_NUMBER(NVL(repno,'0')))+1,1)", _
            "repno < 999 and branchcode='" & BranchCd & "' and ALMDATE='" & sSSLDt & "'")
        
        If recRepObj.EOF = True And recRepObj.BOF = True Then
            Set recRepObj = Nothing
            Err.Raise 999, , "Report Number in SSL Report Table reached to its max value." & _
                "Please reset it to continue"
        Else
            RepNo = recRepObj(0).Value
        End If
        If recRepObj.State = 1 Then recRepObj.Close
        
        'Step 2: Insert all categories with zero balances w.r.t each bucket
        
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',CATEGORYCODE," & _
            "NARRATION,0,0,0,0,0,0,0,0,0,0,0,'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMCATEGORYMST WHERE STATUS='R'"
        
        AdoConnObj.Execute sQuery, RowsEffected
        If RowsEffected = 0 Then
            Err.Raise 999, , "ALM Categories not found to proceed..."
        End If
    
        'Step 3: Update balances w.r.t. Category code and their bucket codes
        sQuery = "CURRENCYCODE='" & i_CurrencyCd & "' AND STATUS='R'"
            
        Set recCatgObj = SingleRecordSet("ALMSSLMST", _
        "CATEGORYCODE CtgCd,BUCKETCODE BktCd,nvl(PERCENTAGE,100) Percentage", _
        sQuery, "CATEGORYCODE,BUCKETCODE")
        
        If recCatgObj.EOF = True Or recCatgObj.BOF = True Then
            Err.Raise 999, , "Mapping between ALM Categories and Bucket Codes not found to proceed..."
        End If
        
        Do While Not recCatgObj.EOF
        
            'Get GL codes which are related current Category code

            sQuery = "a.currencycode='" & _
                i_CurrencyCd & "' AND a.status='R' AND b.branchcode='" & BranchCd & _
                "' AND a.categorycode='" & recCatgObj!CtgCd & "'" & _
                " AND b.currencycode=a.currencycode AND b.glcode=a.glcode" & _
                " AND b.applicationdate = (SELECT MAX(applicationdate) FROM GLDAYWISEBALANCE" & _
                " WHERE branchcode='" & BranchCd & "' AND currencycode='" & _
                i_CurrencyCd & "' AND applicationdate <='" & sSSLDt & "')" & _
                " GROUP BY a.balancetype"

            Set recGLObj = SingleRecordSet("ALMGLMST a, GLDAYWISEBALANCE b", _
            "a.balancetype BalType,SUM(nvl(b.dayeffect,0)) DayBal", sQuery)
            
            If recGLObj.EOF = True And recGLObj.BOF = True Then

                GoTo EndOfLoop
            End If
        
        
            Do While Not recGLObj.EOF
                
                dblSumOfDayBalance = IIf(IsNull(recGLObj!DayBal), 0, recGLObj!DayBal)
                dblSumOfDayBalance = (dblSumOfDayBalance * recCatgObj!Percentage) / 100
                
                sQuery = "update ALMSSLTEMP set " & recCatgObj!BktCd & "=" & _
                recCatgObj!BktCd & " + " & dblSumOfDayBalance & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE='" & Trim(recCatgObj!CtgCd) & "'"
                
                AdoConnObj.Execute sQuery, RowsEffected
            
                recGLObj.MoveNext
            Loop
            
EndOfLoop:
            If recGLObj.State = 1 Then recGLObj.Close
            
            recCatgObj.MoveNext
            
        Loop
        If recCatgObj.State = 1 Then recCatgObj.Close
            
        'Update balances of Deposits with the Category Code 5
        sTableName = "ALMDEPOSITDTLS"
        sQuery = " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate = (" & _
            "SELECT MAX(applicationdate) FROM  " & sTableName & " WHERE " & _
            " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate<='" & _
            sSSLDt & "') and bucketcode is not null GROUP BY bucketcode"
        
        Set recBucketObj = SingleRecordSet(sTableName & " a", _
            "bucketcode BktCd,NVL(SUM(NVL(curbal,0)),0) SumBal", sQuery)
        
        Do While Not recBucketObj.EOF
            
            sQuery = "update ALMSSLTEMP set " & recBucketObj!BktCd & " = " & _
                recBucketObj!BktCd & " + " & _
                IIf(IsNull(recBucketObj!SumBal), 0, recBucketObj!SumBal) & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE=5 "
        
            AdoConnObj.Execute sQuery, RowsEffected
            
            recBucketObj.MoveNext
        Loop
        
        'Update balances of Loans with the Category Code 27
        
        sTableName = "ALMLOANDTLS"
        sQuery = " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate = (" & _
            "SELECT MAX(applicationdate) FROM  " & sTableName & " WHERE " & _
            " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate<='" & _
            sSSLDt & "') and bucketcode is not null " & _
            " GROUP BY bucketcode"
        
        Set recBucketObj = SingleRecordSet(sTableName & " a", _
            "bucketcode BktCd,NVL(SUM(NVL(curbal,0)),0) SumBal", sQuery)
        
        Do While Not recBucketObj.EOF
            
            sQuery = "update ALMSSLTEMP set " & recBucketObj!BktCd & " = " & _
                recBucketObj!BktCd & " + " & _
                IIf(IsNull(recBucketObj!SumBal), 0, recBucketObj!SumBal) & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE= 27 "
        
            AdoConnObj.Execute sQuery, RowsEffected
            
            recBucketObj.MoveNext
        Loop
        
        'Update Total Column values of "ALMSSLTEMP" table
        sQuery = "update ALMSSLTEMP set b1=nvl(B1,0), b2=nvl(B2,0),b3=nvl(B3,0)," & _
            " b4=nvl(B4,0), b5=nvl(B5,0),b6=nvl(B6,0),b7=nvl(B7,0), b8=nvl(B8,0)," & _
            " b9=nvl(B9,0),b10=nvl(B10,0)," & _
            " total = nvl(B1,0)+ nvl(B2,0)+nvl(B3,0)+nvl(B4,0)+nvl(B5,0)" & _
            " +nvl(B6,0)+nvl(B7,0)+nvl(B8,0)+nvl(B9,0)+nvl(B10,0) " & _
            " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for OutFlows
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',91," & _
            "'A. Total OutFlow',nvl(sum(nvl(b1,0)),0),nvl(sum(nvl(b2,0)),0),nvl(sum(nvl(b3,0)),0)," & _
            "nvl(sum(nvl(b4,0)),0),nvl(sum(nvl(b5,0)),0),nvl(sum(nvl(b6,0)),0)," & _
            "nvl(sum(nvl(b7,0)),0),nvl(sum(nvl(b8,0)),0),nvl(sum(nvl(b9,0)),0)," & _
            "nvl(sum(nvl(b10,0)),0),nvl(sum(nvl(total,0)),0),'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMSSLTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & " AND CATEGORYCODE<=19"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for InFlows
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',92," & _
            "'B. Total InFlow',nvl(sum(nvl(b1,0)),0),nvl(sum(nvl(b2,0)),0),nvl(sum(nvl(b3,0)),0)," & _
            "nvl(sum(nvl(b4,0)),0),nvl(sum(nvl(b5,0)),0),nvl(sum(nvl(b6,0)),0)," & _
            "nvl(sum(nvl(b7,0)),0),nvl(sum(nvl(b8,0)),0),nvl(sum(nvl(b9,0)),0)," & _
            "nvl(sum(nvl(b10,0)),0),nvl(sum(nvl(total,0)),0),'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMSSLTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & " AND CATEGORYCODE>19" & _
            " AND CATEGORYCODE<91"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for MisMatch
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',93," & _
            "'C. Mismatch',nvl(a.b1,0) + nvl(b.b1,0), " & _
            " nvl(a.b2,0) + nvl(b.b2,0), " & _
            " nvl(a.b3,0) + nvl(b.b3,0), " & _
            " nvl(a.b4,0) + nvl(b.b4,0), " & _
            " nvl(a.b5,0) + nvl(b.b5,0), " & _
            " nvl(a.b6,0) + nvl(b.b6,0), " & _
            " nvl(a.b7,0) + nvl(b.b7,0), " & _
            " nvl(a.b8,0) + nvl(b.b8,0), " & _
            " nvl(a.b9,0) + nvl(b.b9,0), " & _
            " nvl(a.b10,0) + nvl(b.b10,0), " & _
            " nvl(a.total,0) + nvl(b.total,0), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMSSLTEMP a, ALMSSLTEMP b where " & _
            " a.BRANCHCODE='" & BranchCd & "' and a.CURRENCYCODE='" & i_CurrencyCd & _
            "' and a.ALMDATE='" & sSSLDt & "' and a.repno=" & RepNo & " and a.categorycode=91" & _
            " and a.BRANCHCODE = b.BRANCHCODE and a.CURRENCYCODE = b.CURRENCYCODE" & _
            " and a.ALMDATE=b.ALMDATE and a.repno=b.repno and b.categorycode=92"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for Cumulative MisMatch
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',94," & _
            "'D. Cumulative Mismatch',nvl(b1,0), " & _
            " nvl(b1,0) + nvl(b2,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0)+ nvl(b9,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0)+ nvl(b9,0)+ nvl(b10,0), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMSSLTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sSSLDt & "' and repno=" & RepNo & " AND CATEGORYCODE=93"
    
        AdoConnObj.Execute sQuery, RowsEffected
           
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for 93 as % to 91
        sQuery = "INSERT INTO ALMSSLTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',95," & _
            "'E. C as % to A', DECODE(NVL(b.b1,0),0,0,(NVL(a.b1,0)*100)/NVL(b.b1,0)), " & _
            " DECODE(NVL(b.b2,0),0,0,(NVL(a.b2,0)*100)/NVL(b.b2,0))," & _
            " DECODE(NVL(b.b3,0),0,0,(NVL(a.b3,0)*100)/NVL(b.b3,0)), " & _
            " DECODE(NVL(b.b4,0),0,0,(NVL(a.b4,0)*100)/NVL(b.b4,0)), " & _
            " DECODE(NVL(b.b5,0),0,0,(NVL(a.b5,0)*100)/NVL(b.b5,0))," & _
            " DECODE(NVL(b.b6,0),0,0,(NVL(a.b6,0)*100)/NVL(b.b6,0)), " & _
            " DECODE(NVL(b.b7,0),0,0,(NVL(a.b7,0)*100)/NVL(b.b7,0)), " & _
            " DECODE(NVL(b.b8,0),0,0,(NVL(a.b8,0)*100)/NVL(b.b8,0)), " & _
            " DECODE(NVL(b.b9,0),0,0,(NVL(a.b9,0)*100)/NVL(b.b9,0)), " & _
            " DECODE(NVL(b.b10,0),0,0,(NVL(a.b10,0)*100)/NVL(b.b10,0)), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sSSLDt & "'," & _
            RepNo & " FROM ALMSSLTEMP a, ALMSSLTEMP b where " & _
            " a.BRANCHCODE='" & BranchCd & "' and a.CURRENCYCODE='" & i_CurrencyCd & _
            "' and a.ALMDATE='" & sSSLDt & "' and a.repno=" & RepNo & " and a.categorycode=93" & _
            " and a.BRANCHCODE = b.BRANCHCODE and a.CURRENCYCODE = b.CURRENCYCODE" & _
            " and a.ALMDATE=b.ALMDATE and a.repno=b.repno and b.categorycode=91"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        recBranchObj.MoveNext
    Loop
    If recBranchObj.State = 1 Then recBranchObj.Close

    bTransBegin = False
    PrepareALMSSLData = "Data Prepared Successfully"
    
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

    Exit Function
ErrHandler:
    
    ErrMsg = "ERROR:" & Err.Number & " " & Err.Description
    ErrMsg = Replace(ErrMsg, Chr(10), " ")
    ErrMsg = Replace(ErrMsg, Chr(13), " ")
    objErrlog.LogError "AML", "PrepareALMSSLData", Err.Number, Err.Description
    
    On Error Resume Next
    If bTransBegin = True Then
        'AdoConnObj.RollbackTrans
    End If
    'AdoConnObj.Close
    
    PrepareALMSSLData = ErrMsg
    
    If recGLObj.State = 1 Then recGLObj.Close
    Set recGLObj = Nothing
    If recRepObj.State = 1 Then recRepObj.Close
    Set recRepObj = Nothing
    If recBranchObj.State = 1 Then recBranchObj.Close
    Set recBranchObj = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing


    
End Function

Private Function PrepareALMIRSData(ByVal i_CurrencyCd As String, ByVal i_IRSDate As Date, _
ByVal i_UserId As String, ByVal i_MachineId As String, _
ByVal i_ApplicationDate As Date) As String

    On Error GoTo ErrHandler
    Dim ErrMsg As String, sQuery As String
    Dim sApplicationDt As String, sIRSDt As String
    Dim recBucketObj As New ADODB.Recordset, recCatgObj As New ADODB.Recordset
    Dim recGLObj As New ADODB.Recordset, recRepObj As Object
    Dim bIsDataInserted As Boolean, bTransBegin As Boolean, RowsEffected As Long
    Dim RepNo As Long, dblSumOfDayBalance As Double
    Dim sTableName As String
    Dim recBranchObj As New ADODB.Recordset, BranchCd As String
        
    i_CurrencyCd = UCase(Trim(i_CurrencyCd))
    i_UserId = UCase(Trim(i_UserId))
    i_MachineId = Trim(i_MachineId)
    sApplicationDt = Format(i_ApplicationDate, "dd-mmm-yyyy")
    sIRSDt = Format(i_IRSDate, "dd-mmm-yyyy")
    
    intLineNumber = 61
    'Open a Recordset with all the branchs
    Set recBranchObj = AdoConnObj.Execute("SELECT branchcode FROM GENBANKBRANCHMST" & _
        " WHERE status='R' ORDER BY branchcode")
        
    If recBranchObj.EOF = True Or recBranchObj.BOF = True Then
        Err.Raise 999, "", "No Branch Codes were found to prepare SSL Report Data"
    End If
    
    'AdoConnObj.BeginTrans
    bTransBegin = True
    
    Do While Not recBranchObj.EOF
    
        'Step 1: Get Max Report Number from "ALMIRSTEMP" table
        
        BranchCd = UCase(Trim(recBranchObj!BranchCode))
        intLineNumber = 62
        Set recRepObj = CreateObject("ADODB.Recordset")
        Set recRepObj = SingleRecordSet("ALMIRSTEMP", _
            "NVL(MAX(TO_NUMBER(NVL(repno,'0')))+1,1)", _
            "repno < 999 and branchcode='" & BranchCd & "' and ALMDATE='" & sIRSDt & "'")
    
        If recRepObj.EOF = True And recRepObj.BOF = True Then
            Set recRepObj = Nothing
            Err.Raise 999, , "Report Number in Temp Table reached to its max value." & _
                "Please reset it to continue"
        Else
            RepNo = recRepObj(0).Value
        End If
        Set recRepObj = Nothing
    
        'Step 2: Insert all categories with zero balances w.r.t each bucket
    
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',CATEGORYCODE," & _
            "NARRATION,0,0,0,0,0,0,0,0,0,0,0,'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMCATEGORYMST WHERE STATUS='R'"
        
        intLineNumber = 63
        AdoConnObj.Execute sQuery, RowsEffected
        If RowsEffected = 0 Then
            Err.Raise 999, , "ALM Categories not found to proceed..."
        End If
        
        'Step 3: Update balances w.r.t. Category code and their bucket codes
        sQuery = "CURRENCYCODE='" & i_CurrencyCd & "' AND STATUS='R'"
        
        intLineNumber = 64
        Set recCatgObj = SingleRecordSet("ALMIRSMST", _
        "CATEGORYCODE CtgCd,BUCKETCODE BktCd,nvl(PERCENTAGE,100) Percentage", _
        sQuery, "CATEGORYCODE,BUCKETCODE")
        
        If recCatgObj.EOF = True Or recCatgObj.BOF = True Then
            Err.Raise 999, , "Mapping between ALM Categories and Bucket Codes not found to proceed..."
        End If
        
        Do While Not recCatgObj.EOF
            
            'Get GL codes which are related current Category code
    '        sQuery = "a.currencycode='" & _
    '            i_CurrencyCd & "' AND a.status='R' AND b.branchcode='" & BranchCd & _
    '            "' AND a.categorycode='" & recCatgObj!CtgCd & "'" & _
    '            " AND b.currencycode=a.currencycode AND b.glcode=a.glcode" & _
    '            " AND b.applicationdate = (SELECT MAX(applicationdate) FROM GLDAYWISEBALANCE" & _
    '            " WHERE branchcode='" & BranchCd & "' AND currencycode='" & _
    '            i_CurrencyCd & "' AND applicationdate <='" & sIRSDt & "')" & _
    '            " AND ( (UPPER(TRIM(a.balancetype))='CR' AND NVL(b.dayeffect,0)>0)" & _
    '            "    OR (UPPER(TRIM(a.balancetype))='DR' AND NVL(b.dayeffect,0)<0) )" & _
    '            " GROUP BY a.balancetype"
    
            sQuery = "a.currencycode='" & _
                i_CurrencyCd & "' AND a.status='R' AND b.branchcode='" & BranchCd & _
                "' AND a.categorycode='" & recCatgObj!CtgCd & "'" & _
                " AND b.currencycode=a.currencycode AND b.glcode=a.glcode" & _
                " AND b.applicationdate = (SELECT MAX(applicationdate) FROM GLDAYWISEBALANCE" & _
                " WHERE branchcode='" & BranchCd & "' AND currencycode='" & _
                i_CurrencyCd & "' AND applicationdate <='" & sIRSDt & "')" & _
                " GROUP BY a.balancetype"
    
            intLineNumber = 65
            Set recGLObj = SingleRecordSet("ALMGLMST a, GLDAYWISEBALANCE b", _
            "a.balancetype BalType,SUM(nvl(b.dayeffect,0)) DayBal", sQuery)
            
            If recGLObj.EOF = True And recGLObj.BOF = True Then
    '            Err.Raise 999, , "GL Codes were not found for the ALM Category :" & _
    '                recCatgObj(0).Value & " (OR) GL Balances were not found for the date:" & _
    '                sIRSDt
                GoTo EndOfLoop
            End If
            
            
            Do While Not recGLObj.EOF
                
                dblSumOfDayBalance = IIf(IsNull(recGLObj!DayBal), 0, recGLObj!DayBal)
                dblSumOfDayBalance = (dblSumOfDayBalance * recCatgObj!Percentage) / 100
                intLineNumber = 66
                sQuery = "update ALMIRSTEMP set " & recCatgObj!BktCd & "=" & _
                recCatgObj!BktCd & " + " & dblSumOfDayBalance & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE='" & Trim(recCatgObj!CtgCd) & "'"
                
                AdoConnObj.Execute sQuery, RowsEffected
            
                recGLObj.MoveNext
            Loop
            
EndOfLoop:
            Set recGLObj = Nothing
            recCatgObj.MoveNext
            
        Loop
        Set recCatgObj = Nothing
        
        'Update balances of Deposits with the Category Code 5
        sTableName = "ALMDEPOSITDTLS"
        sQuery = " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate = (" & _
            "SELECT MAX(applicationdate) FROM  " & sTableName & " WHERE " & _
            " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate<='" & _
            sIRSDt & "') and bucketcode is not null GROUP BY bucketcode"
        
        intLineNumber = 67
        Set recBucketObj = SingleRecordSet(sTableName & " a", _
            "bucketcode BktCd,NVL(SUM(NVL(curbal,0)),0) SumBal", sQuery)
        
        Do While Not recBucketObj.EOF
            
            sQuery = "update ALMIRSTEMP set " & recBucketObj!BktCd & " = " & _
                recBucketObj!BktCd & " + " & _
                IIf(IsNull(recBucketObj!SumBal), 0, recBucketObj!SumBal) & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE=5 "
            intLineNumber = 68
            AdoConnObj.Execute sQuery, RowsEffected
            
            recBucketObj.MoveNext
        Loop
        
        'Update balances of Loans with the Category Code 27
        
        sTableName = "ALMLOANDTLS"
        sQuery = " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate = (" & _
            "SELECT MAX(applicationdate) FROM  " & sTableName & " WHERE " & _
            " branchcode='" & BranchCd & "' AND currencycode='" & _
            i_CurrencyCd & "' AND analysistype='R' AND applicationdate<='" & _
            sIRSDt & "') and bucketcode is not null " & _
            " GROUP BY bucketcode"
        
        intLineNumber = 69
        Set recBucketObj = SingleRecordSet(sTableName & " a", _
            "bucketcode BktCd,NVL(SUM(NVL(curbal,0)),0) SumBal", sQuery)
        
        Do While Not recBucketObj.EOF
            
            intLineNumber = 611
            sQuery = "update ALMIRSTEMP set " & recBucketObj!BktCd & " = " & _
                recBucketObj!BktCd & " + " & _
                IIf(IsNull(recBucketObj!SumBal), 0, recBucketObj!SumBal) & _
                " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
                "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & _
                " and CATEGORYCODE= 27 "
        
            AdoConnObj.Execute sQuery, RowsEffected
            
            recBucketObj.MoveNext
        Loop
        
        intLineNumber = 612
        'UPDATE BUCKET 3 = BUCKET 1 + BUCKET 2 + BUCKET 3
        sQuery = "update ALMIRSTEMP set B3 = NVL(B1,0)+NVL(B2,0)+NVL(B3,0)" & _
            ", b1=0,b2=0" & _
            " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & _
            " and CATEGORYCODE IN (5,27) "
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 613
        'Update Total Column values of "ALMIRSTEMP" table
        sQuery = "update ALMIRSTEMP set b1=nvl(B1,0), b2=nvl(B2,0),b3=nvl(B3,0)," & _
            " b4=nvl(B4,0), b5=nvl(B5,0),b6=nvl(B6,0),b7=nvl(B7,0), b8=nvl(B8,0)," & _
            " b9=nvl(B9,0),b10=nvl(B10,0)," & _
            " total = nvl(B1,0)+ nvl(B2,0)+nvl(B3,0)+nvl(B4,0)+nvl(B5,0)" & _
            " +nvl(B6,0)+nvl(B7,0)+nvl(B8,0)+nvl(B9,0)+nvl(B10,0) " & _
            " where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 614
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for OutFlows
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',91," & _
            "'A. Total Liabilities',nvl(sum(nvl(b1,0)),0),nvl(sum(nvl(b2,0)),0),nvl(sum(nvl(b3,0)),0)," & _
            "nvl(sum(nvl(b4,0)),0),nvl(sum(nvl(b5,0)),0),nvl(sum(nvl(b6,0)),0)," & _
            "nvl(sum(nvl(b7,0)),0),nvl(sum(nvl(b8,0)),0),nvl(sum(nvl(b9,0)),0)," & _
            "nvl(sum(nvl(b10,0)),0),nvl(sum(nvl(total,0)),0),'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMIRSTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & " AND CATEGORYCODE<=19"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 615
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for InFlows
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',92," & _
            "'B. Total Assets',nvl(sum(nvl(b1,0)),0),nvl(sum(nvl(b2,0)),0),nvl(sum(nvl(b3,0)),0)," & _
            "nvl(sum(nvl(b4,0)),0),nvl(sum(nvl(b5,0)),0),nvl(sum(nvl(b6,0)),0)," & _
            "nvl(sum(nvl(b7,0)),0),nvl(sum(nvl(b8,0)),0),nvl(sum(nvl(b9,0)),0)," & _
            "nvl(sum(nvl(b10,0)),0),nvl(sum(nvl(total,0)),0),'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMIRSTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & " AND CATEGORYCODE>19" & _
            " AND CATEGORYCODE<91"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 616
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for MisMatch
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, TOTAL, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',93," & _
            "'C. GAP',nvl(a.b1,0) + nvl(b.b1,0), " & _
            " nvl(a.b2,0) + nvl(b.b2,0), " & _
            " nvl(a.b3,0) + nvl(b.b3,0), " & _
            " nvl(a.b4,0) + nvl(b.b4,0), " & _
            " nvl(a.b5,0) + nvl(b.b5,0), " & _
            " nvl(a.b6,0) + nvl(b.b6,0), " & _
            " nvl(a.b7,0) + nvl(b.b7,0), " & _
            " nvl(a.b8,0) + nvl(b.b8,0), " & _
            " nvl(a.b9,0) + nvl(b.b9,0), " & _
            " nvl(a.b10,0) + nvl(b.b10,0), " & _
            " nvl(a.total,0) + nvl(b.total,0), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMIRSTEMP a, ALMIRSTEMP b where " & _
            " a.BRANCHCODE='" & BranchCd & "' and a.CURRENCYCODE='" & i_CurrencyCd & _
            "' and a.ALMDATE='" & sIRSDt & "' and a.repno=" & RepNo & " and a.categorycode=91" & _
            " and a.BRANCHCODE = b.BRANCHCODE and a.CURRENCYCODE = b.CURRENCYCODE" & _
            " and a.ALMDATE=b.ALMDATE and a.repno=b.repno and b.categorycode=92"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 617
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for Cumulative MisMatch
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',94," & _
            "'D. Cumulative GAP',nvl(b1,0), " & _
            " nvl(b1,0) + nvl(b2,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0)+ nvl(b9,0), " & _
            " nvl(b1,0) + nvl(b2,0)+ nvl(b3,0)+ nvl(b4,0)+ nvl(b5,0)+ nvl(b6,0)+ nvl(b7,0)+ nvl(b8,0)+ nvl(b9,0)+ nvl(b10,0), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMIRSTEMP where BRANCHCODE='" & BranchCd & "' and CURRENCYCODE='" & i_CurrencyCd & _
            "' and ALMDATE='" & sIRSDt & "' and repno=" & RepNo & " AND CATEGORYCODE=93"
    
        AdoConnObj.Execute sQuery, RowsEffected
           
        intLineNumber = 618
        'Insert a Row with Bucket wise Totals i.e. Column wise totals for 93 as % to 91
        sQuery = "INSERT INTO ALMIRSTEMP(BRANCHCODE, CURRENCYCODE, CATEGORYCODE, " & _
            "CATEGORYDESCRIPTION,B1, B2, B3, B4, b5,B6, B7, B8, B9, B10, " & _
            "APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, ALMDATE,repno)" & _
            " SELECT '" & BranchCd & "','" & i_CurrencyCd & "',95," & _
            "'E. C as % to A', DECODE(NVL(b.b1,0),0,0,(NVL(a.b1,0)*100)/NVL(b.b1,0)), " & _
            " DECODE(NVL(b.b2,0),0,0,(NVL(a.b2,0)*100)/NVL(b.b2,0))," & _
            " DECODE(NVL(b.b3,0),0,0,(NVL(a.b3,0)*100)/NVL(b.b3,0)), " & _
            " DECODE(NVL(b.b4,0),0,0,(NVL(a.b4,0)*100)/NVL(b.b4,0)), " & _
            " DECODE(NVL(b.b5,0),0,0,(NVL(a.b5,0)*100)/NVL(b.b5,0))," & _
            " DECODE(NVL(b.b6,0),0,0,(NVL(a.b6,0)*100)/NVL(b.b6,0)), " & _
            " DECODE(NVL(b.b7,0),0,0,(NVL(a.b7,0)*100)/NVL(b.b7,0)), " & _
            " DECODE(NVL(b.b8,0),0,0,(NVL(a.b8,0)*100)/NVL(b.b8,0)), " & _
            " DECODE(NVL(b.b9,0),0,0,(NVL(a.b9,0)*100)/NVL(b.b9,0)), " & _
            " DECODE(NVL(b.b10,0),0,0,(NVL(a.b10,0)*100)/NVL(b.b10,0)), " & _
            "'" & sApplicationDt & "'" & _
            ",'" & i_UserId & "','" & i_MachineId & "','A','R','" & sIRSDt & "'," & _
            RepNo & " FROM ALMIRSTEMP a, ALMIRSTEMP b where " & _
            " a.BRANCHCODE='" & BranchCd & "' and a.CURRENCYCODE='" & i_CurrencyCd & _
            "' and a.ALMDATE='" & sIRSDt & "' and a.repno=" & RepNo & " and a.categorycode=93" & _
            " and a.BRANCHCODE = b.BRANCHCODE and a.CURRENCYCODE = b.CURRENCYCODE" & _
            " and a.ALMDATE=b.ALMDATE and a.repno=b.repno and b.categorycode=91"
    
        AdoConnObj.Execute sQuery, RowsEffected
        
        intLineNumber = 619
        recBranchObj.MoveNext
    Loop
    
    
    bTransBegin = False
    PrepareALMIRSData = "Data Prepared Successfully"
    
    intLineNumber = 620
    
    If recBucketObj.State = 1 Then recBucketObj.Close
    Set recBucketObj = Nothing
    If recCatgObj.State = 1 Then recCatgObj.Close
    Set recCatgObj = Nothing
    If recGLObj.State = 1 Then recGLObj.Close
    Set recGLObj = Nothing
    If recBranchObj.State = 1 Then recBranchObj.Close
    Set recBranchObj = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing

    Exit Function
ErrHandler:
    
    ErrMsg = "ERROR:" & Err.Number & " " & Err.Description
    ErrMsg = Replace(ErrMsg, Chr(10), " ")
    ErrMsg = Replace(ErrMsg, Chr(13), " ")
    
    PrepareALMIRSData = ErrMsg
    
    objErrlog.LogError "AML", "PrepareALMRSData", Err.Number, Err.Description
    
    If recBucketObj.State = 1 Then recBucketObj.Close
    Set recBucketObj = Nothing
    If recCatgObj.State = 1 Then recCatgObj.Close
    Set recCatgObj = Nothing
    If recGLObj.State = 1 Then recGLObj.Close
    Set recGLObj = Nothing
    If recBranchObj.State = 1 Then recBranchObj.Close
    Set recBranchObj = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
End Function

''ALM Day End
Private Function almBckp(ByVal i_almdate As Date) As String
On Error GoTo ErrHandler

Dim rsBckp As New ADODB.Recordset
Dim rsdate As New ADODB.Recordset
Dim strbckp As String
Dim strqry As String
Dim almdate As Date

almdate = Format(i_almdate, "dd-mmm-yyyy")

strqry = "select TABLENAME, BACKUPTABLENAME from ALMBACKUPINFO"
Set rsdate = AdoConnObj.Execute(strqry)

'AdoConnObj.BeginTrans

If Not rsdate.EOF And Not rsdate.BOF Then
    rsdate.MoveFirst
    Do Until rsdate.EOF = True
        strbckp = "insert into " & rsdate!BACKUPTABLENAME & " select * from " & rsdate!tablename
        AdoConnObj.Execute (strbckp)
        ''Delete records from main tables other than master tables
        If Right(rsdate!tablename, 3) <> "MST" Then
            AdoConnObj.Execute ("delete from " & rsdate!tablename)
        End If
        rsdate.MoveNext
    Loop
End If
''insert into MSTBKP tables with application date as ALM Date
strbckp = "INSERT INTO ALMCATEGORYMSTBKP SELECT CATEGORYCODE," & _
        "NARRATION,'" & Format(almdate, "dd-mmm-yyyy") & "', USERID," & _
        "MACHINEID, STATUS,SYSTEMDATE, GROUPCODE FROM  ALMCATEGORYMST"
Set rsdate = AdoConnObj.Execute(strbckp)

strbckp = "insert into ALMTIMEBUCKETSMSTBKP select CURRENCYCODE, BUCKETCODE," & _
        "FROMTIMEPERIOD, FROMTIMEPERIODTYPE, TOTIMEPERIOD, TOTIMEPERIODTYPE," & _
        "SENSITIVITY, TOLERANCE,'" & Format(almdate, "dd-mmm-yyyy") & "'," & _
        "USERID, MACHINEID, STATUS, SYSTEMDATE from ALMTIMEBUCKETSMST"
Set rsdate = AdoConnObj.Execute(strbckp)

strbckp = "insert into ALMGLMSTBKP select GLCODE, CURRENCYCODE, GLDESCRIPTION," & _
        "CATEGORYCODE, CATEGORYDESCRIPTION, SENSITIVITY, TOLERANCE, BALANCETYPE,'" & _
        Format(almdate, "dd-mmm-yyyy") & "', USERID, MACHINEID," & _
        "STATUS, SYSTEMDATE from ALMGLMST"
Set rsdate = AdoConnObj.Execute(strbckp)

strbckp = "insert into ALMGROUPMSTBKP select GROUPCODE, GROUPDESCRIPTION," & _
        "USERID, MACHINEID, STATUS, SYSTEMDATE,'" & Format(almdate, "dd-mmm-yyyy") & _
        "' from ALMGROUPMST"
Set rsdate = AdoConnObj.Execute(strbckp)

''update table with status='C'
AdoConnObj.Execute ("update GENSYSTEMACTIVITYLOG set status='C' " & _
            " where ACTIVITYID='ALM' and FROMDATE='" & _
            Format(almdate, "dd-mmm-yyyy") & "' and TODATE='" & Format(almdate, "dd-mmm-yyyy") & "'")

almBckp = "ALM Operations Closed Successfully"

    If rsBckp.State = 1 Then rsBckp.Close
    Set rsBckp = Nothing
    If rsdate.State = 1 Then rsdate.Close
    Set rsdate = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing



Exit Function

ErrHandler:
ErrMsg = "ERROR:" & Err.Number & " " & Err.Description
ErrMsg = Replace(ErrMsg, Chr(10), " ")
ErrMsg = Replace(ErrMsg, Chr(13), " ")

almBckp = ErrMsg

objErrlog.LogError "AML", "almBckp", Err.Number, Err.Description

If rsBckp.State = 1 Then rsBckp.Close
Set rsBckp = Nothing
If rsdate.State = 1 Then rsdate.Close
Set rsdate = Nothing
If AdoConnObj.State = 1 Then AdoConnObj.Close
Set AdoConnObj = Nothing
End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
