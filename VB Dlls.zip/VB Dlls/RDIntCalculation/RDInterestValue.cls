VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "RDInterestValue"
Attribute VB_GlobalNameSpace = True
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Dim objErrlog As Object
Dim Maturityvalue As Double
Dim Strmsg As String, Tilldate As String
Dim BreakDate  As String, DateTill As String, DiffMonths As Double, NewROI As Double
Dim NoOfQuarters As Double
Dim Factor As Double
Dim TERM As String
Dim Prd As Integer, Year As Double, Mon As Double, Day As Double
Dim PrincipalAmount As Double, Chkstr As Integer
Dim Count, i, SimIntDays, Strperiod As Double
Dim TotQuarters, intcount, RemainingDays, Intamt
Dim dblNoOfDaysPerYear, InMonths, Monstr
Public ConnError As String 'error object
Public AdoConnObj As ADODB.Connection ' Connection Object
Dim objdblink As Object
Dim ArrLink As Variant
Dim recmst As Recordset
Dim StrInsTabName As String
Dim StrInsFldNames As String
Dim StrInsValues() As Variant
Dim ObjTrans As Object
Dim objError As Object
Dim strComponent As String
Dim ErrNum As String
Dim errDesc As String
Dim clntDesc As String
Const blnDebug As Boolean = True
Dim ArrError As Variant

Public Function GetMaturityvalue(Period As String, EffDate As String, _
    Matdate As String, Amount As Double, CompoundTerm As String, _
    InstalmentsYN As String, ROI As Double) As Variant

    Dim Prddtls
    On Error GoTo errhand
    dblNoOfDaysPerYear = 36500
    If Period = "" Then
        If EffDate = "" Or Matdate = "" Then
            GetMaturityvalue = "Error  ! Please send required parameters"
            Exit Function
        End If
    End If
'----Either two dates or period can be given as input for Mat value Calculation---

    If EffDate <> "" And Matdate <> "" Then
        Tilldate = CDate(Matdate)
        BreakDate = CDate(EffDate)
    End If
    
    If Period <> "" Then
        Prddtls = Split(Period, "|")
        Year = Prddtls(0)
        Mon = Prddtls(1)
        Day = Prddtls(2)
        If IsNull(Year) Then
            Year = 0
        End If
        If IsNull(Mon) Then
            Mon = 0
        End If
        If IsNull(Day) Then
            Day = 0
        End If
    '------------------If period is send as input then-----------------------
    '------------BreakDate is assumed as this date for reference only--------
        BreakDate = CDate("1-jan-2000")
        Tilldate = DateAdd("YYYY", Year, BreakDate)
        Tilldate = DateAdd("M", Mon, Tilldate)
        Tilldate = DateAdd("D", Day, Tilldate)
        Tilldate = CDate(Tilldate)
    End If
    
    NewROI = ROI
    PrincipalAmount = Amount
    
    Count = 0
    DateTill = CDate(BreakDate)
    DateTill = CDate(DateTill)
 '--------Finding exact number of full months between two periods---------------
'    For i = 1 To 1000
'        DateTill = DateAdd("M", 1, CDate(DateTill))
'        If CDate(DateTill) > CDate(Tilldate) Then
'            Exit For
'        End If
'        Count = Count + 1
'    Next
'    DiffMonths = Count
DiffMonths = Fix(DateDiff("M", BreakDate, Tilldate))
'-----------------------Simple Int calc------------------------------------------
'----------If Compound term is null component calculates Simple Interest---------
        If CompoundTerm = "" And InstalmentsYN = "N" Or CompoundTerm = "N" And InstalmentsYN = "N" Then

        Strperiod = DiffMonths / 12
        BreakDate = DateAdd("M", DiffMonths, BreakDate)
        RemainingDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        If RemainingDays > 0 Then
            Strperiod = Strperiod + (RemainingDays / 365)
        End If
        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
        GetMaturityvalue = CDbl(PrincipalAmount)
        Exit Function
    End If
    '-----------------------Simple Int Calc Ends----------------------------------
    
    If InstalmentsYN = "Y" Then  'For Recurring Deposits
       GetMaturityvalue = CDbl(getRDMaturityValue(CDate(Matdate), CDate(EffDate), Amount, CDbl(ROI)))
    Else
        '-----------------------Compound Int Calc Starts------------------------------
        Select Case CompoundTerm
            Case "Q"    'Quarterly
            If DiffMonths >= 3 Then
                NoOfQuarters = DiffMonths / 3
                Factor = 0.0025
                TERM = "Q"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                GetMaturityvalue = "Error  ! Period does not satisfy one Quarter"
            End If
            Case "M"    'Monthly
            If DiffMonths >= 1 Then
                NoOfQuarters = DiffMonths
                Factor = 1 / 1200
                TERM = "M"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                GetMaturityvalue = "Error  ! Period does not satisfy one Month"
            End If
            Case "H"    'Half Yearly
            If DiffMonths >= 6 Then
                NoOfQuarters = DiffMonths / 6
                Factor = 0.005
                TERM = "Q"
                Prd = 2
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                GetMaturityvalue = "Error  ! Period does not satisfy one Halfyear"
            End If
            Case "Y"    'Yearly
            If DiffMonths >= 12 Then
                NoOfQuarters = DiffMonths / 12
                Factor = 0.01
                TERM = "YYYY"
                Prd = 1
                Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                GetMaturityvalue = PrincipalAmount
            Else
                GetMaturityvalue = "Error  ! Period does not satisfy one Year"
            End If
        End Select
    End If
  Exit Function
errhand:
GetMaturityvalue = "Error  !" & Err.Number & " : " & Err.Description
GetMaturityvalue = Replace(GetMaturityvalue, Chr(10), "")
GetMaturityvalue = Replace(GetMaturityvalue, Chr(13), "")

End Function
Private Sub CompCalculation(Fact As Double, Quarters As Double, TERM As String, Prd As Integer)
   
  '-------------Full period calculation------------------------------------------
    dblNoOfDaysPerYear = 36500
    For intcount = 1 To Quarters
        BreakDate = DateAdd(TERM, Prd, CDate(BreakDate))
        Intamt = CDbl(PrincipalAmount) * CDbl(NewROI) * Fact
        PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
    Next
  '-------------Remaining Months calculation--------------------------------------
    Count = 0
    DateTill = BreakDate
    For i = 1 To 1000
        DateTill = DateAdd("M", 1, DateTill)
        If CDate(DateTill) > CDate(Tilldate) Then
            Exit For
        End If
        Count = Count + 1
    Next
    InMonths = Count
    BreakDate = DateAdd("M", InMonths, BreakDate)
    PrincipalAmount = CDbl(PrincipalAmount) + ((CDbl(PrincipalAmount) * (InMonths / 12) * CDbl(NewROI)) / 100)
  '-------------Remaining Days calculation----------------------
  
    RemainingDays = DateDiff("D", BreakDate, Tilldate)
    If RemainingDays > 0 Then
        Intamt = (CDbl(PrincipalAmount) * CDbl(NewROI) * _
                       CDbl(RemainingDays)) / CDbl(dblNoOfDaysPerYear)
        PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
    End If
    
End Sub


Private Function getRDMaturityValue(MaturityDate As Date, _
                                   IntEffectiveDate As Date, _
                                   InstalmentAmt As Double, _
                                   ROI As Single) As Double
Dim NoOfQuarters As Integer
Dim FirstQuarterAmt As Double
Dim RemainingDays As Integer
'If Not IsDate(MaturityDate) Or Not IsDate(IntEffectiveDate) Then
'MsgBox "Either Maturity date or Interest Effective Date is null." & Chr(13) & _
'       "System cannot calculate Maturity Amount", vbInformation
'Exit Function
'End If
'New formula is Introduced on 18-01-2003 don't change this formula without informing to the project manager
    NoOfQuarters = Fix(DateDiff("M", IntEffectiveDate, MaturityDate) / 3)
    RemainingDays = DateDiff("D", DateAdd("M", NoOfQuarters * 3, IntEffectiveDate), MaturityDate)
    FirstQuarterAmt = InstalmentAmt * (3 + ROI / 200)
    getRDMaturityValue = getRDCompundedValue(NoOfQuarters, FirstQuarterAmt, ROI)
    'After Quarter, Calculate Simple Interest and add it.
    
    If RemainingDays > 0 Then
    getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * 31 * ROI / 36500)
    End If
    If RemainingDays > 31 Then
        getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * (RemainingDays - 31) * ROI / 36500)
    End If
    
'New formula Ends here
End Function
Private Function getRDCompundedValue(Quarter As Integer, _
                                    InstalmentAmt As Double, _
                                    ROI As Single) As Double
Dim SubTotal As Double
If Quarter <= 0 Then getRDCompundedValue = 0: Exit Function
SubTotal = InstalmentAmt * (1 + ROI / 400) ^ (Quarter - 1) + _
           getRDCompundedValue(Quarter - 1, InstalmentAmt, ROI)
getRDCompundedValue = SubTotal
End Function

Public Function GetInterestAmount(PrincipalAmount As Double, CompoundYesNo As String, _
    CompoundTerm As String, ROI As Double, IntPeriodicity As String) As Variant
    Dim Prddtls
    On Error GoTo errhand
    dblNoOfDaysPerYear = 36500
    Dim IntAmount As Double
    Dim Period As Integer
    
    ''''''''''''''''''''''''''''' Mandatory Check ''''''''''''''''''''''''''''''
    If PrincipalAmount <= 0 Or (CompoundTerm = "" And CompoundYesNo = "Y") Or ROI <= 0 Or IntPeriodicity = "" Then
        
            GetInterestAmount = "Error ! Required Input Parameters are not sent."
            Exit Function
        
    End If
    ''''''''''''''''''''''''''''End of Mandatory Check ''''''''''''''''''''''''''''
        
     
    
    ''''''''''''''''''''' Interest Calculation'''''''''''''''''''''''''''''''''''
        
    If CompoundYesNo = "N" Then
    ''''''''''''''''''''''''''' Simple Interest Calculation '''''''''''''''''''''
SimpleInterest:


        ''''  Set value for Interst Calculation Period in months based on Periodicity
        If IntPeriodicity = "M" Then
            Period = 1
        ElseIf IntPeriodicity = "Q" Then
            Period = 3
        ElseIf IntPeriodicity = "H" Then
            Period = 6
        ElseIf IntPeriodicity = "Y" Then
            Period = 12
        End If
        IntAmount = (PrincipalAmount * Period * ROI) / 1200
        ''''''''''''''''''''''End of Simple Interst Calculation ''''''''''''''''''''''''
    
    Else
        
        If IntPeriodicity = CompoundTerm Then
        ''''''''' If Interest Payment Periodicity and Compounding Periodicity is same
        '''''''' then Simple Interest can be applied
            GoTo SimpleInterest
        Else
            ''''''''''''''''''''''''''' Compound Interest Calculation '''''''''''''''''''''
          ''''  Set value for Interst Calculation Period in months based on Periodicity
          '''' if Interest Periodicity is less than Compounding term then divert it
          '''' to simple interest calculation
          If CompoundTerm = "M" Then
               
               If IntPeriodicity = "Q" Then
                    Period = 3
               ElseIf IntPeriodicity = "H" Then
                    Period = 6
                ElseIf IntPeriodicity = "Y" Then
                    Period = 12
                End If
                 ROI = ROI / 1200
            ElseIf CompoundTerm = "Q" Then
                
               If IntPeriodicity = "M" Then
                    GoTo SimpleInterest
               ElseIf IntPeriodicity = "H" Then
                    Period = 2
               ElseIf IntPeriodicity = "Y" Then
                    Period = 4
                End If
                ROI = ROI / 400
            ElseIf CompoundTerm = "H" Then
               
                If IntPeriodicity = "M" Or IntPeriodicity = "Q" Then
                    GoTo SimpleInterest
                ElseIf IntPeriodicity = "Y" Then
                    Period = 2
                End If
                 ROI = ROI / 200
            End If
            
           IntAmount = (PrincipalAmount * (1 + (ROI)) ^ (Period)) - PrincipalAmount
                        
        '''''''''''''''''''''''''''End of Compound Interest Calculation '''''''''''''''''''''
        End If
        
        
    End If
    
    GetInterestAmount = IntAmount

    ''''''''''''''''''End of Interest Calculation ''''''''''''''''''''''''''''''
  Exit Function
errhand:
GetInterestAmount = "Error  !" & Err.Number & " : " & Err.Description
GetInterestAmount = Replace(GetInterestAmount, Chr(10), "")
GetInterestAmount = Replace(GetInterestAmount, Chr(13), "")

End Function


''Private Sub DbConnection()
''Dim DataLink As String
''
''''''' calling shared property manager for dblink
''Set objDBlink = CreateObject("SharedStaticValues.AcceptDBLink")
''DataLink = objDBlink.GetDBLink
''Set objDBlink = Nothing
''ArrLink = Split(DataLink, ",", -1)
''If UBound(ArrLink) < 2 Then
''    ConnError = ArrLink(0)
''    Exit Sub
''ElseIf UBound(ArrLink) = 2 Then
''    DataLink = ""
''ElseIf UBound(ArrLink) = 3 Then
''    DataLink = Trim(ArrLink(3))
''End If
''
''
''ConnError = ""
''Set AdoConnObj = CreateObject("ADODB.Connection")
''AdoConnObj.CursorLocation = adUseClient
'''AdoConnObj.Open "Provider=MSDAORA.1;data source=v3;Password=esmart;User ID=v3"
''AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''If AdoConnObj.State = 1 Then ConnError = "Connected"
''End Sub


Public Sub DBConnection()
Dim intRetrycnt As Integer
Dim intMaxRetCnt As Integer
Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
Dim strUserName As String
Dim AdoScConnObj As ADODB.Connection
Dim strLineno As String
Dim ErrNum As String
Dim errDesc As String
''Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
strSupreUserPassword = "RamSmart2020" ''objPwd.getMUP()
strUserid = "v3" ''objPwd.getMU()
strDataSource = "v3" ''objPwd.getDS()
intMaxRetCnt = 5
intRetrycnt = 0

'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink

 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
''    With AdoConnObj
''
''            strUserName = "scott"
''           .ConnectionString = "user id=" & strUserName & ";password=tiger" & _
''            ";data source=" & strDataSource
''           .CursorLocation = adUseClient
''           .Provider = "MSDAORA.1"
''           .Open
''    End With

''    Set AdoScConnObj = CreateObject("Adodb.Connection")
''    AdoScConnObj.CursorLocation = adUseClient
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    strUserName = "scott"
''
''
''    AdoScConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=tiger;User ID=" & strUserName _
''    & ";Pooling=true;Min Pool Size=10;Max Pool Size=100;"
''
''    Set resDBdate = AdoScConnObj.Execute("SELECT LatestDaybegindate FROM DBDATE")
''
''    If IsNull(resDBdate) = True Then
''    GoTo errhand:
''    End If
''
''    strpassword = objPwd.getPassword(Format(resDBdate!LATESTDAYBEGINDATE, "DD-MM-YYYY") & "/bank/city/grams")
''
''    resDBdate.Close
''    Set resDBdate = Nothing
''    If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''    Set AdoScConnObj = Nothing
    
''    strpassword = "RA1715141464430"
''    'strUserid = "v"
''    strUserName = "v3"
''    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    Set AdoConnObj = New ADODB.Connection

    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strSupreUserPassword & ";User ID=" & _
    strUserid & "; Pooling=true;Min Pool Size=10;Max Pool Size=100;"
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"


    If AdoConnObj.State = 1 Then ConnError = "Connected"

    
Exit Sub

errhand:


'''If Not resDBdate.EOF Or Not resDBdate.BOF Then
'''    If IsNull(resDBdate!LATESTDAYBEGINDATE) = True Then
'''    ConnError = "DBDATE: Latest Date Not Found."
'''    End If
'''End If



If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct connect string in TNS names or TNS:could not resolve service name"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
            ConnError = "Server not up or verify names in tns name or Listener could not  resolved"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
        Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
        End If
        
ElseIf Err.Number = -2147217843 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
            If strUserName = "scott" Then
            ConnError = "User/password not found while trying to get dbdate."
            ElseIf strUserName = "v3" Then
            ConnError = "Main UserName/password not Tallied."
            End If
        End If
ElseIf Err.Number = -2147217865 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
        ConnError = "DBDATE: Table or View does not exist."
        End If
ElseIf Err.Number = -2147217900 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
        ConnError = "DBDATE: Grant Not Given."
        End If
   ''' End If
Else
            If intMaxRetCnt = intRetrycnt Then
                ConnError = "Connection Failed Please try again"
            Else
                intRetrycnt = intRetrycnt + 1
                Sleep 1000
                Resume
            End If
End If
''   If AdoScConnObj.State = 1 Then AdoScConnObj.Close
''   Set AdoScConnObj = Nothing

objErrlog.LogError "RDIntCalc", "DBConnection" & strLineno, Err.Number, Err.Description

   Set objError = CreateObject("TrapError.ErrorDescription")
   ErrNum = Err.Number
   errDesc = Err.Description
   strComponent = Err.Source & "- DBConnection - at Lineno : " & strLineno
   ArrError = objError.ErrorProcess(ErrNum, errDesc, "", strComponent, "", "", "")
    '''''*************RecordSet Not oppened************
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
     Set objError = Nothing

End Sub

Public Function RDInterestAmount(StrBrCode As String, StrCurCode As String, _
            StrGL As String, StrDepNo As String, DblOpBal As Double, _
            DblNewRate As Double, StrAppDate As String, StrPrematureYN As String) As Variant
On Error GoTo errhand
Call DBConnection
If ConnError <> "Connected" Then GoTo errhand

    Dim dtLastDayOfMonth As Date
    Dim intcount As Double
    Dim intInstalmentNo As Double
    Dim TERM As Double
    Dim PENAL As Double
    Dim MONTH As Double
    Dim StrDet As String
    Dim StrCond As String
    Dim RsPenal As New ADODB.Recordset
    Dim RecLast As New ADODB.Recordset
    Dim RecCurBal  As New ADODB.Recordset
    Dim recfdtran As New ADODB.Recordset
    Dim RESMON As New ADODB.Recordset
    Dim intRecfdCount As Integer
    Dim intAmtInst As Integer
    Dim intAmtInstCnt As Integer
    Dim FromDt As Date
    Dim ToDt As Date
    Dim EffDate As Date
    Dim DblBalAmt As Double
    Dim DblIntAmt As Double
    Dim DblPenalInt As Double
    Dim PrevEffDt As Date
    Dim DueDt As Date
    Dim DblOpAmt As Double
    Dim MONTHS As Integer
    Dim Balance As Double
    Dim intmonths As Integer
    Dim DblTotAmt As Double
    Dim DtCalUpto As Date
    PrevEffDt = "09-09-1009"
    
    StrCond = "branchcode='" & Trim(StrBrCode) & "' " & _
             " and glcode ='" & Trim(StrGL) & "' and accno=" & _
            Trim(StrDepNo)
        Set recmst = AdoConnObj.Execute("select accno,glcode,name," _
            & "opdate depdate,roi,opbal,MATURITYDATE, MATURITYVALUE, " _
            & "status from depmst where " & StrCond & "")
            
        If recmst.RecordCount > 0 Then
            
               MONTHS = DateDiff("M", recmst!depdate, recmst!MaturityDate)
               TERM = DateDiff("M", recmst!depdate, recmst!MaturityDate)
               PrevEffDt = recmst!depdate
                intInstalmentNo = 1
                dtLastDayOfMonth = recmst!depdate
                StrDet = intInstalmentNo & "~" & Format(recmst!depdate, "dd-MM-YYYY") & "~" & _
                Format(recmst!depdate, "dd-MM-YYYY") & "~" & _
                Format(recmst!opbal, "0.00") & "~" & Format(recmst!opbal, "0.00") & "~0.00~0.00"
               
                dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
                
                Set RecLast = AdoConnObj.Execute("select last_day('" & _
                    Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
                    dtLastDayOfMonth = Format(RecLast!LastDate)

                Set RecCurBal = AdoConnObj.Execute("select DAYENDBAL balance from " & _
                    " DEPtran where " & StrCond & " AND " & _
                    " applicationdate =(select max(applicationdate) from deptran where " & _
                    " " & StrCond & " and applicationdate<= to_date('" & _
                    Format(dtLastDayOfMonth, "DD-MMM-YYYY") & "','dd-Mon-yyyy'))")

                
                    If RecCurBal.RecordCount > 0 Then
                         Balance = Val(Format(RecCurBal!Balance))
                    Else
                         Balance = Val(DblOpBal)
                    End If
                   
                   DueDt = Format(recmst!depdate)

                For intcount = 2 To MONTHS
                       Set recfdtran = AdoConnObj.Execute("select amount,applicationdate" _
                            & " from deptran where " & StrCond & " and applicationdate" _
                            & ">=to_date('" & "1-" & _
                            Format(dtLastDayOfMonth, "MMM-YYYY") & "'," _
                            & "'dd-mon-yyyy') and applicationdate" _
                            & "<=to_date('" _
                            & Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "'," _
                            & "'dd-mon-yyyy')", , adCmdText)
                        If recfdtran.RecordCount > 0 Then
                           
                            For intRecfdCount = 0 To recfdtran.RecordCount - 1
                                
                               intAmtInst = (recfdtran!Amount / DblOpBal)
                                    For intAmtInstCnt = 1 To intAmtInst
                                        
                                        intInstalmentNo = intInstalmentNo + 1
                                        Balance = Balance + (Val(Format(recfdtran!Amount)) / intAmtInst)
                                        EffDate = Format(recfdtran!ApplicationDate, "dd-MM-yyyy")
                                        If Format(PrevEffDt, "dd-mm-yyyy") = "09-09-1009" Then
                                           PrevEffDt = EffDate
                                           DueDt = Format(DateAdd("M", 1, PrevEffDt))
                                        Else
                                            DueDt = Format(DateAdd("M", 1, DueDt))
                                        End If
                                        'OpBal
                                        DblOpAmt = Format(DblOpBal, "0.00")
                                        'DueDt = Format(DateAdd("M", 1, PrevEffDt))
                                        Balance = Format(Balance, "0.00") 'balance
                                        DblIntAmt = Format(Round((Balance - DblOpBal) * Val(DblNewRate) / 1200, 2), "0.00") 'interest
                                        StrDet = StrDet & "|" & intInstalmentNo & "~" & EffDate & "~" _
                                                & DueDt & "~" & Format(DblOpAmt, "0.00") & "~" & Format(Balance, "0.00") & "~" & Format(DblIntAmt, "0.00") & "~" & "0.00"
                                        
                                        PrevEffDt = EffDate
                                        DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                                        
                                     Next intAmtInstCnt
                               recfdtran.MoveNext
                            Next intRecfdCount
                        End If
                    
                    dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
                    Set RecLast = AdoConnObj.Execute("select last_day('" & _
                        Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
                    dtLastDayOfMonth = Format(RecLast!LastDate)
                Next intcount
                
                
            If StrPrematureYN = "Y" Then
                If CDate(Format(StrAppDate, "DD-MM-YYYY")) <= CDate(Format(recmst!MaturityDate, "DD-MM-YYYY")) Then
                    DtCalUpto = Format(StrAppDate, "DD-MM-YYYY")
                Else
                    DtCalUpto = Format(recmst!MaturityDate, "DD-MM-YYYY")
                End If
               Set RESMON = AdoConnObj.Execute("SELECT MONTHS_BETWEEN(to_date('" & _
                    Format(StrAppDate, "DD-MM-YYYY") & "','DD-MM-YYYY'), to_date('" & _
                    Format(PrevEffDt, "DD-MM-YYYY") & "','DD-MM-YYYY')) MONTHS FROM DUAL", , adCmdText)

                    intmonths = Fix(RESMON!MONTHS)
                    
                If intmonths > 0 Then
                    intInstalmentNo = intInstalmentNo + 1
                    DblIntAmt = Format(Round((Balance * Val(DblNewRate) * intmonths) / 1200, 2), "0.00")  'interest
                    StrDet = StrDet & "|" & intInstalmentNo & "~~" _
                                             & Format(DtCalUpto, "dd-mm-yyyy") & "~~" & Format(Balance, "0.00") & "~" & Format(DblIntAmt, "0.00") & "~" & "0"
                   
                End If
            End If
               DblTotAmt = Format(Val(DblTotAmt) + Val(DblIntAmt), "0.00")
    End If
    
    RDInterestAmount = StrDet & "$" & intInstalmentNo & "$" & Format(Round(Val(DblTotAmt)), "0.00")
          

    If RsPenal.State = 1 Then RsPenal.Close
    Set RsPenal = Nothing
    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If RecCurBal.State = 1 Then RecCurBal.Close
    Set RecCurBal = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    

Exit Function
errhand:

    RDInterestAmount = "Error  !" & Err.Number & " : " & Err.Description
    
    
objErrlog.LogError "RDIntCalc", "RDInterestAmount", Err.Number, Err.Description
    
    If RsPenal.State = 1 Then RsPenal.Close
    Set RsPenal = Nothing
    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If RecCurBal.State = 1 Then RecCurBal.Close
    Set RecCurBal = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
End Function


Public Function RDAllAccInterestAmount(StrBrCode As String, StrCurCode As String, _
            StrGL As String, StrfrDate As String, StrtoDate As String, _
            StrFrDepNo As String, StrToDepNo As String, DblOpBal As Double, _
            pDblNewRate As Double, StrAppDate As String, StrPrematureYN As String, _
            userid As String, machineid As String) As Variant

    Dim dtLastDayOfMonth As Date
    Dim intcount As Double
    Dim intInstalmentNo As Double
    Dim TERM As Double
    Dim PENAL As Double
    Dim MONTH As Double
    Dim StrDet As String
    Dim StrCond As String
    Dim RsPenal As New ADODB.Recordset
    Dim RecLast As New ADODB.Recordset
    Dim RecCurBal  As New ADODB.Recordset
    Dim recfdtran As New ADODB.Recordset
    Dim RESMON As New ADODB.Recordset
    Dim intRecfdCount As Integer
    Dim intAmtInst As Integer
    Dim intAmtInstCnt As Integer
    Dim FromDt As Date
    Dim ToDt As Date
    Dim EffDate As Date
    Dim DblBalAmt As Double
    Dim DblIntAmt As Double
    Dim DblPenalInt As Double
    Dim PrevEffDt As Date
    Dim DueDt As Date
    Dim DblOpAmt As Double
    Dim MONTHS As Integer
    Dim Balance As Double
    Dim intmonths As Integer
    Dim DblTotAmt As Double
    Dim DtCalUpto As Date
    Dim DtFrom As Date
    Dim DtTo As Date
    Dim DblNewRate As Double
    Dim StrGetBal As String
    Dim StrCurBalDt As Date
    Dim IntAccr As Double
    Dim DblTotBal As Double
    Dim RecIntAccr As New ADODB.Recordset
    Dim bTransBegin As Boolean
    
On Error GoTo errhand
    
    bTransBegin = False
    
    Call DBConnection
    If ConnError <> "Connected" Then
        RDAllAccInterestAmount = "Error  !" & ConnError
        Exit Function
    End If
    
    PrevEffDt = "09-09-1009"
    StrInsTabName = "DEPINTCALTEMP"
    StrInsFldNames = "BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, BALANCE, " & _
                     "INTRATE, INTAMOUNT, INTEFFDATE, FROMDATE, TODATE, INTDAYS," & _
                     " INTPAIDUPTO, PAYTYPE, REMARKS, APPLICATIONDATE, USERID, " & _
                     " MACHINEID, SYSTEMDATE, SYSTEMYEAR"
     
    DtTo = CDate(Format(StrtoDate, "dd-mm-yyyy"))
       
    StrCond = "branchcode='" & Trim(StrBrCode) & "' " & _
             " and glcode ='" & Trim(StrGL) & "' and EFFDATE<='" & Format(DtTo, "DD-MMM-YYYY") & _
             "' and LASTINTCALCDATE<='" & Format(DtTo, "DD-MMM-YYYY") & "' AND STATUS='R'"
            
            
    Set recmst = AdoConnObj.Execute("select accno,glcode,name," _
            & "opdate depdate,EFFDATE,nvl(roi,0) roi ,opbal,MATURITYDATE, MATURITYVALUE, " _
            & "status from depmst where " & StrCond & "")
        
        'Set RsPenal = AdoConnObj.Execute("Select * from DEPPENALINTDTLS where applicationdate<='" & _
                    Format(StrAppDate, "DD-MMM-YYYY") & "'")
    AdoConnObj.BeginTrans
    bTransBegin = True
    
    If recmst.RecordCount > 0 Then
            
            AdoConnObj.Execute "delete from DEPINTCALTEMP where branchcode='" & _
                        Trim(StrBrCode) & "' and glcode ='" & Trim(StrGL) & "'"
                        
            Do Until recmst.EOF
              
               StrGetBal = ""
               If CDate(Format(StrfrDate, "dd-mm-yyyy")) > CDate(Format(recmst!EffDate, "dd-mm-yyyy")) Then
                    DtFrom = CDate(Format(StrfrDate, "dd-mm-yyyy"))
               Else
                    DtFrom = CDate(Format(recmst!EffDate, "dd-mm-yyyy"))
               End If
                              
               MONTHS = DateDiff("M", DtFrom, DtTo)
               TERM = DateDiff("M", DtFrom, DtTo)
               PrevEffDt = DtFrom
               DblNewRate = Val(recmst!ROI)
               StrCond = "branchcode='" & Trim(StrBrCode) & "' " & _
                 " and glcode ='" & Trim(StrGL) & "' and accno='" & Trim(recmst!accno) & "'"
               
               Set RecIntAccr = AdoConnObj.Execute("Select nvl(sum(nvl(intamount,0)),0) AccrAmt " & _
                    " from DEPINTACCRUEDDTLS where " & StrCond & "")
                    
               If RecIntAccr.RecordCount > 0 Then
                    IntAccr = RecIntAccr!accramt
               Else
                    IntAccr = 0
               End If
                
                intInstalmentNo = 1
                dtLastDayOfMonth = DtFrom
                StrCurBalDt = DateAdd("D", "-1", Format(dtLastDayOfMonth, "dd-mm-yyyy"))
                
                Set RecLast = AdoConnObj.Execute("select last_day('" & _
                    Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
                    dtLastDayOfMonth = Format(RecLast!LastDate)

                StrGetBal = "'" & Trim(StrBrCode) & "','" & Trim(StrCurCode) & "','DEP','" & _
                            Trim(StrGL) & "','" & Trim(recmst!accno) & "','" & _
                            Format(StrCurBalDt, "DD-MMM-YYYY") & "'"

                Set RecCurBal = AdoConnObj.Execute("SELECT GETANYDAYBAL(" & StrGetBal & ") BALANCE FROM DUAL")
                
                    If RecCurBal.RecordCount > 0 Then
                         Balance = Val(Format(RecCurBal!Balance))
                    Else
                         Balance = Val(recmst!opbal)
                    End If
                   
                   DueDt = Format(DtFrom)
                   
                   'First month
                      DblTotAmt = 0
                      DblIntAmt = Format(Round((Balance) * Val(DblNewRate) / 1200, 2), "0.00") 'interest
                      DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                      DblIntAmt = 0
                   'dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
                   
                For intcount = 1 To MONTHS
                       Set recfdtran = AdoConnObj.Execute("select nvl(sum(nvl(amount,0)),0) amount" _
                            & " from deptran where " & StrCond & " and applicationdate" _
                            & ">=to_date('" & "1-" & _
                            Format(dtLastDayOfMonth, "MMM-YYYY") & "'," _
                            & "'dd-mon-yyyy') and applicationdate" _
                            & "<=to_date('" _
                            & Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "'," _
                            & "'dd-mon-yyyy')", , adCmdText)
                        If recfdtran.RecordCount > 0 Then
                             Balance = Balance + Val(Format(recfdtran!Amount))
                             Balance = Format(Balance, "0.00") 'balance
                             DblIntAmt = Format(Round((Balance) * Val(DblNewRate) / 1200, 2), "0.00") 'interest
                             DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                        Else
                             Balance = Format(Balance, "0.00") 'balance
                             DblIntAmt = Format(Round((Balance) * Val(DblNewRate) / 1200, 2), "0.00") 'interest
                             DblTotAmt = Val(DblTotAmt) + Val(DblIntAmt)
                        End If
                    
                    dtLastDayOfMonth = DateAdd("M", 1, dtLastDayOfMonth)
                    Set RecLast = AdoConnObj.Execute("select last_day('" & _
                        Format(dtLastDayOfMonth, "dd-MMM-YYYY") & "') LastDate from dual")
                    dtLastDayOfMonth = Format(RecLast!LastDate)
                Next intcount
                
                                DblTotBal = Round(Val(Balance) + Val(IntAccr) + Val(DblTotAmt))
               If Val(DblTotBal) > Val(recmst!Maturityvalue) Then
                  DblTotAmt = Val(recmst!Maturityvalue) - Val(DblTotBal)
               End If
               If Val(DblTotAmt) >= 0 Then
              AdoConnObj.Execute "INSERT INTO  DEPINTCALTEMP(BRANCHCODE, CURRENCYCODE," & _
                        " GLCODE, ACCNO, BALANCE,INTRATE, INTAMOUNT, INTEFFDATE, FROMDATE," & _
                        " TODATE, APPLICATIONDATE," & _
                        " USERID,MACHINEID, SYSTEMDATE) VALUES ('" & StrBrCode _
                        & "','" & StrCurCode & "','" & StrGL & "','" & recmst!accno & _
                        "'," & Val(Balance) & "," & Val(DblNewRate) & "," & Round(Val(DblTotAmt)) & _
                        ",'" & Format(DtFrom, "dd-mmm-yyyy") & "','" & Format(DtFrom, "dd-mmm-yyyy") & "','" & _
                        Format(DtTo, "dd-mmm-yyyy") & _
                        "','" & Format(StrAppDate, "dd-mmm-yyyy") & "','" & userid & _
                        "','" & machineid & "','" & _
                        Format(StrAppDate, "dd-mmm-yyyy") & "' )"
               End If
             
            DblTotAmt = 0
            DblIntAmt = 0
            recmst.MoveNext
        Loop
    End If
    
    RDAllAccInterestAmount = "OK"
    AdoConnObj.CommitTrans
    
    
    If RecIntAccr.State = 1 Then RecIntAccr.Close
    Set RecIntAccr = Nothing
    If RsPenal.State = 1 Then RsPenal.Close
    Set RsPenal = Nothing
    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If RecCurBal.State = 1 Then RecCurBal.Close
    Set RecCurBal = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
Exit Function
errhand:
RDAllAccInterestAmount = "Error  !" & Err.Number & " : " & Err.Description

    If bTransBegin = True Then
        AdoConnObj.RollbackTrans
    End If
    
    
objErrlog.LogError "RDIntCalc", "RDInterestAmount", Err.Number, Err.Description
    
    If RecIntAccr.State = 1 Then RecIntAccr.Close
    Set RecIntAccr = Nothing
    If RsPenal.State = 1 Then RsPenal.Close
    Set RsPenal = Nothing
    If RecLast.State = 1 Then RecLast.Close
    Set RecLast = Nothing
    If RecCurBal.State = 1 Then RecCurBal.Close
    Set RecCurBal = Nothing
    If recfdtran.State = 1 Then recfdtran.Close
    Set recfdtran = Nothing
    If RESMON.State = 1 Then RESMON.Close
    Set RESMON = Nothing
    If AdoConnObj.State = 1 Then AdoConnObj.Close
    Set AdoConnObj = Nothing
    
End Function

Private Sub Class_Initialize()
Set objErrlog = CreateObject("TrapError.ErrorDescription")
End Sub

Private Sub Class_Terminate()
Set objErrlog = Nothing
End Sub
