VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   2490
   ClientLeft      =   240
   ClientTop       =   1935
   ClientWidth     =   6765
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   ScaleHeight     =   2490
   ScaleWidth      =   6765
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   615
      Left            =   1440
      TabIndex        =   0
      Top             =   720
      Width           =   2175
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim st As String
Public Rdint As RDIntCalc.RDInterestValue
Private Sub Command1_Click()
On Error GoTo errh
'Set Rdint = New MaturityValueCalc.MatValue
'st = Rdint.RDInterestAmount("999", "INR", "104111", "702", "500", _
             "8.50", "23-FEB-2007", "Y")
Set Rdint = New RDIntCalc.RDInterestValue
st = Rdint.RDAllAccInterestAmount("104", "INR", "104111", "01-SEP-2007", "31-OCT-2007", _
             "", "", "0", "8.50", "11-OCT-2007", "N", "RAJ", "RAJ")
             
MsgBox st
Exit Sub
errh:
MsgBox Err.Description, vbInformation
End Sub
