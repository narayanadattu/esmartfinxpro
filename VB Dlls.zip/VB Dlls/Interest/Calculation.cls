VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 1  'NoTransaction
END
Attribute VB_Name = "Calculation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public ConnError As String 'error object
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim Rstemp As ADODB.Recordset
Dim strMsg As String
Dim DayPerMon As Integer
Dim DayPerYr As Integer
Dim DbLink As String
Dim Icount As Integer
Dim RowCount As Integer
Dim objQuery As Object
Dim ArrLink As Variant
Dim DataLink As String
Dim objDBlink As Object
Dim strCurCode As String
Dim strQuery As String
Dim ROI As Double
''''''''''' variables declared for interest caluclation
Dim strFlds As String
Dim RsRate As ADODB.Recordset
Dim RsBaseRate As ADODB.Recordset
Dim RsRateDup1 As ADODB.Recordset
Dim RsRateDup2 As ADODB.Recordset
Dim intYrs As Double
Dim intMon As Double
Dim intday As Double
Dim PrdYrs As Double
Dim PrdMon As Double
Dim PrdDay As Double
Dim EffectDate As String
Dim BaseRateSymbol As String
Dim BaseRateCode As String
Dim Variation As Double
Dim arrRate(1) As Variant
Dim Glcode As String
Dim CategoryCode As String
Dim Amount As Double
Dim ArrFlds() As Variant
Dim ArrVals() As Variant
Dim ArrMon As Variant
Dim strCond As String
Dim MatDate As String

Public Function GetRateofInterest(CurrencyCode As String, _
                                  strGlcode As String, _
                                  strCategoryCode As String, _
                                  Optional EffectiveDate As String, _
                                  Optional DblAmount As Double, _
                                  Optional PrdYears As Double, _
                                  Optional PrdMonths As Double, _
                                  Optional PrdDays As Double) As Variant
                                  
                                  
                                  
'''''Dim strFlds As String
'''''Dim RsRate As ADODB.Recordset
'''''Dim RsBaseRate As ADODB.Recordset
'''''Dim RsRateDup1 As ADODB.Recordset
'''''Dim RsRateDup2 As ADODB.Recordset
'''''Dim intYrs As Double
'''''Dim intMon As Double
'''''Dim intday As Double
'''''Dim PrdYrs As Double
'''''Dim PrdMon As Double
'''''Dim PrdDay As Double
'''''Dim EffectDate As String
'''''Dim BaseRateSymbol As String
'''''Dim BaseRateCode As String
'''''Dim arrRate(1) As Variant
'''''On Error GoTo errHand
'''''Dim ArrFlds() As Variant
'''''Dim ArrVals() As Variant
'''''Dim ArrMon As Variant
'''''PrdDay = PrdDays
'''''PrdMon = PrdMonths
'''''PrdYrs = PrdYears
'''''strCurCode = CurrencyCode


PrdDay = PrdDays
PrdMon = PrdMonths
PrdYrs = PrdYears
strCurCode = CurrencyCode
Glcode = strGlcode
Amount = IIf(IsNull(DblAmount), 0, DblAmount)
CategoryCode = strCategoryCode

Call DbConnection
On Error GoTo errHand
If ConnError <> "Connected" Then
    strMsg = ConnError
    GoTo errHand
End If

EffectDate = Format(EffectiveDate, "dd-MMM-yyyy")
Set Rstemp = CreateObject("ADODB.Recordset")

strQuery = "select DAYSPERMONTH, DAYSPERYEAR from GENBANKDAYSCONVERSIONMST where " _
        & " CURRENCYCODE='" & strCurCode & "' and status='R'"
Set objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
'Set Rstemp = objQuery.SingleRecordSet("GENBANKDAYSCONVERSIONMST", _
'                                        "DAYSPERMONTH, DAYSPERYEAR", strQuery)
Set Rstemp = AdoConnObj.Execute(strQuery)

'If objQuery.ConnError <> "Connected" Then
'    strMsg = objQuery.ConnError
'    GoTo errHand
'Else
If Rstemp.EOF And Rstemp.BOF Then
    strMsg = "Days/Year and Days/Month to be specified."
    GoTo errHand
End If
DayPerMon = Rstemp!DAYSPERMONTH
DayPerYr = Rstemp!DAYSPERYEAR

If (PrdYrs > 0 And PrdMon > 12) Or (PrdYrs > 0 And PrdDay > DayPerYr) _
                            Or (PrdMon > 0 And PrdDay > DayPerMon) Then
    strMsg = "Please Check The Period."
    GoTo errHand
End If


'''''''''''''********************************************************************************
'''''''''''''********************************************************************************
strFlds = "BASERATECODE, RATE, VARIATIONRATE "
strQuery = "select " & strFlds & " from GENINTERESTDTLS where glcode='" & Glcode _
& "' and currencycode='" & strCurCode & "' and baseratecode is not null and  EFFECTIVEDATE= ( select max(EFFECTIVEDATE) " _
& " from GENINTERESTDTLS where glcode='" & Glcode & "' and currencycode='" _
& strCurCode & "' and effectivedate<='" & EffectDate & "' and baseratecode is not null)"

Set RsBaseRate = AdoConnObj.Execute(strQuery)

If RsBaseRate.RecordCount > 0 Then
    strMsg = "ROI"
    ROI = (RsBaseRate!Rate) + (RsBaseRate!VARIATIONRATE)
    RsBaseRate.Close
Else
    RsBaseRate.Close
    strMsg = RateOfInterest
    Rstemp.Close
    RsRate.Close
    RsRateDup1.Close
    RsRateDup2.Close
End If


''''''''''''''''********************Base Rate*********************************''''''''''''
''''''''''''''''********************Base Rate*********************************''''''''''''
''''''''''''''''********************Base Rate*********************************''''''''''''

If strMsg = "ROI" Then
   arrRate(0) = strMsg
   arrRate(1) = ROI
Else
    GoTo errHand
End If

Set objQuery = Nothing
GetRateofInterest = arrRate
Exit Function


errHand:
'RsRate.Close
'RsRate.Close
'RsRateDup1.Close
'RsRateDup2.Close
Set objQuery = Nothing

arrRate(0) = "ERROR"

If strMsg = "" Then
    arrRate(1) = Err.Number & " : " & Err.Description
Else
    arrRate(1) = strMsg
End If

    GetRateofInterest = arrRate
End Function


''''Database Connection
Private Sub DbConnection()
'Dim DataLink As String
'
''''' calling shared property manager for dblink
'Set objDBlink = CreateObject("SharedStaticValues.AcceptDBLink")
'DataLink = objDBlink.GetDBLink
'Set objDBlink = Nothing
'ArrLink = Split(DataLink, ",", -1)
'If UBound(ArrLink) < 2 Then
'    ConnError = ArrLink(0)
'    Exit Sub
'ElseIf UBound(ArrLink) = 2 Then
'    DataLink = ""
'ElseIf UBound(ArrLink) = 3 Then
'    DataLink = Trim(ArrLink(3))
'End If


ConnError = ""
Set AdoConnObj = CreateObject("ADODB.Connection")
AdoConnObj.CursorLocation = adUseClient
AdoConnObj.Open "Provider=MSDAORA.1;data source=v3;Password=RamSmart2020;User ID=v3"
''AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
If AdoConnObj.State = 1 Then ConnError = "Connected"
End Sub

Private Function BaseRate() As String
Dim errMsg As String
BaseRateCode = RsBaseRate!BaseRateCode
BaseRateSymbol = RsBaseRate!BaseRateSymbol
Variation = RsBaseRate!VARIATIONRATE
strQuery = "select rate from GENBASEINTERESTDTLS where BASERATECODE='" & BaseRateCode _
& "' and currencycode='" & strCurCode & "' and EFFECTIVEDATE= ( select max(EFFECTIVEDATE) " _
& " from GENINTERESTDTLS where BASERATECODE='" & BaseRateCode & "' and currencycode='" _
& strCurCode & "' and effectivedate<='" & EffectDate & "')"
If RsBaseRate.State = 1 Then RsBaseRate.Close

Set RsBaseRate = AdoConnObj.Execute(strQuery)
If RsBaseRate.EOF And RsBaseRate.BOF Then
    BaseRate = "Rate Of Interest not available"
Else
    ROI = (RsBaseRate!Rate) + (Variation)
'    If BaseRateSymbol = "-" Then
'        ROI = RsBaseRate!Rate - Variation
'    ElseIf BaseRateSymbol = "+" Then
'        ROI = RsBaseRate!Rate + Variation
'    End If
    BaseRate = "ROI"
End If

Exit Function



Exit Function

errHand:
If errMsg = "" Then
   BaseRate = Err.Number & " : " & Err.Description
   BaseRate = Replace(BaseRate, Chr(10), "")
   BaseRate = Replace(BaseRate, Chr(13), "")
Else
    BaseRate = errMsg
    BaseRate = Replace(BaseRate, Chr(10), "")
   BaseRate = Replace(BaseRate, Chr(13), "")
    
End If
End Function

Private Function RateOfInterest() As String

Dim errMsg As String
On Error GoTo errHand

strFlds = " FROMPRDSYMBOL, FROMPRDYEARS, FROMPRDMONTHS, FROMPRDDAYS, TOPRDSYMBOL, " _
& " TOPRDYEARS, TOPRDMONTHS, TOPRDDAYS, FROMAMTSYMBOL, FROMAMOUNT, TOAMTSYMBOL, " _
& " TOAMOUNT, RATE, BASERATECODE, BASERATESYMBOL, VARIATIONRATE ,FROMCONVDAYS ,TOCONVDAYS"

strQuery = ""
strQuery = "select " & strFlds & " from GENINTERESTDTLS where glcode='" & Glcode _
& "' and currencycode='" & strCurCode & "' and (CATEGORYCODE='" & CategoryCode _
& "' or CATEGORYCODE='99')  and nvl(fromamount,0)<=" & Amount & " and nvl(toamount,0)>=" & Amount _
& "  and EFFECTIVEDATE= ( select max(EFFECTIVEDATE) " _
& " from GENINTERESTDTLS where glcode='" & Glcode & "' and currencycode='" _
& strCurCode & "' and (CATEGORYCODE='" & CategoryCode _
& "' or CATEGORYCODE='99') and nvl(fromamount,0)<=" & Amount & " and nvl(toamount,0)>=" & Amount _
& " and effectivedate<='" & EffectDate & "')"

Set RsRate = CreateObject("ADODB.Recordset")

Set RsRate = AdoConnObj.Execute(strQuery)

'If objQuery.ConnError <> "Connected" Then
'    errMsg = objQuery.ConnError
'    GoTo errHand
'Else
If RsRate.EOF And RsRate.BOF Then
    strQuery = "select " & strFlds & " from GENINTERESTDTLS where glcode='" & Glcode _
    & "' and currencycode='" & strCurCode & "' and (CATEGORYCODE='" & CategoryCode _
    & "' or CATEGORYCODE='99') AND EFFECTIVEDATE= ( select max(EFFECTIVEDATE) " _
    & " from GENINTERESTDTLS where glcode='" & Glcode & "' and currencycode='" _
    & strCurCode & "' and (CATEGORYCODE='" & CategoryCode _
    & "' or CATEGORYCODE='99') and effectivedate<='" & EffectDate & "')"
    
    If RsRate.State = 0 Then RsRate.Close
    
    Set RsRate = AdoConnObj.Execute(strQuery)

ElseIf RsRate.EOF And RsRate.BOF Then
    errMsg = "Interest not specified for this Account Type or this Effective date : " & EffectDate
    '''''errMsg = errMsg & " " & strQuery
    GoTo errHand
End If
Icount = RsRate.Fields.Count
ReDim ArrFlds(Icount) As Variant
ReDim ArrVals(Icount) As Variant
Set RsRateDup1 = CreateObject("ADODB.Recordset")
Set RsRateDup2 = CreateObject("ADODB.Recordset")


''''''''''duplicate records.
strQuery = ""
strQuery = "select " & strFlds & " from GENINTERESTDTLS where 1=2 "
RsRateDup1.Open strQuery, AdoConnObj, adOpenDynamic, adLockBatchOptimistic
RsRateDup2.Open strQuery, AdoConnObj, adOpenDynamic, adLockBatchOptimistic

ROI = 0

If PrdYrs > 0 Then
    
    RsRate.Filter = " fromprdyears <=" & PrdYrs & " and toprdyears >=" & PrdYrs
    If RsRate.RecordCount = 0 Then
        RsRate.Filter = " fromprdyears <=" & PrdYrs & " and toprdyears =0"
        
    If RsRate.RecordCount >= 1 Then
        ROI = RsRate!Rate
        BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
        BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
    Else
        If RsRate.RecordCount > 1 Or PrdMon > 0 Then
            For RowCount = 0 To RsRate.RecordCount - 1
                RsRateDup1.AddNew
                For Icount = 0 To RsRate.Fields.Count - 1
                    RsRateDup1(Icount) = IIf(Trim(RsRate.Fields(Icount).Value) = "", Null, _
                    Trim(RsRate.Fields(Icount).Value))
                Next Icount
                RsRate.MoveNext
            Next RowCount
            RsRateDup1.MoveFirst
            If PrdMon > 0 Then
    '            RsRateDup1.Filter = " fromprdmonths <=" & prdmon & " and toprdmonths >=" & prdmon
                RsRateDup1.Filter = " fromprdmonths <=" & PrdMon & " and fromprdyears >=" & PrdYrs
            ElseIf PrdDay < 1 Then
                'RsRateDup1.Filter = " toprdyears <=" & PrdYrs
            End If
            If RsRateDup1.RecordCount = 0 Then
                RsRateDup1.Filter = " fromprdmonths <=" & PrdMon & " and toprdmonths =0"
            ElseIf RsRateDup1.RecordCount = 1 Then
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                 BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            End If
    
        End If
    End If
        If RsRateDup1.RecordCount > 0 And PrdDay > 0 Then
            'RsRateDup1.MoveFirst
            For RowCount = 0 To RsRateDup1.RecordCount - 1
                RsRateDup2.AddNew
                For Icount = 0 To RsRateDup1.Fields.Count - 1
                    RsRateDup2(Icount) = IIf(Trim(RsRateDup1.Fields(Icount).Value) = "", Null, _
                    Trim(RsRateDup1.Fields(Icount).Value))
                Next Icount
                RsRateDup1.MoveNext
            Next RowCount
            RsRateDup2.MoveFirst
            If PrdDay > 30 Then
                intMon = (PrdDay) / DayPerMon
                ArrMon = Split(CStr(intMon), ".", -1)
                intMon = ArrMon(0)
                intday = PrdDay - (intMon * DayPerMon)
               RsRateDup2.Filter = " fromprdmonths <=" & intMon & " and fromprdyears >=" & PrdYrs
                
                If RsRateDup2.RecordCount = 1 Then
                    ROI = RsRateDup2!Rate
                    BaseRateCode = IIf(IsNull(RsRateDup2!BaseRateCode), "", RsRateDup2!BaseRateCode)
                     BaseRateSymbol = IIf(IsNull(RsRateDup2!BaseRateSymbol), "", RsRateDup2!BaseRateSymbol)
                Else
                    RsRateDup2.Filter = " fromprddays <=" & PrdDay _
                        & " and toprddays >=" & PrdDay
                     If RsRateDup2.RecordCount = 1 Then
                        ROI = RsRateDup2!Rate
                        BaseRateCode = IIf(IsNull(RsRateDup2!BaseRateCode), "", RsRateDup2!BaseRateCode)
                        BaseRateSymbol = IIf(IsNull(RsRateDup2!BaseRateSymbol), "", RsRateDup2!BaseRateSymbol)
                     End If
                End If
            Else
                RsRateDup2.Filter = " ( fromprdmonths =0 ) "
                If RsRateDup2.RecordCount <> 1 Then RsRateDup2.Filter = " toprddays >=" & PrdDay
                If RsRateDup2.RecordCount <> 1 Then RsRateDup2.Filter = " toprdmonths >=1 and fromprdmonths <1"
                If RsRateDup2.RecordCount <> 1 Then RsRateDup2.Filter = " toprdyears >" & PrdYrs
                    
            End If
            If RsRateDup2.RecordCount = 1 Then
                ROI = RsRateDup2!Rate
                BaseRateCode = IIf(IsNull(RsRateDup2!BaseRateCode), "", RsRateDup2!BaseRateCode)
                 BaseRateSymbol = IIf(IsNull(RsRateDup2!BaseRateSymbol), "", RsRateDup2!BaseRateSymbol)
            Else
                errMsg = "No Slab available for this period"
                GoTo errHand
            End If
        ElseIf RsRateDup1.RecordCount = 1 Then
            ROI = RsRateDup1!Rate
            BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
             BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
        ElseIf RsRateDup1.RecordCount > 1 Then
            RsRateDup1.Filter = " toprdyears >=" & PrdYrs & " and toprdmonths =0 and toprddays =0 and fromprdyears <" _
                & PrdYrs
            If RsRateDup1.RecordCount = 1 Then
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                 BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            Else
                errMsg = " No interest for this period"
                GoTo errHand
            End If
        
        End If
    
    End If
    ''''''-------------------------------------------------------------------------------
    ''''''************ Interest for months if years not specified.**************************
    ''''''-------------------------------------------------------------------------------
ElseIf PrdMon > 0 Then
    If PrdMon <= 12 Then
   
    intday = PrdMon * DayPerMon
        If PrdDay < 1 Then
        
            RsRate.Filter = " fromprdmonths <=" & PrdMon & " and fromprdyears <=1 " ' and toprdyears >=1"
        
        ElseIf PrdMon = 12 Then
            RsRate.Filter = " fromprdmonths <=" & PrdMon & " and fromprdyears <=1 and toprdyears >1 "
        
        
        End If
        If RsRate.RecordCount > 1 Then
        'RsRate.MoveFirst
            For RowCount = 0 To RsRate.RecordCount - 1
                RsRateDup1.AddNew
                For Icount = 0 To RsRate.Fields.Count - 1
                    RsRateDup1(Icount) = IIf(Trim(RsRate.Fields(Icount).Value) = "", Null, _
                    Trim(RsRate.Fields(Icount).Value))
                Next Icount
                RsRate.MoveNext
            Next RowCount
            RsRateDup1.MoveFirst
                 RsRateDup1.Filter = " ( toprdmonths >=" & PrdMon & " and fromprdmonths <" _
                & PrdMon & " ) or ( toprddays >=" & intday + PrdDay & " and fromprddays <=" _
                & intday + PrdDay & " ) "
           
            If RsRateDup1.RecordCount = 1 Then
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            ElseIf RsRateDup1.RecordCount > 1 Then
                RsRateDup1.Filter = " toprddays >=" & intday + PrdDay & " and fromprddays <=" & intday + PrdDay
            Else
                RsRateDup1.Filter = " ( toprdmonths >" & PrdMon & " and fromprdmonths <=" _
                    & PrdMon & " ) or ( fromprdmonths <=" & PrdMon & " and toprdyears >=1 and fromprdyears <1 ) "
            End If
            
            If RsRateDup1.RecordCount >= 1 Then
            
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            Else
                errMsg = "No rate for this period"
                GoTo errHand
            End If
        ElseIf RsRate.RecordCount = 1 Then
            ROI = RsRate!Rate
            BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
        ElseIf RsRate.RecordCount = 0 Then
            errMsg = "Slab not available for this period"
            GoTo errHand
        End If
    ElseIf PrdMon > 12 Then
        intYrs = (PrdMon) / 12
        ArrMon = Split(CStr(intYrs), ".", -1)
        intYrs = ArrMon(0)
        intMon = PrdMon - (intYrs * 12)
        RsRate.Filter = " fromprdyears <=" & intYrs & " and toprdyears >=" & intYrs
        If RsRate.RecordCount = 0 Then
            RsRate.Filter = " fromprdmonths <=" & PrdMon & " and fromprdyears =0 and toprdyears =0 "
            If RsRate.RecordCount >= 1 Then
                ROI = RsRate!Rate
                BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
                BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
            Else
                errMsg = "Slab not available for this period"
                GoTo errHand
            End If
        ElseIf RsRate.RecordCount = 1 Then
            ROI = RsRate!Rate
            BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
        ElseIf RsRate.RecordCount > 1 Then
            For RowCount = 0 To RsRate.RecordCount - 1
                RsRateDup1.AddNew
                For Icount = 0 To RsRate.Fields.Count - 1
                    RsRateDup1(Icount) = IIf(Trim(RsRate.Fields(Icount).Value) = "", Null, _
                    Trim(RsRate.Fields(Icount).Value))
                Next Icount
                
                RsRate.MoveNext
            Next RowCount
            RsRateDup1.MoveFirst
            If intMon > 0 Or PrdDay > 0 Then
                RsRateDup1.Filter = " fromprdmonths <=" & intMon & " and fromprdyears >=" & intYrs
            Else
                RsRateDup1.Filter = " toprdyears <=" & intYrs
            End If
            ROI = RsRateDup1!Rate
            BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
        End If
    
    End If
    ''''''-------------------------------------------------------------------------------
    '''''***********Interest for days if years & months not specified.**************************
    ''''''-------------------------------------------------------------------------------
ElseIf PrdDay > 0 Then
    If PrdDay >= DayPerYr Then
        intYrs = (PrdDay) / DayPerYr
        ArrMon = Split(CStr(intYrs), ".", -1)
        intYrs = ArrMon(0)
        intday = PrdDay - (intYrs * DayPerYr)
        
        If intday > DayPerMon Then
            intMon = (intday) / DayPerMon
            ArrMon = Split(CStr(intMon), ".", -1)
            intMon = ArrMon(0)
           
        End If
        RsRate.Filter = " fromprdyears <=" & intYrs & " and toprdyears >=" & intYrs
        If RsRate.RecordCount = 1 Then
            ROI = RsRate!Rate
            BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
        ElseIf RsRate.RecordCount > 1 Then
            For RowCount = 0 To RsRate.RecordCount - 1
                RsRateDup1.AddNew
                For Icount = 0 To RsRate.Fields.Count - 1
                    RsRateDup1(Icount) = IIf(Trim(RsRate.Fields(Icount).Value) = "", Null, _
                    Trim(RsRate.Fields(Icount).Value))
                Next Icount

            
                RsRate.MoveNext
               
            Next RowCount
            RsRateDup1.MoveFirst
            If intday > 0 Then
                RsRateDup1.Filter = " ( fromprdmonths <=" & intMon & " and toprdmonths >=" _
                                & intMon & " ) or ( fromprdmonths <=" & intMon _
                                & " and toprdmonths =0 ) "
            Else
            
                RsRateDup1.Filter = " toprdyears >=" & intYrs & " and toprdmonths >=" & intMon _
                & " and toprddays >=" & intday & " and fromprdyears <" & intYrs
            End If
            
            If RsRateDup1.RecordCount = 1 Then
                
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            ElseIf RsRateDup1.RecordCount > 1 Or intday > 0 Then
                For RowCount = 0 To RsRateDup1.RecordCount - 1
                    RsRateDup2.AddNew
                    For Icount = 0 To RsRateDup1.Fields.Count - 1
                        RsRateDup2(Icount) = IIf(Trim(RsRateDup1.Fields(Icount).Value) = "", Null, _
                        Trim(RsRateDup1.Fields(Icount).Value))
                    Next Icount

                    RsRateDup1.MoveNext
                    
                Next RowCount
                RsRateDup2.MoveFirst
                RsRateDup2.Filter = "  toprdyears >" & intYrs
                If RsRateDup2.RecordCount > 1 Then
                
                    RsRateDup2.Filter = "( fromprddays <=" & intday & " and toprddays >=" _
                            & intday & " ) or ( fromprddays <=" & intday & " and toprddays =0 ) "
                ElseIf RsRateDup2.RecordCount = 1 Then
                    ROI = RsRateDup2!Rate
                    BaseRateCode = IIf(IsNull(RsRateDup2!BaseRateCode), "", RsRateDup2!BaseRateCode)
                    BaseRateSymbol = IIf(IsNull(RsRateDup2!BaseRateSymbol), "", RsRateDup2!BaseRateSymbol)
                Else
                    errMsg = "No rate for this period"
                    GoTo errHand
                End If
            End If
        End If
    ElseIf PrdDay > DayPerMon Then
        RsRate.Filter = " fromprdmonths =0 and fromprdyears =0 and toprddays >=" _
            & PrdDay & " and fromprddays <=" & PrdDay
        If RsRate.RecordCount = 1 Then
            ROI = RsRate!Rate
            BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
        Else
            
            intMon = (PrdDay) / DayPerMon
            ArrMon = Split(CStr(intMon), ".", -1)
            intMon = ArrMon(0)
            intday = PrdDay - (intMon * DayPerMon)
            
            If intday = 0 Then
                 RsRate.Filter = " toprdmonths >=" & intMon & " and fromprdmonths <" _
                & intMon & " and toprdyears <1"
            Else
                    RsRate.Filter = "  toprdmonths >" & intMon & " and fromprdmonths <=" _
                & intMon & " and toprdyears <1"
'
            End If

            If RsRate.RecordCount = 1 Then
                ROI = RsRate!Rate
                BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
            Else
                RsRate.Filter = " fromprddays <=" & PrdDay _
                    & " and toprddays >=" & PrdDay
                    
''''''                    & " or toprdmonths >=" & intMon _
''''''                    & " or toprdyears =1  "
                 If RsRate.RecordCount = 1 Then
                    ROI = RsRate!Rate
                    BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
                    BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
                 Else
                     RsRate.Filter = " FROMCONVDAYS <=" & PrdDay _
                    & " and TOCONVDAYS >=" & PrdDay
                    If RsRate.RecordCount >= 1 Then
                        ROI = RsRate!Rate
                    Else
                        errMsg = "No slab available for this period."
                        GoTo errHand
                    End If
                End If
            End If
        End If
    Else
        RsRate.Filter = "fromprdmonths =0 and fromprdyears =0 "
        If RsRate.RecordCount > 1 Then
            For RowCount = 0 To RsRate.RecordCount - 1
            
                RsRateDup1.AddNew
                For Icount = 0 To RsRate.Fields.Count - 1
                    RsRateDup1(Icount) = IIf(Trim(RsRate.Fields(Icount).Value) = "", Null, _
                    Trim(RsRate.Fields(Icount).Value))
                Next Icount
                RsRate.MoveNext
                
            Next RowCount
            RsRateDup1.MoveFirst
            RsRateDup1.Filter = " toprddays >=" & PrdDay & " and fromprddays <=" & PrdDay _
                                & " and toprdmonths =0 and toprdyears =0 "
            If RsRateDup1.RecordCount = 1 Then
                ROI = RsRateDup1!Rate
                BaseRateCode = IIf(IsNull(RsRateDup1!BaseRateCode), "", RsRateDup1!BaseRateCode)
                BaseRateSymbol = IIf(IsNull(RsRateDup1!BaseRateSymbol), "", RsRateDup1!BaseRateSymbol)
            Else
                errMsg = "No rate for this period"
                GoTo errHand
            End If
        ElseIf RsRate.RecordCount = 1 Then
            ROI = RsRate!Rate
            BaseRateCode = IIf(IsNull(RsRate!BaseRateCode), "", RsRate!BaseRateCode)
            BaseRateSymbol = IIf(IsNull(RsRate!BaseRateSymbol), "", RsRate!BaseRateSymbol)
        Else
            RsRate.Filter = " FROMCONVDAYS <=" & PrdDay _
                    & " and TOCONVDAYS >=" & PrdDay
                If RsRate.RecordCount = 1 Then
                    ROI = RsRate!Rate
                Else
                    errMsg = "No slab available for this period."
                    GoTo errHand
                End If
        End If
       
    End If

End If

If ROI > 0 Then
RateOfInterest = "ROI"
Else
RateOfInterest = "Rate Of Interest not available"
End If

Exit Function

errHand:
If errMsg = "" Then
    RateOfInterest = Err.Number & " : " & Err.Description
    RateOfInterest = Replace(RateOfInterest, Chr(10), "")
    RateOfInterest = Replace(RateOfInterest, Chr(13), "")
Else
    RateOfInterest = errMsg
    RateOfInterest = Replace(RateOfInterest, Chr(10), "")
    RateOfInterest = Replace(RateOfInterest, Chr(13), "")
End If
End Function

Public Function GetROI(CurrencyCode As String, _
                                  strGlcode As String, _
                                  strCategoryCode As String, _
                                  StrEffectiveDate As String, _
                                  StrMaturityDate As String, _
                                  DblAmount As Double) As Variant
                                  
strCurCode = CurrencyCode
Glcode = strGlcode
Amount = IIf(IsNull(DblAmount), 0, DblAmount)
CategoryCode = strCategoryCode
EffectDate = StrEffectiveDate
MatDate = StrMaturityDate

Call DbConnection
On Error GoTo errHand
If ConnError <> "Connected" Then
    strMsg = ConnError
    GoTo errHand
End If

EffectDate = Format(EffectDate, "dd-MMM-yyyy")
MatDate = Format(MatDate, "dd-MMM-yyyy")
Set Rstemp = CreateObject("ADODB.Recordset")


If (Amount = 0) Or (MatDate = "") Or (EffectDate = "") Or (CategoryCode = "") Or (strCurCode = "") Or (Glcode = "") Then
    strMsg = "Please Check The Details"
    GoTo errHand
End If


'''''''''''''********************************************************************************
'''''''''''''********************************************************************************
strFlds = "RATE"
strCond = "currencycode='" & strCurCode & "' and glcode='" & Glcode & _
            "' AND (categorycode='" & CategoryCode & "' OR categorycode=99) AND " & _
            " effectivedate=(SELECT MAX(effectivedate) FROM GENINTERESTDTLS g  WHERE " & _
            " currencycode=g.currencycode AND glcode=g.glcode AND categorycode=g.categorycode AND " & _
            " (categorycode='" & CategoryCode & "' OR categorycode=99) and effectivedate<=TO_DATE('" & EffectDate & "') AND (SELECT FLOOR(TO_DATE('" & _
            MatDate & "')-TO_DATE('" & EffectDate & _
            "')) FROM dual)>= DECODE(fromprdsymbol,'>',fromconvdays+1,'>=',fromconvdays,'=',fromconvdays) " & _
            " AND (SELECT FLOOR(TO_DATE('" & MatDate & "')-TO_DATE('" & EffectDate & "')) " & _
            " FROM dual)<= DECODE(Toprdsymbol,'<',Toconvdays-1,'<=',Toconvdays,'=',Toconvdays) " & _
            " AND " & Amount & " >= DECODE(fromamtsymbol,'>',fromamount+1,'>=',fromamount,'=',fromamount) " & _
            " AND " & Amount & " <= DECODE(toamtsymbol,'<',toamount-1,'<=',toamount,'=',toamount)) " & _
            " and (SELECT FLOOR(TO_DATE('" & _
            MatDate & "')-TO_DATE('" & EffectDate & _
            "')) FROM dual)>= DECODE(fromprdsymbol,'>',fromconvdays+1,'>=',fromconvdays,'=',fromconvdays) " & _
            " AND (SELECT FLOOR(TO_DATE('" & MatDate & "')-TO_DATE('" & EffectDate & "')) " & _
            " FROM dual)<= DECODE(Toprdsymbol,'<',Toconvdays-1,'<=',Toconvdays,'=',Toconvdays) " & _
            " AND " & Amount & " >= DECODE(fromamtsymbol,'>',fromamount+1,'>=',fromamount,'=',fromamount) " & _
            " AND " & Amount & " <= DECODE(toamtsymbol,'<',toamount-1,'<=',toamount,'=',toamount)"
            
strQuery = "select " & strFlds & " from GENINTERESTDTLS where " & strCond & ""

Set RsBaseRate = AdoConnObj.Execute(strQuery)

    If RsBaseRate.RecordCount > 0 Then
        strMsg = "ROI"
        ROI = (RsBaseRate!Rate)
        RsBaseRate.Close
    Else
        RsBaseRate.Close
        strMsg = RateOfInterest
        RsBaseRate.Close
        
    End If

If strMsg = "ROI" Then
   arrRate(0) = strMsg
   arrRate(1) = ROI
Else
    GoTo errHand
End If

Set objQuery = Nothing
GetROI = arrRate
Exit Function

errHand:

Set objQuery = Nothing
arrRate(0) = "ERROR"
If strMsg = "" Then
    arrRate(1) = Err.Number & " : " & Err.Description
Else
    arrRate(1) = strMsg
End If
GetROI = arrRate
End Function



