VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4935
   ClientLeft      =   240
   ClientTop       =   2325
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   ScaleHeight     =   4935
   ScaleWidth      =   6585
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   390
      Left            =   1920
      TabIndex        =   0
      Top             =   1080
      Width           =   1665
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Obj As Object

Private Sub Command1_Click()
'Set Obj = CreateObject("DeptInstrInsert.BookLeafDeptInsert")
Dim Obj As New DeptInstrInsert1.BookLeafDeptInsert
Dim str As String

'str = Obj.CustInstruments("gendeptcustinstrstockdtls", "9999", "SB", "ANUPAMA", "10-10-2001", "10-10-2001", "CHQ", _
'                    "B", "10", "PQR", "1", "20", "", "", "", "", "2", "", "yyy", "uuu")
                    
Dim Stno(2)
Stno(0) = 500051
Stno(1) = 500061
Stno(2) = 500071


'str = Obj.CustInstruments("gendeptcustinstrstockdtls", "9999", "SB", "ANUPAMA", "10-10-2001", "10-10-2001", "CHQ", _
                    "B", "10", "PQR", "1", "20", "", "", "", "", "2", "", "yyy", "uuu")
                   
'str = Obj.CustInstruments("gendeptcustinstrstockdtls", "999", "REM", "DAMODAR", "29-mAY-2007", "29-mAY-2007", "BC", _
'                   "Y", "10", "", "460001", "460030", "", "", "", "", "3", "", "Damodar", "localhost", stno)
'for leafs
str = Obj.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS", "999", "REM", "DAMODAR", "29-mAY-2007", "29-mAY-2007", "CHQ", _
          "", "", "", "", "", "Y", "", "800506", "800510", "", 5, "Damodar", "localhost", , 800501)



'str = Obj.CustInstruments("gendeptcustinstrstockdtls", "999", "REM", "DAMODAR", "29-mAY-2007", "29-mAY-2007", "BC", _
 '                  "Y", "10", "", "500051", "500080", "", "", "", "", "3", "", "Damodar", "localhost", Stno, "500001")


MsgBox (str)
                    
                    
                    
End Sub
