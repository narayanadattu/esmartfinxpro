VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "Transaction"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'Dim ObjContext As ObjectContext
'Dim ObjTrans As Object
'Dim ObjTrans As New TransactionMethods
Dim ObjFetchRec As Object
''Dim ObjFetchRec As New FetchRecordsets
Dim RecNPAParam As Recordset
Dim RecLoanmst As Recordset
Dim RecLoan As Recordset
Dim RecRecoveryDt As Recordset
Dim RecRecoveryBal As Recordset
Dim RecLoanBal As Recordset
Dim recRecovDt As Recordset
Dim RecRecovBal As Recordset
Dim RecLoans As Recordset
Dim RecIntRecovery As Recordset
Dim RecIntRecoverybal As Recordset
Dim LoanPrevBal As Double
Dim LoanBal As Double
Dim icnt As Long
Dim StrArr() As Variant
Dim st As String
Dim i As Double
Dim BalAmt As Double
Dim LoanAmt As Double
Dim Crbal As Long
Dim RecCurBal As Recordset
Public Function NpaTransaction(BranchCode As String, CurrencyCode As String, _
                                CutOffDt As String, GlId As String) As Variant
'''' declaring variables

Dim BrCode As String
Dim CurCode As String
Dim CutOffDate As String
Dim IntCutOffDate As String
Dim GlCode As String
Dim TransResult As String
Dim StrIntBal As String
Dim StrIntCr As String
 Dim Crbal As Long
On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********
BrCode = UCase(Trim(BranchCode))
CurCode = UCase(Trim(CurrencyCode))
'CutOffDate = Format(CutOffDt, "dd-mm-yyyy")
CutOffDate = CutOffDt
IntCutOffDate = CutOffDt
GlCode = UCase(Trim(GlId))
icnt = 0
StrIntBal = 0
StrIntCr = 0
Dim strst
strst = ""
'''setting the Recordsets
ReDim StrArr(0)
Set RecNPAParam = CreateObject("Adodb.Recordset")
Set RecLoanmst = CreateObject("Adodb.Recordset")
Set RecLoan = CreateObject("adodb.recordset")
Set RecRecoveryDt = CreateObject("adodb.recordset")
Set RecRecoveryBal = CreateObject("adodb.recordset")
Set RecLoanBal = CreateObject("adodb.recordset")
Set recRecovDt = CreateObject("adodb.recordset")
Set RecRecovBal = CreateObject("adodb.recordset")
Set RecLoans = CreateObject("adodb.recordset")
Set RecIntRecovery = CreateObject("adodb.recordset")

Set RecIntRecoverybal = CreateObject("adodb.recordset")

'''' Calling the General Query recordset component for querying
Set ObjFetchRec = CreateObject("queryrecordsets.fetchrecordsets")

'''setting the recordset for fetching the principle recovery months,pastdue and
''''interest recovery months,past due

Set RecNPAParam = ObjFetchRec.SingleRecordSet("NPAASSETTYPEPMT", _
                "nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)," & _
                "nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(PRINRECOVERYDAYS, 0)," & _
                "nvl(INTRECOVERYDAYS, 0)", _
                "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(glcode))='" & GlCode & "'")

If Not RecNPAParam.EOF And Not RecNPAParam.BOF Then
''''calculating the npa priniciple calc date for the given cuttoffdate
   
    CutOffDate = DateAdd("M", "-" & Val(RecNPAParam(0)) + Val(RecNPAParam(1)), _
                    Format(CutOffDate, "dd-mm-yyyy"))
     CutOffDate = DateAdd("D", "-" & Val(RecNPAParam(4)), _
                    Format(CutOffDate, "dd-mm-yyyy"))
    CutOffDate = Format(CutOffDate, "dd-mm-yyyy")
    ''''calculating the npa interest calc date for the given cuttoffdate
    IntCutOffDate = DateAdd("M", "-" & Val(RecNPAParam(2)) + Val(RecNPAParam(3)), _
                    Format(IntCutOffDate, "dd-mm-yyyy"))
     IntCutOffDate = DateAdd("D", "-" & Val(RecNPAParam(5)), _
                    Format(IntCutOffDate, "dd-mm-yyyy"))
    IntCutOffDate = Format(IntCutOffDate, "dd-mm-yyyy")
    

Else

    StrArr(0) = "NoRecords" & Err.Description
    StrArr(0) = Replace(StrArr(0), Chr(10), "")
    StrArr(0) = Replace(StrArr(0), Chr(13), "")
    NpaTransaction = StrArr
    Exit Function
End If
'''setting the recordset for  fetching the max repayduedate from loanaccnos,name from
''''loanscheduledts,loanmst when the NPA Calcdate is not exactly match the repayduedate in
'''loanrecoverydts table

 Set RecLoanmst = ObjFetchRec.SingleRecordSet("loanmst l,loantypemst t,LOANSCHEDULEDTLS s", _
                "distinct(s.accno),l.name, nvl(l.SANCTIONEDAMT, 0)", _
                "upper(trim(l.branchcode))='" & BrCode & "' and " & _
                "upper(trim(l.currencycode))='" & CurCode & "' and " & _
                "upper(trim(l.glcode))='" & GlCode & "' and " & _
                "upper(trim(t.NPACLASSIFIABLEYN))='Y' and " & _
                "l.glcode=t.glcode and " & _
                "s.glcode in(select glcode from loanmst) and " & _
                "s.accno in(select accno from loanmst) and " & _
                "(l.status='R' and l.opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') or " & _
                "l.status='C' and l.CLOSEDATE>=to_date('" & CutOffDt & "','dd-mm-yyyy') and l.opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')) AND " & _
                "l.accno=s.accno", "s.accno")
'''"s.REPAYDUEDATE<=to_date('" & CutOffDate & "', 'dd-mm-yyyy')  and " & '_
    If Not RecLoanmst.EOF Then
   
        ReDim StrArr(RecLoanmst.RecordCount - 1)
   
     Do Until RecLoanmst.EOF
     LoanBal = 0
     LoanAmt = 0
     Crbal = 0
    Set RecLoan = CreateObject("adodb.recordset")
Set RecRecoveryDt = CreateObject("adodb.recordset")
Set RecRecoveryBal = CreateObject("adodb.recordset")
Set RecLoanBal = CreateObject("adodb.recordset")
Set recRecovDt = CreateObject("adodb.recordset")
Set RecRecovBal = CreateObject("adodb.recordset")
Set RecLoans = CreateObject("adodb.recordset")

'''------------------------------------------------
    '''------------------------------------------------------------------------
                  ''''setting the recordsets to  fetch the current priniciple balance
                '''' from the recovery table as on parametarised date

                 ''' a recordset for if parameter date not exactly match to
                 '''' recoverydtls paid date fetch immediate previous date
                        Set recRecovDt = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                 "max(to_char(applicationdate,'dd-mm-yyyy'))", _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate<=to_date('" & CutOffDt & "', 'dd-mm-yyyy') group by accno")
                                 
                                 
                 

                        If Not recRecovDt.EOF And Not recRecovDt.BOF Then
                       '''' a recordset for fetching the balance as on or just previous
                       '''''recoverydtls date in recoverydtls table

                        Set RecRecovBal = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                        "nvl(TOTALBAL,0),nvl(PRINCIPLECR,0)", _
                                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                                    "upper(trim(glcode))='" & GlCode & "' and " & _
                                    "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                    "applicationdate=to_date('" & recRecovDt(0) & "', 'dd-mm-yyyy') AND " & _
                                    "TRANNO IN(SELECT MAX(TRANNO) FROM LOANRECOVERYDTLS WHERE " & _
                                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                                    "upper(trim(glcode))='" & GlCode & "' and " & _
                                    "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                    "applicationdate=to_date('" & recRecovDt(0) & "', 'dd-mm-yyyy'))")
                                    If Not RecRecovBal.EOF And Not RecRecovBal.EOF Then
                                       
                                         If Not IsNull(RecRecovBal(0)) Then
                                            LoanBal = RecRecovBal(0)
                                            Crbal = RecRecovBal(1)
                                        Else
                                            LoanBal = 0
                                            Crbal = 0
                                        End If
                                    End If

                        End If
                        '''''-----------------------------------



''''------------------------------------------------------
Set RecLoans = ObjFetchRec.SingleRecordSet("LOANSCHEDULEDTLS", _
               "max(to_char(REPAYDUEDATE,'dd-mm-yyyy'))", _
               "accno='" & RecLoanmst(0) & "' and " & _
                "REPAYDUEDATE<=to_date('" & CutOffDate & "', 'dd-mm-yyyy')")
     
   If Not RecLoans.EOF And RecLoans(0) <> "" Then
   
   ''''' setting a recordset for fetching the balanceamt,curbal from loanscheduledtls,
   '''''loanbalance tables on NPACalcdate
            Set RecLoan = ObjFetchRec.SingleRecordSet("LOANSCHEDULEDTLS S,loanmst b", _
                        " nvl(s.balanceamt,0), nvl(b.SANCTIONEDAMT,0),b.opdate", "upper(trim(s.branchcode))='" & BrCode & "' and " & _
                        "upper(trim(s.glcode))='" & GlCode & "' and " & _
                        "upper(trim(s.currencycode))='" & CurCode & "' and " & _
                        "s.accno='" & RecLoanmst(0) & "' and " & _
                        "s.accno=b.accno and " & _
                        "s.REPAYDUEDATE=to_date('" & RecLoans(0) & "', 'dd-mm-yyyy')")


               If Not RecLoan.EOF Then
       
                    BalAmt = RecLoan(0)
                    LoanAmt = RecLoan(1)
         
         ''' setting the recordset for fetching the maxDate from the loanrecoverydtls
        '''when npacalcdate is not exactly match the applicationdate in the
        ''''loanrecoverydate

                 Set RecRecoveryDt = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                 "max(to_char(applicationdate,'dd-mm-yyyy'))", _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate<=to_date('" & CutOffDt & "', 'dd-mm-yyyy')  and " & _
                                 "tranno in (select max(tranno) from LOANRECOVERYDTLS where " & _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate<=to_date('" & CutOffDt & "', 'dd-mm-yyyy')) " & _
                                 "group by accno")
                     If Not RecRecoveryDt.EOF And Not RecRecoveryDt.BOF Then

                    Rem  setting the recordset for fetching the principle bal from the
                    ''' loanrecoverydtls  on the npacalcdate
                     Set RecRecoveryBal = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                    "nvl(PRINCIPLEBAL,0),nvl(PRINCIPLECR,0)", _
                                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                                    "upper(trim(glcode))='" & GlCode & "' and " & _
                                    "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                    "applicationdate=to_date('" & RecRecoveryDt(0) & "', 'dd-mm-yyyy') and " & _
                                 "tranno in (select max(tranno) from LOANRECOVERYDTLS where " & _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate=to_date('" & RecRecoveryDt(0) & "', 'dd-mm-yyyy'))")
                         If Not RecRecoveryBal.EOF And Not RecRecoveryBal.EOF Then
                            ''' if recoverybalance is lessthan or eual to loanschedule balance then
                            '''' that accno is PA
                             If IsNull(RecRecoveryBal(0)) Then
                                RecRecoveryBal(0) = 0
                                End If
                                If Val(RecRecoveryBal(0)) <= Val(BalAmt) Then

                                 ' StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & LoanAmt & "~" & RecRecoveryBal(0) & "~" & RecRecoveryBal(1) & "|PA"
                                  strst = "PA"
                                  '''if acc=pa go for interest npa calculation
                                  
                                  
                                  
                                  
                                Else
                                    StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & LoanAmt & "~" & RecRecoveryBal(0) & "~" & RecRecoveryBal(1) & "|NPA"
                                End If
                        Else
                            
                              '''' if accno is not paid any balance in loanrecoverydtls table
                                StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & LoanAmt & "~" & LoanBal & "~" & Crbal & "|NPA"
                       End If
                    Else
                    '''if accno is not paid any balance on npaCalcdate take the paid balance as last paid balance
                      StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & LoanAmt & "~" & LoanBal & "~" & Crbal & "|NPA"
                    End If
            Else
                StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & RecLoanmst(2) & "~" & LoanBal & "~" & Crbal & "|PA"
        
            End If
'''--------
Else
    'StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & RecLoanmst(2) & "~" & LoanBal & "~" & Crbal & "|PA"
    strst = "PA"
End If

'''----------------
''''''-------------------------------------------------
''''if the accno is PA then
    If strst = "PA" Then
                                  '''''checking interest wise npa calculation
                                  ''''1.calculate the adjust date i.e from parameter date - interest period
                                  ''' above it is calculated and store it in IntCutOffDate variable
                                  '''2.fetch the interest balance from loanrecoverydtls as on(<=) that adjust date
                                  Set RecIntRecovery = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                 "nvl(INTERESTBAL,0)", _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate=(select max(applicationdate) from " & _
                                 "LOANRECOVERYDTLS  where upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate<=to_date('" & IntCutOffDate & "', 'dd-mm-yyyy')) and " & _
                                 "tranno in (select max(tranno) from LOANRECOVERYDTLS where " & _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate=(select max(applicationdate) from " & _
                                 "LOANRECOVERYDTLS  where upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate<=to_date('" & IntCutOffDate & "', 'dd-mm-yyyy')))")

                                  If Not RecIntRecovery.EOF And Not RecIntRecovery.BOF Then
                                  StrIntBal = RecIntRecovery(0)
                                  End If
                                '''3.fetch the sum(interest credit) from loanrecoverydtls between the
                                '''' adjust date and parameter date
                                Set RecIntRecoverybal = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", _
                                 "nvl(sum(INTERESTCR),0)", _
                                 "upper(trim(branchcode))='" & BrCode & "' and " & _
                                 "upper(trim(glcode))='" & GlCode & "' and " & _
                                 "trim(accno)='" & Trim(RecLoanmst(0)) & "' and " & _
                                 "applicationdate>=to_date('" & IntCutOffDate & "', 'dd-mm-yyyy') and  " & _
                                 "applicationdate<=to_date('" & CutOffDt & "', 'dd-mm-yyyy')")
                                  If Not RecIntRecoverybal.BOF And Not RecIntRecoverybal.EOF Then
                                  StrIntCr = RecIntRecoverybal(0)
                                  End If
                                  If CDbl(StrIntCr) >= Abs(CDbl(StrIntBal)) Then
                                     StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & RecLoanmst(2) & "~" & LoanBal & "~" & LoanBal & "|PA"
                                  Else
                                     StrArr(icnt) = RecLoanmst(0) & "~" & RecLoanmst(1) & "~" & RecLoanmst(2) & "~" & LoanBal & "~" & LoanBal & "|NPA"
                                  End If
                                  strst = ""
''''''--------------------------------------------------
    End If
      icnt = icnt + 1
     RecLoanmst.MoveNext
    Loop
 Else
  StrArr(0) = "NoRecords"
    NpaTransaction = StrArr
       Set ObjFetchRec = Nothing
   Set RecLoan = Nothing
   Set RecLoanmst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
   Set RecLoanBal = Nothing
   Set RecLoans = Nothing
    Exit Function
    End If
    Set ObjFetchRec = Nothing
   Set RecLoan = Nothing
   Set RecLoanmst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
   Set RecLoanBal = Nothing
    Set RecLoans = Nothing

   NpaTransaction = StrArr

Exit Function

ErrHand:


Set RecLoan = Nothing
   'Set RecLoanMst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
   Set RecLoanBal = Nothing
'If Trim(TransResult) <> "" Then
'*************Connection Failed************

   ' NpaTransaction = TransResult
 'Else
 StrArr(0) = Err.Number
 StrArr(0) = Replace(StrArr(0), Chr(10), "")
 StrArr(0) = Replace(StrArr(0), Chr(13), "")
 NpaTransaction = StrArr
    
' End If

End Function

Public Function CCTransaction(BranchCode As String, CurrencyCode As String, _
                                CutOffDt As String, GlId As String) As Variant
'''' declaring variables
Dim RecCCMst As Recordset
Dim RecCCTran As Recordset
Dim RecTran As Recordset
Dim RecRecoveryDt As Recordset
Dim RecRecoveryBal As Recordset
Dim RecLimit As Recordset
Dim RecTranBal As Recordset
Dim RecLimitBal As Recordset
Dim RecTranBal1 As Recordset
Dim RecLimitBal1 As Recordset
Dim LimitBal As Long
Dim DispLimitBal As Long
Dim DispTranBal As Long
Dim Status As String
Dim BrCode As String
Dim CurCode As String
Dim CutOffDate As String
Dim GlCode As String
Dim TransResult As String
Dim icnt As Long
 Dim Crbal As Long
On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********
BrCode = UCase(Trim(BranchCode))
CurCode = UCase(Trim(CurrencyCode))
'CutOffDate = Format(CutOffDt, "dd-mm-yyyy")
CutOffDate = CutOffDt
GlCode = UCase(Trim(GlId))
icnt = 0
Dim TranBal As Long
'''setting the Recordsets
ReDim StrArr(0)
Set RecNPAParam = CreateObject("Adodb.Recordset")
Set RecCCMst = CreateObject("Adodb.Recordset")
Set RecCCTran = CreateObject("adodb.recordset")
Set RecTran = CreateObject("adodb.recordset")
Set RecRecoveryDt = CreateObject("adodb.recordset")
Set RecRecoveryBal = CreateObject("adodb.recordset")
Set RecLimit = CreateObject("adodb.recordset")
Set RecTranBal = CreateObject("adodb.recordset")
Set RecLimitBal = CreateObject("adodb.recordset")
Set RecTranBal1 = CreateObject("adodb.recordset")
Set RecLimitBal1 = CreateObject("adodb.recordset")
'''' Calling the General Query recordset component for querying
Set ObjFetchRec = CreateObject("queryrecordsets.fetchrecordsets")

'''setting the recordset for fetching the principle recovery months,pastdue and
''''interest recovery months,past due

Set RecNPAParam = ObjFetchRec.SingleRecordSet("NPAASSETTYPEPMT", _
                "nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0),INTRECOVERYMTHS,INTPASTDUEMTHS", _
                "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(glcode))='" & GlCode & "'")

If Not RecNPAParam.EOF And Not RecNPAParam.BOF Then
''''calculating the npa calc date for the given cuttoffdate
  
    CutOffDate = DateAdd("M", "-" & Val(RecNPAParam(0)) + Val(RecNPAParam(1)), _
                    Format(CutOffDate, "dd-mm-yyyy"))
    CutOffDate = Format(CutOffDate, "dd-mm-yyyy")

Else

    StrArr(0) = "NoRecords" & Err.Description
    StrArr(0) = Replace(StrArr(0), Chr(10), "")
    StrArr(0) = Replace(StrArr(0), Chr(13), "")
    CCTransaction = StrArr

    Exit Function
End If
''' setting a recordset for fetching Accno,name  from CCMst
Set RecCCMst = ObjFetchRec.SingleRecordSet("ccmst l", _
                "distinct(l.accno),l.customerid,l.name", _
                "upper(trim(l.branchcode))='" & BrCode & "' and " & _
                "upper(trim(l.currencycode))='" & CurCode & "' and " & _
                "upper(trim(l.glcode))='" & GlCode & "' and " & _
                "(l.status='R' and l.opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') or " & _
                "l.status='C' and l.CLOSEDATE>=to_date('" & CutOffDt & "','dd-mm-yyyy') and l.opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy'))", _
                "l.accno")
    
    If Not RecCCMst.EOF Then
    '''' redimentioning the array variable which is return by function
        ReDim StrArr(RecCCMst.RecordCount - 1)
   
     Do Until RecCCMst.EOF
DispTranBal = 0
DispLimitBal = 0
Set RecTranBal = CreateObject("adodb.recordset")
Set RecLimitBal = CreateObject("adodb.recordset")
Set RecTranBal1 = CreateObject("adodb.recordset")
Set RecLimitBal1 = CreateObject("adodb.recordset")
Set RecLimit = CreateObject("adodb.recordset")
Set RecCCTran = CreateObject("adodb.recordset")
Set RecTran = CreateObject("adodb.recordset")
Set RecRecoveryDt = CreateObject("adodb.recordset")
Set RecRecoveryBal = CreateObject("adodb.recordset")


''' 1 st Condition
'''' a condition
'''setting a recordset for fetching dayendbal from cctran as on parameter date
TranBal = 0
Set RecTranBal = ObjFetchRec.SingleRecordSet("cctran", _
                    "max(applicationdate)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(currencycode))='" & CurCode & "' and " & _
                    "upper(trim(glcode))='" & GlCode & "' and " & _
                    "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                    "applicationdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') group by accno")
        If Not RecTranBal.EOF Then
        
            Set RecTranBal1 = ObjFetchRec.SingleRecordSet("cctran", _
                            "nvl(dayendbal,0)", _
                            "tranno in(select max(tranno) from cctran where " & _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(glcode))='" & GlCode & "' and " & _
                            "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                            "applicationdate='" & RecTranBal(0) & "')")
                    
                If Not RecTranBal1.EOF Then
                    TranBal = RecTranBal1(0)
                    DispTranBal = RecTranBal1(0)
                    
                End If
        Else
            
        End If
 '''setting a recordset for fetching limitbal from genlimitlink
       Set RecLimitBal = ObjFetchRec.SingleRecordSet("genlimitlnk", _
                    "max(applicationdate)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(linkedmoduleid))='CC' and " & _
                            "upper(trim(linkedglcode))='" & GlCode & "' and " & _
                            "upper(trim(linkedaccno))='" & RecCCMst(0) & "' and " & _
                            "(upper(trim(STATUS))='R' and " & _
                            "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') or " & _
                            "upper(trim(status))='C' and " & _
                            "linkdate>=to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                            "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')) group by linkedaccno")
            If Not RecLimitBal.EOF Then
                Set RecLimitBal1 = ObjFetchRec.SingleRecordSet("genlimitlnk", _
                                "sum(nvl(LINKEDAMOUNT,0))", _
                                "upper(trim(branchcode))='" & BrCode & "' and " & _
                                "upper(trim(currencycode))='" & CurCode & "' and " & _
                                "upper(trim(linkedmoduleid))='CC' and " & _
                                "upper(trim(linkedglcode))='" & GlCode & "' and " & _
                                "upper(trim(linkedaccno))='" & RecCCMst(0) & "' and " & _
                                "(upper(trim(STATUS))='R' and " & _
                                "linkdate='" & RecLimitBal(0) & "' or " & _
                                "upper(trim(status))='C' and " & _
                                "linkdate>=to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                                "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')) group by linkedaccno")
                          If Not RecLimitBal1.EOF Then
                          LimitBal = RecLimitBal1(0)
                          DispLimitBal = RecLimitBal1(0)
                          End If
                                
                                
            End If
    
    '''checking limitbal is exceeding the limitbal(a)
    If Val(TranBal) < 0 Then
        If Abs(Val(TranBal)) <= Val(LimitBal) Then
            Status = "PA"
        Else
        TranBal = 0
        LimitBal = 0
        ''''b Condition
        '''setting a recordset for fetching dayendbal from cctran as on parameter date
            Set RecTranBal = ObjFetchRec.SingleRecordSet("cctran", _
                    "max(applicationdate)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(currencycode))='" & CurCode & "' and " & _
                    "upper(trim(glcode))='" & GlCode & "' and " & _
                    "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                    "applicationdate<=to_date('" & CutOffDate & "','dd-mm-yyyy') group by accno")
            If Not RecTranBal.EOF Then
                Set RecTranBal1 = ObjFetchRec.SingleRecordSet("cctran", _
                            "nvl(dayendbal,0)", _
                            "tranno in(select max(tranno) from cctran where " & _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(glcode))='" & GlCode & "' and " & _
                            "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                            "applicationdate='" & RecTranBal(0) & "')")
                    
                If Not RecTranBal1.EOF Then
                    
                    TranBal = RecTranBal1(0)
                End If
                Else
            
                End If
        
         '''setting a recordset for fetching limitbal from genlimitlink
                Set RecLimitBal = ObjFetchRec.SingleRecordSet("genlimitlnk", _
                            "max(applicationdate)", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(linkedmoduleid))='CC' and " & _
                            "upper(trim(linkedglcode))='" & GlCode & "' and " & _
                            "upper(trim(linkedaccno))='" & RecCCMst(0) & "' and " & _
                            "(upper(trim(STATUS))='R' and " & _
                            "linkdate<=to_date('" & CutOffDate & "','dd-mm-yyyy') or " & _
                            "upper(trim(status))='C' and " & _
                            "linkdate>=to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                            "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')) group by linkedaccno")
                If Not RecLimitBal.EOF Then
                    Set RecLimitBal1 = ObjFetchRec.SingleRecordSet("genlimitlnk", _
                                "sum(nvl(LINKEDAMOUNT,0))", _
                                "upper(trim(branchcode))='" & BrCode & "' and " & _
                                "upper(trim(currencycode))='" & CurCode & "' and " & _
                                "upper(trim(linkedmoduleid))='CC' and " & _
                                "upper(trim(linkedglcode))='" & GlCode & "' and " & _
                                "upper(trim(linkedaccno))='" & RecCCMst(0) & "' and " & _
                                "(upper(trim(STATUS))='R' and " & _
                                "linkdate='" & RecLimitBal(0) & "') or " & _
                                "upper(trim(status))='C' and " & _
                                "linkdate>=to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                                "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')")
                          If Not RecLimitBal1.EOF Then
                          LimitBal = RecLimitBal1(0)
                          End If
                                
                                
            End If
    
    '''checking limitbal is exceeding the limitbal(a)
    If Val(TranBal) < 0 Then
        If Abs(Val(TranBal)) <= Val(LimitBal) Then
           Status = "PA"
        Else
        ''''c Condition
   
        TranBal = 0
       LimitBal = 0
       ''setting a recordset for fetching each day max(trano) from cctran in between paramerdate
       ''' and calc date
        Set RecCCTran = ObjFetchRec.SingleRecordSet("CCTran", _
                    "applicationdate,max(tranno)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(currencycode))='" & CurCode & "' and " & _
                    "upper(trim(glcode))='" & GlCode & "' and " & _
                    "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                    "applicationdate<to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                    "applicationdate>to_date('" & CutOffDate & "','dd-mm-yyyy') group by applicationdate")
            If RecCCTran.RecordCount > 0 Then
          ' If Not RecCCTran.EOF Then
                Do Until RecCCTran.EOF
                ''setting a recordset for fetching the dayendbal in above seleted max(tranno)
                
                    Set RecTranBal = ObjFetchRec.SingleRecordSet("cctran", _
                            "nvl(dayendbal,0)", _
                            "tranno in(select max(tranno) from cctran where " & _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(glcode))='" & GlCode & "' and " & _
                            "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                            "tranno='" & RecCCTran(1) & "' and " & _
                            "applicationdate='" & RecCCTran(0) & "')")
                           If Not RecTranBal.EOF Then
                            TranBal = RecTranBal(0)
                           End If
              '''setting a recordset for fetching the linked amount from genlimitlnk
              ''' for each day
              Set RecLimit = ObjFetchRec.SingleRecordSet("GENLIMITLNK", _
                            "sum(nvl(LINKEDAMOUNT,0))", _
                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                            "upper(trim(linkedmoduleid))='CC' and " & _
                            "upper(trim(linkedglcode))='" & GlCode & "' and " & _
                            "upper(trim(linkedaccno))='" & RecCCMst(0) & "' and " & _
                            "(upper(trim(STATUS))='R' and " & _
                            "linkdate<='" & RecCCTran(0) & "' or " & _
                            "upper(trim(status))='C' and " & _
                            "linkdate>=to_date('" & CutOffDt & "','dd-mm-yyyy') and " & _
                            "linkdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')) " & _
                            " group by linkedaccno,applicationdate")
                        If Not RecLimit.EOF Then
                        LimitBal = RecLimit(0)
                        End If
                ''''checking limitbal is exceeding the balance for each day
                 If Val(TranBal) < 0 Then
                    If Abs(Val(TranBal)) <= Val(LimitBal) Then
                    Status = "PA"
                    Exit Do
                    Else
                    StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|NPA"
                    Status = "NPA"
                    End If
                 Else
                    Status = "PA"
                 End If
            RecCCTran.MoveNext
            Loop
              
          ' End If
    Else
        StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|NPA"
        Status = "NPA"
    End If
                         
                    
    End If
 Else
 Status = "PA"
 End If
End If
Else
Status = "PA"
End If
    If Status = "PA" Then
    
    
 ''''2nd  condition no credits in parameterised period continueosly
 
      ''' setting a recordset for fetching noof credit transactions and sum of credits within
      ''''cutoffdate,parameterdate
      
                Set RecTran = ObjFetchRec.SingleRecordSet("CCTran", _
                "count(*),sum(amount)", _
                "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(currencycode))='" & CurCode & "' and " & _
                "upper(trim(glcode))='" & GlCode & "' and " & _
                "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                "(modeoftran='2' or modeoftran='4' or modeoftran='6') and " & _
                "applicationdate>=to_date('" & CutOffDate & "','dd-mm-yyyy') and " & _
                "applicationdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')" & _
                " group by accno")
                
                If Not RecTran.EOF Then
                '''' setting a recordset for fetching sum of chargesDr and sum of
                '''interestDr from loanrecoverydtls for particular account
                ''''within cutoffdate,parameterdate
        '''''3rd condition totalcr= sum(chargesdb)+sum(interestdb)
                            Set RecRecoveryDt = ObjFetchRec.SingleRecordSet("ccrecoverydtls", _
                                            "nvl(sum(CHARGESDB),0),nvl(sum(INTERESTDB),0)", _
                                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                                            "upper(trim(currencycode))='" & CurCode & "' and " & _
                                            "upper(trim(glcode))='" & GlCode & "' and " & _
                                            "upper(trim(accno))='" & RecCCMst(0) & "' and " & _
                                            "applicationdate>=to_date('" & CutOffDate & "','dd-mm-yyyy') and " & _
                                            "applicationdate<=to_date('" & CutOffDt & "','dd-mm-yyyy')" & _
                                            "")
                                            If Not RecRecoveryDt.EOF Then
                                                If Val(RecTran(1)) >= Val(RecRecoveryDt(0)) + Val(RecRecoveryDt(1)) Then
                                                    StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|PA"
                                                Else
                                                    
                                                    StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|NPA"
                                                    Status = "NPA"
                                                End If
                                            Else
                                               StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|NPA"
                                            End If
                                              
                        
                    Else '''(for rectran)
                    StrArr(icnt) = RecCCMst(0) & "~" & RecCCMst(2) & "~" & DispTranBal & "~" & DispLimitBal & "|NPA"
                    End If
                      
            
  End If
   
  ''''---------

       icnt = icnt + 1
   
    
    RecCCMst.MoveNext
    Loop
 Else
 ''ReDim StrArr(0)

 StrArr(0) = "NoRecords"
    CCTransaction = StrArr
       Set ObjFetchRec = Nothing
   Set RecCCTran = Nothing
   Set RecCCMst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
   Set RecLimit = Nothing
    Exit Function
    End If
    Set ObjFetchRec = Nothing
   Set RecCCTran = Nothing
   Set RecCCMst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
  Set RecLimit = Nothing

   CCTransaction = StrArr

Exit Function

ErrHand:


'Set Reccc = Nothing
   'Set RecLoanMst = Nothing
   Set RecRecoveryBal = Nothing
   Set RecRecoveryDt = Nothing
   
'If Trim(TransResult) <> "" Then
'*************Connection Failed************

   
 'Else
 StrArr(0) = Err.Number
 StrArr(0) = Replace(StrArr(0), Chr(10), "")
 StrArr(0) = Replace(StrArr(0), Chr(13), "")
    CCTransaction = StrArr
' End If

End Function
Public Function BillTransaction(BranchCode As String, CurrencyCode As String, _
                                CutOffDt As String, GlId As String) As Variant
'''' declaring variables)
Dim BrCode As String
Dim CurCode As String
Dim CutOffDate As String
Dim GlCode As String
Dim icnt As Long
Dim RecBillMst As Recordset
Dim RecNPAParam As Recordset

On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********
BrCode = UCase(Trim(BranchCode))
CurCode = UCase(Trim(CurrencyCode))
'CutOffDate = Format(CutOffDt, "dd-mm-yyyy")
CutOffDate = CutOffDt
GlCode = UCase(Trim(GlId))
ReDim StrArr(0)
'''setting the Recordsets
Set RecBillMst = CreateObject("adodb.recordset")
Set RecNPAParam = CreateObject("adodb.recordset")

'''' Calling the General Query recordset component for querying
Set ObjFetchRec = CreateObject("queryrecordsets.fetchrecordsets")

'''setting the recordset for fetching the principle recovery months,pastdue and
''''interest recovery months,past due

Set RecNPAParam = ObjFetchRec.SingleRecordSet("NPAASSETTYPEPMT", _
                "nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0),INTRECOVERYMTHS,INTPASTDUEMTHS", _
                "upper(trim(branchcode))='" & BrCode & "' and " & _
                "upper(trim(glcode))='" & GlCode & "'")

If Not RecNPAParam.EOF And Not RecNPAParam.BOF Then
''''calculating the npa calc date for the given cuttoffdate
  
    CutOffDate = DateAdd("M", "-" & Val(RecNPAParam(0)) + Val(RecNPAParam(1)), _
                    Format(CutOffDate, "dd-mm-yyyy"))
    CutOffDate = Format(CutOffDate, "dd-mm-yyyy")

Else

    StrArr(0) = "NoRecords" & Err.Description
    StrArr(0) = Replace(StrArr(0), Chr(10), "")
    StrArr(0) = Replace(StrArr(0), Chr(13), "")
    BillTransaction = StrArr

    Exit Function
End If
''' setting a recordset for fetching Accno,name,billduedate  from billoutwardmst
Set RecBillMst = ObjFetchRec.SingleRecordSet("billsmst l", _
                "distinct(l.accno),l.name,l.BILLDUEDATE", _
                "upper(trim(l.branchcode))='" & BrCode & "' and " & _
                "upper(trim(l.currencycode))='" & CurCode & "' and " & _
                "upper(trim(l.glcode))='" & GlCode & "' and " & _
                "(l.status='R' and l.applicationdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') or " & _
                "l.status='C' and l.CLOSEDATE>=to_date('" & CutOffDt & "','dd-mm-yyyy') and l.applicationdate<=to_date('" & CutOffDt & "','dd-mm-yyyy'))", _
                "l.accno")
    
    If Not RecBillMst.EOF Then
    '''' redimentioning the array variable which is return by function
        ReDim StrArr(RecBillMst.RecordCount - 1)
   
     Do Until RecBillMst.EOF
        '''checking billduedate is greater than the calculated cutofdate if it is then it is PA
        ''''else that accno is NPA
        
                
            If RecBillMst(2) >= CutOffDate Then
                StrArr(icnt) = RecBillMst(0) & "~" & RecBillMst(1) & "~" & RecBillMst(2) & "|PA"
            Else
                StrArr(icnt) = RecBillMst(0) & "~" & RecBillMst(1) & "~" & RecBillMst(2) & "|NPA"
            End If
    

       icnt = icnt + 1
   
    
    RecBillMst.MoveNext
    Loop
 Else


 StrArr(0) = "NoRecords"
    BillTransaction = StrArr
   Set ObjFetchRec = Nothing
   Set RecBillMst = Nothing
   
    Exit Function
    End If
    Set ObjFetchRec = Nothing
   
   Set RecBillMst = Nothing
   
   BillTransaction = StrArr

Exit Function

ErrHand:
    StrArr(0) = Err.Number
    StrArr(0) = Replace(StrArr(0), Chr(10), "")
    StrArr(0) = Replace(StrArr(0), Chr(13), "")
    BillTransaction = StrArr
End Function
''' this is method used to classify the accno to which npa category
Public Function AssetClassificationTran(BranchCode As String, CurrencyCode As String, _
                                        ModuleCode As String, GlId As String) As Variant
'''' declaring variables
ReDim StrArr(0)
Dim BrCode As String
Dim CurCode As String
Dim GlCode As String
Dim ModuleId As String
BrCode = UCase(Trim(BranchCode))
CurCode = UCase(Trim(CurrencyCode))
GlCode = UCase(Trim(GlId))
ModuleId = UCase(Trim(ModuleCode))
Dim NpaParamDate As String
Dim TransResult As String
Dim icnt As Long
Dim RecLoanmst As Recordset
Dim RecNpatoPa As Recordset
Dim RecNpaParamMaxDays As Recordset
Dim jcnt As Long
Dim NpaprevParamDate As String
Dim assettype As String
Dim narration  As String
Dim AccCurBal As Double
''setting the recordsets
    Set RecLoanmst = CreateObject("adodb.recordset")
    Set RecNpatoPa = CreateObject("adodb.recordset")
    Set RecNPAParam = CreateObject("adodb.recordset")
    Set RecNpaParamMaxDays = CreateObject("adodb.recordset")
On Error GoTo ErrHand
'''******* Assiging the Arguments to the variables *********

icnt = 0
''' calling general query componenet for fetching records
Set ObjFetchRec = CreateObject("Queryrecordsets.FetchRecordsets")
 
    ''setting the recordset to fetch Acco,name effectivedate from  loanmst,
    ''''NPAPAACTIVITYLOG table
     
     Set RecLoanmst = ObjFetchRec.SingleRecordSet(ModuleId & "mst l,NPAPAACTIVITYLOG g", _
                "distinct(l.accno),l.name,l.glcode,l.branchcode," & _
                "to_char(g.EFFECTIVEDATE,'dd-Mon-yyyy'),l.npastatus,nvl(L.OPBAL,0)", _
                "g.status='R' and " & _
                "upper(trim(l.branchcode))='" & BrCode & "' and " & _
                "upper(trim(l.currencycode))='" & CurCode & "' and " & _
                "upper(trim(l.glcode))='" & GlCode & "' and " & _
                "upper(trim(g.currencycode))='" & CurCode & "' and " & _
                "upper(trim(g.branchcode))='" & BrCode & "' and " & _
                "upper(trim(g.glcode))='" & GlCode & "' and " & _
                "upper(trim(l.ASSETCLASSIFIABLEYN))='Y' and " & _
                "(l.status='R' and l.opdate<=g.EFFECTIVEDATE or " & _
                "l.status='C' and l.CLOSEDATE>=g.EFFECTIVEDATE and l.opdate<=g.EFFECTIVEDATE)", _
                "l.accno")
If Not RecLoanmst.EOF Then
    ReDim StrArr(RecLoanmst.RecordCount - 1)
    Do Until RecLoanmst.EOF
    Set RecNPAParam = CreateObject("adodb.recordset")
    Set RecNpatoPa = CreateObject("adodb.recordset")
    Set RecNpaParamMaxDays = CreateObject("adodb.recordset")
    Set RecCurBal = CreateObject("adodb.recordset")
    AccCurBal = 0
    '''opening arecordeset for fetching the currentbal(scheduleamount) from
    '''loanrecorverydtls table for each account
    Set RecCurBal = ObjFetchRec.SingleRecordSet("LOANRECOVERYDTLS", "nvl(TOTALBAL,0)", _
                    "upper(trim(branchcode))='" & BrCode & "' and " & _
                    "upper(trim(currencycode))='" & CurCode & "' and " & _
                    "upper(trim(glcode))='" & GlCode & "' and " & _
                    "upper(trim(currencycode))='" & CurCode & "' and " & _
                    "accno='" & RecLoanmst(0) & "'")
           If RecCurBal.RecordCount <> 0 Then
                AccCurBal = RecCurBal(0) & ""
           Else
                AccCurBal = RecLoanmst(6) & ""
           End If
  ''setting the recordset for fetching assettype narration,yrs,mnths,days from npaagepmt table
    Set RecNPAParam = ObjFetchRec.SingleRecordSet("NPAAGEPMT a,NPAASSETTYPEMST b", _
                    "a.assettype,b.narration,nvl(AGEYRS,0),nvl(AGEMTHS,0),nvl(AGEDAYS,0)", "a.assettype=b.code", "qualityrange")
    If Not RecNPAParam.EOF Then
         assettype = RecNPAParam(0) & ""
         narration = RecNPAParam(1) & ""
    End If
   ''' if  npastatus='N accounts in loanmst table for that acco classifying the asset type
    If UCase(Trim(RecLoanmst(5))) = "N" Then
         
        '''setting a recordset to fetch the patonpadate fro  the NPANPADTLS
        Set RecNpatoPa = ObjFetchRec.SingleRecordSet("NPANPADTLS", _
                                            "PATONPADT", _
                                            "upper(trim(branchcode))='" & BrCode & "' and " & _
                                            "upper(trim(glcode))='" & GlCode & "' and " & _
                                            "upper(trim(accno))='" & RecLoanmst(0) & "' and " & _
                                            "upper(trim(moduleid))='" & ModuleId & "' and NPATOPADT is null")
       
        If Not RecNpatoPa.EOF Then
          If Not RecNPAParam.EOF Then
          RecNPAParam.MoveNext
          NpaprevParamDate = Format(RecLoanmst(4), "dd-mm-yyyy")
           Do Until RecNPAParam.EOF
             NpaParamDate = ""
             NpaParamDate = DateAdd("YYYY", "-" & Val(RecNPAParam(2)), Format(RecLoanmst(4), "dd-mm-yyyy"))
             NpaParamDate = DateAdd("M", "-" & Val(RecNPAParam(3)), Format(NpaParamDate, "dd-mm-yyyy"))
             NpaParamDate = DateAdd("D", "-" & Val(RecNPAParam(4)), Format(NpaParamDate, "dd-mm-yyyy"))
               ''' checking effectivedate in loannpapadts table is in between asset's period
                If CDate(RecNpatoPa(0)) >= CDate(NpaParamDate) And CDate(RecNpatoPa(0)) <= CDate(NpaprevParamDate) Then
                    StrArr(icnt) = RecLoanmst(0) & "*" & RecLoanmst(1) & "*" & RecNPAParam(1) & "*" & _
                    RecLoanmst(4) & "*" & RecLoanmst(5) & "*" & RecLoanmst(6) & _
                    "*" & AccCurBal & "|" & RecNPAParam(0)
                    Exit Do
                End If
             NpaprevParamDate = Format(NpaParamDate, "dd-mm-yyyy")
           RecNPAParam.MoveNext
           Loop
         End If
          icnt = icnt + 1
        End If
  '''' if  npastatus<>'N accounts in loanmst table that acco  are standered assets
   Else
    StrArr(icnt) = RecLoanmst(0) & "*" & RecLoanmst(1) & "*" & narration & "*" & RecLoanmst(4) & _
    "*" & RecLoanmst(5) & "*" & RecLoanmst(6) & "*" & AccCurBal & "|" & assettype
     icnt = icnt + 1
   End If
   
    RecLoanmst.MoveNext
    Loop
Else
    StrArr(0) = "No Records"
    Set RecCurBal = Nothing
End If
AssetClassificationTran = StrArr
Set RecCurBal = Nothing
Exit Function
ErrHand:
 StrArr(0) = "No Records"
    AssetClassificationTran = StrArr
' End If

End Function


