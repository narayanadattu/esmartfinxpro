VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "Transactions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim AdoConnObj As ADODB.Connection ' Connection Object
Dim ConnError As String
Dim ObjContext As ObjectContext
Dim ObjFetchRec As Object
Dim objTrans As Object
Dim RecTranslog As Recordset
Dim RecCashPos As Recordset
Dim RecCashAllot As Recordset
Dim RecCashRefund As Recordset
Dim RecCashExchng As Recordset
Dim RecCashPayment As Recordset
Dim RecCashTransfer As Recordset
Dim RecCashReciepts As Recordset
Dim recCashVault As Recordset
Dim RecCutSoiled As Recordset
Dim RecActLog As Recordset
Dim RecSysLog As Recordset
Dim RecActGl As Recordset
Dim ChngStatus As String
Dim StrUpValues(0) As Variant
Dim str As String
Dim objdblink As Object
Dim ArrLink As Variant
Dim datalink As String

'   ***************************************************************************************
' This method is only for Cash Day Begin. All the pending status is being checked.
' Backups taken from all TRN tables
' Previous day's DAY END checked and data from TRN tables removed
' The status in genmoduleactivitylog is checked for GL daybegin
' Finally, the current status in genmoduleactivitylog is marked with 'O'
'   ***************************************************************************************

Public Function DayBeginCashQueryTrans(BranchCode As String, ApplicationDate As String) As String
'''Declaring the variables
Dim Date1 As String
Dim BrCode As String
Dim AppDate As String

Dim StrAllotInsert As String
Dim StrExchangeInsert As String
Dim StrPaymentsInsert As String
Dim StrReceiptsInsert As String
Dim StrTransferInsert As String
Dim StrRefundsInsert As String
Dim StrAllotDelete As String
Dim StrCashTranInsert As String
Dim StrExchangeDelete As String
Dim StrPaymentsDelete As String
Dim StrReceiptsDelete As String
Dim StrRefundsDelete As String
Dim StrTransferDelete As String
Dim StrCashTranDelete As String
BrCode = UCase(Trim(BranchCode))
AppDate = Format(ApplicationDate, "dd/mm/yyyy")
'''******Setting recordsets*****************
Set RecActLog = CreateObject("Adodb.recordset")
Set RecSysLog = CreateObject("Adodb.recordset")
Set RecCashPos = CreateObject("Adodb.recordset")
Set RecActGl = CreateObject("Adodb.recordset")
On Error GoTo errhand
ConnError = ""
Call DBConnection
If ConnError <> "Connected" Then
    DayBeginCashQueryTrans = ConnError
    DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(10), "")
    DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(13), "")
    Exit Function
End If

''''*** calling fetchrecordeset component

Set ObjContext = GetObjectContext
 Set ObjFetchRec = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")
Set objTrans = ObjContext.CreateInstance("DatabaseTransactions.transactionmethods")

''' updating daybegin status='S' while starting the daybegin

Dim StrUpValues(0) As Variant
'StrUpValues(0) = "'S' ~ 'N' ~ to_date('" & AppDate & "','dd-mm-yyyy')"
StrUpValues(0) = "'S'"
str = objTrans.UpdateRecord("GENMODULEACTIVITYLOG", "daybeginstatus", StrUpValues, _
                            "trim(upper(branchcode))='" & BrCode & "' and  " & _
                            "moduleid='CASH' and " & _
                            "applicationdate<to_date('" & AppDate & "','dd-mm-yyyy')")
  If str = "Trans Completed" Then
    ObjContext.SetComplete
  End If
  str = ""
  StrUpValues(0) = ""


''''*******checking the dayBeginstatus in the  GENActivityACTIVITYLOG table


''' checking the yesterdays dayendstatus='O' for moduleid Gl in genmoduleactivitylog

Set RecActGl = ObjFetchRec.singlerecordset("GENMODULEACTIVITYLOG", "*", _
                "upper(trim(daybeginstatus))='O' and " & _
                "daybegindate=to_date('" & AppDate & "','dd-mm-yyyy') and " & _
                "upper(trim(moduleid))='GL' and " & _
                "dayendstatus='O' and " & _
                "dayenddate<to_date('" & AppDate & "','dd-mm-yyyy') and " & _
                "upper(trim(branchcode))='" & BrCode & "'")
If RecActGl.EOF Then
DayBeginCashQueryTrans = "DayBegin is not completed Due to Gl DayBegin is not completed "
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(10), "")
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(13), "")
Set ObjFetchRec = Nothing
Set RecActGl = Nothing
Exit Function
End If
Set RecActGl = Nothing
''''checking the todays daybeginstatus='O'  for moduleid='CASH' in genmoduleactivitylog

Set RecActGl = ObjFetchRec.singlerecordset("GENMODULEACTIVITYLOG", "*", _
               "upper(trim(daybeginstatus))='O' and " & _
               "upper(trim(moduleid))='CASH' and " & _
               "daybegindate=to_date('" & AppDate & "','dd-mm-yyyy')")
    If Not RecActGl.EOF Then
        DayBeginCashQueryTrans = "DayBegin Already Completed for this date " & AppDate
        DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(10), "")
        DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(13), "")
        Set ObjFetchRec = Nothing
        Set RecActGl = Nothing
        Exit Function
    End If
Set RecActGl = Nothing
''checking the yesterdays dayendstatus='O' fro cash in genmoduleactivitylog

Set RecActLog = ObjFetchRec.singlerecordset("GENMODULEACTIVITYLOG", "*", _
                "upper(trim(dayendstatus))='O' and   upper(trim(moduleid))='CASH' and " & _
                "dayenddate<to_date('" & AppDate & "','dd-mm-yyyy') and " & _
                 "upper(trim(branchcode))='" & BrCode & "'")
If RecActLog.EOF Then
DayBeginCashQueryTrans = "DayBegin is Not Completed due to yesterdays day end not completed"
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(10), "")
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(13), "")
Set ObjFetchRec = Nothing
Set RecActLog = Nothing
Exit Function
End If


'Dim StrUpValues(0) As Variant
'StrUpValues(0) = "'S' ~ 'N' ~ to_date('" & AppDate & "','dd-mm-yyyy')"
'str = ObjTrans.UpdateRecord("GENMODULEACTIVITYLOG", "daybeginstatus,dayendstatus,Daybegindate", StrUpValues, _
 '                          "trim(upper(branchcode))='" & BrCode & "' and " & _
  '                          "moduleid='CASH' and " & _
   '                         "applicationdate='" & AppDate & "'")
''''*******checking the balance is 0 in the Cashcashierposmast  table

'' Set RecCashPos = ObjFetchRec.SingleRecordSet("Cashcashierposmst", "*", _
''                "trim(upper(branchcode))='" & BrCode & "' and  " & _
''                "applicationdate=to_date('" & AppDate & "','dd-mm-yyyy') and nvl(totamount,0)>0")
''If Not RecCashPos.EOF Then
''    DayBeginCashQueryTrans = "cashier must be Balance  0"
''    Set ObjFetchRec = Nothing
''    Set RecCashPos = Nothing
''    Exit Function
''End If
''Set RecCashPos = Nothing

''''****** inserting all rows of 'TRN' tables into 'BKP' tables before deleting

StrAllotInsert = "Insert into CASHALLOTMENTSTRNBKP select * from CASHALLOTMENTSTRN"
StrExchangeInsert = "Insert into CASHEXCHANGETRNBKP select * from CASHEXCHANGETRN"
StrPaymentsInsert = "Insert into CASHPAYMENTSTRNBKP select * from CASHPAYMENTSTRN"
StrReceiptsInsert = "Insert into CASHRECEIPTSTRNBKP select * from CASHRECEIPTSTRN"
StrRefundsInsert = "Insert into CASHREFUNDSTRNBKP select * from CASHREFUNDSTRN"
StrTransferInsert = "Insert into CASHTRANSBTCASHIERSTRNBKP select * from CASHTRANSBTCASHIERSTRN"
StrCashTranInsert = "Insert into Cashtran select * from cashtranday"
If StrAllotInsert <> "" Then AdoConnObj.Execute StrAllotInsert
If StrExchangeInsert <> "" Then AdoConnObj.Execute StrExchangeInsert
If StrPaymentsInsert <> "" Then AdoConnObj.Execute StrPaymentsInsert
If StrReceiptsInsert <> "" Then AdoConnObj.Execute StrReceiptsInsert
If StrRefundsInsert <> "" Then AdoConnObj.Execute StrRefundsInsert
If StrTransferInsert <> "" Then AdoConnObj.Execute StrTransferInsert
If StrCashTranInsert <> "" Then AdoConnObj.Execute StrCashTranInsert
'''''*************Deleting all rows in the 'TRN' tables using General Child Component

StrAllotDelete = objTrans.DeleteRecord("CASHALLOTMENTSTRN", "upper(trim(branchcode))='" & BrCode & "'")
StrExchangeDelete = objTrans.DeleteRecord("CASHEXCHANGETRN", "upper(trim(branchcode))='" & BrCode & "'")
StrPaymentsDelete = objTrans.DeleteRecord("CASHPAYMENTSTRN", "upper(trim(branchcode))='" & BrCode & "'")
StrReceiptsDelete = objTrans.DeleteRecord("CASHRECEIPTSTRN", "upper(trim(branchcode))='" & BrCode & "'")
StrRefundsDelete = objTrans.DeleteRecord("CASHREFUNDSTRN", "upper(trim(branchcode))='" & BrCode & "'")
StrTransferDelete = objTrans.DeleteRecord("CASHTRANSBTCASHIERSTRN", "upper(trim(branchcode))='" & BrCode & "'")
StrCashTranDelete = objTrans.DeleteRecord("CASHTRANday", "upper(trim(branchcode))='" & BrCode & "'")




StrUpValues(0) = "'O'~to_date('" & AppDate & "','dd-mm-yyyy')~to_date('" & AppDate & "','dd-mm-yyyy')"
str = objTrans.UpdateRecord("GENMODULEACTIVITYLOG", "daybeginstatus,applicationdate,daybegindate", StrUpValues, _
                            "trim(upper(branchcode))='" & BrCode & "' and  " & _
                            "moduleid='CASH' and " & _
                            "applicationdate<to_date('" & AppDate & "','dd-mm-yyyy')")

ObjContext.SetComplete
Set ObjFetchRec = Nothing
DayBeginCashQueryTrans = "TRUE"
Exit Function

errhand:
ObjContext.SetAbort
DayBeginCashQueryTrans = "Transaction is not success Due to " & Err.Number & " : " & Err.Description
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(10), "")
DayBeginCashQueryTrans = Replace(DayBeginCashQueryTrans, Chr(13), "")
''''MsgBox DayBeginCashQueryTrans
Set objTrans = Nothing
Set ObjContext = Nothing
End Function

Public Function SBDayBeginTrans(BranchCode As String, ApplicationDate As String) As String
Dim BrCode As String
Dim AppDate As String
Dim StrUpValues(0) As Variant
Dim Status As String
Dim RecTranslog As Recordset
Dim RecSysLog As Recordset
Dim RecActGl As Recordset
Dim StrSbTran As String
BrCode = UCase(Trim(BranchCode))
AppDate = Format(ApplicationDate, "dd-mm-yyyy")
Set RecActLog = CreateObject("Adodb.recordset")
Set RecSysLog = CreateObject("Adodb.recordset")
Set RecActGl = CreateObject("Adodb.recordset")
On Error GoTo errhand
Status = ""
''''*** calling fetchrecordeset component
Set ObjContext = GetObjectContext
Set ObjFetchRec = ObjContext.CreateInstance("QueryRecordsets.FetchRecordsets")
Set objTrans = ObjContext.CreateInstance("DatabaseTransactions.transactionmethods")

''''*******checking the dayendstatus='0' in the  GENActivityACTIVITYLOG table

Set RecActLog = ObjFetchRec.singlerecordset("GENMODULEACTIVITYLOG", "*", _
                "upper(trim(dayendstatus))='O' and   upper(trim(moduleid))='SB' and " & _
                "to_date(dayenddate,'dd-mm-yyyy')<to_date('" & AppDate & "','dd-mm-yyyy') and " & _
                "upper(trim(branchcode))='" & BrCode & "'")
If RecActLog.EOF Then
    SBDayBeginTrans = "SB Day End Status is not yet Completed"
Exit Function
End If
Set RecActGl = ObjFetchRec.singlerecordset("GENMODULEACTIVITYLOG", "*", _
                "upper(trim(daybeginstatus))='O' and   upper(trim(moduleid))='GL' and " & _
                "to_char(applicationdate,'dd-mm-yyyy')='" & AppDate & "' and " & _
                "upper(trim(branchcode))='" & BrCode & "'")
If RecActGl.EOF Then
    SBDayBeginTrans = "Gl Daybegin  is not yet Completed"
Exit Function
End If


StrUpValues(0) = "'S' ~ to_date('" & AppDate & "','dd-mm-yyyy')~to_date('" & AppDate & "','dd-mm-yyyy')"
str = objTrans.UpdateRecord("GENMODULEACTIVITYLOG", "daybeginstatus,Daybegindate,applicationdate", StrUpValues, _
                            "trim(upper(branchcode))='" & BrCode & "' and " & _
                            " upper(trim(moduleid))='SB' and " & _
                            "to_date(applicationdate,'dd-mm-yyyy')<to_date('" & AppDate & "','dd-mm-yyyy')")
If str = "Trans Completed" Then
    Status = "True"
    ObjContext.SetComplete
Else
    ObjContext.SetAbort
    SBDayBeginTrans = "Day Begin is  not yet started due to:" & str
    Exit Function
End If
'''''-------------------------------------------------------------------------------------------

''''''deleting the  tranday tables
StrSbTran = objTrans.DeleteRecord("SBtranday", "")

'''''-------------------------------------------------------------------------------------
                            
                            
StrUpValues(0) = "'O'"
str = objTrans.UpdateRecord("GENMODULEACTIVITYLOG", "daybeginstatus", StrUpValues, _
                            "trim(upper(branchcode))='" & BrCode & "' and  " & _
                            "to_char(applicationdate,'dd-mm-yyyy')='" & AppDate & "'")

ObjContext.SetComplete
Set ObjFetchRec = Nothing
SBDayBeginTrans = "SB Day Begin Completed"
Exit Function
errhand:
If Status <> "" Then
ObjContext.SetAbort
End If
SBDayBeginTrans = "SB Day Begin not Completed Due to " & Err.Number & " : " & Err.Description
SBDayBeginTrans = Replace(SBDayBeginTrans, Chr(10), "")
SBDayBeginTrans = Replace(SBDayBeginTrans, Chr(13), "")
Set objTrans = Nothing
Set ObjContext = Nothing
End Function



''Private Sub DBConnection()
''
'' ''''''calling shared property manager for dblink
''    Set objDBlink = CreateObject("SharedStaticValues.AcceptDBLink")
''    datalink = objDBlink.GetDBLink
''    Set objDBlink = Nothing
''    ArrLink = Split(datalink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        datalink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        datalink = Trim(ArrLink(3))
''    End If
''
''
''ConnError = ""
''
''AdoConnObj.CursorLocation = adUseClient
'''''''AdoConnObj.Open "Provider=MSDAORA.1;data source=ver3;Password=v3;User ID=v3"
''AdoConnObj.Open "Provider=MSDAORA.1;data source=" & ArrLink(2) & ";Password=" & ArrLink(1) & ";User ID=" & ArrLink(0)
''If AdoConnObj.State = 1 Then ConnError = "Connected"
''
''
''
''End Sub


Private Sub DBConnection()

Dim objdblink As Object
Dim strpassword As String
Dim ArrLink As Variant
Dim objPwd As Object
Dim resDBdate As New ADODB.Recordset
Dim strUserid As String
Dim strDataSource As String
Dim strSupreUserPassword As String
strSupreUserPassword = "ramsmart"
strUserid = "V3"
strDataSource = "V3"


'************Oppening the connection to dblink*************
On Error GoTo errhand
'''' calling shared property manager for dblink
 Set AdoConnObj = CreateObject("Adodb.Connection")
 
''    Set objdblink = CreateObject("SharedStaticValues.AcceptDBLink")
''    DataLink = objdblink.GetDBLink
''    Set objdblink = Nothing
''    ArrLink = Split(DataLink, ",", -1)
''    If UBound(ArrLink) < 2 Then
''        ConnError = ArrLink(0)
''        Exit Sub
''    ElseIf UBound(ArrLink) = 2 Then
''        DataLink = ""
''    ElseIf UBound(ArrLink) = 3 Then
''        DataLink = Trim(ArrLink(3))
''    End If
    
    With AdoConnObj

           .ConnectionString = "user id=scott;password=tiger" & _
            ";data source=" & strDataSource
           .CursorLocation = adUseClient
           .Provider = "MSDAORA"
           .Open

    End With
    Set resDBdate = AdoConnObj.Execute("SELECT LatestDaybegindate FROM " & strUserid & ".DBDATE")

    Set objPwd = CreateObject("GeneratePwd.clsGeneratePassword")
    
    strpassword = objPwd.getPassword(Format(resDBdate!LatestDaybegindate, "DD-MM-YYYY") & "/bank/city/grams")
    Set AdoConnObj = Nothing
    
    ConnError = ""
    Set AdoConnObj = CreateObject("Adodb.Connection")
    AdoConnObj.CursorLocation = adUseClient
    AdoConnObj.Open "Provider=MSDAORA.1;data source=" & strDataSource & ";Password=" & strpassword & ";User ID=" & strUserid
'    AdoConnObj.Open "Provider=MSDAORA.1;data source=V3;Password=esmart;User ID=V3"
    If AdoConnObj.State = 1 Then ConnError = "Connected"
    
Exit Sub

errhand:

If Err.Number = -2147467259 Then
        If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
            ConnError = "Please enter correct conect string or " & Chr(13) & Chr(13) & "(TNS:could not resolve service name)"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Then
            ConnError = "Server or Network not available (Check your Network/Server ) or " & Chr(13) & Chr(13) & "TNS:operation timed out "
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
            ConnError = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct" & Chr(13) & Chr(13) & "(TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
            ConnError = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
            ConnError = "Please Verify your systems Network connection to the Server OR" & Chr(13) & Chr(13) & "Please Verify the HOST Mentioned in the Tnsnames file is correct " & Chr(13) & Chr(13) & "(ORA-12545: Connect failed because target host or object does not exist)"
        ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
            ConnError = "Database is NOT STARTED UP to connect. To start database please click on 'Start Up DB' button."
        Else
            ConnError = "Connection Failed Due To : " & Err.Number & " : " & Err.Description
        End If
    Else
    
    If VerifyConnectionWithV3(strDataSource, strUserid, strSupreUserPassword) = False Then
         ConnError = "Unable to connect to Main User .Contact Raminfo"
        Exit Sub
    End If
    If AdoConnObj.State = 1 Then ConnError = "Connected"
  End If
  
End Sub

Public Function VerifyConnectionWithV3(strDS As String, strUid As String, strSupreUserPassword As String) As Boolean
On Error GoTo errh
Set AdoConnObj = CreateObject("Adodb.Connection")
AdoConnObj.CursorLocation = adUseClient
    
    With AdoConnObj

        If .State = 1 Then .Close

           .ConnectionString = "user id=" & strUid & ";password=" & strSupreUserPassword & _
           ";data source=" & strDS
           .CursorLocation = adUseClient
           .Provider = "MSDAORA"
           .Open

    End With
VerifyConnectionWithV3 = True


Exit Function
errh:
VerifyConnectionWithV3 = False
End Function


