VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 4  'RequiresNewTransaction
END
Attribute VB_Name = "NewCustomer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim objcontext As ObjectContext
Dim ObjAuto As Object
Dim ObjQuery As Object
Dim RsAutoPmt As ADODB.Recordset
Dim Rstemp  As ADODB.Recordset
Dim objTrans As Object
Dim objErrlog As New TrapError.ErrorDescription


'''' This function genrate a new customerid and inserts all the information to the
'''' the gencustinfomst table. And later returns the new Customerid generated
'''' the parent application.
Public Function CreateCustomerID(ArrCustomerInfo As Variant, _
                                 Userid As String, MachineId As String) As String

Dim arrCustInfo As Variant
Dim AutoNumValue As String
Dim AutoPmtCond As String
Dim AutoFlds As String
Dim AutoVal(0) As Variant
Dim TransResult As String
Dim strCustFlds As String
Dim arrCustVal() As Variant
On Error GoTo ErrHand
arrCustInfo = ArrCustomerInfo
Set objcontext = GetObjectContext
Set ObjQuery = CreateObject("QueryRecordsets.FetchRecordsets")
Set objTrans = objcontext.CreateInstance("DataBaseTransactions.TransactionMethods")
Set Rstemp = CreateObject("ADODB.Recordset")
Set RsAutoPmt = CreateObject("ADODB.Recordset")
AutoNumValue = ""
'''' querying the parameters for Autonumber generation
AutoPmtCond = " TRIM(UPPER(MAXAUTOTABLENAME))='GENCUSTINFOMST' AND " _
            & " TRIM(UPPER(MAXAUTOFIELDNAME))='CUSTOMERID'"
            
Set RsAutoPmt = ObjQuery.SingleRecordSet("GENAUTONUMBERPMT", "*", AutoPmtCond)
If ObjQuery.connerror <> "Connected" Then
    TransResult = ObjQuery.connerror
    GoTo ErrHand
End If
        If RsAutoPmt.EOF And RsAutoPmt.BOF Then
            TransResult = "Parameters for the CustomerID to be specified"
            GoTo ErrHand
        End If
AutoPmtCond = AutoPmtCond & " and upper(trim(branchcode))='" _
                          & UCase(Trim(arrCustInfo(0))) & "' for update"

Set Rstemp = ObjQuery.SingleRecordSet("GENAUTONUMMAX", " * ", AutoPmtCond)

    If Rstemp.EOF And Rstemp.BOF Then
        AutoFlds = "MAXAUTOTABLENAME, MAXAUTOFIELDNAME, BRANCHCODE ,MAXAUTONUM"
        AutoVal(0) = "'GENCUSTINFOMST','CUSTOMERID','" & UCase(Trim(arrCustInfo(0))) & "','0'"
        TransResult = objTrans.insertrecord("GENAUTONUMMAX", AutoFlds, AutoVal, _
                                            CStr(arrCustInfo(0)), Userid, MachineId)
                                        
        If Trim(TransResult) <> "Trans Completed" Then GoTo ErrHand
        objcontext.SetComplete
        If Rstemp.State = 1 Then Rstemp.Close
        Set Rstemp = ObjQuery.SingleRecordSet("GENAUTONUMMAX", " * ", AutoPmtCond)
    End If

'''' retrieving the generated value
AutoPmtCond = " TRIM(UPPER(MAXAUTOTABLENAME))='GENCUSTINFOMST' AND " _
            & " TRIM(UPPER(MAXAUTOFIELDNAME='CUSTOMERID' and upper(trim(branchcode))='" _
            & UCase(Trim(arrCustInfo(0))) & "'"
            
Set ObjAuto = CreateObject("AutoNumber.Generation")
AutoNumValue = ObjAuto.GetAutoNumber("GENAUTONUMMAX", "MAXAUTONUM", AutoPmtCond, CStr(RsAutoPmt!InitialValue))

If ObjAuto.connerror <> "Connected" Then TransResult = ObjAuto.connerror: GoTo ErrHand
Set ObjAuto = Nothing
AutoVal(0) = AutoNumValue
TransResult = ObjQuery.ModifyQueriedTrans("GENAUTONUMMAX", "MAXAUTONUM", AutoVal, _
                                                  AutoPmtCond, CStr(arrCustInfo(0)), Userid, MachineId)
''''prefixing the branchcode and customertype to the generated cutomercode
AutoNumValue = Trim(UCase(arrCustInfo(0))) & Trim(UCase(arrCustInfo(1))) _
                & Trim(UCase(AutoNumValue))

''''Now inserting the new Customer data into gencustinfomst table
strCustFlds = Trim(arrCustInfo(2)) & ",CUSTOMERID"
arrCustVal(0) = arrCustInfo(3) & ",'" & Trim(UCase(AutoNumValue)) & "'"

TransResult = objTrans.insertrecord("GENCUSTINFOMST", strCustFlds, arrCustVal, arrCustInfo(0), Userid, MachineId)
If TransResult <> "Trans Completed" Then GoTo ErrHand
objcontext.SetComplete
CreateCustomerID = "Transaction SucessFul|" & Trim(UCase(AutoNumValue))

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If RsAutoPmt.State = 1 Then RsAutoPmt.Close
Set RsAutoPmt = Nothing
Exit Function

''''Error traping
ErrHand:
objErrlog.LogError "CreateCustomerID", Err.Number, Err.Description

If Rstemp.State = 1 Then Rstemp.Close
Set Rstemp = Nothing
If RsAutoPmt.State = 1 Then RsAutoPmt.Close
Set RsAutoPmt = Nothing

    objcontext.SetAbort
    Set ObjAuto = Nothing
    Set ObjQuery = Nothing
    Set objcontext = Nothing
    Set objTrans = Nothing
    
    If TransResult <> "" Then
        'CreateCustomerID = TransResult
        TransResult = Replace(TransResult, Chr(10), "")
        TransResult = Replace(TransResult, Chr(13), "")
        CreateCustomerID = TransResult

    Else
        CreateCustomerID = Err.Number & " : " & Err.Description
        CreateCustomerID = Replace(CreateCustomerID, Chr(10), "")
        CreateCustomerID = Replace(CreateCustomerID, Chr(13), "")

    End If
    
End Function
