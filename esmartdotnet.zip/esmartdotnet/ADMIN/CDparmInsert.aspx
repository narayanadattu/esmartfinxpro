<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CDparmInsert.aspx.vb" Inherits="eSmartDotNet.CDparmInsert"%>
<%

dim obj,obj1,obj2,obj3,obj4,rs,rs1,rs2,rs3,Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno
obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
obj2=server.CreateObject("queryrecordsets.fetchrecordsets")
obj3=server.CreateObject("queryrecordsets.fetchrecordsets")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")

dim Arrtrans(50,4)
strEfdat=Request.Form("txtEffDate")
strBasic=Request.Form("txtBasic")
strHra=Request.Form("txtHra")
strDa=Request.Form("txtDa")
strPf=Request.Form("txtPf")
strMedallo=Request.Form("txtMedallow")
strAllow=Request.Form("txtAllowance")
strProftax=Request.Form("txtPftax")
strOthallow=Request.Form("txtOtherAllow")

appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("hmode")
strval=split(strmode,"|")


if strval(0)="INSERT" then
	
	
		if strval(1)="CDPARM" then
		
				strcolnames="MODULEID, GLCODE, DLFLAG, STATUS, APPLICATIONDATE, USERID, MACHINEID"
				
				strdelvar=Request.Form("mercust") 
				
				Arrtrans(0,0)="I"			
				Arrtrans(0,1)="CDRATIOPARM"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=""
				
		end if
		
		if strval(1)="CRRSLR" then
		
				strcolnames="MODULEID, GLCODE, DLFLAG,FLAGSUBTYPE, STATUS, APPLICATIONDATE, USERID, MACHINEID"
				
				strdelvar=Request.Form("mercust") 
				
				Arrtrans(0,0)="I"			
				Arrtrans(0,1)="CDRATIOPARM"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=""
				
		end if
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
			
			Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
			Response.Write (Strmsg)	
			obj=nothing
		 
	
else if strval(0)="MODIFY" then
	
		if strval(1)="CDPARM" then
		
			strcolnames="MODULEID, GLCODE, DLFLAG, STATUS, APPLICATIONDATE, USERID, MACHINEID"
		
			strdelvar=Request.Form("mercust") 
			
			upval = split(strdelvar,"|")
			
			cnt=upval.length
			
			dim i
			i=0
			
			for i = 0 to cnt-1
				
				udata = split(upval(i),"~")
				
				strCond = " MODULEID= " & udata(0) & " and GLCODE= " & udata(1) & " and DLFLAG in ('A','B','C') "
				
				Arrtrans(i,0)="U"			
				Arrtrans(i,1)="CDRATIOPARM"
				Arrtrans(i,2)=strcolnames
				Arrtrans(i,3)=upval(i)
				Arrtrans(i,4)=strCond
			
			next 
		
		end if
		
		if strval(1)="CRRSLR" then
		
			strcolnames="MODULEID, GLCODE, DLFLAG,FLAGSUBTYPE, STATUS, APPLICATIONDATE, USERID, MACHINEID"
		
			strdelvar=Request.Form("mercust") 
			
			upval = split(strdelvar,"|")
			
			cnt=upval.length
			
			dim i
			i=0
			
			for i = 0 to cnt-1
				
				udata = split(upval(i),"~")
				
				strCond = " MODULEID= " & udata(0) & " and GLCODE= " & udata(1) & " and DLFLAG in ('CRR','SLR') "
				
				Arrtrans(i,0)="U"			
				Arrtrans(i,1)="CDRATIOPARM"
				Arrtrans(i,2)=strcolnames
				Arrtrans(i,3)=upval(i)
				Arrtrans(i,4)=strCond
			
			next 
		
		end if
		
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
		
	Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		 obj=nothing

else if strval(0)="DELETE" then
	
		if strval(1)="CDPARM" then
		
			strcolnames="MODULEID, GLCODE, DLFLAG, STATUS, APPLICATIONDATE, USERID, MACHINEID"
		
			strdelvar=Request.Form("mercust") 
			
			upval = split(strdelvar,"|")
			
			cnt=upval.length
			
			dim i
			i=0
			
			for i = 0 to cnt-1
				
				udata = split(upval(i),"~")
				
				strCond = " MODULEID= " & udata(0) & " and GLCODE= " & udata(1) & " and DLFLAG in ('A','B','C')"
				
				Arrtrans(i,0)="U"			
				Arrtrans(i,1)="CDRATIOPARM"
				Arrtrans(i,2)=strcolnames
				Arrtrans(i,3)=upval(i)
				Arrtrans(i,4)=strCond
			
			next 
		
		end if
		
		
		if strval(1)="CRRSLR" then
		
			strcolnames="MODULEID, GLCODE, DLFLAG,FLAGSUBTYPE, STATUS, APPLICATIONDATE, USERID, MACHINEID"
		
			strdelvar=Request.Form("mercust") 
			
			upval = split(strdelvar,"|")
			
			cnt=upval.length
			
			dim i
			i=0
			
			for i = 0 to cnt-1
				
				udata = split(upval(i),"~")
				
				strCond = " MODULEID= " & udata(0) & " and GLCODE= " & udata(1) & " and DLFLAG in ('CRR','SLR')"
				
				Arrtrans(i,0)="U"			
				Arrtrans(i,1)="CDRATIOPARM"
				Arrtrans(i,2)=strcolnames
				Arrtrans(i,3)=upval(i)
				Arrtrans(i,4)=strCond
			
			next 
		
		end if
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
		
	Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		 obj=nothing

end if

	Response.Redirect ("frmCDparameter.aspx?record=" & Strmsg)

%>
