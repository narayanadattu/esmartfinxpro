<%@ Page Language="vb" CodeBehind="GenWorkAllotModuleIDApproval.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotModuleIDApproval" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenWorkAllotModuleIdApproval.ASP						*
'*	Purpose	  	     : To get and display all the modules to be approved   	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>


<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<%  Dim objfetch,recrs1,vark,varstr1
	varstr1=split(Request.Form("hden"),"|")
	 varstr=varstr1(0)
	 grcode=varstr1(1)
%>	
<title></title>
<SCRIPT LANGUAGE=javascript>
<!--
function clearframe()
{
	/// to refresh genworkallotformid.asp page
	parent.frames(1).frmforms.action="GenWorkAllotFormid.aspx"
	parent.frames(1).frmforms.method="post"
	parent.frames(1).frmforms.submit()
}
//-->
</SCRIPT>

</head>
<body>

<form name="frmmodule">
  <%
		if len(varstr)>0 then
		 recrs1=server.CreateObject("adodb.recordset")
			 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
			if lcase(varstr1(2))="group" then
				 recrs1=objfetch.singlerecordset("GENGROUPFORMSMST A, GENMODULETYPESMST B","DISTINCT(A.moduleid),initcap(B.narration)","A.MODULEID=B.MODULEID AND A.TRANSTATUS<>'A' and groupcode='" & grcode &"'")
			elseif lcase(varstr1(2))="user" then
				 recrs1=objfetch.singlerecordset("GENUSERIDFORMSMST A, GENMODULETYPESMST B","DISTINCT(A.moduleid),initcap(B.narration)","A.MODULEID=B.MODULEID AND A.TRANSTATUS<>'A' and a.userid='" & grcode &"'")
			end if
		'Response.Write 	"GENUSERIDFORMSMST A, GENMODULETYPESMST B" & "DISTINCT(A.moduleid),B.narration" & "A.MODULEID=B.MODULEID AND A.STATUS='P' and userid='" & grcode &"'"
  %>

  <table border="0" width="140" cellspacing="0" cellpadding="0">
    <tr align="left">
      <td width="30%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modules</font></td>
    </tr>
  </table>

  <table>
     <% 'if 1=2 then
     if recrs1.EOF=false and recrs1.BOF=false then%>
		<%recrs1.MoveFirst%>
		<%do until recrs1.EOF%>
    <tr>
      <td><input type="checkbox" name="optmoduleid" id="optmoduleid" value="<%=recrs1(0).value%>" onclick="clearframe()"> <font color="black" face="MS Sans Serif" size="2"><%=recrs1(1).value%></font></td>
            <%recrs1.MoveNext%>
    </tr>
		<%loop%>
      <%else%>
          <%="Data does not exists"%>
         <% Response.Write("<script language=vbscript>")
           Response.Write ("window.parent.window.document.frmworkallot.cmdDisplay.disabled=true" & chr(13))
           Response.Write ("window.parent.window.document.frmworkallot.cmdok.disabled=true" & chr(13))
           Response.Write ("window.parent.window.document.frmworkallot.cmdreject.disabled=true" & chr(13))
           	Response.Write("</script>") %>
    <%end if%>
    <%end if%>
    <input type="hidden" name="hden" id="hden">
    </form>
  </table>

</body>

