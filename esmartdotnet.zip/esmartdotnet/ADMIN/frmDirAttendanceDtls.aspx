<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmDirAttendanceDtls.aspx.vb" Inherits="eSmartDotNet.frmDirAttendanceDtls"%>

<%
 vAppdate = Session("applicationdate")
meettime = format(now,"HHMM")

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>Director Meeting Attendance </title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	
	<SCRIPT LANGUAGE=javascript>
	function resultmessage()
{

message="<%=Request.QueryString("record")%>"
	if(message!="")
	{
		alert(message)
		location.href="frmDirAttendanceDtls.aspx"
	}
}

 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmEmpMast.txtMeetingDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtMeetingDate.value=""
				window.document.frmEmpMast.txtMeetingDate.focus()
			}
			
			// 
			
			strVal="GetSittingFeeAmt"+"|"+window.document.frmEmpMast.txtMeetingDate.value
			window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	
		}
		
	
		
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}

function changeMonthnum(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="0"
			else if(str=="FEB")
				strMonth="1"
			else if(str=="MAR")
				strMonth="2"
			else if(str=="APR")
				strMonth="3"
			else if(str=="MAY")
				strMonth="4"
			else if(str=="JUN")
				strMonth="5"
			else if(str=="JUL")
				strMonth="6"
			else if(str=="AUG")
				strMonth="7"
			else if(str=="SEP")
				strMonth="8"
			else if(str=="OCT")
				strMonth="9"
			else if(str=="NOV")
				strMonth="10"
			else if(str=="DEC")
				strMonth="11"
			
			return strMonth;
		}
		
		
	
function DirectorID(kstr)
{
var dirid
		dirid = kstr.split("-----")
		
		window.document.frmEmpMast.txtDirectorID.value=dirid[1]
		window.document.frmEmpMast.txtDirectorName.value = dirid[0]
		window.document.frmEmpMast.hdnsittingfeeyn.value = dirid[2]
}	

function DispTranMsg()
{
window.document.frmEmpMast.txtMeetingDate.value	= "<%=session("applicationdate")%>"	
window.document.frmEmpMast.txtMeetingTime.value	= "<%=meettime%>"	

}

function Refresh()
{
if (window.document.frmEmpMast.cmbMeetingType.value == "Select")
	{
	alert("Select Meeting Type")
	return
	}
	
	

var strVal

			strVal="getDirectorDtls"+"|"+window.document.frmEmpMast.cmbMeetingType.value+"|"+window.document.frmEmpMast.txtMeetingDate.value + "|"+window.document.frmEmpMast.txtMeetingTime.value
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
}

function getDirectorDtls1(kstr)
{
	var strdirval = kstr.split("|")
	if (strdirval.length > 0)
		{
		window.document.frmEmpMast.msflexMeetingDtls.Rows=1
		
		window.document.frmEmpMast.msflexMeetingDtls.cols=4;
		window.document.frmEmpMast.msflexMeetingDtls.formatstring="<Sno        |<Dir ID              |<Dir Name                                                 |<AttendanceYN       ";
		
			for(aCnt=0;aCnt<=strdirval.length-1;aCnt++)
			{
				window.document.frmEmpMast.msflexMeetingDtls.rows=window.document.frmEmpMast.msflexMeetingDtls.rows+1
				
				var strCols=strdirval[aCnt].split("~")
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,0)=aCnt + 1
					window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,1)=strCols[0]
					window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,2)=strCols[1]
					window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,3)=strCols[2]
					
				}
			}
		}
}

function msflexMeetingDtls_DblClick() 
{
		row=window.document.frmEmpMast.msflexMeetingDtls.Row
		
		if(window.document.frmEmpMast.msflexMeetingDtls.textmatrix(row,3)=="Y")
		{
			window.document.frmEmpMast.msflexMeetingDtls.textmatrix(row,3)="N"
			
			for (d=0 ;d<window.document.frmEmpMast.msflexMeetingDtls.Cols;d++) 
			{  
				window.document.frmEmpMast.msflexMeetingDtls.Col=d				
				window.document.frmEmpMast.msflexMeetingDtls.CellBackColor=8421616
			}
		}
		else if(window.document.frmEmpMast.msflexMeetingDtls.textmatrix(row,3)=="N")
		{
			window.document.frmEmpMast.msflexMeetingDtls.textmatrix(row,3)="Y"
			
			for (d=0 ;d<window.document.frmEmpMast.msflexMeetingDtls.Cols;d++) 
			{  
				window.document.frmEmpMast.msflexMeetingDtls.Col=d				
				window.document.frmEmpMast.msflexMeetingDtls.CellBackColor=16777215
			}
		}
}


// BOM/BOD Meeting Attendance
function Ok()
{
	
var meetdtls
var meetdtls1
var dbltotsitfee
dbltotsitfee = 0
meetdtls = ""
meetdtls1 = ""
window.document.frmEmpMast.hdnAppdate.value = "<%= vAppdate %>"
if (window.document.frmEmpMast.cmbMeetingType.value == "Select")
	{
	alert("Select Meeting Type")
	return
	}

if (window.document.frmEmpMast.txtMeetingDate.value == "")
	{
	alert("Enter Meeting Date")
	return
	}

if (window.document.frmEmpMast.txtMeetingTime.value == "")
	{
	alert("Enter Meeting Time")
	return
	}

var blncheck
blncheck = false
var rows1= window.document.frmEmpMast.msflexMeetingDtls.Rows

	if(rows1>1)
	{
		
		for(icnt=1;icnt<rows1;icnt++)
		{
			if (window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,3) == 'Y')
			{
			blncheck = true
			}
		}	
		
		if (blncheck == false)
		{
		alert("No Records To Post")
		return
		}
		
	for(icnt=1;icnt<rows1;icnt++)
		{
			if (window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,3) == 'Y')
			{
			 meetdtls1=""+ window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,0) +"~" + window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,1) +"~"+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,3)
			
			 meetdtls=meetdtls+"|"+meetdtls1	 
			 }
		}
		meetdtls=meetdtls.substr(1)
	}

	window.document.frmEmpMast.hdnmeetdtls.value=meetdtls
	
	window.document.frmEmpMast.hdnmeetingtype.value= window.document.frmEmpMast.cmbMeetingType.value
window.document.frmEmpMast.hdnmeetingdate.value= window.document.frmEmpMast.txtMeetingDate.value
window.document.frmEmpMast.hdnmeetingtime.value= window.document.frmEmpMast.txtMeetingTime.value
		window.document.frmEmpMast.method="post"
		window.document.frmEmpMast.action="frmDirAttendanceDtlsInsert.aspx"
		window.document.frmEmpMast.submit()
}
	
	
	

function DescrptionDisp(strTxt)
{
var strVal
strVal = ""

if(strTxt=="txtDirectorID")
	{ 
	strVal="DIRDETAILS"+"|"+window.document.frmEmpMast.txtDirectorID.value+"|"+" STATUS='R'"
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
}


function getDIRDETAILS(str)
{
	var stDetail=str.split("$")
	var strMainVal = stDetail[0].split("~")


window.document.frmEmpMast.txtDirectorName.value = strMainVal[1]
window.document.frmEmpMast.hdnsittingfeeyn.value = strMainVal[13]


}
	</script>
<SCRIPT LANGUAGE=javascript FOR=msflexMeetingDtls EVENT=DblClick>
<!--
 msflexMeetingDtls_DblClick()
//-->
</SCRIPT>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();resultmessage();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmEmpMast">
    
    <div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="40%" align="center" height="22" class="subHeader"><h2>BOD/BOM Meeting Attendance Details</h2></td>
				<td width="20%" height="22" align="right" class="subHeader"><%=appdate%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tblebordermain">
		<tr>
			<td width="100%">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" >
				<tr>
					<td width="100%" height=50 > &nbsp;
					</td>
				</tr>
					<tr>
						<td width="100%" >
							<!--<div style="text-align:center; width:100%; font-weight:bold; color:blue;"><%=Request.QueryString("record")%></div>-->
								
          <div align="center">
            <center>

            <table BORDER = 1 width="100%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="1" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                  <td width="20%" align="left">&nbsp;&nbsp;Meeting Type:&nbsp;&nbsp; <select id= "cmbMeetingType" name="cmbMeetingType">
 <option value="Select" selected>Select</option>
 <option value="BOD">BOD</option>
 <option value="BOM">BOM</option>
 </select><font color="#000000"></font></td>
		<td width="20%" align="left">&nbsp;&nbsp;Meeting Date :<input name="txtMeetingDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtMeetingDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>	
		<td width="20%" align="left"> Meeting Time : <input name="txtMeetingTime" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtMeetingTime.value)" size="12"  maxlength='12'>HH24MM</td>
		
				  </tr>
				  <tr>
				  <td  colspan=6>
				   <table align="center">
                    <tr>
                    <td  align="center">&nbsp;&nbsp;<input name="cmdMeetingDtlssok" onclick="Refresh()" type="button" value="   Refresh   " class="button"><input name="cmdMeetingDtlscancel" onclick="MeetingDtlsCancel()" type="button" value="Cancel" class="button"></td>
                    </tr>
				    </table>
				  </td>
				  </tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=msflexMeetingDtls style="LEFT: 0px; WIDTH: 800px; TOP: 0px; HEIGHT: 350px" 
	height=350 width=800px classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=msflexMeetingDtls >
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="4">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="<Sno         |<Dir ID         |<DirName                                                              |<AttendanceYN   ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
                  
				</table>  
	</td>
              </tr>
            </table>

            </center>
          
	<table width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 1003px"  class="tablebordermain">
	
		<tr>
			<td width="100%" align="center" ><input name="cmdOk" onclick="Ok()" type="button" value="    Ok    " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmDirAttendanceDtls.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
		</tr>
		
  </table>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
	
	<input type="hidden" name="hiddirid">
	<input type="hidden" name="hdnmeetdtls">
	<input type="hidden" name="hdnmeetingtype">
	<input type="hidden" name="hdnmeetingdate">
	<input type="hidden" name="hdnmeetingtime">
	<input type="hidden" name="hdnAppdate">
	<input type="hidden" name="hdndbltotsitfee">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDetails.aspx"></iframe>
    </form>

  </body>
</html>							