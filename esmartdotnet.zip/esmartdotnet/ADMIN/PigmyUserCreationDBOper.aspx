<%@ Page Language="vb" CodeBehind="PigmyUserCreationDBOper.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.PigmyUserCreationDBOper" %>


<%'*************************************************************************
'***************************************************************************
'*	Name Of the File : PigmyUserCreationDBOper.ASP						   *
'*	Purpose	  	     : To create Pigmy Agents in database			       *
'*						             									   *
'*																		   *
'*		   													               *
'*			                                            			       *
'|-------------------------------------------------------------------------|
'|     @Author 	      |    Created On    |  Version      |      Remarks	   |'|--------------------|------------------|---------------|-----------------|
'| Sharath Kumar More |    18-APR-2008   |   ASP.NET 1.0 |		           |
'|				      |                  |	             |                 |
'|-------------------------------------------------------------------------|
'***************************************************************************
'***************************************************************************

%>


<%
'''''' Variables Declaration

dim objfetch
dim objfetch1
dim recrs
dim objdrop
dim strresult
dim branchcode
dim usrname
dim usrid
dim password,pwd
dim passwordlifetime
dim passwordlocktime
dim passwordgracetime
dim FailedLoginAttempts
dim biometrics
dim groupid
dim groupname
dim transarray(0,4) ''''' For Database Transactions
dim objTrans
dim status
dim strfldval
dim strfields
dim add1
dim add2
dim city
dim desig
dim email
dim objmsg
dim strWhere
dim lockDt,expDt

''''' Values from PigmyUserCreation.ASP

status=Request.Form("status")
branchcode=Request.Form("txtbrcode")
GlCode=Request.Form("txtGlCode")
ModCode=Request.Form("txtModCode")
accno = Request.Form("txtAcc")
accNm = Request.Form("txtAccNm")
usrname=trim(Request.Form("txtusername"))
usrid=trim(Request.Form("txtuserid"))
password=trim(Request.Form("txtpwd"))
passwordlifetime=trim(Request.Form("txtlifetime"))
passwordlocktime="1"
passwordgracetime=trim(Request.Form("txtgracetime"))
FailedLoginAttempts=trim(Request.Form("txtfailed"))
biometrics=trim(Request.Form("txtbio"))
groupid=trim(Request.Form("txtGr"))
groupname=trim(Request.Form("txtGrNm"))
optSel=trim(Request.Form("opt1"))
'add1=trim(Request.Form("txtaddress"))
'add2=trim(Request.Form("txtaddress1"))
'city=trim(Request.Form("txtcity"))
'desig=trim(Request.Form("txtdesig"))
'email=trim(Request.Form("txtemail"))
macid=trim(Request.Form("txtMacid"))
appdate=session("applicationdate")
machineid=session("machineid")
createduserd=trim(session("userid"))
sessions=trim(Request.Form("txtSessions"))
reason=trim(Request.Form("txtreason"))
accstatus=trim(Request.Form("hidaccstatus"))
'empcode=trim(Request.Form("txtempcode"))
abbyn=trim(Request.Form("hidabb"))
expDt=trim(Request.Form("txtexpdate"))

if sessions="" then sessions=0

 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")

 objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")

if status="INSERT" then		'''' If new user has to be created
		
		 recrs=server.CreateObject("adodb.recordset")
		 recrs=objfetch.singlerecordset("PIGMYAGENTMST","AGENTCODE","agentcode='" & usrid & "'")
		 
		 if not recrs.eof and not recrs.bof then
			objMsg="User Creation Failed..! User Id Already Exists."
		 	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg & "..." & strresult)
		 end if
		
		pwd = EncodePWD(password, usrid)
		
			'''''' Insert the values into GENUSERMST
			strfields="BRANCHCODE, AGENTCODE, AGENTNAME, APPLICATIONDATE, MODULEID, GLCODE, ACCNO, TRANSTATUS, LOCKEDDATE, EXPIRYDATE, PASSWORD, GROUPID, GROUPNAME, ADDRESS, ADDRESS1, ADDRESS2, CITY, EMAILID, STATUS, USERID, CREATEDATE, MACHINEID, SYSTEMDATE, USERMACHINEID,accountstatusnarration,NOOFSESSIONS"
			
			strfldval="'" & branchcode & "','" & usrid & "','" & usrname & "',to_date('" & appdate & "','dd/Mon/yyyy'),'" & ModCode & "','" & GlCode & "','" & accno & "','P','','" & expDt & "','" & pwd & "','" & groupid & "','" & groupname & "','','','','','','R','" & createduserd & "',to_date('" & appdate & "','dd/Mon/yyyy'),'" & machineid & "',sysdate,'','Running',1"
			
			'strfields="NAME,CREATEDATE,STATUS,SYSTEMDATE,USERID,BRANCHCODE," & _
			'		"ACCOUNTSTATUS,EXPIRYDATE,BIOMETRICS,GROUPID,GROUPNAME,DESIGNATION," & _
			'		"ADDRESS,CITY,EMAILID,CREATEDUSERID,MACHINEID,USERMACHINEID,NOOFSESSIONS," & _
			'		"accountstatusnarration,EMpcode,applicationdate,AbbUserYn"
			'strfldval="'" & ucase(usrname) & "',to_date('" & appdate & "','dd/Mon/yyyy'),'N',sysdate,'" & _
			'		trim(ucase(usrid)) & "','" & branchcode & "','R',sysdate+" & _
			'		trim(passwordlifetime) & ",'" & trim(biometrics) & "','" & trim(groupid) & _
			'		"','" & trim(groupname) & "','" & trim(desig) & "','" & trim(add1) & "+}" & _
			'		trim(add2) & "','" & trim(city) & "','" & trim(email) & "','" & _
			'		trim(createduserd) & "','" & trim(machineid) & "','" & macid & "'," & _
			'		cint(sessions) & ",'Running','" & empcode & "','" & appdate & "','" & abbyn & "'"
			transarray(0,0)="I"	
			transarray(0,1)="pigmyagentmst"
			transarray(0,2)=strfields
			transarray(0,3)=strfldval
			transarray(0,4)=""
			
	
		
elseif status="MODIFY" then  ''''' If to be modify the user information
				
		recrs=server.CreateObject("adodb.recordset")
		recrs=objfetch.singlerecordset("PIGMYAGENTMSTTEMP","AGENTCODE","AGENTCODE='" & usrid & "'")
		 
		 if not recrs.eof and not recrs.bof then
			objMsg="User Modification Failed..! User is Already Under Modification."
		 	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg & "...")
		 end if
		 
		recrs=server.CreateObject("adodb.recordset")
		recrs=objfetch.singlerecordset("PIGMYAGENTMST","nvl(to_char(EXPIRYDATE,'DD-MON-YYYY'),''),password","agentcode='" & usrid & "'")
		 
		 if recrs.recordcount = 0 then
			objMsg="User Modification Failed..! Expiry Date Not Found For The User."
		 	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg & "...")
		 elseif recrs(0).value = "" then
		 	objMsg="User Modification Failed..! Expiry Date Not Found For The User."
		 	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg & "...")
		 end if
		  
		pwd = recrs(1).value
		
		strfields="BRANCHCODE, AGENTCODE, AGENTNAME, APPLICATIONDATE, MODULEID, GLCODE, ACCNO, TRANSTATUS, LOCKEDDATE, EXPIRYDATE, PASSWORD, GROUPID, GROUPNAME, ADDRESS, ADDRESS1, ADDRESS2, CITY, EMAILID, NOOFSESSIONS, STATUS, USERID, CREATEDATE, MACHINEID, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, APPROVEDMACHINE, SYSTEMDATE, USERMACHINEID,USERNAME,accountstatusnarration"
			
			strfldval="'" & branchcode & "','" & usrid & "','" & usrname & "',to_date('" & appdate & "','dd/Mon/yyyy'),'" & ModCode & "','" & GlCode & "','" & accno & "','P','','" & expDt & "','" & pwd & "','" & groupid & "','" & groupname & "','','','','','',1,'P','" & createduserd & "',to_date('" & appdate & "','dd/Mon/yyyy'),'" & machineid & "','" & usrid & "','" & machineid & "','" & usrid & "','" & machineid & "',sysdate,'','" & usrname & "','Modified'"
		
		''25-04-2008'strfields = "USERNAME,PASSWORD,transtatus"
		''25-04-2008'strfldval = "'" & usrname & "'~'" & pwd & "'~'P'" 	
		''25-04-2008'strWhere="upper(userid)='" & ucase(usrid) & "'"
		
		''25-04-2008'transarray(0,0)="U"	
		''25-04-2008'transarray(0,1)="pigmyagentmst"
		''25-04-2008'transarray(0,2)=strfields
		''25-04-2008'transarray(0,3)=strfldval
		''25-04-2008'transarray(0,4)=strwhere
		
		
		transarray(0,0)="I"	
		transarray(0,1)="PIGMYAGENTMSTTEMP"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=""
		
		Response.Write (strfldval & "<br>")
		Response.Write (strfields & "<br>")
		'Response.End (strwhere  & "<br>")
		

elseif status="DISABLE" then  ''''' If to be modify the user information
		
		lockDt=""
		
		if accstatus="F" then
			lockDt= appdate
		end if
		
		strfields="status,MACHINEID,applicationdate,transtatus,systemdate,accountstatusnarration,LOCKEDDATE"
		
		strfldval="'" & accstatus & "'~'" & session("machineid") & "'~'" & _
				session("applicationdate") & "'~'A'~sysdate~'" & reason & _
				"'~'" & lockDt & "'"
				
		strWhere="upper(agentcode)='" & ucase(usrid) &"'"
		transarray(0,0)="U"	
		transarray(0,1)="pigmyagentmst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere
		
elseif status="DELETE" then  ''''' If mark the user for Deletion

		'pwd = EncodePWD(password, usrid)
		
		'recrs=server.CreateObject("adodb.recordset")
		'recrs=objfetch.singlerecordset("PIGMYAGENTMST","PASSWORD","userid='" & usrid & "'")
		 
		'if not recrs.eof and not recrs.bof then
		'	password = recrs(0).value
		'else
		'	objMsg="User deletion Failed..!"
		'	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg )
		'end if
		
		'if pwd<>password then
		'	objMsg="User deletion Failed..! Wrong Password Entered"
		'	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg )
		'end if
		
		strfields="STATUS,MACHINEID,applicationdate,systemdate,accountstatusnarration,transtatus"
		strfldval="'D'~'" & machineid & "'~'" & appdate & "'~sysdate~'Deleted'~'P'"
		strWhere="upper(agentcode)='" & ucase(usrid) & "'"
		transarray(0,0)="U"	
		transarray(0,1)="pigmyagentmst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere

elseif status="REJECT" then   '''''' If the user is rejected ( this is from PigmyUserCreationAPPROVE.aspx)
		
		 'recrs=server.CreateObject("adodb.recordset")
		 'recrs=objfetch.singlerecordset("genusermsthist", _
		'		"BRANCHCODE,NAME,EMPCODE,to_char(APPLICATIONDATE,'DD-MON-YYYY'),ACCOUNTSTATUS,LOCKEDDATE,BIOMETRICS," & _
		'		"GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,MACHINEID," & _
		'		"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,CREATEDUSERID,Abbuseryn", _
		'		"userid='" & usrid &"' and rowid=(select max(rowid) from genusermsthist " & _
		'		"where userid='" & usrid &"')")
		'Response.Write ("genusermsthist" & "   BRANCHCODE,NAME,EMPCODE,APPLICATIONDATE,ACCOUNTSTATUS,LOCKEDDATE,EXPIRYDATE,BIOMETRICS,GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,CREATEDATE,MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,SYSTEMDATE,CREATEDUSERID"&"    userid='" & usrid &"' and rowid=(select max(rowid) from genusermsthist where userid='" & usrid &"')")
		'if 1=2 then
		'if not recrs.eof and not recrs.bof then
		'	for icount=0 to recrs.fields.count-1
		'		strflds=strflds & "," & recrs(icount).name
		'		strvals=strvals & "~'" & recrs(icount).value & "'"
		'	next
		'	strflds="BRANCHCODE,NAME,EMPCODE,APPLICATIONDATE,ACCOUNTSTATUS,LOCKEDDATE,BIOMETRICS," & _
		'		"GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,MACHINEID," & _
		'		"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,CREATEDUSERID,Abbuseryn"
			
			'strflds=right(strflds,len(strflds)-1)
		'	strvals=right(strvals,len(strvals)-1)
		
		dim strSt,strTab,strStatus
		Redim transarray(1,4)
		
		if optSel="INSERT" then
			strSt="U"
			strTab="pigmyagentmst"
			strvals="'J'~'Rejected'"
			strflds="STATUS,ACCOUNTSTATUSNARRATION"
			
		elseif optSel="MODIFY" then
			strSt="D"
			strTab="pigmyagentmsttemp"
			strvals=""
			strflds=""
			
		elseif optSel="DELETE" then
			strSt="U"
			strTab="pigmyagentmst"
			strflds="STATUS,ACCOUNTSTATUSNARRATION"
			strvals="'R'~'Running'"
		
		end if
		
			transarray(0,0)=strSt
			transarray(0,1)=strTab
			transarray(0,2)=strflds
			transarray(0,3)=strvals
			transarray(0,4)="agentcode='" & usrid & "'"
			 
			if optSel="INSERT" then
				transarray(1,0)="D"
				transarray(1,1)=strTab
				transarray(1,2)=""
				transarray(1,3)=""
				transarray(1,4)="agentcode='" & usrid & "'"
			end if
			
			'objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			'Response.Write (objmsg)
		'else
			
		 'objdrop= SERVER.CreateObject("CreateAndAlterUser.DDLTransactions")		
		'''' Drop the user
		'objmsg=objdrop.dropuser(cstr(usrid))
		'''' Delete from the genusermst
		'strWhere="upper(userid)='" & ucase(usrid) &"'"
		'transarray(0,0)="D"	
		'transarray(0,1)="pigmyagentmst"
		'transarray(0,2)=""
		'transarray(0,3)=""
		'transarray(0,4)=strwhere
		'end if
		'end if
elseif status="APPROVE" then  '''''' If the user is approved ( this is from PigmyUserCreationAPPROVE.aspx)

		'''' Update the status 'A' in PigmyAgentmst
		
		 strWhere="agentcode='" & usrid & "'"
		
		 recrs=server.CreateObject("adodb.recordset")
		 recrs=objfetch.singlerecordset("PIGMYAGENTMST","agentcode","status='D' and agentcode='" & usrid &"'")
		if not recrs.EOF and not recrs.BOF then
			transarray(0,0)="D"	
			transarray(0,1)="pigmyagentmst"
			transarray(0,2)=""
			transarray(0,3)=""
			transarray(0,4)="status='D' and " & strWhere
					
		else
			if optSel="INSERT" then
				strfields="transtatus,STATUS,Approvedby,approvedmachine,applicationdate,systemdate,VERIFIEDBY, VERIFIEDMACHINE"	
				strfldval="'A'~'R'~'" & ucase(session("userid")) & "'~'" & session("machineid") & "'~'" & appdate & "'~sysdate~'" & ucase(session("userid")) & "'~'" & session("machineid") & "'"
				

				transarray(0,0)="U"	
				transarray(0,1)="pigmyagentmst"
				transarray(0,2)=strfields
				transarray(0,3)=strfldval
				transarray(0,4)=strwhere

			elseif optSel="MODIFY" then
						
				'strWhere="userid='" & usrid &"'"
				
				recrs=server.CreateObject("adodb.recordset")
				
				strfields="BRANCHCODE, AGENTCODE, AGENTNAME, MODULEID, GLCODE, ACCNO, to_char(EXPIRYDATE,'DD-MON-YYYY'), PASSWORD, GROUPID, GROUPNAME, USERID, to_char(CREATEDATE,'DD-MON-YYYY'), MACHINEID, VERIFIEDBY, VERIFIEDMACHINE, USERMACHINEID,NOOFSESSIONS"
				
				recrs=objfetch.singlerecordset("PIGMYAGENTMSTtemp",strfields,"status='P' and agentcode='" & usrid &"'")
				
				if not recrs.EOF and not recrs.BOF then
						tstr="'"
					for idx=0 to (recrs.Fields.Count)-1
						tstr=tstr & recrs(idx).value & "','"
					next
					
				end if
				
				strfields="BRANCHCODE, AGENTCODE, AGENTNAME, MODULEID, GLCODE, ACCNO, EXPIRYDATE, PASSWORD, GROUPID, GROUPNAME, USERID, CREATEDATE, MACHINEID, VERIFIEDBY, VERIFIEDMACHINE, USERMACHINEID,NOOFSESSIONS,TRANSTATUS,STATUS,Approvedby,approvedmachine,applicationdate,systemdate,ACCOUNTSTATUSNARRATION"	
				
				strfldval=tstr & "A','R','" & ucase(session("userid")) & "','" & session("machineid") & "','" & appdate & "',sysdate,'Running'"
				
				Redim transarray(2,4) ''''' For Database Transactions

				
				transarray(0,0)="D"	
				transarray(0,1)="pigmyagentmst"
				transarray(0,2)=""
				transarray(0,3)=""
				transarray(0,4)=strwhere
				
				transarray(1,0)="I"	
				transarray(1,1)="pigmyagentmst"
				transarray(1,2)=strfields
				transarray(1,3)=strfldval
				transarray(1,4)=""
				
				transarray(2,0)="D"	
				transarray(2,1)="pigmyagentmsttemp"
				transarray(2,2)=""
				transarray(2,3)=""
				transarray(2,4)=strwhere

			end if		
		end if
end if

Response.Write (transarray(0,4) & "<br>" & transarray(0,3) & "<br>" & transarray(0,2) & "<br>" & transarray(0,1) &"<br>")
Response.Write (session("applicationdate"))
''''' Execute the transarray 
	
		'objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
		
		objmsg= ObjTrans.DataTransactions(Transarray,cstr(session("branchcode")),cstr(session("userid")),cstr(session("machineid")),cstr(session("applicationdate")))
		
'Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))

Response.Write (objmsg)
if objmsg<>"Transaction Sucessful." then
	if status="INSERT" then
		 'objdrop= SERVER.CreateObject("CreateAndAlterUser.DDLTransactions")
		'objmsg1=objdrop.dropuser(cstr(usrid))
		
	end if
end if


Response.Write (strresult)
'''' Redirect it accordingly
If status<>"APPROVE" and status<> "REJECT" then
	strresult = replace(strresult,chr(10)," ")
	strresult = replace(strresult,chr(13)," ")
	Response.Redirect ("PigmyUserCreation.ASPx?record=" & objMsg & "..." & strresult)
else
	objMsg = replace(objMsg,chr(10)," ")
	objMsg = replace(objMsg,chr(13)," ")
	Response.Redirect ("PigmyUserCreationapprove.ASPx?record=" & objMsg) 
end if
%>

<script language=vbscript runat=server>

''''''''''''''''''''''''''''''''''''''''''
Function EncodePWD(strPwd, stUserid )
	Dim intcnt, strNpwd, strNuser
    
	'stUserid = UCase(Left(stUserid, 3))
		For intcnt = 1 To Len(strPwd)
			strNpwd = strNpwd & ChartoNum(Mid(strPwd, intcnt, 1))
		Next intcnt
    
		For intcnt = 1 To Len(UCase(Left(stUserid, 3)))
			strNuser = strNuser & ChartoNum(Mid(UCase(Left(stUserid, 3)), intcnt, 1))
		Next intcnt
    
		EncodePWD = strNuser & StrReverse(Mid(strNpwd, 1, Len(strNpwd) / 2)) & Mid(strNpwd, (Len(strNpwd) / 2) + 1)
    
End Function

'Function to Decode Password
Function DecodePWD(strPwd, stUserid )
	Dim intcnt ,strNpwd ,strNuser, strSUser

	strNuser = Left(strPwd, 6)
	strPwd = Mid(strPwd, 7)
	strPwd = StrReverse(Mid(strPwd, 1, Len(strPwd) / 2)) & Mid(strPwd, (Len	(strPwd) / 2) + 1)
	stUserid = Left(stUserid, 3)

		For intcnt = 1 To Len(strPwd)
			strNpwd = strNpwd & NumToChar(Mid(strPwd, intcnt, 2))
			intcnt = intcnt + 1
		Next intcnt
    
		For intcnt = 1 To Len(strNuser)
			 strSUser = strSUser & NumToChar(Mid(strNuser, intcnt, 2))
			intcnt = intcnt + 1
		Next intcnt
           
		DecodePWD = strSUser & strNpwd
End Function

Function ChartoNum(strChar)

	If Left(strChar, 1) = "A" Then ChartoNum = 56
	If Left(strChar, 1) = "B" Then ChartoNum = 18
	If Left(strChar, 1) = "C" Then ChartoNum = 46
	If Left(strChar, 1) = "D" Then ChartoNum = 42
	If Left(strChar, 1) = "E" Then ChartoNum = 55
	If Left(strChar, 1) = "F" Then ChartoNum = 17
	If Left(strChar, 1) = "G" Then ChartoNum = 47
	If Left(strChar, 1) = "H" Then ChartoNum = 57
	If Left(strChar, 1) = "I" Then ChartoNum = 11
	If Left(strChar, 1) = "J" Then ChartoNum = 31
	If Left(strChar, 1) = "K" Then ChartoNum = 65
	If Left(strChar, 1) = "L" Then ChartoNum = 34
	If Left(strChar, 1) = "M" Then ChartoNum = 50
	If Left(strChar, 1) = "N" Then ChartoNum = 23
	If Left(strChar, 1) = "O" Then ChartoNum = 64
	If Left(strChar, 1) = "P" Then ChartoNum = 45
	If Left(strChar, 1) = "Q" Then ChartoNum = 27
	If Left(strChar, 1) = "R" Then ChartoNum = 69
	If Left(strChar, 1) = "S" Then ChartoNum = 52
	If Left(strChar, 1) = "T" Then ChartoNum = 54
	If Left(strChar, 1) = "U" Then ChartoNum = 19
	If Left(strChar, 1) = "V" Then ChartoNum = 36
	If Left(strChar, 1) = "W" Then ChartoNum = 35
	If Left(strChar, 1) = "X" Then ChartoNum = 53
	If Left(strChar, 1) = "Y" Then ChartoNum = 13
	If Left(strChar, 1) = "Z" Then ChartoNum = 14

	If Left(strChar, 1) = "a" Then ChartoNum = 28
	If Left(strChar, 1) = "b" Then ChartoNum = 38
	If Left(strChar, 1) = "c" Then ChartoNum = 39
	If Left(strChar, 1) = "d" Then ChartoNum = 24
	If Left(strChar, 1) = "e" Then ChartoNum = 58
	If Left(strChar, 1) = "f" Then ChartoNum = 33
	If Left(strChar, 1) = "g" Then ChartoNum = 60
	If Left(strChar, 1) = "h" Then ChartoNum = 44
	If Left(strChar, 1) = "i" Then ChartoNum = 16
	If Left(strChar, 1) = "j" Then ChartoNum = 48
	If Left(strChar, 1) = "k" Then ChartoNum = 15
	If Left(strChar, 1) = "l" Then ChartoNum = 59
	If Left(strChar, 1) = "m" Then ChartoNum = 30
	If Left(strChar, 1) = "n" Then ChartoNum = 21
	If Left(strChar, 1) = "o" Then ChartoNum = 32
	If Left(strChar, 1) = "p" Then ChartoNum = 70
	If Left(strChar, 1) = "q" Then ChartoNum = 72
	If Left(strChar, 1) = "r" Then ChartoNum = 68
	If Left(strChar, 1) = "s" Then ChartoNum = 29
	If Left(strChar, 1) = "t" Then ChartoNum = 61
	If Left(strChar, 1) = "u" Then ChartoNum = 37
	If Left(strChar, 1) = "v" Then ChartoNum = 51
	If Left(strChar, 1) = "w" Then ChartoNum = 25
	If Left(strChar, 1) = "x" Then ChartoNum = 43
	If Left(strChar, 1) = "y" Then ChartoNum = 67
	If Left(strChar, 1) = "z" Then ChartoNum = 26


	If Left(strChar, 1) = "1" Then ChartoNum = 62
	If Left(strChar, 1) = "2" Then ChartoNum = 20
	If Left(strChar, 1) = "3" Then ChartoNum = 63
	If Left(strChar, 1) = "4" Then ChartoNum = 40
	If Left(strChar, 1) = "5" Then ChartoNum = 66
	If Left(strChar, 1) = "6" Then ChartoNum = 22
	If Left(strChar, 1) = "7" Then ChartoNum = 12
	If Left(strChar, 1) = "8" Then ChartoNum = 49
	If Left(strChar, 1) = "9" Then ChartoNum = 71
	If Left(strChar, 1) = "0" Then ChartoNum = 41
End Function



Function NumToChar(intNum )
	If intNum=nothing Then NumToChar = ""

	If Val(intNum) = 56 Then NumToChar = "A"
	If Val(intNum) = 18 Then NumToChar = "B"
	If Val(intNum) = 46 Then NumToChar = "C"
	If Val(intNum) = 42 Then NumToChar = "D"
	If Val(intNum) = 55 Then NumToChar = "E"
	If Val(intNum) = 17 Then NumToChar = "F"
	If Val(intNum) = 47 Then NumToChar = "G"
	If Val(intNum) = 57 Then NumToChar = "H"
	If Val(intNum) = 11 Then NumToChar = "I"
	If Val(intNum) = 31 Then NumToChar = "J"
	If Val(intNum) = 65 Then NumToChar = "K"
	If Val(intNum) = 34 Then NumToChar = "L"
	If Val(intNum) = 50 Then NumToChar = "M"
	If Val(intNum) = 23 Then NumToChar = "N"
	If Val(intNum) = 64 Then NumToChar = "O"
	If Val(intNum) = 45 Then NumToChar = "P"
	If Val(intNum) = 27 Then NumToChar = "Q"
	If Val(intNum) = 69 Then NumToChar = "R"
	If Val(intNum) = 52 Then NumToChar = "S"
	If Val(intNum) = 54 Then NumToChar = "T"
	If Val(intNum) = 19 Then NumToChar = "U"
	If Val(intNum) = 36 Then NumToChar = "V"
	If Val(intNum) = 35 Then NumToChar = "W"
	If Val(intNum) = 53 Then NumToChar = "X"
	If Val(intNum) = 13 Then NumToChar = "Y"
	If Val(intNum) = 14 Then NumToChar = "Z"

	If Val(intNum) = 28 Then NumToChar = "a"
	If Val(intNum) = 38 Then NumToChar = "b"
	If Val(intNum) = 39 Then NumToChar = "c"
	If Val(intNum) = 24 Then NumToChar = "d"
	If Val(intNum) = 58 Then NumToChar = "e"
	If Val(intNum) = 33 Then NumToChar = "f"
	If Val(intNum) = 60 Then NumToChar = "g"
	If Val(intNum) = 44 Then NumToChar = "h"
	If Val(intNum) = 16 Then NumToChar = "i"
	If Val(intNum) = 48 Then NumToChar = "j"
	If Val(intNum) = 15 Then NumToChar = "k"
	If Val(intNum) = 59 Then NumToChar = "l"
	If Val(intNum) = 30 Then NumToChar = "m"
	If Val(intNum) = 21 Then NumToChar = "n"
	If Val(intNum) = 32 Then NumToChar = "o"
	If Val(intNum) = 70 Then NumToChar = "p"
	If Val(intNum) = 72 Then NumToChar = "q"
	If Val(intNum) = 68 Then NumToChar = "r"
	If Val(intNum) = 29 Then NumToChar = "s"
	If Val(intNum) = 61 Then NumToChar = "t"
	If Val(intNum) = 37 Then NumToChar = "u"
	If Val(intNum) = 51 Then NumToChar = "v"
	If Val(intNum) = 25 Then NumToChar = "w"
	If Val(intNum) = 43 Then NumToChar = "x"
	If Val(intNum) = 67 Then NumToChar = "y"
	If Val(intNum) = 26 Then NumToChar = "z"

	If Val(intNum) = 62 Then NumToChar = "1"
	If Val(intNum) = 20 Then NumToChar = "2"
	If Val(intNum) = 63 Then NumToChar = "3"
	If Val(intNum) = 40 Then NumToChar = "4"
	If Val(intNum) = 66 Then NumToChar = "5"
	If Val(intNum) = 22 Then NumToChar = "6"
	If Val(intNum) = 12 Then NumToChar = "7"
	If Val(intNum) = 49 Then NumToChar = "8"
	If Val(intNum) = 71 Then NumToChar = "9"
	If Val(intNum) = 41 Then NumToChar = "0"

End Function
''''''''''''''''''''''''''''''''''''''''''

</script>