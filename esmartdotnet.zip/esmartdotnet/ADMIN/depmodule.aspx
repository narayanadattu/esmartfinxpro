<%@ Page CodeBehind="depmodule.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.depmodule1" %>
<%Response.Write Request.QueryString ("madhu")%>
<SCRIPT LANGUAGE=javascript>
<!--
function callme()
{

alert("No Form is alloted this User")
var varst
varst=location.pathname 
varst=varst.split("/")
location.replace ("http://" + location.hostname +"/" + varst[1] +"/back.asp")
}
//-->
</SCRIPT>

<html>

<%	Response.Write session("pwd")%>
<%
	dim usrid
	dim objfetch
	dim objwork
	dim recdtls
	dim vals
	dim title
	dim vmod
	dim chkstr
	dim recmod
	
	vmod=Request.QueryString("record")
	usrid=session("userid")
	
	session("module")=trim(vmod)
	
	set objwork=server.CreateObject("workallotment.allotment")
	vals=objwork.userworkallotment("DELETE",trim(cstr(usrid)),trim(cstr(vmod)),trim(cstr(session("branchcode"))))
	for icount=0 to ubound(vals)-1
		valstr=valstr&",'" & vals(icount) &"'"
	next
	
	if len(valstr)>0 then 
		valstr=right(valstr,len(valstr)-1)
		set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
		set recdtls=server.CreateObject("adodb.recordset")
		set recdtls=objfetch.singlerecordset("genmoduleidformsmst","menutitle,narration,forms,gendir,mainmenu","upper(narration) in(" & ucase(valstr) & ") and moduleid='" & trim(vmod) &"' order by menuorder")
		set recmod=server.CreateObject("adodb.recordset")
		set recmod=objfetch.singlerecordset("genmodulemst","moduledir","moduleid='" & trim(vmod) &"'")
	
		if not recdtls.EOF or not recdtls.BOF then
			chkstr=recdtls(0)
			mainstr=chkstr
		end if
		do while not recdtls.EOF 
			if isnull(recdtls(3))=false then
				stdir=recdtls(3)
			else
				stdir=recmod(0)
			end if
			if recdtls(0)=chkstr then
				mainstr=mainstr & "," & recdtls(1) &"*" & stdir & "/" & recdtls(2)
			else
				chkstr=recdtls(0)
				mainstr=mainstr & "|" & recdtls(0) & "," & recdtls(1)&"*" & stdir & "/" & recdtls(2) 
			end if
			recdtls.MoveNext
		loop
	
		
		set recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir")
		mainstr=trim(recdtls(0)) &"/" & trim(recdtls(1)) &"/" & "~" & mainstr
		session("moduledir")=trim(recdtls(0)) &"/" & trim(recdtls(1)) 
		session("menustring")=mainstr
%>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmart Banker - Administration</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>


<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmart Banker - Administration</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>


</head>
<body onload="GetMenu(&quot;<%=session("menustring")%>&quot;)" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">
<form name="frmcashmodule">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top">

      </form>
      <p><img border="0" src="../cutimages/administrationscr780500.jpg"></p>
      <div align="center">
        <center>

        <table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#7D5445" height="24">
          <tr>
            <td width="100%" height="24">&nbsp;</td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
  </table>

</body>


<% 
else

	session("menustring")=""
	if len( session("userid"))<1 then
	Response.Write "<center><font color=red><b>No User is Logged in...</b></font></center><br>"
	Response.Write "<center><a href='../useridscreen.asp'><b><font color=blue id =i onmouseover=javascript:document.all.i.color='red' onmouseout=javascript:document.all.i.color='blue'>Please Login</b></a></center>"
	session.abandon
	elseif session("menustring")="" then
	Response.Write "<center><font color=red><b>Invalid Module...</b></font></center><br>"
	Response.Write "<center><a href='../useridscreen.asp'><b><font color=blue id =i onmouseover=javascript:document.all.i.color='red' onmouseout=javascript:document.all.i.color='blue'>Please Login again</b></a></center>"
	session.Abandon 
	session("moduleid")="xxxx"
	end if %>
	
<% end if%>

