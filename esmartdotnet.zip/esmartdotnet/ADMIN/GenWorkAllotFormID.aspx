 <%@ Page Language="vb" CodeBehind="GenWorkAllotFormID.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotFormID" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenworkallotformID.ASP								*
'*	Purpose	  	     : To get the forms for the selected module         	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
	<SCRIPT LANGUAGE=javascript>
<!--


//-->

</SCRIPT>
<title></title>
</head>
<body>

<form name="frmforms">
	<%
	'''' Declaration of variables
	Dim objfetch
	dim vark
	dim strdata
	dim recst
	dim cnt
	dim varst(0,0)
	''' Getting data from genworkallotment.asp
    strdata=Request.Form("hform")
	
	 objquery=server.CreateObject("queryrecordsets.fetchrecordsets")
'''''' if data found the split it
 if len(strdata)>0 then
      vark=split(strdata,"|")
     ''' Take the status
      sts=cstr(vark(0))
      '''' create the instance of object
      obj=server.CreateObject("WorkAllotment.Allotment")
      recst=server.CreateObject("adodb.recordset")
        'Response.Write ubound(vark) & "<br>" 
    if ubound(vark)>0 then  
    ''''' If USer is selected call userworkallotment
    
		'Response.Write vark(4) & "<br>"
		'Response.End 
    
		if vark(4)="user" then
			stcond="moduleid='"& cstr(vark(2))  &"'  and userid='"& cstr(vark(1)) &"' and transtatus<>'A' " 
					
			 recst=objquery.singlerecordset("GenuseridFormsMst","transtatus", cstr(stcond))
			
			'Response.Write stcond
			if not recst.EOF and not recst.BOF then
				redim varst(0,0)
				varst(0,0)="This Module for this User is under Pending.."
			else
				varst=obj.UserWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
			end if
			
			
	''''' If Group is selected call Groupworkallotment
		elseif vark(4)="group" then
			stcond="moduleid='"& cstr(vark(2))  &"'  and groupcode='"& cstr(vark(1)) &"' and transtatus<>'A' " 
					
			 recst=objquery.singlerecordset("GenGroupFormsMst","transtatus", cstr(stcond))
			'Response.Write (stcond)
			
			if not recst.EOF and not recst.BOF then
				redim varst(0,0)
				varst(0,0)="This Module for this Group is under Pending.."
			else
				redim varst(0,0)
				dim s1, s2, s3,s4
				
				s1 = cstr(vark(0))
				s2 = cstr(vark(1))
				s3 = cstr(vark(2))
				s4 = cstr(vark(3))
				
				varst=obj.GroupWorkAllotment(s1,s2,s3,s4)
			end if
	
	   end if	
  
	
  end if

	   
  %>


  <table border="0" width="120" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Forms</font></td>
    </tr>
  </table>

  <table>
      
      <%if vark(0)="modify" then%>
		   <%
		  ' if left(varst,6)<>"Object" then
		   if ubound(varst)<>0 then%>  
		   
	           <%for icount=0 to ubound(varst)-1%>
			                <%cnt=cnt+1%>
    <tr>
      <td nowrap>
			          <%if varst(icount,1)="Y"  then%>
				<%'Response.Write varst(icount,1) & "<br>"
				'Response.Write varst(icount,0) & "<br>"%>
      <input type="checkbox" id="chkfrm" name="chkfrm" checked value="<%=varst(icount,0)%>"><font color="black" face="MS Sans Serif" size="2"><%=varst(icount,0)%></font>
			             <%else%>
      <input type="checkbox" id="chkfrm" name="chkfrm" value="<%=varst(icount,0)%>"><font color="black" face="MS Sans Serif" size="2"><%=varst(icount,0)%></font>
			          <%end if%>
      </td>
    </tr>
			          
			   <%next%>
			<%else%>
    <font color="black" face="MS Sans Serif" size="2">
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<%=varst(0,0)%>
			
		<%end if
		'else%>
		<%'="No Forms to Modify.."%>
		<%'end if%>
      <%else%>
	
		<%if ubound(varst)<>0 then%>  
		    <%for icount=0 to ubound(varst)-1 %>
			
		       <%cnt=cnt+1%>
    <tr>
      <td>
				    <%if vark(0)="query" then%>
      <font color="black" face="MS Sans Serif" size="2"><%=varst(icount,0)%></font>
						
				      <%elseif vark(0)="add" then%>
      <input type="checkbox" id="chkfrm" name="chkfrm" value="<%=varst(icount,1)%>"><font color="black" face="MS Sans Serif" size="2"><%=varst(icount,0)%> </font>
				      <%elseif vark(0)="delete" then%>
      <input type="checkbox" id="chkfrm" name="chkfrm"  value="<%=varst(icount,1)%>"><font color="black" face="MS Sans Serif" size="2"><%=varst(icount,0)%></font>
				    <%end  if%>
      </td>
    </tr>
		    <%next%>
		  <%else%>
    <font color="black" face="MS Sans Serif" size="2">
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <%=varst(0,0)%>
	   <%end if%>
	  
	  <%end if
	 obj=nothing%>
      <%end if%>

      <input type="hidden" name="hcnt" value="<%=cnt%>"> <input type="hidden" name="hform" id="hform">
      <input type="hidden" name="hstatus" id="hstatus" value="<%=sts%>">
      </form>
      </td>
    </tr>
    </font></font>
  </table>

</body>

