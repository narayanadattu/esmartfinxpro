<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="EmploymstInst.aspx.vb" Inherits="eSmartDotNet.EmploymstInst"%>
<%

dim obj,obj1,obj2,obj3,obj4,rs,rs1,rs2,rs3,Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno
obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj2 = server.CreateObject("ReportPurposeOnly.Reportonly")

obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
obj3=server.CreateObject("queryrecordsets.fetchrecordsets")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")

dim Arrtrans(50,4)

appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("empval")
strval=split(strmode,"~")


if strval(0)="INSERT" then
	
		
		sqlStr="SELECT nvl(max(EMPCODE),0)+1 num FROM EMPLOYEEMST" ''for table name 
		
		rs=obj2.SingleSelectStat(sqlStr)
		
		if obj2.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				accno = rs(0).value 
			end if
		end if
		
			strcolnames=" EMPCODE, CUSTOMERID, USERID, EMPNAME, DESGNCODE, APPOINTDT, TEMPDT, PERMENTDT, CONFIRMDT, EDUQUALIFY, TECQUALIFY, OTHERQUALIFY, CONPAY, BASIC, DA, HRA, ALLOWANCE, MEDIREIMB, OTHERALLOWANCE, GROSSPAY, PROFTAX, PROVFUND, OTHERDEDUCT, TOTALDEDUCT, NETPAY, GIP, EPFACCNO, BRANCHCODE, MODULEID, GLCODE, ACCNO, WORKINGBRCODE, ESI, VPF, TDS, STATUS, gratuityyn "
			 'EMPCODE, CUSTOMERID, USERID, EMPNAME, DESGNCODE, APPOINTDT, TEMPDT, PERMENTDT, CONFIRMDT, EDUQUALIFY, TECQUALIFY, CONPAY, BASIC, DA, HRA, ALLOWANCE, GROSSPAY, PROFTAX, MR, FESTDEDUCT, OTHERS, LICPREMIUM, PROVFUND, TOTALDEDUCT, NETPAY, EPFACCNO, WORKINGBRCODE, BRANCHCODE, MODULEID, GLCODE, ACCNO,  OTHERQUALIFY, OTHERALLOWANCE, GIP, STATUS"
				
				strInst=split(strval(1),"|")
				
			strdelvar="'" & accno & "','" & strInst(0) & "','" & strInst(1) & "','" & strInst(2) & "','" & strInst(3) & "','" & strInst(4) & "','" & strInst(5) & "','" & strInst(6) & "','" & strInst(7) & "','" & strInst(8) & "','" & strInst(9) & "','" & strInst(10) & "','" & strInst(11) & "','" & strInst(12) & "','" & strInst(13) & "','" & strInst(14) & "','" & strInst(15) & "','" & strInst(16) & "','" & strInst(17) & "','" & strInst(18) & "','" & strInst(19) & "','" & strInst(20) & "','" & strInst(21) & "','" & strInst(22) & "','" & strInst(23) & "','" & strInst(24) & "','" & strInst(25) & "','" & strInst(26) & "','" & strInst(27) & "','" & strInst(28) & "','" & strInst(29) & "','" & strInst(30) & "','" & strInst(31) & "','" & strInst(32) & "','" & strInst(33) & "','R','" & strInst(34) & "'"
				
				Arrtrans(0,0)="I"			
				Arrtrans(0,1)="EMPLOYEEMST"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=""
				
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
			
			Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
			
			Strmsg = Strmsg & "|" & accno
			
			Response.Write (Strmsg)	
			obj=nothing
		 
	
else if strval(0)="MODIFY" then
	
			strcolnames=" EMPCODE, CUSTOMERID, USERID, EMPNAME, DESGNCODE, APPOINTDT, TEMPDT, PERMENTDT, CONFIRMDT, EDUQUALIFY, TECQUALIFY, OTHERQUALIFY, CONPAY, BASIC, DA, HRA, ALLOWANCE, MEDIREIMB, OTHERALLOWANCE, GROSSPAY, PROFTAX, PROVFUND, OTHERDEDUCT, TOTALDEDUCT, NETPAY, GIP, EPFACCNO, BRANCHCODE, MODULEID, GLCODE, ACCNO, WORKINGBRCODE, LETTERDT, LEAVINGDT, REASON, STATUS, ESI, VPF, TDS, systemdate,gratuityyn"
			
			'EMPCODE, CUSTOMERID, USERID, EMPNAME, DESGNCODE, DOA, DOT, DOP, DOC, EDUQUALIFY, TECQUALIFY, CONPAY, BASIC, DA, HRA, ALLOWANCE, GROSSPAY, PROFTAX, MR, FESTDEDUCT, OTHERS, LICPREMIUM, PROVFUND, TOTALDEDUCT, NETPAY, EPFACCNO, WORKINGBRCODE, BRANCHCODE, MODULEID, GLCODE, ACCNO,  OTHERQUALIFY, OTHERALLOWANCE, GIP,LEAVINGDT, LETTERDT, REASON,STATUS "
						
			strInst=split(strval(1),"|")
				
			strdelvar="'" & strInst(0) & "'~'" & strInst(1) & "'~'" & strInst(2) & "'~'" & strInst(3) & "'~'" & strInst(4) & "'~'" & strInst(5) & "'~'" & strInst(6) & "'~'" & strInst(7) & "'~'" & strInst(8) & "'~'" & strInst(9) & "'~'" & strInst(10) & "'~'" & strInst(11) & "'~'" & strInst(12) & "'~'" & strInst(13) & "'~'" & strInst(14) & "'~'" & strInst(15) & "'~'" & strInst(16) & "'~'" & strInst(17) & "'~'" & strInst(18) & "'~'" & strInst(19) & "'~'" & strInst(20) & "'~'" & strInst(21) & "'~'" & strInst(22) & "'~'" & strInst(23) & "'~'" & strInst(24) & "'~'" & strInst(25) & "'~'" & strInst(26) & "'~'" & strInst(27) & "'~'" & strInst(28) & "'~'" & strInst(29) & "'~'" & strInst(30) & "'~'" & strInst(31) & "'~'" & strInst(32) & "'~'" & strInst(33) & "'~'" & strInst(34) & "'~'" & strInst(35) & "'~'" & strInst(36) & "'~'" & strInst(37) & "'~'" & strInst(38) & "'~SYSDATE~'" & strInst(39) &"'"
			
			strCond = " EMPCODE='" & strInst(0) & "' "
				
				Arrtrans(0,0)="U"			
				Arrtrans(0,1)="EMPLOYEEMST"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=strCond
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
		
	Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		 obj=nothing


end if

	Response.Redirect ("frmEmploymast.aspx?record=" & Strmsg)




%>