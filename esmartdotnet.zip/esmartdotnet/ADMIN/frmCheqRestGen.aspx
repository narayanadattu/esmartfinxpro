<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmCheqRestGen.aspx.vb" Inherits="eSmartDotNet.frmCheqRestGen"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<%

		'' modified by dattu 22-nov-22
	'' HO Trans Allowed
		dim strHOTrALWBrCode
	dim objhotraw as new GENVALIDATIONS.Validations
	strHOTrALWBrCode = objhotraw.GetHOTRALWBrCode()
	
	dim strSql, strDepcertificate as string
strDepcertificate=""
dim rsNFTS, objNFTS
rsNFTS=server.CreateObject("adodb.recordset")
objNFTS =server.CreateObject("ReportPurposeOnly.Reportonly")
strSql="SELECT Depcertificate FROM GENBANKPARM"
rsNFTS=objNFTS.SingleSelectStat(strSql)
if objNFTS.ConnError="Connected" then
	if not rsNFTS.bof and not rsNFTS.eof then
		strDepcertificate=rsNFTS(0).value
	end if
end if

	dim obj, rs, obj1, rs1
	
	dim impYn,brcod,Refnm
	
	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN","CODE='CHQREQ'")
	
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
	end if
	
	dim strmessage

	strmessage=Request.QueryString("record")

%>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>Customer Cheque Issue Request</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	
	function Display()
	{
		var strHOTrALWBrCode1 = "<%=strHOTrALWBrCode%>"
	var strDepcert= "<%=strDepcertificate%>"
	//alert(strDepcert)
	if (strDepcert == "PCUB")
	{
		window.document.frmCheqAscii.rdmode[1].disabled = true
	}
	else
	{
	window.document.frmCheqAscii.rdmode[1].disabled = false
	}
		var BRCD="<%=session("branchcode")%>"
		
		var IMP="<%=impYn%>"
		
		if(IMP=="Y")
		{
			if(BRCD==strHOTrALWBrCode1)
			{
				
			}
			else
			{
				alert("This Branch is not Authorized to do File Generation\n Please Contact H O ")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
		
		
	}
	
	
	function branch()
	{  
		telbr="Tellerbranch";
		window.showModalDialog("../GEN/Listquery.aspx"+"?"+"st="+telbr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
	}
	function Branchcode(kstr)
	{ 
		assign(kstr,window.document.frmCheqAscii.txtbranchdesc,window.document.frmCheqAscii.txtbranchcode)		
	} 
	
	var stBr,br,actyp,stActyp,actp,strVal
	
	function Ok()
	{
		//var stBr,br,actyp,stActyp,actp,strVal
		if(window.document.frmCheqAscii.rdmode[0].checked==true)
		{
		
		stBr = window.document.frmCheqAscii.txtbranchcode.value
		actp = window.document.frmCheqAscii.selAcType.value
		
		
		if(window.document.frmCheqAscii.chkAllbr.checked==true)
		{
			br = " "
		}
		else
		{
			br = " AND BRANCHCODE = '"+stBr+"' "
		}
		
		if(window.document.frmCheqAscii.selAcType.value=="ALL")
		{
			stActyp=""
		}
		else
		{
			stActyp=" AND ACTYPE = '"+actp+"' "
		}
		
		strVal = "FILEGEN"+"~"+br+"~"+stActyp+"~"+stBr
		
		/*window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;*/
		}
		
			// bankers cheque
	if(window.document.frmCheqAscii.rdmode[1].checked==true)
	{
	
	stBr = window.document.frmCheqAscii.txtbranchcode.value
		
		
		if(window.document.frmCheqAscii.chkAllbr.checked==true)
		{
			br = " "
		}
		else
		{
			br = " AND BRANCHCODE = '"+stBr+"' "
		}
		
		if(window.document.frmCheqAscii.selAcType.value=="ALL")
		{
			stActyp=""
		}
		else
		{
			stActyp=" AND ACTYPE = '"+actp+"' "
		}
		
		strVal = "BCGEN"+"~"+br+"~"+stActyp+"~"+stBr
	}	

		window.document.frmCheqAscii.mercust.value=strVal
		window.document.frmCheqAscii.action="CheqReqGen.aspx"
		window.document.frmCheqAscii.method="post"   
		window.document.frmCheqAscii.submit()
		
		
	}
	
	function popFilRep(str)
	{
		if(str=="")
		{
			alert("No records found to Generate file")
			return;
		}
		
		var strResult=str.split("|")
		
		var time = new Date();
		
		var month = new Array();
		month[0] = "Jan";
		month[1] = "Feb";
		month[2] = "Mar";
		month[3] = "Apr";
		month[4] = "May";
		month[5] = "Jun";
		month[6] = "Jul";
		month[7] = "Aug";
		month[8] = "Sep";
		month[9] = "Oct";
		month[10] = "Nov";
		month[11] = "Dec";

		var D = time.getDate();
		var M = month[time.getMonth()];
		var Y = time.getFullYear();
		var hh = time.getHours();
		var mm = time.getMinutes();
		var ss = time.getSeconds();
		
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		filepath="CHEQUEASCII"+D+"-"+M+"-"+Y+" "+hh+"-"+mm+"-"+ss
		
		if (! fso.FolderExists("C://ChequeRequest") )
		fso.CreateFolder("C://ChequeRequest")
		
		var fh = fso.CreateTextFile("c://"+ "ChequeRequest/"+filepath+".asc" , true); 
		var�strTemp=""
		
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			strTemp=strResult[aCnt]
			fh.WriteLine(strTemp)
			strTemp=""
		}
		fh.Close();
		alert("c://"+ "ChequeRequest/"+filepath+".asc: Customer Cheque File Created")
		
		br = window.document.frmCheqAscii.hidBrcd.value
		stActyp = window.document.frmCheqAscii.hidChbr.value
		
		strVal = "GENYNSTAT"+"~"+br+"~"+stActyp+"~"+stBr
		
		window.document.frmCheqAscii.mercust.value=strVal
		window.document.frmCheqAscii.action="CheqReqGen.aspx"
		window.document.frmCheqAscii.method="post"   
		window.document.frmCheqAscii.submit()
		
	}
	
	function DispTranMsg()
	{
		var strtran = "<%=strmessage%>"
		var mystr
		
		var stTr,stb,stc,stmsg,stbc,stlen,stc1,stb1
		var strfilename
		strfilename =  strtran.split("|")
		if ((strfilename[1] == "FILEGEN") || (strfilename[1] == "GENYNSTAT"))
		{
		if (strfilename[0] == "Sucessful.")
		{
		}
		else
		{		
		stTr = strtran.split("~")
		stmsg = stTr[0]
		}
		
		if(strtran!="")
		{
			if(strfilename[0]=="Sucessful.")
			{
			alert("Customer Cheque File Generated Successfully")
				window.location.href="frmCheqRestGen.aspx"
			}
			else if (stmsg=="Transaction Sucessful.")
			{
				
				stbc = stTr[1].split("#")
				stlen = stbc.length
				
				if(stlen == "1")
				{
					stb = stbc[0]
					stc = ""
				}
				if(stlen == "2")
				{
					stb = stbc[0]
					stc1 = stbc[1].split("|")
					stc = stc1[0]
				}
				
				window.document.frmCheqAscii.hidBrcd.value = stb
				window.document.frmCheqAscii.hidChbr.value = stc
			
				var br,stActyp
				
				br = "" 
				stActyp = ""
				
				if (stb!="")
				{
					br = stb
				}
				else
				{
					br = " "
				}
				if(stc!="")
				{
					stActyp = stc
				}
				else
				{
					stActyp = ""
				}
					
					strVal = "FILEGEN"+"|"+br+"|"+stActyp
					
					window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
			}
			else
			{
				alert("No Records Found")
				window.location.href="frmCheqRestGen.aspx" 
			}
		}
	}
	
	
	if ((strfilename[1] == "BCGEN") || (strfilename[1] == "BCGENYNSTAT"))
		{
		if (strfilename[0] == "Sucessful.")
		{
		}
		else
		{		
		stTr = strtran.split("~")
		stmsg = stTr[0]
		}
		if(strtran!="")
		{
			if(strfilename[0]=="Sucessful.")
			{
			alert("Bankers Cheque File Generated Successfully")
				window.location.href="frmCheqRestGen.aspx"
			}
			else if (stmsg=="Transaction Sucessful.")
			{
				
				stbc = stTr[1].split("#")
				stlen = stbc.length
				
				if(stlen == "1")
				{
					stb1 = stbc[0].split("|")
					stb = stb1[0]
					stc = ""
				}
				if(stlen == "2")
				{
					stb = stbc[0]
					stc1 = stbc[1].split("|")
					stc = stc1[0]
				}
				
				window.document.frmCheqAscii.hidBrcd.value = stb
				window.document.frmCheqAscii.hidChbr.value = stc
			
				var br,stActyp
				
				br = "" 
				stActyp = ""
				
				if (stb!="")
				{
					br = stb
				}
				else
				{
					br = " "
				}
				if(stc!="")
				{
					stActyp = stc
				}
				else
				{
					stActyp = ""
				}
					
					strVal = "BCFILEGEN"+"|"+br+"|"+stActyp
					
					window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
			}
			else
			{
				alert("No Records Found")
				window.location.href="frmCheqRestGen.aspx" 
			}
		}
		
		}
	
			
	}
	
	
	function popBCFilRep(str)
	{
		if(str=="")
		{
			alert("No records found to Generate file")
			return;
		}
		
		var strResult=str.split("|")
		
		var time = new Date();
		
		var month = new Array();
		month[0] = "Jan";
		month[1] = "Feb";
		month[2] = "Mar";
		month[3] = "Apr";
		month[4] = "May";
		month[5] = "Jun";
		month[6] = "Jul";
		month[7] = "Aug";
		month[8] = "Sep";
		month[9] = "Oct";
		month[10] = "Nov";
		month[11] = "Dec";

		var D = time.getDate();
		var M = month[time.getMonth()];
		var Y = time.getFullYear();
		var hh = time.getHours();
		var mm = time.getMinutes();
		var ss = time.getSeconds();
		
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		filepath="BCASCII"+D+"-"+M+"-"+Y+" "+hh+"-"+mm+"-"+ss
		
		if (! fso.FolderExists("C://BCRequest") )
		fso.CreateFolder("C://BCRequest")
		
		var fh = fso.CreateTextFile("c://"+ "BCRequest/"+filepath+".asc" , true); 
		var�strTemp=""
		
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			strTemp=strResult[aCnt]
			fh.WriteLine(strTemp)
			strTemp=""
		}
		fh.Close();
		alert("c://"+ "BCRequest/"+filepath+".asc: Bankers Cheque File Created")
		
		br = window.document.frmCheqAscii.hidBrcd.value
		stActyp = window.document.frmCheqAscii.hidChbr.value
		
		strVal = "BCGENYNSTAT"+"~"+br+"~"+stActyp+"~"+stBr
		
		window.document.frmCheqAscii.mercust.value=strVal
		window.document.frmCheqAscii.action="CheqReqGen.aspx"
		window.document.frmCheqAscii.method="post"   
		window.document.frmCheqAscii.submit()
		
	}
	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display();DispTranMsg();">
	<form name="frmCheqAscii">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>Cheque ASCII Generation</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
				<tr>
				<td colspan=2>
				
				<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
              <tr class="bgcolor1">
                <td width="23%" align="middle">
                <p align="center"><font class="textblack"><input type="radio" name="rdmode" onclick="GetMode()" checked>
                Customer Cheque</font></p>
                </td>
                <td width="26%" align="middle">
                <p align="center"><font class="textblack"><input type="radio" name="rdmode"  onclick="GetMode()">
                BC Issue(Banker Cheque)</font></p>
                </td>
              </tr>
            </table>

				
				</td>
				</tr>
					<tr>
						<td width="100%" height="20" colspan="2">
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr class="BGCOLOR">
									<td width="12%" align="right">Branch Code&nbsp;&nbsp;</font></td>
									<td width="38%">&nbsp;<input name="txtbranchcode" size="9" readonly class="txtautofill" value="<%=session("branchcode")%>" maxlength="4" style="TEXT-ALIGN: right"><input type="button" value=" L " name="cmdbranch" onclick="branch()" style="height: 22; width: 22" class="button"><input name="txtbranchdesc" size="16" readonly class="bgcolor1" value="<%=session("branchnarration")%>"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;All Branches<input type="checkbox" name="chkAllbr" ></td>
									
								</tr>
							</table>
							
							<table width="100%" cellspacing="0" cellpadding="0" border="0" >
								<tr class="bgcolor1">
									<td width="24%" align="right">A/C Type&nbsp;&nbsp;</font></td>
									<td width="10%">&nbsp;<select name="selAcType">
																<option value="ALL" selected >All</option>
																<option value="10">SB</option>
																<option value="11">CA</option>
																<option value="13">CC</option>
																</select></td></td>
									<td width="15%" align="right"><!--Select Folder&nbsp;&nbsp;</font>--></td>
									<td width="55%"><!--<input type="text" name="txtFolderpath" size="10"size="16" readonly value=""><input type="button" name="butFolder" size="10"size="16" value=" Browse ">--></td>
								</tr>
							</table>
						</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center"><input name="cmdOk" onclick="Ok()" type="button" value=" Generate " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmCheqRestGen.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
					
					
					
				</table>
			</div>
			</td>
		</tr>
	</table>
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>
