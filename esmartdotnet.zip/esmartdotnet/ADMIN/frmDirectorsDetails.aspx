<%@ Page Language="vb" AutoEventWireup="false" aspcompat="true" explicit="false" Codebehind="frmDirectorsDetails.aspx.vb" Inherits="eSmartDotNet.frmDirectorsDetails"%>
<%
 Dim objhotraw As New GENVALIDATIONS.Validations
 dim strMainBrCode 
''strMainBrCode = "101"
'' modified by dattu 24-nov-22
        '' HO Trans Allowed
        strMainBrcode = objhotraw.GetHOTRALWBrCode()
dim strSql
dim rsAuto, objAuto
    rsAuto=Server.CreateObject("ADODB.Recordset")
objAuto=server.CreateObject("ReportPurposeOnly.Reportonly")

strSql="select nvl(max(dircode),0) +1  from GENDIRECTORDTLS"
rsAuto=objAuto.SingleSelectStat(strSql)
if objAuto.ConnError="Connected" then
	if not rsAuto.bof and not rsAuto.eof then
		strdircode=iif(isdbnull(rsAuto(0).value),"",rsAuto(0).value)
		
	end if
end if
rsAuto =  nothing
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>Director Details</title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	
	<SCRIPT LANGUAGE=javascript>
	var userid="'"+'<%=session("userid")%>'+"'"
	var macid="'"+'<%=session("machineid")%>'+"'"
	function DispTranMsg()
	{
	window.document.frmEmpMast.txtDirectorID.value = "<%=strdircode%>"
	window.document.frmEmpMast.txtElectionDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtJoinDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTermEffDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTermDueDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTerminateDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtFromDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtToDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTerminateDate.disabled = true
window.document.frmEmpMast.txtReason.disabled = true

window.document.frmEmpMast.cmbcomtype.disabled = true
	window.document.frmEmpMast.txtFromDate.disabled = true
	window.document.frmEmpMast.txtToDate.disabled = true
	window.document.frmEmpMast.cmdcommemdtlssok.disabled = true
	window.document.frmEmpMast.msflexcommmem.disabled = true
	
	window.document.frmEmpMast.cmbfammemrelid.disabled = true
window.document.frmEmpMast.txtfammemname.disabled = true
window.document.frmEmpMast.cmbfammemprofid.disabled = true
window.document.frmEmpMast.txtfammemcustid.disabled = true
window.document.frmEmpMast.cmdcustlstj.disabled = true
window.document.frmEmpMast.txtfammemcustname.disabled = true

window.document.frmEmpMast.txtfammempanno.disabled = true
window.document.frmEmpMast.txtfammemmobile.disabled = true
window.document.frmEmpMast.cmdfammemdtlsok.disabled = true
window.document.frmEmpMast.msflexfammemdtls.disabled = true
	}
	
function resultmessage()
{

message="<%=Request.QueryString("record")%>"
	if(message!="")
	{
		alert(message)
		location.href="frmDirectorsDetails.aspx"
	}
}

//'''''''''''''Displaying the Division 
function showdiv(strdiv)
{

if(strdiv=="commemdtls")
	{
	window.document.all.divcommmem.style.display="block"
	
	}
	else
	{
	window.document.all.divcommmem.style.display="none"
	
	}
	
	if(strdiv=="fammemdtls")
	{
	window.document.all.divfammemdtls.style.display="block"
	
	}
	else
	{
	window.document.all.divfammemdtls.style.display="none"
	
	}
	
	if(strdiv=="creditaccdtls")
	{
	window.document.all.divCrAccDtls.style.display="block"
	
	}
	else
	{
	window.document.all.divCrAccDtls.style.display="none"
	
	}
}


	var custid=""
function Customer(MyStr)
{ 
  custid=MyStr
  var std
 //alert("<%=strMainBrCode%>")
	std="ch~"+ "<%=strMainBrCode%>"
	window.showModalDialog('<%="http://" & session("moduledir")%>'+ "/GEN/custlist.aspx" + 
		"?"+"strbut="+std,window,"status:no;"+
		"DialogWidth:490px;DialogHeight:240px;DialogLeft:320px;DialogTop:210px")
}

function getcustid(MyStr)
{ 
	if(MyStr=="No Data Found....")
		return
	var st
	
	st=MyStr.split("~")
	
		if(custid=="0")
		{  
	
		window.document.frmEmpMast.txtCustname.value=st[2]
		window.document.frmEmpMast.txtCustid.value=st[1]
		window.document.frmEmpMast.txtDirectorName.value=st[2]
		}
		if(custid=="2")
	{
		
		window.document.frmEmpMast.txtfammemcustname.value=st[2]
		window.document.frmEmpMast.txtfammemcustid.value=st[1]
	}
}

 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
		/*	var intDiff=getDateDiff(window.document.frmEmpMast.txtElectionDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtElectionDate.value=""
				window.document.frmEmpMast.txtElectionDate.focus()
			}
			*/
		/*	var intDiff1=getDateDiff(window.document.frmEmpMast.txtJoinDate.value, "<%=session("applicationdate")%>")
			
			if(intDiff1>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtJoinDate.value=""
				window.document.frmEmpMast.txtJoinDate.focus()
			}
			*/
			var intDiffelec=getDateDiff(window.document.frmEmpMast.txtElectionDate.value,window.document.frmEmpMast.txtJoinDate.value)
			//alert("intDiffelec :" + intDiffelec)
			if (intDiffelec>0)
			{
			alert("Join Date Should  Be Greater Than Election Date.")
				window.document.frmEmpMast.txtJoinDate.value=""
				window.document.frmEmpMast.txtJoinDate.focus()
			}
			
			var intDiff3=getDateDiff(window.document.frmEmpMast.txtTermDueDate.value,window.document.frmEmpMast.txtToDate.value)
			
			if(intDiff3<0)
			{
				alert("Committe To Date Should be Less Than Term Due Date.")
				window.document.frmEmpMast.txtToDate.value=""
				window.document.frmEmpMast.txtToDate.focus()
			}
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}

function changeMonthnum(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="0"
			else if(str=="FEB")
				strMonth="1"
			else if(str=="MAR")
				strMonth="2"
			else if(str=="APR")
				strMonth="3"
			else if(str=="MAY")
				strMonth="4"
			else if(str=="JUN")
				strMonth="5"
			else if(str=="JUL")
				strMonth="6"
			else if(str=="AUG")
				strMonth="7"
			else if(str=="SEP")
				strMonth="8"
			else if(str=="OCT")
				strMonth="9"
			else if(str=="NOV")
				strMonth="10"
			else if(str=="DEC")
				strMonth="11"
			
			return strMonth;
		}
		
function GetTermDueDate()
{

if ((window.document.frmEmpMast.txtTermPeriod.value == "") || (window.document.frmEmpMast.txtTermPeriod.value == "0"))
{
alert("Enter Term Period")
return
}

strVal="SETTERMDUEDATE"+"|"+window.document.frmEmpMast.txtTermPeriod.value+"|"+window.document.frmEmpMast.txtTermEffDate.value+"|"+""
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		
}		

function GETTERMDUEDATE(str)
{
window.document.frmEmpMast.txtTermDueDate.value = str
}

///''''' Filling committe type flex grid
function commemdtlsflxgrd(){
var strboolean
var introwcnt
strboolean="true"

var comtype= window.document.frmEmpMast.cmbcomtype.options[window.document.frmEmpMast.cmbcomtype.selectedIndex].value

if(comtype=="Select")
{
	alert("Please Select Committe Type")
	return;
}
//alert(window.document.frmEmpMast.hidcomtype.value)
if(window.document.frmEmpMast.hidcomtype.value.length<1)
{
	for(introwcnt=1;introwcnt<eval(window.document.frmEmpMast.msflexcommmem.Rows);introwcnt++)
	{
		if(window.document.frmEmpMast.msflexcommmem.TextMatrix(introwcnt,1)==
		window.document.frmEmpMast.cmbcomtype.value)
		{
		strboolean="false"
		}
	}
	if(strboolean=="true")
	{
		if((window.document.frmEmpMast.cmbcomtype.value).length>0)
		{ 
			window.document.frmEmpMast.msflexcommmem.Rows=
			eval(window.document.frmEmpMast.msflexcommmem.Rows)+1
			
			window.document.frmEmpMast.msflexcommmem.TextMatrix(
			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1,0)=
			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1
			
			window.document.frmEmpMast.msflexcommmem.TextMatrix(
			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1,1)=
			window.document.frmEmpMast.cmbcomtype.value
			
			window.document.frmEmpMast.msflexcommmem.TextMatrix(
			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1,2)=
			window.document.frmEmpMast.txtFromDate.value  
			
			window.document.frmEmpMast.msflexcommmem.TextMatrix(
			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1,3)=window.document.frmEmpMast.txtToDate.value
			
			
			window.document.frmEmpMast.cmbcomtype.selectedIndex = 0
	    
	        window.document.frmEmpMast.cmbcomtype.options[0].selected=true
		}
	}
	else
	{
	alert("Committe Member allready entered")
	window.document.frmEmpMast.cmbcomtype.value=""
	
	window.document.frmEmpMast.cmbcomtype.options[0].selected=true
	}
}
else
{
var intsno
intsno=window.document.frmEmpMast.hidcomtype.value 

window.document.frmEmpMast.msflexcommmem.TextMatrix(intsno,0) = intsno
window.document.frmEmpMast.msflexcommmem.TextMatrix(intsno,1)=
	window.document.frmEmpMast.cmbcomtype.value
window.document.frmEmpMast.msflexcommmem.TextMatrix(intsno,2)=
	window.document.frmEmpMast.txtFromDate.value   
window.document.frmEmpMast.msflexcommmem.TextMatrix(intsno,3)=
	window.document.frmEmpMast.txtToDate.value  
window.document.frmEmpMast.hidcomtype.value=""
window.document.frmEmpMast.cmbcomtype.selectedIndex =0
window.document.frmEmpMast.txtFromDate.value=""
window.document.frmEmpMast.txtToDate.value = ""
}	

//first column make it as sno
for(introwcnt=1;introwcnt<eval(window.document.frmEmpMast.msflexcommmem.Rows);introwcnt++)
	{
		window.document.frmEmpMast.msflexcommmem.TextMatrix(introwcnt,0)= introwcnt
		
	} 
}

function msflexcommmem_DblClick() 
{
	var row=window.document.frmEmpMast.msflexcommmem.row
	
	window.document.frmEmpMast.hidcomtype.value= row
		
	window.document.frmEmpMast.cmbcomtype.value=
		window.document.frmEmpMast.msflexcommmem.TextMatrix(row,1)
	window.document.frmEmpMast.txtFromDate.value=
		window.document.frmEmpMast.msflexcommmem.TextMatrix(row,2)
	window.document.frmEmpMast.txtToDate.value=
		window.document.frmEmpMast.msflexcommmem.TextMatrix(row,3)
			
}

///////// To cancel the selected committe member
function commemdtlsCancel()
{

var introw,stryesno
var intcol=window.document.frmEmpMast.msflexcommmem.Cols 
introw=window.document.frmEmpMast.msflexcommmem.Row

if(window.document.frmEmpMast.cmbcomtype.value=="" || window.document.frmEmpMast.cmbcomtype.value=="Select")
	return
introw=window.document.frmEmpMast.msflexcommmem.Row
if(window.document.frmEmpMast.hidcomtype.value=="")
	return


window.document.frmEmpMast.hidcomtype.value=""
if(window.document.frmEmpMast.msflexcommmem.Rows>1)
	{

	   {
		stryesno=confirm("Do You Want To Cancel : "+ 
			window.document.frmEmpMast.msflexcommmem.TextMatrix(introw,1)+" committe member type")
		if(stryesno==true)
			{
			introw=introw
			window.document.frmEmpMast.cmbcomtype.value=""
			//window.document.frmEmpMast.txtFromDate.value=""
			//window.document.frmEmpMast.txtToDate.value=""
			}
		else
			{
			return
			}
	  }
	
       {
        if(introw==eval(window.document.frmEmpMast.msflexcommmem.Rows)-1)
			{
			window.document.frmEmpMast.msflexcommmem.Rows=
				eval(window.document.frmEmpMast.msflexcommmem.Rows)-1
			}
	   	else 
	   	    {
	   	      {
	   			for(var intfill=introw;intfill<
	   				eval(window.document.frmEmpMast.msflexcommmem.Rows)-1;intfill++)
	   			{
	   			  for(var intcolfill=1;intcolfill<intcol;intcolfill++)
	   			  {
	   			  window.document.frmEmpMast.msflexcommmem.TextMatrix(intfill,intcolfill)=
	   				window.document.frmEmpMast.msflexcommmem.TextMatrix(eval(intfill)+1,intcolfill)
	   			  }
	   			} 
	   			}	
	   		  {
	   	      window.document.frmEmpMast.msflexcommmem.Rows=
	   			eval(window.document.frmEmpMast.msflexcommmem.Rows)-1
	   	      }
	   	    }   
       }
	}
}





///''''' Filling family member  flex grid
function fammemdtlsflxgrd(){
var strboolean
var introwcnt
strboolean="true"

var memrelid= window.document.frmEmpMast.cmbfammemrelid.options[window.document.frmEmpMast.cmbfammemrelid.selectedIndex].value

if(memrelid=="Select")
{
	alert("Please Select Relation ID")
	return;
}


if(window.document.frmEmpMast.hidfammemname.value.length<1)
{
	for(introwcnt=1;introwcnt<eval(window.document.frmEmpMast.msflexfammemdtls.Rows);introwcnt++)
	{
		if(window.document.frmEmpMast.msflexfammemdtls.TextMatrix(introwcnt,2)==
		window.document.frmEmpMast.txtfammemname.value)
		{
		strboolean="false"
		}
	}
	if(strboolean=="true")
	{
	"<Sno      |<Relation                             |<Name                                           |<Profession ID                    |< Customer No             |<PAnno                  |<MobileNo                   "
		if((window.document.frmEmpMast.cmbfammemrelid.value).length>0)
		{ 
			window.document.frmEmpMast.msflexfammemdtls.Rows=
			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)+1
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(
			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,0)=
			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(
			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,1)=
			window.document.frmEmpMast.cmbfammemrelid.value
			
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(
			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,2)=
			window.document.frmEmpMast.txtfammemname.value  
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(		eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,3)=window.document.frmEmpMast.cmbfammemprofid.value
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(		eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,4)=window.document.frmEmpMast.txtfammemcustid.value
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(		eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,5)=window.document.frmEmpMast.txtfammempanno.value
			
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(		eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1,6)=window.document.frmEmpMast.txtfammemmobile.value
			
			window.document.frmEmpMast.cmbfammemrelid.value=""
	        window.document.frmEmpMast.cmbfammemrelid.options[0].selected=true
	        window.document.frmEmpMast.txtfammemname.value  = ""
	        window.document.frmEmpMast.cmbfammemprofid.value=""
	        window.document.frmEmpMast.cmbfammemprofid.options[0].selected=true
	        window.document.frmEmpMast.txtfammemcustid.value = ""
	        window.document.frmEmpMast.txtfammemcustname.value = ""
	        window.document.frmEmpMast.txtfammempanno.value = ""
	        window.document.frmEmpMast.txtfammemmobile.value = ""
	        
		}
	}
	else
	{
	alert("Name Already Entered")
	window.document.frmEmpMast.cmbfammemrelid.value=""
	window.document.frmEmpMast.cmbfammemrelid.options[0].selected=true
	        window.document.frmEmpMast.txtfammemname.value  = ""
	        window.document.frmEmpMast.cmbfammemprofid.value=""
	        window.document.frmEmpMast.cmbfammemprofid.options[0].selected=true
	        window.document.frmEmpMast.txtfammemcustid.value = ""
	        window.document.frmEmpMast.txtfammemcustname.value = ""
	        window.document.frmEmpMast.txtfammempanno.value = ""
	        window.document.frmEmpMast.txtfammemmobile.value = ""
	}
}
else
{
var intsno
intsno=window.document.frmEmpMast.hidfammemname.value 
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,1)= intsno
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,1)= window.document.frmEmpMast.cmbfammemrelid.value
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,2)= window.document.frmEmpMast.txtfammemname.value   
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,3)= window.document.frmEmpMast.cmbfammemprofid.value 
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,4)= window.document.frmEmpMast.txtfammemcustid.value
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,5)= window.document.frmEmpMast.txtfammempanno.value
window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intsno,6)= window.document.frmEmpMast.txtfammemmobile.value
window.document.frmEmpMast.hidfammemname.value=""
window.document.frmEmpMast.cmbfammemrelid.value=""
window.document.frmEmpMast.txtfammemname.value=""
window.document.frmEmpMast.cmbfammemprofid.value=""
window.document.frmEmpMast.txtfammemcustid.value=""
window.document.frmEmpMast.txtfammempanno.value=""
window.document.frmEmpMast.txtfammemmobile.value=""
}
//first column make it as sno
for(introwcnt=1;introwcnt<eval(window.document.frmEmpMast.msflexfammemdtls.Rows);introwcnt++)
	{
		window.document.frmEmpMast.msflexfammemdtls.TextMatrix(introwcnt,0)= introwcnt
	} 
}

function msflexfammemdtls_DblClick() 
{

	var row=window.document.frmEmpMast.msflexfammemdtls.row
	
//	window.document.frmEmpMast.hidfammemname.value=	window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,0)
	window.document.frmEmpMast.hidfammemname.value = row
	window.document.frmEmpMast.cmbfammemrelid.value=window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,1)
	window.document.frmEmpMast.txtfammemname.value=	window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,2)
	window.document.frmEmpMast.cmbfammemprofid.value=window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,3)
	window.document.frmEmpMast.txtfammemcustid.value=window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,4)
	window.document.frmEmpMast.txtfammempanno.value=window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,5)
	window.document.frmEmpMast.txtfammemmobile.value=window.document.frmEmpMast.msflexfammemdtls.TextMatrix(row,6)
	
}

///////// To cancel the selected committe member
function fammemdtlsCancel()
{

var introw,stryesno
var intcol=window.document.frmEmpMast.msflexfammemdtls.Cols 
introw=window.document.frmEmpMast.msflexfammemdtls.Row

if(window.document.frmEmpMast.cmbfammemrelid.value=="")
	return
introw=window.document.frmEmpMast.msflexfammemdtls.Row
if(window.document.frmEmpMast.hidfammemname.value=="")
	return


window.document.frmEmpMast.hidfammemname.value=""
if(window.document.frmEmpMast.msflexfammemdtls.Rows>1)
	{

	   {
		stryesno=confirm("Do You Want To Cancel : "+ 
			window.document.frmEmpMast.msflexfammemdtls.TextMatrix(introw,1)+" Family member")
		if(stryesno==true)
			{
			introw=introw
			window.document.frmEmpMast.cmbfammemrelid.value=""
			window.document.frmEmpMast.txtfammemname.value=""
			window.document.frmEmpMast.cmbfammemprofid.value=""
			window.document.frmEmpMast.txtfammemcustid.value=""
			window.document.frmEmpMast.txtfammempanno.value=""
			window.document.frmEmpMast.txtfammemmobile.value=""
			}
		else
			{
			return
			}
	  }
	
       {
        if(introw==eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1)
			{
			window.document.frmEmpMast.msflexfammemdtls.Rows=
				eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1
			}
	   	else 
	   	    {
	   	      {
	   			for(var intfill=introw;intfill<
	   				eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1;intfill++)
	   			{
	   			  for(var intcolfill=1;intcolfill<intcol;intcolfill++)
	   			  {
	   			  window.document.frmEmpMast.msflexfammemdtls.TextMatrix(intfill,intcolfill)=
	   				window.document.frmEmpMast.msflexfammemdtls.TextMatrix(eval(intfill)+1,intcolfill)
	   			  }
	   			} 
	   			}	
	   		  {
	   	      window.document.frmEmpMast.msflexfammemdtls.Rows=
	   			eval(window.document.frmEmpMast.msflexfammemdtls.Rows)-1
	   	      }
	   	    }   
       }
	}
}

 function paymode()
 {
 
 window.document.frmEmpMast.txtAccno.value=""
 window.document.frmEmpMast.txtCrAccName.value=""
 window.document.frmEmpMast.txtIFSCCode.value=""
  var input = document.getElementById("txtAccno");
          
            
 	if (window.document.frmEmpMast.cmbpaymode.value == 'T')
	{
	  input.maxLength = 16;
	}
	else
	{
	input.maxLength = 25;
	}
 }

function Ok()
{

var strmode
if(window.document.frmEmpMast.opt1(0).checked==true)
	{
		strmode="NEW"
		
		
	}
	else if(window.document.frmEmpMast.opt1(1).checked==true)
	{
		strmode="MODIFY"
		
	}
	else if(window.document.frmEmpMast.opt1(2).checked==true)
	{
		strmode="DELETE"  
		
	}
	else
	{
		return
	}
if ((window.document.frmEmpMast.opt1(0).checked==true) || (window.document.frmEmpMast.opt1(1).checked==true))
{
	
	if (window.document.frmEmpMast.txtDirectorID.value == "")
	{
	alert("Enter Director ID")
	return
	}

	/*if (window.document.frmEmpMast.txtCustid.value == "")
	{
	alert("Enter Customer ID")
	return
	}*/
	
	if (window.document.frmEmpMast.txtDirectorName.value == "")
	{
	alert("Enter Director Name")
	return
	}
	

    if (window.document.frmEmpMast.txtQualification.value == "")
	{
	alert("Enter Qualification")
	return
	}
	
if (window.document.frmEmpMast.cmbBOD.value == "Y")
	{
		if (window.document.frmEmpMast.cmbBODDesig.value == "NONE")
		{
		alert("Enter BOD Designation")
		window.document.frmEmpMast.cmbBODDesig.focus();
		return
		}
	}
	else
	{
		if (window.document.frmEmpMast.cmbBODDesig.value != "NONE")
		{
		
		window.document.frmEmpMast.cmbBODDesig.value = "NONE"
		return
		}
	}
	
	if (window.document.frmEmpMast.cmbBOM.value == "Y")
	{
		if (window.document.frmEmpMast.cmbBOMDesig.value == "NONE")
		{
		alert("Enter BOM Designation")
		return
		}
	}
	else
	{
		if (window.document.frmEmpMast.cmbBOMDesig.value != "NONE")
		{
		
		window.document.frmEmpMast.cmbBOMDesig.value = "NONE"
		return
		}
	}
	
	
/*	
	if (window.document.frmEmpMast.cmbRelationYN.value == "Select")
	{
	alert("Enter Relation YN")
	return
	}*/
		
	if (window.document.frmEmpMast.txtElectionDate.value == "")
	{
	alert("Enter Election Date")
	return
	}
	
	if (window.document.frmEmpMast.txtJoinDate.value == "")
	{
	alert("Enter Join Date")
	return
	}
	
	if (window.document.frmEmpMast.txtTermPeriod.value == "")
	{
	alert("Enter Term Period")
	return
	}
	if (window.document.frmEmpMast.txtTermEffDate.value == "")
	{
	alert("Enter Term Effective Date")
	return
	}
	if (window.document.frmEmpMast.txtTermDueDate.value == "")
	{
	alert("Enter Term Due Date")
	return
	}
	

/*	if (window.document.frmEmpMast.cmbCommMemYN.value == "Select")
	{
	alert("Enter Committee Member YN")
	return
	}
	if (window.document.frmEmpMast.cmbSittingFees.value == "Select")
	{
	alert("Enter Sitting Fees")
	return
	}
	*/
	if (window.document.frmEmpMast.txtBOMSalary.value == "")
	{
	alert("Enter BOM Salary")
	return
	}
/*	if (window.document.frmEmpMast.cmbTDSYN.value == "Select")
	{
	alert("Enter TDS YN")
	return
	}
	
	
	if (window.document.frmEmpMast.cmbpaymode.value == "Select")
	{
	alert("Select Pay Mode")
	return
	}
	*/
	if (window.document.frmEmpMast.txtAccno.value == "")
	{
	alert("Enter Acc No")
	return
	}
	if (window.document.frmEmpMast.txtCrAccName.value == "")
	{
	alert("Enter Credit Acc Name")
	return
	}
	
	if (window.document.frmEmpMast.cmbpaymode.value == 'T')
	{
	
	}
	else
	{
		if (window.document.frmEmpMast.txtIFSCCode.value == "")
		{
		alert("Enter IFSC Code")
		return
		}
	}
}
if (window.document.frmEmpMast.opt1(2).checked==true)
{
if (window.document.frmEmpMast.txtTerminateDate.value == "")
	{
	alert("Enter Terminate Date")
	return
	}
	if (window.document.frmEmpMast.txtReason.value == "")
	{
	alert("Enter Terminate Reason")
	return
	}
}

window.document.frmEmpMast.hdnDirectorID.value = window.document.frmEmpMast.txtDirectorID.value
window.document.frmEmpMast.hdnCustid.value = window.document.frmEmpMast.txtCustid.value
window.document.frmEmpMast.hdnDirectorName.value = window.document.frmEmpMast.txtDirectorName.value
window.document.frmEmpMast.hdnQualification.value = window.document.frmEmpMast.txtQualification.value
window.document.frmEmpMast.hdnBOD.value = window.document.frmEmpMast.cmbBOD.value
window.document.frmEmpMast.hdnBODDesig.value = window.document.frmEmpMast.cmbBODDesig.value
window.document.frmEmpMast.hdnBOM.value = window.document.frmEmpMast.cmbBOM.value
window.document.frmEmpMast.hdnBOMDesig.value = window.document.frmEmpMast.cmbBOMDesig.value
window.document.frmEmpMast.hdnElectionDate.value = window.document.frmEmpMast.txtElectionDate.value
window.document.frmEmpMast.hdnJoinDate.value = window.document.frmEmpMast.txtJoinDate.value
window.document.frmEmpMast.hdnTermPeriod.value = window.document.frmEmpMast.txtTermPeriod.value
window.document.frmEmpMast.hdnTermEffDate.value = window.document.frmEmpMast.txtTermEffDate.value
window.document.frmEmpMast.hdnTermDueDate.value = window.document.frmEmpMast.txtTermDueDate.value
window.document.frmEmpMast.hdnCommMemYN.value = window.document.frmEmpMast.cmbCommMemYN.value
window.document.frmEmpMast.hdnSittingFees.value = window.document.frmEmpMast.cmbSittingFees.value
window.document.frmEmpMast.hdnBOMSalary.value = window.document.frmEmpMast.txtBOMSalary.value
window.document.frmEmpMast.hdnTDSYN.value = window.document.frmEmpMast.cmbTDSYN.value
window.document.frmEmpMast.hdnTerminateDate.value = window.document.frmEmpMast.txtTerminateDate.value
window.document.frmEmpMast.hdnReason.value = window.document.frmEmpMast.txtReason.value
window.document.frmEmpMast.hdnRelationYN.value = window.document.frmEmpMast.cmbRelationYN.value
window.document.frmEmpMast.hdnpaymode.value = window.document.frmEmpMast.cmbpaymode.value
window.document.frmEmpMast.hdnAccno.value = window.document.frmEmpMast.txtAccno.value
window.document.frmEmpMast.hdnCrAccName.value = window.document.frmEmpMast.txtCrAccName.value
window.document.frmEmpMast.hdnIFSCCode.value = window.document.frmEmpMast.txtIFSCCode.value

// committee member details
var commemval
var commemval1
commemval = ""
commemval1 = ""
var rows1= window.document.frmEmpMast.msflexcommmem.Rows

	if(rows1>1)
	{
	
	for(icnt=1;icnt<rows1;icnt++)
		{
		
			 commemval1=window.document.frmEmpMast.txtDirectorID.value +"," + window.document.frmEmpMast.msflexcommmem.TextMatrix(icnt,0) +",'"+ window.document.frmEmpMast.msflexcommmem.TextMatrix(icnt,1) +"',"+" to_date('"+window.document.frmEmpMast.msflexcommmem.TextMatrix(icnt,2)+"','dd-MM-yyyy') " + ","+ " to_date('"+window.document.frmEmpMast.msflexcommmem.TextMatrix(icnt,3)+"','dd-MM-yyyy') "
			  
				
			 commemval=commemval+"|"+commemval1
		}
		commemval=commemval.substr(1)
	}
	

// family member details
var fammemval=""
var fammemval1 = ""
	var rows=window.document.frmEmpMast.msflexfammemdtls.Rows
	if(rows>1)
	{
		for(icnt=1;icnt<rows;icnt++)
		{
			 fammemval1= window.document.frmEmpMast.txtDirectorID.value +","+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,0)+","+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,1)+",'"+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,2) +"','"+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,3)+"','"+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,4) +"','"+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,5) +"','"+window.document.frmEmpMast.msflexfammemdtls.TextMatrix(icnt,6) +"',"+ userid +","+ macid +",sysdate"			
					
			 fammemval=fammemval+"|"+fammemval1
		}
		
		fammemval=fammemval.substr(1)
		
	}
	
	resmaxamt1 = confirm("Do You Want To Post Director Details ?  Do you want to continue..")
				if (resmaxamt1 == true)
				{}
				else
				{
				
				return
				}

	window.document.frmEmpMast.hdncommemval.value=commemval
		
	
		window.document.frmEmpMast.hdnfammemval.value=fammemval
			
		window.document.frmEmpMast.hidmode.value=strmode
		
		window.document.frmEmpMast.method="post"
		window.document.frmEmpMast.action="frmDirectorDtlsInsert.aspx"
		window.document.frmEmpMast.submit()

}

function SetRelation()
{
if (window.document.frmEmpMast.cmbRelationYN.value == 'Y')
{
window.document.frmEmpMast.cmbfammemrelid.disabled = false
window.document.frmEmpMast.txtfammemname.disabled = false
window.document.frmEmpMast.cmbfammemprofid.disabled = false
window.document.frmEmpMast.txtfammemcustid.disabled = false
window.document.frmEmpMast.cmdcustlstj.disabled = false
window.document.frmEmpMast.txtfammemcustname.disabled = false

window.document.frmEmpMast.txtfammempanno.disabled = false
window.document.frmEmpMast.txtfammemmobile.disabled = false
window.document.frmEmpMast.cmdfammemdtlsok.disabled = false
window.document.frmEmpMast.msflexfammemdtls.disabled = false
}
else
{
window.document.frmEmpMast.cmbfammemrelid.disabled = true
window.document.frmEmpMast.txtfammemname.disabled = true
window.document.frmEmpMast.cmbfammemprofid.disabled = true
window.document.frmEmpMast.txtfammemcustid.disabled = true
window.document.frmEmpMast.cmdcustlstj.disabled = true
window.document.frmEmpMast.txtfammemcustname.disabled = true

window.document.frmEmpMast.txtfammempanno.disabled = true
window.document.frmEmpMast.txtfammemmobile.disabled = true
window.document.frmEmpMast.cmdfammemdtlsok.disabled = true
window.document.frmEmpMast.msflexfammemdtls.disabled = true
}
}

function setCommitteeMem()
{
	if (window.document.frmEmpMast.cmbCommMemYN.value == 'Y')
	{
	window.document.frmEmpMast.cmbcomtype.disabled = false
	window.document.frmEmpMast.txtFromDate.disabled = false
	window.document.frmEmpMast.txtToDate.disabled = false
	window.document.frmEmpMast.cmdcommemdtlssok.disabled = false
	window.document.frmEmpMast.msflexcommmem.disabled = false
	}
	else
	{
	window.document.frmEmpMast.cmbcomtype.disabled = true
	window.document.frmEmpMast.txtFromDate.disabled = true
	window.document.frmEmpMast.txtToDate.disabled = true
	window.document.frmEmpMast.cmdcommemdtlssok.disabled = true
	window.document.frmEmpMast.msflexcommmem.disabled = true
	}
}

function setSittingFees()
{
if (window.document.frmEmpMast.cmbSittingFees.value == 'Y')
	{
	window.document.frmEmpMast.txtBOMSalary.disabled = true
	window.document.frmEmpMast.txtBOMSalary.value =0
	}
	else
	{
	window.document.frmEmpMast.txtBOMSalary.disabled = false
	window.document.frmEmpMast.txtBOMSalary.value =""
	}
}

function New()
{

window.document.frmEmpMast.txtCustid.value = ""
window.document.frmEmpMast.txtCustname.value = ""
window.document.frmEmpMast.txtDirectorName.value = ""
window.document.frmEmpMast.txtQualification.value = ""
window.document.frmEmpMast.cmbBOD.value = ""
window.document.frmEmpMast.cmbBODDesig.value = ""
window.document.frmEmpMast.cmbBOM.value = ""
window.document.frmEmpMast.cmbBOMDesig.value = ""
window.document.frmEmpMast.txtElectionDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtJoinDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTermPeriod.value = ""
window.document.frmEmpMast.txtTermEffDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtTermDueDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.cmbCommMemYN.value = ""
window.document.frmEmpMast.cmbSittingFees.value = ""
window.document.frmEmpMast.txtBOMSalary.value = ""
window.document.frmEmpMast.cmbTDSYN.value = ""
window.document.frmEmpMast.txtTerminateDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtReason.value = ""

window.document.frmEmpMast.cmbRelationYN.value = ""
window.document.frmEmpMast.cmbpaymode.selectedIndex = 0
window.document.frmEmpMast.txtAccno.value = ""
window.document.frmEmpMast.txtCrAccName.value = ""
window.document.frmEmpMast.txtIFSCCode.value = ""
window.document.frmEmpMast.cmbfammemrelid.value = ""
window.document.frmEmpMast.txtfammemname.value = ""
window.document.frmEmpMast.cmbfammemprofid.value = ""
window.document.frmEmpMast.txtfammemcustid.value = ""
window.document.frmEmpMast.txtfammemcustname.value = ""

window.document.frmEmpMast.txtfammempanno.value = ""

window.document.frmEmpMast.txtfammemmobile.value = ""


window.document.frmEmpMast.msflexfammemdtls.Rows = 1

window.document.frmEmpMast.cmbcomtype.selectedIndex = 0

window.document.frmEmpMast.txtFromDate.value = "<%=session("applicationdate")%>"
window.document.frmEmpMast.txtToDate.value = "<%=session("applicationdate")%>"

window.document.frmEmpMast.msflexcommmem.Rows = 1

window.document.frmEmpMast.txtTerminateDate.disabled = true
window.document.frmEmpMast.txtReason.disabled = true

if(window.document.frmEmpMast.opt1(0).checked==true)
	{
		
	window.document.frmEmpMast.butDirID.disabled = true
	window.document.frmEmpMast.txtDirectorID.value="<%=strdircode%>"
	controlsCheck(false)
	}
	else if(window.document.frmEmpMast.opt1(1).checked==true)
	{
	window.document.frmEmpMast.butDirID.disabled = false	
	window.document.frmEmpMast.txtDirectorID.value=""	
	controlsCheck(false)
	}
	else if(window.document.frmEmpMast.opt1(2).checked==true)
	{
	window.document.frmEmpMast.butDirID.disabled = false	
	window.document.frmEmpMast.txtDirectorID.value=""	
	window.document.frmEmpMast.txtTerminateDate.disabled = false
	window.document.frmEmpMast.txtReason.disabled = false
	controlsCheck(true)
	}
	else
	{
	window.document.frmEmpMast.butDirID.disabled = false
	window.document.frmEmpMast.txtDirectorID.value=""
	controlsCheck(true)
	}

}

function controlsCheck(strcheck)
{

window.document.frmEmpMast.txtCustid.disabled = strcheck
window.document.frmEmpMast.txtDirectorName.disabled = strcheck
window.document.frmEmpMast.txtQualification.disabled = strcheck
window.document.frmEmpMast.cmbBOD.disabled = strcheck
window.document.frmEmpMast.cmbBODDesig.disabled = strcheck
window.document.frmEmpMast.cmbBOM.disabled = strcheck
window.document.frmEmpMast.cmbBOMDesig.disabled = strcheck
window.document.frmEmpMast.txtElectionDate.disabled = strcheck
window.document.frmEmpMast.txtJoinDate.disabled = strcheck
window.document.frmEmpMast.txtTermPeriod.disabled = strcheck
window.document.frmEmpMast.txtTermEffDate.disabled = strcheck
window.document.frmEmpMast.txtTermDueDate.disabled = strcheck
window.document.frmEmpMast.cmbCommMemYN.disabled = strcheck
window.document.frmEmpMast.cmbSittingFees.disabled = strcheck
window.document.frmEmpMast.txtBOMSalary.disabled = strcheck
window.document.frmEmpMast.cmbTDSYN.disabled = strcheck

window.document.frmEmpMast.cmbRelationYN.disabled = strcheck
window.document.frmEmpMast.cmbpaymode.disabled = strcheck
window.document.frmEmpMast.txtAccno.disabled = strcheck
window.document.frmEmpMast.txtCrAccName.disabled = strcheck
window.document.frmEmpMast.txtIFSCCode.disabled = strcheck

window.document.frmEmpMast.cmbfammemrelid.disabled = strcheck
window.document.frmEmpMast.txtfammemname.disabled = strcheck
window.document.frmEmpMast.cmbfammemprofid.disabled = strcheck
window.document.frmEmpMast.txtfammemcustid.disabled = strcheck
window.document.frmEmpMast.cmdcustlstj.disabled = strcheck
window.document.frmEmpMast.txtfammemcustname.disabled = strcheck

window.document.frmEmpMast.txtfammempanno.disabled = strcheck
window.document.frmEmpMast.txtfammemmobile.disabled = strcheck
window.document.frmEmpMast.cmdfammemdtlsok.disabled = strcheck
window.document.frmEmpMast.msflexfammemdtls.disabled = strcheck
	window.document.frmEmpMast.cmbcomtype.disabled = strcheck
	window.document.frmEmpMast.txtFromDate.disabled = strcheck
	window.document.frmEmpMast.txtToDate.disabled = strcheck
	window.document.frmEmpMast.cmdcommemdtlssok.disabled = strcheck
	window.document.frmEmpMast.msflexcommmem.disabled = strcheck
	
}


function DescrptionDisp(strTxt)
{
var strVal
strVal = ""
	var sCust
sCust=""
	if(strTxt=="txtCustid")
	{ 
		sCust=window.document.frmEmpMast.txtCustid.value		
		window.document.frmEmpMast.txtCustname.value=""
		
		if (sCust == "")
	{
	return
	}
code="CustomerId"+"|"+sCust+"|"+strTxt
	
	window.document.all["iBatch2"].src="../Loan/combo.aspx?strval=" + code	
	}

if(strTxt=="txtfammemcustid")
	{ 
		sCust=window.document.frmEmpMast.txtfammemcustid.value		
		window.document.frmEmpMast.txtfammemcustname.value=""
		
		if (sCust == "")
	{
	return
	}
code="CustomerId"+"|"+sCust+"|"+strTxt
	
	window.document.all["iBatch2"].src="../Loan/combo.aspx?strval=" + code	
		
	}
	
	if(strTxt=="txtDirectorID")
	{ 
	
	strVal="DIRDETAILS"+"|"+window.document.frmEmpMast.txtDirectorID.value+"|"+""
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	
	
}


function DisplayCode(strval)
{
if(strval)
{
	MyStr=strval.split("|")
     	if(MyStr[0]=="CustomerId")
	{
	   
		if(MyStr[2]=="NOTHING")
		{
			alert("Not a Valid Customer Id..")
			if(MyStr[1]=="txtCustid")	
			{ 
				window.document.frmEmpMast.txtCustid.value=""
				return
			}
			
			if(MyStr[1]=="txtfammemcustid")	
			{ 
				window.document.frmEmpMast.txtfammemcustid.value=""
				return
			}
		}		
			if(MyStr[1]=="txtCustid")	
			{ 	
			window.document.frmEmpMast.txtCustname.value=MyStr[2] 
			window.document.frmEmpMast.txtDirectorName.value = MyStr[2] 
			}
			if(MyStr[1]=="txtfammemcustid")	
			{ 	
			window.document.frmEmpMast.txtfammemcustname.value=MyStr[2] 
		
			}
}
}
}


function Custold(butname)
	{
		
		if(butname=="butDirID")
		{
			if ((window.document.frmEmpMast.opt1(1).checked==true) || (window.document.frmEmpMast.opt1(2).checked==true))
			{
				st="DIRID"+"|"+" STATUS='R'"
			}
			if(window.document.frmEmpMast.opt1(3).checked==true)
			{
				st="DIRID"+"|"+"1=1"
			}
			
			window.showModalDialog('<%="http://" & session("moduledir")& "/CUSTOMER/"%>'+ "silist.aspx" + "?"+"st="+st,window,
  "status:no;dialogWidth:440px;dialogHeight:170px");
		}

	}
	
function DirectorID(kstr)
{
var dirid
		dirid = kstr.split("-----")
		
		window.document.frmEmpMast.txtDirectorID.value=dirid[1] 
		
		strVal="DIRDETAILS"+"|"+window.document.frmEmpMast.txtDirectorID.value+"|"+" STATUS='R'"
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;

}	
	
function getDIRDETAILS(str)
{
	var stDetail=str.split("$")
	var strMainVal = stDetail[0].split("~")

window.document.frmEmpMast.txtCustid.value = strMainVal[0]
window.document.frmEmpMast.txtCustname.value = strMainVal[1]
window.document.frmEmpMast.txtDirectorName.value = strMainVal[1]
window.document.frmEmpMast.txtQualification.value = strMainVal[2]
window.document.frmEmpMast.cmbBOD.value = strMainVal[3]
window.document.frmEmpMast.cmbBODDesig.value = strMainVal[4]
window.document.frmEmpMast.cmbBOM.value = strMainVal[5]
window.document.frmEmpMast.cmbBOMDesig.value = strMainVal[6]
window.document.frmEmpMast.txtElectionDate.value = Datepick1(strMainVal[7])
window.document.frmEmpMast.txtJoinDate.value = Datepick1(strMainVal[8])
window.document.frmEmpMast.txtTermPeriod.value = strMainVal[9]
window.document.frmEmpMast.txtTermEffDate.value = Datepick1(strMainVal[10])
window.document.frmEmpMast.txtTermDueDate.value = Datepick1(strMainVal[11])
window.document.frmEmpMast.cmbCommMemYN.value = strMainVal[12]
window.document.frmEmpMast.cmbSittingFees.value = strMainVal[13]
window.document.frmEmpMast.txtBOMSalary.value = strMainVal[14]
window.document.frmEmpMast.cmbTDSYN.value = strMainVal[15]
if (strMainVal[16] == '')
{
window.document.frmEmpMast.txtTerminateDate.value = ""
}
else
{
window.document.frmEmpMast.txtTerminateDate.value = Datepick1(strMainVal[16])
}
window.document.frmEmpMast.txtReason.value = strMainVal[17]
window.document.frmEmpMast.cmbRelationYN.value = strMainVal[18]
window.document.frmEmpMast.cmbpaymode.value = strMainVal[19]
window.document.frmEmpMast.txtAccno.value = strMainVal[20]
window.document.frmEmpMast.txtCrAccName.value = strMainVal[21]
window.document.frmEmpMast.txtIFSCCode.value = strMainVal[22]

setCommitteeMem()
SetRelation()

var strCommVal = stDetail[1].split("|")
	
		if (strCommVal.length > 0)
		{
		window.document.frmEmpMast.msflexcommmem.Rows=1
		
		window.document.frmEmpMast.msflexcommmem.cols=4;
		window.document.frmEmpMast.msflexcommmem.formatstring="<Sno      |<CommitteType         |<From Date         |<To Date       ";
		
			for(aCnt=0;aCnt<=strCommVal.length-1;aCnt++)
			{
				window.document.frmEmpMast.msflexcommmem.rows=window.document.frmEmpMast.msflexcommmem.rows+1
				
				var strCols=strCommVal[aCnt].split("~")
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmEmpMast.msflexcommmem.textmatrix(aCnt+1,0)=strCols[0]
					window.document.frmEmpMast.msflexcommmem.textmatrix(aCnt+1,1)=strCols[1]
					window.document.frmEmpMast.msflexcommmem.textmatrix(aCnt+1,2)=Datepick1(strCols[2])
					window.document.frmEmpMast.msflexcommmem.textmatrix(aCnt+1,3)=Datepick1(strCols[3])
				}
			}
		}
		
		var strFamMemVal = stDetail[2].split("|")
	
		if (strFamMemVal.length > 0)
		{
		window.document.frmEmpMast.msflexfammemdtls.Rows=1
		
		window.document.frmEmpMast.msflexfammemdtls.cols=7;
		window.document.frmEmpMast.msflexfammemdtls.formatstring="<Sno      |<Relation                             |<Name                                           |<Profession ID                    |< Customer No             |<Panno                  |<MobileNo                   ";
		
			for(aCnt=0;aCnt<=strFamMemVal.length-1;aCnt++)
			{
				window.document.frmEmpMast.msflexfammemdtls.rows=window.document.frmEmpMast.msflexfammemdtls.rows+1
				
				var strCols=strFamMemVal[aCnt].split("~")
			
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,0)=strCols[0]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,1)=strCols[1]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,2)=strCols[2]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,3)=strCols[3]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,4)=strCols[4]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,5)=strCols[5]
					window.document.frmEmpMast.msflexfammemdtls.textmatrix(aCnt+1,6)=strCols[6]
				}
			}
		}

}	

function panCheck()
{
var panNum
	panNum=window.document.frmEmpMast.txtfammempanno.value

if(window.document.frmEmpMast.txtfammempanno.value=="")
		{
			alert("Please Enter Pan Number")
			return;
		}
		else
		{
			if((panNum.length=="10")&&(panNum.substring(0,10)).match("[(/).]+"))
			{
				alert("Not a valid PanNumber")
				window.document.frmEmpMast.txtfammempanno.value=""
			}
			else
			{
				if(panNum.length=="10")
				{
					if((panNum.substring(0,5)).match(/^[a-zA-Z]+$/)&&(panNum.substring(5,9)).match(/^[0-9]+$/)&&(panNum.substring(9,10)).match(/^[a-zA-Z]+$/))
					{
						
					}
					else
					{
						alert("Not a valid PanNumber")
						window.document.frmEmpMast.txtfammempanno.value=""
						//window.document.frmEmpMast.txtfammempanno.focus()
						return;
					}
				}
				else
				{
					alert("Not a valid PanNumber")
					window.document.frmEmpMast.txtfammempanno.value=""
				//	window.document.frmEmpMast.txtfammempanno.focus()
					return;
				}
			}
		}
}

function AllowIFSC()
{

if (window.document.frmEmpMast.cmbpaymode.value == 'T')
{

}
else
{
var ifsc = window.document.frmEmpMast.txtIFSCCode.value
	if (window.document.frmEmpMast.txtIFSCCode.value == "")
	{
	alert("Enter IFSC Code")
	window.document.frmEmpMast.txtIFSCCode.focus();
	return
	}

	if (ifsc.length < 11)
	{
		
		alert("Length Of Destination IFSC Code Should not Be Less Than 11 Alphanumerics")
		window.document.frmEmpMast.txtIFSCCode.value=""
		window.document.frmEmpMast.txtIFSCCode.focus();
		return
	}
}

            var reg = /[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$/

if (ifsc.length > 0)
{
            if (ifsc.match(reg)) {
               return
            }
            else {
                alert("Invalid IFSC Code")
                window.document.frmEmpMast.txtIFSCCode.value = ""
                return
            }
            
 }     
    

 
}


function CheckAccno()
{
var strAccno
	strAccno = window.document.frmEmpMast.txtAccno.value
	if (window.document.frmEmpMast.cmbpaymode.value == 'T')
	{
	

		if (strAccno.length == 16)
		{
		}
		else
		{
		alert("Length Of Own Bank Account Should Be 16")
		window.document.frmEmpMast.txtAccno.value = ""
		}
		
		strVal="GetAccName"+"|"+window.document.frmEmpMast.txtAccno.value
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		
	}
	else
	{
	
	if (strAccno.length >= 5 && strAccno.length <= 25)
		{}
		else
		{
		alert("Length Of Other Bank Account Should Be Between 5 and 25")
		window.document.frmEmpMast.txtAccno.value = ""
		}
	}
}

function GetAccName1(str)
{
if (str == '')
{
alert("Invalid Accno")
window.document.frmEmpMast.txtAccno.value = ""
window.document.frmEmpMast.txtCrAccName.value = ""
return
}
else
{
window.document.frmEmpMast.txtCrAccName.value = str
}
}



function CheckAllCommitte()
{
var strboolean
strboolean = "true"

if (eval(window.document.frmEmpMast.msflexcommmem.Rows) > 1)
{
if (window.document.frmEmpMast.cmbcomtype.value == "ALL COMMITTIES")
{
strboolean = "Other"
}


for(introwcnt=1;introwcnt<eval(window.document.frmEmpMast.msflexcommmem.Rows);introwcnt++)
	{
		if(window.document.frmEmpMast.msflexcommmem.TextMatrix(introwcnt,1)=="ALL COMMITTIES")
		{
		strboolean="false"
		}
		else
		{
		
		}
	}	
}
	if (strboolean == "false")
	{
		alert("ALL COMMITTIES Already Entered, You Cannot Enter Any Other Committies")
		window.document.frmEmpMast.cmbcomtype.value = "Select"
	}
	
	if (strboolean == "Other")
	{
		alert("Already You Entered Other Committies, You Cannot Enter ALL COMMITTIES")
		window.document.frmEmpMast.cmbcomtype.value = "Select"
	}
}

function SetBOD()
{
if (window.document.frmEmpMast.cmbBOD.value == "N")
	{
	window.document.frmEmpMast.cmbBODDesig.value = "NONE"
	}
}

function SetBOM()
{
if (window.document.frmEmpMast.cmbBOM.value == "N")
	{
	window.document.frmEmpMast.cmbBOMDesig.value = "NONE"
	}
}
function SetBODDesignation()
{
if (window.document.frmEmpMast.cmbBOD.value == "Y")
	{
		if (window.document.frmEmpMast.cmbBODDesig.value == "NONE")
		{
		alert("Enter BOD Designation")
		window.document.frmEmpMast.cmbBODDesig.focus();
		return
		}
	}
	else
	{
		if (window.document.frmEmpMast.cmbBODDesig.value != "NONE")
		{
		
		window.document.frmEmpMast.cmbBODDesig.value = "NONE"
		return
		}
	}
}

function SetBOMDesignation()
{	
	if (window.document.frmEmpMast.cmbBOM.value == "Y")
	{
	if (window.document.frmEmpMast.cmbBOMDesig.value == "NONE")
	{
	alert("Enter BOM Designation")
	return
	}
	}
	else
	{
	if (window.document.frmEmpMast.cmbBOMDesig.value != "NONE")
	{
	
	window.document.frmEmpMast.cmbBOMDesig.value = "NONE"
	return
	}
	}
}	

</script>

<SCRIPT LANGUAGE=javascript FOR=msflexcommmem EVENT=DblClick>
<!--
 msflexcommmem_DblClick()
//-->
</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=msflexfammemdtls EVENT=DblClick>
<!--
 msflexfammemdtls_DblClick()
//-->
</SCRIPT>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);resultmessage();DispTranMsg();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmEmpMast">
    
    <div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="40%" align="center" height="22" class="subHeader"><h2>Director Details</h2></td>
				<td width="20%" height="22" align="right" class="subHeader"><%=appdate%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<table align =center width="95%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" >
					<tr>
						<td width="100%" >
							<!--<div style="text-align:center; width:100%; font-weight:bold; color:blue;"><%=Request.QueryString("record")%></div>-->
							<div align="center">
							<center>
							<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor1">
												<td width="10%">
												<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>New&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">Modify&nbsp;</font></p></td>
										<td width="12%">
												<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="Close">Close</font></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="VIEW">View</font></td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							</center>
							</div>
							<div align="center">
								<center>
								<table border="0" width="100%" cellspacing="0" cellpadding="0" >
									<tr class="bgcolor">
										<td width="13%" align="left">&nbsp;&nbsp;Director ID :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtDirectorID" onblur="DescrptionDisp(&quot;txtDirectorID&quot;)" onkeypress="Alphanum()" size="6" maxlength = 6 style="TEXT-ALIGN: right"><font color="#000000"><input name="butDirID" onclick="Custold('butDirID')" type="button" value=" L " class="button" disabled></font></td>
										<td width="11%" align="right">&nbsp;&nbsp;Cust. ID&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtCustid" class="txtautofill" onblur="DescrptionDisp(&quot;txtCustid&quot;)" onkeypress="Alphanum()" size="10" maxlength = 10 style="TEXT-ALIGN: right"><font color="#000000"><input name="butCustid" onclick="Customer(0)" type="button" value=" L " class="button"></font><input name="txtCustname"  class="bgcolor1" size="30"><font color="#000000"></font></td>
									</tr>
									<tr>
										<td width="13%" align="left">&nbsp;&nbsp;Director Name :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtDirectorName" onblur="DescrptionDisp(&quot;txtDirectorName&quot;)" onkeypress="Alphanum()" maxlength=50  size="50" ><font color="#000000"></font></td>
										<td width="11%" align="right">
										<p align="right">Qualification&nbsp;&nbsp;</p></td>
										<td width="25%"><input name="txtQualification" size="50" maxlength = 50 value="" class="txtautofill" >&nbsp;</td>
									</tr>
										<tr>
										<td width="13%" align="left">&nbsp;&nbsp;BOD:&nbsp;&nbsp;</td>
										<td width="25%"> <select id= "cmbBOD" name="cmbBOD" onchange="SetBOD()">
 <option value="N">NO</option>
 <option value="Y">YES</option>

 </select><font color="#000000"></font></td>
										<td width="11%" align="right">
										<p align="right">BOD Designation&nbsp;&nbsp;</p></td>
										<td width="25%"> <select id= "cmbBODDesig" name="cmbBODDesig" >

 <option value="NONE">NONE</option>
 <option value="CHAIRMAN">CHAIRMAN</option>
  <option value="DIRECTOR">DIRECTOR</option>
 </select>&nbsp;</td> 
 <td width="15%" align="right">&nbsp;</td>
 <td width="25%" align="right">&nbsp;</td>
									</tr>
										<tr>
										<td width="13%" align="left">&nbsp;&nbsp;BOM :&nbsp;&nbsp;</td>
										<td width="25%"><select id= "cmbBOM" name="cmbBOM" onfocus="SetBODDesignation()" onchange = "SetBOM()" >
 <option value="N">NO</option>
 <option value="Y">YES</option>
 
 </select><font color="#000000"></font></td>
										<td width="11%" align="right">
										<p align="right">BOM Designation&nbsp;&nbsp;</p></td>
										<td width="25%"> <select id= "cmbBOMDesig" name="cmbBOMDesig"  >


 <option value="NONE">NONE</option>
 <option value="CHAIRMAN">CHAIRMAN</option>
  <option value="DIRECTOR">DIRECTOR</option>
 </select>&nbsp;</td>
<td width="15%" align="right">
										RelationYN&nbsp;&nbsp;</td>
										<td width="25%"> <select id= "cmbRelationYN" name="cmbRelationYN" onfocus ="SetBOMDesignation()"  onchange="SetRelation()" >
 <option value="N" selected>NO</option>
 <option value="Y">YES</option>

 </select>&nbsp;</td>
									</tr>
								</table>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="13%" align="left">&nbsp;&nbsp;Election Date :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtElectionDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtElectionDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right">(DDMMYYYY)<font color="#000000"></font></td>
										<td width="11%" align="right">
										<p align="right">Join Date&nbsp;&nbsp;</p></td>
										<td width="25%"><input name="txtJoinDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtJoinDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right" > (DDMMYYYY)&nbsp;</td>
										<td width="15%" align="right">
										<p align="right">Term Period&nbsp;&nbsp;</p></td>
										<td width="25%"><input name="txtTermPeriod" size="5"  maxlength=2 onkeypress="numeric(window.document.frmEmpMast.txtTermPeriod.value)" value="" class="txtautofill" > &nbsp;</td>
									</tr>
									
										<tr>
										<td width="13%" align="left">&nbsp;&nbsp;TermEff Date :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtTermEffDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtTermEffDate.value)" size="12"  maxlength='12' onblur="datecheck(this);GetTermDueDate()" style="TEXT-ALIGN: right">(DDMMYYYY)<font color="#000000"></font></td>
										<td width="11%" align="right">
										<p align="right">Term Due Date&nbsp;&nbsp;</p></td>
										<td width="25%"><input name="txtTermDueDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtTermDueDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right" >(DDMMYYYY)&nbsp;</td>
										<td width="15%" align="right">
										<p align="right">CommMemYN&nbsp;&nbsp;</p></td>
										<td width="25%"><select id= "cmbCommMemYN" name="cmbCommMemYN" onchange="setCommitteeMem()">
 <option value="N" selected>NO</option>
 <option value="Y">YES</option>

 </select>&nbsp;</td>
									</tr>
									
									<tr>
										<td width="13%" align="left">&nbsp;&nbsp;Sitting Fees :&nbsp;&nbsp;</td>
										<td width="25%"><select id= "cmbSittingFees" name="cmbSittingFees" onchange="setSittingFees()">

 <option value="Y" selected >YES</option>
 <option value="N">NO</option>
 </select></font></td>
										<td width="11%" align="right">
										<p align="right">Salary&nbsp;&nbsp;</p></td>
										<td width="25%"><input name="txtBOMSalary" size="12" maxlength=13 onkeypress="numdec(window.document.frmEmpMast.txtBOMSalary.value)"  onkeyup='Numvalidate()' value="0" class="txtautofill" disabled>&nbsp;</td>
										<td width="15%" align="right">
										<p align="right">TDSYN&nbsp;&nbsp;</p></td>
										<td width="25%"> <select id= "cmbTDSYN" name="cmbTDSYN">
 <option value="N" selected>NO</option>
 <option value="Y">YES</option>

 </select>&nbsp;</td>
									</tr>
									
										<tr>
										<td width="13%" align="left">&nbsp;&nbsp;TerminateDate :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtTerminateDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtTerminateDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>
										<td width="11%" align="right">
										<p align="right">Reason&nbsp;&nbsp;</p></td>
										<td width="25%" colspan=3 ><input name="txtReason" size="50" maxlength=100  value="" class="txtautofill" >&nbsp;</td>
										
									</tr>
									
								</table>
								
						
								    <div align="center">

          <table cellpadding="0" width="900"  class="tablebordermain">
            <tr>
              <td width="300" align="center" ><a href="#" class="link" onclick="showdiv('commemdtls')" >Commitee Member Details</a></td>
             <td width="300" align="center"><a href="#" class="link" onclick="showdiv('fammemdtls')">Family Member Details</a></td>
              <td width="300" align="center"><a href="#" class="link" onclick="showdiv('creditaccdtls')">Credit Account Details</a></td>
              
            </tr>
          </table>
        </div>
		
		<div id="divcommmem" style="display: block; height: 114; width: 950">
          <div align="center">
            <center>

            <table width="96%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
				  <td width="18%" align="left">Committe Type</td>
				  <td width="24%" align="left">&nbsp;<select size="1" name="cmbcomtype" onchange="CheckAllCommitte()">
									<option value="Select" selected>Select</option>
									<option value="NONE">NONE</option>
<option value="ALL COMMITTIES">ALL COMMITTIES</option>
<option value="AUDIT COMMITTEE">AUDIT COMMITTEE</option>
<option value="INVESTMENT COMMITTEE">INVESTMENT COMMITTEE</option>
<option value="LOANS COMMITTEE">LOANS COMMITTEE</option>
<option value="ARBITRATION COMMITTEE">ARBITRATION COMMITTEE</option>
<option value="ALM COMMITTEE">ALM COMMITTEE</option>
<option value="CYBER SECURITY COMMITTEE">CYBER SECURITY COMMITTEE</option>
                                 </select>
                                 </td>
		<td width="15%" align="left">&nbsp;&nbsp;From Date :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtFromDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtFromDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>	
<td width="15%" align="left">&nbsp;&nbsp;To Date :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtToDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtToDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>
								 
				  </tr>
				  <tr>
				  <td colspan = "6" >
				   <table align="center">
                    <tr>
                    <td width="70%" align="center">&nbsp;&nbsp;<input name="cmdcommemdtlssok" onclick="commemdtlsflxgrd()" type="button" value="   OK   " class="button"><input name="cmdcommemdtlscancel" onclick="commemdtlsCancel()" type="button" value="Delete" class="button"></td>
                    </tr>
				    </table>
				  </td>
				  </tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=msflexcommmem style="LEFT: 0px; WIDTH: 699px; TOP: 0px; HEIGHT: 102px" 
	height=102 width=699 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=msflexcommmem >
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="4">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="^Sno          |<CommitteType                                     |<From Date                       |<To Date                     ">
	<PARAM NAME="GridColor" VALUE="12632256"> 
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
				</table>  
	</td>
              </tr>
            </table>

            </center>
          </div>
        </div>
		 <div id="divfammemdtls" style="display: none; height: 114; width: 950">
          <div align="center">
            <center>

            <table width="96%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                  <td width="15%" align="left">Relation </td>
                    <td width="24%" align="left"><select size="1" name="cmbfammemrelid">
									<option value="" selected>select</option>
										<% dim objJnt,rsJnt
										
										objJnt=server.CreateObject("queryrecordsets.fetchrecordsets")
										
										rsJnt=objJnt.SingleRecordSet("DIRRELATIONTYPEMST","RELATIONID, RELATIONNAME","")%>
										<%if not rsJnt.EOF and not rsJnt.BOF  then
											do until rsJnt.EOF %>
											<option value="<%=rsJnt(0).value%>"><%=rsJnt(1).value%></option>
										<%rsJnt.MoveNext()
											loop
											end if%>
                                                      
                                 </select>
                                 </td>
                                 <td width="20%" align="left">Name </td>
                                  <td width="24%" align="left"><input class="txtautofill" name="txtfammemname"  onblur="DescrptionDisp(&quot;txtfammemname&quot;)" maxlength=50  size="50" style="HEIGHT: 22px; WIDTH: 151px">     </td>
                                 </tr>
                                 <tr>
                                 <td width="15%" align="left">Profession </td>
                    <td width="24%" align="left"><select size="1" name="cmbfammemprofid">
									<option value="" selected>select</option>
										<% dim objpro,rspro
										
										objpro=server.CreateObject("queryrecordsets.fetchrecordsets")
										
										rspro=objpro.SingleRecordSet("GENOCCUPATIONMST","CODE, NARRATION","")%>
										<%if not rspro.EOF and not rspro.BOF  then
											do until rspro.EOF %>
											<option value="<%=rspro(0).value%>"><%=rspro(1).value%></option>
										<%rspro.MoveNext()
											loop
											end if%>
                                                      
                                 </select>
                                 </td>
                    <td width="20%" align="left">Cust. ID</td>
                    <td width="24%" align="left"><input class="txtautofill" name="txtfammemcustid"  onblur="DescrptionDisp(&quot;txtfammemcustid&quot;)" maxlength = 10  size="10" style="HEIGHT: 22px; WIDTH: 151px"><input name="cmdcustlstj" onclick="Customer(2)" type="button" value=" L " class="button"><input disabled class="bgcolor1" name="txtfammemcustname" size="25" style="HEIGHT: 22px; WIDTH: 226px"></td>
                   
                  </tr>
                   <tr>
 <td width="24%" align="left">Panno </td>
                    
                                  <td width="15%" align="left"><input class="txtautofill" name="txtfammempanno"  onblur="DescrptionDisp(&quot;txtfammempanno&quot;);panCheck()" size="10" maxlength=10 style="HEIGHT: 22px; WIDTH: 151px">     </td>
                                 <td width="20%" align="left">Mobile </td>
                                  <td width="24%" align="left"><input class="txtautofill" name="txtfammemmobile"  onblur="DescrptionDisp(&quot;txtfammemmobile&quot;)" size="10" maxlength=10 style="HEIGHT: 22px; WIDTH: 151px">     </td>
                                  
                                 </tr>
                                 <tr>
                                 <td colspan=4>
                                 <table align="center">
                    <tr>
                    <td width="70%" align="center">&nbsp;&nbsp;<input name="cmdfammemdtlsok" onclick="fammemdtlsflxgrd()" type="button" value="   OK   " class="button"><input name="cmdfammemdtlscancel" onclick="fammemdtlsCancel()" type="button" value="Cancel" class="button"></td>
                    </tr>
				    </table>
				    </td>
                                 </tr>
                  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=msflexfammemdtls style="LEFT: 0px; WIDTH: 750px; TOP: 0px; HEIGHT: 102px" 
	height=102 width=750 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=msflexfammemdtls VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="7">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="<Sno   |<Relation  |<Name                                           |<Profession ID|< Customer No             |<Panno                  |<MobileNo                  ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>

                    </p>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="3" width="100%" height="5"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
        </div>
        	<div id="divCrAccDtls" style="display: none; height: 114; width: 900">
          <div align="center">
            <center>

            <table width="96%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                 <tr>
                    <td width="24%" align="left">PayMode</td>
                    <td width="24%" align="left">&nbsp;&nbsp;<select size="1" name="cmbpaymode" onchange="paymode()">
								<!--	<option value="Select" selected>Select</option>  -->
									<option value="T">OWN Bank Transfer</option>
									<option value="N">Other Bank Transfer</option>
                                 </select></td>
                    <td width="24%" align="left">Accno </td>
                    <td width="24%" align="left">&nbsp;<input class="txtautofill" name="txtAccno"  onblur="DescrptionDisp(&quot;txtAccno&quot;);CheckAccno()" size="25" maxlength = 16 style="HEIGHT: 22px; WIDTH: 200px">
                                 </td>
                  </tr>
                  <tr>
                    <td width="24%" align="left">Name</td>
                    <td width="24%" align="left">&nbsp;&nbsp;<input class="txtautofill" name="txtCrAccName"  onblur="DescrptionDisp(&quot;txtCrAccName&quot;)" size="50" maxlength = 50 style="HEIGHT: 22px; WIDTH: 170px"></td>
                    <td width="24%" align="left">IFSCCode </td>
                    <td width="24%" align="left">&nbsp;<input class="txtautofill" name="txtIFSCCode"  onblur="DescrptionDisp(&quot;txtIFSCCode&quot;);AllowIFSC()" size="25" maxlength=11  style="HEIGHT: 22px; WIDTH: 200px">
                                 </td>
                  </tr>
                  <tr>
                    <td colspan="4" width="100%">
                    <p align="center">
                    
                    </p>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="3" width="100%" height="5"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
        </div>	
		</center>
		</div> 
					</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	
	<table width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px"  class="tablebordermain">
		<tr>
			<td width="100%" align="center" ><input name="cmdOk" onclick="Ok()" type="button" value="    Ok    " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmEmploymast.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
		</tr>
  </table>
	
	<input type="hidden" name="hmod" value="<%=session("module")%>">
	<input type="hidden" name="hpr" value="<%=session("precision")%>">
	<input type="hidden" name="status">
	<input type="hidden" name="hidaccstatus">
	<input type="hidden" name="hidAbb">
	<input type="hidden" name="empval">
	<input type="hidden" name="hidcomtype">
	<input type="hidden" name="hidfammemname">
	<input type="hidden" name="hdnDirectorID">
<input type="hidden" name="hdnCustid">
<input type="hidden" name="hdnDirectorName">
<input type="hidden" name="hdnQualification">
<input type="hidden" name="hdnBOD">
<input type="hidden" name="hdnBODDesig">
<input type="hidden" name="hdnBOM">
<input type="hidden" name="hdnBOMDesig">
<input type="hidden" name="hdnElectionDate">
<input type="hidden" name="hdnJoinDate">
<input type="hidden" name="hdnTermPeriod">
<input type="hidden" name="hdnTermEffDate">
<input type="hidden" name="hdnTermDueDate">
<input type="hidden" name="hdnCommMemYN">
<input type="hidden" name="hdnSittingFees">
<input type="hidden" name="hdnBOMSalary">
<input type="hidden" name="hdnTDSYN">
<input type="hidden" name="hdnTerminateDate">
<input type="hidden" name="hdnReason">
<input type="hidden" name="hdnRelationYN">
<input type="hidden" name="hdnpaymode">
<input type="hidden" name="hdnAccno">
<input type="hidden" name="hdnCrAccName">
<input type="hidden" name="hdnIFSCCode">
<input type="hidden" name="hdncommemval">
<input type="hidden" name="hdnfammemval">
<input type="hidden" name="hidmode">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDetails.aspx"></iframe>
	<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="../gensbca/querydisplay.aspx"></iframe>
	
	<iframe id="iBatch2" align=center frameBorder=0 frameSpacing=0  height=0 width=0 ></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>
