<%@ Page Language="vb" CodeBehind="PigmyUserCreationApprove.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.PigmyUserCreationApprove" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : PigmyUserCreationApprove.ASP							*
'*	Purpose	  	     : To Approve new,modified and deleted users		  	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<%
abb=session("Abbuser")
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>User Creation Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE=javascript>
<!--

function DescQry(str)
{
	
	if(str=="Gl")
	{  Clear()
		
	    window.document.frmPigmyUserCreation.txtAcc.value=""
	    window.document.frmPigmyUserCreation.txtAccNm.value="" 
	    window.document.frmPigmyUserCreation.txtGldesc.value=""
	    
		if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
		return;
		
		if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
		{
			alert("Select Branchcode")
			window.document.frmPigmyUserCreation.txtBrcode.focus()
	//		window.document.frmPigmyUserCreation.txtGr.value=""
	//		window.document.frmPigmyUserCreation.txtGrNm.value=""
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
		if(window.document.frmPigmyUserCreation.txtGr.value=="")
		{
			alert("Select Group")
			window.document.frmPigmyUserCreation.cmdGroup.focus()
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
	    str = "PigmyGl" 
				+"|"+window.document.frmPigmyUserCreation.txtBrcode.value
				+"|"+window.document.frmPigmyUserCreation.txtModcode.value
				+"|"+window.document.frmPigmyUserCreation.txtGlCode.value
						
	    window.document.all["iBatch"].src="../GEN/querydisplay.aspx?st="+str
	}		
}

/*
function DescDislay(kstr)
{   
	kstr=kstr.split("|")

	if(kstr[0]=="PigmyGl")
	{	
		if(kstr[1]=="")
		{
			alert("Invalid GlCode")
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtGlCode.focus()
			return;
		}
		
		window.document.frmPigmyUserCreation.txtGldesc.value = kstr[1]
		
	}
}*/



function GlCode()
{   
	Clear()

	// send Branch string to LIST.asp
	window.document.frmPigmyUserCreation.txtGldesc.value=""
	window.document.frmPigmyUserCreation.txtGlCode.value=""
	
	if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
	{
		alert("Select Branch Code")
		window.document.frmPigmyUserCreation.txtBrcode.focus()
		//window.document.frmPigmyUserCreation.txtGr.value=""
		//window.document.frmPigmyUserCreation.txtGrNm.value=""
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		
		return;
	}

	if(window.document.frmPigmyUserCreation.txtGr.value=="")
	{
		alert("Select Group")
		window.document.frmPigmyUserCreation.cmdGroup.focus()
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		return;
	}
		
		window.document.frmPigmyUserCreation.opt1(0).checked=false
		//window.document.frmPigmyUserCreation.txtAcc.disabled=false
		//window.document.frmPigmyUserCreation.txtAcc.readOnly=false
		//window.document.frmPigmyUserCreation.txtUserID.disabled=false
		//window.document.frmPigmyUserCreation.txtUserID.readOnly=false
		//window.document.frmPigmyUserCreation.cmdAcc.disabled=false
		//window.document.frmPigmyUserCreation.txtAcc.value=""
		//window.document.frmPigmyUserCreation.txtAccNm.value=""
	
		
	st="PigmyGlcode"
	
	st=st+"|"+window.document.frmPigmyUserCreation.txtModcode.value	
	     +"|"+window.document.frmPigmyUserCreation.txtBrcode.value
		
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Glcodeid(kstr)
{	
	
	
	if (kstr=="No Data Found...")
		return
		
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  window.document.frmPigmyUserCreation.txtGlCode.value=kstr[1]
	 	  window.document.frmPigmyUserCreation.txtGldesc.value=kstr[0]
	 	  
	 	  	
}


// to refresh the contents of screen
function Cancel()
{
location.href ="PigmyUserCreationApprove.aspx"
}                                                                                          

// If cmdApprove button is pressed call this function
function Approve()
{
	// enable txtuserid text box to extract the value from PigmyUserCreationtrans.aspx
	if(window.document.frmPigmyUserCreation.status.value!="")
		window.document.frmPigmyUserCreation.status.value=""
	else
		return
	window.document.frmPigmyUserCreation.txtUserID.disabled=false
	window.document.frmPigmyUserCreation.status.value="APPROVE"
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPX"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();
	
}

//// this fucntion is called when branch list button is pressed
function branch()
{   
	// send Branch string to LIST.aspx
	st="Branch"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Branchid(kstr)
{
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  window.document.frmPigmyUserCreation.txtBrdesc.value=kstr[0]
	 	  window.document.frmPigmyUserCreation.txtBrcode.value=kstr[1]
	 	  	
}



// If cmdApprove button is pressed call this function
function Reject()
{
	if(window.document.frmPigmyUserCreation.status.value!="")
		window.document.frmPigmyUserCreation.status.value=""
	else
		return
	// enable txtuserid text box to extract the value from PigmyUserCreationtrans.aspx
	window.document.frmPigmyUserCreation.txtUserID.disabled=false
	window.document.frmPigmyUserCreation.status.value="REJECT"
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPx"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();
	
}

function Abbcheck()
{/*
var abb="<%=abb%>"
if (abb.toUpperCase()=="Y")
{
	window.document.frmPigmyUserCreation.cmdbranch.disabled=false
	window.document.frmPigmyUserCreation.txtBrcode.readonly=false
}
else
{
	window.document.frmPigmyUserCreation.cmdbranch.disabled=true
	window.document.frmPigmyUserCreation.txtBrcode.readonly=true
	
}*/
}

//to get branchcode description 

///function for sending parameters to display the description on blur event
function DescrptionDisp(strTxt)
{
 if(strTxt=="txtbranchcode")
	{ 
		if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
		 {
			return;
		 }
		st="DescDisplay~GENBANKBRANCHMST~"+"NARRATION~branchcode='"+
		window.document.frmPigmyUserCreation.txtBrcode.value+"'~~"+strTxt
	}
	window.document.all["iBatch"].src="../Gen/reportdisplay.aspx?st="+st	
}

 ///selcted code which is returned in tfrmae page
function DescDisplay(stri)
{
 //alert(stri)
var strtype=new String()
 strtype=stri.split("~")
//for description displaying  split the values
var StrArrFld=new String()
//var StrArrFlds=new String()
 StrArrFld=strtype[0].split("|")
	
	if(StrArrFld[0]=="PigmyGl")
	{
		if(StrArrFld[1]=="")
		{
			alert("Invalid GlCode")
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtGlCode.focus()
			return;
		}
		
		window.document.frmPigmyUserCreation.txtGldesc.value = StrArrFld[1]
	}
	else
	{
		///for Branchcode
		if(strtype[1]=="txtbranchcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Acc No")
				window.document.frmPigmyUserCreation.txtBrcode.value=""
				window.document.frmPigmyUserCreation.txtBrdesc.value=""
				return;
			}
			window.document.frmPigmyUserCreation.txtBrdesc.value=StrArrFld[0]
		}
	}
}	

/// To clear All the required fields
function Clear()
{
	//window.document.frmPigmyUserCreation.txtAddress.value=""
	//window.document.frmPigmyUserCreation.txtAddress1.value=""
	//window.document.frmPigmyUserCreation.txtCity.value=""
	window.document.frmPigmyUserCreation.txtAcc.value=""
	window.document.frmPigmyUserCreation.txtAccNm.value=""
	window.document.frmPigmyUserCreation.txtUserName.value=""
	//window.document.frmPigmyUserCreation.txtEmpcode.value=""
	window.document.frmPigmyUserCreation.txtUserID.value=""
	window.document.frmPigmyUserCreation.txtBio.value=""
	window.document.frmPigmyUserCreation.txtpwd.value=""
	//window.document.frmPigmyUserCreation.txtMacid.value=""

}


function DispMacid()
{/*
if(window.document.frmPigmyUserCreation.chkmacid.checked==true)
	{
	window.document.all.spmacid.style.display="block"
	window.document.frmPigmyUserCreation.txtMacid.style.visibility="visible"
	}
else if(window.document.frmPigmyUserCreation.chkmacid.checked==false)
	{
	window.document.all.spmacid.style.display="none"
	window.document.frmPigmyUserCreation.txtMacid.style.visibility="hidden"
	}
	window.document.frmPigmyUserCreation.txtMacid.value=""*/
}

function Gendisplay()
{/*
	// Sending userid to genuserdetails.aspx
	st=window.document.frmPigmyUserCreation.txtUserID.value 
	window.document.all['iBatch'].src="GenUserDetails.aspx?st="+st */
}


function GenDisp(kstr)
  {/*
  // Get the informatin from GenUSerDetails.ASPX
  var Str1
  // split the string based on "+}" delimeter
  Str1=kstr.split("+}")
  
  // Display it
  window.document.frmPigmyUserCreation.txtBrcode.value=Str1[0]
 // window.document.frmPigmyUserCreation.txtBio.value=Str1[1] 
  window.document.frmPigmyUserCreation.txtGr.value=Str1[2]
  window.document.frmPigmyUserCreation.txtGrNm.value=Str1[3]
  //window.document.frmPigmyUserCreation.txtDesig.value=Str1[4]
  //window.document.frmPigmyUserCreation.txtAddress.value=Str1[5]
  //window.document.frmPigmyUserCreation .txtAddress1.value=Str1[6]
  //window.document.frmPigmyUserCreation.txtCity.value=Str1[7]
  //window.document.frmPigmyUserCreation.txtEmail.value=Str1[8]
 if(Str1[9].length>2)
	window.document.frmPigmyUserCreation.chkmacid.checked=true
  else
	window.document.frmPigmyUserCreation.chkmacid.checked=false
  window.document.frmPigmyUserCreation.txtMacid.value=Str1[9]
  window.document.frmPigmyUserCreation.txtSessions.value=Str1[10]
  window.document.frmPigmyUserCreation.txtBrdesc.value=Str1[15]
  window.document.frmPigmyUserCreation.txtEmpcode.value=Str1[13]
  
   
  if(Str1[14]=="Y")
	window.document.frmPigmyUserCreation.chkAbb.checked=true
  else
	window.document.frmPigmyUserCreation.chkAbb.checked=false
	
  
   if(window.document.frmPigmyUserCreation.txtGr.value=="ADMIN")
		{
		window.document.all.spsessions.style.display="block"
		window.document.frmPigmyUserCreation.txtSessions.style.visibility="visible"
		}
  else
		{
		window.document.all.spsessions.style.display="none"
		window.document.frmPigmyUserCreation.txtSessions.style.visibility="hidden"
		}
  DispMacid()
  window.document.frmPigmyUserCreation.txtMacid.value=Str1[9]*/
  }

// Calling list

function QueryList()
{
	Clear()
	
	if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
	{
		alert("Select GlCode")
		window.document.frmPigmyUserCreation.txtGlCode.focus()
		return;
	}
	
	if (window.document.frmPigmyUserCreation.opt1(0).checked==true)
		window.document.frmPigmyUserCreation.status.value ="PNEW"
	else if (window.document.frmPigmyUserCreation.opt1(1).checked==true)
		window.document.frmPigmyUserCreation.status.value ="MODIFY"	
	else if (window.document.frmPigmyUserCreation.opt1(2).checked==true)
		window.document.frmPigmyUserCreation.status.value ="DELETE"	
	
	
	// Send Query to LIST.ASP to get the users list
	
	st="PQuery"+window.document.frmPigmyUserCreation.status.value+ "|" +
			window.document.frmPigmyUserCreation.txtBrcode.value+"|"+
		 window.document.frmPigmyUserCreation.txtGlCode.value
		 
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
}

function DisplayQuery(kstr)
{

	// Display the selected fields from list
	if (kstr=="No Data Found...")
		return
	kstr=kstr.split("-----")
	//assign(kstr,window.document.frmPigmyUserCreation.txtUserName,
	//window.document.frmPigmyUserCreation.txtUserID )
	//Gendisplay()
	window.document.frmPigmyUserCreation.txtUserName.value=kstr[0]
	window.document.frmPigmyUserCreation.txtUserID.value=kstr[1]
	window.document.frmPigmyUserCreation.txtAcc.value=kstr[2]
	window.document.frmPigmyUserCreation.txtAccNm.value=kstr[3]
	
	// Enable and disable the fields
	//window.document.frmPigmyUserCreation.cmdreject.disabled=false
	window.document.frmPigmyUserCreation.txtUserID.disabled=true
	window.document.frmPigmyUserCreation.txtBio.disabled=true
	window.document.frmPigmyUserCreation.txtpwd.disabled= true
	
	//window.document.frmPigmyUserCreation.txtEmpcode.disabled= true
	//window.document.frmPigmyUserCreation.cmdapprove.disabled= false
	
	//window.document.frmPigmyUserCreation.cmdGroup.disabled=true
}



//-->
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Abbcheck()">

<form name="frmPigmyUserCreation">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="2%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="center" height="22" class="subHeader"><h2>approval of daily deposits user creation</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>
  <table width="100%" cellspacing="0" cellpadding="0" height="460" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="427">
        <tr>
          <td height="28" colspan="3">

          

        
          <td width="100%" height="15" colspan="3" align="center">
          <p align="center"></p>
          </td>
        </tr>
        <tr>
              <td width="100%" colspan="3" align="center" height="15">
              <p align="center"><%=Request.QueryString("record")%></p>
              </td>
            </tr>
        <tr>
          <td width="100%" height="29" colspan="3">
          <div align="center">
            <center>

            <table border="0" width="98%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="28%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code
                </td>
                <td width="42%"><input name="txtBrcode" class="txtautofill" readonly size="9" value="<%=session("branchcode")%>" onblur="DescrptionDisp(&quot;txtbranchcode&quot;)"><input type="button" value=" L " name="cmdbranch" class="button" onclick="branch()"><input name="txtBrdesc" class="bgcolor1" size="16" readonly value="<%=session("branchnarration")%>"></td>
                <td width="54%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;Group
                Code&nbsp;&nbsp;</td>
                <td width="32%" align="left"><input name="txtGr" class="txtautofill" size="9" readonly value="PIGMY"><input type="button" value=" L " name="cmdGroup" class="button" disabled><input name="txtGrNm" class="bgcolor1" size="16" readonly value="PIGMY" ></td>
              </tr>
              <tr class="bgcolor">
                <td width="25%" align="left">
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module Code
                </td>
                <td width="50%"><input name="txtModcode" size="9" class="txtautofill" readonly value="PIGMY"><input type="button" value=" L " name="cmdmod" class="button" disabled><input name="txtModdesc" size="16" class="bgcolor1" readonly value="Daily Deposits">&nbsp;</td>
                <td width="54%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;GL Code</td>
                <td width="32%" align="right"><input name="txtGlCode" size="9" onkeypress="Alphanum()" class="txtautofill" onblur="DescQry('Gl')" ><input type="button" value=" L " name="cmdGl" class="button" onclick="GlCode()"><input name="txtGldesc" size="16" readonly class="bgcolor1" ></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
          <div align="center">
            <center>

            <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%">

                <table width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
                  <tr class="bgcolor1">
                    <td width="33%">
                    <p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="QueryList()">
                    New&nbsp;</font></p>
                    </td>
                    <td width="34%">
                    <p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="QueryList()">
                    Modify&nbsp;</font></p>
                    </td>
                    <td width="39%" style="display:none">
                    <p align="center"><font class="textwhite"><input name="opt1" onclick="QueryList()" type="radio" value="DELETE">
                    &nbsp;Delete&nbsp;</font></p>
                    </td>
                  </tr>
                </table>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" valign="top" height="10"></td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" height="242">
                    <div align="center">

                      <table width="64%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td width="100%">

                          <table border="0" width="466" cellspacing="0" cellpadding="0" >
                            <tr class="bgcolor">
                              <td width="464" colspan="4" height="18"><font class="subheading">&nbsp;User
                              Information</font></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;User ID</td>
                              <td width="266" height="25" colspan="3"><input name="txtUserID" size="35" class="txtautofill" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;User Name</td>
                              <td width="266" height="25" colspan="3"><input name="txtUserName" class="txtautofill" size="35" readonly></td>
                            </tr>                            
                            <tr>
                              <td width="196">&nbsp;AccNo</td>
                              <td width="290" colspan="3"><input type="text" name="txtAcc" class="txtautofill" size="9" onkeypress="numeric()" onblur="" readonly><input type="button" value=" L " name="cmdAcc" class="button" onclick="Accno()" disabled><input  type="text" class="bgcolor1" name="txtAccNm" size="21" readonly>&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Password</td>
                              <td width="266" height="25" colspan="3"><input name="txtpwd" class="txtautofill" size="35" disabled></td>
                            </tr>
                            <tr style="display:none">
                              <td width="196" height="25">&nbsp;Second Password</td>
                              <td width="266" height="25" colspan="3"><input type="password" name="txtBio" size="35" disabled></td>
                            </tr>
                            <!--<tr>
                              <td width="196" height="25">&nbsp;Employee Code</td>
                              <td width="101" height="25"><input name="txtEmpcode" style="TEXT-TRANSFORM: capitalize;"  size="13" readonly></td>

            </center>
                              <td width="108" height="25">
                                <p align="right">ABB User Y/N&nbsp;&nbsp;&nbsp;</td>
            <center>

                              <td width="53" height="25"><input type="checkbox" name="chkAbb" disabled value="ON"></td>
                            </tr>
                            <tr>
                              <td width="464" colspan="4" height="27">
                                <table border="0" cellpadding="0" cellspacing="0" width="460">
                                  <tr>
                                    <td width="226" height="23">&nbsp;Restricted to a
                                Single Machine&nbsp;&nbsp;&nbsp; <input type="checkbox" name="chkmacid" disabled onclick="DispMacid()" value="ON">&nbsp;</td>
                                    <td valign="middle" width="102"><span id="spsessions" style="display:none">No. Of
                                Sessions&nbsp;</span></td>
                                    <td width="126" height="23"><input  name="txtSessions" readonly size="12" maxlength="2" style="visibility:hidden"></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td width="196" height="25"><span id="spmacid" style="display:none">&nbsp;Machine ID&nbsp;</span></td>
                              <td width="266" height="25" colspan="3"><input name="txtMacid" style="TEXT-TRANSFORM: capitalize;"  readonly size="32" maxlength="30" style="visibility:hidden"></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="464" colspan="4" height="13"><font class="subheading">&nbsp;Personal
                              Information</font></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Designation</td>
                              <td width="266" height="25" colspan="3"><input name="txtDesig" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Address</td>
                              <td width="266" height="25" colspan="3"><input name="txtAddress" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25"></td>
                              <td width="266" height="25" colspan="3"><input name="txtAddress1" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                              <td width="266" height="25" colspan="3"><input name="txtCity" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25" align="right">
                              <p align="left">&nbsp;E-mail ID</p>
                              </td>
                              <td width="266" height="25" colspan="3"><input name="txtEmail" size="32" readonly></td>
                            </tr>-->
                          </table>

                          </td>
                        </tr>
                      </table>

                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" height="10" colspan="3"><center></center></td>
        </tr>
        <tr>
          <td width="100%" height="30" colspan="3"><center>
          <div align="center">
            <center>

            <table width="30%" cellspacing="0" cellpadding="0" style="height: 28px" class="tablebordermain">
              <tr>
                <td width="500">
                <p align="center"><input name="cmdok" onclick="Approve()" type="button" value=" Approve" class="button"><input name="cmdok1" onclick="Reject()" type="button" value=" Reject " class="button"><input name="cmdCancel" onclick="Cancel()" type="button" value="Cancel" class="button"><input name="cmdexit" class="button" type="button" value="   Exit   " class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></p>
                </td>
              </tr>
            </table>

            </center>
          </div>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="10"></td>
            </tr>
          </table>

          </center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="status">
  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.aspx">
           </iframe>

          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>
<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="">
                                              </iframe>
</body>

</html>
