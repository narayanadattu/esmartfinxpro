<%@ Page Language="vb" AutoEventWireup="false" aspcompat="true" explicit="false" Codebehind="frmEmploymast.aspx.vb" Inherits="eSmartDotNet.frmEmploymast"%>
<%
abb=session("Abbuser")

	dim obj,rs
	
	dim impYn,brcod,CalSa
	
	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
''	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE, value1","CODE='EMPMOD'")
		rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE, value1","CODE='HOTRAW'")
	
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
		brcod = rs(1).value
		CalSa = rs(2).value
	end if
	
	dim rsBnk,objBnk,frmname,staccond
	rsBnk=server.CreateObject("adodb.recordset")
	objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsBnk=objBnk.singlerecordset("genbankparm","depcertificate","")
	
	if objBnk.ConnError="Connected" then	
		if not rsBnk.EOF and not rsBnk.BOF then
			frmname=rsBnk(0).value
		end if
	end if
	
	dim rsPimp,objPimp,PimpYn,PimpVal
	rsPimp=server.CreateObject("adodb.recordset")
	objPimp=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsPimp=objPimp.singlerecordset("GENCONFIGMST","IMPYN, value1","CODE='PFIMP'")
	
	if objPimp.ConnError="Connected" then	
		if not rsPimp.EOF and not rsPimp.BOF then
			PimpYn = rsPimp(0).value
			PimpVal = rsPimp(1).value
		end if
	end if
	
	dim obj1,rs1,esi 
	
	esi = 0
	
	obj1 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs1 = obj1.SingleRecordSet("EMPLOYERPARM","value","effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND code='ESI') AND empcode='EMP' AND code='ESI'")
	
	if not rs1.EOF and not rs1.BOF then
		esi = rs1(0).value
	end if
	
	dim obj2,rs2,pf
	
	pf = 0
	
	obj2 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs2 = obj2.SingleRecordSet("EMPLOYERPARM","value","effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND code='PF') AND empcode='EMP' AND code='PF'")
	
	if not rs2.EOF and not rs2.BOF then
		pf = rs2(0).value
	end if
	
	dim obj3,rs3,sPF,pfval,pflg, obj4,rs4,da,daval,daflg, obj5,rs5,ptxfm,ptxTo,ptxval,ptxflg, obj6,rs6,hra,hraval,hraflg, obj7,rs7,mr,mrval,mrflg, obj8,rs8,adv,adval,advflg, obj9,rs9, basval, basflg, obj10,rs10
	
	pfval = 0
	
	obj3 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs3 = obj3.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG","status='R' AND code='PF' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='PF')")
	
	if not rs3.EOF and not rs3.BOF then
		pfval = rs3(0).value
		pflg  = rs3(1).value
	end if
	
	obj4 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs4 = obj4.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG","status='R' AND code='DA' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='DA')")
	
	daval = 0
	
	if not rs4.EOF and not rs4.BOF then
		daval = rs4(0).value
		daflg  = rs4(1).value
	end if
	
	obj5 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs5 = obj5.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG","status='R' AND code='HRA' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='HRA')")
	
	hraval = 0
	
	if not rs5.EOF and not rs5.BOF then
		hraval = rs5(0).value
		hraflg  = rs5(1).value
	end if
	
	obj6 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	if frmname = "ELURU" then
		rs6 = obj6.SingleRecordSet("SALARYPARMST"," nvl(VALUE,0), FLAG, FROMAMT, TOAMT","status='R' AND code='PTAX' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='PTAX')") 
	elseif frmname = "MAHARAJA" then
		rs6 = obj6.SingleRecordSet("SALARYPARMST"," distinct nvl(VALUE,0), FLAG, FROMAMT, TOAMT","status='R' AND code='PTAX' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='PTAX')") 
	else
		rs6 = obj6.SingleRecordSet("SALARYPARMST"," nvl(VALUE,0), FLAG, FROMAMT, TOAMT","status='R' AND code='PTAX' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='PTAX')") 
	end if
	
	
	ptxval = 0
	if not rs6.EOF and not rs6.BOF then
		ptxval = rs6(0).value
		ptxflg  = rs6(1).value
		ptxfm =  rs6(2).value
		ptxTo = rs6(3).value
	end if
	
	obj9 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs9 = obj9.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG ","status='R' AND code='BASIC' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='BASIC')") 
	
	basval = 0
	if not rs9.EOF and not rs9.BOF then
		basval = rs9(0).value
		basflg  = rs9(1).value
	end if
	
	obj7 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs7 = obj7.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG ","status='R' AND code='MA' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='MA')") 
	
	mrval = 0
	if not rs7.EOF and not rs7.BOF then
		mrval = rs7(0).value
		mrflg  = rs7(1).value
	end if
	
	obj8 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rs8 = obj8.SingleRecordSet("SALARYPARMST","nvl(VALUE,0), FLAG ","status='R' AND code='ADV' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='ADV')") 
	
	adval = 0
	if not rs8.EOF and not rs8.BOF then
		adval = rs8(0).value
		advflg  = rs8(1).value
	end if

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>Employee Master</title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	
	<SCRIPT LANGUAGE=javascript>
	var strVal,strEsi,strPf
	
	strEsi = "<%=esi%>"
	strPf = "<%=pf%>"
	
	var SCal = "<%=CalSa%>"
	
	var Adv,Da,Gip,Hra,Ma,Oth,Pf,Ptax,bas,Othded,Othallow,Lic,stGrs
	var Totded, Grospay, Netpay
	
	
	var stPtx,stPtxfg,Ptxamt,stPamt,stPtoamt
		
		stPtx = "<%=ptxval%>"
		stPtxfg = "<%=ptxflg%>"
		stPamt = "<%=ptxfm%>"
		stPtoamt = "<%=ptxTo%>"
		
	var strBas,strBasfg	
		strBas = "<%=basval%>"
		strBasfg = "<%=basflg%>"
		
	var stP,stPg ,PFAmt
		
		stP = "<%=pfval%>"
		stPg = "<%=pflg%>"	
		
	var std,stdg,DAmt 
		
		std = "<%=daval%>"
		stdg = "<%=daflg%>"	
		
	var sthr,sthrg,Hramt
		
		sthr = "<%=hraval%>"
		sthrg = "<%=hraflg%>"
		
	var Pfimp,PfVa,Bnknm
		Pfimp = "<%=PimpYn%>"
		PfVa = "<%=PimpVal%>"
		Bnknm = "<%=frmname%>"
		
	
	function DispTranMsg()
	{
		var strtran
			strtran='<%=Request.QueryString("record")%>'
		
		if(strtran!="")
		{
			alert(strtran)
			window.location.href="http://"+"<%=session("moduledir")& "/ADMIN/frmEmploymast.aspx"%>"
		}
	}
	
	function checkImplement()
	{
		var IMP="<%=impYn%>"
		var BCOD="<%=brcod%>"
		var stBrcd = "<%=session("branchcode")%>"
		
		
		if(IMP=="Y")
		{
			if(BCOD == stBrcd)
			{
			
			}
			else
			{
				alert("You are Not Authorised Branch. \n Please Contact Main Branch")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}
			
			if(SCal == "GROSS")
			{
				window.document.all.divGenType.style.display="block"
				window.document.all.divGrosSal.style.display="block"
				window.document.all.divGenSal.style.display="none"
			}	
			
			else
			{
				window.document.all.divGenType.style.display="block"
				window.document.all.divGrosSal.style.display="none"
				window.document.all.divGenSal.style.display="block"
			}
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
	}
	
	function salary()
	{
		window.document.frmEmpMast.txtEmpsall.value=""
		window.document.frmEmpMast.txtEmpbasic.value=""
		window.document.frmEmpMast.txtEmppf.value=""
		window.document.frmEmpMast.txtEmpothded.value=""
		window.document.frmEmpMast.txtEmphra.value=""
		window.document.frmEmpMast.txtEmpprftax.value=""
		window.document.frmEmpMast.txtEmptotded.value=""
		window.document.frmEmpMast.txtEmpda.value=""
		window.document.frmEmpMast.chkGip.checked = false
		//window.document.frmEmpMast.txtEmplictax.value=""
		window.document.frmEmpMast.txtEmpgrospay.value=""
		window.document.frmEmpMast.txtEmpallow.value=""
		//window.document.frmEmpMast.txtEmpfestadv.value=""
		window.document.frmEmpMast.txtEmpnetpay.value=""
		//window.document.frmEmpMast.txtEmpGip.value=""
		window.document.frmEmpMast.txtEmpothallow.value=""
		window.document.frmEmpMast.txtEmpMr.value=""
		
		if(window.document.frmEmpMast.opt2(0).checked==true)
		{
			
			window.document.all.divGenType.style.display="block"
			window.document.all.divGenSal.style.display="block"
			window.document.all.divConSal.style.display="none"
		}
		if(window.document.frmEmpMast.opt2(1).checked==true)
		{
			window.document.all.divConSal.style.display="block"
			window.document.all.divGenSal.style.display="none"
			window.document.all.divGenType.style.display="none"
		}
		
	}
	
	function clearall()
	{
		window.document.frmEmpMast.txtEmpid.value=""
		window.document.frmEmpMast.txtCustid.value=""
		window.document.frmEmpMast.txtCustname.value=""
		window.document.frmEmpMast.txtUserid.value=""
		window.document.frmEmpMast.txtWorkBrcode.value=""
		window.document.frmEmpMast.txtWorkBrdesc.value=""
		//employ details
		window.document.frmEmpMast.txtEmpName.value=""
		window.document.frmEmpMast.selEmpDesig.value=""
		window.document.frmEmpMast.txtEmpdoa.value=""
		window.document.frmEmpMast.txtEmpdot.value=""
		window.document.frmEmpMast.txtEmpdop.value=""
		window.document.frmEmpMast.txtEmpdoc.value=""
		//Qualification details
		window.document.frmEmpMast.txtEmpqualif.value=""
		window.document.frmEmpMast.txtEmpTecqualif.value=""
		window.document.frmEmpMast.txtEmpOthqualif.value=""
		//acc details clear
		window.document.frmEmpMast.txtBrcode.value=""
		window.document.frmEmpMast.txtBrdesc.value=""
		window.document.frmEmpMast.txtModid.value=""
		window.document.frmEmpMast.txtModiddesc.value=""
		window.document.frmEmpMast.txtGlcode.value=""
		window.document.frmEmpMast.txtGlcodedesc.value=""
		window.document.frmEmpMast.txtAccNo.value=""
		window.document.frmEmpMast.txtAccNm.value=""
		//resign clear
		window.document.frmEmpMast.txtEmpletdat.value=""
		window.document.frmEmpMast.txtEmpleavdat.value=""
		window.document.frmEmpMast.txtEmpreason.value=""
		//salary clear
		window.document.frmEmpMast.txtEmpsall.value=""
		window.document.frmEmpMast.txtEmpbasic.value=""
		window.document.frmEmpMast.txtEmppf.value=""
		window.document.frmEmpMast.txtEmpothded.value=""
		window.document.frmEmpMast.txtEmphra.value=""
		window.document.frmEmpMast.txtEmpprftax.value=""
		window.document.frmEmpMast.txtEmptotded.value=""
		window.document.frmEmpMast.txtEmpda.value=""
		window.document.frmEmpMast.chkGip.checked=false
		window.document.frmEmpMast.chkEsi.checked=false
		window.document.frmEmpMast.chkVPF.checked=false
		window.document.all.divVpf.style.display="none"
		window.document.all.divTds.style.display="none"
		window.document.all.divEsi.style.display="none"
		//window.document.frmEmpMast.txtEmplictax.value=""
		window.document.frmEmpMast.txtEmpgrospay.value=""
		window.document.frmEmpMast.txtEmpallow.value=""
		//window.document.frmEmpMast.txtEmpfestadv.value=""
		window.document.frmEmpMast.txtEmpnetpay.value=""
		//window.document.frmEmpMast.txtEmpGip.value=""
		window.document.frmEmpMast.txtEmpothallow.value=""
		window.document.frmEmpMast.txtEmpMr.value=""
		window.document.frmEmpMast.txtEmpESi.value=""
		
		//for gross clear
		window.document.frmEmpMast.txtGrEmpgrospay.value=""
		window.document.frmEmpMast.txtGrEmpbasic.value=""
		window.document.frmEmpMast.txtGrEmphra.value=""
		window.document.frmEmpMast.txtGrEmpda.value=""
		window.document.frmEmpMast.txtGrEmpallow.value=""
		window.document.frmEmpMast.txtGrEmpMr.value=""
		window.document.frmEmpMast.txtGrEmpothallow.value=""
		window.document.frmEmpMast.txtGrEmpprftax.value=""
		window.document.frmEmpMast.txtGrEmppf.value=""
		window.document.frmEmpMast.txtGrEmpothded.value=""
		window.document.frmEmpMast.txtGrEmptotded.value=""
		window.document.frmEmpMast.txtGrEmpnetpay.value=""
		
	}
	function New()
	{
		clearall()
		window.document.all.divResign.style.display="none"
		
		window.document.frmEmpMast.txtCustid.disabled=false
		window.document.frmEmpMast.txtUserid.disabled=false
		window.document.frmEmpMast.txtCustname.disabled=false
		window.document.frmEmpMast.txtEmpName.disabled=false
		window.document.frmEmpMast.selEmpDesig.disabled=false
		window.document.frmEmpMast.txtEmpdoa.disabled=false
		window.document.frmEmpMast.txtEmpdot.disabled=false
		window.document.frmEmpMast.txtEmpdop.disabled=false
		window.document.frmEmpMast.txtEmpdoc.disabled=false
		window.document.frmEmpMast.txtEmpqualif.disabled=false
		window.document.frmEmpMast.txtEmpTecqualif.disabled=false
		window.document.frmEmpMast.txtEmpOthqualif.disabled=false
		window.document.frmEmpMast.txtEmpsall.disabled=false
		window.document.frmEmpMast.txtEmpbasic.disabled=false
		window.document.frmEmpMast.txtEmpda.disabled=false
		window.document.frmEmpMast.txtEmphra.disabled=false
		window.document.frmEmpMast.txtEmpallow.disabled=false
		window.document.frmEmpMast.txtEmpgrospay.disabled=false
		window.document.frmEmpMast.txtEmpprftax.disabled=false
		window.document.frmEmpMast.txtEmpMr.disabled=false
		//window.document.frmEmpMast.txtEmpfestadv.disabled=false
		window.document.frmEmpMast.txtEmpothded.disabled=false
		window.document.frmEmpMast.txtEmpothallow.disabled=false
		//window.document.frmEmpMast.txtEmplictax.disabled=false
		window.document.frmEmpMast.txtEmppf.disabled=false
		window.document.frmEmpMast.txtEmptotded.disabled=false
		window.document.frmEmpMast.txtEmpnetpay.disabled=false
		//window.document.frmEmpMast.txtEmpGip.disabled=false
		window.document.frmEmpMast.txtEmpleavdat.disabled=false
		window.document.frmEmpMast.txtEmpletdat.disabled=false
		window.document.frmEmpMast.txtEmpreason.disabled=false
		window.document.frmEmpMast.txtEpfno.disabled=false
		window.document.frmEmpMast.txtBrcode.disabled=false
		window.document.frmEmpMast.txtModid.disabled=false
		window.document.frmEmpMast.txtGlcode.disabled=false
		window.document.frmEmpMast.txtAccNo.disabled=false
		window.document.frmEmpMast.txtWorkBrcode.disabled=false
		window.document.frmEmpMast.txtWorkBrdesc.disabled=false
		window.document.frmEmpMast.txtBrdesc.disabled=false
		window.document.frmEmpMast.txtModiddesc.disabled=false
		window.document.frmEmpMast.txtGlcodedesc.disabled=false
		window.document.frmEmpMast.txtAccNm.disabled=false
		window.document.frmEmpMast.chkGip.disabled=false
		window.document.frmEmpMast.chkEsi.disabled=false
		window.document.frmEmpMast.chkVPF.disabled=false
		window.document.frmEmpMast.txtEmpESi.disabled=false
		window.document.frmEmpMast.txtEmpVpf.disabled=false
		//window.document.frmEmpMast.txtEmpVpfValue.disabled=false
		
		window.document.frmEmpMast.txtGrEmpgrospay.disabled=false
		window.document.frmEmpMast.txtGrEmpbasic.disabled=false
		window.document.frmEmpMast.txtGrEmphra.disabled=false
		window.document.frmEmpMast.txtGrEmpda.disabled=false
		window.document.frmEmpMast.txtGrEmpallow.disabled=false
		window.document.frmEmpMast.txtGrEmpMr.disabled=false
		window.document.frmEmpMast.txtGrEmpothallow.disabled=false
		window.document.frmEmpMast.txtGrEmpprftax.disabled=false
		window.document.frmEmpMast.txtGrEmppf.disabled=false
		window.document.frmEmpMast.txtGrEmpothded.disabled=false
		window.document.frmEmpMast.txtGrEmptotded.disabled=false
		window.document.frmEmpMast.txtGrEmpnetpay.disabled=false
		
		if(window.document.frmEmpMast.opt1(0).checked==true)
		{
			window.document.frmEmpMast.butEmpid.disabled=true
			window.document.frmEmpMast.butUserid.disabled=true
			window.document.frmEmpMast.cmdOk.disabled=false
			
		}
		if(window.document.frmEmpMast.opt1(1).checked==true)
		{
			window.document.frmEmpMast.butEmpid.disabled=false
			window.document.frmEmpMast.butUserid.disabled=false
			window.document.all.divResign.style.display="block"
			window.document.frmEmpMast.cmdOk.disabled=false
		}
		if(window.document.frmEmpMast.opt1(2).checked==true)
		{
			window.document.frmEmpMast.butEmpid.disabled=false
			window.document.frmEmpMast.butUserid.disabled=false
			window.document.all.divResign.style.display="block"
			
			window.document.frmEmpMast.txtCustid.disabled=true
			window.document.frmEmpMast.txtUserid.disabled=true
			window.document.frmEmpMast.txtCustname.disabled=true
			window.document.frmEmpMast.txtEmpName.disabled=true
			window.document.frmEmpMast.selEmpDesig.disabled=true
			window.document.frmEmpMast.txtEmpdoa.disabled=true
			window.document.frmEmpMast.txtEmpdot.disabled=true
			window.document.frmEmpMast.txtEmpdop.disabled=true
			window.document.frmEmpMast.txtEmpdoc.disabled=true
			window.document.frmEmpMast.txtEmpqualif.disabled=true
			window.document.frmEmpMast.txtEmpTecqualif.disabled=true
			window.document.frmEmpMast.txtEmpOthqualif.disabled=true
			window.document.frmEmpMast.txtEmpsall.disabled=true
			window.document.frmEmpMast.txtEmpbasic.disabled=true
			window.document.frmEmpMast.txtEmpda.disabled=true
			window.document.frmEmpMast.txtEmphra.disabled=true
			window.document.frmEmpMast.txtEmpallow.disabled=true
			window.document.frmEmpMast.txtEmpgrospay.disabled=true
			window.document.frmEmpMast.txtEmpprftax.disabled=true
			window.document.frmEmpMast.txtEmpMr.disabled=true
			//window.document.frmEmpMast.txtEmpfestadv.disabled=true
			window.document.frmEmpMast.txtEmpothded.disabled=true
			window.document.frmEmpMast.txtEmpothallow.disabled=true
			//window.document.frmEmpMast.txtEmplictax.disabled=true
			window.document.frmEmpMast.txtEmppf.disabled=true
			window.document.frmEmpMast.txtEmptotded.disabled=true
			window.document.frmEmpMast.txtEmpnetpay.disabled=true
			//window.document.frmEmpMast.txtEmpGip.disabled=true
			window.document.frmEmpMast.txtEmpleavdat.disabled=true
			window.document.frmEmpMast.txtEmpletdat.disabled=true
			window.document.frmEmpMast.txtEmpreason.disabled=true
			window.document.frmEmpMast.txtEpfno.disabled=true
			window.document.frmEmpMast.txtBrcode.disabled=true
			window.document.frmEmpMast.txtModid.disabled=true
			window.document.frmEmpMast.txtGlcode.disabled=true
			window.document.frmEmpMast.txtAccNo.disabled=true
			window.document.frmEmpMast.txtWorkBrcode.disabled=true
			window.document.frmEmpMast.txtWorkBrdesc.disabled=true
			window.document.frmEmpMast.txtBrdesc.disabled=true
			window.document.frmEmpMast.txtModiddesc.disabled=true
			window.document.frmEmpMast.txtGlcodedesc.disabled=true
			window.document.frmEmpMast.txtAccNm.disabled=true
			window.document.frmEmpMast.cmdOk.disabled=true
			window.document.frmEmpMast.chkGip.disabled=true
			window.document.frmEmpMast.chkEsi.disabled=true
			window.document.frmEmpMast.chkVPF.disabled=true
			window.document.frmEmpMast.txtEmpESi.disabled=true
			window.document.frmEmpMast.txtEmpVpf.disabled=true
			//window.document.frmEmpMast.txtEmpVpfValue.disabled=true
			
			window.document.frmEmpMast.txtGrEmpgrospay.disabled=true
			window.document.frmEmpMast.txtGrEmpbasic.disabled=true
			window.document.frmEmpMast.txtGrEmphra.disabled=true
			window.document.frmEmpMast.txtGrEmpda.disabled=true
			window.document.frmEmpMast.txtGrEmpallow.disabled=true
			window.document.frmEmpMast.txtGrEmpMr.disabled=true
			window.document.frmEmpMast.txtGrEmpothallow.disabled=true
			window.document.frmEmpMast.txtGrEmpprftax.disabled=true
			window.document.frmEmpMast.txtGrEmppf.disabled=true
			window.document.frmEmpMast.txtGrEmpothded.disabled=true
			window.document.frmEmpMast.txtGrEmptotded.disabled=true
			window.document.frmEmpMast.txtGrEmpnetpay.disabled=true
			
		}
		
	}
	function branch()
	{
		st="Tellerbranch";
		window.showModalDialog('<%="http://" & session("moduledir") & "/CUSTOMER/" %>'+"silist.aspx" + "?"+"st="+st,window,"status:no;"+"dialogWidth:300px;dialogHeight:170px;DialogLeft:120px;DialogTop:235px");
	}
	
	function Branchcode(kstr)
	{
		assign(kstr,window.document.frmEmpMast.txtWorkBrdesc,window.document.frmEmpMast.txtWorkBrcode)
	}

	function branches()
	{
		var branch="Branch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user
		
		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}

	function Branchid(kstr)
	{	
		assign(kstr,window.document.frmEmpMast.txtBrdesc,window.document.frmEmpMast.txtBrcode)
	}
	
	function Tellmodule()
	{
		if(window.document.frmEmpMast.txtBrcode.value=="")
		{
			alert("Please Select Branch Code.")
			return
		}
		stmod="Tellmodule"; 
		stbr=window.document.frmEmpMast.txtBrcode.value
		kstr=stmod+"|"+stbr
		
		window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
		
	function modulecode(kstr)
	{
		var strMod=kstr.split("-----")
		window.document.frmEmpMast.txtModid.value=strMod[1]
		window.document.frmEmpMast.txtModiddesc.value=strMod[0]
	}
		
	function TellerGl()
	{
		if(window.document.frmEmpMast.txtModid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmEmpMast.txtBrcode.value
		modid=window.document.frmEmpMast.txtModid.value
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmEmpMast.txtGlcodedesc,window.document.frmEmpMast.txtGlcode)
	}
		
	function Acccode()
	{
		if(window.document.frmEmpMast.txtGlcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		stacc="Telleraccno"
		brchCd=window.document.frmEmpMast.txtBrcode.value;
		ModId=window.document.frmEmpMast.txtModid.value.toUpperCase();
		GlCd=window.document.frmEmpMast.txtGlcode.value.toUpperCase();
		
		kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+'INR'+"|"+"='R'"
		
		window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
		"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	}

	function accountid(kstr)
	{
		assign(kstr,window.document.frmEmpMast.txtAccNm,window.document.frmEmpMast.txtAccNo)
	}
		
		///function for checking the number checking
	function numbercheck(strTxt)
	{

		var theNum=parseFloat(strTxt.value);
		if(isNaN(theNum)||theNum<0)
		{
			if(theNum<0)
			{
				alert("Enter Only Numbers and Shoud Not Be Less Than Zero")
			}
			strTxt.value=""
			return;
		}
		else
		{
			strTxt.value=theNum;
		}

	}
		
	function Custnew(kstr)
	{	
		newcustomer=kstr
			
		var brcode="<%=session("branchcode")%>"	 	
		var crcode="INR"
		var brnar="<%=session("branchnarration")%>"
		var crnar="INDIAN RUPEES"
		
		var queryst=brcode+"@@"+crcode+"@@"+brnar+"@@"+crnar
		window.open('<%="http://" & session("moduledir")& "/GEN/"%>'+"newcustomer.aspx?code="+queryst,"Customer","width=800,height=510 left=150 top=110")
			
	}
	
	function NewCustDisplay(kstr)
	{
		kstr=kstr.split("|")
		
		window.document.frmEmpMast.txtCustid.value=kstr[0]
		window.document.frmEmpMast.txtCustname.value=kstr[1]
		
		window.document.frmEmpMast.txtEmpName.value = kstr[1]
	}
	
	function Custold(butname)
	{
		if(butname=="butCustid")
		{
			st=butname+"~"+"<%=session("branchcode")%>"	
			
			window.showModalDialog('<%="http://" & session("moduledir")& "/GEN/"%>'+ "accnamecustlist.aspx" + "?"+"strbut="+st,window,"status:no;dialogWidth:490px;dialogHeight:210px;DialogLeft:130px;DialogTop:335px")
		}
		if(butname=="butEmpid")
		{
			if(window.document.frmEmpMast.opt1(1).checked==true)
			{
				st="EMPID"+"|"+"<%=session("branchcode")%>"+"|"+" STATUS='R' "
			}
			if(window.document.frmEmpMast.opt1(2).checked==true)
			{
				st="EMPID"+"|"+"<%=session("branchcode")%>"+"|"+" STATUS<>'N' "	
			}
			
			window.showModalDialog('<%="http://" & session("moduledir")& "/CUSTOMER/"%>'+ "silist.aspx" + "?"+"st="+st,window,
  "status:no;dialogWidth:440px;dialogHeight:170px");
		}
		
		if(butname=="butUserid")
		{
		
				st="USERID"+"|"+ window.document.frmEmpMast.txtEmpid.value

			
			window.showModalDialog('<%="http://" & session("moduledir")& "/CUSTOMER/"%>'+ "silist.aspx" + "?"+"st="+st,window,
  "status:no;dialogWidth:440px;dialogHeight:170px");
		}

	}

function GetUserID(kstr)
{
var empid
		empid = (kstr).split("-----")
		
		window.document.frmEmpMast.txtUserid.value=empid[1] 

}


	function getcustid(strcustid)
	{
		var strsplit		
		strsplit=(strcustid).split("~")
			
		if(strsplit[0]=="butCustid")
		{
			window.document.frmEmpMast.txtCustname.value = strsplit[2]
			window.document.frmEmpMast.txtCustid.value = strsplit[1]
			
			window.document.frmEmpMast.txtEmpName.value = strsplit[2]
		}

	}
	function EmpCode(kstr)
	{
		var empid
		empid = (kstr).split("-----")
		
		window.document.frmEmpMast.txtEmpid.value=empid[1] 
		
		strVal="EMPDETAILS"+"|"+window.document.frmEmpMast.txtEmpid.value+"|"+""
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		
	}
	
	function DescrptionDisp1(strTxt)
	{
		sBr=window.document.frmEmpMast.txtBrcode.value.toUpperCase()
		sCur="INR"
	
		if(strTxt=="txtModid")
		{
			if(window.document.frmEmpMast.txtModid.value=="")
			{
				alert("Enter Module Id")
				//window.document.frmEmpMast.txtModId.focus()
				return;
			}
			sMod=window.document.frmEmpMast.txtModid.value.toUpperCase()
		
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"'~~"+strTxt
		
		}
		///for Gl Code
		if(strTxt=="txtGlcode")
		{ 
			sMod=window.document.frmEmpMast.txtModid.value.toUpperCase()
			sGL=window.document.frmEmpMast.txtGlcode.value.toUpperCase()
			
			if(window.document.frmEmpMast.txtGlcode.value=="")
			{
				alert("Enter Gl Code")
				//window.document.frmEmpMast.txtGLcode.focus()
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
		}
		///for Accno
		
		if(strTxt=="txtAccNo")
		{ 
			sMod=window.document.frmEmpMast.txtModid.value.toUpperCase()
			sGL=window.document.frmEmpMast.txtGlcode.value.toUpperCase()
			sAccno=window.document.frmEmpMast.txtAccNo.value.toUpperCase()
			
			if(window.document.frmEmpMast.txtAccNo.value=="")
			{
				alert("Enter Acc.No")
				//window.document.frmEmpMast.txtAccNo.focus()
				return;
			}
			
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
			
		}
		//alert(st)
		window.document.all["iBatch"].src="../gensbca/querydisplay.aspx?st="+st	
	}
	
	function DescDisplay(stri)
	{
		var strtype=new String()
		strtype=stri.split("~")
		//for description displaying  split the values
		var StrArrFld=new String()
		StrArrFld=strtype[0].split("|")
		
		if(strtype[1]=="txtModid")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid ModuleId")
				window.document.frmEmpMast.txtModid.value=""
				window.document.frmEmpMast.txtModiddesc.value=""
				window.document.frmEmpMast.txtModid.focus()
				return;
			}
			window.document.frmEmpMast.txtModiddesc.value=StrArrFld[0]
			window.document.frmEmpMast.txtGlcode.value=""
			window.document.frmEmpMast.txtGlcodedesc.value=""
			window.document.frmEmpMast.txtAccNm.value=""
			window.document.frmEmpMast.txtAccNo.value=""
		}	
		if(strtype[1]=="txtGlcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid GL Code")
				window.document.frmEmpMast.txtGlcode.value=""
				window.document.frmEmpMast.txtGlcodedesc.value=""
				window.document.frmEmpMast.txtGlcode.focus()
				return;
			}
			window.document.frmEmpMast.txtGlcodedesc.value=StrArrFld[0]
			window.document.frmEmpMast.txtAccNm.value=""
			window.document.frmEmpMast.txtAccNo.value=""
		}
		///for accno
		if(strtype[1]=="txtAccNo")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Acc No")
				window.document.frmEmpMast.txtAccNo.value=""
				window.document.frmEmpMast.txtAccNm.value=""
				window.document.frmEmpMast.txtAccNo.focus()
				return;
			}
			window.document.frmEmpMast.txtAccNm.value=StrArrFld[0]
		}
	}
	
	function DescrptionDisp(name)
	{
		if(name=="txtEmpid")
		{
			if(window.document.frmEmpMast.opt1(1).checked==true)
			{
				strVal="EMPDETAILS"+"|"+window.document.frmEmpMast.txtEmpid.value+"|"+" and STATUS<>'N' "
			}
			if(window.document.frmEmpMast.opt1(2).checked==true)
			{
				strVal="EMPDETAILS"+"|"+window.document.frmEmpMast.txtEmpid.value+"|"+" and STATUS<>'N' "
			}
		
			window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		}
	}
	
	function getEmpDetail(str)
	{
		if(str=="")
		{
			alert("No Records Found")
			clearall()
			return;
		}
		var stDetail=str.split("~")
		
		if(window.document.frmEmpMast.opt1(1).checked==true)
		{
			if(stDetail[29]=="C")
			{
				alert("These Employee Id Closed")
				clearall()
				return;
			}
		}
			
		window.document.frmEmpMast.txtCustid.value = stDetail[0]
		window.document.frmEmpMast.txtUserid.value = stDetail[1]
		window.document.frmEmpMast.txtCustname.value = stDetail[2]
		window.document.frmEmpMast.txtEmpName.value = stDetail[2]
		window.document.frmEmpMast.selEmpDesig.value = stDetail[3]
		window.document.frmEmpMast.txtEmpdoa.value = stDetail[4]
		window.document.frmEmpMast.txtEmpdot.value = stDetail[5]
		window.document.frmEmpMast.txtEmpdop.value = stDetail[6]
		window.document.frmEmpMast.txtEmpdoc.value = stDetail[7]
		window.document.frmEmpMast.txtEmpqualif.value = stDetail[8]
		window.document.frmEmpMast.txtEmpTecqualif.value = stDetail[9]
		window.document.frmEmpMast.txtEmpOthqualif.value = stDetail[10]
		
		if(stDetail[11]!="0")
		{
			window.document.frmEmpMast.opt2(1).checked=true
			window.document.all.divConSal.style.display="block"
			window.document.all.divGenSal.style.display="none"
			window.document.frmEmpMast.txtEmpsall.value = stDetail[11]
		}
		else
		{
			window.document.frmEmpMast.opt2(0).checked=true
			window.document.all.divConSal.style.display="none"
			window.document.all.divGenType.style.display="block"
			
			if(SCal == "GROSS")
			{
				window.document.all.divGrosSal.style.display="block"
				window.document.all.divGenSal.style.display="none"
				window.document.frmEmpMast.txtGrEmpbasic.value = stDetail[12]
				window.document.frmEmpMast.txtGrEmpda.value = stDetail[13]
				window.document.frmEmpMast.txtGrEmphra.value = stDetail[14]
				window.document.frmEmpMast.txtGrEmpallow.value = stDetail[15]
				window.document.frmEmpMast.txtGrEmpMr.value = stDetail[16]
				window.document.frmEmpMast.txtGrEmpothallow.value = stDetail[17]
				window.document.frmEmpMast.txtGrEmpgrospay.value = stDetail[18]
				
				if(window.document.frmEmpMast.txtGrEmpgrospay.value>"15000")
				{
					window.document.frmEmpMast.chkEsi.disabled = true
					window.document.frmEmpMast.chkEsi.checked = false
					window.document.frmEmpMast.txtEmpESi.value = ""
					window.document.all.divEsi.style.display = "none"
				}
				else
				{	
					window.document.frmEmpMast.chkEsi.disabled=false
				}
				
				window.document.frmEmpMast.txtGrEmpprftax.value = stDetail[19]
				window.document.frmEmpMast.txtGrEmppf.value = stDetail[20]
				window.document.frmEmpMast.txtGrEmpothded.value = stDetail[21]
				window.document.frmEmpMast.txtGrEmptotded.value = stDetail[22]
				window.document.frmEmpMast.txtGrEmpnetpay.value = stDetail[23]
			
			}
			else
			{
				window.document.all.divGenSal.style.display="block"
				window.document.all.divGrosSal.style.display="none"
				window.document.frmEmpMast.txtEmpbasic.value = stDetail[12]
				window.document.frmEmpMast.txtEmpda.value = stDetail[13]
				window.document.frmEmpMast.txtEmphra.value = stDetail[14]
				window.document.frmEmpMast.txtEmpallow.value = stDetail[15]
				window.document.frmEmpMast.txtEmpMr.value = stDetail[16]
				window.document.frmEmpMast.txtEmpothallow.value = stDetail[17]
				window.document.frmEmpMast.txtEmpgrospay.value = stDetail[18]
				
				if(window.document.frmEmpMast.txtEmpgrospay.value>"15000")
				{
					window.document.frmEmpMast.chkEsi.disabled = true
					window.document.frmEmpMast.chkEsi.checked = false
					window.document.frmEmpMast.txtEmpESi.value = ""
					window.document.all.divEsi.style.display = "none"
				}
				else
				{	
					window.document.frmEmpMast.chkEsi.disabled=false
				}
				
				window.document.frmEmpMast.txtEmpprftax.value = stDetail[19]
				window.document.frmEmpMast.txtEmppf.value = stDetail[20]
				window.document.frmEmpMast.txtEmpothded.value = stDetail[21]
				window.document.frmEmpMast.txtEmptotded.value = stDetail[22]
				window.document.frmEmpMast.txtEmpnetpay.value = stDetail[23]
			}
			
			
			//window.document.frmEmpMast.txtEmpfestadv.value = stDetail[19]
			//window.document.frmEmpMast.txtEmplictax.value = stDetail[22]
			
			
			//window.document.frmEmpMast.txtEmpGip.value = stDetail[39]
		}
		
		if(stDetail[24]=="Y")
		{
			window.document.frmEmpMast.chkGip.checked = true
		}
		else
		{
			window.document.frmEmpMast.chkGip.checked = false
		}
		window.document.frmEmpMast.txtEmpletdat.value = stDetail[25]
		window.document.frmEmpMast.txtEmpleavdat.value = stDetail[26]
		window.document.frmEmpMast.txtEmpreason.value = stDetail[27]
		window.document.frmEmpMast.txtEpfno.value = stDetail[28]
		window.document.frmEmpMast.txtBrcode.value = stDetail[30]
		window.document.frmEmpMast.txtBrdesc.value = stDetail[31]
		window.document.frmEmpMast.txtModid.value = stDetail[32]
		window.document.frmEmpMast.txtModiddesc.value = stDetail[33]
		window.document.frmEmpMast.txtGlcode.value = stDetail[34]
		window.document.frmEmpMast.txtGlcodedesc.value = stDetail[35]
		window.document.frmEmpMast.txtAccNo.value = stDetail[36]
		window.document.frmEmpMast.txtWorkBrcode.value = stDetail[37]
		window.document.frmEmpMast.txtWorkBrdesc.value = stDetail[38]
		
		if(stDetail[39]=="Y")
		{
			var stVal
			
			window.document.frmEmpMast.chkEsi.checked = true
			window.document.all.divEsi.style.display="block"
				
			if(SCal == "GROSS")
			{
				stVal = parseInt(parseInt(window.document.frmEmpMast.txtGrEmpgrospay.value)*strEsi)/100
				window.document.frmEmpMast.txtEmpESi.value = stVal
				
				window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(window.document.frmEmpMast.txtGrEmpnetpay.value) -  parseInt(window.document.frmEmpMast.txtEmpESi.value)
			}
			else
			{
				mancalc()
				
				stVal = parseInt(parseInt(window.document.frmEmpMast.txtEmpgrospay.value)*strEsi)/100
				window.document.frmEmpMast.txtEmpESi.value = stVal
				
				window.document.frmEmpMast.txtEmpnetpay.value = parseInt(window.document.frmEmpMast.txtEmpnetpay.value) -  parseInt(window.document.frmEmpMast.txtEmpESi.value)
			
			}
			
		}
		else
		{
			window.document.frmEmpMast.chkEsi.checked = false
			window.document.all.divEsi.style.display="none"
			window.document.frmEmpMast.txtEmpESi.value = ""
		}
		
		if(stDetail[40]!="0")
		{
			window.document.frmEmpMast.chkVPF.checked = true
			window.document.all.divVpf.style.display = "block"
			window.document.frmEmpMast.txtEmpVpf.value = stDetail[40]
			vpfVale()
		}
		else
		{
			window.document.frmEmpMast.chkVPF.checked = false
			window.document.all.divVpf.style.display = "none"
			window.document.frmEmpMast.txtEmpVpf.value = ""
		}
		
		if(stDetail[41]!="0")
		{
			window.document.frmEmpMast.chkTds.checked = true
			window.document.all.divTds.style.display = "block"
			window.document.frmEmpMast.txtEmpTds.value = stDetail[41]
			TdsVale()
		}
		else
		{
			window.document.frmEmpMast.chkTds.checked = false
			window.document.all.divTds.style.display = "none"
			window.document.frmEmpMast.txtEmpTds.value = ""
		}
		
		if(stDetail[42]=="Y")
		{
		window.document.frmEmpMast.chkGratuity.checked = true
		}
		else
		{
		window.document.frmEmpMast.chkGratuity.checked = false
		}
		
		window.document.frmEmpMast.txtAccNm.value = stDetail[43]
	
	}
	
	
	function CustDtls(kstr)
	{
		var custid
		
		custid=window.document.frmEmpMast.txtCustid.value
		
		window.open('<%="http://" & session("moduledir")& "/GEN/"%>'+"newcustomer.aspx?custid=" + custid,"Customer","width=450%,height=620% left=300 top=110")
	}
	
	function Tellmodule()
	{
		if(window.document.frmEmpMast.txtBrcode.value=="")
		{
			alert("Please Select Branch Code.")
			return
		}
		stmod="Tellmodule"; 
		stbr=window.document.frmEmpMast.txtBrcode.value
		kstr=stmod+"|"+stbr
		
		window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}

	function modulecode(kstr)
	{
		var strMod=kstr.split("-----")
		window.document.frmEmpMast.txtModid.value=strMod[1]
		window.document.frmEmpMast.txtModiddesc.value=strMod[0]
	}
	function TellerGl()
	{
		if(window.document.frmEmpMast.txtModid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmEmpMast.txtBrcode.value
		modid=window.document.frmEmpMast.txtModid.value
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmEmpMast.txtGlcodedesc,window.document.frmEmpMast.txtGlcode)
	}

	function Acccode()
	{
		if(window.document.frmEmpMast.txtGlcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		stacc="Telleraccno"
		brchCd=window.document.frmEmpMast.txtBrcode.value;
		ModId=window.document.frmEmpMast.txtModid.value.toUpperCase();
		GlCd=window.document.frmEmpMast.txtGlcode.value.toUpperCase();
		
		kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+"INR"+"|"+"='R'"
		
		/*kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+"INR"
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		window.showModalDialog('<%="http://" & session("moduledir")& "/Customer/"%>'+"Silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")*/
		
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		{
   			window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
				"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   		}
   		else
   		{
   			alert('Select Branch code,Currency code,Module id and GL code.')
   		}
	}

	function accountid(kstr)
	{
		strsp=kstr.split("-----")
		window.document.frmEmpMast.txtAccNo.value=strsp[1]
		window.document.frmEmpMast.txtAccNm.value=strsp[0]
	}
	
	function Ok()
	{
		var chkGip,stChEsi,stVpf,sTd,stPay
		var strchkgratuity
		
		if((window.document.frmEmpMast.txtCustid.value=="")||(window.document.frmEmpMast.txtCustname.value==""))
		{
			alert("Please Select Customerid")
			window.document.frmEmpMast.txtCustid.focus();
			return;
		}
		
		
		
		if((window.document.frmEmpMast.txtWorkBrcode.value=="")||(window.document.frmEmpMast.txtWorkBrdesc.value==""))
		{
			alert("Please Enter Working Branch code")
			window.document.frmEmpMast.txtWorkBrcode.focus();
			return;
		}
		if(window.document.frmEmpMast.txtEmpName.value=="")
		{
			alert("Please Enter Employee Name")
			window.document.frmEmpMast.txtEmpName.focus();
			return;
		}
		
		if(window.document.frmEmpMast.selEmpDesig.options.value=="")
		{
			alert("Please Select Designation")
			return;
		}
		
		if(window.document.frmEmpMast.txtEmpdoa.value=="")
		{
			alert("Please Enter Date Of Appointment")
			window.document.frmEmpMast.txtEmpdoa.focus();
			return;
		}
		
		if(window.document.frmEmpMast.txtEmpdot.value=="")
		{
			alert("Please Enter Date Of Temporary")
			window.document.frmEmpMast.txtEmpdot.focus();
			return;
		}
		
		if(window.document.frmEmpMast.txtEmpqualif.value=="")
		{
			alert("Please Enter Qualification")
			window.document.frmEmpMast.txtEmpqualif.focus();
			return;
		}
		
		if(window.document.frmEmpMast.chkGip.checked==true)
		{
			chkGip = "Y"
		}
		else
		{
			chkGip = "N"
		}
		
		if(window.document.frmEmpMast.chkEsi.checked==true)
		{
			stChEsi = "Y"
		}
		else
		{
			stChEsi = "N"
		}
		
		if(window.document.frmEmpMast.chkVPF.checked==true)
		{
			stVpf = window.document.frmEmpMast.txtEmpVpf.value
		}
		else
		{
			stVpf = "0"
		}
		
		
		if(window.document.frmEmpMast.chkTds.checked==true)
		{
			sTd = window.document.frmEmpMast.txtEmpTds.value
		}
		else
		{
			sTd = "0"
		}
		
		if(window.document.frmEmpMast.chkGratuity.checked==true)
		{
			strchkgratuity = "Y"
		}
		else
		{
			strchkgratuity = "N"
		}
		
		if(window.document.frmEmpMast.opt2(0).checked==true)
		{
			if(SCal == "GROSS")
			{
				if((window.document.frmEmpMast.txtGrEmpgrospay.value=="")||(window.document.frmEmpMast.txtGrEmpgrospay.value=="0")||(window.document.frmEmpMast.txtGrEmpgrospay.value=="0.00"))
				{
					alert("Please Enter Gross Amount")
					window.document.frmEmpMast.txtGrEmpgrospay.focus();
					return;
				}
				if((window.document.frmEmpMast.txtGrEmpnetpay.value=="")||(window.document.frmEmpMast.txtGrEmpnetpay.value=="0")||(window.document.frmEmpMast.txtGrEmpnetpay.value=="0.00")||(window.document.frmEmpMast.txtGrEmpnetpay.value<="0.00"))
				{
					alert("Please Enter NETPAY Amount")
					window.document.frmEmpMast.txtGrEmpnetpay.focus();
					return;
				}
			}
			else
			{
			
				if((window.document.frmEmpMast.txtEmpbasic.value=="")||(window.document.frmEmpMast.txtEmpbasic.value=="0")||(window.document.frmEmpMast.txtEmpbasic.value=="0.00"))
				{
					alert("Please Enter Basic Amount")
					window.document.frmEmpMast.txtEmpbasic.focus();
					return;
				}
				
				if(window.document.frmEmpMast.txtEmphra.value=="")
				{
					alert("Please Enter HRA Amount")
					window.document.frmEmpMast.txtEmphra.focus();
					return;
				}
				
				if(window.document.frmEmpMast.txtEmpda.value=="")
				{
					alert("Please Enter HRA Amount")
					window.document.frmEmpMast.txtEmpda.focus();
					return;
				}
				
				if((window.document.frmEmpMast.txtEmpnetpay.value=="")||(window.document.frmEmpMast.txtEmpnetpay.value=="0")||(window.document.frmEmpMast.txtEmpnetpay.value=="0.00")||(window.document.frmEmpMast.txtEmpnetpay.value<="0.00"))
				{
					alert("Please Enter NETPAY Amount")
					window.document.frmEmpMast.txtEmpnetpay.focus();
					return;
				}
			}
		}
		if(window.document.frmEmpMast.opt2(1).checked==true)
		{	
			if((window.document.frmEmpMast.txtEmpsall.value=="")||(window.document.frmEmpMast.txtEmpsall.value=="0")||(window.document.frmEmpMast.txtEmpsall.value=="0.00")||(window.document.frmEmpMast.txtEmpsall.value<="0.00"))
			{
				alert("Please Enter NETPAY Amount")
				window.document.frmEmpMast.txtEmpsall.focus();
				return;
			}
			
		}
		// start bank details mandatory
		
					if(window.document.frmEmpMast.txtBrcode.value=="")
				{
					alert("Please Enter BranchCode")
					window.document.frmEmpMast.txtBrcode.focus();
					return;
				}
				
				if(window.document.frmEmpMast.txtModid.value=="")
				{
					alert("Please Enter Mod Code")
					window.document.frmEmpMast.txtModid.focus();
					return;
				}
				
				if(window.document.frmEmpMast.txtGlcode.value=="")
				{
					alert("Please Enter GL Code")
					window.document.frmEmpMast.txtGlcode.focus();
					return;
				}
				
				if(window.document.frmEmpMast.txtAccNo.value=="")
				{
					alert("Please Enter Acc No")
					window.document.frmEmpMast.txtAccNo.focus();
					return;
				}
				
		// end bank details mandatory
		
		if(SCal == "GROSS")
		{
			if(window.document.frmEmpMast.opt2(1).checked==true)
			{
				window.document.frmEmpMast.txtGrEmpgrospay.value = window.document.frmEmpMast.txtEmpsall.value
				window.document.frmEmpMast.txtGrEmpnetpay.value = window.document.frmEmpMast.txtEmpsall.value
			}
			
			stPay = window.document.frmEmpMast.txtGrEmpbasic.value.toUpperCase()+"|"+ //BASIC
					window.document.frmEmpMast.txtGrEmpda.value.toUpperCase()+"|"+ //DA
					window.document.frmEmpMast.txtGrEmphra.value.toUpperCase()+"|"+ //HRA
					window.document.frmEmpMast.txtGrEmpallow.value.toUpperCase()+"|"+ //ALLOWANCE
					window.document.frmEmpMast.txtGrEmpMr.value.toUpperCase()+"|"+ //MEDIREIMB
					window.document.frmEmpMast.txtGrEmpothallow.value.toUpperCase()+"|"+ //OTHERALLOWANCE
					window.document.frmEmpMast.txtGrEmpgrospay.value.toUpperCase()+"|"+ //GROSSPAY
					window.document.frmEmpMast.txtGrEmpprftax.value.toUpperCase()+"|"+ //PROFTAX
					window.document.frmEmpMast.txtGrEmppf.value.toUpperCase()+"|"+ //PROVFUND
					window.document.frmEmpMast.txtGrEmpothded.value.toUpperCase()+"|"+ //OTHERDEDUCT
					window.document.frmEmpMast.txtGrEmptotded.value.toUpperCase()+"|"+ //TOTALDEDUCT
					window.document.frmEmpMast.txtGrEmpnetpay.value.toUpperCase()//NETPAY
		}
		else
		{
			if(window.document.frmEmpMast.opt2(1).checked==true)
			{
				window.document.frmEmpMast.txtEmpgrospay.value = window.document.frmEmpMast.txtEmpsall.value
				window.document.frmEmpMast.txtEmpnetpay.value = window.document.frmEmpMast.txtEmpsall.value
			}
			
			stPay = window.document.frmEmpMast.txtEmpbasic.value.toUpperCase()+"|"+ //BASIC
					window.document.frmEmpMast.txtEmpda.value.toUpperCase()+"|"+ //DA
					window.document.frmEmpMast.txtEmphra.value.toUpperCase()+"|"+ //HRA
					window.document.frmEmpMast.txtEmpallow.value.toUpperCase()+"|"+ //ALLOWANCE
					window.document.frmEmpMast.txtEmpMr.value.toUpperCase()+"|"+ //MEDIREIMB
					window.document.frmEmpMast.txtEmpothallow.value.toUpperCase()+"|"+ //OTHERALLOWANCE
					window.document.frmEmpMast.txtEmpgrospay.value.toUpperCase()+"|"+ //GROSSPAY
					window.document.frmEmpMast.txtEmpprftax.value.toUpperCase()+"|"+ //PROFTAX
					window.document.frmEmpMast.txtEmppf.value.toUpperCase()+"|"+ //PROVFUND
					window.document.frmEmpMast.txtEmpothded.value.toUpperCase()+"|"+ //OTHERDEDUCT
					window.document.frmEmpMast.txtEmptotded.value.toUpperCase()+"|"+ //TOTALDEDUCT
					window.document.frmEmpMast.txtEmpnetpay.value.toUpperCase()//NETPAY

		}
		
		
		
		if(window.document.frmEmpMast.opt1(0).checked==true)
		{
			var str
			
			str = window.document.frmEmpMast.txtCustid.value.toUpperCase()+"|"+ //CUSTOMERID
					window.document.frmEmpMast.txtUserid.value.toUpperCase()+"|"+ //USERID
					window.document.frmEmpMast.txtEmpName.value.toUpperCase()+"|"+ //EMPNAME
					window.document.frmEmpMast.selEmpDesig.options[window.document.frmEmpMast.selEmpDesig.selectedIndex].value+"|"+ //DESGNCODE
					window.document.frmEmpMast.txtEmpdoa.value.toUpperCase()+"|"+ //APPOINTDT
					window.document.frmEmpMast.txtEmpdot.value.toUpperCase()+"|"+ //TEMPDT
					window.document.frmEmpMast.txtEmpdop.value.toUpperCase()+"|"+ //PERMENTDT
					window.document.frmEmpMast.txtEmpdoc.value.toUpperCase()+"|"+ //CONFIRMDT
					window.document.frmEmpMast.txtEmpqualif.value.toUpperCase()+"|"+ //EDUQUALIFY
					window.document.frmEmpMast.txtEmpTecqualif.value.toUpperCase()+"|"+ //TECQUALIFY
					window.document.frmEmpMast.txtEmpOthqualif.value.toUpperCase()+"|"+ //OTHERQUALIFY
					window.document.frmEmpMast.txtEmpsall.value.toUpperCase()+"|"+ //CONPAY
					stPay +"|"+ //Sal PAY
					chkGip +"|"+ //GIP
					window.document.frmEmpMast.txtEpfno.value.toUpperCase()+"|"+ //EPFACCNO
					window.document.frmEmpMast.txtBrcode.value.toUpperCase()+"|"+ //BRANCHCODE
					window.document.frmEmpMast.txtModid.value.toUpperCase()+"|"+ //MODULEID          
					window.document.frmEmpMast.txtGlcode.value.toUpperCase()+"|"+ //GLCODE            
					window.document.frmEmpMast.txtAccNo.value.toUpperCase()+"|"+ //ACCNO             
					window.document.frmEmpMast.txtWorkBrcode.value.toUpperCase()+"|"+  //WORKINGBRCODE
					stChEsi+"|"+//ESI
					stVpf+"|"+ //VPF
					sTd +"|"+//Tds
					strchkgratuity // gratuity
			str = "INSERT"+"~"+str
			
		}
		if(window.document.frmEmpMast.opt1(1).checked==true)
		{
			
			if(window.document.frmEmpMast.txtEmpleavdat.value!="")
			{
				status = "C"
			}
			else
			{
				status = "R"
			}
			
			str = window.document.frmEmpMast.txtEmpid.value.toUpperCase()+"|"+ //EMPCODE
					window.document.frmEmpMast.txtCustid.value.toUpperCase()+"|"+ //CUSTOMERID
					window.document.frmEmpMast.txtUserid.value.toUpperCase()+"|"+ //USERID
					window.document.frmEmpMast.txtEmpName.value.toUpperCase()+"|"+ //EMPNAME
					window.document.frmEmpMast.selEmpDesig.options[window.document.frmEmpMast.selEmpDesig.selectedIndex].value+"|"+ //DESGNCODE
					window.document.frmEmpMast.txtEmpdoa.value.toUpperCase()+"|"+ //APPOINTDT
					window.document.frmEmpMast.txtEmpdot.value.toUpperCase()+"|"+ //TEMPDT
					window.document.frmEmpMast.txtEmpdop.value.toUpperCase()+"|"+ //PERMENTDT
					window.document.frmEmpMast.txtEmpdoc.value.toUpperCase()+"|"+ //CONFIRMDT
					window.document.frmEmpMast.txtEmpqualif.value.toUpperCase()+"|"+ //EDUQUALIFY
					window.document.frmEmpMast.txtEmpTecqualif.value.toUpperCase()+"|"+ //TECQUALIFY
					window.document.frmEmpMast.txtEmpOthqualif.value.toUpperCase()+"|"+ //OTHERQUALIFY
					window.document.frmEmpMast.txtEmpsall.value.toUpperCase()+"|"+ //CONPAY
					stPay +"|"+ //Sal PAY
					chkGip +"|"+ //GIP
					window.document.frmEmpMast.txtEpfno.value.toUpperCase()+"|"+ //EPFACCNO
					window.document.frmEmpMast.txtBrcode.value.toUpperCase()+"|"+ //BRANCHCODE
					window.document.frmEmpMast.txtModid.value.toUpperCase()+"|"+ //MODULEID          
					window.document.frmEmpMast.txtGlcode.value.toUpperCase()+"|"+ //GLCODE            
					window.document.frmEmpMast.txtAccNo.value.toUpperCase()+"|"+ //ACCNO             
					window.document.frmEmpMast.txtWorkBrcode.value.toUpperCase()+"|"+  //WORKINGBRCODE 
					window.document.frmEmpMast.txtEmpletdat.value.toUpperCase()+"|"+
					window.document.frmEmpMast.txtEmpleavdat.value.toUpperCase()+"|"+
					window.document.frmEmpMast.txtEmpreason.value+"|"+status+"|"+
					stChEsi+"|"+//ESI
					stVpf+"|"+ //VPF
					sTd +"|"+//Tds
					strchkgratuity // gratuity
					
			str = "MODIFY"+"~"+str
		}
		
		//alert("str = "+str)
		
		if(window.document.frmEmpMast.txtUserid.value=="")
		{
			if (confirm("UserId Is Not Given \n Do You Want To Continue Y/N ")== true)
			{
				if(confirm("Are You Sure") == true)
				{
					window.document.frmEmpMast.empval.value=str
					window.document.frmEmpMast.action="EmploymstInst.aspx"
					window.document.frmEmpMast.method="post"   
					window.document.frmEmpMast.submit()
				}
				else
				{
					window.document.frmEmpMast.txtUserid.focus();
				}
			}
			else
			{
				window.document.frmEmpMast.txtUserid.focus();
			}
			/*window.document.frmEmpMast.txtUserid.focus();
			return;*/
		}
		else
		{
			window.document.frmEmpMast.empval.value=str
			window.document.frmEmpMast.action="EmploymstInst.aspx"
			window.document.frmEmpMast.method="post"   
			window.document.frmEmpMast.submit()
		} 
	}
	
	function calc()
	{
		if((window.document.frmEmpMast.txtEmpbasic.value=="0.00")||(window.document.frmEmpMast.txtEmpbasic.value=="0")||(window.document.frmEmpMast.txtEmpbasic.value==""))
		{
			alert("Please Enter the Basic Amount")
			window.document.frmEmpMast.txtEmpbasic.focus()
			return;
		}
		
		var bas = Math.round(window.document.frmEmpMast.txtEmpbasic.value)
		
		
		/*if(stPg == "P")
		{
			PFAmt = parseInt(bas)/100 * parseInt(stP) 
			
			if(PFAmt>"1800")
			{
				window.document.frmEmpMast.txtEmppf.value = PFAmt
			}
			else
			{
				window.document.frmEmpMast.txtEmppf.value = PFAmt
			}
		}
		else
		{
			PFAmt = parseInt(stP) 
			
			if(PFAmt>"1800")
			{
				window.document.frmEmpMast.txtEmppf.value = PFAmt
			}
			else
			{
				window.document.frmEmpMast.txtEmppf.value = PFAmt
			}
		}*/
		
		if(sthrg=="P")
		{
			Hramt = parseInt(bas)/100 * (sthr)
			
			window.document.frmEmpMast.txtEmphra.value = Math.round(Hramt)
		}
		else
		{
			Hramt = parseInt(sthr)
			
			window.document.frmEmpMast.txtEmphra.value = Math.round(Hramt)
		}
		
		if(stdg=="P")
		{
			DAmt = parseInt(bas)/100 * (std)
			
			window.document.frmEmpMast.txtEmpda.value =Math.round(DAmt)
		}
		else
		{
			DAmt = parseInt(std)
			
			window.document.frmEmpMast.txtEmpda.value = Math.round(DAmt)
		}
		
		
		if(Pfimp=="Y")
		{
			PFAmt = parseInt(bas)/100 * (strPf) 
				
			if(PFAmt>PfVa)
			{
				window.document.frmEmpMast.txtEmppf.value = PfVa
			}
			else
			{
				window.document.frmEmpMast.txtEmppf.value = Math.round(PFAmt)
			}
		}
		else
		{
			if (Bnknm == "ELURU")
			{
				PFAmt = parseInt(parseInt(bas)+parseInt(window.document.frmEmpMast.txtEmpda.value))/100 * (strPf) 
					
				window.document.frmEmpMast.txtEmppf.value = Math.round(PFAmt)
			}
			else
			{
				PFAmt = parseInt(bas)/100 * (strPf) 
				
				window.document.frmEmpMast.txtEmppf.value = Math.round(PFAmt)
			}
		}
		
		var Totded, Grospay, Netpay
		
		
		Grospay = parseInt(Math.round(window.document.frmEmpMast.txtEmpbasic.value)) + parseInt(Math.round(window.document.frmEmpMast.txtEmphra.value)) + parseInt(Math.round(window.document.frmEmpMast.txtEmpda.value)) + parseInt(Math.round(window.document.frmEmpMast.txtEmpothallow.value)) + parseInt(Math.round(window.document.frmEmpMast.txtEmpMr.value))
		
		var grs
		
		window.document.frmEmpMast.txtEmpgrospay.value = Math.round(Grospay)
		
		grs = Math.round(window.document.frmEmpMast.txtEmpgrospay.value)
		getPtax()
		/*if (Bnknm == "ELURU")
		{
			if(grs<=stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = "150"
			}
			else if(grs>stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtEmpprftax.value = "0"
			}
		}
		else
		{
			if(grs>=stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtEmpprftax.value = "0"
			}
		}*/
		
		Totded =  parseInt(Math.round(window.document.frmEmpMast.txtEmppf.value)) + parseInt(Math.round(window.document.frmEmpMast.txtEmpprftax.value)) 
		
		Netpay = parseInt(Math.round(Grospay)) - parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Math.round(Netpay))
		
		window.document.frmEmpMast.txtEmptotded.value = parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtEmpgrospay.value = parseInt(Math.round(Grospay))
		
	
	}
	
	function calGros()
	{
		if((window.document.frmEmpMast.txtGrEmpgrospay.value=="0.00")||(window.document.frmEmpMast.txtGrEmpgrospay.value=="0")||(window.document.frmEmpMast.txtGrEmpgrospay.value==""))
		{
			alert("Please Enter the Gross Amount")
			window.document.frmEmpMast.txtGrEmpgrospay.focus()
			return;
		}
		
		var sBaset
		
		if(strBasfg=="P")
		{
			sBaset = parseInt(window.document.frmEmpMast.txtGrEmpgrospay.value)/100 * parseInt(strBas)
			
			window.document.frmEmpMast.txtGrEmpbasic.value = Math.round(sBaset)
		}
		else
		{
			window.document.frmEmpMast.txtGrEmpbasic.value = Math.round(sBaset)
		}
		
		var bas = window.document.frmEmpMast.txtGrEmpbasic.value
		
		if(sthrg=="P")
		{
			Hramt = parseInt(window.document.frmEmpMast.txtGrEmpgrospay.value)/100 * parseInt(sthr)
			
			window.document.frmEmpMast.txtGrEmphra.value = Math.round(Hramt)
		}
		else
		{
			Hramt = parseInt(sthr)
			
			window.document.frmEmpMast.txtGrEmphra.value = Math.round(Hramt)
		}
		
		if(stdg=="P")
		{
			DAmt = parseInt(window.document.frmEmpMast.txtGrEmpgrospay.value)/100 * (std)
			
			window.document.frmEmpMast.txtGrEmpda.value = Math.round(DAmt)
		}
		else
		{
			DAmt = parseInt(std)
			
			window.document.frmEmpMast.txtGrEmpda.value = Math.round(DAmt)
		}
		
		/*PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * parseInt(strPf) 
			
		if(PFAmt>"1800")
		{
			window.document.frmEmpMast.txtGrEmppf.value = "1800"
		}
		else
		{
			window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
		}*/
		
		if(Pfimp=="Y")
		{
			PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * (strPf) 
				
			if(PFAmt>PfVa)
			{
				window.document.frmEmpMast.txtGrEmppf.value = PfVa
			}
			else
			{
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
		}
		else
		{
			if (Bnknm == "ELURU")
			{
				PFAmt = parseInt(parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)+parseInt(window.document.frmEmpMast.txtGrEmpda.value))/100 * (strPf) 
					
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
			else
			{
				PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * (strPf) 
				
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
		}
		
		var grs
		
		grs = window.document.frmEmpMast.txtGrEmpgrospay.value
		
		if (Bnknm == "ELURU")
		{
			if(window.document.frmEmpMast.txtGrEmpgrospay.value<=stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "150"
			}
			else if(window.document.frmEmpMast.txtGrEmpgrospay.value>stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "0"
			}
		}
		else
		{
			if(eval(window.document.frmEmpMast.txtGrEmpgrospay.value)>=stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "0"
			}
		}
		if(window.document.frmEmpMast.txtGrEmpallow.value=="")
		{
			window.document.frmEmpMast.txtGrEmpallow.value="0"
		}
		if(window.document.frmEmpMast.txtGrEmpothallow.value=="") 
		{
			window.document.frmEmpMast.txtGrEmpothallow.value="0"
		}
		if(window.document.frmEmpMast.txtGrEmpMr.value=="")
		{
			window.document.frmEmpMast.txtGrEmpMr.value="0"
		}
		
		if(window.document.frmEmpMast.txtGrEmppf.value=="") 
		{
			window.document.frmEmpMast.txtGrEmppf.value="0"
		}
		if(window.document.frmEmpMast.txtGrEmpprftax.value=="")
		{
			window.document.frmEmpMast.txtGrEmpprftax.value="0"
		}
		
		var Totded, Grospay, Netpay
		
		
		window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpbasic.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmphra.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpda.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpallow.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpothallow.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpMr.value))
		
		
		
		Totded =  parseInt(Math.round(window.document.frmEmpMast.txtGrEmppf.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpprftax.value)) 
		
		Netpay = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpnetpay.value)) - parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(Netpay))
		
		window.document.frmEmpMast.txtGrEmptotded.value = parseInt(Math.round(Totded))
		
		getPtax()
	
	}
	
	function getPtax()
	{
	
		if(SCal == "GROSS")
		{
			strVal="GETPTAXDTLS"+"|"+window.document.frmEmpMast.txtGrEmpgrospay.value
		}
		else
		{
			strVal="GETPTAXDTLS"+"|"+window.document.frmEmpMast.txtEmpgrospay.value
		}
	//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popPtax(str)
	{//alert("str = "+str)
		if(SCal == "GROSS")
		{
			if (Bnknm == "ELURU")
			{
				if(str == "0")
				{
					window.document.frmEmpMast.txtGrEmpprftax.value = "150"
				}
				else 
				{
					window.document.frmEmpMast.txtGrEmpprftax.value = str
				}
			}
			else
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = str
			}
		}
		else
		{
			if (Bnknm == "ELURU")
			{
				if(str == "0")
				{
					window.document.frmEmpMast.txtEmpprftax.value = "150"
				}
				else 
				{
					window.document.frmEmpMast.txtEmpprftax.value = str
				}
			}
			else
			{
				window.document.frmEmpMast.txtEmpprftax.value = str
			}
		}
	}
	/*function popSalParm(str)
	{
		var stDetail=str.split("|")
		
		//var Adv  = stDetail[0].split("~")
		
		var Da  = stDetail[1].split("~")
		
		//var Gip = stDetail[2].split("~")
		
		var Hra  = stDetail[3].split("~")
		
		var Ma = stDetail[4].split("~")
		
		var Oth = stDetail[5].split("~")
		
		//var Pf = stDetail[6].split("~")
		
		var Ptax = stDetail[7].split("~")
		
		var bas
		
		bas = window.document.frmEmpMast.txtEmpbasic.value
		
		if(Ma[2]=="P")
		{
			var medal
			
			medal = parseInt(bas)/100 * parseInt(Ma[1])
			
			window.document.frmEmpMast.txtEmpMr.value = medal
		}
		else
		{
			var medal
			
			medal = parseInt(Ma[1])
			
			window.document.frmEmpMast.txtEmpMr.value = medal
		}
		if(Oth[2]=="P")
		{
			var Other
			
			Other = parseInt(bas)/100 * parseInt(Oth[1])
			
			window.document.frmEmpMast.txtEmpothallow.value = Other
		}
		else
		{
			var Other
			
			Other = parseInt(Oth[1])
			
			window.document.frmEmpMast.txtEmpothallow.value = Other
		}
		if(Da[2]=="P")
		{
			var DAmt
			
			DAmt = parseInt(bas)/100 * parseInt(Da[1])
			
			window.document.frmEmpMast.txtEmpda.value = DAmt
		}
		else
		{
			var DAmt
			
			DAmt = parseInt(Da[1])
			
			window.document.frmEmpMast.txtEmpda.value = DAmt
		}
		if(Hra[2]=="P")
		{
			var Hramt
			
			Hramt = parseInt(bas)/100 * parseInt(Hra[1])
			
			window.document.frmEmpMast.txtEmphra.value = Hramt
		}
		else
		{
			var Hramt
			
			Hramt = parseInt(Hra[1])
			
			window.document.frmEmpMast.txtEmphra.value = Hramt
		}
		if(Pf[2]=="P")
		{
			var PFAmt
			
			//PFAmt = parseInt(bas)/100 * parseInt(Pf[1]) 
			
			PFAmt = parseInt(bas)/100 * parseInt(strPf;) 
			
			window.document.frmEmpMast.txtEmppf.value = PFAmt
		}
		else
		{
			var PFAmt
			
			PFAmt = parseInt(Pf[1]) 
			
			window.document.frmEmpMast.txtEmppf.value = PFAmt
		}
		if(Ptax[2]=="P")
		{
			var PtaxAmt
			
			PtaxAmt = parseInt(bas)/100 * parseInt(Ptax[1]) 
			
			window.document.frmEmpMast.txtEmpprftax.value = PtaxAmt
		}
		else
		{
			var PtaxAmt
			
			PtaxAmt = parseInt(Ptax[1]) 
			
			window.document.frmEmpMast.txtEmpprftax.value = PtaxAmt
		}
		
		var Totded, Grospay, Netpay
		
		Totded =  parseInt(PFAmt) + parseInt(PtaxAmt) 
		
		Grospay = parseInt(bas) + parseInt(Hramt) + parseInt(DAmt) + parseInt(Other) + parseInt(medal) 
		
		Netpay = parseInt(Grospay) - parseInt(Totded)
		
		
		window.document.frmEmpMast.txtEmptotded.value = parseInt(Totded)
		window.document.frmEmpMast.txtEmpgrospay.value = parseInt(Grospay)
		
		window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Netpay)
		
	}*/
	
	
		
	function Grosmancalc()
	{
		stGrs = window.document.frmEmpMast.txtGrEmpgrospay.value
		bas = window.document.frmEmpMast.txtGrEmpbasic.value
		DAmt = window.document.frmEmpMast.txtGrEmpda.value
		Hramt = window.document.frmEmpMast.txtGrEmphra.value
		medal = window.document.frmEmpMast.txtGrEmpMr.value 
		//Advan = window.document.frmEmpMast.txtEmpfestadv.value
		//Grip = window.document.frmEmpMast.txtEmpGip.value
		Oth = window.document.frmEmpMast.txtGrEmpallow.value 
		
		PFAmt = window.document.frmEmpMast.txtGrEmppf.value
		PtaxAmt = window.document.frmEmpMast.txtGrEmpprftax.value
		Othded = window.document.frmEmpMast.txtGrEmpothded.value
		Othallow = window.document.frmEmpMast.txtGrEmpothallow.value
		
		if(DAmt == "")
		{
			window.document.frmEmpMast.txtGrEmpda.value = 0
		}
		if(Hramt == "")
		{
			window.document.frmEmpMast.txtGrEmphra.value = 0
		}
		if(medal == "")
		{
			window.document.frmEmpMast.txtGrEmpMr.value = 0
		}
		if(PFAmt == "")
		{
			window.document.frmEmpMast.txtGrEmppf.value = 0
		}
		if(PtaxAmt == "")
		{
			window.document.frmEmpMast.txtGrEmpprftax.value = 0
		}
		if(Othded == "")
		{
			window.document.frmEmpMast.txtGrEmpothded.value = 0
		}
		if(Othallow == "")
		{
			window.document.frmEmpMast.txtGrEmpothallow.value = 0
		}
		if(Oth == "")
		{
			window.document.frmEmpMast.txtGrEmpallow.value = 0
		}
		
		/*PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * parseInt(strPf) 
			
		if(PFAmt>"1800")
		{
			window.document.frmEmpMast.txtGrEmppf.value = "1800"
		}
		else
		{
			window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
		}*/
		
		if(Pfimp=="Y")
		{
			PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * (strPf) 
				
			if(PFAmt>PfVa)
			{
				window.document.frmEmpMast.txtGrEmppf.value = PfVa
			}
			else
			{
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
		}
		else
		{
			if (Bnknm == "ELURU")
			{
				PFAmt = parseInt(parseInt(window.document.frmEmpMast.txtGrEmpbasic.value) + parseInt(window.document.frmEmpMast.txtGrEmpda.value))/100 * (strPf) 
					
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
			else
			{
				PFAmt = parseInt(window.document.frmEmpMast.txtGrEmpbasic.value)/100 * (strPf) 
				
				window.document.frmEmpMast.txtGrEmppf.value = Math.round(PFAmt)
			}
		}
		
		
		if(window.document.frmEmpMast.txtGrEmpgrospay.value>"15000")
		{
			window.document.frmEmpMast.txtEmpESi.value = ""
			window.document.frmEmpMast.chkEsi.disabled = true
			window.document.frmEmpMast.chkEsi.checked = false
			window.document.all.divEsi.style.display = "none"
		}
		else
		{	
			window.document.frmEmpMast.chkEsi.disabled=false
		}
		getPtax()
		
		//window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Netpay)
		
		/*if (Bnknm == "ELURU")
		{
			if(window.document.frmEmpMast.txtGrEmpgrospay.value<=stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "150"
			}
			else if(window.document.frmEmpMast.txtGrEmpgrospay.value>stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = stPtx
			}
			else
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "0"
			}
		}
		else
		{
			if(eval(window.document.frmEmpMast.txtGrEmpgrospay.value)>=stPamt)
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = stPtx
			}
			else
			{
				window.document.frmEmpMast.txtGrEmpprftax.value = "0"
			}
		}*/
		
		Totded = parseInt(Math.round(window.document.frmEmpMast.txtGrEmppf.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpprftax.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpothded.value))
		
		window.document.frmEmpMast.txtGrEmptotded.value = parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpbasic.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmphra.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpda.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpallow.value )) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpothallow.value)) + parseInt(Math.round(window.document.frmEmpMast.txtGrEmpMr.value))
		
		Netpay = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpnetpay.value)) - parseInt(Math.round(Totded))
		
		//window.document.frmEmpMast.txtEmpgrospay.value = parseInt(Grospay)
		
		window.document.frmEmpMast.txtGrEmpnetpay.value = Math.round(Netpay)
		
		if(window.document.frmEmpMast.txtEmpESi.value!="")
		{
			window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpESi.value))
		}
		if(window.document.frmEmpMast.txtEmpVpf.value!="")
		{
			window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpVpf.value))
		}
		if(window.document.frmEmpMast.txtEmpTds.value!="")
		{
			window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtGrEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpTds.value))
		}
	}
	
	
	function mancalc()
	{
		Adv,Da,Gip,Hra,Ma,Oth,Pf,Ptax
		
		bas = Math.round(window.document.frmEmpMast.txtEmpbasic.value)
		DAmt = Math.round(window.document.frmEmpMast.txtEmpda.value)
		Hramt = Math.round(window.document.frmEmpMast.txtEmphra.value)
		medal = Math.round(window.document.frmEmpMast.txtEmpMr.value)
		//Advan = window.document.frmEmpMast.txtEmpfestadv.value
		//Grip = window.document.frmEmpMast.txtEmpGip.value
		Oth = Math.round(window.document.frmEmpMast.txtEmpallow.value)
		
		PFAmt = Math.round(window.document.frmEmpMast.txtEmppf.value)
		PtaxAmt = Math.round(window.document.frmEmpMast.txtEmpprftax.value)
		Othded = Math.round(window.document.frmEmpMast.txtEmpothded.value)
		Othallow = Math.round(window.document.frmEmpMast.txtEmpothallow.value)
		//Lic = window.document.frmEmpMast.txtEmplictax.value
		
		
		if(DAmt == "")
		{
			DAmt = 0
		}
		if(Hramt == "")
		{
			Hramt = 0
		}
		if(medal == "")
		{
			medal = 0
		}
		if(PFAmt == "")
		{
			PFAmt = 0
		}
		if(PtaxAmt == "")
		{
			PtaxAmt = 0
		}
		if(Othded == "")
		{
			Othded = 0
		}
		if(Othallow == "")
		{
			Othallow = 0
		}
		/*if(Lic == "")
		{
			Lic = 0
		}*/
		if(Oth == "")
		{
			Oth = 0
		}
		
		Totded = parseInt(Math.round(PFAmt)) + parseInt(Math.round(PtaxAmt)) + parseInt(Math.round(Othded))
		
		Grospay = parseInt(Math.round(bas)) + parseInt(Math.round(Hramt)) + parseInt(Math.round(DAmt))+ parseInt(Math.round(Oth)) + parseInt(Math.round(Othallow)) + parseInt(Math.round(medal))
		
		Netpay = parseInt(Math.round(Grospay)) - parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtEmptotded.value = parseInt(Math.round(Totded))
		
		window.document.frmEmpMast.txtEmpgrospay.value = parseInt(Math.round(Grospay))
		
		if(window.document.frmEmpMast.txtEmpgrospay.value>"15000")
		{
			window.document.frmEmpMast.txtEmpESi.value = ""
			window.document.frmEmpMast.chkEsi.disabled = true
			window.document.frmEmpMast.chkEsi.checked = false
			window.document.all.divEsi.style.display = "none"
		}
		else
		{	
			window.document.frmEmpMast.chkEsi.disabled=false
		}
		
		window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Math.round(Netpay))
		
		getPtax()
		/*if (Bnknm == "ELURU")
		{
			if(Grospay<=stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = "150"
			}
			else if(Grospay>stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtEmpprftax.value = "0"
			}
		}
		else
		{
			if(Grospay>=stPamt)
			{
				window.document.frmEmpMast.txtEmpprftax.value = Math.round(stPtx)
			}
			else
			{
				window.document.frmEmpMast.txtEmpprftax.value = "0"
			}
		}*/
		
		
		
		if(window.document.frmEmpMast.txtEmpESi.value!="")
		{
			window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpESi.value))
		}
		if(window.document.frmEmpMast.txtEmpVpf.value!="")
		{
			window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpVpf.value))
		}
		if(window.document.frmEmpMast.txtEmpTds.value!="")
		{
			window.document.frmEmpMast.txtEmpnetpay.value = parseInt(Math.round(window.document.frmEmpMast.txtEmpnetpay.value))-parseInt(Math.round(window.document.frmEmpMast.txtEmpTds.value))
		}
	}
	
	function lecalrt()
	{
		if(window.document.frmEmpMast.txtEmpleavdat.value!="")
		{
			alert("DO you want to close these Employee ID")
			return;
		}
	}
	
	function VpfChk()
	{
		window.document.frmEmpMast.txtEmpVpf.value=""
		//window.document.frmEmpMast.txtEmpVpfValue.value=""
		
		if(window.document.frmEmpMast.chkVPF.checked==true)
		{
			window.document.all.divVpf.style.display="block"
		}
		else
		{
			if(SCal == "GROSS")
			{
				Grosmancalc()
			}
			else
			{
				mancalc()
			}
			window.document.all.divVpf.style.display="none"
		}
	
	}
	
	function vpfVale()
	{
		var stBas,stNet,stVpf,stVpval
		
		stVpf = window.document.frmEmpMast.txtEmpVpf.value
		
		if((stVpf =="0")||(stVpf==""))
		{
			alert("Please Enter the Minimum Value")
			window.document.frmEmpMast.txtEmpVpf.focus()
			return;
		}
		//window.document.frmEmpMast.txtEmpVpfValue.value = ""
		if(SCal == "GROSS")
		{
			Grosmancalc()
		}
		else
		{
			mancalc()
			
			stBas = window.document.frmEmpMast.txtEmpbasic.value
			stNet = window.document.frmEmpMast.txtEmpnetpay.value
		}
		
		//stVpval = parseInt(parseInt(stBas)*(stVpf))/100
		
		//window.document.frmEmpMast.txtEmpVpfValue.value = parseInt(stVpval)
		//window.document.frmEmpMast.txtEmpnetpay.value = parseInt(stNet) - parseInt(stVpval)
		
		//window.document.frmEmpMast.txtEmpnetpay.value = parseInt(stNet) - parseInt(stVpf)
	}
	
	function GratuityCheck()
	{
	strVal="GRATUITYCHECK"+"|"+window.document.frmEmpMast.txtEmpid.value+"|"+""
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function getGRATUITYCHECK(str)
	{
	var str1 = str.split("|")
		if (str1[0]=="NO")
		{
		alert(str1[1] + " Months NOT Eligible FOR Gratuity ")
		window.document.frmEmpMast.chkGratuity.checked = false
		}
	}
	
	function TdsChk()
	{
		window.document.frmEmpMast.txtEmpTds.value=""
		
		if(window.document.frmEmpMast.chkTds.checked==true)
		{
			window.document.all.divTds.style.display="block"
		}
		else
		{
			if(SCal == "GROSS")
			{
				Grosmancalc()
			}
			else
			{
				mancalc()
			}
			window.document.all.divTds.style.display="none"
		}
	}
	
	function TdsVale()
	{
		var stTds
		
		stTds = window.document.frmEmpMast.txtEmpTds.value
		
		if((stTds =="0")||(stTds==""))
		{
			alert("Please Enter the Minimum Value")
			window.document.frmEmpMast.txtEmpTds.focus()
			return;
		}
		
		if(SCal == "GROSS")
		{
			Grosmancalc()
		}
		else
		{
			mancalc()
		}
		
		
		//window.document.frmEmpMast.txtEmpnetpay.value = parseInt(window.document.frmEmpMast.txtEmpnetpay.value) - parseInt(stTds)
	}
	
	function EsiChk()
	{	
		window.document.frmEmpMast.txtEmpESi.value=""
		
		if(strEsi=="0")
		{
			alert("Please set ESI Parameter First")
			window.document.frmEmpMast.chkEsi.checked = false
			return;
		}
		
		if(SCal == "GROSS")
		{
			Grosmancalc()
		}
		else
		{
			mancalc()
		}
		if(window.document.frmEmpMast.chkEsi.checked==true)
		{
			window.document.all.divEsi.style.display="block"
			
			var stVal
			
			if(SCal == "GROSS")
			{
				stVal = parseInt(parseInt(window.document.frmEmpMast.txtGrEmpgrospay.value)*strEsi)/100
				window.document.frmEmpMast.txtEmpESi.value = stVal
				
				window.document.frmEmpMast.txtGrEmpnetpay.value = parseInt(window.document.frmEmpMast.txtGrEmpnetpay.value) -  parseInt(window.document.frmEmpMast.txtEmpESi.value)
			}
			else
			{
				stVal = parseInt(parseInt(window.document.frmEmpMast.txtEmpgrospay.value)*strEsi)/100
				window.document.frmEmpMast.txtEmpESi.value = stVal
				
				window.document.frmEmpMast.txtEmpnetpay.value = parseInt(window.document.frmEmpMast.txtEmpnetpay.value) -  parseInt(window.document.frmEmpMast.txtEmpESi.value)
			}
			
		}
		else
		{
			window.document.all.divEsi.style.display="none"
		}
	}
	
	function numcheck(strTxt)
	{	
		var theNum=parseFloat(strTxt.value);
		
		if(isNaN(theNum)||theNum<0)
		{
			alert("Enter Only Numbers and Shoud Not Be Less Than Zero")
			strTxt.value=""
			strTxt.focus()
			return;

		}
		else if(theNum<=0)
		{
			alert("Enter Minimum value")
			strTxt.value=""
			strTxt.focus()
			return;
		}
		else if(theNum>99.99)
		{
			alert("Maximum Value Can Be 99.99")
			strTxt.value=""
			strTxt.focus()
			return;
		}
		else
		{
			strTxt.value=theNum;
		}

	}
	</script>
	
	<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmEmpMast.txtEmpdoa.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpdoa.value=""
				window.document.frmEmpMast.txtEmpdoa.focus()
			}
			
			var intDiff1=getDateDiff(window.document.frmEmpMast.txtEmpdot.value, "<%=session("applicationdate")%>")
			
			if(intDiff1>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpdot.value=""
				window.document.frmEmpMast.txtEmpdot.focus()
			}
			
			var intDiff2=getDateDiff(window.document.frmEmpMast.txtEmpdop.value,"<%=session("applicationdate")%>")
			
			if(intDiff2>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpdop.value=""
				window.document.frmEmpMast.txtEmpdop.focus()
			}
			
			var intDiff3=getDateDiff(window.document.frmEmpMast.txtEmpdoc.value, "<%=session("applicationdate")%>")
			
			if(intDiff3>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpdoc.value=""
				window.document.frmEmpMast.txtEmpdoc.focus()
			}
			
			var intDiff4=getDateDiff(window.document.frmEmpMast.txtEmpletdat.value, "<%=session("applicationdate")%>")
			
			if(intDiff4>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpletdat.value=""
				window.document.frmEmpMast.txtEmpletdat.focus()
			}
			
			var intDiff5=getDateDiff(window.document.frmEmpMast.txtEmpleavdat.value, "<%=session("applicationdate")%>")
			
			if(intDiff5>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtEmpleavdat.value=""
				window.document.frmEmpMast.txtEmpleavdat.focus()
			}
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	</script>
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();checkImplement();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmEmpMast">
    
    <div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="40%" align="center" height="22" class="subHeader"><h2>Employee Master</h2></td>
				<td width="20%" height="22" align="right" class="subHeader"><%=appdate%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tblebordermain">
		<tr>
			<td width="100%">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" >
					<tr>
						<td width="100%" >
							<!--<div style="text-align:center; width:100%; font-weight:bold; color:blue;"><%=Request.QueryString("record")%></div>-->
							<div align="center">
							<center>
							<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor1">
												<td width="10%">
												<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>New&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">Modify&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="VIEW">View</font></td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							</center>
							</div>
							<div align="center">
								<center>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="15%" align="left">&nbsp;&nbsp;Emp ID :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtEmpid" onblur="DescrptionDisp(&quot;txtEmpid&quot;)" onkeypress="Alphanum()" size="10" style="TEXT-ALIGN: right"><font color="#000000"><input name="butEmpid" onclick="Custold('butEmpid')" type="button" value=" L " class="button" disabled></font></td>
										<td width="15%" align="right">&nbsp;&nbsp;Cust. ID&nbsp;&nbsp;</td>
										<td width="55%"><input name="txtCustid" class="txtautofill" onblur="DescrptionDisp(&quot;txtCustid&quot;)" onkeypress="Alphanum()" size="17" style="TEXT-ALIGN: right"><font color="#000000"><input name="butCustid" onclick="Custold('butCustid')" type="button" value=" L " class="button"></font><input name="txtCustname" readonly class="bgcolor1" size="20"><font color="#000000"><input name="butCustnew" onclick="Custnew('5')" type="button" value=" N " class="button"><input name="butCustdtls" onclick="CustDtls('6')" type="button" value=" D " class="button"></font></td>
									</tr>
									<tr>
										<td width="15%" align="left">&nbsp;&nbsp;User ID :&nbsp;&nbsp;</td>
										<td width="25%"><input name="txtUserid" onblur="DescrptionDisp(&quot;txtUserid&quot;)" onkeypress="Alphanum()" size="10" style="TEXT-ALIGN: right"><font color="#000000"><input name="butUserid" onclick="Custold('butUserid')" type="button" value=" L " class="button" disabled></font></td>
										<td width="15%" align="right">
										<p align="right">Working Branch Code&nbsp;&nbsp;</p></td>
										<td width="55%"><input name="txtWorkBrcode" size="17" readonly value="<%=session("branchcode")%>" class="txtautofill" ><input type="button" value=" L " name="cmdbranch" onclick="branch()" class="button"><input name="txtWorkBrdesc" size="16" readonly value="<%=session("branchnarration")%>" class="bgcolor1" >&nbsp;</td>
									</tr>
								</table>
								
								<!-----Employee Details Code--->
								<fieldset style="width:990px;">
								<legend><font color="blue">Employee Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="15%" align="left">&nbsp;&nbsp;Name &nbsp;&nbsp;</td>
										<td width="25%" colspan='3'><input name="txtEmpName" class="txtautofill"  onkeypress="Alphanum()" size="30"  maxlength='50' style="TEXT-ALIGN: left; TEXT-TRANSFORM: uppercase;" readonly></td>
										<td width="10%" align="right">&nbsp;&nbsp;Designation &nbsp;&nbsp;</td>
										<!--<td width="13%"><input name="txtEmpDesig" class="txtautofill"  onkeypress="Alphanum()" size="12" maxlength='50' style="TEXT-ALIGN: left"></td>--->
										<%
										dim rsKYC, objKYC

											rsKYC=server.CreateObject("adodb.recordset")
											objKYC=server.CreateObject("queryrecordsets.fetchrecordsets")
											rsKYC=objKYC.singlerecordset("GENDESIGNATIONMST","DISTINCT CODE, DESCRIPTION","","to_number(CODE)")
									
									%>
										<td width="13%"><select name="selEmpDesig">
										<option value="" selected >Select</option>
										<%
										if objKYC.ConnError="Connected" then
											if not rsKYC.BOF and not rsKYC.EOF then
												do until rsKYC.EOF
										%>
										<option value="<%=rsKYC(0).value%>"><%=rsKYC(1).value%></option>
										<%		
												rsKYC.movenext()
												loop
											end if
										end if
										%>
										</select></td>
										<td width="20%" colspan='3'>&nbsp;&nbsp;UID No : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtEpfno" onkeypress="numdec(window.document.frmEmpMast.txtEpfno.value)" size="10" maxlength='20' style="TEXT-ALIGN: left"></td>
									</tr>
									<tr>
										<td width="10%" align="left">&nbsp;&nbsp;<asp:Label ID="Label2" runat="server" Text="DOA" ToolTip="Date Of Appointment" ></asp:Label> &nbsp;&nbsp;</td>
										<td width="10%"><input name="txtEmpdoa" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpdoa.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"></td>
										<td width="10%" align="center">&nbsp;&nbsp;<asp:Label ID="Label1" runat="server" Text="DOT" ToolTip="Date Of Temporary" ></asp:Label> &nbsp;&nbsp;</td>
										<td width="10%"><input name="txtEmpdot" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpdot.value)" size="12" maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"></td>
										<td width="10%" align="right">&nbsp;&nbsp;<asp:Label ID="Label3" runat="server" Text="DOP" ToolTip="Date Of Permanent" ></asp:Label>  &nbsp;&nbsp;</td>
										<td width="13%"><input name="txtEmpdop" onkeypress="numdec(window.document.frmEmpMast.txtEmpdop.value)" size="12" maxlength='12' style="TEXT-ALIGN: right" onblur="datecheck(this)"></td>
										<td width="10%" align="left">&nbsp;&nbsp;<asp:Label ID="Label4" runat="server" Text="DOC" ToolTip="Date Of Confirm" ></asp:Label> &nbsp;&nbsp;</td>
										<td width="13%"><input name="txtEmpdoc" onkeypress="numdec(window.document.frmEmpMast.txtEmpdoc.value)" size="12" maxlength='12' style="TEXT-ALIGN: right" onblur="datecheck(this)"></td>
										<td width="14%">(DDMMYYYY)</td>
									</tr>
								</table>	
								</fieldset>
								<!-----Education Details Code--->
								<fieldset style="width:990px;">
								<legend><font color="blue">Education Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="15%" align="left">&nbsp;&nbsp;Qualification </td>
										<td width="25%" ><input name="txtEmpqualif" class="txtautofill"  onkeypress="Alphanum()" size="30" maxlength='50' style="TEXT-ALIGN: left"></td>
										<td width="15%" align="right">Technical  Qualification&nbsp;&nbsp;</td>
										<td width="55%" ><input name="txtEmpTecqualif" onkeypress="Alphanum()" size="30" style="TEXT-ALIGN: left" maxlength='50'></td>
									</tr>
									<tr class="bgcolor">
										<td width="15%" align="left">&nbsp;&nbsp;Other Qualification</td>
										<td width="25%" ><input name="txtEmpOthqualif" onkeypress="Alphanum()" size="30" style="TEXT-ALIGN: left" maxlength='50'></td>
									</tr>
								</table>	
								</fieldset>
								<!-----Salary Details Code--->
								<fieldset style="width:990px;">
								<legend><font color="blue">Salary Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="100%">
											<table border="0" width="100%">
												<tr>
													<td width="100%"><p align="center"><font class="textblack"><input type="radio" value="GENERAL" name="opt2" onclick="salary()" checked>General&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="CONSOLIDATE" name="opt2" onclick="salary()">Consolidate&nbsp;</font></p></td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td width="100%">
											<table border="0" width="100%">
												<tr>
													<td width="100%">
													<div id="divGenType"  style="display:block">
														<div id="divGenSal"  style="display:block">
												<table border="0" width="100%" cellspacing="0" cellpadding="0">
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Basic &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpbasic" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpbasic.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpbasic);precision(window.document.frmEmpMast.txtEmpbasic,window.document.frmEmpMast.hpr.value);calc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;HRA  &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmphra" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmphra.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmphra);precision(window.document.frmEmpMast.txtEmphra,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;DA/CA &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpda" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpda.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpda);precision(window.document.frmEmpMast.txtEmpda,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Allowance &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpallow" onkeypress="numdec(window.document.frmEmpMast.txtEmpallow.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpallow);precision(window.document.frmEmpMast.txtEmpallow,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;MR &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpMr" onkeypress="numdec(window.document.frmEmpMast.txtEmpMr.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpMr);precision(window.document.frmEmpMast.txtEmpMr,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Other Allowance &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpothallow" onkeypress="numdec(window.document.frmEmpMast.txtEmpothallow.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpothallow);precision(window.document.frmEmpMast.txtEmpothallow,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Prof Tax &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpprftax" onkeypress="numdec(window.document.frmEmpMast.txtEmpprftax.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpprftax);precision(window.document.frmEmpMast.txtEmpprftax,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;PF &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmppf" onkeypress="numdec(window.document.frmEmpMast.txtEmppf.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmppf);precision(window.document.frmEmpMast.txtEmppf,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Other Deduct  &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpothded" onkeypress="numdec(window.document.frmEmpMast.txtEmpothded.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpothded);precision(window.document.frmEmpMast.txtEmpothded,window.document.frmEmpMast.hpr.value);mancalc();"></td>
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Gross Pay &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpgrospay" Readonly onkeypress="numdec(window.document.frmEmpMast.txtEmpgrospay.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpgrospay);precision(window.document.frmEmpMast.txtEmpgrospay,window.document.frmEmpMast.hpr.value);"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Total Deduct &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmptotded" Readonly onkeypress="numdec(window.document.frmEmpMast.txtEmptotded.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmptotded);precision(window.document.frmEmpMast.txtEmptotded,window.document.frmEmpMast.hpr.value);"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Net Pay &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtEmpnetpay" readonly class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpnetpay.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpnetpay);precision(window.document.frmEmpMast.txtEmpnetpay,window.document.frmEmpMast.hpr.value);"></td>
																</tr>
															</table>
														</td>
													</tr>
												</table>
												</div>
												
												<div id="divGrosSal"  style="display:none">
												<table border="0" width="100%" cellspacing="0" cellpadding="0">
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Gross Pay &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpgrospay" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtGrEmpgrospay.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpgrospay);precision(window.document.frmEmpMast.txtGrEmpgrospay,window.document.frmEmpMast.hpr.value);calGros();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Basic &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpbasic" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtGrEmpbasic.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpbasic);precision(window.document.frmEmpMast.txtGrEmpbasic,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;HRA  &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmphra" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtGrEmphra.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmphra);precision(window.document.frmEmpMast.txtGrEmphra,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;DA/CA &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpda" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtGrEmpda.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpda);precision(window.document.frmEmpMast.txtGrEmpda,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Allowance &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpallow" onkeypress="numdec(window.document.frmEmpMast.txtGrEmpallow.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpallow);precision(window.document.frmEmpMast.txtGrEmpallow,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;MR &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpMr" onkeypress="numdec(window.document.frmEmpMast.txtGrEmpMr.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpMr);precision(window.document.frmEmpMast.txtGrEmpMr,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Other Allowance &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpothallow" onkeypress="numdec(window.document.frmEmpMast.txtGrEmpothallow.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpothallow);precision(window.document.frmEmpMast.txtGrEmpothallow,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Prof Tax &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpprftax" onkeypress="numdec(window.document.frmEmpMast.txtGrEmpprftax.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpprftax);precision(window.document.frmEmpMast.txtGrEmpprftax,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;PF &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmppf" onkeypress="numdec(window.document.frmEmpMast.txtGrEmppf.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmppf);precision(window.document.frmEmpMast.txtGrEmppf,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td width="100%">
															<table border="0" width="100%">
																<tr>
																	<td width="10%" align="right">&nbsp;&nbsp;Other Deduct  &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpothded" onkeypress="numdec(window.document.frmEmpMast.txtGrEmpothded.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpothded);precision(window.document.frmEmpMast.txtGrEmpothded,window.document.frmEmpMast.hpr.value);Grosmancalc();"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Total Deduct &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmptotded" Readonly onkeypress="numdec(window.document.frmEmpMast.txtGrEmptotded.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmptotded);precision(window.document.frmEmpMast.txtGrEmptotded,window.document.frmEmpMast.hpr.value);"></td>
																	<td width="10%" align="right">&nbsp;&nbsp;Net Pay &nbsp;&nbsp;</td>
																	<td width="13%"><input name="txtGrEmpnetpay" readonly class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtGrEmpnetpay.value,window.document.frmEmpMast.hpr.value)" size="12" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtGrEmpnetpay);precision(window.document.frmEmpMast.txtGrEmpnetpay,window.document.frmEmpMast.hpr.value);"></td>
																</tr>
															</table>
														</td>
													</tr>
												</table>
												</div>
												
												
												<table border="0" width="100%">
													<tr>
														<td width="3%" align="right">&nbsp;&nbsp;GIP &nbsp;&nbsp;<input type="checkbox" name="chkGip" id="chkGip" ></td>
														<td width="3%" align="right">&nbsp;&nbsp;ESI&nbsp;&nbsp;<input type="checkbox" name="chkEsi" id="chkEsi" onclick="EsiChk()"></td>
														<td width="5%">
															<div id="divEsi"  style="display:none">
																<table border="0" width="100%">
																	<tr>
																		<td><input name="txtEmpESi" class="txtautofill"  size="5" style="TEXT-ALIGN: right" readonly></td>
																	</tr>
																</table>
															</div>
														</td>
														<td width="3%" align="right">&nbsp;&nbsp;VPF&nbsp;&nbsp;<input type="checkbox" name="chkVPF" id="chkVPF" onclick="VpfChk()"></td>
														<td width="5%">
															<div id="divVpf"  style="display:none">
																<table border="0" width="100%">
																	<tr>
																		<td><input name="txtEmpVpf" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpVpf.value,window.document.frmEmpMast.hpr.value)" size="5" style="TEXT-ALIGN: right" onblur="precision(window.document.frmEmpMast.txtEmpVpf,window.document.frmEmpMast.hpr.value);vpfVale();">
																		<!--%  <input name="txtEmpVpfValue" class="txtautofill" style="TEXT-ALIGN: right" size="5" readonly> -->
																		</td>
																	</tr>
																</table>
															</div>
														</td>
														<td width="3%" align="right">&nbsp;&nbsp;TDS&nbsp;&nbsp;<input type="checkbox" name="chkTds" id="chkTds" onclick="TdsChk()"></td>
														<td width="5%" align="right">
															<div id="divTds"  style="display:none">
																<table border="0" width="100%">
																	<tr>
																		<td><input name="txtEmpTds" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtEmpTds.value,window.document.frmEmpMast.hpr.value)" size="5" style="TEXT-ALIGN: right" onblur="precision(window.document.frmEmpMast.txtEmpTds,window.document.frmEmpMast.hpr.value);TdsVale();">
																		<!--%  <input name="txtEmpVpfValue" class="txtautofill" style="TEXT-ALIGN: right" size="5" readonly> -->
																		</td>
																	</tr>
																</table>
															</div>
														</td>
														<td width="5%" align="right">&nbsp;&nbsp;Gratuity&nbsp;&nbsp;<input type="checkbox" name="chkGratuity" id="chkGratuity" onclick="GratuityCheck()"></td>
														<td width="5%" align="right">&nbsp;&nbsp;</td>
													</tr>
												</table>
												
												</div>
												
												<div id="divConSal"  style="display:none">
													<table border="0" width="100%" cellspacing="0" cellpadding="0">
														<tr>
															<td width="10%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;</td>
															<td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;</td>
															<td width="10%" align="right">&nbsp;&nbsp;Net Pay :&nbsp;&nbsp;</td>
															<td width="13%"><input name="txtEmpsall" onkeypress="numdec(window.document.frmEmpMast.txtEmpsall.value,window.document.frmEmpMast.hpr.value)" size="12" class="txtautofill" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmEmpMast.txtEmpsall);precision(window.document.frmEmpMast.txtEmpsall,window.document.frmEmpMast.hpr.value);"></td>
															<td width="10%" align="right">&nbsp;&nbsp;&nbsp;&nbsp;</td>
															<td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;</td>
														</tr>
													</table>
												</div>
													
													</td>
												</tr>
											</table>
										</td>
									</tr>
									
								</table>
								</fieldset>
								
								<!---- Bank Acc Details ----->
								<fieldset style="width:990px;">
								<legend><font color="blue">Bank A/C Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="15%" align="right">
										<p align="left">&nbsp;&nbsp;Branch Code</p></td>
										<td width="25%"><input name="txtBrcode" size="10" readonly value="<%=session("branchcode")%>" ><input type="button" value=" L " name="cmdbranch" onclick="branches()" class="button"><input name="txtBrdesc" size="23" readonly value="<%=session("branchnarration")%>" >&nbsp;</td>
										<td width="15%"><P align="right">Module Id&nbsp;&nbsp;</P></td>
										<td width="55%"><FONT color=#000000 size=2><INPUT onkeypress=Alphanum() onblur="DescrptionDisp1('txtModid')" style="TEXT-TRANSFORM: uppercase" maxLength=16 onchange="return txtdbtmodid_onchange()" size=16 name=txtModid ><INPUT class=button onclick=Tellmodule() type=button value=" L " name=butdbtmodid><INPUT readOnly type=text size=20 name=txtModiddesc ></FONT></td>
									</tr>
									<tr>
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;GL Code</P></td>
										<td width="25%"><FONT color=#000000 size=2 ><INPUT onkeypress=Alphanum() onblur="DescrptionDisp1('txtGlcode')" style="TEXT-TRANSFORM: uppercase" type=text maxLength=6 onchange="return txtdbtglcode_onchange()" size=10 name=txtGlcode ><INPUT class=button onclick=TellerGl() type=button value=" L " name=butdbtglcode><INPUT readOnly type=text size=23 name=txtGlcodedesc ></FONT></td>
										<td width="15%"><P align="right">Acc.No&nbsp;&nbsp;</P></td>
										<td width="55%"><INPUT onkeypress=Alphanum() onblur="DescrptionDisp1('txtAccNo')" type=text maxLength=16 size=16 name=txtAccNo><INPUT class=button onclick=Acccode() type=button value=" L " name=butdbtaccno><INPUT  readOnly type=text size=20 name=txtAccNm ></td>
									
									</tr>
								</table>
								</fieldset>
								
								<!-----Resign Code--->
								<div id="divResign" style="display:none">
								<fieldset style="width:990px;">
								<legend><font color="blue">Resign Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td width="15%" align="left">&nbsp;&nbsp;Letter Date &nbsp;&nbsp;</td>
										<td width="25%"><input name="txtEmpletdat" onkeypress="Alphanum()" size="12" style="TEXT-ALIGN: right" onblur="datecheck(this)"></td>
										<td width="10%" align="left">&nbsp;&nbsp;Leaving Date &nbsp;&nbsp;</td>
										<td width="60%"><input name="txtEmpleavdat" onkeypress="Alphanum()" size="12" style="TEXT-ALIGN: right" onblur="lecalrt();datecheck(this);">&nbsp;(DDMMYYYY)</td>
									</tr>
									<tr>
										<td width="15%" align="left">&nbsp;&nbsp;Reason &nbsp;&nbsp;</td>
										<td width="25%" colspan='3'><input name="txtEmpreason"  onkeypress="Alphanum()" size="50" style="TEXT-ALIGN: left"></td>
									</tr>
								</table>
								</fieldset>
								</div>
								</center>
							</div> 
							<div align="center" id="Employdeta">
							
							
							
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	
	<table width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 1003px"  class="tablebordermain">
		<tr >
			<td width="100%" align="center" ><input name="cmdOk" onclick="Ok()" type="button" value="    Ok    " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmEmploymast.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
		</tr>
  </table>
	
	<input type="hidden" name="hmod" value="<%=session("module")%>">
	<input type="hidden" name="hpr" value="<%=session("precision")%>">
	<input type="hidden" name="status">
	<input type="hidden" name="hidaccstatus">
	<input type="hidden" name="hidAbb">
	<input type="hidden" name="empval">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="../gensbca/querydisplay.aspx"></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>
