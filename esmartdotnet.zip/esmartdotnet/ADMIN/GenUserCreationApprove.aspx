<%@ Page Language="vb" CodeBehind="GenUserCreationApprove.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenUserCreationApprove" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreationApprove.ASP							*
'*	Purpose	  	     : To Approve new,modified and deleted users		  	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<%
abb=session("Abbuser")
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>User Creation Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE=javascript>
<!--
// to refresh the contents of screen
function Cancel()
{
location.href ="GenUserCreationApprove.aspx"
}                                                                                          

// If cmdApprove button is pressed call this function
function Approve()
{
	// enable txtuserid text box to extract the value from genusercreationtrans.aspx
	if(window.document.frmUserCreation.status.value!="")
		window.document.frmUserCreation.status.value=""
	else
		return
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.status.value="APPROVE"
	window.document.frmUserCreation.action="GenUserCreationDBOper.ASPX"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
}

//// this fucntion is called when branch list button is pressed
function branch()
{   
	// send Branch string to LIST.aspx
	st="Branch"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Branchid(kstr)
{
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  window.document.frmUserCreation.txtBrdesc.value=kstr[0]
	 	  window.document.frmUserCreation.txtBrcode.value=kstr[1]
	 	  	
}



// If cmdApprove button is pressed call this function
function Reject()
{
	if(window.document.frmUserCreation.status.value!="")
		window.document.frmUserCreation.status.value=""
	else
		return
	// enable txtuserid text box to extract the value from genusercreationtrans.aspx
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.status.value="REJECT"
	window.document.frmUserCreation.action="GenUserCreationDBOper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
}

function Abbcheck()
{
var abb="<%=abb%>"
if (abb.toUpperCase()=="Y")
{
	window.document.frmUserCreation.cmdbranch.disabled=false
	window.document.frmUserCreation.txtBrcode.readonly=false
}
else
{
	window.document.frmUserCreation.cmdbranch.disabled=true
	window.document.frmUserCreation.txtBrcode.readonly=true
	
}
}

//to get branchcode description 

///function for sending parameters to display the description on blur event
function DescrptionDisp(strTxt)
{
 if(strTxt=="txtbranchcode")
	{ 
		if(window.document.frmUserCreation.txtBrcode.value=="")
		 {
			return;
		 }
		st="DescDisplay~GENBANKBRANCHMST~"+"NARRATION~branchcode='"+
		window.document.frmUserCreation.txtBrcode.value+"'~~"+strTxt
	}
	window.document.all["iBatch"].src="../Gen/reportdisplay.aspx?st="+st	
}

 ///selcted code which is returned in tfrmae page
function DescDisplay(stri)
{
 //alert(stri)
var strtype=new String()
 strtype=stri.split("~")
//for description displaying  split the values
var StrArrFld=new String()
//var StrArrFlds=new String()
 StrArrFld=strtype[0].split("|")

///for Branchcode
	if(strtype[1]=="txtbranchcode")
	{
		if(StrArrFld[0]=="No")
		{
			alert("Invalid Acc No")
			window.document.frmUserCreation.txtBrcode.value=""
			window.document.frmUserCreation.txtBrdesc.value=""
			return;
		}
		window.document.frmUserCreation.txtBrdesc.value=StrArrFld[0]
	}
}

/// To clear All the required fields
function Clear()
{
	window.document.frmUserCreation.txtAddress.value=""
	window.document.frmUserCreation.txtAddress1.value=""
	window.document.frmUserCreation.txtCity.value=""
	window.document.frmUserCreation.txtDesig.value=""
	window.document.frmUserCreation.txtEmail.value=""
	window.document.frmUserCreation.txtUserName.value=""
	window.document.frmUserCreation.txtEmpcode.value=""
	window.document.frmUserCreation.txtUserID.value=""
	window.document.frmUserCreation.txtBio.value=""
	window.document.frmUserCreation.txtpwd.value=""
	window.document.frmUserCreation.txtMacid.value=""

}


function DispMacid()
{
if(window.document.frmUserCreation.chkmacid.checked==true)
	{
	window.document.all.spmacid.style.display="block"
	window.document.frmUserCreation.txtMacid.style.visibility="visible"
	}
else if(window.document.frmUserCreation.chkmacid.checked==false)
	{
	window.document.all.spmacid.style.display="none"
	window.document.frmUserCreation.txtMacid.style.visibility="hidden"
	}
	window.document.frmUserCreation.txtMacid.value=""
}
function Gendisplay()
{
	// Sending userid to genuserdetails.aspx
	st=window.document.frmUserCreation.txtUserID.value 
	window.document.all['iBatch'].src="GenUserDetails.aspx?st="+st 
}


function GenDisp(kstr)
  {
  // Get the informatin from GenUSerDetails.ASPX
  var Str1
  // split the string based on "+}" delimeter
  Str1=kstr.split("+}")
  
  // Display it
  window.document.frmUserCreation.txtBrcode.value=Str1[0]
 // window.document.frmUserCreation.txtBio.value=Str1[1] 
  window.document.frmUserCreation.txtGrcode.value=Str1[2]
  window.document.frmUserCreation.txtGrdesc.value=Str1[3]
  window.document.frmUserCreation.txtDesig.value=Str1[4]
  window.document.frmUserCreation.txtAddress.value=Str1[5]
  window.document.frmUserCreation .txtAddress1.value=Str1[6]
  window.document.frmUserCreation.txtCity.value=Str1[7]
  window.document.frmUserCreation.txtEmail.value=Str1[8]
 if(Str1[9].length>2)
	window.document.frmUserCreation.chkmacid.checked=true
  else
	window.document.frmUserCreation.chkmacid.checked=false
  window.document.frmUserCreation.txtMacid.value=Str1[9]
  window.document.frmUserCreation.txtSessions.value=Str1[10]
  window.document.frmUserCreation.txtBrdesc.value=Str1[15]
  window.document.frmUserCreation.txtEmpcode.value=Str1[13]
  
   
  if(Str1[14]=="Y")
	window.document.frmUserCreation.chkAbb.checked=true
  else
	window.document.frmUserCreation.chkAbb.checked=false
	
  
   if(window.document.frmUserCreation.txtGrcode.value=="ADMIN")
		{
		window.document.all.spsessions.style.display="block"
		window.document.frmUserCreation.txtSessions.style.visibility="visible"
		}
  else
		{
		window.document.all.spsessions.style.display="none"
		window.document.frmUserCreation.txtSessions.style.visibility="hidden"
		}
  DispMacid()
  window.document.frmUserCreation.txtMacid.value=Str1[9]
  }

// Calling list
function QueryList()
{
	Clear()
	if (window.document.frmUserCreation.opt1(0).checked==true)
		window.document.frmUserCreation.status.value ="XNEW"
	else if (window.document.frmUserCreation.opt1(1).checked==true)
		window.document.frmUserCreation.status.value ="MODIFY"	
	else if (window.document.frmUserCreation.opt1(2).checked==true)
		window.document.frmUserCreation.status.value ="DELETE"	
	
	
	// Send Query to LIST.ASP to get the users list
	st="Query"+window.document.frmUserCreation.status.value+ "|" +
			window.document.frmUserCreation.txtBrcode.value
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
}

function DisplayQuery(kstr)
{
	// Display the selected fields from list
	if (kstr=="No Data Found...")
		return
	assign(kstr,window.document.frmUserCreation.txtUserName,
	window.document.frmUserCreation.txtUserID )
	Gendisplay()
	// Enable and disable the fields
	//window.document.frmUserCreation.cmdreject.disabled=false
	window.document.frmUserCreation.txtUserID.disabled=true
	window.document.frmUserCreation.txtBio.disabled=true
	window.document.frmUserCreation.txtpwd.disabled= true
	
	window.document.frmUserCreation.txtEmpcode.disabled= true
	//window.document.frmUserCreation.cmdapprove.disabled= false
	
	window.document.frmUserCreation.cmdGroup.disabled=true
}



//-->
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Abbcheck()">

<form name="frmUserCreation">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="2%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>approval of user creation</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>
  <table width="100%" cellspacing="0" cellpadding="0" height="460" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="427">
        <tr>
          <td height="28" colspan="3">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="187%" height="28"></td>
              <td width="2%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
              </table>

              </td>
            </tr>
          </table>
</tr>
        <tr>
              <td width="100%" colspan="3" align="center" height="15">
              <p align="center" style="font-weight:bold; color:blue;"><%=Request.QueryString("record")%></p>
              </td>
            </tr>
        <tr>
          <td width="100%" height="29" colspan="3">
          <div align="center">
            <center>

            <table border="0" width="96%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="20%" align="left">&nbsp;&nbsp;Branch Code&nbsp;
                &nbsp;</td>
                <td width="36%"><input name="txtBrcode" readonly size="9" value="<%=session("branchcode")%>" onblur="DescrptionDisp(&quot;txtbranchcode&quot;)" class="txtautofill" ><input type="button" value=" L " name="cmdbranch" class="button" onclick="branch()"><input name="txtBrdesc" size="16" readonly value="<%=session("branchnarration")%>" class="bgcolor1" ></td>
                <td width="54%" align="right">Group
                Code&nbsp;&nbsp;</td>
                <td width="32%" align="right"><input name="txtGrcode" size="9" readonly  class="txtautofill" ><input type="button" value=" L " name="cmdGroup" class="button" ><input name="txtGrdesc" size="16" readonly class="bgcolor1" ></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
          <div align="center">
            <center>

            <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%">

                <table width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
                  <tr class="bgcolor1">
                    <td width="33%">
                    <p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="QueryList()">
                    New&nbsp;</font></p>
                    </td>
                    <td width="34%">
                    <p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="QueryList()">
                    Modify&nbsp;</font></p>
                    </td>
                    <td width="39%">
                    <p align="center"><font class="textblack"><input name="opt1" onclick="QueryList()" type="radio" value="DELETE">
                    &nbsp;Delete&nbsp;</font></p>
                    </td>
                  </tr>
                </table>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" valign="top" height="10"></td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" height="242">
                    <div align="center">

                      <table width="64%" cellpadding="0" class="tableborder1">
                        <tr>
                          <td width="100%">

                          <table border="0" width="466" cellspacing="0" cellpadding="0" height="308">
                            <tr class="bgcolor">
                              <td width="464" colspan="4" height="18"><font class="subheading">&nbsp;User
                              Information</font></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;User Name</td>
                              <td width="266" height="25" colspan="3"><input name="txtUserName" size="32" class="bgcolor1"  style="TEXT-TRANSFORM: uppercase;"   readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;User ID</td>
                              <td width="266" height="25" colspan="3"><input name="txtUserID" size="32" style="TEXT-TRANSFORM: uppercase;"  class="bgcolor1" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Password</td>
                              <td width="266" height="25" colspan="3"><input name="txtpwd" size="32" disabled></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Second Password</td>
                              <td width="266" height="25" colspan="3"><input type="password" name="txtBio" size="32" disabled></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Employee Code</td>
                              <td width="101" height="25"><input name="txtEmpcode" class="bgcolor1" style="TEXT-TRANSFORM: capitalize;"  size="13" readonly></td>

            </center>
                              <td width="108" height="25">
                                <p align="right">ABB User Y/N&nbsp;&nbsp;&nbsp;</td>
            <center>

                              <td width="53" height="25"><input type="checkbox" name="chkAbb" disabled value="ON"></td>
                            </tr>
                            <tr>
                              <td width="464" colspan="4" height="27">
                                <table border="0" cellpadding="0" cellspacing="0" width="460">
                                  <tr>
                                    <td width="226" height="23">&nbsp;Restricted to a
                                Single Machine&nbsp;&nbsp;&nbsp; <input type="checkbox" name="chkmacid" disabled onclick="DispMacid()" value="ON">&nbsp;</td>
                                    <td valign="middle" width="102"><span id="spsessions" style="display:none">No. Of
                                Sessions&nbsp;</span></td>
                                    <td width="126" height="23"><input  name="txtSessions" readonly size="12" maxlength="2" style="visibility:hidden"></td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td width="196" height="25"><span id="spmacid" style="display:none">&nbsp;Machine ID&nbsp;</span></td>
                              <td width="266" height="25" colspan="3"><input name="txtMacid" style="TEXT-TRANSFORM: capitalize;"  readonly size="32" maxlength="30" style="visibility:hidden"></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="464" colspan="4" height="13"><font class="subheading">&nbsp;Personal
                              Information</font></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Designation</td>
                              <td width="266" height="25" colspan="3"><input name="txtDesig" class="bgcolor1" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Address</td>
                              <td width="266" height="25" colspan="3"><input name="txtAddress" class="bgcolor1" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25"></td>
                              <td width="266" height="25" colspan="3"><input name="txtAddress1" class="bgcolor1" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                              <td width="266" height="25" colspan="3"><input name="txtCity" class="bgcolor1" style="TEXT-TRANSFORM: capitalize;"  size="32" readonly></td>
                            </tr>
                            <tr>
                              <td width="196" height="25" align="right">
                              <p align="left">&nbsp;E-mail ID</p>
                              </td>
                              <td width="266" height="25" colspan="3"><input name="txtEmail" size="32" readonly></td>
                            </tr>
                          </table>

                          </td>
                        </tr>
                      </table>

                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" height="10" colspan="3"><center></center></td>
        </tr>
        <tr>
          <td width="100%" height="32" colspan="3"><center>
          <div align="center">
            <center>

            <table width="37%" cellspacing="0" cellpadding="0" style="height: 28px" class="tablebordermain">
              <tr>
                <td width="350">
                <p align="center"><input name="cmdok" onclick="Approve()" type="button" value=" Approve" class="button"><input name="cmdok1" onclick="Reject()" type="button" value=" Reject " class="button"><input name="cmdCancel" onclick="Cancel()" type="button" value="Cancel" class="button"><input name="cmdexit" class="button" type="button" value="   Exit   "  onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></p>
                </td>
              </tr>
            </table>

            </center>
          </div>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="10"></td>
            </tr>
          </table>

          </center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="status">
  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.aspx">
           </iframe>

          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>
<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="">
                                              </iframe>
</body>

</html>
