<%@ Page Language="vb" CodeBehind="GenWorkAllotmentApproval.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotmentApproval" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Work Allotment Approval</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<script language="javascript">
<!--

function hh()
{
alert("sd")
window.parent.window.document.frames(0).src="GenWorkAllotModuleID.aspx"
window.parent.window.document.frames(0).href="GenWorkAllotModuleID.aspx"
window.parent.window.document.frames(1).frmforms.reset()
}
function branch()
 {
 
	st="Branch"
	   window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	window.document.frmworkallot.txtuserid.value=""
	window.document.frmworkallot.txtuserdesc.value=""
	
 }
function Branchid(kstr)
	 { 
	 	  if (kstr=="No Data Found...")
			return
	 	  kstr=kstr.split("-----")
	 	  window.document.frmworkallot.txtbrdesc.value=kstr[0]
	 	  window.document.frmworkallot.txtbrcode.value=kstr[1]
	 	  if(kstr[2]=="HO")
	 	  	  window.document.frmworkallot.radgroup(0).disabled=false
	 	  else
	 	  	 window.document.frmworkallot.radgroup(0).disabled=true
	 	    window.document.all.imod.src="GenWorkAllotModuleID.aspx"
     		window.parent.frames(1).frmforms.action="GenWorkAllotFormIDApproval.aspx"
			window.parent.frames(1).frmforms.method="post"
			window.parent.frames(1).frmforms.submit()
	 } 
	 
	 
	 
function User()
{
 if ((window.document.frmworkallot.txtbrcode.value=="") || (window.document.frmworkallot.txtbrdesc.value==""))
    {
			alert('Select Branch Code...!')
			return
    }
 if (window.document.frmworkallot.radgroup(0).checked==true)
       {
		   st="AppGroupid"
		    window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
		}
 else if (window.document.frmworkallot.radgroup(1).checked==true)
  {
	 args=window.document.frmworkallot.txtbrcode.value 
	 st="Work1"+args
	 window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
  }
  
  window.document.frmworkallot.cmdDisplay.disabled=false
  }


function UserCode(kstr)
    { 
      if (kstr=="No Data Found...")
			return
      assign(kstr,window.document.frmworkallot.txtuserdesc ,window.document.frmworkallot.txtuserid)

      window.document.all.imod.src="GenWorkAllotModuleID.aspx"
	  window.parent.frames(1).frmforms.action="GenWorkAllotFormIDApproval.aspx"
	  window.parent.frames(1).frmforms.method="post"
	  window.parent.frames(1).frmforms.submit()
      module()
    }
 
function module()
     {     
		if(window.document.frmworkallot.radgroup(0).checked==true)
			varo="group"
		else if(window.document.frmworkallot.radgroup(1).checked==true)
			varo="user"
		
			
			
			vars=window.document.frmworkallot.txtbrcode.value + "|" + window.document.frmworkallot.txtuserid.value +"|"+varo
			varst=vars 
			window.document.frames(0).frmmodule.hden.value=varst
			window.document.frames(0).frmmodule.action="GenWorkAllotModuleIDApproval.aspx"
			window.document.frames(0).frmmodule.method="post"
			window.document.frames(0).frmmodule.submit()
      }
      


      

	

function Display()
{
var vara
vara=false;
if(checknulls()==false)
return
if (parent.frames(0).frmmodule.optmoduleid.length>1)
{
vars=""
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)
{
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
	{
		vars=vars + "," +(parent.frames(0).frmmodule.optmoduleid(i).value)
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value 
		if(window.document.frmworkallot.radgroup(0).checked==true)
		{ 
		varo="group"
		}
		else if(window.document.frmworkallot.radgroup(1).checked==true)
		{
		varo="user"
		}
		
		varst="query" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		
		parent.frames(1).frmforms.hform.value=varst
		parent.frames(1).frmforms.action="GenWorkAllotFormIDApproval.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
	}
	window.document.frmworkallot.hmodule.value=vars
}
}
else
{
vars=","
if(parent.frames(0).frmmodule.optmoduleid.checked==true)
	{
		vars=vars+(parent.frames(0).frmmodule.optmoduleid.value);
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value 
		if(window.document.frmworkallot.radgroup(0).checked==true)
		{ 
		varo="group"
		}
		else if(window.document.frmworkallot.radgroup(1).checked==true)
		{
		varo="user"
		}
		
		varst="query" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		
		parent.frames(1).frmforms.hform.value=varst
		parent.frames(1).frmforms.action="GenWorkAllotFormIDApproval.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
	}
	window.document.frmworkallot.hmodule.value=vars


}

		if(vara!=true)
		{	
		alert('Select any one')	
		return
		}
		window.document.frmworkallot.cmdOk.disabled=false
		//window.document.frmworkallot.cmdreject.disabled=false


}

	
	
	
	
	


function group()
{
   window.document.all.imod.src="GenWorkAllotModuleID.aspx"
   if (window.document.frmworkallot.radgroup(0).checked==true)
  {
     window.document.frmworkallot.lblgr.value="Group Code"
     window.document.frmworkallot.txtuserid.value=""
     window.document.frmworkallot.txtuserdesc.value=""
     window.document.all.iform.src="GenWorkAllotFormIDApproval.aspx" 
     
  }
      else
     {
		window.document.frmworkallot.lblgr.value="User Id"
		window.document.frmworkallot.txtuserid.value=""
		window.document.frmworkallot.txtuserdesc.value=""
		window.document.all.iform.src="GenWorkAllotFormIDApproval.aspx" 
		
     }
}	
		
function ok()
{
var grcode,groption,modid

if (window.document.frmworkallot.radgroup(0).checked==true)
	groption="Group"
else
	groption="User"
	
grcode=window.document.frmworkallot.txtuserid.value
modid=""
if(parent.frames(0).frmmodule.optmoduleid.length>1)
{
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)
{
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
		modid=modid+","+parent.frames(0).frmmodule.optmoduleid(i).value
}
}
else
{
modid=","
if(parent.frames(0).frmmodule.optmoduleid.checked==true)
		modid=modid+parent.frames(0).frmmodule.optmoduleid.value
}

window.document.frmworkallot.stat.value ="approve"
window.document.frmworkallot.info.value=groption+"|"+grcode+"|"+modid
window.document.frmworkallot.action="GenWorkAllotmentApproveDBOper.aspx"
window.document.frmworkallot.method ="post"
window.document.frmworkallot.submit();



}


function Reject()
{
var grcode,groption,modid

if (window.document.frmworkallot.radgroup(0).checked==true)
	groption="Group"
else
	groption="User"
	
grcode=window.document.frmworkallot.txtuserid.value
modid=""
if(parent.frames(0).frmmodule.optmoduleid.length>1)
{
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)
{
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
		modid=modid+","+parent.frames(0).frmmodule.optmoduleid(i).value
}
}
else
{
modid=","
if(parent.frames(0).frmmodule.optmoduleid.checked==true)
		modid=modid+parent.frames(0).frmmodule.optmoduleid.value
}
		
window.document.frmworkallot.stat.value ="reject"
window.document.frmworkallot.info.value=groption+"|"+grcode+"|"+modid
alert(window.document.frmworkallot.info.value)
window.document.frmworkallot.action="GenWorkAllotmentApproveDBOper.aspx"
window.document.frmworkallot.method ="post"
window.document.frmworkallot.submit();
}

function checknulls()
{
		if (window.document.frmworkallot.txtbrcode.value=="")
		
		{        
	       alert('Select Branch Code')
	       return false
	    }
	    
	       
	    if (window.document.frmworkallot.txtuserid.value=="")
	    {
	    if(window.document.frmworkallot.radgroup(0).checked==true)
	    		
			{        
				alert('Select Groupid ')
				return false
			}
	    if(window.document.frmworkallot.radgroup(1).checked==true)
	    		
			{        
				alert('Select Userid ')
				return false
			}
	    
		}
	    
}      



 function Cancel(){
 location.href="Genworkallotmentapproval.aspx"
 }
 
 
 
   
 
  function yy(){
  window.document.all.imod.src="GenWorkAllotmoduleidapproval.aspx"
 }
 
//-->
</script>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);group()">

<form name="frmworkallot">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>work allotment approval</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>
  <table width="100%" height="450" class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td>

                  <%appdate=formatdatetime(session("applicationdate"),1)%>

          <table width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" align="center" height="15"><font class="textblue"><%=Request.QueryString("record")%></font></td>
            </tr>
            <tr>
              <td width="100%" align="right" height="20">
              <div align="center">
                <center>

                <table width="88%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="44%" align="right">&nbsp;Branch
                    Code&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td width="98%"><input name="txtbrcode" class="txtautofill"  readonly size="6" style="TEXT-ALIGN: right" value="<%=session("branchcode")%>"><input type="button" value=" L " name="butbranch" class="button" onclick="branch()"><input name="txtbrdesc" size="15" class="bgcolor1" readonly value="<%=session("branchnarration")%>"></td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" align="right" height="20">
              <div align="center">
                <center>

                <table width="88%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="30%" height="10"></td>
                        <td width="81%" height="10"></td>
                      </tr>
                      <tr>
                        <td width="30%" height="26" align="right"></td>
                        <td width="81%" height="26">

                        <table width="62%" cellspacing="0" cellpadding="0" class="tableborder1">
                          <tr class="bgcolor1">
                            <td width="51%" align="middle"><font class="textblack">Group
                            Id &nbsp;&nbsp;&nbsp;</font><input type="radio" name="radgroup" id="radgroup" size="6" checked onclick="group()" value="2"></td>
                            <td width="49%" align="middle"><font class="textblack">User Id</font><input type="radio" name="radgroup" id="radgroup" size="15" onclick="group()" value="1"></td>
                          </tr>
                        </table>

                        </td>
                      </tr>
                      <tr>
                        <td width="100%" align="right" colspan="2" height="20"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="right" colspan="2">
                        <div align="center">

                          <table width="53%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="39%" align="right" ><input name="lblgr" value="Group Code" readonly size="10"  style="BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; 
                       BORDER-TOP-STYLE: none; COLOR: black"></td>
                              <td width="95%">&nbsp;<input name="txtuserid" class="txtautofill" size="6" onchange="yy()" readonly><input type="button" value=" L " name="butuser" class="button" onclick="User()"><input name="txtuserdesc" class="bgcolor1" size="15" readonly></td>
                            </tr>
                          </table>

                        </div>
                        </td>
                      </tr>
                      <tr>
                        <td width="100%" align="right" colspan="2" height="10"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="right" height="22" colspan="2">

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="44%" valign="top">
                            <div align="right">

                              <table width="90%" cellpadding="0" class="tableborder2">
                                <tr>
                                  <td width="100%" align="right"><iframe id="imod" align=right             
                            frameborder=0 framespacing=0 noresize height=200 width=260
                                
                              src="GenWorkAllotModuleIDApproval.aspx"
                                  
                                valign="top" style="BACKGROUND-COLOR: darkred; LEFT: 0px; TOP: -1px" 
                               ></iframe></td>
                                </tr>
                              </table>

                            </div>
                            </td>
                            <td width="14%"><input type="button" value="    Display    " name="cmdDisplay" class="button" onclick="Display()"></td>
                            <td width="46%" valign="top">
                            <div align="left">

                              <table width="92%" cellpadding="0" class="tableborder2">
                                <tr>
                                  <td width="100%" align="left"><iframe id="iform" align=left              
            frameborder=0 framespacing=0 noresize 
           
                              height=200 width=285 valign="top"  style="BACKGROUND-COLOR: darkred" 
                               ></iframe></td>
                                </tr>
                              </table>

                            </div>
                            </td>
                          </tr>
                          <tr>
                            <td width="44%" valign="top" height="15"></td>
                            <td width="14%" height="15"></td>
                            <td width="46%" valign="top" height="15"></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top" colspan="3">
                            <div align="center">
                              &nbsp;
                            </div>
                            </td>
                          </tr>
                          <tr>
                            <td colspan="3" height="10" valign="top" width="100%"></td>
                          </tr>
                        </table>

                        </td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td align="right" height="10" width="100%"></td>
            </tr>
            <tr>
              <td align="right" height="10" width="100%"></td>
            </tr>
            <tr>
              <td width="100%">
              <div align="center">
                <center>

                <table border="0" width="20%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td><input name="cmdOk" class="button" type="button" value="Approve" class="button" onclick="ok()" disabled><!--<input name="cmdreject" class="bgcolor" type="button" value="    Reject" class="button" onclick="Reject()" disabled>--><input name="cmdCancel" onclick="Cancel()" type="button" value="Cancel" class="button"><input name="cmdexit" class="button" type="button" value="   Exit   " onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button">
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td align="right" height="20" width="100%">
              <p align="center"></p>
              </td>
            </tr>
          </table>

      </table>

      <input id="hadd" name="hadd" type="hidden"><input id="hmodule" name="hmodule" type="hidden"><input id="hopt" name="hopt" type="hidden" value="user"><input id="hok" name="hok" type="hidden"><input id="hopt" name="hopt" type="hidden" value="group"><input id="info" name="info" type="hidden"><input id="stat" name="stat" type="hidden">
      <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
      </form>
      

      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="90%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.aspx">
            </iframe>
            </td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
  </table>

</body>

