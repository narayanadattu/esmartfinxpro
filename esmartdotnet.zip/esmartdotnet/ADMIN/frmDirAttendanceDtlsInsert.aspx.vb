Public Class frmDirAttendanceDtlsInsert
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strdirid, strsno, strAttendanceyn, strSql, strmeetdtls, strmeetingtype, strmeetingdate, strmeetingtime As String
    Dim strvalcol, strvalrow()
    Dim icnt As Integer
    Dim userId, machineID, appDate As String
    Dim objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim errmsg, o_errmsg, o_errmsg1 As String
    Dim objtran As OracleClient.OracleTransaction
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        userId = Session("userid")
        machineID = Session("machineid")
        appDate = Session("applicationdate")
        strmeetdtls = Request.Form("hdnmeetdtls")
        strvalrow = strmeetdtls.Split("|")
        strmeetingtype = Request.Form("hdnmeetingtype")
        strmeetingdate = Request.Form("hdnmeetingdate")
        strmeetingtime = Request.Form("hdnmeetingtime")
        Try

      
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Sub
            End If
        End If
        objtran = objconn.BeginTransaction()
        For icnt = 0 To strvalrow.Length - 1
            strvalcol = strvalrow(icnt).Split("~")

            strsno = strvalcol(0)
            strdirid = strvalcol(1)
                strAttendanceyn = strvalcol(2)

            strSql = "insert into DirAttendtls(DIRCODE, SNO, MEETINGTYPE, MEETINGDATE, MEETINGTIME, ATTENDYN, SYSTEMDATE, USERID) values('" & strdirid & "'," & strsno & ",'" & strmeetingtype & "','" & Format(CDate(strmeetingdate), "dd-MMM-yyyy") & "','" & strmeetingtime & "','" & strAttendanceyn & "',sysdate,'" & userId & "')"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.Transaction = objtran
            objCmd.ExecuteNonQuery()
            objCmd.Dispose()
            objCmd = Nothing
            Next icnt

            objtran.Commit()
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirAttendanceDtls.aspx?record=Saved Successfully", False)
            Exit Sub
        Catch ex As Exception
            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirAttendanceDtls.aspx?record=" & o_errmsg1, False)

        End Try
    End Sub

End Class
