<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmBODReport.aspx.vb" Inherits="eSmartDotNet.frmBODReport"%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>BOD/BOM Report</title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	
	<SCRIPT ID="clientEventHandlersJS" LANGUAGE="javascript">
	function datecheck(obj)
	{
		var dt,arrDt
		if(obj.value=="")
			return;

		dt = obj.value
		dt=dt.toUpperCase();
		arrDt = dt.split("-")
		if(eval(arrDt[0].length)!=2)
			arrDt = dt.split("/")

		if(eval(arrDt[0].length)==2)
		{
			switch(arrDt[1])
			{
				case "JAN" :	arrDt[1]= "01";
								break ; 
				case "Jan" :	arrDt[1]= "01";
								break ; 				
				case "FEB" :	arrDt[1]= "02";
								break ;
				case "Feb" :	arrDt[1]= "02";
								break ;				 
				case "MAR" :	arrDt[1]= "03";
								break ; 
				case "Mar" :	arrDt[1]= "03";
								break ; 				
				case "APR" :	arrDt[1]= "04";
								break ; 
				case "Apr" :	arrDt[1]= "04";
								break ; 				
				case "MAY" :	arrDt[1]= "05";
								break ;
				case "May" :	arrDt[1]= "05";
								break ; 				 
				case "JUN" :	arrDt[1]= "06";
								break ; 
				case "Jun" :	arrDt[1]= "06";
								break ;				
				case "JUL" :	arrDt[1]= "07";
								break ; 
				case "Jul" :	arrDt[1]= "07";
								break ; 				
				case "AUG" :	arrDt[1]= "08";
								break ; 
				case "Aug" :	arrDt[1]= "08";
								break ;
				case "SEP" :	arrDt[1]= "09";
								break ; 
				case "Sep" :	arrDt[1]= "09";
								break ; 				
				case "OCT" :	arrDt[1]= "10";
								break ; 
				case "Oct" :	arrDt[1]= "10";
								break ; 				
				case "NOV" :	arrDt[1]= "11";
								break ; 
				case "Nov" :	arrDt[1]= "11";
								break ; 				
				case "DEC" :	arrDt[1]= "12";
								break ; 
				case "Dec" :	arrDt[1]= "12";
								break ; 										
			}
			
			dt = arrDt[0]+arrDt[1]+arrDt[2]
			obj.value = dt
		}
		formatDate(obj)
		
		if(window.document.all.divBODBOMSittingFee.style.display=="block")
		{
		var intDiff=getDateDiff(window.document.frmEmpMast.txtSittingFeeDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtSittingFeeDate.value=""
				window.document.frmEmpMast.txtSittingFeeDate.focus()
			}
			
			if (window.document.frmEmpMast.cmbSittingFeeType.value == "Select")
			{
			alert("Select Sitting Fee Meeting  Type")
			return
			}
			strVal="CheckMeetingDate"+"|"+window.document.frmEmpMast.cmbSittingFeeType.value+"|"+window.document.frmEmpMast.txtSittingFeeDate.value
		
	//	alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		}
		
		if(window.document.all.divBODBOMAttendance.style.display=="block")
		{
			var intDiff=getDateDiff(window.document.frmEmpMast.txtMeetingDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmEmpMast.txtMeetingDate.value=""
				window.document.frmEmpMast.txtMeetingDate.focus()
			}
			
			if (window.document.frmEmpMast.cmbMeetingType.value == "Select")
			{
			alert("Select  Meeting  Type")
			return
			}
		}
	}
		
		function GetCheckMeetingDate(str)
		{
		if (str=='NO')
		{
		alert("No Records In This Meeting Date")
		window.document.frmEmpMast.txtSittingFeeDate.value = ""
		window.document.frmEmpMast.msflexSittingFeeDtls.Rows=1
		}
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	</script>
	
	<SCRIPT LANGUAGE=javascript>
	
	function ShowDivision(str)
	{
		//for grid values
		window.document.frmEmpMast.msflexSittingFeeDtls.Rows=1
		window.document.frmEmpMast.mfgSal.Rows=1
		window.document.frmEmpMast.msflexMeetingDtls.Rows=1
		window.document.frmEmpMast.txtSittingFeeDate.value	= "<%=session("applicationdate")%>"	
		window.document.frmEmpMast.txtMeetingDate.value = "<%=session("applicationdate")%>"	
		window.document.all.divBODBOMAttendance.style.display="none"
		window.document.all.divBODBOMSittingFee.style.display="none"
		window.document.all.divBODBOMSalaryRep.style.display="none"
		
		if(str=="0")
		{
			window.document.all.divBODBOMSittingFee.style.display="block"
			
		}
		
		if(str=="1")
		{
			window.document.all.divBODBOMSalaryRep.style.display="block"
		}
		if(str=="2")
		{
			window.document.all.divBODBOMAttendance.style.display="block"
		}
	}	

	function DispTranMsg()
	{
	
	window.document.frmEmpMast.txtSittingFeeDate.value	= "<%=session("applicationdate")%>"	
	}
	
// start sitting fee
	
function QueryParamSittingFee()
	{
	var strVal;
if (window.document.frmEmpMast.cmbSittingFeeType.value == "Select")
{
alert("Select Sitting Fee Type")
return
}
if (window.document.frmEmpMast.txtSittingFeeDate.value == "")
{
alert("Enter Sittting Fee Date")
return
}

			strVal="BODBOMSittingREPORT"+"|"+window.document.frmEmpMast.cmbSittingFeeType.value+"|"+window.document.frmEmpMast.txtSittingFeeDate.value
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popBODBOMSittingREPORT(str)
	{
		window.document.frmEmpMast.msflexSittingFeeDtls.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
			window.document.frmEmpMast.msflexSittingFeeDtls.cols = 5;
			window.document.frmEmpMast.msflexSittingFeeDtls.formatstring="<Sno       |<Dir Code            |<DirName                                                                               |> Sitting Fee         |^Signature                    "
			  
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmEmpMast.msflexSittingFeeDtls.rows = window.document.frmEmpMast.msflexSittingFeeDtls.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmEmpMast.msflexSittingFeeDtls.textmatrix(aCnt+1,0) = aCnt+1
				window.document.frmEmpMast.msflexSittingFeeDtls.textmatrix(aCnt+1,1) = strCols[0]
				window.document.frmEmpMast.msflexSittingFeeDtls.textmatrix(aCnt+1,2) = strCols[1]
				window.document.frmEmpMast.msflexSittingFeeDtls.textmatrix(aCnt+1,3) = strCols[2]
				window.document.frmEmpMast.msflexSittingFeeDtls.textmatrix(aCnt+1,4) = strCols[3]
				
			}
			
	}
	
// end sitting fee


// start meeting attendance Report
function QueryParamMeetingAtten()
	{
	var strVal;
if (window.document.frmEmpMast.cmbMeetingType.value == "Select")
{
alert("Select Meeting Type")
return
}
if (window.document.frmEmpMast.txtMeetingDate.value == "")
{
alert("Enter Meeting Date")
return
}

			strVal="BODBOMMeetingAttendREPORT"+"|"+window.document.frmEmpMast.cmbMeetingType.value+"|"+window.document.frmEmpMast.txtMeetingDate.value
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popBODBOMMeetingAttendREPORT(str)
	{
		window.document.frmEmpMast.msflexMeetingDtls.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
			window.document.frmEmpMast.msflexMeetingDtls.cols = 4;
			window.document.frmEmpMast.msflexMeetingDtls.formatstring="<Sno       |<Dir Code            |<DirName                                                                               |> AttendanceYN"
			  
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmEmpMast.msflexMeetingDtls.rows = window.document.frmEmpMast.msflexMeetingDtls.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,0) = aCnt+1
				window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,1) = strCols[0]
				window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,2) = strCols[1]
				window.document.frmEmpMast.msflexMeetingDtls.textmatrix(aCnt+1,3) = strCols[2]
			}
			
	}

	
	function Report(strrep)
	{
	
	var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
		if(window.document.all.divBODBOMSittingFee.style.display=="block")
		{
	strheadtype = "BOM/BOD sitting Fee Report"
	strheadsub = "Board of Directors Sitting Fee held On " + window.document.frmEmpMast.txtSittingFeeDate.value + ". The following BOD/BOM are attended."
	StrHead= strheadsub + ",60,80"
	window.document.frmEmpMast.reptitle.value=strheadtype
	
	StrCol=StrCol+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(0,0)+",5,C"+"~"  // slno
			StrCol=StrCol+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(0,1)+",8,L"+"~" // Dir Code
			StrCol=StrCol+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(0,2)+",40,L"+"~" //Dir Name
			StrCol=StrCol+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(0,3)+",12,R"+"~" //sitting fee
			StrCol=StrCol+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(0,4)+",14,C"+"|" // Attendance YN
		
			for(icnt=1;icnt<=window.document.frmEmpMast.msflexSittingFeeDtls.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmEmpMast.msflexSittingFeeDtls.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmEmpMast.msflexSittingFeeDtls.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
			
			window.document.frmEmpMast.hreport.value=StrArr
			//alert(StrArr)
			if (strrep == "HTML") 
			{
				window.document.frmEmpMast.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmBODReport"
			}
			else
			{
				window.document.frmEmpMast.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmBODReport"
			}
			window.document.frmEmpMast.method="post"
			window.document.frmEmpMast.submit() 
		}	
		
		if(window.document.all.divBODBOMSalaryRep.style.display=="block")
		{
	strheadtype = "BOM/BOD Salary Report"
	strheadsub = "Board of Directors Salary for  " + window.document.frmEmpMast.selSalmon.options[window.document.frmEmpMast.selSalmon.selectedIndex].text+" "+window.document.frmEmpMast.selSalyear.options[window.document.frmEmpMast.selSalyear.selectedIndex].text
	StrHead= strheadsub + ",60,80"
	window.document.frmEmpMast.reptitle.value=strheadtype
	
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,0)+",5,C"+"~"  // slno
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,1)+",8,L"+"~" // Dir Code
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,2)+",8,L"+"~" // Dir Type
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,3)+",40,L"+"~" //Dir Name
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,4)+",14,R"+"~" //Salary
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,5)+",14,R"+"|" // TDS
		
			for(icnt=1;icnt<=window.document.frmEmpMast.mfgSal.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmEmpMast.mfgSal.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmEmpMast.mfgSal.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
			
			window.document.frmEmpMast.hreport.value=StrArr
			//alert(StrArr)
			if (strrep == "HTML") 
			{
				window.document.frmEmpMast.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmBODReport"
			}
			else
			{
				window.document.frmEmpMast.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmBODReport"
			}
			window.document.frmEmpMast.method="post"
			window.document.frmEmpMast.submit() 
		}	
		
		if(window.document.all.divBODBOMAttendance.style.display=="block")
		{
	strheadtype = "BOM/BOD Meeting Attendance Report"
	strheadsub = "Board of Directors Meeting held On " + window.document.frmEmpMast.txtMeetingDate.value + ". The following BOD/BOM are attended."
	StrHead= strheadsub + ",60,80"
	window.document.frmEmpMast.reptitle.value=strheadtype
	
	StrCol=StrCol+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(0,0)+",5,C"+"~"  // slno
			StrCol=StrCol+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(0,1)+",8,L"+"~" // Dir Code
			StrCol=StrCol+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(0,2)+",40,L"+"~" //Dir Name
			StrCol=StrCol+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(0,3)+",10,C"+"|" // Attendance YN
		
			for(icnt=1;icnt<=window.document.frmEmpMast.msflexMeetingDtls.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmEmpMast.msflexMeetingDtls.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmEmpMast.msflexMeetingDtls.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
			
			window.document.frmEmpMast.hreport.value=StrArr
			//alert(StrArr)
			if (strrep == "HTML") 
			{
				window.document.frmEmpMast.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmBODReport"
			}
			else
			{
				window.document.frmEmpMast.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmBODReport"
			}
			window.document.frmEmpMast.method="post"
			window.document.frmEmpMast.submit() 
		}	
		
	}
	
	// BOD/BOM Salary Report Start
	function Refresh()
	{
			strVal="BODBOMSalaryRep"+"|"+window.document.frmEmpMast.selSalmon.options[window.document.frmEmpMast.selSalmon.selectedIndex].text+"|"+window.document.frmEmpMast.selSalyear.options[window.document.frmEmpMast.selSalyear.selectedIndex].text
		
	//	alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	
	function GetBODBOMSalaryRep(str)
	{
	window.document.frmEmpMast.mfgSal.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
			window.document.frmEmpMast.mfgSal.cols = 6;
			window.document.frmEmpMast.mfgSal.formatstring="^Sno        |<Dir Type            |<Dir ID              |<DirName                                                                       |> Salary              |>TDSAmount           "

			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmEmpMast.mfgSal.rows = window.document.frmEmpMast.mfgSal.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,0) = aCnt+1
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,1) = strCols[0]
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,2) = strCols[1]
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,3) = strCols[2]
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,4) = strCols[3]
				window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,5) = strCols[4]
			}
	}
	// BOD/BOM Salary Report End
	</script>

<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();">


	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmEmpMast">
		<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%">
				<tr>
					<td align="left" class="bankHeaderLogo"></td>
					<td align="right" class="esmartBankerLogo"></td>
				</tr>
			</table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" border="0" cellspacing="0" width="100%">
				<tr>
					<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="30%" align="center" height="22" class="subHeader"><h2>BOD/BOM Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol">
		</div><%appdate=formatdatetime(session("applicationdate"),1)%>

		<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
			<tr>
				<td width="100%">
					<table align="center" cellspacing="0" cellpadding="0">
						<tr>
							<td height="15"><font class="textblue"></font></td>
						</tr>
					</table>
					
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
						<tr>
							<td width="16%" valign="top">
								<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
									<tr bgcolor="#99ccff" >
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">BOD/BOM Sitting Fee Report</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">BOD/BOM Salary Report</font></a></td>
									</tr>
							
										<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">BOD/BOM Meeting Attendance Report</font></a></td>
									</tr>
								</table>
							</td>
						<td width="84%" valign="top">
						
						<!---- BOD/BOM Sitting Fee Report Start  ----------->
						
						<div align="center" id="divBODBOMSittingFee" style="display:none">
            <center>

            <table BORDER = 1 width="100%" cellpadding="0" class="tableborder2">
            <tr>
										<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="BOD/BOM Sitting Fee Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
									</tr>
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
			  <td width="20%" align="left">&nbsp;&nbsp;Meeting Type:&nbsp;&nbsp; <select id= "cmbSittingFeeType" name="cmbSittingFeeType">
 <option value="Select" selected>Select</option>
 <option value="BOD">BOD</option>
 <option value="BOM">BOM</option>
 </select><font color="#000000"></font></td>
		<td width="60%" align="left">&nbsp;&nbsp;Meeting Date :<input name="txtSittingFeeDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtSittingFeeDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>	
				  </tr>
				  <tr>
				  <td  colspan=6>
				   <table align="center">
                    <tr>
                    <td  align="center">&nbsp;&nbsp;<input name="cmdSittingFeeDtlssok" onclick="QueryParamSittingFee()" type="button" value="   OK   " class="button"><input name="cmdSittingFeeDtlscancel" onclick="SittingFeeDtlsCancel()" type="button" value="Cancel" class="button"></td>
                    </tr>
				    </table>
				  </td>
				  </tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=msflexSittingFeeDtls style="LEFT: 0px; WIDTH: 800px; TOP: 0px; HEIGHT: 350px" 
	height=350 width=800 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=msflexSittingFeeDtls VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="5">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="<Sno       |<Dir Code            |<DirName                                                                               |> Sitting Fee         |^Signature                    ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
                  <tr>
					<td width="100%" height=50 colspan=6> &nbsp;
					</td>
				</tr>
				</table>  
	</td>
              </tr>
            </table>

            </center>
          </div>
						<!---- BOD/BOM Sitting Fee Report End  ----------->
		
		<!---- BOD/BOM Salary Report Start  ----------->

 <div align="center" id="divBODBOMSalaryRep" style="display:none">
            <center>

            <table BORDER = 1 width="100%" cellpadding="0" class="tableborder2">
             <tr>
										<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="BOD/BOM Salary Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
									</tr>
              <tr>
                <td width="100%">

                <table border="1" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
											<td width="100%" align="center">Month&nbsp;&nbsp;											
											<%
												dim mon,mon1,mon2,nmon,nmon1,nmon2
												
												mon = Month(session("applicationdate"))
												
												if mon = 1 then
													mon1 = 12
												else
													mon1 = mon-1
												end if
												
												if mon = 12 then
													mon2 = 1
												else
													mon2 = mon+1
												end if
												
												nmon = MonthName(mon)
												
												nmon1 = MonthName(mon1)
												
												nmon2 = MonthName(mon2)
												
											%>
											
											<select name="selSalmon" onchange="selSalmonchng()">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=mon%>" selected><%=nmon%></option>
												<option value="<%=mon1%>"><%=nmon1%></option>
												<option value="<%=mon2%>"><%=nmon2%></option>
											</select>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												dim yer,yer1,yer2
												
												yer = Year(session("applicationdate"))
												
												if mon = 1 then
													yer1 = yer-1
												else
													yer1 = ""
												end if
												
												if mon = 12 then
													yer2 = yer+1
												else
													yer2 = ""
												end if
												
											%>
											<select name="selSalyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=yer%>" selected><%=yer%></option>
												<option value="<%=yer1%>"><%=yer1%></option>
												<option value="<%=yer2%>"><%=yer2%></option>
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="Refresh1" class="button" name="Refresh1" value=" Refresh" onclick="Refresh()">
											
											</td>
											
										</tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=mfgSal style="LEFT: 0px; WIDTH: 850px; TOP: 0px; HEIGHT: 350px" 
	height=350 width=850 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=mfgSal VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="6">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="^Sno        |<Dir Type            |<Dir ID              |<DirName                                                                       |> Salary              |>TDSAmount           ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
                  <tr>
					<td width="100%" height=50 colspan=6> &nbsp;
					</td>
				</tr>
				</table>  
	</td>
              </tr>
            </table>

            </center>
         </div>
<!---- BOD/BOM Salary Report End  ----------->		 				
<!---- BOD/BOM Meeting Attendance Report Start  ----------->
						
						<div align="center" id="divBODBOMAttendance" style="display:none">
            <center>

            <table BORDER = 1 width="100%" cellpadding="0" class="tableborder2">
            <tr>
										<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="BOD/BOM Meeting Attendance Report " class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
									</tr>
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
			  <td width="20%" align="left">&nbsp;&nbsp;Meeting Type:&nbsp;&nbsp; <select id= "cmbMeetingType" name="cmbMeetingType">
 <option value="Select" selected>Select</option>
 <option value="BOD">BOD</option>
 <option value="BOM">BOM</option>
 </select><font color="#000000"></font></td>
		<td width="60%" align="left">&nbsp;&nbsp;Meeting Date :<input name="txtMeetingDate" class="txtautofill"  onkeypress="numdec(window.document.frmEmpMast.txtMeetingDate.value)" size="12"  maxlength='12' onblur="datecheck(this)" style="TEXT-ALIGN: right"><font color="#000000">(DDMMYYYY)</font></td>	
				  </tr>
				  <tr>
				  <td  colspan=6>
				   <table align="center">
                    <tr>
                    <td  align="center">&nbsp;&nbsp;<input name="cmdMeetingDtlssok" onclick="QueryParamMeetingAtten()" type="button" value="   OK   " class="button"><input name="cmdMeetingDtlscancel" onclick="MeetingDtlsCancel()" type="button" value="Cancel" class="button"></td>
                    </tr>
				    </table>
				  </td>
				  </tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=msflexMeetingDtls style="LEFT: 0px; WIDTH: 800px; TOP: 0px; HEIGHT: 350px" 
	height=350 width=800 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=msflexMeetingDtls VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="5">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="<Sno       |<Dir Code            |<DirName                                                                               |> AttendanceYN         ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
                  <tr>
					<td width="100%" height=50 colspan=6> &nbsp;
					</td>
				</tr>
				</table>  
	</td>
              </tr>
            </table>

            </center>
          </div>
						<!---- BOD/BOM Meeting Attendance Report End  ----------->
						</td>
					</tr>
				</table>
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%">
							<div align="center">
								<center>	
								
								<table width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px"  class="tablebordermain">
	
		<tr >
			<td width="100%"  align="center"><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmBODReport.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
		</tr>
		
  </table>
								</center>
							</div>
							</td>
						</tr>
					</table>
					<input type="hidden" name="hpr" value="<%=session("precision")%>">
						<input type="hidden" name="hreport">
    <input type="hidden" name="reptitle">
					
<input type="text"  style="VISIBILITY: Hidden" readonly class="bgcolor1" name="txtMaxdate" size="20">
<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src = "getDetails.aspx"></iframe>
		<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
                </td>
            </tr>
         </table>
                  
    </form>

  </body>
</html>

						

