<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="getDetails.aspx.vb" Inherits="eSmartDotNet.getDetails1"%>
<HTML>
	<HEAD>
		<%
		dim objval as new GENVALIDATIONS.Validations
		dim strSql, strDepcertificate as string
strDepcertificate=""
dim rs5
dim rsNFTS, objNFTS
rs5 = server.CreateObject("adodb.recordset")
rsNFTS=server.CreateObject("adodb.recordset")
objNFTS =server.CreateObject("ReportPurposeOnly.Reportonly")
strSql="SELECT Depcertificate FROM GENBANKPARM"
rsNFTS=objNFTS.SingleSelectStat(strSql)
if objNFTS.ConnError="Connected" then
	if not rsNFTS.bof and not rsNFTS.eof then
		strDepcertificate=rsNFTS(0).value
	end if
end if

dim strVal
dim strArr
dim strIndvVal
dim strResult,batchNo,tranNo, sqlStr

					
rs = Server.CreateObject("adodb.recordset")
strVal=request.querystring("st")
strArr=split(strVal,"|")

if strArr(0)="SETTERMDUEDATE" then
dim inttermmonths 
strResult=""
inttermmonths = 0 
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
inttermmonths = cint(strArr(1)) * 12
sqlStr = "select ADD_MONTHS( to_date('"& strArr(2) & "'),"& inttermmonths &")-1 from dual"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=format(rs(0).value,"dd-MMM-yyyy")
				end if
			end if	
else if strArr(0)="GetAccName" then

strResult=""
	strResult= objval.GetAccName(strArr(1))
	
		
else if strArr(0)="EMPDETAILS" then

	strResult=""
	
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		'sqlStr="SELECT CUSTOMERID, USERID, EMPNAME, DESGNCODE, TO_CHAR(DOA,'DD-Mon-YYYY') DOA, TO_CHAR(DOT,'DD-Mon-YYYY') DOT, TO_CHAR(DOP,'DD-Mon-YYYY') DOP, TO_CHAR(DOC,'DD-Mon-YYYY') DOC, EDUQUALIFY, TECQUALIFY,OTHERQUALIFY, NVL(CONPAY,0) CONPAY, NVL(BASIC,0) BASIC , NVL(DA,0) DA ,NVL(HRA,0) HRA, NVL(ALLOWANCE,0) ALLOWANCE, NVL(GROSSPAY,0) GROSSPAY, NVL(PROFTAX,0) PROFTAX, NVL(SWELFARE,0) SWELFARE, NVL(FESTDEDUCT,0) FESTDEDUCT, NVL(OTHERS,0) OTHERS, NVL(OTHERALLOWANCE,0) OTHERALLOWANCE, NVL(LICPREMIUM,0) LICPREMIUM, NVL(PROVFUND,0) PROVFUND, NVL(TOTALDEDUCT,0) TOTALDEDUCT, NVL(NETPAY,0) NETPAY, TO_CHAR(LEAVINGDT,'DD-Mon-YYYY') LEAVINGDT, TO_CHAR(LETTERDT,'DD-Mon-YYYY') LETTERDT, REASON, EPFACCNO, BRANCHCODE,(SELECT NARRATION FROM GENBANKBRANCHMST WHERE BRANCHCODE=a.BRANCHCODE) brdesc, MODULEID, (SELECT NARRATION FROM GENMODULETYPESMST WHERE MODULEID=a.MODULEID AND BRANCHCODE=a.BRANCHCODE) moddesc, GLCODE,  (SELECT GLDESCRIPTION FROM GenGlMastMst WHERE GLCODE=a.GLCODE) gldesc, ACCNO,  WORKINGBRCODE,(SELECT NARRATION FROM GENBANKBRANCHMST WHERE BRANCHCODE=a.WORKINGBRCODE) workdesc, NVL(GIP,0) GIP, STATUS FROM EMPLOYEEMST a WHERE EMPCODE='" & strArr(1) & "' " & strArr(2) & ""
		
		sqlStr = " select CUSTOMERID, USERID, EMPNAME, DESGNCODE, TO_CHAR(APPOINTDT,'DD-Mon-YYYY') APPOINTDT, TO_CHAR(TEMPDT,'DD-Mon-YYYY') TEMPDT, TO_CHAR(PERMENTDT,'DD-Mon-YYYY') PERMENTDT, TO_CHAR(CONFIRMDT,'DD-Mon-YYYY') CONFIRMDT, EDUQUALIFY, TECQUALIFY, OTHERQUALIFY, NVL(CONPAY,0) CONPAY, NVL(BASIC,0) BASIC , NVL(DA,0) DA ,NVL(HRA,0) HRA, NVL(ALLOWANCE,0) ALLOWANCE, NVL(MEDIREIMB,0) MEDIREIMB,  NVL(OTHERALLOWANCE,0) OTHERALLOWANCE, NVL(GROSSPAY,0) GROSSPAY,  NVL(PROFTAX,0) PROFTAX, NVL(PROVFUND,0) PROVFUND,  NVL(OTHERDEDUCT,0) OTHERDEDUCT,  NVL(TOTALDEDUCT,0) TOTALDEDUCT,  NVL(NETPAY,0) NETPAY,  GIP, TO_CHAR(LETTERDT,'DD-Mon-YYYY') LETTERDT, TO_CHAR(LEAVINGDT,'DD-Mon-YYYY') LEAVINGDT, REASON, EPFACCNO, STATUS, BRANCHCODE,(SELECT NARRATION FROM GENBANKBRANCHMST WHERE BRANCHCODE=a.BRANCHCODE) brdesc, MODULEID, (SELECT NARRATION FROM GENMODULETYPESMST WHERE MODULEID=a.MODULEID AND BRANCHCODE=a.BRANCHCODE) moddesc, GLCODE, (SELECT GLDESCRIPTION FROM GenGlMastMst WHERE GLCODE=a.GLCODE) gldesc, ACCNO, WORKINGBRCODE, (SELECT NARRATION FROM GENBANKBRANCHMST WHERE BRANCHCODE=a.WORKINGBRCODE) workdesc, ESI, nvl(VPF,0)vpf ,nvl(TDS,0)tds,GRATUITYYN FROM EMPLOYEEMST a WHERE EMPCODE='" & strArr(1) & "' " & strArr(2) & " "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					strResult=rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value & "~" & rs(23).value & "~" & rs(24).value & "~" & rs(25).value & "~" & rs(26).value & "~" & rs(27).value & "~" & rs(28).value & "~" & rs(29).value & "~" & rs(30).value & "~" & rs(31).value & "~" & rs(32).value & "~" & rs(33).value & "~" & rs(34).value & "~" & rs(35).value & "~" & rs(36).value & "~" & rs(37).value & "~" & rs(38).value & "~" & rs(39).value & "~" & rs(40).value & "~" & rs(41).value & "~" & rs(42).value
					
					if isdbnull(rs(36).value) = false then
						
						sqlStr="SELECT N.NAME  FROM " & rs(32).value & "MST N WHERE N.BRANCHCODE='" & rs(30).value & "' AND N.GLCODE='" & rs(34).value & "' AND N.ACCNO='" & rs(36).value & "' GROUP BY N.NAME"
					
						rs1 = Server.CreateObject("adodb.recordset")
						rs1=obj1.SingleSelectStat(sqlStr)
						if obj1.ConnError="Connected" then
							if not rs1.BOF and not rs1.EOF then
								strResult=strResult & "~" & rs1(0).value 
							end if
						end if
						rs1 = nothing
						obj1=nothing
						
					else
						strResult=strResult & "~" & ""
					end if
					
				end if
			end if
		rs=nothing

else if strArr(0)="getDirectorDtls" then
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	if strArr(1) = "BOD" then
	 sqlStr = " SELECT DIRCODE, DIRNAME,'Y' FROM GENDIRECTORDTLS where BOD = 'Y' AND dircode NOT IN (SELECT DIRCODE FROM DirAttendtls WHERE MEETINGTYPE = '"& strArr(1) &"' AND  MEETINGDATE =  '"& format(cdate(strArr(2)),"dd-MMM-yyyy") &"')"
	else if  strArr(1) = "BOM" then
	 sqlStr = " SELECT DIRCODE, DIRNAME,'Y' FROM GENDIRECTORDTLS where BOM = 'Y' AND dircode NOT IN (SELECT DIRCODE FROM DirAttendtls WHERE MEETINGTYPE = '"& strArr(1) &"' AND  MEETINGDATE = '"& format(cdate(strArr(2)),"dd-MMM-yyyy") &"')"
	end if

 rs=obj.SingleSelectStat(sqlStr)
 if obj.ConnError="Connected" then
	if not rs.BOF and not rs.EOF then
	do until rs.EOF
	strResult = strResult  & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "|" 
	rs.movenext()
	loop
	strResult=mid(strResult,1,strResult.length-1)
	end if
	
end if	
else if strArr(0)="DIRDETAILS" then
dim strResultC,strResultR,strResult1

	strResult1=""
	
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
		sqlStr = " SELECT CUSTOMERID, DIRNAME, EDUCATION, BOD, BODDISG, BOM, BOMDISG, ELECDATE, JOINDATE, TERMPERIOD, TERMEFFDT, DUEDATE, COMMITTEEMEMYN, SITTINGFEE, BOMSALARY, TDSYN, TERMINATIONDATE, TERMINATEREASON, RELATIONSYN, PAYMENTMODE, ACCNO, PAYEENAME, IFSCCODE FROM GENDIRECTORDTLS WHERE DIRCODE ='"& strArr(1) &"' and " & strArr(2)
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					strResult1=rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value 
				end if
			end if
			
			sqlStr = " SELECT SNO, COMMITTEEID, JOINFROMDATE, JOINTODATE FROM DIRCOMTDTLS WHERE DIRCODE ='"& strArr(1) &"'"
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
			strResultC = strResultC  & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value &"|"
			rs.movenext()
				loop
			strResultC=mid(strResultC,1,strResultC.length-1)
				end if
			end if	
			
			
			sqlStr = " SELECT SNO, RELATIONID, RELATIONNAME, PROFESSION, CUSTOMERID, PANNO, MOBILENO FROM DIRRELATIONDTLS WHERE DIRCODE ='"& strArr(1) &"'"
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
			strResultR = strResultR  & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value  & "~" & rs(4).value  & "~" & rs(5).value  & "~" & rs(6).value &"|"
			rs.movenext()
			loop
				strResultR=mid(strResultR,1,strResultR.length-1)
				end if
			end if	
			
			strResult = strResult1 & "$" & strResultC & "$" & strResultR
			
else if strArr(0)="GetSittingFeeAmt" then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="SELECT fees FROM DIRSITTINGFEEDTLS WHERE effdate = (SELECT MAX(effdate) FROM DIRSITTINGFEEDTLS WHERE effdate <= '" & strArr(1) &"')"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					strResult=rs(0).value 
				end if
			end if
else if strArr(0)="SalRepSelMonth"  or strArr(0)="VoucherReprintclickMonth" then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select DISTINCT paidmonth from SALARYPAIDDTLS where branchcode = '"& strArr(1) &"' order by paidmonth"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if		
else if strArr(0)="SalRepSelYear" or  strArr(0)="SalRepSelYear1" or strArr(0)="VoucherReprintSelYear" then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select DISTINCT PAIDYEAR from SALARYPAIDDTLS where branchcode = '"& strArr(1) &"' order by PAIDYEAR"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if			
else if strArr(0)="RentReportsclickMonth" then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select DISTINCT paidmonth from TENANTPAIDDTLS where branchcode = '"& strArr(1) &"' order by paidmonth"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if		
else if strArr(0)="RentReportsSelYear"  then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select DISTINCT PAIDYEAR from TENANTPAIDDTLS where branchcode = '"& strArr(1) &"' order by PAIDYEAR"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if			
else if strArr(0)="SalPaySlipSelEmployee" or strArr(0)="GeneralRepSelEmployee" then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
''sqlStr="select  EMPCODE, EMPNAME from EMPLOYEEMST where status='R' and  branchcode = '"& strArr(1) &"' order by EMPCODE"
sqlStr="select  EMPCODE, EMPNAME from EMPLOYEEMST where status='R' and  WORKINGBRCODE = '"& strArr(1) &"' order by EMPCODE"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if		
else if strArr(0)="GetTDSAmt" then
dim strErrorMessage
dim strPanYN
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select customerid from "& strArr(2) &"mst where branchcode='"& strArr(1) &"' and glcode='"& strArr(3) &"' and accno ='"& strArr(4) &"'"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
			strPanYN = objval.GetPanYN(rs(0).value,"TDS",strErrorMessage)
				if strPanYN = "Y" then
					strResult= (cDbl(strArr(5)) * (10/100))
				else
					strResult= (cDbl(strArr(5)) * (20/100))
				end if 
				
				end if
			end if				
else if strArr(0)="EmployeeDetails"  then
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
sqlStr="select  EMPCODE, EMPNAME from EMPLOYEEMST where branchcode = '"& strArr(1) &"' order by EMPCODE"
rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
				end if
			end if			
else if  strArr(0)="GRATUITYCHECK" then
strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		strResult= "NO"		
		sqlStr="SELECT FLOOR(MONTHS_BETWEEN(SYSDATE,APPOINTDT)) FROM employeemst a WHERE empcode = '"& strArr(1) &"'"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
						if cdbl(rs(0).value) >= 60 then
						strResult= "YES" & "|" & cdbl(rs(0).value)
						else
						strResult= "NO" & "|" & cdbl(rs(0).value)
						end if
				else
				strResult= "NO"	& "|0"	
				end if
			end if
			
			rs=nothing
			obj=nothing
else if strArr(0)="SALPARM" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT CODE, VALUE, FLAG, FROMAMT, TOAMT  FROM SALARYPARMST WHERE status='R' AND (CODE,effectivedate) IN (SELECT CODE,MAX(effectivedate) FROM SALARYPARMST WHERE status='R' GROUP BY CODE) ORDER BY CODE"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
else if strArr(0)="CALC" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT CODE, VALUE, FLAG, FROMAMT, TOAMT  FROM SALARYPARMST WHERE status='R' AND CODE <> '" & strArr(1) & "' AND (CODE,effectivedate) IN (SELECT CODE,MAX(effectivedate) FROM SALARYPARMST WHERE status='R' GROUP BY CODE) ORDER BY CODE"
			
			strResult = strArr(1) & "$"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
else if strArr(0)="GENERATEGRATUITY" then
dim frmfinyear,tofinyear 
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		frmfinyear = "01-Apr-" & mid(strArr(1),1,4)
		tofinyear =  "31-Mar-" & mid(strArr(1),1,2) & mid(strArr(1),5,2)
		sqlStr="SELECT z.empcode,z.empname,z.basic,z.da,z.graamt,z.postyn FROM (SELECT x.empcode,x.empname,x.basic,x.da, ROUND((((x.basic+ x.da) / 26 ) * 15 )) graamt , 'Y' postyn FROM ( " & _
" SELECT empcode,empname,basic,da, systemdate FROM employeemst WHERE status = 'R' AND FLOOR(MONTHS_BETWEEN(SYSDATE,APPOINTDT)) > 60 AND systemdate BETWEEN '"& frmfinyear &"'  AND '"& tofinyear &"'" & _
" UNION ALL " & _
" SELECT empcode,empname,basic,da, systemdate FROM employeemsthist WHERE status = 'R' AND FLOOR(MONTHS_BETWEEN(SYSDATE,APPOINTDT)) > 60 AND systemdate BETWEEN '"& frmfinyear &"'  AND '"& tofinyear &"' ) x " & _
" WHERE x.systemdate = (SELECT MAX(y.systemdate) FROM ( " & _
" SELECT empcode,empname,basic,da, systemdate FROM employeemst WHERE status = 'R' AND FLOOR(MONTHS_BETWEEN(SYSDATE,APPOINTDT)) > 60  AND systemdate BETWEEN '"& frmfinyear &"'  AND '"& tofinyear &"' " & _
" UNION ALL " & _
" SELECT empcode,empname,basic,da, systemdate FROM employeemsthist WHERE status = 'R' AND FLOOR(MONTHS_BETWEEN(SYSDATE,APPOINTDT)) > 60  AND systemdate BETWEEN '"& frmfinyear &"'  AND '"& tofinyear &"' ) y WHERE " & _
" y.empcode = x.empcode)) z WHERE ("& strArr(1) &",z.empcode) NOT IN (SELECT FINANCIALYEAR, EMPCODE FROM GRATUITYDTLS) ORDER BY z.empcode"
			
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
else if strArr(0)="GRATUITYREPORT" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="select SLNO, EMPCODE, EMPNAME, GRATUITY from GRATUITYDTLS  where financialyear ="& strArr(1) &""
			
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value  & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing


else if strArr(0)="GetSittingFeeDetails" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT SNO, EFFDATE, FEES FROM DIRSITTINGFEEDTLS ORDER BY sno"
			
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value  & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
else if strArr(0)="CheckMeetingDate" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
	strResult="NO"
			sqlStr="SELECT MEETINGDATE  FROM DirectorMeetingAttndtls m , GENDIRECTORDTLS d WHERE m.DIRCODE = d.DIRCODE AND MEETINGTYPE = '"& strArr(1) &"' and m.MEETINGDATE = '"& strArr(2) &"'"
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
						strResult="YES"
						else
						strResult="NO"
				end if
				else
				strResult="NO"
			end if
			
			rs=nothing
			obj=nothing
			

else if strArr(0)="BODBOMSittingREPORT" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT m.DIRCODE,substr(d.DIRNAME,1,40) DIRNAME, PAIDFEEAMT,'' signature  FROM DirectorMeetingAttndtls m , GENDIRECTORDTLS d WHERE m.DIRCODE = d.DIRCODE and MEETINGTYPE = '"& strArr(1) &"' and m.MEETINGDATE = '"& strArr(2) &"'"
			
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value   & "~" & rs(3).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
else if strArr(0)="BODBOMMeetingAttendREPORT" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="select m.DIRCODE,substr(d.DIRNAME,1,40) DIRNAME,ATTENDYN from DirAttendtls m, GENDIRECTORDTLS d WHERE m.DIRCODE = d.DIRCODE and MEETINGTYPE = '"& strArr(1) &"' and m.MEETINGDATE = '"& strArr(2) &"' and m.attendyn = 'Y'"
			
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value    & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing			

else if strArr(0)="CheckDupMeetingAttend" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		
			sqlStr= "select dircode from DirectorMeetingAttndtls where meetingtype ='"& strArr(1) &"'  and meetingdate ='"& strArr(2) &"' and dircode = '"& strArr(3) &"'"
				
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
						strResult= "Exits"
						else
						strResult= "NotExits"
				end if
			end if
			
			rs=nothing
			obj=nothing
else if strArr(0)="EMPLOYSAL" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT EMPCODE, EMPNAME FROM EMPLOYEEMST WHERE EMPCODE NOT IN (SELECT EMPCODE  FROM SALARYPAIDDTLS WHERE PAIDMONTH='" & strArr(1) & "' AND  PAIDYEAR='" & strArr(2) & "' AND branchcode='" & strArr(3) & "') AND STATUS='R' AND WORKINGBRCODE='" & strArr(3) & "' "
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				else
					strResult = "No Records"
				end if
			end if
			
			rs=nothing
			obj=nothing

else if strArr(0)="BOMSAL" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT DIRCODE, substr(DIRNAME,1,36) DIRNAME, BOMSALARY, TDSYN, CASE WHEN tdsyn = 'Y' THEN (BOMSALARY * 10/100 ) ELSE 0 END tdsamt,'Y' executionyn FROM gendirectordtls WHERE sittingfee = 'N' AND bomsalary <> 0 and status = 'R' AND bom ='Y' and DIRCODE not in (SELECT DIRCODE from  BOMSALPAIDDTLS WHERE PAIDMONTH='" & strArr(1) & "' AND  PAIDYEAR='" & strArr(2) & "') ORDER BY dircode"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value  & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				else
					strResult = "No Records"
				end if
			end if
			
			rs=nothing
			obj=nothing
			
else if strArr(0)="BODBOMSalaryRep" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="select d.DIRCODE,case when g.BOD = 'Y' then 'BOD' else 'BOM' end dirtype, g.DIRNAME,d.BOMSALARY,d.TDS from BOMSALPAIDDTLS d, gendirectordtls g where d.dircode = g.dircode and d.PAIDMONTH='" & strArr(1) & "' and d.PAIDYEAR='" & strArr(2) & "' ORDER BY d.dircode"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value  & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				else
					strResult = "No Records"
				end if
			end if
			
			rs=nothing
			obj=nothing
						
else if strArr(0)="TENANTGEN" then
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr="SELECT CRBRANCHCODE, MODULEID, GLCODE, ACCNO, AMOUNT, GSTYN, REVGSTYN FROM TENANTMST WHERE branchcode='" & strArr(3) & "' AND status='R' AND DUEDATE >= '" & strArr(4) & "' AND (CRBRANCHCODE, MODULEID, GLCODE, ACCNO) NOT IN (SELECT CRBRANCHCODE, MODULEID, GLCODE, ACCNO FROM TENANTPAIDDTLS WHERE PAIDMONTH='" & strArr(1) & "' AND  PAIDYEAR='" & strArr(2) & "' AND branchcode='" & strArr(3) & "') ORDER BY CRBRANCHCODE "
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				else
					strResult = "No Records"
				end if
			end if
			
			rs=nothing
			obj=nothing
			
else if strArr(0)="TENANTGENRAT" then
	
		strResult=""
			
		strdelvar = strArr(1)
		
		upval = split(strdelvar,"$")
		
		cnt=upval.length
		
		i=0
		
		for i = 0 to cnt-1
			
			udata = split(upval(i),"~")
			
			obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
			sqlStr=""
			
			sqlStr="SELECT x.CRBRANCHCODE, x.MODULEID, x.GLCODE, x.ACCNO, x.AMOUNT,x.GSTAMT,x.REVGSTAMT,x.tds,x.advinsamt,(x.amount-x.tds-x.advinsamt) netamt,x.TENANTID,x.RECVUPTO  FROM (SELECT CRBRANCHCODE, MODULEID, GLCODE, ACCNO, NVL(Amount,0) amount, CASE WHEN GSTYN = 'Y' THEN (AMOUNT*(SELECT VALUE1 FROM genconfigmst WHERE CODE='GSTR'))/100 ELSE 0 END GSTAMT ,CASE WHEN REVGSTYN = 'Y' THEN ((AMOUNT*(SELECT VALUE1 FROM genconfigmst WHERE CODE='GSTR'))/100)/2 ELSE 0 END REVGSTAMT, NVL(tds,0) tds,NVL(( SELECT Advinsamt FROM TENANTADVRECVLNK WHERE TENANTID = t.TENANTID and RECVUPTO >= '"& format(cdate(session("applicationdate")),"dd-MMM-yyyy") &"'),0) advinsamt, t.TENANTID,(SELECT RECVUPTO  FROM TENANTADVRECVLNK where tenantid = t.TENANTID) RECVUPTO FROM TENANTMST t WHERE accno='" & udata(3) & "' AND glcode = '" & udata(2) & "'  AND moduleid='" & udata(1) & "' AND amount='" & udata(4) & "' AND Crbranchcode='" & udata(0) & "' AND branchcode='" & strArr(2) & "' AND status='R' AND DUEDATE >= '" & strArr(3) & "') x "
		
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "|"
					rs.movenext()
					loop
				end if
			end if
			
			rs=nothing
			obj=nothing
				
		next 
		
		
		if strResult = "" then
			strResult = "No Records"
		else
			strResult=mid(strResult,1,strResult.length-1)
		end if
			
			
else if strArr(0)="CheckLoanDepstatusYN" then
			obj = server.CreateObject("ReportPurposeOnly.Reportonly")
				obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
		rs1 = Server.CreateObject("adodb.recordset")
		
	dim stremp,strdep,strloan
	strResult=""
	stremp = split(strArr(1),",")
	strdep = split(strArr(2),",")
	strloan = split(strArr(3),",")
	for i= 0 to ubound(stremp)
			if strdep(i) <> 0 then
			  StrQuery = "SELECT branchcode, moduleid, glcode, accno, amount FROM SALARYDEDUCTIONMST WHERE dedtype='DEP' AND empcode IN ( SELECT  EMPCODE FROM employeemst WHERE EMPNAME LIKE '%"& stremp(i) &"%' AND status='R') AND STATUS='R' "
			  rs=obj.SingleSelectStat(StrQuery)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					 StrQuery = "SELECT STATUS FROM " & rs(1).value & "MST WHERE accno='" & rs(3).value & "' AND glcode='" & rs(2).value & "' AND branchcode='" & rs(0).value & "'"					
							rs1=obj1.SingleSelectStat(StrQuery)
							if obj1.ConnError="Connected" then
										if not rs1.BOF and not rs1.EOF then
											if rs1(0).value = "C" then
											strResult= strResult & " " &  stremp(i) & " Deposit Account is Closed" & "|"
											end if 
										end if 
							end if 			
				end if ''not rs.BOF and not rs.EOF 
			end if	''obj.ConnError="Connected"
			rs= nothing
			rs1= nothing
			
			end if ''strdep(i) <> 0
			
			if strloan(i) <> 0 then
			StrQuery = "SELECT branchcode, moduleid, glcode, accno, amount FROM SALARYDEDUCTIONMST WHERE dedtype='LOAN' AND empcode IN ( SELECT  EMPCODE FROM employeemst WHERE EMPNAME LIKE '%"& stremp(i) &"%' AND status='R') AND STATUS='R' "
			  rs=obj.SingleSelectStat(StrQuery)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					 StrQuery = "SELECT STATUS FROM " & rs(1).value & "MST WHERE accno='" & rs(3).value & "' AND glcode='" & rs(2).value & "' AND branchcode='" & rs(0).value & "'"					
							rs1=obj1.SingleSelectStat(StrQuery)
							if obj1.ConnError="Connected" then
										if not rs1.BOF and not rs1.EOF then
											if rs1(0).value = "C" then
											strResult= strResult & " " &  stremp(i) & " Loan Account is Closed" & "|"
											end if 
										end if 
							end if 			
				end if ''not rs.BOF and not rs.EOF 
			end if	''obj.ConnError="Connected"
			rs= nothing
			rs1= nothing
			
			
			end if ''strloan(i) <> 0
	next i
	if strResult = "" then
			strResult = "No Records"
		else
			strResult=mid(strResult,1,strResult.length-1)
		end if
else if strArr(0)="SALGENRAT" then
	
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
		rs1 = Server.CreateObject("adodb.recordset")
		
		
	dim stryn,resul
	stryn = "Yes"
	
	''commented by Mahender on 04-feb-2017
	
	'stryn = "No"
	
	'sqlStr="SELECT DISTINCT paidmonth FROM SALARYPAIDDTLS WHERE paidyear='" & strArr(2) & "' AND BRANCHCODE='" & strArr(3) & "' "
		
	'	rs1=obj1.SingleSelectStat(sqlStr)
	'	if obj1.ConnError="Connected" then
	'		if not rs1.BOF and not rs1.EOF then
	'			do until rs1.EOF
					
	'				if strArr(1) = rs1(0).value then
	'					stryn = "exit"	
	'					strResult = "EXIT"
	'					exit do
	'					'' exit 
	'				else
	'					stryn = "Yes"
	'				end if
					
	'				rs1.movenext()
	'			loop
	'		else
	'			stryn = "Yes"
	'		end if
	'	end if
		
		dim rsBnk,objBnk,frmname,staccond
		rsBnk=server.CreateObject("adodb.recordset")
		objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
		rsBnk=objBnk.singlerecordset("genbankparm","depcertificate","")
		
		if objBnk.ConnError="Connected" then	
			if not rsBnk.EOF and not rsBnk.BOF then
				frmname=rsBnk(0).value
			end if
		end if
		
		
		dim rsPimp,objPimp,PimpYn,PimpVal
		rsPimp=server.CreateObject("adodb.recordset")
		objPimp=server.CreateObject("queryrecordsets.fetchrecordsets")
		rsPimp=objPimp.singlerecordset("GENCONFIGMST","IMPYN, value1","CODE='PFIMP'")
		
		if objPimp.ConnError="Connected" then	
			if not rsPimp.EOF and not rsPimp.BOF then
				PimpYn = rsPimp(0).value
				PimpVal = rsPimp(1).value
			end if
		end if
		
			sqlStr = ""
		if stryn = "Yes" then
			'sqlStr="SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,nvl((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow,NVL(GROSSPAY,0) gros, NVL(PROVFUND,0) PROVFUND, NVL(PROFTAX,0) PROFTAX,NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP,NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN,NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV,NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='TDS' AND status='R' ),0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other FROM EMPLOYEEMST A WHERE status='R' and grosspay<>'0'"
			''sqlStr = " SELECT x.EMPNAME,x.bas,x.da,x.hra,x.allow,x.gros,CASE WHEN x.PROVFUND > 1800 THEN 1800 ELSE x.PROVFUND END pf,x.PROFTAX,x.DEP,x.LOAN,x.ADV,x.TDS,x.GIP,x.other,x.ESI,x.vpf,x.othAlow FROM (SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,NVL((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow, NVL(GROSSPAY,0) gros, ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF')),0))/100),0))PROVFUND, NVL(PROFTAX,0) PROFTAX, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='TDS' AND status='R' ),0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other, CASE WHEN ESI = 'Y' AND GROSSPAY < '15000' THEN ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI')),0))/100),0)) ELSE 0 END ESI, ROUND(NVL(((NVL(BASIC,0)*NVL(VPF,0))/100),0)) vpf, 0 othAlow FROM EMPLOYEEMST A WHERE status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & strArr(3) & "')x "
			
			''sqlStr = " SELECT x.EMPNAME,x.bas,x.da,x.hra,x.allow,x.gros,CASE WHEN x.PROVFUND > 1800 THEN 1800 ELSE x.PROVFUND END pf,x.PROFTAX,x.DEP,x.LOAN,x.ADV,x.TDS,x.GIP,x.other,x.ESI,x.vpf,x.othAlow FROM (SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,NVL((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow, NVL(GROSSPAY,0) gros, ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF')),0))/100),0))PROVFUND, NVL(PROFTAX,0) PROFTAX, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV, NVL(TDS,0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other, CASE WHEN ESI = 'Y' AND GROSSPAY < '15000' THEN ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI')),0))/100),0)) ELSE 0 END ESI, NVL(VPF,0) vpf, 0 othAlow FROM EMPLOYEEMST A WHERE status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & strArr(3) & "')x "
			
			''Changed due to Pf value Changed on 23-Jan-2017
			
			if PimpYn = "Y" then
				sqlStr = " SELECT x.EMPNAME,x.bas,x.da,x.hra,x.allow,x.gros,CASE WHEN x.PROVFUND > " & PimpVal & " THEN " & PimpVal & " ELSE x.PROVFUND END pf,x.PROFTAX,x.DEP,x.LOAN,x.ADV,x.TDS,x.GIP,x.other,x.ESI,x.vpf,x.othAlow FROM (SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,NVL((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow, NVL(GROSSPAY,0) gros, ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF')),0))/100),0))PROVFUND, NVL(PROFTAX,0) PROFTAX, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV, NVL(TDS,0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other, CASE WHEN ESI = 'Y' AND GROSSPAY < '15000' THEN ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI')),0))/100),0)) ELSE 0 END ESI, NVL(VPF,0) vpf, 0 othAlow FROM EMPLOYEEMST A WHERE status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & strArr(3) & "' " & strArr(4) & ")x "
			else
				if frmname = "ELURU" then
					sqlStr = " SELECT x.EMPNAME,x.bas,x.da,x.hra,x.allow,x.gros, x.PROVFUND ,x.PROFTAX,x.DEP,x.LOAN,x.ADV,x.TDS,x.GIP,x.other,x.ESI,x.vpf,x.othAlow FROM (SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,NVL((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow, NVL(GROSSPAY,0) gros, ROUND(NVL((((NVL(BASIC,0)+NVL(DA,0))*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF')),0))/100),0))PROVFUND, NVL(PROFTAX,0) PROFTAX, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV, NVL(TDS,0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other, CASE WHEN ESI = 'Y' AND GROSSPAY < '15000' THEN ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI')),0))/100),0)) ELSE 0 END ESI, NVL(VPF,0) vpf, 0 othAlow FROM EMPLOYEEMST A WHERE status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & strArr(3) & "' " & strArr(4) & ")x "
				else
					sqlStr = " SELECT x.EMPNAME,x.bas,x.da,x.hra,x.allow,x.gros, x.PROVFUND ,x.PROFTAX,x.DEP,x.LOAN,x.ADV,x.TDS,x.GIP,x.other,x.ESI,x.vpf,x.othAlow FROM (SELECT EMPNAME,NVL(BASIC,0) bas, NVL(DA,0) da, NVL(HRA,0) hra,NVL((NVL(ALLOWANCE,0)+NVL(MEDIREIMB,0)+NVL(OTHERALLOWANCE,0)),0) allow, NVL(GROSSPAY,0) gros, ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='PF')),0))/100),0))PROVFUND, NVL(PROFTAX,0) PROFTAX, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='DEP' AND status='R' ),0) DEP, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='LOAN' AND status='R' ),0) LOAN, NVL((SELECT SUM(AMOUNT) FROM SALARYDEDUCTIONMST b WHERE B.EMPCODE=A.EMPCODE AND DEDTYPE='ADV' AND status='R' ),0)ADV, NVL(TDS,0)TDS, CASE WHEN gip = 'Y' THEN NVL((SELECT NVL(value,0) val FROM SALARYPARMST WHERE status='R' AND code='GIP' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='GIP')),0) ELSE 0 END GIP, 0 other, CASE WHEN ESI = 'Y' AND GROSSPAY < '15000' THEN ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMP' AND CODE='ESI')),0))/100),0)) ELSE 0 END ESI, NVL(VPF,0) vpf, 0 othAlow FROM EMPLOYEEMST A WHERE status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & strArr(3) & "' " & strArr(4) & ")x "
				end if
			
			end if
			
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value &  "|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
	end if
	
	rs1=nothing
	obj1=nothing
	
	else if strArr(0)="SALREPRT" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		if strArr(4) = "Y" then
		sqlStr="SELECT a.EMPCODE, substr(b.EMPNAME,0,40) empnam, a.BASIC, a.DA, a.HRA, a.ALLOWANCE, a.GROSS, a.PF, a.PTAX, a.RD, a.LOAN, a.ADVANCES, a.GIP, a.TDS, a.OTHDEDUC, a.ESI, a.VPF, a.OTHALOW, a.NETPAY,g.panno FROM SALARYPAIDDTLS a ,EMPLOYEEMST b, gencustinfomst g  WHERE b.customerid= g.customerid and b.EMPCODE=a.EMPCODE AND a.paidmonth='" & strArr(1) & "' AND a.PAIDYEAR = '" & strArr(2) & "' ORDER BY TO_NUMBER(EMPCODE)"
		else
			sqlStr="SELECT a.EMPCODE, substr(b.EMPNAME,0,40) empnam, a.BASIC, a.DA, a.HRA, a.ALLOWANCE, a.GROSS, a.PF, a.PTAX, a.RD, a.LOAN, a.ADVANCES, a.GIP, a.TDS, a.OTHDEDUC, a.ESI, a.VPF, a.OTHALOW, a.NETPAY,g.panno FROM SALARYPAIDDTLS a ,EMPLOYEEMST b, gencustinfomst g  WHERE b.customerid= g.customerid and b.EMPCODE=a.EMPCODE AND a.paidmonth='" & strArr(1) & "' AND a.PAIDYEAR = '" & strArr(2) & "' and  a.branchcode='" & strArr(3) & "' ORDER BY TO_NUMBER(EMPCODE)"
		end if	
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
	else if strArr(0)="FILEGEN" then
	
		strResult=""
		dim rscust
		dim strCustomerid
		rscust = Server.CreateObject("adodb.recordset")
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		if strDepcertificate = "PCUB"  then
		
		sqlStr="SELECT REFNO, SUBSTR(CITYCODE,1,3), SUBSTR(BANKCODE,1,3), SUBSTR(BRCODE,1,3), LPAD(MICRCODE,9,0) MICRCODE, SUBSTR(ACCNO,11,6), LPAD(ACCNO,20,'0'), SUBSTR(ACTYPE,1,2), SUBSTR(NAME,1,50) , SUBSTR(JNAME1,1,50), SUBSTR(JNAME2,1,50), SUBSTR( SIGNAME1,1,30), SUBSTR( SIGNAME2,1,30),  SUBSTR( SIGNAME3,1,30), SUBSTR( ADDR1,1,50), SUBSTR( ADDR2,1,50), SUBSTR( ADDR3,1,50),  SUBSTR(CITY,1,30), SUBSTR(PINCODE,1,6), NOBOOKS, NOPAGES, SUBSTR(BO,1,6), ATPAR, SUBSTR(CHQFROM,1,6), SUBSTR(CHQTO,1,6) FROM CHQREQSTDTLS WHERE transtatus='A' AND status='R' and AF2GENDATE is not null and GENYN='N' " & strArr(1) & " " & strArr(2) & " ORDER BY TO_NUMBER(REFNO)"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
					
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value & "~" & rs(23).value & "~" & rs(24).value &  "|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		else if strDepcertificate = "ELURU"  then
		
		sqlStr="SELECT REFNO, SUBSTR(CITYCODE,1,3), SUBSTR(BANKCODE,1,3), SUBSTR(BRCODE,1,3), LPAD(MICRCODE,9,0) MICRCODE, SUBSTR(ACCNO,11,6), LPAD(ACCNO,20,'0'), SUBSTR(ACTYPE,1,2), SUBSTR(NAME,1,50) , SUBSTR(JNAME1,1,50), SUBSTR(JNAME2,1,50), SUBSTR( SIGNAME1,1,30), SUBSTR( SIGNAME2,1,30),  SUBSTR( SIGNAME3,1,30), SUBSTR( ADDR1,1,50), SUBSTR( ADDR2,1,50), SUBSTR( ADDR3,1,50),  SUBSTR(CITY,1,30), SUBSTR(PINCODE,1,6),1 NOBOOKS,to_number(NOBOOKS) *  to_number(NOPAGES), SUBSTR(BO,1,6), ATPAR, SUBSTR(CHQFROM,1,6), SUBSTR(CHQTO,1,6) FROM CHQREQSTDTLS WHERE transtatus='A' AND status='R' and AF2GENDATE is not null and GENYN='N' " & strArr(1) & " " & strArr(2) & " ORDER BY TO_NUMBER(REFNO)"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
					
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value & "~" & rs(23).value & "~" & rs(24).value &  "|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		
			else 
				'sqlStr="SELECT REFNO, CITYCODE, BANKCODE, BRCODE, BSRID, LPAD(MICRCODE,6,0) MICRCODE, ACCNO, ACTYPE, NAME, JNAME1, JNAME2, SIGNAME1, SIGNAME2, SIGNAME3, ADDR1, ADDR2, ADDR3, ADDR4, ADDR5, CITY, PINCODE, TELRES, TELOFF, MOBILE, NOBOOKS, NOPAGES, BO, ATPAR, PRCCODE, CHQFROM, CHQTO, AF1REQDATE, AF2GENDATE, AF3SLNO, AF4ACTYPE, AF5, AF6GLCD, AF7MICR, AF8BRCD, AF9,SUBSTR(ACCNO,1,3) brcode1,SUBSTR(ACCNO,4,6) glcode1,LTRIM(SUBSTR(ACCNO,10,7),'0') accno1 FROM CHQREQSTDTLS WHERE transtatus='A' AND status='R' and AF2GENDATE is not null and GENYN='N' " & strArr(1) & " " & strArr(2) & " ORDER BY TO_NUMBER(REFNO)"

				
			sqlStr="SELECT REFNO, CITYCODE, BANKCODE, BRCODE, BSRID, SUBSTR(ACCNO,11,7) accno2, ACCNO, ACTYPE, NAME, JNAME1, JNAME2, SIGNAME1, SIGNAME2, SIGNAME3, ADDR1, ADDR2, ADDR3, ADDR4, ADDR5, CITY, PINCODE, TELRES, TELOFF, MOBILE, NOBOOKS, NOPAGES, BO, ATPAR, PRCCODE, CHQFROM, CHQTO, AF1REQDATE, AF2GENDATE, AF3SLNO, AF4ACTYPE, AF5, AF6GLCD, SUBSTR(ACCNO,11,7) accno3, AF8BRCD, AF9,SUBSTR(ACCNO,1,3) brcode1,SUBSTR(ACCNO,4,6) glcode1,LTRIM(SUBSTR(ACCNO,10,7),'0') accno1 FROM CHQREQSTDTLS WHERE transtatus='A' AND status='R' and AF2GENDATE is not null and GENYN='N' " & strArr(1) & " " & strArr(2) & " ORDER BY TO_NUMBER(REFNO)"
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
					strCustomerid = ""
					if rs(34).value = "SB" or rs(34).value = "CA" or rs(34).value = "CC" then
						sqlstr = "select customerid from " & rs(34).value & "mst where branchcode = '"& rs(40).value &"' and glcode = '"& rs(41).value &"' and accno = '"& rs(42).value &"'" 
						rscust=obj.SingleSelectStat(sqlStr)
						if obj.ConnError="Connected" then
							if not rscust.BOF and not rscust.EOF then
							strCustomerid = iif(isdbnull(rscust(0).value),"",rscust(0).value)
							end if
						end if	
						rscust=nothing			
					end if
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value & "~" & rs(23).value & "~" & rs(24).value & "~" & rs(25).value & "~" & rs(26).value & "~" & rs(27).value & "~" & rs(28).value & "~" & rs(29).value & "~" & rs(30).value & "~" & rs(31).value & "~" & rs(32).value & "~" & rs(33).value & "~" & rs(34).value & "~" & rs(35).value & "~" & rs(36).value & "~" & rs(37).value & "~" & rs(38).value & "~" & rs(39).value & "~" & strCustomerid & "~|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
					
			
			end if ''strDepcertificate 
			rs=nothing
			obj=nothing
	
		else if strArr(0)="BCFILEGEN" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			sqlStr="SELECT REFNO, CITYCODE, BANKCODE, BRCODE, BSRID, LPAD(MICRCODE,6,0) MICRCODE, ACCNO, ACTYPE, NAME, JNAME1, JNAME2, SIGNAME1, SIGNAME2, SIGNAME3, ADDR1, ADDR2, ADDR3, ADDR4, ADDR5, CITY, PINCODE, TELRES, TELOFF, MOBILE, NOBOOKS, NOPAGES, BO, ATPAR, PRCCODE, CHQFROM, CHQTO, AF1REQDATE, AF2GENDATE, AF3SLNO, AF4ACTYPE, AF5, AF6GLCD, AF7MICR, AF8BRCD, AF9 FROM BCREQSTDTLS WHERE transtatus='A' AND status='R' and AF2GENDATE is not null and GENYN='N' " & strArr(1) & " ORDER BY TO_NUMBER(REFNO)"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value & "~" & rs(15).value & "~" & rs(16).value & "~" & rs(17).value & "~" & rs(18).value & "~" & rs(19).value & "~" & rs(20).value & "~" & rs(21).value & "~" & rs(22).value & "~" & rs(23).value & "~" & rs(24).value & "~" & rs(25).value & "~" & rs(26).value & "~" & rs(27).value & "~" & rs(28).value & "~" & rs(29).value & "~" & rs(30).value & "~" & rs(31).value & "~" & rs(32).value & "~" & rs(33).value & "~" & rs(34).value & "~" & rs(35).value & "~" & rs(36).value & "~" & rs(37).value & "~" & rs(38).value & "~" & rs(39).value & "~|" 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
	
	else if strArr(0)="USERPSW" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			sqlStr=" SELECT TO_CHAR(a.PWDEXPIRYDT,'DD-Mon-YYYY') pswdat,TO_CHAR(b.EXPIRYDATE,'DD-Mon-YYYY') EXPIRYDATE FROM GENPROMOTIONSMST a, genusermst b WHERE a.EMPID=b.userid AND a.branchcode=b.branchcode AND b.userid='" & strArr(1) & "' AND b.branchcode = '" & strArr(2) & "'  "
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					strResult = rs(0).value & "~" & rs(1).value 
				end if
			end if
			
			rs=nothing
			obj=nothing
	
	else if strArr(0)="ESI" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			sqlStr = " SELECT b.empname, a.ESI, a.EMPRESI FROM SALARYPAIDDTLS a, EMPLOYEEMST b WHERE a.ESI<>'0' and  a.EMPRESI<>'0' AND a.PAIDMONTH='" & strArr(2) & "' AND a.paidyear='" & strArr(3) & "' AND b.EMPCODE=a.EMPCODE " & strArr(1) & " AND a.branchcode='" & strArr(4) & "'"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
	
	else if strArr(0)="PF" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			sqlStr = " SELECT b.empname, a.PF, a.EMPRPF FROM SALARYPAIDDTLS a, EMPLOYEEMST b WHERE a.PF<>'0' AND  a.EMPRPF<>'0' AND a.PAIDMONTH='" & strArr(2) & "' AND a.paidyear='" & strArr(3) & "' AND b.EMPCODE=a.EMPCODE " & strArr(1) & " AND a.branchcode='" & strArr(4) & "' "
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
	else if strArr(0)="VPF" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			sqlStr = " SELECT b.empname,a.VPF FROM SALARYPAIDDTLS a, EMPLOYEEMST b WHERE a.VPF<>'0' AND a.PAIDMONTH='" & strArr(2) & "' AND a.paidyear='" & strArr(3) & "' AND b.EMPCODE=a.EMPCODE " & strArr(1) & " AND a.branchcode='" & strArr(4) & "' "
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
	
	else if strArr(0)="EMPDTLS" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
			'sqlStr = " SELECT EMPCODE, a.USERID, SUBSTR(EMPNAME,0,25)EMPNAME , b.DESCRIPTION, TO_CHAR(APPOINTDT,'DD-Mon-YYYY') APPOINTDT, TO_CHAR(PERMENTDT,'DD-Mon-YYYY') PERMENTDT, WORKINGBRCODE, TO_CHAR(LETTERDT,'DD-Mon-YYYY') LETTERDT, TO_CHAR(LEAVINGDT,'DD-Mon-YYYY') LEAVINGDT, SUBSTR(REASON,0,30)REASON , EPFACCNO FROM EMPLOYEEMST a , GENDESIGNATIONMST b WHERE b.code=a.DESGNCODE and a.branchcode='" & strArr(3) & "' " & strArr(2) & " " & strArr(1) & " order by to_number(EMPCODE)"
	
	sqlStr = " SELECT EMPCODE, a.USERID, SUBSTR(EMPNAME,0,25)EMPNAME , b.DESCRIPTION, TO_CHAR(APPOINTDT,'DD-Mon-YYYY') APPOINTDT, TO_CHAR(PERMENTDT,'DD-Mon-YYYY') PERMENTDT, WORKINGBRCODE, TO_CHAR(LETTERDT,'DD-Mon-YYYY') LETTERDT, TO_CHAR(LEAVINGDT,'DD-Mon-YYYY') LEAVINGDT, SUBSTR(REASON,0,30)REASON , EPFACCNO FROM EMPLOYEEMST a , GENDESIGNATIONMST b WHERE b.code=a.DESGNCODE " & strArr(2) & " " & strArr(1) & " order by to_number(EMPCODE)"
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
	else if strArr(0)="TENANTMAST" then
	
		strResult=""
			obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
								rs1 = Server.CreateObject("adodb.recordset")
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
								
		'	sqlStr = " SELECT a.crbranchcode,b.BRANCHNAME, a.moduleid, c.NARRATION moddesc, a.glcode,d.NARRATION gldesc, a.accno, a.amount, a.gstyn, a.revgstyn, TO_CHAR(a.duedate,'dd-Mon-YYYY') duedat, a.TDS tdsamt, a.status,'' clsdat,'N' modfy  FROM TENANTMST a, GENBANKBRANCHMST b,GENMODULETYPESMST c,GENGLSHEETMST d WHERE a.crbranchcode = b.branchcode AND a.crbranchcode = c.branchcode AND a.moduleid = c.moduleid AND a.crbranchcode = d.branchcode AND a.moduleid = d.moduleid AND a.glcode =d.glcode AND a.branchcode='" & strArr(1) & "' AND a.status='R' "
		
			sqlStr = " SELECT a.crbranchcode,(SELECT BRANCHNAME FROM GENBANKBRANCHMST WHERE ROWNUM = 1 AND  branchcode = a.crbranchcode) BRANCHNAME, a.moduleid, (SELECT narration FROM GENMODULETYPESMST WHERE ROWNUM = 1 AND   branchcode = a.crbranchcode AND moduleid = a.moduleid ) moddesc, a.glcode,(SELECT narration  FROM GENGLSHEETMST WHERE ROWNUM = 1 AND  branchcode = a.crbranchcode AND moduleid = a.moduleid AND glcode = a.glcode) gldesc,  a.accno, a.amount, a.gstyn, a.revgstyn, TO_CHAR(a.duedate,'dd-Mon-YYYY') duedat, a.TDS tdsamt, a.status,'' clsdat,'N' modfy, l.BRANCHCODE recbrcode, (SELECT BRANCHNAME FROM GENBANKBRANCHMST WHERE ROWNUM = 1 AND  branchcode = l.branchcode) recbrname,   l.MODULEID recmodid, (SELECT narration FROM GENMODULETYPESMST WHERE ROWNUM = 1 AND   branchcode = l.branchcode AND moduleid = l.moduleid ) recmoddesc, l.GLCODE recglcode,(SELECT narration  FROM GENGLSHEETMST WHERE ROWNUM = 1 AND branchcode = l.branchcode AND moduleid = l.moduleid AND glcode = l.glcode ) recgldesc  , l.ACCNO recaccno,   l.RECADVAMT,l.Noofinst,l.Advinsamt, l.RECVUPTO,l.STATUS,   l.tenantid,a.branchcode  FROM TENANTMST a,  TENANTADVRECVLNK l  WHERE a.tenantid = l.tenantid(+)  AND a.status='R'  "
			
			rs=obj.SingleSelectStat(sqlStr)
				if obj.ConnError="Connected" then
					if not rs.BOF and not rs.EOF then
						do until rs.EOF
						
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "~" & rs(13).value & "~" & rs(14).value 
						
							sqlStr = ""
								
							if isdbnull(rs(6).value) = false then
								
								sqlStr="SELECT N.NAME  FROM " & rs(2).value & "MST N WHERE N.BRANCHCODE='" & rs(0).value & "' AND N.GLCODE='" & rs(4).value & "' AND N.ACCNO='" & rs(6).value & "'"
								
						
								rs1=obj1.SingleSelectStat(sqlStr)
								if obj1.ConnError="Connected" then
									if not rs1.BOF and not rs1.EOF then
										strResult=strResult & "~" & rs1(0).value 
									end if
								end if
								
								rs1 = nothing
								'obj1 = nothing
								
							else
								strResult=strResult & "~" & "" 
							end if
							
							strResult = strResult &  "~" & rs(15).value &  "~" & rs(16).value &  "~" & rs(17).value &  "~" & rs(18).value &  "~" & rs(19).value &  "~" & rs(20).value &  "~" & rs(21).value  
							
							'' recovery accno 
								if isdbnull(rs(21).value) = false then
								
								sqlStr="SELECT N.NAME  FROM " & rs(17).value & "MST N WHERE N.BRANCHCODE='" & rs(15).value & "' AND N.GLCODE='" & rs(19).value & "' AND N.ACCNO='" & rs(21).value & "'"
								
								
							
								rs1=obj1.SingleSelectStat(sqlStr)
								if obj1.ConnError="Connected" then
									if not rs1.BOF and not rs1.EOF then
										strResult=strResult & "~" & rs1(0).value 
									end if
								end if
								
								rs1 = nothing
								'obj1 = nothing
								
							else
								strResult=strResult & "~" & "" 
							end if
						strResult = strResult &  "~" & rs(22).value  &  "~" & rs(23).value &  "~" & rs(24).value &  "~" & rs(25).value &  "~" & rs(26).value &  "~" & rs(27).value  &  "~" & rs(28).value &  "|"
						
						rs.movenext()
						loop
				
						strResult=mid(strResult,1,strResult.length-1)
					end if
				end if
			rs=nothing
			obj=nothing
	
	else if strArr(0)="RECUPTO" then
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	dim strnoofins
	strnoofins = cint(strArr(1)) + 1
	sqlStr = "SELECT TO_CHAR(ADD_MONTHS('"& session("applicationdate") &"', "& strnoofins &"), 'DD-MON-YYYY') FROM dual "
	rs=obj.SingleSelectStat(sqlStr)
				if obj.ConnError="Connected" then
					if not rs.BOF and not rs.EOF then
					strResult = rs(0).value
					end if
				end if	
	else if strArr(0)="RENTDETAILREP" then
	
		strResult=""
	
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
								
			sqlStr = " SELECT a.crbranchcode, a.moduleid, a.glcode, a.accno, a.amount, a.gstyn, a.revgstyn, a.TDS, TO_CHAR(a.OPDATE,'dd-Mon-YYYY') OPDATE, TO_CHAR(a.duedate,'dd-Mon-YYYY') duedat, TO_CHAR(a.CLOSEDATE,'dd-Mon-YYYY') CLOSEDATE, a.narration remarks, a.status  FROM TENANTMST a " & strArr(1) & " "
			
			rs=obj.SingleSelectStat(sqlStr)
				if obj.ConnError="Connected" then
					if not rs.BOF and not rs.EOF then
						do until rs.EOF
						
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value
						
							sqlStr = ""
								
							if isdbnull(rs(3).value) = false then
								
								sqlStr="SELECT N.NAME  FROM " & rs(1).value & "MST N WHERE N.BRANCHCODE='" & rs(0).value & "' AND N.GLCODE='" & rs(2).value & "' AND N.ACCNO='" & rs(3).value & "' GROUP BY N.NAME"
								
								obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
								rs1 = Server.CreateObject("adodb.recordset")
							
								rs1=obj1.SingleSelectStat(sqlStr)
								if obj1.ConnError="Connected" then
									if not rs1.BOF and not rs1.EOF then
										strResult=strResult & "~" & rs1(0).value & "|"
									end if
								end if
								
								'rs1 = nothing
								'obj1 = nothing
								
							else
								strResult=strResult & "~" & "" & "|"
							end if
						rs.movenext()
						loop
					
						strResult=mid(strResult,1,strResult.length-1)
					end if
				end if
			rs=nothing
			obj=nothing
			
	else if strArr(0)="RENTPAIDREP" then
	
		strResult=""
	
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
								
			sqlStr = " SELECT CRBRANCHCODE, MODULEID, GLCODE, ACCNO, AMOUNT, GST, REVGST, TDS, NETPAY, PAIDBATCH FROM tenantpaiddtls  WHERE paidmonth='" & strArr(1) & "' AND paidyear='" & strArr(2) & "' " & strArr(3) & " "
			
			rs=obj.SingleSelectStat(sqlStr)
				if obj.ConnError="Connected" then
					if not rs.BOF and not rs.EOF then
						do until rs.EOF
						
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value 
						
							sqlStr = ""
								
							if isdbnull(rs(3).value) = false then
								
								sqlStr="SELECT N.NAME  FROM " & rs(1).value & "MST N WHERE N.BRANCHCODE='" & rs(0).value & "' AND N.GLCODE='" & rs(2).value & "' AND N.ACCNO='" & rs(3).value & "' GROUP BY N.NAME"
								
								obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
								rs1 = Server.CreateObject("adodb.recordset")
							
								rs1=obj1.SingleSelectStat(sqlStr)
								if obj1.ConnError="Connected" then
									if not rs1.BOF and not rs1.EOF then
										strResult=strResult & "~" & rs1(0).value & "|"
									end if
								end if
								
								'rs1 = nothing
								'obj1 = nothing
								
							else
								strResult=strResult & "~" & "" & "|"
							end if
						rs.movenext()
						loop
					
						strResult=mid(strResult,1,strResult.length-1)
					end if
				end if
			rs=nothing
			obj=nothing
			
	else if strArr(0)="RBIOUTWORD" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		if strArr(1)="MONTH" then
			
			sqlStr = " SELECT TO_CHAR(b.CLGDATE, 'YYYY-MM') MONTH, SUM(B.TOTINSTR) TOTINSTR, SUM(TOTAMT) TOTALAMT, SUM(NOOFCLR) NOOFCLR, SUM(CLEARAMT) CLEARAMT,SUM(NOOFRET) NOOFRET, SUM(RETAMT) RETAMT FROM ( SELECT a.LODGEMENTDATE CLGDATE,  SUM(a.noofinstr) TOTINSTR, SUM(a.amt) TOTAMT, SUM(CCNT) NOOFCLR,NVL(SUM(a.clgamt),0) CLEARAMT, nvl(SUM(RCNT),0) NOOFRET,NVL(SUM(a.retamt),0) RETAMT FROM ( SELECT LODGEMENTDATE, status, noofinstr,amt,(CASE WHEN status='C' THEN noofinstr ELSE NULL END) CCNT,(CASE WHEN status='C' THEN AMT ELSE NULL END) CLGAMT, (CASE WHEN status='R' THEN noofinstr ELSE NULL END) RCNT, (CASE WHEN status='R' THEN AMT ELSE NULL END) RETAMT FROM ( SELECT LODGEMENTDATE, status, COUNT(*) noofinstr, SUM(amount) AMT FROM CLGLODGEMENTINSTRUMENTDTLS WHERE " & strArr(2) & " " & strArr(3) & " GROUP BY LODGEMENTDATE, status) )a GROUP BY a.LODGEMENTDATE ) B GROUP BY TO_CHAR(b.CLGDATE, 'YYYY-MM') ORDER BY TO_CHAR(b.CLGDATE, 'YYYY-MM') "
		
		else if strArr(1)="DAY" then
			
			sqlStr = " SELECT  TO_CHAR(a.LODGEMENTDATE, 'DD-MON-yyyy' ) CLGDATE,  SUM(a.noofinstr) TOTINSTR, SUM(a.amt) TOTAMT, SUM(CCNT) NOOFCLR,NVL(SUM(a.clgamt),0) CLEARAMT, nvl(SUM(RCNT),0) NOOFRET,NVL(SUM(a.retamt),0) RETAMT FROM ( SELECT  LODGEMENTDATE, status, noofinstr,amt,(CASE WHEN status='C' THEN noofinstr ELSE NULL END) CCNT,(CASE WHEN status='C' THEN AMT ELSE NULL END) CLGAMT, (CASE WHEN status='R' THEN noofinstr ELSE NULL END) RCNT, (CASE WHEN status='R' THEN AMT ELSE NULL END) RETAMT FROM ( SELECT  LODGEMENTDATE, status, COUNT(*) noofinstr, SUM(amount) AMT FROM CLGLODGEMENTINSTRUMENTDTLS WHERE " & strArr(2) & " " & strArr(3) & "  GROUP BY  LODGEMENTDATE, status) )a  GROUP BY  a.LODGEMENTDATE  ORDER BY a.LODGEMENTDATE "
		
		else if strArr(1)="INSTRWISE" then
			
			sqlStr = " SELECT A.BRANCHCODE,TO_CHAR(A.LODGEMENTDATE,'DD-MON-YYYY') LODGEMENTDATE, TO_CHAR(A.ISSUEDATE,'DD-MON-YYYY') ISSUEDATE,A.INSTRNO , A.AMOUNT, A.STATUS,SUBSTR(A.ISSUEDBY,0,35)ISSUEDBY ,  TO_CHAR(A.REGULARISATIONDATE,'DD-MON-YYYY') REGULARISATIONDATE, TO_CHAR(A.CHQRETURNDATE,'DD-MON-YYYY') CHQRETURNDATE, SUBSTR(A.receivedfrom,0,35) receivedfrom, SUBSTR(B.BANKNAME,0,35) BANKNAME ,SUBSTR(C.BRANCHNAME,0,35) BRANCHNAME FROM CLGLODGEMENTINSTRUMENTDTLS A , GENOTHERBANKMST B ,GENOTHERBRANCHMST C WHERE " & strArr(2) & " " & strArr(3) & " AND A.PAYABLEBANKCODE=B.BANKCODE AND A.PAYABLEBANKCODE=C.BANKCODE  AND B.BANKCODE=C.BANKCODE AND A.PAYABLEBRANCHCODE=C.BRANCHCODE "
		
		end if
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(1)="INSTRWISE" then
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "|"
						else
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
						end if
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
			
	else if strArr(0)="RBIINWORD" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		if strArr(1)="MONTH" then
			
			sqlStr = " SELECT TO_CHAR(b.CLGDATE, 'YYYY-MM') MONTH, SUM(B.TOTINSTR) TOTINSTR, ABS(SUM(TOTAMT)) TOTALAMT, SUM(NOOFCLR) NOOFCLR, ABS(SUM(CLEARAMT)) CLEARAMT,SUM(NOOFRET) NOOFRET, ABS(SUM(RETAMT)) RETAMT FROM ( SELECT APPLICATIONDATE CLGDATE, TOTALINSTRUMENTS TOTINSTR,TOTINSTRAMT TOTAMT, NOOFINWARDDEBITS NOOFCLR, INWARDRETURNDEBITAMT CLEARAMT, NOOFINWARDRETURNS NOOFRET, INWARDRETURNAMT RETAMT FROM CLGINWARDINSTRUMENTDTLS A WHERE " & strArr(2) & " " & strArr(3) & " ) B GROUP BY TO_CHAR(b.CLGDATE, 'YYYY-MM') ORDER BY TO_CHAR(b.CLGDATE, 'YYYY-MM') "
		
		else if strArr(1)="DAY" then
			
			sqlStr = " SELECT TO_CHAR(APPLICATIONDATE,'DD-MON-yyyy') appdate, TOTALINSTRUMENTS TOTINSTR,TOTINSTRAMT TOTALAMT, NOOFINWARDDEBITS NOOFCLR, INWARDRETURNDEBITAMT CLEARAMT, NOOFINWARDRETURNS NOOFRET, INWARDRETURNAMT RETAMT FROM CLGINWARDINSTRUMENTDTLS A WHERE " & strArr(2) & " " & strArr(3) & " ORDER BY APPLICATIONDATE "
		
		else if strArr(1)="INSTRWISE" then
			
			sqlStr = " SELECT BRANCHCODE, TO_CHAR(APPLICATIONDATE,'DD-MON-YYYY')APPLICATIONDATE,GLCODE, ACCNO,SUBSTR(NAME,0,35) NAME,AMOUNT, CHQNO,  TO_CHAR(CHQDATE,'DD-MON-YYYY') CHQDATE, SUBSTR(CHQFVG,0,35) CHQFVG, NVL(REMARKS,'InWard Clearing') REMARKS FROM ( SELECT BRANCHCODE, APPLICATIONDATE,GLCODE, ACCNO, AMOUNT, NAME, CHQNO, CHQFVG, CHQDATE, REMARKS FROM GENTRANSLOGBKP A WHERE " & strArr(2) & " " & strArr(3) & " AND SERVICEID!=8 AND MODEOFTRAN IN (5) AND (BRANCHCODE, APPLICATIONDATE,BATCHNO) IN ( SELECT BRANCHCODE, APPLICATIONDATE,BATCHNO FROM CLGINWARDINSTRUMENTDTLS B WHERE B.APPLICATIONDATE=A.APPLICATIONDATE AND B.BRANCHCODE=A.BRANCHCODE AND B.BATCHNO=A.BATCHNO) UNION ALL SELECT BRANCHCODE, APPLICATIONDATE, LINKGLCODE, LINKACCNO, AMOUNT, CHQFVG NAME, CHQNO, CHQFVG, CHQDATE, 'CHQ RETURN' FROM GENTRANSLOGBKP A WHERE " & strArr(2) & " " & strArr(3) & " AND SERVICEID=8 AND MODEOFTRAN IN (5)AND (BRANCHCODE, APPLICATIONDATE,BATCHNO) IN ( SELECT BRANCHCODE, APPLICATIONDATE,BATCHNO FROM CLGINWARDINSTRUMENTDTLS B WHERE B.APPLICATIONDATE=A.APPLICATIONDATE AND B.BRANCHCODE=A.BRANCHCODE AND B.BATCHNO=A.BATCHNO))D ORDER BY D.APPLICATIONDATE,D.GLCODE,D.ACCNO "
		
		end if
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(1)="INSTRWISE" then
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "|"
						else
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
						end if
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
			
	else if strArr(0)="STRDTLS" then
			obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	sqlStr = "SELECT branchcode,glcode,accno,CUSTOMERID, NAME FROM sbtran WHERE modeoftran = 2 AND " & strArr(2) & " and " & strArr(1) & " GROUP BY branchcode,glcode,accno,CUSTOMERID, NAME "
	
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						sqlStr = "SELECT BRANCHCODE, MODULEID, GLCODE, ACCNO, CUSTOMERID,count(*) cnt FROM sbtran WHERE " & strArr(2) & " and  customerid = '"& rs(3).value &"' and accno ='"& rs(2).value &"' AND glcode ='"& rs(1).value &"' AND branchcode ='"& rs(0).value &"' AND  modeoftran in (2,4) AND chqfvg NOT IN ('IC' , 'ICCR') group by BRANCHCODE, MODULEID, GLCODE, ACCNO, CUSTOMERID"
						rs5=obj.SingleSelectStat(sqlStr)
						if not rs5.bof and not rs5.eof then
						if rs5(0).value = 0 then
								strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value  & "|"
						end if 
						end if 
						if rs5.state = 1 then
							 rs5.close
						 rs5 = nothing
						end if 
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if ''rs.BOF and not rs.EOF
					if rs.state = 1 then
						 rs.close
						 rs = nothing
					end if 
			end if ''obj.ConnError="Connected" 
			
			rs=nothing
			obj=nothing
	else if strArr(0)="NACHDTLS" then
	
	strResult=""
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		if strArr(1)="MONTH" then
			
			sqlStr = "SELECT NVL(a.month1,b.month1) , NVL(a.totsucrec,0),NVL(a.totsucamt,0),NVL(b.totretrec,0),NVL(b.totretamt,0) FROM ( SELECT TO_CHAR(n.applicationdate,'YYYY-MM') month1,COUNT(*) totsucrec ,NVL(SUM(AMOUNT),0) totsucamt FROM nachtrandtls n WHERE nachtype = '" & strArr(4) & "' and  " & strArr(2) & " " & strArr(3) & "   AND status = 'SUCCESS' GROUP BY TO_CHAR(n.applicationdate, 'YYYY-MM')) a FULL outer join  (SELECT TO_CHAR(n.applicationdate,'YYYY-MM') month1,COUNT(*) totretrec ,NVL(SUM(AMOUNT),0) totretamt FROM nachtrandtls n WHERE nachtype = '" & strArr(4) & "' and  " & strArr(2) & " " & strArr(3) & "   AND status != 'SUCCESS' GROUP BY TO_CHAR(n.applicationdate, 'YYYY-MM') ) b ON  a.month1 =  b.month1 ORDER BY a.month1"
		
		else if strArr(1)="DAY" then
			
		
		sqlStr="SELECT NVL(a.month1,b.month1) , NVL(a.totsucrec,0),NVL(a.totsucamt,0),NVL(b.totretrec,0),NVL(b.totretamt,0) FROM (SELECT TO_CHAR(n.applicationdate,'dd-MM-yyyy') month1,COUNT(*) totsucrec ,SUM(AMOUNT) totsucamt FROM nachtrandtls n WHERE nachtype = '" & strArr(4) & "' and  " & strArr(2) & " " & strArr(3) & "   AND status = 'SUCCESS' GROUP BY TO_CHAR(n.applicationdate,'dd-MM-yyyy')) a FULL outer join (SELECT TO_CHAR(n.applicationdate,'dd-MM-yyyy') month1,COUNT(*) totretrec ,SUM(AMOUNT) totretamt FROM nachtrandtls n WHERE nachtype = '" & strArr(4) & "' and " & strArr(2) & " " & strArr(3) & "   AND status != 'SUCCESS' GROUP BY TO_CHAR(n.applicationdate, 'dd-MM-yyyy') ) b ON a.month1 =   b.month1 ORDER BY a.month1"
		
		end if
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "|"
			
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing
	
	else if strArr(0)="LSTRNDETAIL" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		dim stmd,stFd
		
		if strArr(1)="SB" or strArr(1)="CA" then
			stmd = ""
		else
			stmd = strArr(1)
		end if
		
		if strArr(3) = "Y" then
			stFd =	" c.accno "
		else
			stFd =	" c.branchcode ||c.glcode||LPAD(c.accno,'7','0') "
		end if
		
		if  strArr(1) = "SHARES" then
			sqlStr = " SELECT SUBNATURE acctype," & stFd & " Accno,SUBSTR(c.name,0,25) name,c.Balance,  TO_CHAR(c.LastTrnDt,'DD-MON-YYYY') lasttrdate, d.curbal FROM ( SELECT 'SHARES' SUBNATURE,a.branchcode, a.glcode, a.accno, b.name , SUM(a.amount) Balance, MAX(a.applicationdate) LastTrnDt FROM sharestran a, sharesmst b WHERE a.applicationdate<='" & strArr(2) & "' AND (b.closedate IS NULL OR b.closedate>'" & strArr(2) & "') AND b.branchcode='" & strArr(4) & "' AND a.accno=b.accno AND a.glcode=b.glcode AND a.branchcode=b.branchcode  GROUP BY a.branchcode,a.glcode, a.accno, b.name )c, sharesbalance d  WHERE c.accno=d.accno AND c.glcode=d.glcode AND c.branchcode=d.branchcode ORDER BY  c.glcode, TO_NUMBER(c.accno) "
		else
			sqlStr = " SELECT t." & stmd & "SUBNATURE acctype," & stFd & " Accno,SUBSTR(c.name,0,25) name, c.Balance, TO_CHAR(c.LastTrnDt,'DD-MON-YYYY') lasttrdate, d.curbal FROM ( SELECT a.branchcode, a.glcode, a.accno, b.name , SUM(a.amount) Balance, MAX(a.applicationdate) LastTrnDt FROM " & strArr(1) & "tran a, " & strArr(1) & "mst b WHERE a.applicationdate<='" & strArr(2) & "' AND (b.closedate IS NULL OR b.closedate>'" & strArr(2) & "')  AND b.branchcode='" & strArr(4) & "' AND a.accno=b.accno AND a.glcode=b.glcode AND a.branchcode=b.branchcode  GROUP BY a.branchcode,a.glcode, a.accno, b.name )c, " & strArr(1) & "balance d , " & strArr(1) & "typemst t WHERE c.accno=d.accno AND c.glcode=d.glcode AND c.branchcode=d.branchcode AND c.glcode=t.glcode AND d.glcode=t.glcode ORDER BY  c.glcode, TO_NUMBER(c.accno) "
		end if
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
		rs=nothing
		obj=nothing
		
	else if strArr(0)="KYCDETAIL" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		dim sFdt
		
		if strArr(3) = "Y" then
			sFdt =	" a.accno "
		else
			sFdt =	" (a.branchcode || a.glcode||LPAD(a.accno,'7','0')) "
		end if
		
		if strArr(1)="KYCSUBACC" then
			
			sqlStr = " SELECT a.customerid, A.SUBNATURE ACCTYPE, " & sFdt & " ACCNO, SUBSTR(a.name,0,35) name, to_char(a.custdob,'DD-MON-YYYY') custdob, a.custmobile, SUBSTR(a.FATHERNAME,0,35) FATHERNAME, (DECODE(TRIM(a.OPINST),'1','SELF','2','E or S','3','Joint','4','F or S','5','Senior Citizen','SELF')) OPINSTR, SUBSTR(B.NOMINEENAME,0,35) NOMINEENAME, SUBSTR(c.DESCRIPTION,0,8)  kyc, a.panno kycid,a.AADHARUID, SUBSTR(a.address,0,75) address FROM ( SELECT m.branchcode ,'SHARE' SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sharesmst m , gencustinfomst g  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL UNION  SELECT m.branchcode ,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sbmst m , gencustinfomst g ,SBtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM camst m , gencustinfomst g ,CAtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.LOANsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM loanmst m , gencustinfomst g ,LOANtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.DEPsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM depmst m , gencustinfomst g ,DEPtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, t.CCsubnature SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM ccmst m , gencustinfomst g ,CCtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode  UNION SELECT m.branchcode, 'LOCKER' SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM lockermst m , gencustinfomst g ,sbtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL )a, gencustnomineemst b, GENKYCMST c WHERE  c.code=a.kycid AND a.accno=b.accno(+) AND a.glcode=b.glcode(+) AND a.branchcode=b.branchcode(+) AND A.CUSTOMERID=B.CUSTOMERID(+)  AND A.BRANCHCODE='" & strArr(2) & "' ORDER BY a.branchcode, a.customerid,a.glcode,TO_NUMBER(a.accno) "
		
		else if strArr(1)="KYCSUBCUST" then
			
			sqlStr = " SELECT a.customerid, SUBSTR(a.name,0,35) name, TO_CHAR(a.custdob,'DD-MON-YYYY') custdob, a.custmobile, SUBSTR(a.FATHERNAME,0,35) FATHERNAME, SUBSTR(c.DESCRIPTION,0,8)  kyc,a.panno kycid, a.AADHARUID, SUBSTR(a.address,0,75) address FROM ( SELECT m.branchcode ,'SHARE' SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sharesmst m , gencustinfomst g  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL UNION  SELECT m.branchcode ,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sbmst m , gencustinfomst g ,SBtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM camst m , gencustinfomst g ,CAtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.LOANsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM loanmst m , gencustinfomst g ,LOANtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.DEPsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM depmst m , gencustinfomst g ,DEPtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, t.CCsubnature SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM ccmst m , gencustinfomst g ,CCtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, 'LOCKER' SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM lockermst m , gencustinfomst g ,sbtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NOT NULL OR g.kycid!=0) AND g.AADHARUID IS NOT NULL )a, gencustnomineemst b, GENKYCMST c WHERE c.code=a.kycid AND a.accno=b.accno(+) AND a.glcode=b.glcode(+) AND a.branchcode=b.branchcode(+) AND A.CUSTOMERID=B.CUSTOMERID(+)  AND A.BRANCHCODE='" & strArr(2) & "' GROUP BY a.customerid, a.name,a.custdob,a.custmobile,a.FATHERNAME,a.panno , a.AADHARUID, a.address,c.DESCRIPTION ORDER BY  a.customerid  "
		
		else if strArr(1)="KYCNONSUBACC" then
			
			sqlStr = " SELECT a.customerid, A.SUBNATURE ACCTYPE, " & sFdt & " ACCNO, SUBSTR(a.name,0,35) name, to_char(a.custdob,'DD-MON-YYYY' ) custdob, a.custmobile, SUBSTR(a.FATHERNAME,0,35) FATHERNAME, (DECODE(TRIM(a.OPINST),'1','SELF','2','E or S','3','Joint','4','F or S','5','Senior Citizen','SELF')) OPINSTR,SUBSTR(B.NOMINEENAME,0,35) NOMINEENAME, SUBSTR(a.address,0,75) address FROM ( SELECT m.branchcode ,'SHARE' SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sharesmst m , gencustinfomst g  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL UNION  SELECT m.branchcode ,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sbmst m , gencustinfomst g ,SBtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM camst m , gencustinfomst g ,CAtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.LOANsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM loanmst m , gencustinfomst g ,LOANtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.DEPsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM depmst m , gencustinfomst g ,DEPtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, t.CCsubnature SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM ccmst m , gencustinfomst g ,CCtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, 'LOCKER' SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM lockermst m , gencustinfomst g ,sbtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS  NULL )a, gencustnomineemst b WHERE a.accno=b.accno(+) AND a.glcode=b.glcode(+) AND a.branchcode=b.branchcode(+) AND A.CUSTOMERID=B.CUSTOMERID(+)  AND A.BRANCHCODE='" & strArr(2) & "' ORDER BY a.branchcode, a.customerid,a.glcode,TO_NUMBER(a.accno) "
		
		else if strArr(1)="KYCNONSUBCUST" then
			
			sqlStr = " SELECT a.customerid,  SUBSTR(a.name,0,35) name, TO_CHAR(a.custdob,'DD-MON-YYYY' ) custdob,a.custmobile,SUBSTR(a.FATHERNAME,0,35) FATHERNAME, SUBSTR(a.address,0,75) address FROM ( SELECT m.branchcode ,'SHARE' SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sharesmst m , gencustinfomst g  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL UNION SELECT m.branchcode ,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM sbmst m , gencustinfomst g ,SBtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.subnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM camst m , gencustinfomst g ,CAtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.LOANsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM loanmst m , gencustinfomst g ,LOANtypemst t  WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL AND m.glcode=t.glcode UNION SELECT m.branchcode,t.DEPsubnature SUBNATURE, m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM depmst m , gencustinfomst g ,DEPtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL AND m.glcode=t.glcode UNION SELECT m.branchcode, t.CCsubnature SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM ccmst m , gencustinfomst g ,CCtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL AND m.glcode=t.glcode  UNION SELECT m.branchcode, 'LOCKER' SUBNATURE,m.glcode,g.customerid,m.accno, m.name,g.custdob,g.custmobile,g.FATHERNAME,m.OPERATINGINSTR OPINST, (g.MAILADDRESS1|| ' , '|| g.MAILADDRESS2|| ' , '|| g.MAILADDRESS3|| ' , '|| g.MAILADDRESS4|| ' , '|| g.MAILADDRESS5) address, g.panno,g.kycid, g.AADHARUID FROM lockermst m , gencustinfomst g ,sbtypemst t WHERE m.CUSTOMERID=g.customerid AND m.status='R'  AND  (g.kycid IS NULL OR g.kycid=0) AND g.AADHARUID IS NULL )a, gencustnomineemst b WHERE a.accno=b.accno(+) AND a.glcode=b.glcode(+) AND a.branchcode=b.branchcode(+) AND A.CUSTOMERID=B.CUSTOMERID(+)  AND A.BRANCHCODE='" & strArr(2) & "' GROUP BY a.customerid, a.name,a.custdob,a.custmobile,a.FATHERNAME, a.address ORDER BY  a.customerid  "
		
		end if
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(1)="KYCSUBACC" then
							
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "|"
						
						else if strArr(1)="KYCSUBCUST" then
			
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "|"
		
						else if strArr(1)="KYCNONSUBACC" then
							
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "|"
						
						else if strArr(1)="KYCNONSUBCUST" then
							
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "|"
						
						end if
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
		rs=nothing
		obj=nothing

else if strArr(0)="AADHARLYNK" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		if strArr(2)="1" then
			
			sqlStr = " SELECT ( SELECT SUM(cnt) totalaccount FROM ( SELECT COUNT(*) cnt FROM sbmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM CAmst WHERE customerid IN (SELECT customerid FROM gencustinfomst) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM CCmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "')  AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM Depmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND glcode<>'104270' AND applicationdate<'" & strArr(1) & "' ) a) TOTALACCNT ,( SELECT SUM(cnt) aadhar FROM ( SELECT COUNT(*) cnt FROM sbmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM CAmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM CCmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' UNION SELECT COUNT(*) cnt FROM Depmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND glcode<>'104270' AND applicationdate<'" & strArr(1) & "'  ) b ) LNKACCNT FROM dual "
		
		else if strArr(2)="0" then
			
			sqlStr = " SELECT X.branchcode,X.totalaccount,y.aadhar FROM ( SELECT a.branchcode,SUM(a.cnt) totalaccount FROM ( SELECT branchcode,COUNT(*) cnt FROM sbmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM CAmst WHERE customerid IN (SELECT customerid FROM gencustinfomst) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM CCmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM Depmst WHERE customerid IN (SELECT customerid FROM gencustinfomst ) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND glcode<>'104270' AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode ) a  GROUP BY a.branchcode ) x , (SELECT b.branchcode,SUM(b.cnt) aadhar FROM ( SELECT branchcode,COUNT(*) cnt FROM sbmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM CAmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM CCmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode UNION SELECT branchcode,COUNT(*) cnt FROM Depmst WHERE customerid IN (SELECT customerid FROM gencustinfomst WHERE AADHARUID IS NOT NULL) AND (closedate IS NULL OR closedate>'" & strArr(1) & "') AND glcode<>'104270' AND applicationdate<'" & strArr(1) & "' GROUP BY branchcode  ) b GROUP BY b.branchcode ) y  WHERE x.branchcode = y.branchcode ORDER BY X.branchcode  "
		
		end if
			
			rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(2)="1" then
						
							strResult = strResult & rs(0).value & "~" & rs(1).value &  "|"
							
						else if strArr(2)="0" then
						
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "|"
							
						end if
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
			
			rs=nothing
			obj=nothing	

else if strArr(0)="GETPTAXDTLS" then
	
		strResult=""
		
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		
		sqlStr = " SELECT NVL(VALUE,0) FROM SALARYPARMST WHERE status='R' AND code='PTAX' AND effectivedate = (SELECT MAX(effectivedate) FROM SALARYPARMST WHERE status='R' AND code='PTAX' ) AND  fromamt <= '" & strArr(1) & "' AND toamt >= '" & strArr(1) & "' "		
		
		rs=obj.SingleSelectStat(sqlStr)
		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				strResult = rs(0).value 
			else	
				strResult = "0"
			end if
		end if
		
		rs=nothing
		obj=nothing	

end if
obj = nothing

%>
		<script>
		function Details()
		{
			var type="<%=strArr(0)%>"
			var strResult="<%=strResult%>"
			if(type=="SETTERMDUEDATE")
				window.attachEvent(window.parent.GETTERMDUEDATE(strResult))
			if(type=="EMPDETAILS")
				window.attachEvent(window.parent.getEmpDetail(strResult))
			if(type=="GetAccName")
				window.attachEvent(window.parent.GetAccName1(strResult))
			if(type=="DIRDETAILS")
				window.attachEvent(window.parent.getDIRDETAILS(strResult))	
			if(type=="getDirectorDtls")
				window.attachEvent(window.parent.getDirectorDtls1(strResult))	
			if(type=="GetSittingFeeAmt")
				window.attachEvent(window.parent.GetSittingFeeAmt1(strResult))	
			if(type=="SalRepSelMonth")
				window.attachEvent(window.parent.FillSalRepSelMonth(strResult))
			if(type=="RentReportsclickMonth")
				window.attachEvent(window.parent.FillRentReportsclickMonth(strResult))
			if(type=="VoucherReprintclickMonth")
				window.attachEvent(window.parent.FillVoucherReprintclickMonth(strResult))		
			if(type=="SalRepSelYear")
				window.attachEvent(window.parent.FillSalRepSelYear(strResult))	
			if(type=="SalRepSelYear1")
				window.attachEvent(window.parent.FillSalRepSelYear1(strResult))	
			if(type=="VoucherReprintSelYear")
				window.attachEvent(window.parent.FillVoucherReprintSelYear(strResult))	
			if(type=="RentReportsSelYear")
				window.attachEvent(window.parent.FillRentReportsSelYear(strResult))		
			if (type=="SalPaySlipSelEmployee") 
				window.attachEvent(window.parent.FillSalPaySlipSelEmployee(strResult))
			if (type=="EmployeeDetails") 
				window.attachEvent(window.parent.FillEmployeeDetails(strResult))	
			if (type=="GetTDSAmt") 
				window.attachEvent(window.parent.SetTDSAmt(strResult))		
			if  (type=="GeneralRepSelEmployee")	
				window.attachEvent(window.parent.FillGeneralRepSelEmployee(strResult))
			if(type=="GRATUITYCHECK")
				window.attachEvent(window.parent.getGRATUITYCHECK(strResult))
			if(type=="GENERATEGRATUITY")
				window.attachEvent(window.parent.popGratuitydtls(strResult))
			if(type=="GRATUITYREPORT")
				window.attachEvent(window.parent.popGRATUITYREPORT(strResult))
			if(type=="BODBOMSittingREPORT")
				window.attachEvent(window.parent.popBODBOMSittingREPORT(strResult))
			if(type=="BODBOMMeetingAttendREPORT")
				window.attachEvent(window.parent.popBODBOMMeetingAttendREPORT(strResult))	
				if(type=="CheckMeetingDate")
				window.attachEvent(window.parent.GetCheckMeetingDate(strResult))
			if(type=="GetSittingFeeDetails")
				window.attachEvent(window.parent.GetSittingFeeDetails(strResult))				
			if(type=="CheckDupMeetingAttend")
				window.attachEvent(window.parent.GetCheckDupMeetingAttend(strResult))
			else if(type=="SALPARM")
				window.attachEvent(window.parent.popSalParm(strResult))
			else if(type=="CALC")
				window.attachEvent(window.parent.popCalc(strResult))
			else if(type=="SALGENRAT")
				window.attachEvent(window.parent.popSal(strResult))
			else if(type=="CheckLoanDepstatusYN")
				window.attachEvent(window.parent.popCheckLoanDepstatusYN(strResult))
			else if(type=="SALREPRT")
				window.attachEvent(window.parent.popSalRep(strResult))
			else if(type=="FILEGEN")
				window.attachEvent(window.parent.popFilRep(strResult))
			else if(type=="BCFILEGEN")
				window.attachEvent(window.parent.popBCFilRep(strResult))
			else if(type=="USERPSW")
				window.attachEvent(window.parent.popUPdat(strResult))
			else if((type=="ESI") || (type=="PF") || (type=="VPF"))
				window.attachEvent(window.parent.popESIPF(strResult))
			else if(type=="EMPDTLS")
				window.attachEvent(window.parent.popEmDtl(strResult))
			else if(type=="EMPLOYSAL")
				window.attachEvent(window.parent.popEmSal(strResult))
			else if(type=="BOMSAL")
				window.attachEvent(window.parent.GetBOMSAL(strResult))	
			else if(type=="BODBOMSalaryRep")
				window.attachEvent(window.parent.GetBODBOMSalaryRep(strResult))	
			else if(type=="TENANTGEN")
				window.attachEvent(window.parent.popTenant(strResult))
			else if(type=="RBIOUTWORD")
				window.attachEvent(window.parent.popRbiOut(strResult))
			else if(type=="RBIINWORD")
				window.attachEvent(window.parent.popRbiIN(strResult))
			else if(type=="NACHDTLS")
				window.attachEvent(window.parent.popNACHDTLS(strResult))	
			else if(type=="STRDTLS")
				window.attachEvent(window.parent.popSTRDTLS(strResult))
			else if(type=="LSTRNDETAIL")
				window.attachEvent(window.parent.popLstrep(strResult))
			else if(type=="KYCDETAIL")
				window.attachEvent(window.parent.popKycdtls(strResult))
			else if(type=="TENANTGENRAT")
				window.attachEvent(window.parent.popTenRentdtls(strResult))
			else if(type=="TENANTMAST")
				window.attachEvent(window.parent.popTenantdtls(strResult))
			else if((type=="RENTDETAILREP") || (type=="RENTPAIDREP"))
				window.attachEvent(window.parent.popRentdtls(strResult))
			else if (type=="RECUPTO")
				window.attachEvent(window.parent.popRECUPTO(strResult))
			else if(type=="AADHARLYNK")
				window.attachEvent(window.parent.popAadtals(strResult))
			else if(type=="GETPTAXDTLS")
				window.attachEvent(window.parent.popPtax(strResult))
				window.close()
		}
		</script>
	</HEAD>
	<body onload="Details()">
		<form id="frmDetails" method="post" runat="server">
			<input type="button" name="hdnResult" value="strResult">
		</form>
	</body>
</HTML>
