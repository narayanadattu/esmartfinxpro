Public Class frmDirectorDtlsInsert
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim errmsg As String
    Dim strUserid, strMachineid, vAppdate As String
    Dim strDirectorID, strCustid, strDirectorName, strQualification, strBOD, strBODDesig, strBOM, strBOMDesig, strElectionDate, strJoinDate, strTermPeriod, strTermEffDate, strTermDueDate, strCommMemYN, strSittingFees, strBOMSalary, strTDSYN, strTerminateDate, strReason, strRelationYN, strpaymode, strAccno, strCrAccName, strIFSCCode As String

    Dim tabname, strfields, strvalmain, strMode As String
    Dim intcnt, icnt As Integer
    Dim strcommemval, strfammemval As String
    Dim o_errmsg, o_errmsg1 As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim arrtrans(5, 4)
        Dim obj
        Try
          
        obj = Server.CreateObject("GeneralTransactions.DBTransactions")
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Sub
            End If
        End If

        strDirectorID = Request.Form("hdnDirectorID")
        strCustid = Request.Form("hdnCustid")
        strDirectorName = Request.Form("hdnDirectorName")
        strQualification = Request.Form("hdnQualification")
        strBOD = Request.Form("hdnBOD")
        strBODDesig = Request.Form("hdnBODDesig")
        strBOM = Request.Form("hdnBOM")
        strBOMDesig = Request.Form("hdnBOMDesig")
        strElectionDate = Request.Form("hdnElectionDate")
        strJoinDate = Request.Form("hdnJoinDate")
        strTermPeriod = Request.Form("hdnTermPeriod")
        strTermEffDate = Request.Form("hdnTermEffDate")
        strTermDueDate = Request.Form("hdnTermDueDate")
        strCommMemYN = Request.Form("hdnCommMemYN")
        strSittingFees = Request.Form("hdnSittingFees")
        strBOMSalary = Request.Form("hdnBOMSalary")
        strTDSYN = Request.Form("hdnTDSYN")
        strTerminateDate = Request.Form("hdnTerminateDate")
        strReason = Request.Form("hdnReason")
        strRelationYN = Request.Form("hdnRelationYN")
        strpaymode = Request.Form("hdnpaymode")
        strAccno = Request.Form("hdnAccno")
        strCrAccName = Request.Form("hdnCrAccName")
        strIFSCCode = Request.Form("hdnIFSCCode")

        strcommemval = Request.Form("hdncommemval")
        strfammemval = Request.Form("hdnfammemval")
        strMode = Request.Form("hidmode")

        strUserid = Session("userid")
        strMachineid = Session("machineid")
        vAppdate = Session("applicationdate")

        If strDirectorID.Length > 0 Then
            If strMode = "NEW" Then

                    strfields = "DIRCODE, CUSTOMERID, DIRNAME, EDUCATION, BOD, BODDISG, BOM, BOMDISG, ELECDATE, JOINDATE, TERMPERIOD, TERMEFFDT, DUEDATE, COMMITTEEMEMYN, SITTINGFEE, BOMSALARY, TDSYN,  RELATIONSYN, PAYMENTMODE, ACCNO, PAYEENAME, IFSCCODE, STATUS, APPLIATIONDATE, USERID, MACHINEID, SYSTEMDATE"
                    strvalmain = "'" & strDirectorID & "','" & strCustid & "','" & strDirectorName & "','" & strQualification & "','" & strBOD & "','" & strBODDesig & "','" & strBOM & "','" & strBOMDesig & "','" & strElectionDate & "','" & strJoinDate & "','" & strTermPeriod & "','" & strTermEffDate & "','" & strTermDueDate & "','" & strCommMemYN & "','" & strSittingFees & "','" & strBOMSalary & "','" & strTDSYN & "','" & strRelationYN & "','" & strpaymode & "','" & strAccno & "','" & strCrAccName & "','" & strIFSCCode & "','R','" & vAppdate & "','" & strUserid & "','" & strMachineid & "',sysdate"
                arrtrans(icnt, 0) = "I"
                arrtrans(icnt, 1) = "GENDIRECTORDTLS"
                arrtrans(icnt, 2) = strfields
                arrtrans(icnt, 3) = strvalmain
                arrtrans(icnt, 4) = ""
                icnt = icnt + 1
                    If strCommMemYN = "Y" Then
                        arrtrans(icnt, 0) = "I"
                        arrtrans(icnt, 1) = "DIRCOMTDTLS"
                        arrtrans(icnt, 2) = "DIRCODE,SNO,  COMMITTEEID, JOINFROMDATE, JOINTODATE"
                        arrtrans(icnt, 3) = strcommemval
                        arrtrans(icnt, 4) = ""
                        icnt = icnt + 1
                    End If ''strCommMemYN = "Y"
                    If strRelationYN = "Y" Then
                        arrtrans(icnt, 0) = "I"
                        arrtrans(icnt, 1) = "DIRRELATIONDTLS"
                        arrtrans(icnt, 2) = "DIRCODE, SNO, RELATIONID, RELATIONNAME, PROFESSION, CUSTOMERID, PANNO, MOBILENO, USERID, MACHINEID, SYSTEMDATE"
                        arrtrans(icnt, 3) = strfammemval
                        arrtrans(icnt, 4) = ""
                        icnt = icnt + 1
                    End If  ''strRelationYN = "Y"
                  

                ElseIf strMode = "MODIFY" Then

                    strfields = "CUSTOMERID, DIRNAME, EDUCATION, BOD, BODDISG, BOM, BOMDISG, ELECDATE, JOINDATE, TERMPERIOD, TERMEFFDT, DUEDATE, COMMITTEEMEMYN, SITTINGFEE, BOMSALARY, TDSYN,   RELATIONSYN, PAYMENTMODE, ACCNO, PAYEENAME, IFSCCODE"
                    strvalmain = "'" & strCustid & "'~'" & strDirectorName & "'~'" & strQualification & "'~'" & strBOD & "'~'" & strBODDesig & "'~'" & strBOM & "'~'" & strBOMDesig & "'~'" & strElectionDate & "'~'" & strJoinDate & "'~'" & strTermPeriod & "'~'" & strTermEffDate & "'~'" & strTermDueDate & "'~'" & strCommMemYN & "'~'" & strSittingFees & "'~'" & strBOMSalary & "'~'" & strTDSYN & "'~'" & strRelationYN & "'~'" & strpaymode & "'~'" & strAccno & "'~'" & strCrAccName & "'~'" & strIFSCCode & "'"

                    arrtrans(icnt, 0) = "U"
                    arrtrans(icnt, 1) = "GENDIRECTORDTLS"
                    arrtrans(icnt, 2) = strfields
                    arrtrans(icnt, 3) = strvalmain
                    arrtrans(icnt, 4) = "DIRCODE=" & strDirectorID & ""
                    icnt = icnt + 1

                    intcnt = 0
                    intcnt = getRecCntByTable("DIRCOMTDTLS", strDirectorID)
                    If intcnt > 0 Then

                        arrtrans(icnt, 0) = "D"
                        arrtrans(icnt, 1) = "DIRCOMTDTLS"
                        arrtrans(icnt, 2) = ""
                        arrtrans(icnt, 3) = ""
                        arrtrans(icnt, 4) = "DIRCODE=" & strDirectorID & ""
                        icnt = icnt + 1
                    End If
                    arrtrans(icnt, 0) = "I"
                    arrtrans(icnt, 1) = "DIRCOMTDTLS"
                    arrtrans(icnt, 2) = "DIRCODE,SNO,  COMMITTEEID, JOINFROMDATE, JOINTODATE"
                    arrtrans(icnt, 3) = strcommemval
                    arrtrans(icnt, 4) = ""
                    icnt = icnt + 1

                    intcnt = 0
                    intcnt = getRecCntByTable("DIRRELATIONDTLS", strDirectorID)
                    If intcnt > 0 Then

                        arrtrans(icnt, 0) = "D"
                        arrtrans(icnt, 1) = "DIRRELATIONDTLS"
                        arrtrans(icnt, 2) = ""
                        arrtrans(icnt, 3) = ""
                        arrtrans(icnt, 4) = "DIRCODE=" & strDirectorID & ""
                        icnt = icnt + 1
                    End If
                    arrtrans(icnt, 0) = "I"
                    arrtrans(icnt, 1) = "DIRRELATIONDTLS"
                    arrtrans(icnt, 2) = "DIRCODE, SNO, RELATIONID, RELATIONNAME, PROFESSION, CUSTOMERID, PANNO, MOBILENO, USERID, MACHINEID, SYSTEMDATE"
                    arrtrans(icnt, 3) = strfammemval
                    arrtrans(icnt, 4) = ""

                ElseIf strMode = "DELETE" Then

                    arrtrans(icnt, 0) = "U"
                    arrtrans(icnt, 1) = "GENDIRECTORDTLS"
                    arrtrans(icnt, 2) = "TERMINATIONDATE, TERMINATEREASON,STATUS"
                    arrtrans(icnt, 3) = "'" & strTerminateDate & "'~'" & strReason & "'~'C'"
                    arrtrans(icnt, 4) = "DIRCODE=" & strDirectorID & ""

                End If
            End If
            o_errmsg = obj.DataTransactions(arrtrans)

            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirectorsDetails.aspx?record=" & o_errmsg, False)
            Exit Sub
        Catch ex As Exception

            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirectorsDetails.aspx?record=" & o_errmsg1, False)

        End Try
    End Sub

    Private Function getRecCntByTable(ByVal strtable As String, ByVal dircode As String) As Integer

        Dim objdrinstyn As OracleClient.OracleDataReader
        Dim objCmd As OracleClient.OracleCommand
        Dim strSql As String
        Dim intcnt As Integer = 0
        Try
            strSql = "select *  from " & strtable & " where dircode = '" & dircode & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objdrinstyn = objCmd.ExecuteReader()
            If objdrinstyn.HasRows = True Then

                intcnt = 1
            Else
                intcnt = 0
            End If
            getRecCntByTable = intcnt
            objdrinstyn.Close()
            objdrinstyn.Dispose()
            objdrinstyn = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            Exit Function
        Catch ex As Exception
            getRecCntByTable = intcnt
        End Try
    End Function
End Class
