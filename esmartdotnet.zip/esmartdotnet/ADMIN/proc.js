
//------ please Don't modify the following code--------------------

function assign(str,txt1,txt2)
{
    var ints,strNo,strName
    ints =str.indexOf("-")
	strNo=str.substring(0,ints)
	strName=str.substring(ints+5,str.length)
	txt1.value=strNo
	txt2.value=strName
}	

//-------------------------------------------------------------------


