Public Class frmDirectorMeetAttndDtlsInsert
    Inherits System.Web.UI.Page
    Dim objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim errmsg, o_errmsg, o_errmsg1 As String
    Dim icnt As Integer = 0
    Dim strmeetdtls As String
    Dim strmeetingtype, strmeetingdate As String
    Dim dbltotsitfee As Double
    Dim strSql As String
    Dim objtran As OracleClient.OracleTransaction
    Dim strdirid, strsno, strsitfeeyn, strAttendanceyn As String
    Dim dblpaidfeeamt As Double = 0
    Dim userId, machineID, appDate As String
    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim brAbbcode, strBatchNo, strMainBrCode, brCode, strTranNo1, totDrAmt, strTranNo2 As String
    Dim strvalcol, strvalrow()
    Dim objDr As OracleClient.OracleDataReader
    Dim drMod, drGl, drAcc As String
    Dim objDrtab As OracleClient.OracleDataReader
    Dim strCrBrID, strCrModid, strCrGLCode, strCraccno As String
    Dim strRemarksDr, strRemarksCr, strTranCols, curCode As String
    Dim strpaymentmode, straccno As String
    Dim strDrbrCode, strAccFullName, stIfsc, stPynam, stPyAccno, stPyacTy, stPyBnk, stPyBnam, stPyamt, stChr, stSer, strTranStatus, stNft, stRmk, strMobileno, strMobileNoDr, strNeftRtgsRefno As String
    Dim objval As New GENVALIDATIONS.Validations
    Dim objDrtab2 As OracleClient.OracleDataReader
    Dim objhotraw As New GENVALIDATIONS.Validations
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            strDrbrCode = Session("branchcode")
            ''  strMainBrCode = "101"
            '' modified by dattu 24-nov-22
            '' HO Trans Allowed
            strMainBrCode = objhotraw.GetHOTRALWBrCode()
            brCode = Session("branchcode")
            curCode = "INR"
            userId = Session("userid")
            machineID = Session("machineid")
            appDate = Session("applicationdate")
            strmeetdtls = Request.Form("hdnmeetdtls")
            strvalrow = strmeetdtls.Split("|")
            strmeetingtype = Request.Form("cmbMeetingType")
            strmeetingdate = Request.Form("txtMeetingDate")
            dbltotsitfee = Request.Form("hdndbltotsitfee")
            totDrAmt = dbltotsitfee

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            objtran = objconn.BeginTransaction()

            If totDrAmt <> 0 Then


            For icnt = 0 To strvalrow.Length - 1
                strvalcol = strvalrow(icnt).Split("~")
                strsno = strvalcol(0)
                strdirid = strvalcol(1)
                strsitfeeyn = strvalcol(2)
                dblpaidfeeamt = strvalcol(3)
                strAttendanceyn = strvalcol(4)

                If strsitfeeyn = "Y" Then

                    strSql = "SELECT paymentmode,accno,PAYEENAME,IFSCCODE FROM GENDIRECTORDTLS WHERE DIRCODE = '" & strdirid & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDrtab2 = objCmd.ExecuteReader()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If objDrtab2.HasRows = True Then
                        objDrtab2.Read()

                        strpaymentmode = objDrtab2!paymentmode
                        straccno = objDrtab2!accno
                        strAccFullName = objDrtab2!PAYEENAME
                        stIfsc = objDrtab2!IFSCCODE


                    End If ''objDrtab2


                    objDrtab2.Close()
                    objDrtab2 = Nothing

                    If strpaymentmode = "T" Then
                        GetCreditBrAcGlAcc(straccno, strCrBrID, strCrModid, strCrGLCode, strCraccno)
                        If brCode <> strCrBrID Then

                            brAbbcode = "ABB"

                            Exit For

                        End If
                    Else
                        strCrBrID = strMainBrCode
                        GetCreditInvGlcodeAccno(strCrModid, strCrGLCode, strCraccno)
                        brAbbcode = ""
                    End If
                End If ''strsitfeeyn = "Y"

            Next
            If brAbbcode = "ABB" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            Else
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            End If
            '' debit modid,glcode,accno

            strSql = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='SFPAID' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='SFPAID' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.Transaction = objtran
            objDr = objCmd.ExecuteReader()
            objCmd.Dispose()
            objCmd = Nothing
            If objDr.HasRows = True Then
                objDr.Read()
                drMod = objDr!Moduleid
                drGl = objDr!glcode
                drAcc = objDr!accno


                objDr.Close()
                objDr = Nothing


                strSql = "SELECT glcode,accno FROM " & drMod & "MST where GLCODE='" & drGl & "' and ACCNO='" & drAcc & "' and Branchcode='" & brCode & "'"

                objCmd = New OracleClient.OracleCommand(strSql, objconn)
                objCmd.Transaction = objtran
                objDrtab = objCmd.ExecuteReader()
                objCmd.Dispose()
                objCmd = Nothing

                If objDrtab.HasRows = True Then
                    While objDrtab.Read

                        drGl = objDrtab(0)
                        drAcc = objDrtab(1)

                        strRemarksDr = "Sitting Fee Paid for " & strmeetingtype & " Meeting " & " on " & strmeetingdate


                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                        "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                        "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                        "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                        "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                        "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                        "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                        "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                        "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                        "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                        "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                        "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                        "ABBYN"

                        If brAbbcode = "ABB" Then
                            strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                        "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                        "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                        Else
                            strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                        "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                        "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                        End If


                        objCmd = New OracleClient.OracleCommand(strSql, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                        If brAbbcode = "ABB" Then
                            strSql = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                        Else
                            strSql = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                        End If


                        objCmd = New OracleClient.OracleCommand(strSql, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                    End While
                Else
                    Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)

                End If

                objDrtab.Close()
                objDrtab.Dispose()
                objDrtab = Nothing

            Else
                Throw New Exception("ModuleId or Glcode Or Accno is null for Debit Sitting Fee Paid ")
            End If

            End If  '' totdramt

            For icnt = 0 To strvalrow.Length - 1
                strvalcol = strvalrow(icnt).Split("~")

                strsno = strvalcol(0)
                strdirid = strvalcol(1)
                strsitfeeyn = strvalcol(2)
                dblpaidfeeamt = strvalcol(3)
                strAttendanceyn = strvalcol(4)

                strSql = "insert into DirectorMeetingAttndtls(DIRCODE, SNO, MEETINGTYPE, MEETINGDATE, ATTENDYN, SITTINGFEEYN, PAIDFEEAMT, FEEPAIDDATE, SYSTEMDATE, USERID) values('" & strdirid & "'," & strsno & ",'" & strmeetingtype & "','" & Format(CDate(strmeetingdate), "dd-MMM-yyyy") & "','" & strAttendanceyn & "','" & strsitfeeyn & "','" & dblpaidfeeamt & "','" & appDate & "',sysdate,'" & userId & "')"

                objCmd = New OracleClient.OracleCommand(strSql, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing


                strAccFullName = ""
                stIfsc = ""
           
                If strsitfeeyn = "Y" Then
                    If dblpaidfeeamt <> 0 Then


                    strSql = "SELECT paymentmode,accno,PAYEENAME,IFSCCODE FROM GENDIRECTORDTLS WHERE DIRCODE = '" & strdirid & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDrtab2 = objCmd.ExecuteReader()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If objDrtab2.HasRows = True Then
                        objDrtab2.Read()

                        strpaymentmode = objDrtab2!paymentmode
                        straccno = objDrtab2!accno
                        strAccFullName = objDrtab2!PAYEENAME
                        stIfsc = objDrtab2!IFSCCODE


                    End If ''objDrtab2


                    objDrtab2.Close()
                    objDrtab2 = Nothing


                    If strpaymentmode = "T" Then
                        GetCreditBrAcGlAcc(straccno, strCrBrID, strCrModid, strCrGLCode, strCraccno)
                    Else
                        strCrBrID = strMainBrCode
                        GetCreditInvGlcodeAccno(strCrModid, strCrGLCode, strCraccno)
                    End If
                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    End If

                    strRemarksCr = "Sitting Fee Paid for " & strmeetingtype & " Meeting " & " on " & strmeetingdate

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblpaidfeeamt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblpaidfeeamt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If



                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblpaidfeeamt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblpaidfeeamt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If


                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing


                    If strpaymentmode = "T" Then
                    Else
                        stPyamt = totDrAmt
                        stNft = "NEFT"
                        strMobileno = objval.GetCustMobileNo(strCrBrID, curCode, strCrModid, strCrGLCode, strCraccno)
                        strMobileNoDr = ""
                        strNeftRtgsRefno = ""
                        strNeftRtgsRefno = objval.GetRefno(objconn, objtran, o_errmsg)
                        If o_errmsg <> "" Then
                            Throw New Exception(o_errmsg)
                        End If
                        ''for NeftRtgs Table insert
                            strSql = "INSERT INTO NEFTRTGSDTLS (BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME,AMOUNT, PAYEENAME, PAYEEACCNO,PAYEEACCTYPE, PAYEEBANK, PAYEEBRANCH,IFSCCODE, PAYEEAMT,CITY, COMM,SERVTAX, BATCHNO, TRANNO,TRANSTATUS, APPLICATIONDATE, USERID,MACHINEID, SYSTEMYEAR, SYSTEMDATE,NEFTRTGS,REMARKS,mobile,SENDMOBILENO,refno,FILEGENYN,sessbrcode) VALUES ('" & strDrbrCode & "','" & curCode & "','" & drMod & "','" & drGl & "','" & drAcc & "','" & strAccFullName & "','" & totDrAmt & "','" & stPynam & "', '" & stPyAccno & "','', '', '', '" & stIfsc & "', '" & stPyamt & "', '', '','','" & strBatchNo & "','" & strTranNo1 & "','" & strTranStatus & "','" & appDate & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')),SYSDATE,'" & stNft & "','" & stRmk & "','" & strMobileno & "','" & strMobileNoDr & "','" & strNeftRtgsRefno & "','Y','" & brCode & "')"


                        objCmd = New OracleClient.OracleCommand(strSql, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                        End If
                    End If
                End If ''strsitfeeyn = "Y"
            Next

            objtran.Commit()
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirectorMeetingAttndDtls.aspx?record=Transaction Completed Batchno " & strBatchNo, False)
            Exit Sub
        Catch ex As Exception
            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmDirectorMeetingAttndDtls.aspx?record=" & o_errmsg1, False)

        End Try

   
    End Sub

    Private Sub GetCreditBrAcGlAcc(ByVal strfullaccno2 As String, ByRef pstrBrId As String, ByRef pstrACTP As String, ByRef pstrGlcd As String, ByRef pstrAccNo As String)
        Dim strfullaccno1 As String

        Dim NFTSCONVYN As String
        Try
            strfullaccno1 = StrReverse(Mid(StrReverse(strfullaccno2), 1, 16))

            pstrBrId = Mid(strfullaccno1, 1, 3)
            pstrGlcd = Mid(strfullaccno1, 4, 6)

            '' for accno 16 digits only
            NFTSCONVYN = objval.GetNFTSCONVYN
            If NFTSCONVYN = "Y" Then
                pstrAccNo = pstrBrId & pstrGlcd & Mid(strfullaccno1, 10, 7)
            Else
                pstrAccNo = Mid(strfullaccno1, 10, 7).TrimStart("0")
            End If
            pstrACTP = objval.GetModuleID(pstrGlcd)
            Exit Sub
        Catch ex As Exception

        End Try
    End Sub



    Private Sub GetCreditInvGlcodeAccno(ByRef ModId As String, ByRef GlCode As String, ByRef AccNo As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strMobileNo As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "SELECT MODULEID, GLCODE, ACCNO FROM NEFTRTGSTYPEPMT WHERE trantype = 'NEFTOW'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)

            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()

                ModId = IIf(IsDBNull(dr!MODULEID), "", dr!MODULEID)
                GlCode = IIf(IsDBNull(dr!GLCODE), "", dr!GLCODE)
                AccNo = IIf(IsDBNull(dr!ACCNO), "", dr!ACCNO)
            Else
                ModId = ""
                GlCode = ""
                AccNo = ""
            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Sub
        Catch ex As Exception

        End Try
    End Sub
End Class
