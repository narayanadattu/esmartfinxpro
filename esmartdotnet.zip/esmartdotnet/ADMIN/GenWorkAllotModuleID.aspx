<%@ Page Language="vb" CodeBehind="GenWorkAllotModuleID.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotModuleID" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenWorkAllotModuleID.ASP									*
'*	Purpose	  	     : To Display modules according to the User/Group selected 	*
'*						             											*
'*																				*      	                              *
'*		   																		*
'*			                                            						*
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************


%>


<html>

<SCRIPT LANGUAGE=javascript>
<!--
// called to refresh fromid page
function clearframe()
{
	/// to refresh genworkallotformid.aspx page
	parent.frames(1).frmforms.action="GenWorkAllotFormid.aspx"
	parent.frames(1).frmforms.method="post"
	parent.frames(1).frmforms.submit()
}



//-->
</SCRIPT>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<%  '''''' Declaration of Variables
	Dim objfetch
	dim recfetch
	dim vark
	dim strdata
	'''' Getting data from calling page
	strdata=Request.Form("hden")
%>	
<title></title>
</head>
<body>

<form name="frmmodule">
  <%
		'''' if data found then
		if len(strdata)>0 then
			''''' create the instance of objects
			 recfetch=server.CreateObject("adodb.recordset")
			 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
			
			'''' Query Moduleid and its narration where modules are implemented
			 recfetch=objfetch.singlerecordset("GENMODULETYPESMST","moduleid,initcap(narration)"," branchcode='"& cstr(strdata)&"'  and IMPLEMENTEDYN='Y'")
			
  %>

  <table border="0" width="140" cellspacing="0" cellpadding="0">
    <tr align="left">
      <td width="30%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modules</font></td>
    </tr>
  </table>

  <table>
     <%
	   if recfetch.EOF=false and recfetch.BOF=false then
		recfetch.MoveFirst
		do until recfetch.EOF%>
          <tr>
          <td><input type="radio" name="optmoduleid" id="optmoduleid" value="<%=recfetch(0).value%>" onclick="clearframe()">
          <font color="black" face="MS Sans Serif" size="2"><%=recfetch(1).value%></font></td>
          <%recfetch.MoveNext%>
          </tr>
		<%loop%>
      <%else%>
          <% Response.Write ("Data does not exists")%>
          <% 
       		'''''' Make buttons disable or enable 
       		Response.Write("<script language=vbscript>")
			Response.Write ("window.parent.window.document.frmworkallot.cmdAdd.disabled=true" & chr(13))
			Response.Write ("window.parent.window.document.frmworkallot.cmddelete.disabled=true" & chr(13))
			'Response.Write ("window.parent.window.document.frmworkallot.cmdModify.disabled=true" & chr(13))
			Response.Write ("window.parent.window.document.frmworkallot.cmdQuery.disabled=true")
			Response.Write("</script>" )
      			   
      end if%>
    <%end if%>
    <input type="hidden" name="hden" id="hden">
    </form>
  </table>

</body>

