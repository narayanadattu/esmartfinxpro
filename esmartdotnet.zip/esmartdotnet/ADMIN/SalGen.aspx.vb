Imports System.IO
Imports System.Web
Imports System.Web.UI.HtmlControls.HtmlInputFile

Public Class SalGen
    Inherits System.Web.UI.Page

    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim objtran As OracleClient.OracleTransaction
    'Protected WithEvents txtResult As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txtInputVals As System.Web.UI.WebControls.TextBox
    Dim objconn As New OracleClient.OracleConnection
    Dim errmsg As String
    Dim o_errmsg1 As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Try

            'txtResult.Text = ""
            Dim strCurrFileName, strCurrFileExt, filePath, strQS, strArrQS() As String

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If


            ' strQS = Request.QueryString("strVin")
            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")

            If strArrQS(0) = "OKCLICK" Then
                Dim impStatus As String
                impStatus = postTransaction()
            End If

        Catch ex As Exception
            'txtResult.Text = ex.Message()
        End Try
    End Sub

    Private Function postTransaction() As String
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        Dim dt As New DataTable


        Try
            Dim strCommServ, strCommMod, strCommGl, strCommBr, strCommGlDesc, strCommAcc, strCommAmt, StrIndGrossAmt, strServMod, strServGl, strServGlDesc, strServAcc, strServPercent, strEffDate, strSrvTax, strAutoPostCharges, errmsg, strBatchNo, strTranNo1, strTranNo2, strTranNo3, commYN, servTaxYN, strtranno, strNam As String
            Dim brCode, curCode, drMod, drGl, drAcc, appDate, userId, machineID, brAbbcode, stOtalow As String
            Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg As String
            Dim dblComm, dblSrv, totDrAmt As Double
            Dim iCnt, jCnt As Integer
            Dim strtemp, strbill, grdRows, grdCols, strBal, strQS, strArrQS, strVal, strValDr, StrQuery, strEmpno, strEmprPf, strEmprEsi
            Dim strPF, strPtax, strDep, strLoan, strAdv, strTds, strmn, stryr, strGip, strOthd, strESI, strVPF As String
            Dim strSqlAcc, strNftsYN, strPayfield, strPayVal, strCommMod1, strCommGl1, strCommAcc1 As String
            Dim stBnam, stImpyn, stPamt
            Dim strAssessYear As String
            Dim strPanno As String
            Dim strTDSCustomerid, o_ErrMsg As String
            Dim strSalBrCode, strSalModId, strSalGlcode, strSalAccNo, strITForm As String


            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")
            strVal = strArrQS(1).Split("@")
            strValDr = strVal(0).Split("~")
            Dim strvalcol, strvalrow()
            strvalrow = strVal(1).Split("|")

            appDate = strValDr(0)
            userId = strValDr(1)
            machineID = strValDr(2)
            totDrAmt = strValDr(3)
            brCode = strValDr(4)
            strmn = strValDr(5)
            stryr = strValDr(6)

            strBatchNo = ""
            strTranNo1 = ""
            curCode = "INR"

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            objtran = objconn.BeginTransaction()

            ''for bank name 
            StrQuery = ""

            StrQuery = "SELECT depcertificate from genbankparm"

            Dim objBnk As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objBnk, StrQuery, objtran)

            If objBnk.HasRows = True Then
                objBnk.Read()

                stBnam = objBnk(0)

            End If

            objBnk.Close()
            objBnk.Dispose()
            objBnk = Nothing

            ''for Pf Cut off Value
            StrQuery = ""
            StrQuery = "SELECT IMPYN, value1 from GENCONFIGMST where CODE='PFIMP'"

            Dim objPcf As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objPcf, StrQuery, objtran)

            If objPcf.HasRows = True Then
                objPcf.Read()

                stImpyn = objPcf(0)
                stPamt = objPcf(1)
            End If

            objPcf.Close()
            objPcf.Dispose()
            objPcf = Nothing


            For iCnt = 0 To strvalrow.Length - 1

                'For iCnt = 0 To UBound(strvalrow)
                strvalcol = strvalrow(iCnt).Split("~")

                strNam = strvalcol(1)

                StrQuery = ""

                StrQuery = "SELECT BRANCHCODE FROM employeemst where EMPNAME like '%" & strNam & "%'"

                Dim objDr1 As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDr1, StrQuery, objtran)

                If objDr1.HasRows = True Then
                    objDr1.Read()

                    strCommBr = objDr1(0)

                    If brCode <> strCommBr Then

                        brAbbcode = "ABB"

                        Exit For

                    End If

                End If

                objDr1.Close()
                objDr1.Dispose()
                objDr1 = Nothing

            Next

            If brAbbcode = "ABB" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            Else
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            End If


            StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='SALPAID' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='SALPAID' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

            Dim objDr As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objDr, StrQuery, objtran)

            If objDr.HasRows = True Then
                objDr.Read()

                drMod = objDr(0)
                drGl = objDr(1)
                drAcc = objDr(2)

                StrQuery = "SELECT glcode,accno FROM " & drMod & "MST where GLCODE='" & drGl & "' and ACCNO='" & drAcc & "' and Branchcode='" & brCode & "'"
                Dim objDrtab As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                If objDrtab.HasRows = True Then
                    While objDrtab.Read

                        drGl = objDrtab(0)
                        drAcc = objDrtab(1)

                        strRemarksDr = "Salary Paid for the Month Of " & strmn & " " & stryr '& " "
                        'Salary Paid for the Month Of April 2016


                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                        "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                        "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                        "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                        "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                        "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                        "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                        "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                        "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                        "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                        "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                        "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                        "ABBYN"

                        If brAbbcode = "ABB" Then
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                        "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                        "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                        Else
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                        "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                        "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                        End If


                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                        If brAbbcode = "ABB" Then
                            StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                        Else
                            StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                        "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                        "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                        "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                        End If


                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                    End While
                Else
                    Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)

                End If

                objDrtab.Close()
                objDrtab.Dispose()
                objDrtab = Nothing

            Else
                Throw New Exception("ModuleId or Glcode Or Accno is null for Debit Salary Paid ")

            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing




            For iCnt = 0 To strvalrow.Length - 1

                'For iCnt = 0 To UBound(strvalrow)
                strvalcol = strvalrow(iCnt).Split("~")

                strNam = strvalcol(1)
                strCommAmt = strvalcol(19)
                StrIndGrossAmt = strvalcol(6)
                strPF = strvalcol(7)
                strPtax = strvalcol(8)
                strDep = strvalcol(9)
                strLoan = strvalcol(10)
                strAdv = strvalcol(11)
                strTds = strvalcol(12)
                strGip = strvalcol(13)
                strOthd = strvalcol(14)
                strESI = strvalcol(15)
                strVPF = strvalcol(16)
                stOtalow = strvalcol(17)

                strEmprPf = 0
                strEmprEsi = 0

                StrQuery = ""


                StrQuery = "SELECT BRANCHCODE, MODULEID, GLCODE, ACCNO, EMPCODE FROM employeemst where EMPNAME like '%" & strNam & "%' and status='R'"
                Dim objDr1 As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDr1, StrQuery, objtran)

                strSalBrCode = ""
                strSalModId = ""
                strSalGlcode = ""
                strSalAccNo = ""
                If objDr1.HasRows = True Then
                    objDr1.Read()
                    strCommBr = objDr1(0)
                    strCommMod = objDr1(1)
                    strCommGl = objDr1(2)
                    strCommAcc = objDr1(3)
                    strEmpno = objDr1(4)
                    strSalBrCode = objDr1(0)
                    strSalModId = objDr1(1)
                    strSalGlcode = objDr1(2)
                    strSalAccNo = objDr1(3)
                End If

                objDr1.Close()
                objDr1.Dispose()
                objDr1 = Nothing

                Dim Acstat
                StrQuery = ""

                StrQuery = "SELECT STATUS FROM " & strCommMod & "MST WHERE accno='" & strCommAcc & "' AND glcode='" & strCommGl & "' AND branchcode='" & strCommBr & "'"

                Dim objMac As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objMac, StrQuery, objtran)

                If objMac.HasRows = True Then
                    objMac.Read()

                    Acstat = objMac(0)

                    If Acstat = "R" Then

                    Else
                        Throw New Exception("Salary Credit Account Is closed For Module : " + strCommMod + " AccNo. " + strCommAcc)
                    End If
                Else
                    Throw New Exception("Not A Valid Credit Account Number ")
                End If

                objMac.Close()
                objMac.Dispose()
                objMac = Nothing


                strServGl = ""
                strServGlDesc = ""
                strServAcc = ""
                strServPercent = ""
                strEffDate = ""
                strSrvTax = ""

                If brAbbcode = "ABB" Then
                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strTranNo2 = objCmd.ExecuteScalar
                Else
                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strTranNo2 = objCmd.ExecuteScalar
                End If


                'Salary for the Month of Apr 2016'
                strRemarksDr = "Salary for the Month of " & strmn & " " & stryr

                If brAbbcode = "ABB" Then
                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                "NULL,NULL,'N',NULL,'Y'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                Else
                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                "NULL,NULL,'N',NULL,'Y'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                End If



                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

                If brAbbcode = "ABB" Then
                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                "NULL,NULL,'N',NULL,'Y'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                Else
                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                "NULL,NULL,'N',NULL,'Y'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                End If



                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

                If strGip <> 0 Then ''gip

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='GIP' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='GIP' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrgip As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrgip, StrQuery, objtran)

                    If objDrgip.HasRows = True Then
                        While objDrgip.Read


                            strCommMod = objDrgip(0)
                            strCommGl = objDrgip(1)
                            strCommAcc = objDrgip(2)

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    strCommAmt = strGip


                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'GIP from "name" for Apr 2016
                                    strRemarksDr = "GIP from " & strNam & " for " & strmn & " " & stryr

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                    "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                    "NULL,NULL,'N',NULL,'Y'," & _
                                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                    "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                    "NULL,NULL,'N',NULL,'Y'," & _
                                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                               "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                               "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                               "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                               "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                               "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                               "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                               "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                               "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                               "NULL,NULL,'N',NULL,'Y'," & _
                                               "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                               "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                               "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                               "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                               "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                               "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                               "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                               "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                               "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                               "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                               "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                               "NULL,NULL,'N',NULL,'Y'," & _
                                               "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                               "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                               "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit GIP")
                    End If

                    objDrgip.Close()
                    objDrgip.Dispose()
                    objDrgip = Nothing


                End If

                If strPF <> 0 Then ''PF

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='PF' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='PF' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrpf As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrpf, StrQuery, objtran)

                    If objDrpf.HasRows = True Then
                        While objDrpf.Read


                            strCommMod = objDrpf(0)
                            strCommGl = objDrpf(1)
                            strCommAcc = objDrpf(2)

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    strCommAmt = strPF


                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'Employee PF from "name" for Apr 2016
                                    strRemarksDr = "Employee PF from " & strNam & " for " & strmn & " " & stryr

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing


                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit PF")
                    End If

                    objDrpf.Close()
                    objDrpf.Dispose()
                    objDrpf = Nothing


                    '''Employer PF 

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='PF' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='PF' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrpf1 As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrpf1, StrQuery, objtran)

                    If objDrpf1.HasRows = True Then
                        While objDrpf1.Read


                            strCommMod1 = objDrpf1(0)
                            strCommGl1 = objDrpf1(1)
                            strCommAcc1 = objDrpf1(2)

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod1 & "MST where GLCODE='" & strCommGl1 & "' and ACCNO='" & strCommAcc1 & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl1 = objDrtab(0)
                                    strCommAcc1 = objDrtab(1)

                                    StrQuery = ""

                                    If stImpyn = "Y" Then

                                        StrQuery = "SELECT CASE WHEN x.PROVFUND > " & stPamt & " THEN " & stPamt & " ELSE x.PROVFUND END pf FROM ( SELECT ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF')),0))/100),0))PROVFUND FROM EMPLOYEEMST WHERE EMPCODE = '" & strEmpno & "' AND status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & brCode & "')x"

                                    Else
                                        If stBnam = "ELURU" Then
                                            StrQuery = "SELECT x.PROVFUND FROM ( SELECT ROUND(NVL((((NVL(BASIC,0)+NVL(DA,0))*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF')),0))/100),0))PROVFUND FROM EMPLOYEEMST WHERE EMPCODE = '" & strEmpno & "' AND status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & brCode & "')x"
                                        Else
                                            StrQuery = "SELECT x.PROVFUND  FROM ( SELECT ROUND(NVL(((NVL(BASIC,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='PF')),0))/100),0))PROVFUND FROM EMPLOYEEMST WHERE EMPCODE = '" & strEmpno & "' AND status='R' AND grosspay<>'0' AND WORKINGBRCODE='" & brCode & "')x"
                                        End If

                                    End If


                                    Dim objDrpf2 As OracleClient.OracleDataReader
                                    ExecuteSelectQuery1(objDrpf2, StrQuery, objtran)

                                    If objDrpf2.HasRows = True Then
                                        While objDrpf2.Read
                                            strCommAmt = objDrpf2(0)

                                            strEmprPf = strCommAmt

                                            ''debit paymet for Pf
                                            If brAbbcode = "ABB" Then
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            Else
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            End If

                                            'Employer PF from "name" for Apr 2016
                                            strRemarksDr = "Employer PF to " & strNam & " for " & strmn & " " & stryr

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                         "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                            Else
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                         "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                            End If



                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO " & strCommMod1 & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                       "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                       "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                       "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                       "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                       "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                       "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                       "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                       "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                       "NULL,NULL,'N',NULL,'Y'," & _
                                                       "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                       "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                       "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                            Else
                                                StrInsert = "INSERT INTO " & strCommMod1 & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                       "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                       "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                       "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                       "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                       "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                       "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                       "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                       "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                       "NULL,NULL,'N',NULL,'Y'," & _
                                                       "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                       "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                       "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                            End If


                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            ''credit paymet for Pf
                                            If brAbbcode = "ABB" Then
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            Else
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            End If

                                            'Employee PF from "name" for Apr 2016
                                            strRemarksDr = "Employer PF from " & strNam & " for " & strmn & " " & stryr

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                            Else
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                            End If



                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                            Else
                                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                            End If


                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                        End While

                                    End If
                                    objDrpf2.Close()
                                    objDrpf2.Dispose()
                                    objDrpf2 = Nothing

                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)

                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Debit PF")
                    End If

                    objDrpf1.Close()
                    objDrpf1.Dispose()
                    objDrpf1 = Nothing

                End If

                If strPtax <> 0 Then ''PTAX

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='PTAX' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='PTAX' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrptax As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrptax, StrQuery, objtran)

                    If objDrptax.HasRows = True Then

                        While objDrptax.Read

                            strCommMod = objDrptax(0)
                            strCommGl = objDrptax(1)
                            strCommAcc = objDrptax(2)
                            strCommAmt = strPtax

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'PTax from "name" for Apr 2016
                                    strRemarksDr = "PTax from " & strNam & " for " & strmn & " " & stryr

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing
                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("Moduleid or Glcode or Accno is null for Credit PTAX")

                    End If

                    objDrptax.Close()
                    objDrptax.Dispose()
                    objDrptax = Nothing

                End If
                '' start DEPOSIT  
                If strDep <> 0 Then ''DEPOSIT  

                    StrQuery = "SELECT branchcode, moduleid, glcode, accno, amount FROM SALARYDEDUCTIONMST WHERE dedtype='DEP' AND empcode='" & strEmpno & "' AND STATUS='R' "

                    Dim objDrdep As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrdep, StrQuery, objtran)

                    If objDrdep.HasRows = True Then

                        While objDrdep.Read


                            strCommMod = objDrdep(1)
                            strCommBr = objDrdep(0)
                            If strCommMod = "MISC" Or strCommMod = "PL" Then
                                strCommBr = brCode
                            Else
                                strCommBr = objDrdep(0)
                            End If


                            strCommGl = objDrdep(2)
                            strCommAcc = objDrdep(3)
                            strCommAmt = objDrdep(4)

                            Dim Depstat
                            StrQuery = ""

                            StrQuery = "SELECT STATUS FROM " & strCommMod & "MST WHERE accno='" & strCommAcc & "' AND glcode='" & strCommGl & "' AND branchcode='" & strCommBr & "'"

                            Dim objDep As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDep, StrQuery, objtran)

                            If objDep.HasRows = True Then
                                objDep.Read()

                                Depstat = objDep(0)

                                If Depstat = "R" Then

                                Else
                                    Throw New Exception("Deposit Account Is closed ")
                                End If
                            Else
                                Throw New Exception("Not A Valid Deposit Account Number ")
                            End If

                            objDep.Close()
                            objDep.Dispose()
                            objDep = Nothing

                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            strRemarksDr = "Trf from " & strNam & " for " & strmn & " " & stryr & " Salary"

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If



                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                        End While
                    Else
                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                    End If

                    objDrdep.Close()
                    objDrdep.Dispose()
                    objDrdep = Nothing

                End If
                '' end DEPOSIT  
                '' start loan  
                If strLoan <> 0 Then ''LOAN 

                    StrQuery = "SELECT branchcode, moduleid, glcode, accno, amount FROM SALARYDEDUCTIONMST WHERE dedtype='LOAN' AND empcode='" & strEmpno & "' AND STATUS='R'"

                    Dim objDrlon As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrlon, StrQuery, objtran)

                    If objDrlon.HasRows = True Then


                        While objDrlon.Read

                            strCommBr = objDrlon(0)
                            strCommMod = objDrlon(1)
                            strCommGl = objDrlon(2)
                            strCommAcc = objDrlon(3)
                            strCommAmt = objDrlon(4)

                            Dim Lonstat
                            StrQuery = ""

                            StrQuery = "SELECT STATUS FROM " & strCommMod & "MST WHERE accno='" & strCommAcc & "' AND glcode='" & strCommGl & "' AND branchcode='" & strCommBr & "'"

                            Dim objLon As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objLon, StrQuery, objtran)

                            If objLon.HasRows = True Then
                                objLon.Read()

                                Lonstat = objLon(0)

                                If Lonstat = "R" Then

                                Else
                                    Throw New Exception("Loan Account Is closed ")
                                End If
                            Else
                                Throw New Exception("Not A Valid Loan Account Number ")
                            End If

                            objLon.Close()
                            objLon.Dispose()
                            objLon = Nothing

                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            strRemarksDr = "Trf from " & strNam & " for " & strmn & " " & stryr & " Salary"

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If



                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing


                        End While
                    Else
                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                    End If

                    objDrlon.Close()
                    objDrlon.Dispose()
                    objDrlon = Nothing

                End If
                '' end  loan  
                '' start Advance  
                If strAdv <> 0 Then ''Advance

                    StrQuery = "SELECT branchcode, moduleid, glcode, accno, amount FROM SALARYDEDUCTIONMST WHERE dedtype='ADV' AND empcode='" & strEmpno & "' AND STATUS='R'"

                    Dim objDradv As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDradv, StrQuery, objtran)

                    If objDradv.HasRows = True Then

                        While objDradv.Read

                            strCommBr = objDradv(0)
                            strCommMod = objDradv(1)
                            strCommGl = objDradv(2)
                            strCommAcc = objDradv(3)
                            strCommAmt = objDradv(4)

                            '' procedure

                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            strRemarksDr = "ADV from " & strNam & " for " & strmn & " " & stryr

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If

                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing


                        End While

                    Else
                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                    End If

                    objDradv.Close()
                    objDradv.Dispose()
                    objDradv = Nothing

                End If
                '' end Advance  
                If strTds <> 0 Then ''TDS

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='TDS' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='TDS' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrtds As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrtds, StrQuery, objtran)

                    If objDrtds.HasRows = True Then
                        While objDrtds.Read

                            strCommMod = objDrtds(0)
                            strCommGl = objDrtds(1)
                            strCommAcc = objDrtds(2)
                            strCommAmt = strTds


                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            'TDS from "name" for Apr 2016
                            strRemarksDr = "TDS from " & strNam & " for " & strmn & " " & stryr

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If



                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            ''tdsdtls 

                            ''    strITForm = "92B"
                            strITForm = getITformITCode(1, objconn, objtran)
                            strAssessYear = GetAssessYear(appDate)
                            strTDSCustomerid = GetCustomerid10(strSalBrCode, strSalModId, strSalGlcode, strSalAccNo, objconn, objtran, o_ErrMsg)
                            strPanno = GetCustomeridPanNo(strTDSCustomerid, objconn, objtran, o_ErrMsg)

                            StrInsert = "INSERT INTO tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, NAME, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, FROMDATE, TODATE, LNKMODULEID, LNKGLCODE, LNKACCNO, REMARKS, TRANSTATUS, STATUS, USERID, MACHINEID,  SYSTEMDATE, APPLICATIONDATE, CUSTOMERID, ASSESYEAR,  REFUNDYN, PANYN, ITFORM,VENDORPANNO, AMTPAID) VALUES('" & strSalBrCode & "','" & curCode & "','" & strSalModId & "','" & strSalGlcode & "','" & strSalAccNo & "','" & strNam & "','" & strBatchNo & "','" & strTranNo2 & "','" & -1 * CDbl(strCommAmt) & "','3','" & appDate & "','" & appDate & "','" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "','" & strRemarksDr & "','A','R','" & userId & "','" & machineID & "',sysdate,'" & appDate & "', '" & strTDSCustomerid & "','" & strAssessYear & "','N','N', '" & strITForm & "', '" & strPanno & "','" & CDbl(StrIndGrossAmt) & "')"

                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit TDS")


                    End If

                    objDrtds.Close()
                    objDrtds.Dispose()
                    objDrtds = Nothing

                End If

                If strOthd <> 0 Then ''Other Deduction

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='OTHD' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='OTHD' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrothd As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrothd, StrQuery, objtran)

                    If objDrothd.HasRows = True Then
                        While objDrothd.Read


                            strCommMod = objDrothd(0)
                            strCommGl = objDrothd(1)
                            strCommAcc = objDrothd(2)
                            strCommAmt = strOthd

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'Oth Ded from "name" for Apr 2016
                                    strRemarksDr = "OTHDed from " & strNam & " for " & strmn & " " & stryr

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing
                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit Other Deduction")
                    End If

                    objDrothd.Close()
                    objDrothd.Dispose()
                    objDrothd = Nothing

                End If

                If strESI <> 0 Then ''ESI

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='ESI' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='ESI' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrpf As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrpf, StrQuery, objtran)

                    If objDrpf.HasRows = True Then
                        While objDrpf.Read


                            strCommMod = objDrpf(0)
                            strCommGl = objDrpf(1)
                            strCommAcc = objDrpf(2)
                            strCommAmt = strESI

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'Employee ESI from "name" for Apr 2016
                                    strRemarksDr = "Employee ESI from " & strNam & " for " & strmn & " " & stryr

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                 "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                 "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                 "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                 "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                 "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                 "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                 "NULL,NULL,'N',NULL,'Y'," & _
                                                 "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                 "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                 "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing
                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit ESI")
                    End If

                    objDrpf.Close()
                    objDrpf.Dispose()
                    objDrpf = Nothing


                    ''Employer ESI 

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='ESI' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='ESI' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrpf1 As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrpf1, StrQuery, objtran)

                    If objDrpf1.HasRows = True Then
                        While objDrpf1.Read


                            strCommMod1 = objDrpf1(0)
                            strCommGl1 = objDrpf1(1)
                            strCommAcc1 = objDrpf1(2)

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod1 & "MST where GLCODE='" & strCommGl1 & "' and ACCNO='" & strCommAcc1 & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl1 = objDrtab(0)
                                    strCommAcc1 = objDrtab(1)

                                    StrQuery = ""

                                    StrQuery = "SELECT ROUND(NVL(((NVL(GROSSPAY,0)*NVL((SELECT value FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='ESI' AND effectivedate=(SELECT MAX(effectivedate) FROM EMPLOYERPARM WHERE empcode='EMY' AND CODE='ESI')),0))/100),0)) esi FROM EMPLOYEEMST WHERE EMPCODE = '" & strEmpno & "' AND status='R' AND GROSSPAY < 15000 and GROSSPAY <> '0' AND WORKINGBRCODE='" & brCode & "'"

                                    Dim objDrpf2 As OracleClient.OracleDataReader
                                    ExecuteSelectQuery1(objDrpf2, StrQuery, objtran)

                                    If objDrpf2.HasRows = True Then
                                        While objDrpf2.Read

                                            strCommAmt = objDrpf2(0)

                                            strEmprEsi = strCommAmt

                                            ''debit paymet for ESI
                                            If brAbbcode = "ABB" Then
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            Else
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            End If

                                            'Employer PF from "name" for Apr 2016
                                            strRemarksDr = "Employer ESI to " & strNam & " for " & strmn & " " & stryr

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                         "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                            Else
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                         "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                            End If



                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO " & strCommMod1 & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                        "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                            Else
                                                StrInsert = "INSERT INTO " & strCommMod1 & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod1 & "'," & _
                                                        "'" & strCommGl1 & "','" & strCommAcc1 & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod1 & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod1 & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc1 & "' AND GLCODE='" & strCommGl1 & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                            End If


                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            ''credit paymet for ESI
                                            If brAbbcode = "ABB" Then
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            Else
                                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                                objCmd.Transaction = objtran
                                                strTranNo2 = objCmd.ExecuteScalar
                                            End If

                                            'Employee PF from "name" for Apr 2016
                                            strRemarksDr = "Employer ESI from " & strNam & " for " & strmn & " " & stryr

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                            Else
                                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                         "NULL,NULL,'N',NULL,'Y'," & _
                                                         "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                            End If



                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                            If brAbbcode = "ABB" Then
                                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                            Else
                                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                        "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                        "NULL,NULL,'N',NULL,'Y'," & _
                                                        "NULL,NULL,NULL,'" & strCommMod1 & "','" & strCommGl1 & "','" & strCommAcc1 & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                            End If


                                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                            objCmd.Transaction = objtran
                                            objCmd.ExecuteNonQuery()
                                            objCmd.Dispose()
                                            objCmd = Nothing

                                        End While
                                    Else
                                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                                    End If
                                    objDrpf2.Close()
                                    objDrpf2.Dispose()
                                    objDrpf2 = Nothing
                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Debit ESI")
                    End If

                    objDrpf1.Close()
                    objDrpf1.Dispose()
                    objDrpf1 = Nothing

                End If


                If strVPF <> 0 Then ''VPF

                    StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='VPF' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='VPF' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    Dim objDrpf As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrpf, StrQuery, objtran)

                    If objDrpf.HasRows = True Then
                        While objDrpf.Read


                            strCommMod = objDrpf(0)
                            strCommGl = objDrpf(1)
                            strCommAcc = objDrpf(2)
                            strCommAmt = strVPF

                            StrQuery = ""

                            StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                            Dim objDrtab As OracleClient.OracleDataReader
                            ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                            If objDrtab.HasRows = True Then
                                While objDrtab.Read

                                    strCommGl = objDrtab(0)
                                    strCommAcc = objDrtab(1)

                                    If brAbbcode = "ABB" Then
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    Else
                                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                        objCmd.Transaction = objtran
                                        strTranNo2 = objCmd.ExecuteScalar
                                    End If

                                    'VPF from "name" for Apr 2016
                                    strRemarksDr = "VPF from " & strNam & " for " & strmn & " " & stryr


                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                    "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                    "NULL,NULL,'N',NULL,'Y'," & _
                                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                    Else
                                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                    "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                    "NULL,NULL,'N',NULL,'Y'," & _
                                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                    End If



                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing

                                    If brAbbcode = "ABB" Then
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                    Else
                                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                    End If


                                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                    objCmd.Transaction = objtran
                                    objCmd.ExecuteNonQuery()
                                    objCmd.Dispose()
                                    objCmd = Nothing
                                End While
                            Else
                                Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                            End If

                            objDrtab.Close()
                            objDrtab.Dispose()
                            objDrtab = Nothing

                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit VPF")
                    End If

                    objDrpf.Close()
                    objDrpf.Dispose()
                    objDrpf = Nothing

                End If


                strPayfield = "BRANCHCODE, EMPCODE, BASIC, DA, HRA, ALLOWANCE, GROSS, PF, PTAX, RD, LOAN, ADVANCES, GIP, TDS, OTHDEDUC, ESI, VPF, NETPAY, EMPRPF, EMPRESI, OTHALOW, PAIDMONTH, PAIDYEAR, PAIDBATCH, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE"

                strPayVal = "'" & brCode & "','" & strEmpno & "','" & strvalcol(2) & "','" & strvalcol(3) & "','" & strvalcol(4) & "','" & strvalcol(5) & "','" & strvalcol(6) & "','" & strvalcol(7) & "','" & strvalcol(8) & "','" & strvalcol(9) & "','" & strvalcol(10) & "','" & strvalcol(11) & "','" & strvalcol(13) & "','" & strvalcol(12) & "','" & strvalcol(14) & "','" & strvalcol(15) & "','" & strvalcol(16) & "','" & strvalcol(19) & "','" & strEmprPf & "','" & strEmprEsi & "','" & stOtalow & "','" & strmn & "','" & stryr & "','" & strBatchNo & "','" & appDate & "','" & userId & "','" & machineID & "',SYSDATE"

                StrInsert = "INSERT INTO SALARYPAIDDTLS (" & strPayfield & ") VALUES (" & strPayVal & ")"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing


            Next

            objtran.Commit()
            'postTransaction = "Posted SuccessFully|" & strBatchNo
            Response.Redirect("frmSalgenerate.aspx?record=Transaction Completed Batchno " & strBatchNo)


            Exit Function
        Catch ex As Exception
            'objtran.Rollback()
            'postTransaction = ex.Message

            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "").Replace("?", "")

            Response.Redirect("frmSalgenerate.aspx?record=" & o_errmsg1, False)

        End Try

    End Function

    Public Function ExecuteSelectQuery(ByRef objDrL As OracleClient.OracleDataReader, ByVal StrQuery As String)
        Dim errmsg As String
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If

        Dim objCmdES As OracleClient.OracleCommand
        objCmdES = New OracleClient.OracleCommand(StrQuery, objconn)
        objDrL = objCmdES.ExecuteReader()
        objCmdES.Dispose()
        objCmdES = Nothing
    End Function

    Private Function executeScalar(ByVal strSql) As String
        Dim strResult As String
        strResult = ""

        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception("Database Connection Failed")
            End If
        End If

        objCmd = New OracleClient.OracleCommand
        objCmd.CommandText = strSql
        objCmd.Connection = objconn
        strResult = objCmd.ExecuteScalar
        objCmd.Dispose()
        objCmd = Nothing
        executeScalar = strResult
    End Function

    Public Function ExecuteSelectQuery1(ByRef objDrL As OracleClient.OracleDataReader, ByVal StrQuery As String, ByVal objtrn As OracleClient.OracleTransaction)

        objCmd = New OracleClient.OracleCommand(StrQuery, objconn)
        objCmd.Transaction = objtrn
        objDrL = objCmd.ExecuteReader()
        objCmd.Dispose()
        objCmd = Nothing
    End Function


End Class
