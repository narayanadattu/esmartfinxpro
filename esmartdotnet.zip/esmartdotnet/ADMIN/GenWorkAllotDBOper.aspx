 <%@ Page Language="vb" CodeBehind="GenWorkAllotDBOper.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotDBOper" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : WorkAllotmentDBOper.ASP									*
'*	Purpose	  	     : A server side page for GenWorkallotment.asp          	*
'*						             							     			*
'*																	    	    *      	                              *
'*		   													                    *
'*			                                            			            *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<%
'''''****************Declaring Variables ***************


dim Objfrm,vark,kstr
dim arrtran(0,4)
dim arrtrans(0,4)
dim objquery
dim recwork
dim varx
dim icount
dim objfetch
dim varabbuser
dim recwork1

''''' Gettting the data from the calling form
modstr=Request.Form("hmod")
kstr=Request.Form("hadd")
vark=split(kstr,"|")
varabbuser=Request.Form("hidabb")
appdate=session("applicationdate")
macid=session("machineid")
''''''Get whether the user is Abbuser or not


''''' Concatenating form narrations in to a single variable
for i=5 to ubound(vark)-1
	mainnar=mainnar & ",'" & vark(i) &"'"
next
'''''' Remove the extra characters before split
mainnar=mid(mainnar,2)

'''' Split to get the data into array
modstr=split(modstr,"|")
''' Create the instance of recordset recwork1=server.CreateObject("adodb.recordset")
							
if len(kstr)>0 then
			'''' If User is selected
			if Request.Form("hok")="userid" then
						'''' formate a string of forms
						for icount=1 to vark(4)
							forms=forms & "','" & vark(icount+4)
						next
						'''' remove the unwanted characters
						forms=right(forms,len(forms)-2) & "'"
						strchk="forms"
						'''''' Create the instance of objects
						 recwork=server.CreateObject("adodb.recordset")
						 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
						
						''''' Query forms for given narrations
						'Code corrected by Radhika on 13 May 2008
						 recwork=objfetch.singlerecordset("genmoduleidformsmst", _
							"forms,narration,formsid", _
							"formsid in(" & forms &") and moduleid='" & _
							cstr(vark(3))& "'")
					
						'''' Set the values for table name and fields	
						StrTabName="GENUSERIDFORMSMST"   
						StrFldNames="userid,moduleid,forms,narration,status,addoreliminate," & _
									"applicationdate,systemdate,machineid,alloteduserid,transtatus,formsid"
			  
		
			  ''''''if  Delete option is selected
			  if vark(0)="delete" then
			  		st1="E"		'''' set the addoreliminate status to E
			  		stat="D"
			  else
					st1="A"		'''' set the addoreliminate status to A
					stat="N"
			  end if 
				
			  'strCond = " (userid,moduleid," & strchk & ") in ("
			  
			  do while not  recwork.eof
			     varx=recwork(1).value
			     vary=recwork(0).value
			    '''''''' Form the update condition into an array of values
			     StrUpCondition="userid='"& cstr(vark(2)) &"' and moduleid='"& _ 
			     cstr(vark(3))&"'"
			     
			     ''''''''''code commented by Radhika 13 May 2008
			     'StrCondition=" userid='"& cstr(vark(2)) &"' and moduleid='"&  _
			     'cstr(vark(3))&"' and " & strchk & " ='"& cstr(vary) &"'" & "|"
				 ''''''''''New code is
			     StrCondition="('" & cstr(vark(2)) & "','"&  _
			     cstr(vark(3)) & "','"& cstr(vary) & "') " 


			     '''' Get the field values
			    
			     
					StrFldValues="'" & cstr(vark(2)) &"','"& cstr(vark(3)) & "','" & _
							cstr(vary)& "','" & cstr(varx) &"','R','" & st1 & "','" & appdate & _
							 "',sysdate,'" & macid & "','" & session("userid") & "','" & _
							 stat & "'," &  recwork(2).value & "|"
				
							
			   	 '''' Form an array of values into  string
			   	 stflds = stflds & StrFldValues 
			  	 '''' Form an array of condtions into  string
			  	 if StrCond = "" then 
			  		strCond = " (userid,moduleid," & strchk & ") in (" & StrCondition 
			  	 else
			  		StrCond=StrCond & "," & StrCondition
			  	 end if
			  	 recwork.movenext
			  loop
				''''' Remove extra characters			
				 if len(stflds)>0 then 	 stflds=left(stflds,len(stflds)-1)
				 'if len(strcond)>0 then  StrCond=left(StrCond,len(StrCond)-1)
				 if len(strcond)>0 then strcond = strcond & ")"
				 '''' Create the instance of object
				  Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
				
				  Response.Write (vark(0))
			''''''' If transaction mode is 'ADD'
			if vark(0)="add" then
					'''' Create the instance of objects
					objquery=server.CreateObject("queryrecordsets.fetchrecordsets")
					recwork=server.CreateObject("adodb.recordset")
					
					''''' Redim the array					
					redim arrtran(0,4)
					
					'''''' Delete the records depending on the condition formed above
					ArrTran(0,0)="D"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=""				
					ArrTran(0,3)=""				
					ArrTran(0,4)=StrCond
				    StrMsg= Objfrm.DataTransactions(ArrTran,,,,,"N")
				  
				 
				    ''''' Redim the array					
				    redim arrtran(0,4)
					'''''' Insert new records with added status
					ArrTran(0,0)="I"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=StrFldNames	
					ArrTran(0,3)=stflds	
					ArrTran(0,4)=""	
					
					Response.Write (ArrTran(0,1) &"<br>")
					Response.Write (ArrTran(0,2) &"<br>")
					Response.Write (ArrTran(0,3) &"<br>")

					StrMsg= Objfrm.DataTransactions(ArrTran,,,,,"N")
						
					 Objfrm=nothing
			
			''''''' If transaction mode is 'delete'
			elseif vark(0)="delete" then
				
				''''' Redim the array					
					redim arrtrans(0,4)
				'''''' Delete the records depending on the condition formed above
						ArrTrans(0,0)="D"			
						ArrTrans(0,1)=StrTabName		
						ArrTrans(0,2)=""				
						ArrTrans(0,3)=""				
						ArrTrans(0,4)=strcond
						StrMsg= Objfrm.DataTransactions(ArrTrans,,,,,"N")
						
					Response.Write (StrTabName & "<br>")
					Response.Write (strcond & "<br>")
					Response.Write (strmsg & "ch" & "<br>")
					
															
					''''' Redim the array	
					redim arrtrans(0,4)
						'''''' Insert new records with added status
					ArrTrans(0,0)="I"			
					ArrTrans(0,1)=StrTabName		
					ArrTrans(0,2)=strfldnames
					ArrTrans(0,3)=stflds				
					ArrTrans(0,4)=""
						StrMsg= Objfrm.DataTransactions(ArrTrans,,,,,"N")
					'Response.Write stflds & "<br>"
					'Response.Write strfldnames & "<br>"
					'Response.Write StrTabName & "<br>"
					
					 Objfrm=nothing
			end if

		   
	    
	    
  '''''''''*************USER Updataions are over*************'''''''''''''''''''''''''''''''''''''''
  
  
  
  '''''''''''  if Group is selected
  elseif Request.Form("hok")="groupid" then
		''''''' Create the instances of objects
		 objquery=server.CreateObject("queryrecordsets.fetchrecordsets")
		 recwork1=server.CreateObject("adodb.recordset")
		'''''Query forms and corresponding narrations for the selected forms
		 recwork1=objquery.singlerecordset("genmoduleidformsmst","forms,NARRATION,formsid", _
		"moduleid='" & cstr(vark(3)) &"' and formsid in(" & mainnar &")")
		
		'Response.Write "genmoduleidformsmst" & "forms,NARRATION,formsid" & _
		'"moduleid='" & cstr(vark(3)) &"' and formsid in(" & mainnar &")" & "<br>"
		
		
		
		''''. Set the table name and fields	
		StrTabName="gengroupformsmst"   
		StrFldNames="groupcode,moduleid,forms,narration,status," & _
					"applicationdate,systemdate,userid,machineid,transtatus,formsid"
		''''''' Check whether the query is formed based on narration or forms
		''''' if it is delete, from the front end narrations are coming other wise it is form 
	
		
			  if vark(0)="delete" then
					strchk="formsid"
					stat="D"
				else
					strchk="formsid"
					stat="N"
			  end if
			 
	
	'if 1=2 then
        for icount=1 to vark(4)
          varx=vark(icount+4)
          
          ''''' Form the condition vlaues
          StrCondition=" Groupcode='"& cstr(vark(2)) &"' and moduleid='"& cstr(vark(3))& _
          "' and " & strchk &  " ='"& cstr(varx) &"'" & "|"
          '''''' Form the field values
          StrFldValues="'" & cstr(vark(2)) &"','"& cstr(vark(3)) &"','"& cstr(recwork1(0).value)& _
          "','" & cstr(recwork1(1).value) &"','R','" & appdate & "',sysdate,'" & session("userid") & "'" & _
		  ",'" & session("machineid") & "','" & stat & "'," & cstr(recwork1(2).value)  & "|"
       	  '''' combine into a string of array
       	  stflds=stflds &	StrFldValues 
       	  StrCond=StrCond & StrCondition
       	 recwork1.MoveNext 
        next
        
			'''''' Avoid unwanted characters	
		  stflds=left(stflds,len(stflds)-1)
		  StrCond=left(StrCond,len(StrCond)-1)
		  ''''''' Create the instances of objects
 	       Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
		  
			if vark(0)="add" then
					''''''' Insert the forms for the given group
					ArrTran(0,0)="I"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=StrFldNames	
					ArrTran(0,3)=stflds	
					ArrTran(0,4)=""				
				    StrMsg= Objfrm.DataTransactions(ArrTran,,,,,"N")
	    			
					
		'''''' If transaction mode is DELETE then
			elseif vark(0)="delete" then
					''''''' DELETe the forms for the given group
					ststr=split(StrCond,"|")
					strval="'D'~'" &session("userid") & "'~'" & _
									session("machineid") & "'~'" & session("applicationdate") & "'"	
					for i=1to ubound(ststr)
						strval=strval & "|" & "'D'~'" &session("userid") & "'~'" & _
									session("machineid") & "'~'" & session("applicationdate") & "'"	
					next
					
					ArrTran(0,0)="U"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)="transtatus,userid,machineid,applicationdate"				
					ArrTran(0,3)=strval
					ArrTran(0,4)=StrCond	
				    
				    Response.Write (ArrTran(0,3) & "<br>")
				    Response.Write (ArrTran(0,4))
				    StrMsg= Objfrm.DataTransactions(ArrTran,,,,,"N")
				  
					
			end if
    'end if
      end if

else
			''''' Return appropriate error message
			StrMsg="Fields does not empty"
end if
	Response.Write (strmsg)
	'''' Redirect the result
	response.Redirect ("GenWorkAllotment.aspx?record=" & StrMsg)

%>

