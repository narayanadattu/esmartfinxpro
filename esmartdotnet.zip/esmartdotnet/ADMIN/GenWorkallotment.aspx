<%@ Page Language="vb" CodeBehind="GenWorkallotment.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkallotment" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Work Allotment</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<script language="javascript">
<!--

function checkUser()
{
	//var strVin="USERCONFIGDATA|USRGRP"
	var strVin="USERCONFIGDATA|HOTRAW"
	window.document.all['idetails'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"getDtls.aspx?st="+strVin;
}

function popConfigData(str)
{
	if(str==0)
	{
		alert("Please set Parameters In Config.")
	}
	else
	{
		var kstr=str.split("|")
		if(kstr[0]=="Y")
		{
			if(("<%=session("groupcode")%>"=="ADMIN")&&("<%=session("branchcode")%>"==kstr[1]))
			{
			}
			else
			{
				alert("You Are Not Authorized User to Create User.")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}
		}
	}
}

function SelectAll()
{
	if (window.document.frames(1).frmforms.hcnt.value>0)
	{
		if(window.document.frmworkallot.chkSelectall.checked==true)
		{
			for(i=0;i<=window.document.frames(1).frmforms.chkfrm.length-1;i++)
			{
				window.document.frames(1).frmforms.chkfrm(i).checked=true
			}
		}
		else
		{
		for(i=0;i<=window.document.frames(1).frmforms.chkfrm.length-1;i++)
			{
				window.document.frames(1).frmforms.chkfrm(i).checked=false
			}
		}
	}
	else
	{
		if(window.document.frmworkallot.chkSelectall.checked==true)
		{
			//window.document.frames(1).frmforms.chkfrm.checked=true
		}
		else
		{
			//window.document.frames(1).frmforms.chkfrm(i).checked=false
		}
	}
}


function branch()
 {
	st="Branch"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	window.document.frmworkallot.txtuserid.value=""
	window.document.frmworkallot.txtuserdesc.value=""
		
 }
 
 
function Branchid(kstr)
	 { 
		  
		  if (kstr=="No Data Found...")
			return
		  kstr=kstr.split("-----")
	 	  window.document.frmworkallot.txtbrdesc.value=kstr[0]
	 	  window.document.frmworkallot.txtbrcode.value=kstr[1]
	 	  if(kstr[2]=="HO")
	 	  	  window.document.frmworkallot.radgroup(0).disabled=false
	 	  else
	 	  	 window.document.frmworkallot.radgroup(0).disabled=true
			window.document.all.imod.src="GenWorkAllotModuleID.aspx"
     		window.parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
			window.parent.frames(1).frmforms.method="post"
			window.parent.frames(1).frmforms.submit()
		
  	  
	 } 
	 
function Abb()
{
if(window.document.frmworkallot.chkABB.checked==true)
	window.document.frmworkallot.hidabb.value="Y"
else
	window.document.frmworkallot.hidabb.value="N"
}


function User()
{
 if (window.document.frmworkallot.txtbrcode.value=="") 
    {
			alert('Select Branch Code..!')
			return
    }
  
		
	window.document.frmworkallot.cmdAdd.disabled=false
	window.document.frmworkallot.cmddelete.disabled=false
	//window.document.frmworkallot.cmdModify.disabled=false
	window.document.frmworkallot.cmdQuery.disabled=false
        
 if (window.document.frmworkallot.radgroup(0).checked==true)
       {
			 window.document.frmworkallot.hopt.value ="group"
			 st="Groupid"
		   window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
		}
 else if (window.document.frmworkallot.radgroup(1).checked==true)
  {
	 args=window.document.frmworkallot.txtbrcode.value 
	 window.document.frmworkallot.hopt.value ="user"
	 st="WUserid"+args
	 window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
  }
//window.document.frmworkallot.txtuserid.value 

  }


function UserCode(kstr)
    { 
      if (kstr=="No Data Found...")
			return
      assign(kstr,window.document.frmworkallot.txtuserdesc ,window.document.frmworkallot.txtuserid)
      window.document.all.imod.src="GenWorkAllotModuleID.aspx"
	  window.parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
	  window.parent.frames(1).frmforms.method="post"
	  window.parent.frames(1).frmforms.submit()
      module()
      
      
    }
 
function module()
     {     
			var vars
			vars=window.document.frmworkallot.txtbrcode.value
			window.document.frames(0).frmmodule.hden.value=vars
			window.document.frames(0).frmmodule.action="GenWorkAllotModuleID.aspx"
			window.document.frames(0).frmmodule.method="post"
			window.document.frames(0).frmmodule.submit()
					
	}
      
function checknulls()
{
		if (window.document.frmworkallot.txtbrcode.value=="")
		
		{        
	       alert('Select Branch Code')
	       return false
	    }
	    
	       
	    if (window.document.frmworkallot.txtuserid.value=="")
	    {
	    if(window.document.frmworkallot.radgroup(0).checked==true)
	    		
			{        
				alert('Select Groupid ')
				return false
			}
	    if(window.document.frmworkallot.radgroup(1).checked==true)
	    		
			{        
				alert('Select Userid ')
				return false
			}
	    
		}
	    
}      



function mod()
  {	
		var vars
		var vart
		var varu
		var varo
		var vara
		vara=false;
		if(checknulls()==false)
			return
 
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)

  {
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
	  { 
		
		if(parent.frames(0).frmmodule.optmoduleid(i).value=="Any Bank Branch")
			window.document.frmworkallot.abbuser.value="Y"
		else
			window.document.frmworkallot.abbuser.value="N"
		vars=(parent.frames(0).frmmodule.optmoduleid(i).value);
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value 
		varo=window.document.frmworkallot.hopt.value 
		st="add" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		
		parent.frames(1).frmforms.hform.value=st
		parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
	}
		window.document.frmworkallot.hmodule.value=vars
  }
	if(vara!=true)
	
	alert('Select any Module...!')	
 
 }
	
function del()
{
var vars
var vart
var varu
var varo
var vara
vara=false;
if(checknulls()==false)
			return
if ((window.document.frmworkallot.txtuserid.value=="") || (window.document.frmworkallot.txtbrcode.value==""))
  {
	alert('Branch Code Should not be Null')
  }
  else
  {
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)
{
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
	{
		if(parent.frames(0).frmmodule.optmoduleid(i).value=="Any Bank Branch")
			window.document.frmworkallot.abbuser.value="Y"
		else
			window.document.frmworkallot.abbuser.value="N"		
		vars=(parent.frames(0).frmmodule.optmoduleid(i).value);
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value
		varo=window.document.frmworkallot.hopt.value  
		st="delete" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		parent.frames(1).frmforms.hform.value=st
		parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
	}
	
window.document.frmworkallot.hmodule.value=vars
	}
	
	if(vara!=true)
	alert('Select any one')	
	
	}	
	}
	
	
function query()
{
var vars
var vart
var varu
var varo
var vara
vara=false;
if(checknulls()==false)
			return
if ((window.document.frmworkallot.txtuserid.value=="") || (window.document.frmworkallot.txtbrcode.value==""))
  {
	alert('Branch Code Should not be Null')
  }
  else
  {
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++)
{
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
	{
		if(parent.frames(0).frmmodule.optmoduleid(i).value=="Any Bank Branch")
			window.document.frmworkallot.abbuser.value="Y"
		else
			window.document.frmworkallot.abbuser.value="N"
		vars=(parent.frames(0).frmmodule.optmoduleid(i).value);
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value 
		varo=window.document.frmworkallot.hopt.value 
		st="query" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		parent.frames(1).frmforms.hform.value=st
		parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
		}
window.document.frmworkallot.hmodule.value=vars
	}
		if(vara!=true)
		alert('Select any one')	
	}
	}		
	
	

function modify()
{
var vars
var vart
var varu
var varo
var vara
vara=false;

if(checknulls()==false)
			return
if ((window.document.frmworkallot.txtuserid.value=="") || (window.document.frmworkallot.txtbrcode.value==""))
  {
	alert('Branch Code Should not be Null')
  }
  else
  {
for(i=0;i<parent.frames(0).frmmodule.optmoduleid.length;i++){
	
	if(parent.frames(0).frmmodule.optmoduleid(i).checked==true)
	{
		if(parent.frames(0).frmmodule.optmoduleid(i).value=="Any Bank Branch")
			window.document.frmworkallot.abbuser.value="Y"
		else
			window.document.frmworkallot.abbuser.value="N"
			
		vars=(parent.frames(0).frmmodule.optmoduleid(i).value);
		vart=window.document.frmworkallot.txtbrcode.value 
		varu=window.document.frmworkallot.txtuserid.value 
		varo=window.document.frmworkallot.hopt.value 
		st="modify" + "|" + varu + "|" + vars + "|" + vart + "|" + varo
		parent.frames(1).frmforms.hform.value=st
		parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
		parent.frames(1).frmforms.method="post"
		parent.frames(1).frmforms.submit()
		vara=true;
	}
	window.document.frmworkallot.hmodule.value=vars
}
	if(vara!=true)
	alert('Select any one')	
}	
}
 
function ok()
{
var vara
var varl     
var varjj
var varf
var cnt
varf=""
vara=false;
cnt=0;


 if (window.document.frmworkallot.radgroup(1).checked==true)
  {
		window.document.frmworkallot.hok.value="userid"
		if(parent.frames(1).frmforms.hstatus.value=="add")
		{
			j=parent.frames(1).frmforms.hcnt.value
			
			if(j=1)
			{
				if(parent.frames(1).frmforms.chkfrm.checked==true)
				{
					varf=parent.frames(1).frmforms.chkfrm.value + "|";
					cnt=cnt+1;
					vara=true;
				} 
			}
   
			if(parent.frames(1).frmforms.chkfrm.length>1)
			{
				for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)   
				{
					if(parent.frames(1).frmforms.chkfrm(i).checked==true)
					{
						varf=varf +(parent.frames(1).frmforms.chkfrm(i).value) + "|";
						cnt=cnt+1;
						vara=true;
					}
				}
			}
			if (vara!=true)
			{
				alert('Select any Form...!')
				return
			}
			varb=window.document.frmworkallot.txtbrcode.value 
			varu=window.document.frmworkallot.txtuserid.value
			varm=window.document.frmworkallot.hmodule.value 
			st="add" + "|" + varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf
			window.document.frmworkallot.hadd.value=st
			window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
			window.document.frmworkallot.method="post"
			window.document.frmworkallot.submit()
		}
		else if  (parent.frames(1).frmforms.hstatus.value=="delete")
		{
			j=parent.frames(1).frmforms.hcnt.value
			if(j=1)
			{
				if(parent.frames(1).frmforms.chkfrm.checked==true)
				{
					varf=parent.frames(1).frmforms.chkfrm.value + "|";
					cnt=cnt+1;
					vara=true;
				} 
			}
        
			if(parent.frames(1).frmforms.chkfrm.length>1)
			{
				for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)
				{
					if(parent.frames(1).frmforms.chkfrm(i).checked==true)
					{
						varf=varf +(parent.frames(1).frmforms.chkfrm(i).value) + "|";
						cnt=cnt+1;
						vara=true;
					}
				}
			}
			if (vara!=true)
			{
				alert('Select any Form....!')
				return
			}
			varb=window.document.frmworkallot.txtbrcode.value 
			varu=window.document.frmworkallot.txtuserid.value
			varm=window.document.frmworkallot.hmodule.value 
			st="delete" + "|" + varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf
			window.document.frmworkallot.hadd.value=st
			window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
			window.document.frmworkallot.method="post"
			window.document.frmworkallot.submit()
		}
	
	
	
 else if  (parent.frames(1).frmforms.hstatus.value=="modify")
 {
  j=parent.frames(1).frmforms.hcnt.value
  if(j=1)
    {
	    if(parent.frames(1).frmforms.chkfrm.checked==true)
		{
			 varf=parent.frames(1).frmforms.chkfrm.value + "|";
			cnt=cnt+1;
			vara=true;
		} 
     }
    
    
  varjj=0;
  varl=""
  varaddval=""
  if(parent.frames(1).frmforms.chkfrm.length>1)
	 {
	    for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)
		{
			if(parent.frames(1).frmforms.chkfrm(i).checked==true)
			{
				varf=varf +(parent.frames(1).frmforms.chkfrm(i).value) + "|";
				varaddval=varaddval+ ",'" + (parent.frames(1).frmforms.chkfrm(i).value)+ "'"
				cnt=cnt+1;
				vara=true;
			}
			else
			{
				varl=varl+"','"+ (parent.frames(1).frmforms.chkfrm(i).value) 
				varjj=varjj+1
			}
		}
		varl=varl.substr(2) + "'|" + varjj
	  }	
	else
	{
		if(parent.frames(1).frmforms.chkfrm.checked==true)
			{
				
				
				varf=varf +(parent.frames(1).frmforms.chkfrm.value) + "|";
				cnt=cnt+1;
				varl="'"+ (parent.frames(1).frmforms.chkfrm.value) +"'|1"
			}
			else
			varl="'"+ (parent.frames(1).frmforms.chkfrm.value) +"'|1"
			vara=true;
	}
	
	
	    if (vara!=true)
	   {
	     alert('Select any Form...!');
	     return
	   } 
			varb=window.document.frmworkallot.txtbrcode.value 
			varu=window.document.frmworkallot.txtuserid.value
			varm=window.document.frmworkallot.hmodule.value 
			st="modify" + "|" +varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf 
			//alert(varaddval)
			window.document.frmworkallot.hadd.value=st 
			window.document.frmworkallot.hmod.value=varl
			window.document.frmworkallot.hmodadd.value=varaddval
			
			window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
			window.document.frmworkallot.method="post"
			window.document.frmworkallot.submit()
			//alert(varl)
	}
	}
else if (window.document.frmworkallot.radgroup(0).checked==true)	
    {
       window.document.frmworkallot.hok.value="groupid"
  if  (parent.frames(1).frmforms.hstatus.value=="add")
   {
   
     j=parent.frames(1).frmforms.hcnt.value
        if(j=1)
    {
        if(parent.frames(1).frmforms.chkfrm.checked==true)
    {
         varf=parent.frames(1).frmforms.chkfrm.value + "|";
         cnt=cnt+1;
         vara=true;
     } 
     }
        
  if(parent.frames(1).frmforms.chkfrm.length>1)
 {
   
        for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)   
    {
	    if(parent.frames(1).frmforms.chkfrm(i).checked==true)
	{
		varf=varf +(parent.frames(1).frmforms.chkfrm(i).value) + "|";
		cnt=cnt+1;
		vara=true;
		
	 }
	}
	}
	if (vara!=true)
	{
	  alert('Select any Form...!');
	   return
	}
	
	varb=window.document.frmworkallot.txtbrcode.value 
	varu=window.document.frmworkallot.txtuserid.value
	varm=window.document.frmworkallot.hmodule.value 
	st="add" + "|" + varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf
	
    window.document.frmworkallot.hadd.value=st
    window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
	window.document.frmworkallot.method="post"
	window.document.frmworkallot.submit()
}
else if  (parent.frames(1).frmforms.hstatus.value=="delete")
{

  j=parent.frames(1).frmforms.hcnt.value
        if(j=1)
    {
        if(parent.frames(1).frmforms.chkfrm.checked==true)
    {
         vatf=parent.frames(1).frmforms.chkfrm.value + "|";
         cnt=cnt+1;
         vara=true;
     } 
     }
        
  if(parent.frames(1).frmforms.chkfrm.length>1)
 {

	for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)
	{
	 if(parent.frames(1).frmforms.chkfrm(i).checked==true)
	  {
	  
	    varf=varf +(parent.frames(1).frmforms.chkfrm(i).value) + "|"
		cnt=cnt+1;
		vara=true;
	  }
	}
	}
	if (vara!=true)
	{
	alert('Select any Form...!')
	return
	}
	varb=window.document.frmworkallot.txtbrcode.value 
	varu=window.document.frmworkallot.txtuserid.value
	varm=window.document.frmworkallot.hmodule.value 
	st="delete" + "|" + varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf
	alert(st)
	window.document.frmworkallot.hadd.value=st
    window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
	window.document.frmworkallot.method="post"
	window.document.frmworkallot.submit()
	}
else  if(parent.frames(1).frmforms.hstatus.value=="modify")
{
	  j=parent.frames(1).frmforms.hcnt.value
        if(j=1)
    {
        if(parent.frames(1).frmforms.chkfrm.checked==true)
    {
         varf=parent.frames(1).frmforms.chkfrm.value + "|";
         cnt=cnt+1;
         vara=true;
     } 
     }
        
  if(parent.frames(1).frmforms.chkfrm.length>1)
 {
	  for(i=0;i<parent.frames(1).frmforms.chkfrm.length;i++)
	{
	  if(parent.frames(1).frmforms.chkfrm(i).checked==true)
	{
	  varf=varf + parent.frames(1).frmforms.chkfrm(i).value + "|";
	  cnt=cnt+1;
	  vara=true;
	}
	}
	}
	   if (vara!=true)
	     {
	       alert('Select any Form...!');
	       return
	      } 
			varb=window.document.frmworkallot.txtbrcode.value 
			varu=window.document.frmworkallot.txtuserid.value
			varm=window.document.frmworkallot.hmodule.value 
			st="modify" + "|" + varb + "|" + varu + "|" + varm + "|" + cnt + "|" + varf
			window.document.frmworkallot.hadd.value=st
			window.document.frmworkallot.action="GenWorkAllotDBOper.aspx"
			window.document.frmworkallot.method="post"
			window.document.frmworkallot.submit()
	}
	}
	}
	
function group()
{

	window.document.all.imod.src="GenWorkAllotModuleID.aspx"
	window.parent.frames(1).frmforms.action="GenWorkAllotFormID.aspx"
	window.parent.frames(1).frmforms.method="post"
	window.parent.frames(1).frmforms.submit()	
		   
   if (window.document.frmworkallot.radgroup(0).checked==true)
    {
     window.document.frmworkallot.lblgr.value="Group Code"
     window.document.frmworkallot.txtuserid.value=""
     window.document.frmworkallot.txtuserdesc.value=""
     window.document.all.iform.src="GenWorkAllotFormID.aspx"
    }
      else
     {
		window.document.frmworkallot.lblgr.value="User Id"
		window.document.frmworkallot.txtuserid.value=""
		window.document.frmworkallot.txtuserdesc.value=""
		window.document.all.iform.src="GenWorkAllotFormID.aspx"
		
     }
    
    
}	
		
 function Cancel(){
  location.href="GenWorkAllotment.aspx"
 //xx()
 }
 
 
 function xx(){
 window.document.all.iform.src="GenWorkAllotFormID.aspx"
 //window.document.all.imod.src="moduleid.aspx"
 yy()
   
 }
  function yy(){
 //window.document.all.iform.src="formid.aspx"
    window.document.all.imod.src="GenWorkAllotModuleID.aspx"
    
 }
 
//-->
</script>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);checkUser();group()">

<form name="frmworkallot">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>work allotment</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>

  <table width="100%" height="450" cellspacing="0" cellpadding="ADMIN0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

  

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" align="center" height="15"><font size="3" face="MS Sans Serif" color="blue"><%=Request.QueryString("record")%></font></td>
        </tr>
        <tr>
          <td width="100%" align="right" height="20" colspan="3">
          <div align="center">
            <center>

            <table border="0" width="86%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="42%" align="right"><font>&nbsp;Branch
                Code&nbsp;&nbsp;</font></td>
                <td width="100%"><input name="txtbrcode" class="txtautofill" size="6" readonly style="TEXT-ALIGN: right" readonly value=<%=session("branchcode")%>><input type="button" value=" L " name="butbranch" class="button" onclick="branch()"><input name="txtbrdesc" size="15" class="bgcolor1" readonly value="<%=session("branchnarration")%>"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" align="right" height="20" colspan="3"><center>
          <div align="center">
            <center>

            <table width="86%" class="tablebordermain">
              <tr>
                <td width="100%">

                <table width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="30%" height="10"></td>
                    <td width="81%" height="10"></td>
                  </tr>
                  <tr>
                    <td width="30%" height="26" align="right"></td>
                    <td width="81%" height="26">

                    <table width="62%" bordercolor="#D9D2B3" cellspacing="0" cellpadding="0" class="tableborder1">
                      <tr class="bgcolor1">
                        <td width="51%" align="center"><font class="textblack">Group Id
                        &nbsp;&nbsp;&nbsp;</font><input type="radio" name="radgroup" id="radgroup" size="6" checked onclick="group()" value="2"></td>
                        <td width="49%" align="center"><font class="textblack">User Id</font><input type="radio" name="radgroup" id="radgroup0" size="15" onclick="group()" value="1"></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                  <tr>
                    <td width="108%" align="right" colspan="2" height="10"></td>
                  </tr>
                </center>
                <tr>
                  <td width="108%" align="right" colspan="2">
                  <div align="center">

                    <table border="0" width="512" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="99" align="right">
                        <p align="center"><input type="checkbox" name="chkABB" value="ON" onclick="Abb()" style="visibility:hidden">
                        &nbsp;</p>
                        </td>
                        <td width="100" align="right">
                        <input name="lblgr" value="Group Code" readonly size="10" class="bgcolor4" style="BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; 
                       BORDER-TOP-STYLE: none; COLOR: black">
                        </td>
                        <td width="50">
                        <td width="270">&nbsp;<input name="txtuserid" class="txtautofill" size="6" onchange="yy()" readonly><input type="button" value=" L " name="butuser" class="button" onclick="User()"><input class="bgcolor1" name="txtuserdesc" size="15" readonly></td>
                        <td width="120">
                        <p align="right"><input type="checkbox" name="chkSelectall" value="ON" onclick="SelectAll()">
                        Select All</td>
                      </tr>
                    </table>

                  </div>
                  </td>
                </tr>
                <center>
                <tr>
                  <td width="108%" align="right" colspan="2" height="10"></td>
                </tr>
                <tr>
                  <td width="102%" align="right" height="22" colspan="2">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="43%" valign="top">
                      <div id="xx" align="right">

                        <table width="90%" class="tableborder2">
                          <tr>
                            <td width="100%" align="right"><iframe id="imod" align=right             
                            frameborder=0 framespacing=0 noresize height=200 width=260
                                
                              src="GenWorkAllotModuleID.aspx"
                                  
                                valign="top" style="BACKGROUND-COLOR: darkred"></iframe></td>
                          </tr>
                        </table>

                      </div>
                      </td>
                      
                      <td width="17%">
                      <div align="center">

                        <table width="15%" class="tablebordermain">
                          <tr>
                            <td width="100%"><input type="button" value="  Add " name="cmdAdd" onclick="mod()" class="button"></td>
                          </tr>
                          <tr>
                            <td width="100%"><input type="button" value="Delete" name="cmddelete" onclick="del()" class="button"></td>
                          </tr>
                          <tr>
                            <td width="100%"><input type="button" value="Query " name="cmdQuery" onclick="query()" class="button"></td>
                          </tr>
                        </table>

                      </div>
                      </td>
                    </center>
                    <td width="40%" valign="top">
                    <div align="left">

                      <table width="96%" class="tableborder2">
                        <tr>
                          <td width="100%" align="left">
                          <p align="right"><iframe id="iform" align=left src="GenWorkAllotFormID.aspx"         
           
                              frameborder=0 framespacing=0 noresize  height=200 width 
                               =285 
                                valign="top" style="BACKGROUND-COLOR: darkred"><center>

                          </iframe></center></td>
                        </tr>
                      </table>

                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="43%" valign="top" height="15"></td>
                    <td width="17%" height="15"></td>
                    <td width="40%" valign="top" height="15"></td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" colspan="3"></td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" colspan="3" height="10"></td>
                  </tr>
                  </table>

                </td>
                </tr>
                </table>

              </td>
            </tr>
            </table>

          </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" align="right" colspan="3" height="10"></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
          <div align="center">
            <center>

            <table border="0" width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="    Ok    " name="cmdok" class="button" onclick="ok()" class="bgcolor"><input type="button" value="Cancel" name="cmdCancel" class="button" onclick="Cancel()" class="button"><input name="cmdexit" class="button" type="button" value="   Exit   " onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;">
                
                </td>
                <table><tr><td height="30" width="100"></td> </tr> </table>
                </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" align="right" colspan="3" height="10">
          <p align="center"></p>
          </td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="hmod" id="hmod"><input type="hidden" name="hadd" id="hadd"><input type="hidden" name="hmodule" id="hmodule"><input type="hidden" name="hopt" id="hopt"><input type="hidden" name="hok" id="hok"><input type="hidden" name="brnar" id="brnar"><input type="hidden" name="brdesc" id="brdesc"><input type="hidden" name="abbuser" id="abbuser">
<input type="hidden" name="hmodadd" id="hmodadd">
<input type="hidden" name="hidabb" id="hidabb">

<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>


<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="GenWorkAllotModuleID.aspx">
          </iframe>
          <IFRAME id="idetails" align=center style="COLOR: #c7ba95;  LEFT: 0px; TOP: 0px; WIDTH: 0px height=0px" 
			height=0 width=0 valign="top"></IFRAME>
          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

</html>
