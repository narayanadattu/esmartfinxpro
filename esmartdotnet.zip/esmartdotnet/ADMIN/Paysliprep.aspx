<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="Paysliprep.aspx.vb" Inherits="eSmartDotNet.Paysliprep" %>

<%

dim strVal,strArr

strhreptype =trim(Request.Form("hreptype"))

if strhreptype = "XL" then
Response.ContentType = "application/vnd.ms-excel" %>
		<% 
		fn = "PaySlip.xls"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & fn) 
end if	

%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>Paysliprep</title>
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <style>.break { page-break-after: always }
    </style>
    
    <script language="vbscript" runat="server">
    
    '' convert to numbers to words
		 
		 ' Function for conversion of a Currency to words 
' Parameter - accept a Currency 
' Returns the number in words format 
'*************************************... 

Function CurrencyToWord(ByVal MyNumber) 
dim intnum2 
Dim Temp 
Dim Rupees, Paisa As String 
Dim DecimalPlace, iCount 
Dim Hundreds, Words As String 
Dim Place(9) As String 
Place(0) = " Thousand " 
Place(2) = " Lakh " 
Place(4) = " Crore " 
Place(6) = " Arab " 
Place(8) = " Kharab " 

On Error Resume Next 
' Convert MyNumber to a string, trimming extra spaces. 
MyNumber = Trim(Str(MyNumber)) 

' Find decimal place. 
DecimalPlace = InStr(MyNumber, ".") 

' If we find decimal place... 
If DecimalPlace > 0 Then 
' Convert Paisa 
Temp = Left(Mid(MyNumber, DecimalPlace + 1) & "00", 2) 
Paisa = " and " & ConvertTens(Temp) & " Paisa" 

' Strip off paisa from remainder to convert. 
MyNumber = Trim(Left(MyNumber, DecimalPlace - 1)) 
End If 

intnum2 = Len(MyNumber)

' Convert last 3 digits of MyNumber to ruppees in word. 
Hundreds = ConvertHundreds(Right(MyNumber, 3)) 
' Strip off last three digits 
MyNumber = Left(MyNumber, Len(MyNumber) - 3) 

iCount = 0 
if intnum2 >  2 then
 
Do While MyNumber <> "" 

'Strip last two digits 
Temp = Right(MyNumber, 2) 
If Len(MyNumber) = 1 Then 
Words = ConvertDigit(Temp) & Place(iCount) & Words 
MyNumber = Left(MyNumber, Len(MyNumber) - 1) 

Else 
Words = ConvertTens(Temp) & Place(iCount) & Words 
MyNumber = Left(MyNumber, Len(MyNumber) - 2) 
End If 
iCount = iCount + 2 
Loop 
end if ''intnum2 >  2

CurrencyToWord = "Rupees " & Words & Hundreds & Paisa & " Only." 
End Function 

' Conversion for hundreds 
'*************************************... 
Private Function ConvertHundreds(ByVal MyNumber) 
Dim Result As String 

' Exit if there is nothing to convert. 
If Val(MyNumber) = 0 Then Exit Function 

' Append leading zeros to number. 
MyNumber = Right("000" & MyNumber, 3) 

' Do we have a hundreds place digit to convert? 
If Left(MyNumber, 1) <> "0" Then 
Result = ConvertDigit(Left(MyNumber, 1)) & " Hundreds " 
End If 

' Do we have a tens place digit to convert? 
If Mid(MyNumber, 2, 1) <> "0" Then 

Result = Result & ConvertTens(Mid(MyNumber, 2)) 
Else 
' If not, then convert the ones place digit. 
Result = Result & ConvertDigit(Mid(MyNumber, 3)) 
End If 

ConvertHundreds = Trim(Result) 
End Function 

' Conversion for tens 
'*************************************... 
Private Function ConvertTens(ByVal MyTens) 
Dim Result As String 

' Is value between 10 and 19? 
If Val(Left(MyTens, 1)) = 1 Then 
Select Case Val(MyTens) 
Case 10: Result = "Ten" 
Case 11: Result = "Eleven" 
Case 12: Result = "Twelve" 
Case 13: Result = "Thirteen" 
Case 14: Result = "Fourteen" 
Case 15: Result = "Fifteen" 
Case 16: Result = "Sixteen" 
Case 17: Result = "Seventeen" 
Case 18: Result = "Eighteen" 
Case 19: Result = "Nineteen" 
Case Else 
End Select 

Else 
' .. otherwise it's between 20 and 99. 
Select Case Val(Left(MyTens, 1)) 
Case 2: Result = "Twenty " 
Case 3: Result = "Thirty " 
Case 4: Result = "Forty " 
Case 5: Result = "Fifty " 
Case 6: Result = "Sixty " 
Case 7: Result = "Seventy " 
Case 8: Result = "Eighty " 
Case 9: Result = "Ninety " 
Case Else 
End Select 

' Convert ones place digit. 
Result = Result & ConvertDigit(Right(MyTens, 1)) 
End If 

ConvertTens = Result 
End Function 

Private Function ConvertDigit(ByVal MyDigit) 
Select Case Val(MyDigit) 
Case 1: ConvertDigit = "One" 
Case 2: ConvertDigit = "Two" 
Case 3: ConvertDigit = "Three" 
Case 4: ConvertDigit = "Four" 
Case 5: ConvertDigit = "Five" 
Case 6: ConvertDigit = "Six" 
Case 7: ConvertDigit = "Seven" 
Case 8: ConvertDigit = "Eight" 
Case 9: ConvertDigit = "Nine" 
Case Else: ConvertDigit = "" 
End Select 
End Function 

</script>
    
    <SCRIPT LANGUAGE=javascript>
	
	function prnt()
	{
	// hide all the buttons from the printing of report
	window.document.frmPayslip.butok.style.visibility="hidden"
	window.document.frmPayslip.butprnt.style.visibility="hidden"
	
	// Print the report 
	window.print()
	window.document.frmPayslip.butok.style.visibility="visible"
	window.document.frmPayslip.butprnt.style.visibility="visible"

	}
	</script>
	<style>
	.button
	{
		background-color: #00803e;
		color: #fff;
		min-width: 80px;
		font-family: 'Arial';
		border-radius: 6px;
		margin: 2px;
		cursor: hand;
	}
	</style>
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<%
		
		
		
		dim rsaddress, objfetch, titFld, titCond, titTab, objfetch1, RecTran
		
		rsaddress=server.CreateObject("adodb.recordset")
		RecTran=server.CreateObject("adodb.recordset")
		
		objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
		objfetch1 =server.CreateObject("ReportPurposeOnly.Reportonly")
	
		branchcode=session("branchcode")
		
		titFld = "a.branchname,a.addr2,a.addr3||','||a.addr4, a.addr5||' '||a.addr6, b.bankname"
		titCond = "a.branchcode='" & trim(branchcode) & "' AND a.bankcode=b.bankcode"
		titTab = "GENBANKBRANCHMST a,GENBANKPARM b"
		rsaddress = objfetch.SingleRecordSet(CStr(titTab), CStr(titFld), CStr(titCond))
		
		dim strMn, strYer, strSelemp, strChk, strQuery
		
		strMn = Request.Form("hidSelmn")
		strYer = Request.Form("hidSelyer")
		strSelemp = Request.Form("hidSelop")
		strChk = Request.Form("hidChk")
		
		if strChk = "0" then
			strQuery = "SELECT a.EMPCODE, a.BASIC, a.DA, a.HRA, a.ALLOWANCE, a.GROSS, a.PF, a.PTAX, a.RD, a.LOAN, a.ADVANCES, a.GIP, a.TDS, a.OTHDEDUC, a.NETPAY, b.EMPNAME, to_char(b.APPOINTDT,'dd-Mon-yyyy') APPOINTDT,  b.branchcode||b.glcode|| lpad(b.ACCNO,7,'0'), c.DESCRIPTION, d.MAILADDRESS1, d.MAILADDRESS2, d.MAILADDRESS3, d.MAILADDRESS4, d.CUSTMOBILE,a.ESI,a.VPF,a.OTHALOW, b.EPFACCNO FROM SALARYPAIDDTLS a ,EMPLOYEEMST b, GENDESIGNATIONMST c, GENCUSTINFOMST d WHERE b.EMPCODE=a.EMPCODE AND c.code=b.DESGNCODE AND d.CUSTOMERID=b.CUSTOMERID AND a.EMPCODE='" & strSelemp & "' AND a.PAIDMONTH='" & strMn & "' AND a.PAIDYEAR='" & strYer & "'"
		else
			strQuery = "SELECT a.EMPCODE, a.BASIC, a.DA, a.HRA, a.ALLOWANCE, a.GROSS, a.PF, a.PTAX, a.RD, a.LOAN, a.ADVANCES, a.GIP, a.TDS, a.OTHDEDUC, a.NETPAY, b.EMPNAME, to_char(b.APPOINTDT,'dd-Mon-yyyy')APPOINTDT,  b.branchcode||b.glcode|| lpad(b.ACCNO,7,'0'), c.DESCRIPTION, d.MAILADDRESS1, d.MAILADDRESS2, d.MAILADDRESS3, d.MAILADDRESS4, d.CUSTMOBILE,a.ESI,a.VPF,a.OTHALOW, b.EPFACCNO FROM SALARYPAIDDTLS a ,EMPLOYEEMST b, GENDESIGNATIONMST c, GENCUSTINFOMST d WHERE b.EMPCODE=a.EMPCODE AND c.code=b.DESGNCODE AND d.CUSTOMERID=b.CUSTOMERID AND a.PAIDMONTH='" & strMn & "' AND a.PAIDYEAR='" & strYer & "' AND b.status='R'"
		end if
		
		RecTran=objfetch1.SingleSelectStat(strQuery)
	
	%>
  </head>
  <body bottommargin="5" topmargin="5" leftmargin="5" rightmargin="5">
	<form name="frmPayslip">
		<table align="center" cellSpacing="0" cellPadding="0" border="0" width="95%">
		<%if RecTran.RecordCount>0 then ''rec count start 
		do until RecTran.EOF
		 %> 
		 
		 <% if kcnt=0 then %>
		<tr>
		</tr>
		<% else %>
		<tr class="break">
		</tr>
		<tr>
		<% end if %>
			<tr>
				<td width="100%"><font color="#000000" face="courier new" size="2"><center>
				<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%><br>
				<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%><br>
				<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%><br>
				<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%><br>
				<br>
				</td>
			</tr>
			<tr>
				<td width="100%">
					<table border="01" width="100%">
						<tr>
							<td width="100%" colspan="4" align="center"><font face="Arial" size="3"><b>Pay Slip For the Month : <%=strMn%> / <%=strYer%></b> </font></td>
						</tr>
						<!--<tr>
							<td width="100%" colspan="4" align="center"><font face="Arial" size="2">Employee Details</font></td>
						</tr> -->
						<tr>
							<td width="10%"><font face="Arial" size="2">Name</font></td>
							<td width="40%"><font face="Arial" size="2"><%=RecTran(15).value%></font></td>
							<td width="15%"><font face="Arial" size="2">Employee No:</font></td>
							<td width="35%"><font face="Arial" size="2"><%=RecTran(0).value%></font></td>
						</tr>
						<% dim stAdd
						
							stAdd = ""
							stAdd1=""
							stAdd2=""
							stAdd3=""
							
							stAdd = RecTran(19).value & "," & RecTran(20).value & "," & RecTran(21).value & "," & RecTran(22).value
							stAdd1 = mid(stAdd,1,30)
							stAdd2 = mid(stAdd,31,60)
							stAdd3 = mid(stAdd,60)
							
						
						%>
						<tr>
							<td width="10%" rowspan="3"><font face="Arial" size="2">Address</font></td>
							<td width="40%" rowspan="3"><font face="Arial" size="2"><%=RecTran(19).value%>,<%=RecTran(20).value%>,<%=RecTran(21).value%>,<%=RecTran(22).value%> </font></td>
							<td width="15%"><font face="Arial" size="2">Designation:</font></td>
							<td width="35%"><font face="Arial" size="2"><%=RecTran(18).value%></font></td>
						</tr>
						<tr>
							<td width="15%"><font face="Arial" size="2">Dat of Join:</font></td>
							<td width="35%"><font face="Arial" size="2"><%=RecTran(16).value%></font></td>
						</tr>
						<tr>
							<td width="15%"><font face="Arial" size="2">UIDNO:</font></td>
							<td width="35%"><font face="Arial" size="2"><%=RecTran(27).value%></font></td>
						</tr>
						<tr>
							<td width="10%"><font face="Arial" size="2">Contact</font></td>
							<td width="40%"><font face="Arial" size="2"><%=RecTran(23).value%></font></td>
							<td width="15%"><font face="Arial" size="2">SB A/C No.</font></td>
							<td width="35%"><font face="Arial" size="2"><%=RecTran(17).value%></font></td>
						</tr>
						<tr>
							<td width="100%" colspan="4"><font color="#000000" face="courier new" size="2">Earning</font></td>
						
						</tr>
						<tr>
							<td width="100%" colspan="4"> 
								<table width="100%" border="0" >
									<tr>
										<td width="17%"><font face="Arial" size="2">Basic</font> </td>
										<td width="17%"><font face="Arial" size="2">DA</font> </td>
										<td width="17%"><font face="Arial" size="2">HRA</font> </td>
										<td width="17%"><font face="Arial" size="2">Allowance</font> </td>
										<td width="16%"><font face="Arial" size="2">Oth Allowance</font> </td>
										<td width="16%"><font face="Arial" size="2">Gross</font> </td>
									</tr>
									<tr>
										<td width="17%"><font face="Arial" size="2"><%=RecTran(1).value%></font> </td>
										<td width="17%"><font face="Arial" size="2"><%=RecTran(2).value%></font> </td>
										<td width="17%"><font face="Arial" size="2"><%=RecTran(3).value%></font> </td>
										<td width="17%"><font face="Arial" size="2"><%=RecTran(4).value%></font> </td>
										<td width="16%"><font face="Arial" size="2"><%=RecTran(26).value%></font> </td>
										<td width="16%"><font face="Arial" size="2"><%=RecTran(5).value%></font> </td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="100%" colspan="4"><font color="#000000" face="courier new" size="2">Deductions</font></td>
						
						</tr>
						<tr>
							<td width="100%" colspan="4"> 
								<table width="100%" border="0" >
									<tr>
										<td width="10%"><font face="Arial" size="2">PF</font> </td>
										<td width="10%"><font face="Arial" size="2">PTax</font> </td>
										<td width="10%"><font face="Arial" size="2">ESI</font> </td>
										<td width="10%"><font face="Arial" size="2">VPF</font> </td>
										<td width="10%"><font face="Arial" size="2">RD</font> </td>
										<td width="10%"><font face="Arial" size="2">Loan</font> </td>
										<td width="10%"><font face="Arial" size="2">ADV</font> </td>
										<td width="10"><font face="Arial" size="2">GIP</font> </td>
										<td width="10%"><font face="Arial" size="2">TDS</font> </td>
										<td width="10%"><font face="Arial" size="2">Oth Ded</font> </td>
									</tr>
									<tr>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(6).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(7).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(24).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(25).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(8).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(9).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(10).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(11).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(12).value%></font> </td>
										<td width="10%"><font face="Arial" size="2"><%=RecTran(13).value%></font> </td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="100%" colspan="4"> </td>
						</tr>
							
						<tr>
							<td width="100%" colspan="4"> 
								<table width="100%" border="0" >
									<tr>
										<td width="33%"><font face="Arial" size="2">Total Earning</font> </td>
										<td width="33%"><font face="Arial" size="2">Total Deduction</font> </td>
										<td width="33%"><font face="Arial" size="2">Net Payment</font> </td>
									</tr>
									<tr>
									<% dim strTotded,strErn
										
										strTotded = 0
										strErn = 0
										
										strTotded = val(RecTran(6).value)+val(RecTran(7).value)+val(RecTran(8).value)+val(RecTran(9).value)+val(RecTran(10).value)+val(RecTran(11).value)+val(RecTran(12).value)+val(RecTran(13).value)+val(RecTran(24).value)+val(RecTran(25).value)
										
										strErn = val(RecTran(5).value)+val(RecTran(26).value)
									
									  %>
										<td width="33%"><font face="Arial" size="2"><%=strErn%></font> </td>
										<td width="33%"><font face="Arial" size="2"><%=strTotded%></font> </td>
										<td width="33%"><font face="Arial" size="2"><%=RecTran(14).value%></font> </td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="25%"><font face="Arial" size="2">Amount In Words</font></td>
							<td width="75%" colspan="3" ><font face="Arial" size="2"> <%=CurrencyToWord(RecTran(14).value)%></font></td>
						</tr>
						
						<tr>
							<td width="100%" colspan="4" ><font face="Arial" size="2"> </font></td>
						</tr>
						<tr>
							<td width="100%" colspan="4" align="left"><font face="Arial" size="1">*This is computer generated pay slip, hence signature not required.</font></td>
						</tr>
						
					</table>
				</td>
			</tr>
		<% 
		
		RecTran.MoveNext
		kcnt=kcnt+1
		loop
		
		else ''else for rectran%>
		
		Response.Redirect ("frmSalgenerate.aspx?record=" & "No Trnsactions Found")
		
		
		<% end if ''end of rectran
		
		RecTran=nothing
		rsaddress=nothing
		objfetch=nothing
		%>	
		</table>
		<table width="650">
			<tr>
				<td align="center"><div id="divPrint"><input type="button" value="  Print   " name="butprnt" onclick="prnt()" class="button"><input type="button" value="   Exit   " name="butok" onclick='location.href="frmSalgenerate.aspx"' class="button"></div>
				</td>
			</tr>
		</table>

    </form>

  </body>
</html>
