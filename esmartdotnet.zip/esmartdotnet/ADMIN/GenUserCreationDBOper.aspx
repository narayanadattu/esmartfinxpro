<%@ Page Language="vb" CodeBehind="GenUserCreationDBOper.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenUserCreationDBOper" %>


<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreationDBOper.ASP									*
'*	Purpose	  	     : A server side page to perform database transactions
'*						for Genusercreation.asp and GenusercreationApprove.asp    	*
'*						            												*
'*							        		*      	                              *
'*		   																			*
'*			                                            							*
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>

<%
'''''' Variables Declaration

dim objfetch
dim objfetch1
dim recrs
dim objdrop
dim strresult
dim branchcode
dim usrname
dim usrid
dim password
dim passwordlifetime
dim useridlifetime
dim passwordlocktime
dim passwordgracetime
dim FailedLoginAttempts
dim biometrics
dim groupid
dim groupname
dim transarray(1,4) ''''' For Database Transactions
dim objTrans
dim status
dim strfldval
dim strfields
dim add1
dim add2
dim city
dim desig
dim email
dim mobileno
dim objmsg
dim strWhere
dim strDataFlds
dim strDataFldVals
dim pwd , nwPsw, nwUsDat, strPw, strUer , i ,strEmp
''''' Values from GENUSERCREATION.ASP

status=Request.Form("status")
branchcode=Request.Form("txtbrcode")
usrname=trim(Request.Form("txtusername"))
usrid=trim(Request.Form("txtuserid"))
password=trim(Request.Form("txtpwd"))
passwordlifetime=trim(Request.Form("txtlifetime"))
passwordlocktime="1"
passwordgracetime=trim(Request.Form("txtgracetime"))
FailedLoginAttempts=trim(Request.Form("txtfailed"))
biometrics=trim(Request.Form("txtbio"))
groupid=trim(Request.Form("txtgrcode"))
groupname=trim(Request.Form("txtgrdesc"))
add1=trim(Request.Form("txtaddress"))
add2=trim(Request.Form("txtaddress1"))
city=trim(Request.Form("txtcity"))
desig=trim(Request.Form("txtdesig"))
email=trim(Request.Form("txtemail"))
macid=trim(Request.Form("txtMacid"))
appdate=session("applicationdate")
machineid=session("machineid")
createduserd=trim(session("userid"))
sessions=trim(Request.Form("txtSessions"))
reason=trim(Request.Form("txtreason"))
accstatus=trim(Request.Form("hidaccstatus"))
empcode=trim(Request.Form("txtempcode"))
abbyn=trim(Request.Form("hidabb"))
useridlifetime=trim(Request.Form("txtUidTime"))
nwPsw = trim(Request.Form("txtNewpsw"))
nwUsDat = trim(Request.Form("txtNewuser"))
strPw = Request.Form("hidPsw")
strUer = Request.Form("hidUsr")
strEmp = trim(Request.Form("txtExpID"))
strmobileno = trim(Request.Form("txtMobileNo"))
strUserDOB = trim(Request.Form("txtuserDOB"))
i = 0

if sessions="" then sessions=0


 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")

 objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")

if status="INSERT" then		'''' If new user has to be created
		
	'	 obj=server.CreateObject("CreateAndAlterUser.DDLTransactions")
	'	''''' Creation of User
	'	strresult=obj.CreateUser(cstr(BranchCode), cstr(UsrName) , cstr(UsrID) , cstr(Password) , cint(PasswordLifeTime) , _
    '             cint(PasswordLockTime), cint(PasswordGraceTime) , cint(FailedLoginAttempts), _
    '              cstr(Biometrics) ,cstr(GroupID) ,cstr(GroupName) )
		
		' New code added by ANIL 23-10-08
		
		strDataFlds="BRANCHCODE,EMPID,EMPPWD,PWDEXPIRYDT,LOCKTIME,GRACETIME,LIFETIME, LOGINATTEMPTS,APPLICATIONDATE,USERID,MACHINEID"
		
		password=trim(Ucase(password))
		pwd=EncodePWD(password, usrid)
		
		strDataFldVals="'" & branchcode & "','" & trim(ucase(usrid))& _
		"','" & pwd &"',to_date('" & appdate & "')+" & trim(passwordlifetime) & "," & cint(PasswordLockTime) &"," & cint(PasswordGraceTime) &"," & cint(PasswordLifeTime) &"," & cint(FailedLoginAttempts) & ",'" & appdate & "','" & createduserd &"','" & machineid & "'"
	
			transarray(0,0)="I"	
			transarray(0,1)="Genpromotionsmst"
			transarray(0,2)=strDataFlds
			transarray(0,3)=strDataFldVals
			transarray(0,4)=""
			
		objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
		if objmsg="Transaction Sucessful." then ''''if database level userid is inserted success fully
		'if strresult="User Created Successfully...!" then  '''' If user is create at database level 
			'''''' Insert the values into GENUSERMST
			strfields="NAME,CREATEDATE,STATUS,SYSTEMDATE,USERID,BRANCHCODE," & _
			"ACCOUNTSTATUS,EXPIRYDATE,BIOMETRICS,GROUPID,GROUPNAME,DESIGNATION," & _
			"ADDRESS,CITY,EMAILID,CREATEDUSERID,MACHINEID,USERMACHINEID," & _
			"NOOFSESSIONS,accountstatusnarration,EMpcode,applicationdate,AbbUserYn,mobileno,userdob"
					
					biometrics=trim(Ucase(biometrics))
					pwd=EncodePWD(trim(biometrics), usrid)
					
			strfldval="'" & ucase(usrname) & "',to_date('" & appdate & _
					"','dd/Mon/yyyy'),'N',sysdate,'" & _
					trim(ucase(usrid)) & "','" & branchcode & "'," & _
					" 'R',to_date('" & appdate & "')+" & _
					trim(useridlifetime) & ",'" & pwd & "','" & _
					trim(groupid) & "','" & trim(groupname) & "'," & _
					" '" & trim(desig) & _
					"','" & trim(add1) & "+}" & _
					trim(add2) & "','" & trim(city) & "','" & trim(email) & "','" & _
			trim(createduserd) & "','" & trim(machineid) & "','" & macid & "'," & _
			cint(sessions) & ",'Running','" & empcode & "','" & appdate & "','" & _
					abbyn & "','"& strmobileno &"','"& strUserDOB &"'"
					
					
			transarray(0,0)="I"	
			transarray(0,1)="Genusermst"
			transarray(0,2)=strfields
			transarray(0,4)=""
			transarray(0,3)=strfldval
			
			'code added by radhika on 05 sep 2008
			'Reason: store oracle profile script too
		'	dim strPorifle
			
		'	strPorifle = "Create profile " & trim(ucase(usrid)) & "profile " & _
		'	" limit sessions_per_user 1  password_reuse_time 18000 " & _ 
		'	" password_reuse_max unlimited Password_lock_time " & cint(PasswordLockTime)& _
		'	" password_grace_time " & cint(PasswordGraceTime) & " password_life_time " & _
		'	cint(PasswordLifeTime) & " failed_login_attempts " & cint(FailedLoginAttempts)
			
		'	transarray(1,0)="I"
		'	transarray(1,1)="GENPROFILESCRIPT"
		'	transarray(1,2)="USERID,SYSTEMDATE,PROFILE"
		'	transarray(1,3)="'" & trim(ucase(usrid)) & "',sysdate,'" & strPorifle & "'"
		'	transarray(1,4)=""
			'end of code added by radhika on 05 sep 2008
		end if
		
elseif status="MODIFY" then  ''''' If to be modify the user information
		'if sessions="" then sessions=0
		strfields="NAME,GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS ," & _
				"CREATEDUSERID,MACHINEID,USERMACHINEID,NOOFSESSIONS,empcode," & _
				"applicationdate,systemdate,AbbuserYn,Branchcode,mobileno,userdob"
		strfldval="'" & ucase(usrname) & "'~'" & trim(groupid) & "'~'" & trim(groupname) & "'~'" & _
				trim(desig) & "'~'" & trim(add1) & "+}" & trim(add2) & "'~'" & trim(city) & "'~'" & trim(email) & "'~'P'~'" & _
				trim(createduserd) & "'~'" & trim(machineid) & "'~'" & trim(macid) & "'~" & cint(sessions) & _
				"~'" & trim(empcode) & "'~'" & appdate & "'~sysdate~'" & abbyn & "'~'" & trim(branchcode) & "'~'" & strmobileno & "'~'" & strUserDOB &"'"
		strWhere="upper(userid)='" & ucase(usrid) & "'"
		transarray(0,0)="U"	
		transarray(0,1)="Genusermst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere
		
		Response.Write (strfldval & "<br>")
		Response.Write (strfields & "<br>")
		'Response.End (strwhere  & "<br>")
		

elseif status="DISABLE" then  ''''' If to be modify the user information

		strfields="accountstatusnarration,accountstatus,MACHINEID,applicationdate,status,systemdate,AbbUserYn"
		strfldval="'" & reason &"'~'" & accstatus & "'~'" & session("machineid") & "'~'" & _
					session("applicationdate") & "'~'P'~sysdate~'" & abbyn & "'"
		strWhere="upper(userid)='" & ucase(usrid) &"'"
		transarray(0,0)="U"	
		transarray(0,1)="Genusermst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere
		
elseif status="DELETE" then  ''''' If mark the user for Deletion

		strfields="STATUS,CREATEDUSERID,MACHINEID,applicationdate,systemdate"
		strfldval="'D'~'" & createduserd & "'~'" & machineid & "'~'" & appdate & "'~sysdate"
		strWhere="upper(userid)='" & ucase(usrid) & "'"
		transarray(0,0)="U"	
		transarray(0,1)="Genusermst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere
elseif status="LOCK" then  ''''' If mark the user for Deletion

		strfields="LOCKEDDATE"
		strfldval="'"& session("ApplicationDate") &"'"
		strWhere="upper(userid)='" & ucase(usrid) & "'"
		
		transarray(0,0)="U"	
		transarray(0,1)="Genusermst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere

elseif status="UNLOCK" then  ''''' If mark the user for Deletion

		strfields="LOCKEDDATE"
		strfldval="NULL"
		strWhere="upper(userid)='" & ucase(usrid) & "'"
		
		transarray(0,0)="U"	
		transarray(0,1)="Genusermst"
		transarray(0,2)=strfields
		transarray(0,3)=strfldval
		transarray(0,4)=strwhere

elseif status="USERPSW" then  ''''' If mark the user for PSW / USER expire 

		if strPw = "PSW" then
			
			strfields="PWDEXPIRYDT"
			strfldval="'" & nwPsw & "'"
			strWhere="upper(EMPID)='" & ucase(strEmp) & "' and upper(branchcode)='" & branchcode & "'"
			
			transarray(i,0)="U"	
			transarray(i,1)="GENPROMOTIONSMST"
			transarray(i,2)=strfields
			transarray(i,3)=strfldval
			transarray(i,4)=strwhere
			
			i = i+1
			
		end if
		
		if strUer = "USER" then 
			
			strfields="EXPIRYDATE"
			strfldval="'" & nwUsDat & "'"
			strWhere="upper(USERID)='" & ucase(strEmp) & "' and upper(branchcode)='" & branchcode & "' "
			
			transarray(i,0)="U"	
			transarray(i,1)="GENUSERMST"
			transarray(i,2)=strfields
			transarray(i,3)=strfldval
			transarray(i,4)=strwhere
			
		end if
		
		
	
elseif status="REJECT" then   '''''' If the user is rejected ( this is from GENUSERCREATIONAPPROVE.aspx)
		
		 recrs=server.CreateObject("adodb.recordset")
		 recrs=objfetch.singlerecordset("genusermsthist", _
				"BRANCHCODE,NAME,EMPCODE,to_char(APPLICATIONDATE,'DD-MON-YYYY'),ACCOUNTSTATUS,LOCKEDDATE,BIOMETRICS," & _
				"GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,MACHINEID," & _
				"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,CREATEDUSERID,Abbuseryn", _
				"userid='" & usrid &"' and rowid=(select max(rowid) from genusermsthist " & _
				"where userid='" & usrid &"')")
		'Response.Write ("genusermsthist" & "   BRANCHCODE,NAME,EMPCODE,APPLICATIONDATE,ACCOUNTSTATUS,LOCKEDDATE,EXPIRYDATE,BIOMETRICS,GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,CREATEDATE,MACHINEID,VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,SYSTEMDATE,CREATEDUSERID"&"    userid='" & usrid &"' and rowid=(select max(rowid) from genusermsthist where userid='" & usrid &"')")
		'if 1=2 then
		if not recrs.eof and not recrs.bof then
			for icount=0 to recrs.fields.count-1
				strflds=strflds & "," & recrs(icount).name
				strvals=strvals & "~'" & recrs(icount).value & "'"
			next
			strflds="BRANCHCODE,NAME,EMPCODE,APPLICATIONDATE,ACCOUNTSTATUS,LOCKEDDATE,BIOMETRICS," & _
				"GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID,STATUS,USERID,MACHINEID," & _
				"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE,CREATEDUSERID,Abbuseryn"
			
			'strflds=right(strflds,len(strflds)-1)
			strvals=right(strvals,len(strvals)-1)
			transarray(0,0)="U"
			transarray(0,1)="GenUSermst"
			transarray(0,2)=strflds
			transarray(0,3)=strvals
			transarray(0,4)="userid='" & usrid &"'"
			objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			Response.Write (objmsg)
		else
			''' new code added by ANIL 24-10-08
			strWhere="upper(userid)='" & ucase(usrid) &"'"
			transarray(0,0)="D"	
			transarray(0,1)="Genusermst"
			transarray(0,2)=""
			transarray(0,3)=""
			transarray(0,4)=strwhere
		
			transarray(1,0)="D"	
			transarray(1,1)="Genpromotionsmst"
			transarray(1,2)=""
			transarray(1,3)=""
			transarray(1,4)="upper(EMPID)='" & ucase(usrid) &"'"
		
		''end of new code
			
			'objdrop= SERVER.CreateObject("CreateAndAlterUser.DDLTransactions")		
			'''' Drop the user
			'objmsg=objdrop.dropuser(cstr(usrid))
			'''' Delete from the genusermst
			
		'	strWhere="upper(userid)='" & ucase(usrid) &"'"
		'	transarray(0,0)="D"	
		'	transarray(0,1)="Genusermst"
		'	transarray(0,2)=""
		'	transarray(0,3)=""
		'	transarray(0,4)=strwhere
			
		'	transarray(1,0)="D"	
		'	transarray(1,1)="GENPROFILESCRIPT"
		'	transarray(1,2)=""
		'	transarray(1,3)=""
		'	transarray(1,4)="upper(userid)='" & ucase(usrid) &"'"
		
		end if
		'end if
elseif status="APPROVE" then  '''''' If the user is approved ( this is from GENUSERCREATIONAPPROVE.aspx)
		'''' Update the status 'A' in genusermst
		 recrs=server.CreateObject("adodb.recordset")
		 recrs=objfetch.singlerecordset("genusermst","userid","status='D' and userid='" & usrid &"'")
		if not recrs.EOF and not recrs.BOF then
			do while not recrs.EOF
				transarray(0,0)="D"	
				transarray(0,1)="Genusermst"
				transarray(0,2)=""
				transarray(0,3)=""
				transarray(0,4)="status='D'"
				recrs.movenext		
			loop
			'objdrop= SERVER.CreateObject("CreateAndAlterUser.DDLTransactions")		
			'''' Drop the user
			'objmsg=objdrop.dropuser(cstr(usrid))
						
			transarray(1,0)="D"	
			transarray(1,1)="GENPROMOTIONSMST"
			transarray(1,2)=""
			transarray(1,3)=""
			transarray(1,4)="upper(EMPID)='" & ucase(usrid) &"'"					
		else
			
			strfields="STATUS,Approvedby,approvedmachine,applicationdate,systemdate"
			strfldval="'A'~'" & ucase(session("userid")) & "'~'" & _
				session("machineid") & "'~'" & appdate & "'~sysdate"
			strWhere="upper(userid)='"& ucase(usrid) &"'"
			recrs=objfetch.singlerecordset("GENBANKPARM","SAMEUSERAPPRYN","")
			if recrs(0).value="Y" then
				recrs=objfetch.singlerecordset("genusermst","CREATEDUSERID",strWhere)
				if recrs(0).value=createduserd then
				objMsg="User creation and Approval With same user doesn't Allowed. Try another user to Approve"
				Response.Redirect ("GenUserCreationapprove.ASPx?record=" & objMsg)
				else
				transarray(0,0)="U"	
				transarray(0,1)="Genusermst"
				transarray(0,2)=strfields
				transarray(0,3)=strfldval
				transarray(0,4)=strwhere
				end if
			elseif recrs(0).value="N" then
			transarray(0,0)="U"	
			transarray(0,1)="Genusermst"
			transarray(0,2)=strfields
			transarray(0,3)=strfldval
			transarray(0,4)=strwhere
			end if
		end if
end if

''''' Execute the transarray 
objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")

if objmsg<>"Transaction Sucessful." then
	if status="INSERT" then
		' objdrop= SERVER.CreateObject("CreateAndAlterUser.DDLTransactions")	
		'objmsg1=objdrop.dropuser(cstr(usrid))
			transarray(0,0)="D"	
			transarray(0,1)="GENPROMOTIONSMST"
			transarray(0,2)=""
			transarray(0,3)=""
			transarray(0,4)="upper(EMPID)='" & ucase(usrid) &"'"
			ObjTrans.DataTransactions(Transarray,,,,,"N")
	end if
end if

Response.Write (strresult)
'''' Redirect it accordingly
If status<>"APPROVE" and status<> "REJECT" then
	strresult = replace(strresult,chr(10)," ")
	strresult = replace(strresult,chr(13)," ")
	Response.Redirect ("GenUserCreation.ASPx?record=" & objMsg & "..." & strresult)
else
	objMsg = replace(objMsg,chr(10)," ")
	objMsg = replace(objMsg,chr(13)," ")
	Response.Redirect ("GenUserCreationapprove.ASPx?record=" & objMsg) 
end if

%>


<script language=vbscript runat=server>

''''''''''''''''''''''''''''''''''''''''''
Function EncodePWD(strPwd, stUserid )
	Dim intcnt, strNpwd, strNuser
    
	'stUserid = UCase(Left(stUserid, 3))
		For intcnt = 1 To Len(strPwd)
			strNpwd = strNpwd & ChartoNum(Mid(strPwd, intcnt, 1))
		Next intcnt
    
		For intcnt = 1 To Len(UCase(Left(stUserid, 3)))
			strNuser = strNuser & ChartoNum(Mid(UCase(Left(stUserid, 3)), intcnt, 1))
		Next intcnt
    
		EncodePWD = strNuser & StrReverse(Mid(strNpwd, 1, Len(strNpwd) / 2)) & Mid(strNpwd, (Len(strNpwd) / 2) + 1)
    
End Function

'Function to Decode Password
Function DecodePWD(strPwd, stUserid )
	Dim intcnt ,strNpwd ,strNuser, strSUser

	strNuser = Left(strPwd, 6)
	strPwd = Mid(strPwd, 7)
	strPwd = StrReverse(Mid(strPwd, 1, Len(strPwd) / 2)) & Mid(strPwd, (Len	(strPwd) / 2) + 1)
	stUserid = Left(stUserid, 3)

		For intcnt = 1 To Len(strPwd)
			strNpwd = strNpwd & NumToChar(Mid(strPwd, intcnt, 2))
			intcnt = intcnt + 1
		Next intcnt
    
		For intcnt = 1 To Len(strNuser)
			 strSUser = strSUser & NumToChar(Mid(strNuser, intcnt, 2))
			intcnt = intcnt + 1
		Next intcnt
           
		DecodePWD = strSUser & strNpwd
End Function

Function ChartoNum(strChar)

	If Left(strChar, 1) = "A" Then ChartoNum = 56
	If Left(strChar, 1) = "B" Then ChartoNum = 18
	If Left(strChar, 1) = "C" Then ChartoNum = 46
	If Left(strChar, 1) = "D" Then ChartoNum = 42
	If Left(strChar, 1) = "E" Then ChartoNum = 55
	If Left(strChar, 1) = "F" Then ChartoNum = 17
	If Left(strChar, 1) = "G" Then ChartoNum = 47
	If Left(strChar, 1) = "H" Then ChartoNum = 57
	If Left(strChar, 1) = "I" Then ChartoNum = 11
	If Left(strChar, 1) = "J" Then ChartoNum = 31
	If Left(strChar, 1) = "K" Then ChartoNum = 65
	If Left(strChar, 1) = "L" Then ChartoNum = 34
	If Left(strChar, 1) = "M" Then ChartoNum = 50
	If Left(strChar, 1) = "N" Then ChartoNum = 23
	If Left(strChar, 1) = "O" Then ChartoNum = 64
	If Left(strChar, 1) = "P" Then ChartoNum = 45
	If Left(strChar, 1) = "Q" Then ChartoNum = 27
	If Left(strChar, 1) = "R" Then ChartoNum = 69
	If Left(strChar, 1) = "S" Then ChartoNum = 52
	If Left(strChar, 1) = "T" Then ChartoNum = 54
	If Left(strChar, 1) = "U" Then ChartoNum = 19
	If Left(strChar, 1) = "V" Then ChartoNum = 36
	If Left(strChar, 1) = "W" Then ChartoNum = 35
	If Left(strChar, 1) = "X" Then ChartoNum = 53
	If Left(strChar, 1) = "Y" Then ChartoNum = 13
	If Left(strChar, 1) = "Z" Then ChartoNum = 14

	If Left(strChar, 1) = "a" Then ChartoNum = 28
	If Left(strChar, 1) = "b" Then ChartoNum = 38
	If Left(strChar, 1) = "c" Then ChartoNum = 39
	If Left(strChar, 1) = "d" Then ChartoNum = 24
	If Left(strChar, 1) = "e" Then ChartoNum = 58
	If Left(strChar, 1) = "f" Then ChartoNum = 33
	If Left(strChar, 1) = "g" Then ChartoNum = 60
	If Left(strChar, 1) = "h" Then ChartoNum = 44
	If Left(strChar, 1) = "i" Then ChartoNum = 16
	If Left(strChar, 1) = "j" Then ChartoNum = 48
	If Left(strChar, 1) = "k" Then ChartoNum = 15
	If Left(strChar, 1) = "l" Then ChartoNum = 59
	If Left(strChar, 1) = "m" Then ChartoNum = 30
	If Left(strChar, 1) = "n" Then ChartoNum = 21
	If Left(strChar, 1) = "o" Then ChartoNum = 32
	If Left(strChar, 1) = "p" Then ChartoNum = 70
	If Left(strChar, 1) = "q" Then ChartoNum = 72
	If Left(strChar, 1) = "r" Then ChartoNum = 68
	If Left(strChar, 1) = "s" Then ChartoNum = 29
	If Left(strChar, 1) = "t" Then ChartoNum = 61
	If Left(strChar, 1) = "u" Then ChartoNum = 37
	If Left(strChar, 1) = "v" Then ChartoNum = 51
	If Left(strChar, 1) = "w" Then ChartoNum = 25
	If Left(strChar, 1) = "x" Then ChartoNum = 43
	If Left(strChar, 1) = "y" Then ChartoNum = 67
	If Left(strChar, 1) = "z" Then ChartoNum = 26


	If Left(strChar, 1) = "1" Then ChartoNum = 62
	If Left(strChar, 1) = "2" Then ChartoNum = 20
	If Left(strChar, 1) = "3" Then ChartoNum = 63
	If Left(strChar, 1) = "4" Then ChartoNum = 40
	If Left(strChar, 1) = "5" Then ChartoNum = 66
	If Left(strChar, 1) = "6" Then ChartoNum = 22
	If Left(strChar, 1) = "7" Then ChartoNum = 12
	If Left(strChar, 1) = "8" Then ChartoNum = 49
	If Left(strChar, 1) = "9" Then ChartoNum = 71
	If Left(strChar, 1) = "0" Then ChartoNum = 41
End Function



Function NumToChar(intNum )
	If intNum=nothing Then NumToChar = ""

	If Val(intNum) = 56 Then NumToChar = "A"
	If Val(intNum) = 18 Then NumToChar = "B"
	If Val(intNum) = 46 Then NumToChar = "C"
	If Val(intNum) = 42 Then NumToChar = "D"
	If Val(intNum) = 55 Then NumToChar = "E"
	If Val(intNum) = 17 Then NumToChar = "F"
	If Val(intNum) = 47 Then NumToChar = "G"
	If Val(intNum) = 57 Then NumToChar = "H"
	If Val(intNum) = 11 Then NumToChar = "I"
	If Val(intNum) = 31 Then NumToChar = "J"
	If Val(intNum) = 65 Then NumToChar = "K"
	If Val(intNum) = 34 Then NumToChar = "L"
	If Val(intNum) = 50 Then NumToChar = "M"
	If Val(intNum) = 23 Then NumToChar = "N"
	If Val(intNum) = 64 Then NumToChar = "O"
	If Val(intNum) = 45 Then NumToChar = "P"
	If Val(intNum) = 27 Then NumToChar = "Q"
	If Val(intNum) = 69 Then NumToChar = "R"
	If Val(intNum) = 52 Then NumToChar = "S"
	If Val(intNum) = 54 Then NumToChar = "T"
	If Val(intNum) = 19 Then NumToChar = "U"
	If Val(intNum) = 36 Then NumToChar = "V"
	If Val(intNum) = 35 Then NumToChar = "W"
	If Val(intNum) = 53 Then NumToChar = "X"
	If Val(intNum) = 13 Then NumToChar = "Y"
	If Val(intNum) = 14 Then NumToChar = "Z"

	If Val(intNum) = 28 Then NumToChar = "a"
	If Val(intNum) = 38 Then NumToChar = "b"
	If Val(intNum) = 39 Then NumToChar = "c"
	If Val(intNum) = 24 Then NumToChar = "d"
	If Val(intNum) = 58 Then NumToChar = "e"
	If Val(intNum) = 33 Then NumToChar = "f"
	If Val(intNum) = 60 Then NumToChar = "g"
	If Val(intNum) = 44 Then NumToChar = "h"
	If Val(intNum) = 16 Then NumToChar = "i"
	If Val(intNum) = 48 Then NumToChar = "j"
	If Val(intNum) = 15 Then NumToChar = "k"
	If Val(intNum) = 59 Then NumToChar = "l"
	If Val(intNum) = 30 Then NumToChar = "m"
	If Val(intNum) = 21 Then NumToChar = "n"
	If Val(intNum) = 32 Then NumToChar = "o"
	If Val(intNum) = 70 Then NumToChar = "p"
	If Val(intNum) = 72 Then NumToChar = "q"
	If Val(intNum) = 68 Then NumToChar = "r"
	If Val(intNum) = 29 Then NumToChar = "s"
	If Val(intNum) = 61 Then NumToChar = "t"
	If Val(intNum) = 37 Then NumToChar = "u"
	If Val(intNum) = 51 Then NumToChar = "v"
	If Val(intNum) = 25 Then NumToChar = "w"
	If Val(intNum) = 43 Then NumToChar = "x"
	If Val(intNum) = 67 Then NumToChar = "y"
	If Val(intNum) = 26 Then NumToChar = "z"

	If Val(intNum) = 62 Then NumToChar = "1"
	If Val(intNum) = 20 Then NumToChar = "2"
	If Val(intNum) = 63 Then NumToChar = "3"
	If Val(intNum) = 40 Then NumToChar = "4"
	If Val(intNum) = 66 Then NumToChar = "5"
	If Val(intNum) = 22 Then NumToChar = "6"
	If Val(intNum) = 12 Then NumToChar = "7"
	If Val(intNum) = 49 Then NumToChar = "8"
	If Val(intNum) = 71 Then NumToChar = "9"
	If Val(intNum) = 41 Then NumToChar = "0"

End Function
''''''''''''''''''''''''''''''''''''''''''

</script>