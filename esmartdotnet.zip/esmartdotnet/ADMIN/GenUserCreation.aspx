<%@ Page Language="vb" CodeBehind="GenUserCreation.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenUserCreation" %>

<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>


<%
abb=session("Abbuser")%>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>User Creation Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff1=getDateDiff(window.document.frmUserCreation.txtNewpsw.value,window.document.frmUserCreation.txtOldpsw.value)
			
			if(intDiff1<0)
			{
				if(window.document.frmUserCreation.txtOldpsw.value=="")
				{
					alert("Old PSW Date Should Not be Null")
					window.document.frmUserCreation.txtOldpsw.focus()
				}
				
				alert("New PSW Date Should Not be Less Than Old PSW Date.")
				window.document.frmUserCreation.txtNewpsw.value=""
				window.document.frmUserCreation.txtNewpsw.focus()
			}
			
			var intDiff2=getDateDiff(window.document.frmUserCreation.txtNewuser.value,window.document.frmUserCreation.txtOlduser.value)
			
			if(intDiff2<0)
			{
				if(window.document.frmUserCreation.txtOlduser.value=="")
				{
					alert("Old User Date Should Not be Null")
					window.document.frmUserCreation.txtOlduser.focus()
				}
				
				alert("New User Date Should Not be Less Than Old User  Date.")
				window.document.frmUserCreation.txtNewuser.value=""
				window.document.frmUserCreation.txtNewuser.focus()
			}
			
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
</script>		
<SCRIPT LANGUAGE=javascript>
<!--
///// this function restricts the length of text area : Reason
function restrictLength()
{
if (window.document.frmUserCreation.txtreason.value.length>=99)
	window.event.keyCode=0
}
/// this function is called when Ok button is pressed
function Ok()
{
if(window.document.frmUserCreation.opt1(0).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="INSERT"
	//// CheckNull() function returns False then return the control
	if (CheckNull()==false)
	return
	Insert() //// Call Insert()
}
if(window.document.frmUserCreation.opt1(1).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="MODIFY"
	//// CheckNull() function returns False then return the control
	if (CheckNull()==false)
		return
	Modify()	/// Call Modify()
}
if(window.document.frmUserCreation.opt1(4).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="DISABLE"
	//// CheckNull() function returns False then return the control
	Disable()	/// Call Disable()
}
if(window.document.frmUserCreation.opt1(2).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="DELETE"
	//// CheckNull() function returns False then return the control
	if (CheckNull()==false)
		return
	Delete() ///// Call Delete()
}

if(window.document.frmUserCreation.opt1(5).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="LOCK"
	//// CheckNull() function returns False then return the control
	Lock() ///// Call Lock()
}
if(window.document.frmUserCreation.opt1(6).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="UNLOCK"
		
	UNLock() ///// Call Lock()
}
if(window.document.frmUserCreation.opt1(7).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmUserCreation.status.value="USERPSW"
		
	Uspsw() ///// User Psw()
}
}

function DispMacid()
{
if(window.document.frmUserCreation.chkmacid.checked==true)
	{
	window.document.all.spmacid.style.display="block"
	window.document.frmUserCreation.txtMacid.style.visibility="visible"
	window.document.frmUserCreation.cmdMachine.style.visibility="visible"
	}
else if(window.document.frmUserCreation.chkmacid.checked==false)
	{
	window.document.all.spmacid.style.display="none"
	window.document.frmUserCreation.txtMacid.style.visibility="hidden"
	window.document.frmUserCreation.cmdMachine.style.visibility="hidden"
	}
	window.document.frmUserCreation.txtMacid.value=""
}

function Abbcheck()
{
var abb="<%=abb%>"
if (abb=="Y")
	window.document.frmUserCreation.cmdbranch.disabled=false
else
	window.document.frmUserCreation.cmdbranch.disabled=true


}

function UName()
{
if(window.document.frmUserCreation.txtUserName.value=="")
	return

if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}	
}

function Uid()
{
if(window.document.frmUserCreation.txtUserID.value=="")
	return
if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	

str = new String()
str=window.document.frmUserCreation.txtUserID.value	
if(str.length<5)
{
	alert("User Id Should have Minimum of Five Characters")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	
F_UsrChk=1
Gendisplay()
defaultpwds()
CheckSpace()
}
function defaultpwds()
{
window.document.frmUserCreation.txtpwd.value=window.document.frmUserCreation.txtUserID.value + "1"
window.document.frmUserCreation.txtBio.value=window.document.frmUserCreation.txtUserID.value + "2"
}
var F_UsrChk
F_UsrChk=0

function Pwd()
{

if(window.document.frmUserCreation.txtpwd.value=="")
	return
if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	
if(window.document.frmUserCreation.txtUserID.value=="")
{
	alert("Select User ID")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	

str = new String()
str=window.document.frmUserCreation.txtpwd.value	
if(str.length<6)
{
	alert("Password Should have Minimum of Six Characters")
	window.document.frmUserCreation.txtpwd.focus()
	return
}	
pwdCheck("pwd")
}

function bio()
{
if(window.document.frmUserCreation.txtBio.value=="")
	return

if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	
if(window.document.frmUserCreation.txtUserID.value=="")
{
	alert("Select User ID")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	
if(window.document.frmUserCreation.txtpwd.value=="")
{
	alert("Select Password")
	window.document.frmUserCreation.txtpwd.focus()
	return
}	

str = new String()
str=window.document.frmUserCreation.txtBio.value	
if(str.length<6)
{
	alert("Second Password Should have Minimum of Six Characters")
	window.document.frmUserCreation.txtBio.focus()
	return
}	
pwdCheck("bio")
}

function pwdCheck(str)
{
	var kstr,i,cntCh,cntNo
	
	cntCh=0
	cntNo=0
	
	kstr = new String()
	
	if (str=="pwd")
		kstr = window.document.frmUserCreation.txtpwd.value
	else if (str=="bio")
		kstr = window.document.frmUserCreation.txtBio.value
	
	for(i=0;i<kstr.length;i++) 
	{
	//alert(kstr.charCodeAt(i))
	
	if(((kstr.charCodeAt(i)>=65) && (kstr.charCodeAt(i)<=90))||
		((kstr.charCodeAt(i)>=97) && (kstr.charCodeAt(i)<=122)))
		cntCh=cntCh+1
		
	if((kstr.charCodeAt(i)>=48) && (kstr.charCodeAt(i)<=57))	
		cntNo=cntNo+1
	//48-57 0-9
	//97-122 a-z
	}
	
	if(cntCh==0)
	{
		alert("Atleast One Character is Required")
		
		if (str=="pwd")
			window.document.frmUserCreation.txtpwd.focus()
		else if (str=="bio")
			window.document.frmUserCreation.txtBio.focus()
		
		return
	}
	
	if(cntNo==0)
	{
		alert("Atleast One Number is Required")
		
		if (str=="pwd")
			window.document.frmUserCreation.txtpwd.focus()
		else if (str=="bio")
			window.document.frmUserCreation.txtBio.focus()
		
		return
	}
	
	
	
}
function des()
{
if(window.document.frmUserCreation.txtDesig.value=="")
	return

if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	
if(window.document.frmUserCreation.txtUserID.value=="")
{
	alert("Select User ID")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	
if(window.document.frmUserCreation.opt1(0).checked==false)
	return
if(window.document.frmUserCreation.txtpwd.value=="")
{
	alert("Select Password")
	window.document.frmUserCreation.txtpwd.focus()
	return
}	
if(window.document.frmUserCreation.txtBio.value=="")
{
	alert("Select Second Password")
	window.document.frmUserCreation.txtBio.focus()
	return
}	
}

function Addr()
{
if(window.document.frmUserCreation.txtAddress.value=="")
	return

if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	
if(window.document.frmUserCreation.txtUserID.value=="")
{
	alert("Select User ID")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	
if(window.document.frmUserCreation.opt1(0).checked==true)
{
if(window.document.frmUserCreation.txtpwd.value=="")
{
	alert("Select Password")
	window.document.frmUserCreation.txtpwd.focus()
	return
}	
if(window.document.frmUserCreation.txtBio.value=="")
{
	alert("Select Second Password")
	window.document.frmUserCreation.txtBio.focus()
	return
}
}	
if(window.document.frmUserCreation.txtDesig.value=="")
{
	alert("Select Designation")
	window.document.frmUserCreation.txtDesig.focus()
	return
}	
}

function city()
{
if(window.document.frmUserCreation.txtCity.value=="")
	return

if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.txtUserName.value=="")
{
	alert("Select User Name")
	window.document.frmUserCreation.txtUserName.focus()
	return
}	
if(window.document.frmUserCreation.txtUserID.value=="")
{
	alert("Select User ID")
	window.document.frmUserCreation.txtUserID.focus()
	return
}	
if(window.document.frmUserCreation.opt1(0).checked==true)
{
if(window.document.frmUserCreation.txtpwd.value=="")
{
	alert("Select Password")
	window.document.frmUserCreation.txtpwd.focus()
	return
}	
if(window.document.frmUserCreation.txtBio.value=="")
{
	alert("Select Second Password")
	window.document.frmUserCreation.txtBio.focus()
	return
}	
}
if(window.document.frmUserCreation.txtDesig.value=="")
{
	alert("Select Designation")
	window.document.frmUserCreation.txtDesig.focus()
	return
}	
if(window.document.frmUserCreation.txtAddress.value=="")
{
	alert("Select Address")
	window.document.frmUserCreation.txtAddress.focus()
	return
}		
}

function Check()
{
	if(window.document.frmUserCreation.txtGrcode.value=="")
	{
		window.document.frmUserCreation.opt1(0).checked=true
		alert("Select Group Code")
		window.document.frmUserCreation.cmdGroup.focus()
		return
	}
	if(window.document.frmUserCreation.txtUserName.value=="")
	{
		alert("Select User Name")
		window.document.frmUserCreation.txtUserName.focus()
		return
	}	
	if(window.document.frmUserCreation.txtUserID.value=="")
	{
		alert("Select User ID")
		window.document.frmUserCreation.txtUserID.focus()
		return
	}	
	if(window.document.frmUserCreation.opt1(0).checked==true)
	{	
	if(window.document.frmUserCreation.txtpwd.value=="")
	{
		alert("Select Password")
		window.document.frmUserCreation.txtpwd.focus()
		return
	}	
	if(window.document.frmUserCreation.txtBio.value=="")
	{
		alert("Select Second Password")
		window.document.frmUserCreation.txtBio.focus()
		return
	}
	}	
	if(window.document.frmUserCreation.txtDesig.value=="")
	{
		alert("Select Designation")
		window.document.frmUserCreation.txtDesig.focus()
		return
	}	
	if(window.document.frmUserCreation.txtAddress.value=="")
	{
		alert("Select Address")
		window.document.frmUserCreation.txtAddress.focus()
		return
	}		
	if(window.document.frmUserCreation.txtCity.value=="")
	{
		alert("Select City")
		window.document.frmUserCreation.txtCity.focus()
		return
	}
}


//// This fucntion is called when any of the option buttons clicked to set the status
function New()
{
if(window.document.frmUserCreation.txtGrcode.value=="")
{
	window.document.frmUserCreation.opt1(0).checked=true
	alert("Select Group Code")
	window.document.frmUserCreation.cmdGroup.focus()
	return
}
if(window.document.frmUserCreation.opt1(0).checked==true)
{
	//// if new is clicked
	/// Make visible the user profile division
	window.document.frmUserCreation.all.profilediv.style.display="block"	
	//// Enable all other required fields
	window.document.frmUserCreation.txtAddress.disabled=false
	window.document.frmUserCreation.txtAddress1.disabled=false
	window.document.frmUserCreation.txtCity.disabled=false
	window.document.frmUserCreation.txtDesig.disabled=false
	window.document.frmUserCreation.txtEmail.disabled=false
	window.document.frmUserCreation.txtUserName.disabled=false
	window.document.frmUserCreation.txtUserID.disabled=false 
	window.document.frmUserCreation.txtBio.disabled=false 
	window.document.frmUserCreation.txtpwd.disabled=false 
	window.document.frmUserCreation.cmdMachine.disabled=false 
	//window.document.frmUserCreation.cmdbranch.disabled=false
	/// Clear the fields
	Clear()

}
else
{
	/// Clear the fields
	
	Clear()
	/// Call list page
	
	QueryList()	
	//// Disable branchlist button
	//window.document.frmUserCreation.cmdbranch.disabled=false
	
}
}

/// To clear All the required fields
function Clear()
{
	window.document.frmUserCreation.txtAddress.value=""
	window.document.frmUserCreation.txtAddress1.value=""
	window.document.frmUserCreation.txtCity.value=""
	window.document.frmUserCreation.txtDesig.value=""
	window.document.frmUserCreation.txtEmail.value=""
	window.document.frmUserCreation.txtUserName.value=""
	window.document.frmUserCreation.txtEmpcode.value=""
	window.document.frmUserCreation.txtUserID.value=""
	window.document.frmUserCreation.txtBio.value=""
	window.document.frmUserCreation.txtpwd.value=""
	window.document.frmUserCreation.txtMacid.value=""
	window.document.frmUserCreation.txtExpName.value=""
	window.document.frmUserCreation.txtExpID.value=""
	window.document.frmUserCreation.txtOldpsw.value=""
	window.document.frmUserCreation.txtNewpsw.value=""
	window.document.frmUserCreation.txtOlduser.value=""
	window.document.frmUserCreation.txtNewuser.value=""
	
	DispMacid()
}

//// this fucntion is called when Machine iP list button is pressed
function Machine()
{   
	// send Branch string to LIST.asp
	if(window.document.frmUserCreation.txtBrcode.value=="")
		{
			alert("Branch Code can not be null..")
			return		
		}
	st="Machine|"+
		window.document.frmUserCreation.txtBrcode.value
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function MachineIp(kstr)
{
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
			  window.document.frmUserCreation.txtMacid.value=kstr[1]
			
}

//// this fucntion is called when branch list button is pressed
function branch()
{   
	// send Branch string to LIST.asp
	st="Branch"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Branchid(kstr)
{
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
		  window.document.frmUserCreation.txtBrdesc.value=kstr[0]
		  window.document.frmUserCreation.txtBrcode.value=kstr[1]
			
}


// to check Nulls
// this function returns FALSE value if any null is there

function CheckNull()
{
		
		if(window.document.frmUserCreation.status.value=="INSERT")
		{
		if((window.document.frmUserCreation.txtUserName.value =="")||
		(window.document.frmUserCreation.txtUserID.value =="") || 
		(window.document.frmUserCreation.txtpwd.value=="") || 
		(window.document.frmUserCreation.txtBio.value=="") ||
		(window.document.frmUserCreation.txtEmpcode.value=="") ||
		(window.document.frmUserCreation.txtDesig.value=="") || 
		(window.document.frmUserCreation.txtAddress.value=="") || 
		(window.document.frmUserCreation.txtCity.value=="")|| 
		(window.document.frmUserCreation.txtFailed.value=="") || 
		(window.document.frmUserCreation.txtLifeTime.value=="")||
		(window.document.frmUserCreation.txtGraceTime.value=="")||
		(window.document.frmUserCreation.txtGrcode.value=="")||
		(window.document.frmUserCreation.txtUidTime.value==""))
		{
				window.alert("Fields Should not be Empty...!")
				window.document.frmUserCreation.txtUserName.focus 
				return false
		}
		}
		else
		{
		if((window.document.frmUserCreation.txtUserName.value =="")||
		(window.document.frmUserCreation.txtUserID.value =="") ||
		(window.document.frmUserCreation.txtDesig.value=="") || 
		(window.document.frmUserCreation.txtEmpcode.value=="") || 
		(window.document.frmUserCreation.txtAddress.value=="") || 
		(window.document.frmUserCreation.txtCity.value==""))
		{
				window.alert("Fields Should not be Empty...!")
				window.document.frmUserCreation.txtUserName.focus 
				return false
		}
		}
		
		if(window.document.frmUserCreation.status.value=="INSERT")
		{
			if(window.document.frmUserCreation.txtUserID.value.toUpperCase() == 
			   window.document.frmUserCreation.txtpwd.value.toUpperCase())
			{
			   alert("Password should not be same as User Id")
			   return false
			}          
		}
	
}


// to check any Space is given in userid
// this function not allows spaces
function CheckSpace()
{
var indx
indx=window.document.frmUserCreation.txtUserID.value.indexOf(" ") // Take the index of space
if (indx!=-1)  // if any space is there
	{
	window.document.frmUserCreation.txtpwd.value=""
	window.document.frmUserCreation.txtBio.value=""
	alert ("Space is not allowed...!")
	window.document.frmUserCreation.txtUserID.focus()
	return true 
	}
}


// to check for "@" and "." symbols in email id
function Checksymbols() 
{
var indx
var indy
	
	if (window.document.frmUserCreation.txtEmail.value!="")
	{
	///get  the number of @ symbols
	indx=window.document.frmUserCreation.txtEmail.value.split("@")
	///get  the number of . symbols
	indy=window.document.frmUserCreation.txtEmail.value.split(".")
	
	if ((indx.length>2)||(indy.length>3)) // if more than required found return an error message
		{
			alert ("Enter valid mailid...!")
			window.document.frmUserCreation.txtEmail.focus() 
			return
		}
	/// get the position of "."
	indy=window.document.frmUserCreation.txtEmail.value.lastIndexOf(".")
	/// get the length of mail id
	indx=window.document.frmUserCreation.txtEmail.value.length
	// if "." is in the begining of mail id return error
	
	if(indy==indx-1) 
		{
			alert ("Enter valid mailid...!")
			window.document.frmUserCreation.txtEmail.focus() 
			return
		}
	indx=window.document.frmUserCreation.txtEmail.value.indexOf("@") // Take the index of "@"
	
	if ((indx==-1)||(indx==0))  // if "@" is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmUserCreation.txtEmail.focus() 
			return
		}
	indy=window.document.frmUserCreation.txtEmail.value.indexOf(".") // Take the index of "."
	
	if ((indx==-1)||(indx==0))  // if "." is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmUserCreation.txtEmail.focus() 
			return
		}
	//// if "." found before "@" then return error
	
	if (indy==indx+1)
		{
			alert ("Enter valid mailid...!")
			window.document.frmUserCreation.txtEmail.focus() 
			return
		}
	}
}


/// is called when group list button is selected
function GroupList()
{
	// send User string to LIST.ASP to get the users list
	st="Group"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")

}

/// to display the selected group from the group list
function DisplayGroup(kstr)

{
		if (kstr=="No Data Found...")
		return
		// assing the selected values to textboxes from users list
		assign(kstr,window.document.frmUserCreation.txtGrdesc,window.document.frmUserCreation.txtGrcode )
		window.document.frmUserCreation.txtSessions.value=""
		if(window.document.frmUserCreation.txtGrcode.value=="ADMIN")
			{
			window.document.all.spsessions.style.display="block"
			window.document.frmUserCreation.txtSessions.style.visibility="visible"
			}
		else
			{
			window.document.all.spsessions.style.display="none"
			window.document.frmUserCreation.txtSessions.style.visibility="hidden"
			}
		//window.document.frmUserCreation.txtDesig.value=window.document.frmUserCreation.txtGrdesc.value 

}

function AbbCheck()
{
if(window.document.frmUserCreation.chkAbb.checked==true)
	window.document.frmUserCreation.hidAbb.value="Y"
else
	window.document.frmUserCreation.hidAbb.value="N"
}



//****************calling this fuction on click of  cmdInsert button to call the Asp Page
// ***************to insert the values in datatbase
function Insert()
{
	window.document.frmUserCreation.status.value="INSERT"
	window.document.frmUserCreation.action="GenUserCreationDBOper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
}


//****************calling this fuction onclick of cmdModify button to call the Asp Page
// ***************to modify the values in datatbase
function Modify()
{
	window.document.frmUserCreation.status.value="MODIFY"
	if (CheckNull()==false)
		return
	window.document.frmUserCreation.txtpwd.disabled=true
	window.document.frmUserCreation.txtBio.disabled=true
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.action="GenUserCreationDBOper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
	
	
}

function Disable()
{
	window.document.frmUserCreation.status.value="DISABLE"
	if(window.document.frmUserCreation.txtreason.value=="")
		{
		alert("Reason can not be null..")
		return
		}
	if(window.document.frmUserCreation.chkdisable.checked==true)
		window.document.frmUserCreation.hidaccstatus.value="D"
	else
		window.document.frmUserCreation.hidaccstatus.value="R"
	
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.action="GenUserCreationDBOper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
	
}

//****************calling this fuction onclick of cmdDelete button to call the Asp Page
// ***************to delete the values in datatbase
function Delete()
{
	window.document.frmUserCreation.status.value="DELETE"
	if (CheckNull()==false)
		return
	
	//window.document.frmUserCreation.cmdbranch.disabled=false
	window.document.frmUserCreation.cmdGroup.disabled=false
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.action="GenUserCreationDBoper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
	
}
function Lock() 
{
	window.document.frmUserCreation.status.value="LOCK"
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.action="GenUserCreationDBoper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
}
function UNLock() 
{
	window.document.frmUserCreation.status.value="UNLOCK"
	window.document.frmUserCreation.txtUserID.disabled=false
	window.document.frmUserCreation.action="GenUserCreationDBoper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
}
function Uspsw()
{
	window.document.frmUserCreation.status.value="USERPSW"
	
	if(window.document.frmUserCreation.txtNewpsw.value!="")
	{
		window.document.frmUserCreation.hidPsw.value="PSW"
	}
	if(window.document.frmUserCreation.txtNewuser.value!="")
	{
		window.document.frmUserCreation.hidUsr.value="USER"
	}	
	
	window.document.frmUserCreation.action="GenUserCreationDBoper.ASPx"
	window.document.frmUserCreation.method="post"
	window.document.frmUserCreation.submit();
}
// Refresh the contents of screen
function Cancel()
{
location.href ="GenUserCreation.aspx"
}

// To get the users list 
function Gendisplay()
{
	st=window.document.frmUserCreation.txtUserID.value 
	window.document.all['iBatch'].src="GenUserDetails.aspx?st="+st 
}

// This function displays the information of selected user from the users list

function GenDisp(kstr)
  {
   var Str1
	
	if(F_UsrChk==1)
	{	
		F_UsrChk=0
		
		if(kstr!="")
		{
			alert(window.document.frmUserCreation.txtUserID.value  + " Is Already Available")
			window.document.frmUserCreation.txtUserID.focus()
		}
		return
	}
 
 // Splits the information on basis of "+}"
  Str1=kstr.split("+}")

  window.document.frmUserCreation.txtBrcode.value=Str1[0]
  window.document.frmUserCreation.txtGrcode.value=Str1[2]
  window.document.frmUserCreation.txtGrdesc.value=Str1[3]
  window.document.frmUserCreation.txtDesig.value=Str1[4]
  window.document.frmUserCreation.txtAddress.value=Str1[5]
  window.document.frmUserCreation .txtAddress1.value=Str1[6]
  window.document.frmUserCreation.txtCity.value=Str1[7]
  window.document.frmUserCreation.txtEmail.value=Str1[8]
  window.document.frmUserCreation.txtMobileNo.value = Str1[15]
  window.document.frmUserCreation.txtuserDOB.value = Str1[16]
  if(Str1[9].length>2)
	window.document.frmUserCreation.chkmacid.checked=true
  else
	window.document.frmUserCreation.chkmacid.checked=false
 

  
  window.document.frmUserCreation.txtSessions.value=Str1[10]
  window.document.frmUserCreation.txtBrdesc.value=Str1[16]
  
  if(Str1[14]=="Y")
	window.document.frmUserCreation.chkAbb.checked=true
  else
	window.document.frmUserCreation.chkAbb.checked=false
  
  DispMacid()
  window.document.frmUserCreation.txtMacid.value=Str1[9]
  window.document.frmUserCreation.txtreason.value=Str1[11]
  
  window.document.frmUserCreation.txtEmpcode.value=Str1[13]
  if(Str1[10]=="R")
	window.document.frmUserCreation.chkdisable.checked=false
  else
	window.document.frmUserCreation.chkdisable.checked=true
	
  if(window.document.frmUserCreation.txtGrcode.value=="ADMIN")
	{
		window.document.all.spsessions.style.display="block"
		window.document.frmUserCreation.txtSessions.style.visibility="visible"
	}
	else
	{
		window.document.all.spsessions.style.display="none"
		window.document.frmUserCreation.txtSessions.style.visibility="hidden"
	}
  }



function QueryList()
{
	// Enable or disable the textboxes and command buttons accordingly
	
	window.document.frmUserCreation.all.profilediv.style.display="None"
	window.document.frmUserCreation.txtUserID.disabled=true
	window.document.frmUserCreation.txtBio.disabled=true
	window.document.frmUserCreation.txtpwd.disabled= true
	

	// Send Query string to get users list
	st="QueryN|"+
		 window.document.frmUserCreation.txtBrcode.value
if (window.document.frmUserCreation.opt1(6).checked==true)
{
st="QueryU|"+
		 window.document.frmUserCreation.txtBrcode.value
}	 
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
}

function DisplayQuery(kstr)
{
	if (kstr=="No Data Found...")
		return
		
	if(window.document.frmUserCreation.opt1(7).checked==false)
	{
		// Assing the selected values into textboxes from list
		assign(kstr,window.document.frmUserCreation.txtUserName,window.document.frmUserCreation.txtUserID )
		window.document.all.divUserdtls.style.display="block"
		window.document.all.divExpire.style.display="none"
		// call function to display the values according to the selected user
		if(window.document.frmUserCreation.opt1(1).checked==true)
		{
			window.document.frmUserCreation.txtAddress.disabled=false
			window.document.frmUserCreation.txtAddress1.disabled=false
			window.document.frmUserCreation.txtCity.disabled=false
			window.document.frmUserCreation.txtDesig.disabled=false 
			window.document.frmUserCreation.txtEmail.disabled=false 
			window.document.frmUserCreation.txtUserName.disabled=false
			window.document.frmUserCreation.txtEmpcode.disabled=false
			window.document.frmUserCreation.txtUserID.disabled=true 
			window.document.frmUserCreation.txtBio.disabled=true 
			window.document.frmUserCreation.txtpwd.disabled=true 
			window.document.frmUserCreation.cmdMachine.disabled=false
			window.document.frmUserCreation.chkmacid.disabled=false
		}
		if ((window.document.frmUserCreation.opt1(2).checked==true)||
		(window.document.frmUserCreation.opt1(3).checked==true)
		||(window.document.frmUserCreation.opt1(4).checked==true)
		||(window.document.frmUserCreation.opt1(5).checked==true)
		||(window.document.frmUserCreation.opt1(6).checked==true))
		{
			window.document.frmUserCreation.txtAddress.disabled=true
			window.document.frmUserCreation.txtAddress1.disabled=true
			window.document.frmUserCreation.txtCity.disabled=true
			window.document.frmUserCreation.txtDesig.disabled=true
			window.document.frmUserCreation.txtEmail.disabled=true
			window.document.frmUserCreation.txtUserName.disabled=true
			window.document.frmUserCreation.txtEmpcode.disabled=true
			window.document.frmUserCreation.txtUserID.disabled=true 
			window.document.frmUserCreation.txtBio.disabled=true 
			window.document.frmUserCreation.txtpwd.disabled=true 
			window.document.frmUserCreation.cmdMachine.disabled=true
			window.document.frmUserCreation.chkmacid.disabled=true
			
		}
		if (window.document.frmUserCreation.opt1(4).checked==true)
		{
			window.document.all.divdisable.style.display="block"
		}
		else
			window.document.all.divdisable.style.display="none"
		

		Gendisplay()
	}
	else
	{
		
		window.document.all.profilediv.style.display="none"
		window.document.all.divUserdtls.style.display="none"
		window.document.all.divdisable.style.display="none"
		window.document.all.divExpire.style.display="block"
		
		assign(kstr,window.document.frmUserCreation.txtExpName,window.document.frmUserCreation.txtExpID)
		
		userpswdat()

	}
	

//
}

function userpswdat()
{
	var st
	
	st="USERPSW"+"|"+window.document.frmUserCreation.txtExpID.value+"|"+window.document.frmUserCreation.txtBrcode.value
	
	window.document.all['iBatch'].src="getDetails.aspx?st="+st 	
}

function popUPdat(str)
{
	var stVal = str.split("~")
	window.document.frmUserCreation.txtOldpsw.value = stVal[0]
	window.document.frmUserCreation.txtOlduser.value = stVal[1]
	window.document.frmUserCreation.txtNewpsw.value = ""
	window.document.frmUserCreation.txtNewuser.value = ""
}

function checkUser()
{

	//var strVin="USERCONFIGDATA|USRGRP"
	var strVin="USERCONFIGDATA|HOTRAW"
	window.document.all['idetails'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"getDtls.aspx?st="+strVin;
}

function popConfigData(str)
{
	if(str==0)
	{
		alert("Please set Parameters In Config.")
	}
	else
	{
		var kstr=str.split("|")
		if(kstr[0]=="Y")
		{
			if(("<%=session("groupcode")%>"=="ADMIN")&&("<%=session("branchcode")%>"==kstr[1]))
			{
			}
			else
			{
				alert("You Are Not Authorized User to Create User.")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}
		}
	}
}

function GrClear()
{
window.document.frmUserCreation.txtUserName.value=""
UnClear()
}

function UnClear()
{
if(window.document.frmUserCreation.opt1(0).checked==true)
{
window.document.frmUserCreation.txtUserID.value=""
UidClear()
}
}	
function UidClear()
{
window.document.frmUserCreation.txtpwd.value=""
PwdClear()
}
function PwdClear()
{
window.document.frmUserCreation.txtBio.value=""
SecClear()
}
function SecClear()
{
window.document.frmUserCreation.txtDesig.value=""
DesClear()
}
function DesClear()
{
window.document.frmUserCreation.txtAddress.value=""
window.document.frmUserCreation.txtAddress1.value=""
addClear()
}
function addClear()
{
window.document.frmUserCreation.txtCity.value=""
CityClear()
}
function CityClear()
{
window.document.frmUserCreation.txtFailed.value=""
FailClear()
}
function FailClear()
{
window.document.frmUserCreation.txtLifeTime.value=""
PlifeClear()
}
function UlifeClear()
{
window.document.frmUserCreation.txtLifeTime.value=""
PlifeClear()
}
function PlifeClear()
{
window.document.frmUserCreation.txtGraceTime.value=""
}
//-->
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Abbcheck();checkUser()">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>
 
		
<form name="frmUserCreation">
<div class="header">
			<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
	
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="center" height="22" class="subHeader"><h2>User Creation</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=appdate%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>
  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain">
	<tr>
	  <td>  

	<tr>
	  <td width="100%">
	  <table border="0" width="100%" cellspacing="0" cellpadding="0" >
		
		
		<tr>
		  <td width="100%" >

		<div style="text-align:center; width:100%; font-weight:bold; color:blue;"><%=Request.QueryString("record")%></div>
			  
		  <div align="center">
			<center>

			<table border="0" width="100%" cellspacing="0" cellpadding="0">
			  <tr class="bgcolor">
				<td width="18%" align="left">
				<p align="center">Branch Code</p>
				</td>
				<td width="40%"><input name="txtBrcode" size="8" readonly value="<%=session("branchcode")%>" class="txtautofill" ><input type="button" value=" L " name="cmdbranch" onclick="branch()" class="button"><input name="txtBrdesc" size="16" readonly value="<%=session("branchnarration")%>" class="bgcolor1" >&nbsp;</td>
				<td width="54%" align="right">Group Code&nbsp;&nbsp;</td>
				<td width="32%" align="right"><input name="txtGrcode" class="txtautofill" size="9" readonly><input type="button" value=" L " name="cmdGroup" onclick="GroupList();GrClear()" class="button"><input name="txtGrdesc" size="15" class="bgcolor1" readonly></td>
			  </tr>
			</table>

			</center>
		  </div>
		  <div align="center">
			<center>

			<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
			  <tr>
				<td width="100%">

				<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
				  <tr class="bgcolor1">
					<td width="8%">
					<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>New&nbsp;</font></p>
					</td>
					<td width="8%">
					<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">
					Modify&nbsp;</font></p>
					</td>
					<td width="8%">
					<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="DELETE">Delete</font></p>
					</td>
					<td width="8%">
					<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="DELETE1">
					View</font></td>
					<td width="12%">
					<font class="textblack">&nbsp;<input name="opt1" onclick="New()" type="radio" value="DELETE2">
					Disable/Enable User</font></td>
					<td width="12%">
					<font class="textblack">&nbsp;<input name="opt1" onclick="New()" type="radio" value="LOCK">Lock User</font></td>
					<td width="12%">
					<font class="textblack">&nbsp;<input name="opt1" onclick="New()" type="radio" value="UnLOCK">UnLock User</font></td>
					<td width="12%">
					<font class="textblack">&nbsp;<input name="opt1" onclick="New()" type="radio" value="Expire">User PSW Exp</font></td>
				  </tr>
				</table>

				<table border="0" width="100%" cellspacing="0" cellpadding="0">
				  <tr>
					<td width="100%" valign="top" height="10"></td>
				  </tr>
				  <tr>
					<td width="100%" valign="top" height="10">
					  <div align="center" style="display:none" id="divdisable">
						<center>
						
					  <table border="0" cellpadding="0" cellspacing="0" width="475" class="tableborder2">
						<tr>
						  <td width="467" colspan="2"></td>
						</tr>
						<tr>
						  <td width="195">&nbsp; Disable User</td>
						  <td width="270"><input type="checkbox" name="chkdisable" onclick="window.document.frmUserCreation.txtreason.value=''" value="ON"></td>
						</tr>
						<tr>
						  <td width="195">&nbsp; Reason</td>
						  <td width="270"><textarea  rows=2 cols=10 name="txtreason" onkeypress="restrictLength()" size="32" maxlength=10></textarea></td>
						</tr>
					  </table>
						</center>
					  </div>
					</td>
				  </tr>
				  <tr>
					<td width="100%" valign="top" height="1">
					<div align="center" id="divUserdtls" style="display:block">

					  <table width="54%" cellpadding="0" height="257" class="tableborder2">
						<tr>
						  <td width="100%" height="255">

						  <table border="0" cellspacing="0" cellpadding="0" width="467">
							<tr class="bgcolor">
							  <td width="465" colspan="4">
							  <p align="left"><font class="subheading">&nbsp;User
							  Information</font></p>
							  </td>
							</tr>
							<tr>
							  <td width="196">&nbsp;User Name</td>
							  <td width="267" colspan="3"><input name="txtUserName" class="txtautofill" size="32" onchange="UnClear()" onblur="UName()" maxlength="40" style="HEIGHT: 22px; TEXT-TRANSFORM: uppercase; " onkeypress="Alphanum()"></td>
							</tr>
							<tr>
							  <td width="196">&nbsp;User ID</td>
							  <td width="267" colspan="3"><input name="txtUserID" size="32"  class="txtautofill" onblur="Uid()" onchange="UidClear()" maxlength="13" style="HEIGHT: 22px; TEXT-TRANSFORM: uppercase;" onblur="CheckSpace()" onkeypress="Alphanum();UidClear()"></td>
							</tr>
							<tr>
							  <td width="196">&nbsp;Password</td>
							  <td width="267" colspan="3"><input type="password" name="txtpwd" maxlength="15" class="txtautofill" onchange="PwdClear()" onblur="Pwd()" size="32" onkeypress="Alphanum()" readonly></td>
							</tr>
							<tr>
							  <td width="196">&nbsp;Second Password</td>
							  <td width="267" colspan="3"><input type="password" name="txtBio" size="32" maxlength="15" class="txtautofill" onchange="SecClear()" onblur="bio()" onkeypress="Alphanum()" readonly></td>
							</tr>
							<tr>
							  <td width="196">&nbsp;Employee Code</td>

			</center>
							  <td width="107">
								<p align="left"><input  name="txtEmpcode" class="txtautofill" size="12" style="TEXT-TRANSFORM: capitalize;" maxlength="12">&nbsp;&nbsp;</p>
							</td>
							  <td width="109">
								<p align="right">ABB User Y/N&nbsp;&nbsp;&nbsp;</td>
			<center>

							  <td width="51"> <input type="checkbox" name="chkAbb" onclick=AbbCheck() value="ON"></td>
							</tr>
							<tr>
							  <td width="465" colspan="4">
								<table border="0" cellpadding="0" cellspacing="0" width="465" height="23">
								  <tr>
									<td width="230" height="23">&nbsp;Restricted to a
								Single Machine&nbsp;&nbsp;&nbsp; <input type="checkbox" name="chkmacid" onclick="DispMacid()" value="ON">&nbsp;</td>
									<td valign="middle"><span id="spsessions" style="display:none">No. Of
								Sessions&nbsp;</span></td>
									<td width="124" height="23"><input  name="txtSessions" size="12" value="1" maxlength="2" style="visibility:hidden"></td>
								  </tr>
								</table>
							  </td>
							</tr>
							<tr>
							  <td width="196"><span id="spmacid" style="display:none">&nbsp;Machine IP&nbsp;</span></td>
							  <td width="267" colspan="3"><input name="txtMacid" readonly size="29" maxlength="30"><input type="button" value=" L " name="cmdMachine" style="visibility:hidden" onclick="Machine()" class="button"></td>
							</tr>
							<tr class="bgcolor">
							  <td width="465" colspan="4" height="18"><font class="subheading">&nbsp;Personal
							  Information</font></td>
							</tr>
							<tr>
							  <td width="196" height="25">&nbsp;Designation</td>
							  <td width="267" height="25" colspan="3"><input name="txtDesig" size="32" class="txtautofill" style="TEXT-TRANSFORM: capitalize;" onchange="DesClear()" onblur="des()"  maxlength="30" onkeypress="chkchar()"></td>
							</tr>
							<tr>
							  <td width="196" height="25">&nbsp;Address</td>
							  <td width="267" height="25" colspan="3"><input name="txtAddress" maxlength="60" class="txtautofill" style="TEXT-TRANSFORM: capitalize;"  onblur="Addr()" onchange="addClear()" size="32" onkeypress="addresschar()"></td>
							</tr>
							<tr>
							  <td width="196" height="25"></td>
							  <td width="267" height="25" colspan="3"><input name="txtAddress1"  onblur="" maxlength="60" class="txtautofill" style="TEXT-TRANSFORM: capitalize;" size="32" onkeypress="addresschar()"></td>
							</tr>
							<tr>
							  <td width="196" height="25">&nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							  <td width="267" height="25" colspan="3"><input name="txtCity" onchange="CityClear()" maxlength="40" size="32" style="TEXT-TRANSFORM: capitalize;" onkeypress="addresschar()"  class="txtautofill" onblur="city()" ></td>
							</tr>
							<tr>
							  <td width="196" height="25" align="right">
							  <p align="left">&nbsp;E-mail ID</p>
							  </td>
							  <td width="267" height="25" colspan="3"><input name="txtEmail" size="32" maxlength="50" onblur="Checksymbols()" class="txtautofill" onkeypress="chkmailchar()"  onblur="Check()" ></td>
							</tr>
							<tr>
							  <td width="196" height="25" align="right">
							  <p align="left">&nbsp;Moobile No</p>
							  </td>
							  <td width="267" height="25" colspan="3"><input name="txtMobileNo" size="32" maxlength="10"  class="txtautofill" onkeypress="numeric()"   ></td>
							</tr>
							<tr>
							  <td width="196" height="25" align="right">
							  <p align="left">&nbsp;User DOB</p>
							  </td>
							  <td width="267" height="25" colspan="3"><input type="text" name="txtuserDOB" id="txtuserDOB" maxlength=10 onblur="datecheck(this)" size="11">(DDMMYYYY)</td>
							</tr>
						  </table>

						  </center>

						  </td>
						</tr>
					  </table>

					</div>
					<!-- for user password Expire ---->
					<div align="center" id="divExpire" style="display:none">

					  <table width="60%" cellpadding="0" height="257" class="tableborder2">
						<tr>
						  <td width="100%">

						  <table border="01" cellspacing="0" cellpadding="0" width="100%">
							<tr class="bgcolor">
							  <td width="100%" colspan="4">
							  <p align="left"><font class="subheading">&nbsp;User
							  Information</font></p>
							  </td>
							</tr>
							<tr>
							  <td width="20%">&nbsp;User Name</td>
							  <td width="80%" colspan="3"><input name="txtExpName" class="txtautofill" size="32" onchange="UnClear()" onblur="UName()" maxlength="40" style="HEIGHT: 22px; TEXT-TRANSFORM: uppercase; " onkeypress="Alphanum()" readonly ></td>
							</tr>
							<tr>
							  <td width="20%">&nbsp;User ID</td>
							  <td width="80%" colspan="3"><input name="txtExpID" size="32"  class="txtautofill" onblur="Uid()" onchange="UidClear()" maxlength="13" style="HEIGHT: 22px; TEXT-TRANSFORM: uppercase;" onblur="CheckSpace()" onkeypress="Alphanum();UidClear()" readonly ></td>
							</tr>
							<tr>
							  <td width="20%">&nbsp;PSW Expire Date</td>
							  <td width="80%" colspan="3"><input name="txtOldpsw" class="txtautofill" size="13" readonly >&nbsp;New PSW Expire Date&nbsp;<input name="txtNewpsw" maxlength=10 onblur="datecheck(this)" class="txtautofill" size="13" >(DDMMYYYY)</td>
							</tr>
							<tr>
							  <td width="20%">&nbsp;User Expire Date</td>
							  <td width="80%" colspan="3"><input name="txtOlduser" class="txtautofill" size="13" readonly >&nbsp;New User Expire Date&nbsp;&nbsp;<input name="txtNewuser" onblur="datecheck(this)" maxlength=10 size="13" class="txtautofill" >(DDMMYYYY)</td>
							</tr>
						</table>
						</td>
						</tr>
						</table>
					</div>
							
					</td>
				  </tr>
				  <tr>
					<td width="100%" height="63">
					<div align="center">
					  <div id="profilediv" style="DISPLAY: block">

						<table width="54%" cellpadding="0" height="82" class="tableborder2">
						  <tr>
							<td width="100%" height="80">

							<table border="0" width="100%" cellspacing="0" cellpadding="0">
							  <tr class="bgcolor">
								<td width="100%" colspan="2" height="18"><font class="subheading">&nbsp;Profile
								Information</font></td>
							  </tr>
							  <tr>
								<td width="42%" height="25">&nbsp;Failed Login attempts</td>
								<td width="58%" height="25"><input name="txtFailed" class="txtautofill" onchange="FailClear()" size="15" maxlength="2" onkeypress="numeric()">&nbsp;</td>
							  </tr>
					   <tr>
							   <td width="42%" height="25">&nbsp;UserId life time</td>
								<td width="58%" height="25"><input name="txtUidTime" onchange="UlifeClear()" class="txtautofill" size="15" maxlength="4" onkeypress="numeric()">&nbsp;Days</td>
							  </tr>       
							  
							  <tr>
								<td width="42%" height="25">&nbsp;Password life time</td>
								<td width="58%" height="25"><input name="txtLifeTime" onchange="PlifeClear()" class="txtautofill" size="15" maxlength="3" onkeypress="numeric()">&nbsp;Days</td>
							  </tr>
							  <tr>
								<td width="42%" height="25">&nbsp;Password grace time</td>
								<td width="58%" height="25"><input name="txtGraceTime" size="15" maxlength="1" class="txtautofill" onkeypress="numeric()">&nbsp;Days</td>
							  </tr>
							</table>

							<div>
							</div>
							</td>
						  </tr>
						</table>

					  </div>
					</div>
					</td>
				  </tr>
				  <tr>
					<td width="100%" height="10"></td>
				  </tr>
				</table>

				</td>
			  </tr>
			</table>

		  </div>
		  </td>
		</tr>
		
		<tr width="100%">
		  <td width="100%" height="32"><center>

		  <table width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 1003px"  class="tablebordermain">
			<tr >
			  <td width="100%" align="center" ><input name="cmdOk" onclick="Ok()" type="button" value="    Ok    " class="button"><input name="cmdcancel" onclick="Cancel()" type="button" value="Cancel" class="button"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
			</tr>
		  </table>

		  </center></td>
		</tr>
	  </table>

	  </td>
	</tr>
  </table>

  <input type="hidden" name="hmod" value="<%=session("module")%>">
  <input type="hidden" name="status">
  <input type="hidden" name="hidaccstatus">
  <input type="hidden" name="hidAbb">
  <input type="hidden" name="hidPsw" value="">
  <input type="hidden" name="hidUsr" value="">
  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
	<td width="100%">
	<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="">
											  </iframe>
	<IFRAME id="idetails" align=center style="COLOR: #c7ba95;  LEFT: 0px; TOP: 0px; WIDTH: 0px height=0px" 
			height=0 width=0 valign="top"></IFRAME>
	</td>
  </tr>
</table>

</body>

</html>
