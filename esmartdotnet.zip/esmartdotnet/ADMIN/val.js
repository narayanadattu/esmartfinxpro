//---------------split function--------------------------

function display1(str){
	var balstr=new String()
	balstr=str.split("|")
	var clrbal=balstr[0]
	var unclrbal=balstr[1]
	var netbal=balstr[2]
	var custId=balstr[3]
}



function Exit(){

location.replace("cashmodule.asp")

}

//---------------Precision starts---------------------------------------

function precision(number,pr)
{
var i,j,k,n,m,v
if(pr.length==0)
{
p=2
}
else
{
p=pr
}
j=0;
k=0;
n=0;
var textvalue=number.value
	
		for(i=1;i<p;i++)
		{
			j=j + "0"	 
		}		
			m= "."+j;
						
	if(textvalue!="")
	{
		var dotindex=textvalue.indexOf('.');
		
		if(dotindex==-1)
		{
			number.value=textvalue + m
				
			return;
		}
		else if(dotindex>-1)
		{
			var dotafterchars=textvalue.substring(dotindex+1)			
			k=dotafterchars.length			
			if(k<p)
			{
			
				t=eval(p)-eval(k);
				
				for(i=0;i<t-1;i++)
				{					
					n=n + "0"					
				}		
		
			number.value =textvalue + n	 				
		
			 return;				
			}				
		else
		{
		number.value= textvalue.substr(0,dotindex) + textvalue.substr(dotindex,p+1)			
		 return;			
		}				
		
			
		}		
	
	}
		
	
}	

//----------------------Precision End----------------------------------------




// -----checking empty-----------

function chkamt(amt)
{

if(amt.value=="")
  {
   amt.value="0.00"
   }
   else
      {
        if(isNaN(amt.value))
       {
		alert("Enter Amount")
		amt.focus()
		amt.select()
        }
      }
              
}

//---------checking numeric---------

function numeric()
{

 if(!(((event.keyCode>=48)&&(event.keyCode<=57))))
 {
   event.keyCode=0;
 }  
  else if(event.keyCode==46)
  {  
   event.keyCode=0;
  } 
}

var m=0
function decimal()
{
	

    if(((event.keyCode<48)||(event.keyCode>57))&&(event.keyCode!=46))
	{
		event.keyCode=null
		return	
   }    
    
  if(event.keyCode==46)
    {   
		m=m+1
    }
   if(m>1)
   { 
   if(event.keyCode==46)
   {
	event.keyCode=null
	return
	}
else
  {
  return;
  }	
  }
   
}

function digit(str,txt)
{

	a=str.indexOf(".")	
	if(a==-1)	
	{
		txt.value=str + ".00" 
		
		return;  
	}

}



function chknum(num)
{
	
     if(isNaN(num.value))
    {
		alert("Should be Numeric")
		num.focus()
		num.select()
        }             
}
// ------------checking numeric values----------------------


<!--

function amtselect(amt) {
 
 amt.select()
}


function amountdigits(number){
	var textvalue=number.value;
	if(textvalue!="")
	{
		var dotindex=textvalue.indexOf('.');
		if(dotindex==-1)
			number.value=number.value+".00";
		else if(dotindex>-1)
		{
			var dotafterchars=textvalue.substring(dotindex)
			if((dotafterchars.length)<2)
				number.value=number.value+"00";
			else if((dotafterchars.length)<=2)
				number.value=number.value+"0";

		}
		if(dotindex>-1){
			var dotafterchars1=(number.value).substring(dotindex)
			if((dotafterchars1.length)>3)
				number.value=(number.value).substring(0,dotindex+3)
		}
	}
}

//-->



//---------checking characters---------

function chkchar()
{
 w=window.event.keyCode
 if (w>96 & w<123 | w>64 & w<91 | w==8 | w==32){
	return
 }
 else
 {
	window.event.keyCode=null
	
 }
}


//----------------------Menus---------------------------------

function init()
{
	var img;
	myNavBar.create();
	img = getImage("placeholder");
	myNavBar.moveTo(getImagePageLeft(img) - 2, getImagePageTop(img) - 2);
}




//----------------------Status----------------------------------

timeID = 5;
stcnt=11;

msg = " WELCOME       T O      e S M A R T      B A N K E R";
wmsg = new Array(33);
blnk = "                                                                                                       ";

wmsg[0] = msg;

for(i=0;i<31;i++) {

 wmsg[i] = "";
 b = blnk.substring(0,i);
 
  for(j=0;j<msg.length;j++) wmsg[i] = wmsg[i]+msg.charAt(j)+b;
 } 

function wiper() {
 if(stcnt > -1) str = wmsg[stcnt]; else str = msg; 
 if(stcnt-- < -40) stcnt = 31;
 status = str;
 clearTimeout(timeID);
 timeID = setTimeout("wiper()",100);

 }

 function perm() {

 status = msg; 
 }




//----------------------------------------------------------------------



//===============================Denominations Multiplication==============


function CashMultiply(Note,Rs,Amt)
{ var i,T
  T="0"
  
  if (Rs.value=="")
  {
    Amt.value="0.00"
  }
  else
  {
    Amt.value=parseInt(Note)* parseInt(Rs.value)
  }
    
}


//-----------------------Date Picker Validation-------------------


function Datepick1(Dtp,Txt) 
 {
  
	var d,day,mon,yr
	d=Dtp.value
	var dd=new Date(d)
	day=dd.getDate()
	mon=dd.getMonth()+1
	yr=dd.getYear()
	if (mon<10)
	mon="0" + mon
	Txt.value=day + "-" + mon + "-" + yr
    
}	




function Datepick(Dtp,Txt) 
 {
  
	var d,day,mon,yr
	d=Dtp.value
	var dd=new Date(d)
	day=dd.getDate()
	mon=dd.getMonth()
	yr=dd.getYear()
	//if (mon<10)
	//	mon="0" + mon
	//	Txt.value=day + "-" + mon + "-" + yr
	if(mon==0)
	{
	mon="Jan"
	}
	   
    else if(mon==1)
	{
	mon="Feb"
	}
	else if(mon==2)
	{
	mon="Mar"
	}
	else if(mon==3)
	{
	mon="Apr"
	}
	else if(mon==4)
	{
	mon="May"
	}
	else if(mon==5)
	{
	mon="Jun"
	}
	else if(mon==6)
	{
	mon="Jul"
	}
	else if(mon==7)
	{
	mon="Aug"
	}
	else if(mon==8)
	{
	mon="Sep"
	}
	else if(mon==9)
	{
	mon="Oct"
	}
	else if(mon==10)
	{
	mon="Nov"
	}
	else if(mon==11)
	{
	mon="Dec"
	}
	
	Txt.value=day + "-" + mon + "-" + yr
}	

//===============================================================


function openJ(URL,WindowName) 
{
	window.open(URL,WindowName, 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=170,height=410');
}

function openS(URL,WindowName)
{
	window.open(URL,WindowName, 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=300,height=260');
}

function openA(URL,WindowName)
 {
	window.open(URL,WindowName, 'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=290,height=420');
}

function startCricVision()
 {
	window.open("http://cricvision.cricinfo.com/realtrack.html","cv",'status=0,scrollbars=0,resizable=0,width=600,height=502,top=50,left=50,screenX=50,screenY=50');
}



//---------checking @ . _ characters---------

function chkmailchar()
{
 w=window.event.keyCode
 if (w>96 & w<123 | w>64 & w<91 | w>47 & w<59 | w==8 | w==32 | w==64 | w==95 | w==46 )
 {
	return
 }
 else
 {
	window.event.keyCode=null
 }
}

function addresschar()
{
 w=window.event.keyCode
 if (w>96 & w<123 | w>64 & w<91 | w>44 & w<59 | w==8 | w==32 | w==64 | w==95 | w==35 | w==38 | w==40 | w==41 | w==123 | w==125 | w==91 | w==93)
 {
	return
 }
 else
 {
	window.event.keyCode=null
 }
}