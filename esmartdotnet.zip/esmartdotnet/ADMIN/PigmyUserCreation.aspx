<%@ Page Language="vb" CodeBehind="PigmyUserCreation.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.PigmyUserCreation" %>

<%'*************************************************************************
'***************************************************************************
'*	Name Of the File : PigmyUserCreation.ASP							   *
'*	Purpose	  	     : To create Pigmy Agents in database			       *
'*						             									   *
'*																		   *
'*		   													               *
'*			                                            			       *
'|-------------------------------------------------------------------------|
'|     @Author 	      |    Created On    |  Version      |      Remarks	   |'|--------------------|------------------|---------------|-----------------|
'| Sharath Kumar More |    17-APR-2008   |   ASP.NET 1.0 |		           |
'|				      |                  |	             |                 |
'|-------------------------------------------------------------------------|
'***************************************************************************
'***************************************************************************

%>


<%
abb=session("Abbuser")%>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>User Creation Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE=javascript>
<!--
///// this function restricts the length of text area : Reason
function restrictLength()
{
if (window.document.frmPigmyUserCreation.txtreason.value.length>=99)
	window.event.keyCode=0
}
/// this function is called when Ok button is pressed
function Ok()
{

	if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
	{
		alert("Enter GlCode")
		window.document.frmPigmyUserCreation.txtGlCode.focus()
		window.document.frmPigmyUserCreation.opt1(0).checked=true
		return;
	}
	

if(window.document.frmPigmyUserCreation.opt1(0).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmPigmyUserCreation.status.value="INSERT"
	//// CheckNull() function returns False then return the control
//	alert("bbbbb")
	if (CheckNull()==false)
	return
	Insert() //// Call Insert()
}
if(window.document.frmPigmyUserCreation.opt1(1).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmPigmyUserCreation.status.value="MODIFY"
	//// CheckNull() function returns False then return the control
	if (CheckNull()==false)
		return
	Modify()	/// Call Modify()
}
if(window.document.frmPigmyUserCreation.opt1(4).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmPigmyUserCreation.status.value="DISABLE"
	//// CheckNull() function returns False then return the control
	Disable()	/// Call Disable()
}
if(window.document.frmPigmyUserCreation.opt1(2).checked==true)
{
	//// Set the status according to the selected option button
	window.document.frmPigmyUserCreation.status.value="DELETE"
	//// CheckNull() function returns False then return the control
	//if (CheckNull()==false)
	//	return
	Delete() ///// Call Delete()
}
}

function DispMacid()
{/*
if(window.document.frmPigmyUserCreation.chkmacid.checked==true)
	{
	window.document.all.spmacid.style.display="block"
	window.document.frmPigmyUserCreation.txtMacid.style.visibility="visible"
	//window.document.frmPigmyUserCreation.cmdMachine.style.visibility="visible"
	}
else if(window.document.frmPigmyUserCreation.chkmacid.checked==false)
	{
	window.document.all.spmacid.style.display="none"
	window.document.frmPigmyUserCreation.txtMacid.style.visibility="hidden"
	//window.document.frmPigmyUserCreation.cmdMachine.style.visibility="hidden"
	}
	window.document.frmPigmyUserCreation.txtMacid.value=""*/
}
/*
function Abbcheck()
{
var abb="<%=abb%>"
if (abb=="Y")
	window.document.frmPigmyUserCreation.cmdbranch.disabled=false
else
	window.document.frmPigmyUserCreation.cmdbranch.disabled=true
}*/

//// This fucntion is called when any of the option buttons clicked to set the status
function New()
{
accNo=""
accNm=""
	if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
	{
		alert("Enter GlCode")
		window.document.frmPigmyUserCreation.txtGlCode.focus()
		window.document.frmPigmyUserCreation.opt1(0).checked=true
		return;
	}
	
	window.document.frmPigmyUserCreation.txtUserName.readOnly=false
	window.document.frmPigmyUserCreation.txtUserID.readOnly=false
	window.document.all.divdisable.style.display="none"
	window.document.frmPigmyUserCreation.cmdAcc.disabled=false
	window.document.frmPigmyUserCreation.txtAcc.readOnly=false
	//window.document.frmPigmyUserCreation.txtAccNm.readOnly=false
	
if(window.document.frmPigmyUserCreation.opt1(0).checked==true)
{
	//// if new is clicked
	/// Make visible the user profile division
	window.document.frmPigmyUserCreation.all.profilediv.style.display="block"	
	
	//// Enable all other required fields
	//window.document.frmPigmyUserCreation.txtAddress.disabled=false
	//window.document.frmPigmyUserCreation.txtAddress1.disabled=false
	//window.document.frmPigmyUserCreation.txtCity.disabled=false
	//window.document.frmPigmyUserCreation.txtDesig.disabled=false
	//window.document.frmPigmyUserCreation.txtEmail.disabled=false
	window.document.frmPigmyUserCreation.txtUserName.disabled=false
	//window.document.frmPigmyUserCreation.txtUserID.disabled=false 
		window.document.frmPigmyUserCreation.txtUserID.readOnly=false 
	window.document.frmPigmyUserCreation.txtBio.disabled=false 
	window.document.frmPigmyUserCreation.txtpwd.disabled=false 
	//window.document.frmPigmyUserCreation.cmdMachine.disabled=false 
	//window.document.frmPigmyUserCreation.cmdbranch.disabled=false
	/// Clear the fields
	Clear()

}
else
{
	/// Clear the fields
	//window.document.frmPigmyUserCreation.cmdAcc.disabled=true
	
	//window.document.frmPigmyUserCreation.txtAcc.readOnly=true
	//window.document.frmPigmyUserCreation.txtAccNm.readOnly=true
//	window.document.frmPigmyUserCreation.txtUserName.readOnly=true
	window.document.frmPigmyUserCreation.txtUserID.readOnly=true
	Clear()
	/// Call list page
	
	QueryList()	
	//// Disable branchlist button
	//window.document.frmPigmyUserCreation.cmdbranch.disabled=false
	
}


}

/// To clear All the required fields
function Clear()
{
	//window.document.frmPigmyUserCreation.txtAddress.value=""
	//window.document.frmPigmyUserCreation.txtAddress1.value=""
	//window.document.frmPigmyUserCreation.txtCity.value=""
	//window.document.frmPigmyUserCreation.txtDesig.value=""
	//window.document.frmPigmyUserCreation.txtEmail.value=""
	window.document.frmPigmyUserCreation.txtUserName.value=""
	//window.document.frmPigmyUserCreation.txtEmpcode.value=""
	window.document.frmPigmyUserCreation.txtUserID.value=""
	window.document.frmPigmyUserCreation.txtBio.value=""
	window.document.frmPigmyUserCreation.txtpwd.value=""
	window.document.frmPigmyUserCreation.txtAcc.value=""
	window.document.frmPigmyUserCreation.txtAccNm.value=""
	
	//window.document.frmPigmyUserCreation.txtMacid.value=""
	DispMacid()
}

//// this fucntion is called when Machine iP list button is pressed
function Machine()
{   
	// send Branch string to LIST.asp
	if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
		{
			alert("Branch Code can not be null..")
			return		
		}
	st="Machine|"+
		window.document.frmPigmyUserCreation.txtBrcode.value
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function MachineIp(kstr)
{/*
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  	  window.document.frmPigmyUserCreation.txtMacid.value=kstr[1]
*/	 	  	
}

//// this fucntion is called when branch list button is pressed
function branch()
{   
	clearInfo()
	//window.document.frmPigmyUserCreation.txtGr.value=""
	//window.document.frmPigmyUserCreation.txtGrNm.value=""
	window.document.frmPigmyUserCreation.txtGlCode.value=""
	window.document.frmPigmyUserCreation.txtGldesc.value=""
	window.document.frmPigmyUserCreation.txtAcc.value=""
	window.document.frmPigmyUserCreation.txtAccNm.value=""
	
	// send Branch string to LIST.asp
	st="Branch"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Branchid(kstr)
{
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  window.document.frmPigmyUserCreation.txtBrdesc.value=kstr[0]
	 	  window.document.frmPigmyUserCreation.txtBrcode.value=kstr[1]
	 	  	
}

//// this fucntion is called when Accno list button is pressed
function Accno()
{   
	//clearInfo()
	
	//window.document.frmPigmyUserCreation.txtAcc.value=""
	//window.document.frmPigmyUserCreation.txtAccNm.value=""
	 	  	  
	if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
	{
		alert("Select Branch Code")
		window.document.frmPigmyUserCreation.txtBrcode.focus()
		//window.document.frmPigmyUserCreation.txtGr.value=""
		//window.document.frmPigmyUserCreation.txtGrNm.value=""
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		return;
	}
		
	if(window.document.frmPigmyUserCreation.txtGr.value=="")
	{
		alert("Select Group")
		window.document.frmPigmyUserCreation.cmdGroup.focus()
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		return;
	}

	if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
	{
		alert("Select GlCode")
		window.document.frmPigmyUserCreation.txtGlCode.focus()
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		return;
	}
				
	// send Branch string to LIST.asp
	st="PigmyAccno"

	st=st+"|"+window.document.frmPigmyUserCreation.txtBrcode.value
	st=st+"|"+window.document.frmPigmyUserCreation.txtModcode.value
	st=st+"|"+window.document.frmPigmyUserCreation.txtGlCode.value
	
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}

// this is called to display the selected branchcodes
function PigmyAccnoid(kstr)
{
	
	if (kstr=="No Data Found...")
		return
	// Display the selected information in text boxes
	
	kstr=kstr.split("-----")
	
	window.document.frmPigmyUserCreation.txtAcc.value=kstr[1]
	window.document.frmPigmyUserCreation.txtAccNm.value=kstr[0]
	 	  	  
	//txtUserID
	 	  	  
	//window.document.frmPigmyUserCreation.txtUserName.value = kstr[0]
	//window.document.frmPigmyUserCreation.txtUserID.value = kstr[1]
	 	  	
}



function GlCode()
{   
	clearInfo()

	// send Branch string to LIST.asp
	window.document.frmPigmyUserCreation.txtGldesc.value=""
	window.document.frmPigmyUserCreation.txtGlCode.value=""
	
	if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
	{
		alert("Select Branch Code")
		window.document.frmPigmyUserCreation.txtBrcode.focus()
		//window.document.frmPigmyUserCreation.txtGr.value=""
		//window.document.frmPigmyUserCreation.txtGrNm.value=""
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		
		return;
	}
		
	if(window.document.frmPigmyUserCreation.txtGr.value=="")
	{
		alert("Select Group")
		window.document.frmPigmyUserCreation.cmdGroup.focus()
		window.document.frmPigmyUserCreation.txtGlCode.value=""
		window.document.frmPigmyUserCreation.txtGldesc.value=""
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
		return;
	}
		
		window.document.frmPigmyUserCreation.opt1(0).checked=true
		window.document.frmPigmyUserCreation.txtAcc.disabled=false
		window.document.frmPigmyUserCreation.txtAcc.readOnly=false
		//window.document.frmPigmyUserCreation.txtUserID.disabled=false
		window.document.frmPigmyUserCreation.txtUserID.readOnly=false
		window.document.frmPigmyUserCreation.cmdAcc.disabled=false
		window.document.frmPigmyUserCreation.txtAcc.value=""
		window.document.frmPigmyUserCreation.txtAccNm.value=""
	
		
	st="PigmyGlcode"
	
	st=st+"|"+window.document.frmPigmyUserCreation.txtModcode.value	
		 +"|"+window.document.frmPigmyUserCreation.txtBrcode.value
		 
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
	
}
// this is called to display the selected branchcodes
function Glcodeid(kstr)
{	
	
	
	if (kstr=="No Data Found...")
		return
		
	// Display the selected information in text boxes
			  kstr=kstr.split("-----")
	 	  window.document.frmPigmyUserCreation.txtGlCode.value=kstr[1]
	 	  window.document.frmPigmyUserCreation.txtGldesc.value=kstr[0]
	 	  
	 	  	
}

function DescQry(str)
{
	
	if(str=="Gl")
	{  clearInfo()
	 
	    window.document.frmPigmyUserCreation.txtAcc.value=""
	    window.document.frmPigmyUserCreation.txtAccNm.value="" 
	    window.document.frmPigmyUserCreation.txtGldesc.value=""
	    
		if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
		return;
		
		if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
		{
			alert("Select Branchcode")
			window.document.frmPigmyUserCreation.txtBrcode.focus()
			//window.document.frmPigmyUserCreation.txtGr.value=""
			//window.document.frmPigmyUserCreation.txtGrNm.value=""
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
		if(window.document.frmPigmyUserCreation.txtGr.value=="")
		{
			alert("Select Group")
			window.document.frmPigmyUserCreation.cmdGroup.focus()
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
	    str = "PigmyGl" 
				+"|"+window.document.frmPigmyUserCreation.txtBrcode.value
				+"|"+window.document.frmPigmyUserCreation.txtModcode.value
				+"|"+window.document.frmPigmyUserCreation.txtGlCode.value
						
	    window.document.all["iBatch"].src="../GEN/querydisplay.aspx?st="+str
	}	
		
	if(str=="Acc")
	{   
		if((window.document.frmPigmyUserCreation.opt1(0).checked==false)
		&& (window.document.frmPigmyUserCreation.opt1(1).checked==false))
		return;
		
		//clearInfo()
	 
	    if(accNo==window.document.frmPigmyUserCreation.txtAcc.value)
	    {
			window.document.frmPigmyUserCreation.txtAccNm.value=accNm
			return;
	    }
	    
	    window.document.frmPigmyUserCreation.txtAccNm.value="" 
		
		if(window.document.frmPigmyUserCreation.txtAcc.value=="")
		return;
			
		
		if(window.document.frmPigmyUserCreation.txtBrcode.value=="")
		{
			alert("Select Branchcode")
			widow.document.frmPigmyUserCreation.txtBrcode.focus()
			//window.document.frmPigmyUserCreation.txtGr.value=""
			//window.document.frmPigmyUserCreation.txtGrNm.value=""
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
		if(window.document.frmPigmyUserCreation.txtGr.value=="")
		{
			alert("Select Group")
			window.document.frmPigmyUserCreation.cmdGroup.focus()
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
		if(window.document.frmPigmyUserCreation.txtGlCode.value=="")
		{
			alert("Select GlCode")
			window.document.frmPigmyUserCreation.txtGlCode.focus()
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
		
			return;
		}
		
	    str = "PigmyAcc" 
				+"|"+window.document.frmPigmyUserCreation.txtBrcode.value
				+"|"+window.document.frmPigmyUserCreation.txtModcode.value
				+"|"+window.document.frmPigmyUserCreation.txtGlCode.value
				+"|"+window.document.frmPigmyUserCreation.txtAcc.value	
				  
	    window.document.all["iBatch"].src="../GEN/querydisplay.aspx?st="+str
	}	
}


function DescDisplay(kstr)
{
	kstr=kstr.split("|")

	if(kstr[0]=="PigmyGl")
	{	
		if(kstr[1]=="")
		{
			alert("Invalid GlCode")
			window.document.frmPigmyUserCreation.txtGlCode.value=""
			window.document.frmPigmyUserCreation.txtGldesc.value=""
			window.document.frmPigmyUserCreation.txtGlCode.focus()
			return;
		}
		
		window.document.frmPigmyUserCreation.txtGldesc.value = kstr[1]
		
	}
	
	else if (kstr[0]=="PigmyAcc")
	{
		if(kstr[1]=="")
		{
			alert("Invalid Account Number")
			window.document.frmPigmyUserCreation.txtAcc.value=""
			window.document.frmPigmyUserCreation.txtAccNm.value=""
			window.document.frmPigmyUserCreation.txtAcc.focus()
			return;
		}
		
		window.document.frmPigmyUserCreation.txtAccNm.value = kstr[1]
		  
		//window.document.frmPigmyUserCreation.txtUserName.value = window.document.frmPigmyUserCreation.txtAccNm.value
	
		//window.document.frmPigmyUserCreation.txtUserID.value = window.document.frmPigmyUserCreation.txtAcc.value
		
	}
}

function clearInfo()
{
		window.document.frmPigmyUserCreation.txtUserName.value=""
		window.document.frmPigmyUserCreation.txtUserID.value=""
		window.document.frmPigmyUserCreation.txtpwd.value=""
		window.document.frmPigmyUserCreation.txtBio.value=""
//		window.document.frmPigmyUserCreation.txtEmpcode.value=""
		//window.document.frmPigmyUserCreation.txtDesig.value=""
		//window.document.frmPigmyUserCreation.txtAddress.value=""
		//window.document.frmPigmyUserCreation.txtAddress1.value=""
		//window.document.frmPigmyUserCreation.txtCity.value=""
		window.document.frmPigmyUserCreation.txtFailed.value=""
		window.document.frmPigmyUserCreation.txtLifeTime.value=""
		window.document.frmPigmyUserCreation.txtGraceTime.value=""
		
}
// to check Nulls
// this function returns FALSE value if any null is there

function CheckNull()
{		
		if(window.document.frmPigmyUserCreation.txtGr.value =="")
		{
			alert("Enter Group Code")
			window.document.frmPigmyUserCreation.txtGr.focus()
			return false
		}
		
		if(window.document.frmPigmyUserCreation.txtUserID.value =="")
		{
			alert("Enter User Id")
			window.document.frmPigmyUserCreation.txtUserID.focus()
			return false
		}
		
		if(window.document.frmPigmyUserCreation.txtUserName.value =="")
		{
			alert("Enter User Name")
			window.document.frmPigmyUserCreation.txtUserName.focus()
			return false
		}
		
		if(window.document.frmPigmyUserCreation.txtAcc.value =="")
		{
			alert("Enter Account Number")
			window.document.frmPigmyUserCreation.txtAcc.focus()
			return false
		}
		
		if(window.document.frmPigmyUserCreation.status.value=="INSERT")
		{
		
		//if((window.document.frmPigmyUserCreation.txtUserName.value =="")||
		//(window.document.frmPigmyUserCreation.txtUserID.value =="") || 
		//(window.document.frmPigmyUserCreation.txtpwd.value=="") || 
		//(window.document.frmPigmyUserCreation.txtBio.value=="") ||
		//(window.document.frmPigmyUserCreation.txtEmpcode.value=="") ||
		//(window.document.frmPigmyUserCreation.txtDesig.value=="") || 
		//(window.document.frmPigmyUserCreation.txtAddress.value=="") || 
		//(window.document.frmPigmyUserCreation.txtCity.value=="")|| 
		//(window.document.frmPigmyUserCreation.txtFailed.value=="") || 
		//(window.document.frmPigmyUserCreation.txtLifeTime.value=="")||
		//(window.document.frmPigmyUserCreation.txtGraceTime.value=="")||
		//(window.document.frmPigmyUserCreation.txtGr.value==""))
		
		if(window.document.frmPigmyUserCreation.txtpwd.value=="")
		{
				window.alert("Password Should not be Empty...!")
				window.document.frmPigmyUserCreation.txtpwd.focus()
				return false
		}
		}
		/*else
		{
		//if((window.document.frmPigmyUserCreation.txtUserName.value =="")||
		//(window.document.frmPigmyUserCreation.txtUserID.value =="") ||
		//(window.document.frmPigmyUserCreation.txtDesig.value=="") || 
		//(window.document.frmPigmyUserCreation.txtEmpcode.value=="") || 
		//(window.document.frmPigmyUserCreation.txtAddress.value=="") || 
		//(window.document.frmPigmyUserCreation.txtCity.value==""))
		
		if((window.document.frmPigmyUserCreation.txtUserName.value =="")||
		(window.document.frmPigmyUserCreation.txtUserID.value =="") )
		{
				window.alert("Fields Should not be Empty...!")
				window.document.frmPigmyUserCreation.txtUserName.focus 
				return false
		}
		}*/
		
		if(window.document.frmPigmyUserCreation.status.value=="INSERT")
		{
			if(window.document.frmPigmyUserCreation.txtUserID.value.toUpperCase() == 
			   window.document.frmPigmyUserCreation.txtpwd.value.toUpperCase())
			{
			   alert("Password should not be same as User Id")
			   return false
			}          
		}
		
		
}


// to check any Space is given in userid
// this function not allows spaces
function CheckSpace()
{
var indx
indx=window.document.frmPigmyUserCreation.txtUserID.value.indexOf(" ") // Take the index of space
if (indx!=-1)  // if any space is there
	{
	alert ("Space is not allowed...!")
	window.document.frmPigmyUserCreation.txtUserID.focus() 
	}
}




// to check for "@" and "." symbols in email id
function Checksymbols() 
{/*
var indx
var indy
	
	if (window.document.frmPigmyUserCreation.txtEmail.value!="")
	{
	///get  the number of @ symbols
	indx=window.document.frmPigmyUserCreation.txtEmail.value.split("@")
	///get  the number of . symbols
	indy=window.document.frmPigmyUserCreation.txtEmail.value.split(".")
	
	if ((indx.length>2)||(indy.length>3)) // if more than required found return an error message
		{
			alert ("Enter valid mailid...!")
			window.document.frmPigmyUserCreation.txtEmail.focus() 
			return
		}
	/// get the position of "."
	indy=window.document.frmPigmyUserCreation.txtEmail.value.lastIndexOf(".")
	/// get the length of mail id
	indx=window.document.frmPigmyUserCreation.txtEmail.value.length
	// if "." is in the begining of mail id return error
	if(indy==indx-1) 
		{
			alert ("Enter valid mailid...!")
			window.document.frmPigmyUserCreation.txtEmail.focus() 
			return
		}
	indx=window.document.frmPigmyUserCreation.txtEmail.value.indexOf("@") // Take the index of "@"
	if ((indx==-1)||(indx==0))  // if "@" is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmPigmyUserCreation.txtEmail.focus() 
			return
		}
	indy=window.document.frmPigmyUserCreation.txtEmail.value.indexOf(".") // Take the index of "."

	if ((indx==-1)||(indx==0))  // if "." is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmPigmyUserCreation.txtEmail.focus() 
			return
		}
	//// if "." found before "@" then return error
	if ((indy==indx+1)||(indy<indx))
		{
			alert ("Enter valid mailid...!")
			window.document.frmPigmyUserCreation.txtEmail.focus() 
			return
		}
	}
*/ }


/// is called when group list button is selected

function GroupList()
{
	clearInfo()
	// send User string to LIST.ASP to get the users list
	//window.document.frmPigmyUserCreation.txtGr.value=""
	//window.document.frmPigmyUserCreation.txtGrNm.value=""
	window.document.frmPigmyUserCreation.txtGlCode.value=""
	window.document.frmPigmyUserCreation.txtGldesc.value=""
	window.document.frmPigmyUserCreation.txtAcc.value=""
	window.document.frmPigmyUserCreation.txtAccNm.value=""
	st="Group"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")

}

/// to display the selected group from the group list
function DisplayGroup(kstr)
{
		if (kstr=="No Data Found...")
		return
		// assing the selected values to textboxes from users list
		//assign(kstr,window.document.frmPigmyUserCreation.txtGrNm,window.document.frmPigmyUserCreation.txtGr )
		
			  kstr=kstr.split("-----")
			   
	 	  window.document.frmPigmyUserCreation.txtGr.value=kstr[1]
	 	  window.document.frmPigmyUserCreation.txtGrNm.value=kstr[0]
	 /*
		window.document.frmPigmyUserCreation.txtSessions.value=""
		if(window.document.frmPigmyUserCreation.txtGr.value=="ADMIN")
			{
			window.document.all.spsessions.style.display="block"
			window.document.frmPigmyUserCreation.txtSessions.style.visibility="visible"
			}
		else
			{
			window.document.all.spsessions.style.display="none"
			window.document.frmPigmyUserCreation.txtSessions.style.visibility="hidden"
			}*/
		//window.document.frmPigmyUserCreation.txtDesig.value=window.document.frmPigmyUserCreation.txtGrNm.value 

}

function AbbCheck()
{
	window.document.frmPigmyUserCreation.DTexp.Value="<%=session("applicationdate")%>"
/*
if(window.document.frmPigmyUserCreation.chkAbb.checked==true)
	window.document.frmPigmyUserCreation.hidAbb.value="Y"
else
	window.document.frmPigmyUserCreation.hidAbb.value="N"
	*/
}



//****************calling this fuction on click of  cmdInsert button to call the Asp Page
// ***************to insert the values in datatbase
function Insert()
{
	window.document.frmPigmyUserCreation.status.value="INSERT"
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPx"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();
	
}


//****************calling this fuction onclick of cmdModify button to call the Asp Page
// ***************to modify the values in datatbase
function Modify()
{
	window.document.frmPigmyUserCreation.status.value="MODIFY"
	if (CheckNull()==false)
		return
	//window.document.frmPigmyUserCreation.txtpwd.disabled=true
	//window.document.frmPigmyUserCreation.txtBio.disabled=true
	//window.document.frmPigmyUserCreation.txtUserID.disabled=false
	//window.document.frmPigmyUserCreation.txtUserName.disabled=false
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPx"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();	
	
}

function Disable()
{
	window.document.frmPigmyUserCreation.status.value="DISABLE"
	if(window.document.frmPigmyUserCreation.txtreason.value=="")
		{
		alert("Reason can not be null..")
		return
		}
	if(window.document.frmPigmyUserCreation.chkdisable.checked==true)
		window.document.frmPigmyUserCreation.hidaccstatus.value="F" //Frozen 
	else
	{
		window.document.frmPigmyUserCreation.hidaccstatus.value="R"
		window.document.frmPigmyUserCreation.txtreason.value="Running"
	}	
	
	//window.document.frmPigmyUserCreation.txtUserID.disabled=false
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPx"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();	
}


//****************calling this fuction onclick of cmdDelete button to call the Asp Page
// ***************to delete the values in datatbase
function Delete()
{
	window.document.frmPigmyUserCreation.status.value="DELETE"
	if (CheckNull()==false)
		return
	
	//window.document.frmPigmyUserCreation.cmdbranch.disabled=false
	//window.document.frmPigmyUserCreation.cmdGroup.disabled=false
	//window.document.frmPigmyUserCreation.txtUserID.disabled=false
	window.document.frmPigmyUserCreation.action="PigmyUserCreationDBOper.ASPx"
	window.document.frmPigmyUserCreation.method="post"
	window.document.frmPigmyUserCreation.submit();
	
}

// Refresh the contents of screen
function Cancel()
{
location.href ="PigmyUserCreation.aspx"
}

// To get the users list 
function Gendisplay()
{
	//st=window.document.frmPigmyUserCreation.txtUserID.value 
	//window.document.all['iBatch'].src="GenUserDetails.aspx?st="+st 
}

// This function displays the information of selected user from the users list
function GenDisp(kstr)
  {
   var Str1
  // Splits the information on basis of "+}"
 
 
  Str1=kstr.split("+}")

  window.document.frmPigmyUserCreation.txtBrcode.value=Str1[0]
  window.document.frmPigmyUserCreation.txtGr.value=Str1[2]
  window.document.frmPigmyUserCreation.txtGrNm.value=Str1[3]
  //window.document.frmPigmyUserCreation.txtDesig.value=Str1[4]
  //window.document.frmPigmyUserCreation.txtAddress.value=Str1[5]
  //window.document.frmPigmyUserCreation .txtAddress1.value=Str1[6]
  //window.document.frmPigmyUserCreation.txtCity.value=Str1[7]
  //window.document.frmPigmyUserCreation.txtEmail.value=Str1[8]
  //if(Str1[9].length>2)
	//window.document.frmPigmyUserCreation.chkmacid.checked=true
  //else
	//window.document.frmPigmyUserCreation.chkmacid.checked=false
 

  
 // window.document.frmPigmyUserCreation.txtSessions.value=Str1[10]
  window.document.frmPigmyUserCreation.txtBrdesc.value=Str1[15]
  /*
  if(Str1[14]=="Y")
	window.document.frmPigmyUserCreation.chkAbb.checked=true
  else
	window.document.frmPigmyUserCreation.chkAbb.checked=false
  */
  DispMacid()
  //window.document.frmPigmyUserCreation.txtMacid.value=Str1[9]
  window.document.frmPigmyUserCreation.txtreason.value=Str1[11]
  
  //window.document.frmPigmyUserCreation.txtEmpcode.value=Str1[13]
  if(Str1[10]=="R")
	window.document.frmPigmyUserCreation.chkdisable.checked=false
  else
	window.document.frmPigmyUserCreation.chkdisable.checked=true
	
  if(window.document.frmPigmyUserCreation.txtGr.value=="ADMIN")
	{/*
		window.document.all.spsessions.style.display="block"
		window.document.frmPigmyUserCreation.txtSessions.style.visibility="visible"*/
	}
	else
	{/*
		window.document.all.spsessions.style.display="none"
		window.document.frmPigmyUserCreation.txtSessions.style.visibility="hidden"*/
	}
  }



function QueryList()
{
	// Enable or disable the textboxes and command buttons accordingly
	
	
	window.document.frmPigmyUserCreation.all.profilediv.style.display="None"
	
	//window.document.frmPigmyUserCreation.txtUserID.disabled=true
	window.document.frmPigmyUserCreation.txtBio.disabled=true
	window.document.frmPigmyUserCreation.txtpwd.disabled= true
	

	// Send Query string to get users list
	var Qstr
	
		Qstr="PQueryN|"
		
	if(window.document.frmPigmyUserCreation.opt1(4).checked==true)
		Qstr="PQueryX|"
	
	
	st=Qstr+
		 window.document.frmPigmyUserCreation.txtBrcode.value+"|"+
		 window.document.frmPigmyUserCreation.txtGlCode.value
		 
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:400px;DialogHeight:150px;DialogLeft:180px;DialogTop:190px")
}

var chkdis,accNo,accNm

function DisplayQuery(kstr)
{   //alert(kstr)
	if (kstr=="No Data Found...")
		return
		kstr=kstr.split("-----")
		window.document.frmPigmyUserCreation.txtUserName.value=kstr[0]
		window.document.frmPigmyUserCreation.txtUserID.value=kstr[1]
		window.document.frmPigmyUserCreation.txtAcc.value=kstr[2]
		accNo=kstr[2]
		window.document.frmPigmyUserCreation.txtAccNm.value=kstr[3]
		accNm=kstr[3]
		if(window.document.frmPigmyUserCreation.opt1(4).checked==true)
		{
			k=kstr[4].split("~")
			//alert(k)
			window.document.frmPigmyUserCreation.txtexpdate.value=k[0]
			window.document.frmPigmyUserCreation.DTexp.value=k[0]
			chkdis=k[1]
		}
		else
		{
			window.document.frmPigmyUserCreation.txtexpdate.value=kstr[4]
			window.document.frmPigmyUserCreation.DTexp.value=kstr[4]
		}
		
	// Assing the selected values into textboxes from list
	
	//assign(kstr,window.document.frmPigmyUserCreation.txtUserName,window.document.frmPigmyUserCreation.txtUserID )
	// call function to display the values according to the selected user
	window.document.frmPigmyUserCreation.DTexp.enabled=true
	window.document.frmPigmyUserCreation.all.profilediv.style.display="block"
	window.document.frmPigmyUserCreation.cmdAcc.disabled=true
	window.document.frmPigmyUserCreation.txtAcc.readOnly=true
	
	if(window.document.frmPigmyUserCreation.opt1(1).checked==true)
	{
		//window.document.frmPigmyUserCreation.txtAddress.disabled=false
		//window.document.frmPigmyUserCreation.txtAddress1.disabled=false
		//window.document.frmPigmyUserCreation.txtCity.disabled=false
		//window.document.frmPigmyUserCreation.txtDesig.disabled=false 
		//window.document.frmPigmyUserCreation.txtEmail.disabled=false 
		window.document.frmPigmyUserCreation.txtUserName.disabled=false
		//window.document.frmPigmyUserCreation.txtEmpcode.disabled=false
		//window.document.frmPigmyUserCreation.txtUserID.disabled=true
		window.document.frmPigmyUserCreation.txtUserID.readOnly=true 
		window.document.frmPigmyUserCreation.txtBio.disabled=false 
		//window.document.frmPigmyUserCreation.txtpwd.disabled=false
		window.document.frmPigmyUserCreation.DTexp.disabled=false
		window.document.frmPigmyUserCreation.cmdAcc.disabled=false
		window.document.frmPigmyUserCreation.txtAcc.readOnly=false
		//window.document.frmPigmyUserCreation.cmdMachine.disabled=false
		//window.document.frmPigmyUserCreation.chkmacid.disabled=false
	}
	if ((window.document.frmPigmyUserCreation.opt1(2).checked==true)||
	(window.document.frmPigmyUserCreation.opt1(3).checked==true)
	||(window.document.frmPigmyUserCreation.opt1(4).checked==true))
	{
		//window.document.frmPigmyUserCreation.txtAddress.disabled=true
		//window.document.frmPigmyUserCreation.txtAddress1.disabled=true
		//window.document.frmPigmyUserCreation.txtCity.disabled=true
		//window.document.frmPigmyUserCreation.txtDesig.disabled=true
		//window.document.frmPigmyUserCreation.txtEmail.disabled=true
		window.document.frmPigmyUserCreation.txtUserName.disabled=true
		//window.document.frmPigmyUserCreation.txtEmpcode.disabled=true
		//window.document.frmPigmyUserCreation.txtUserID.disabled=true 
		window.document.frmPigmyUserCreation.txtUserID.readOnly=true
		window.document.frmPigmyUserCreation.txtBio.disabled=true 
		window.document.frmPigmyUserCreation.txtpwd.disabled=true 
		window.document.frmPigmyUserCreation.DTexp.enabled=false
		//window.document.frmPigmyUserCreation.cmdMachine.disabled=true
		//window.document.frmPigmyUserCreation.chkmacid.disabled=true
		
	}
	if (window.document.frmPigmyUserCreation.opt1(2).checked==true)
	{	
		window.document.frmPigmyUserCreation.DTexp.disabled=false
	}
	if (window.document.frmPigmyUserCreation.opt1(4).checked==true)
		window.document.all.divdisable.style.display="block"
	else
		window.document.all.divdisable.style.display="none"
	
	if(chkdis=='F')
		window.document.frmPigmyUserCreation.chkdisable.checked=true
//Gendisplay()
	chkDisp()
}	

function chkDisp()
{ 
	window.document.frmPigmyUserCreation.txtreason.value=''
	window.document.frmPigmyUserCreation.txtreason.readOnly=false
	if (window.document.frmPigmyUserCreation.chkdisable.checked==false)
	{
		window.document.frmPigmyUserCreation.txtreason.value='Running'
		window.document.frmPigmyUserCreation.txtreason.readOnly=true
	}
	
}

function Datestatus(stri)
{

	var strflds=new String()
	strflds=stri.split("|")

//alert(strflds[0])

	if(strflds[1]=="DateCheckTo") 
	{
		if(strflds[0]=="NotExceed")
		{
			alert("Expiry Date should be Greater Than Application Date..")
			window.document.frmPigmyUserCreation.txtexpdate.value='<%=session("Applicationdate")%>'
			window.document.frmPigmyUserCreation.DTexp.value='<%=session("Applicationdate")%>'
			return;
		}
	}	
}


//-->
</SCRIPT>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function DTexp_CloseUp() 
{
	Datepick(window.document.frmPigmyUserCreation.DTexp,window.document.frmPigmyUserCreation.txtexpdate)
	
	st="DateCheckTo|"+'<%=session("Applicationdate")%>'+
				"|"+window.document.frmPigmyUserCreation.txtexpdate.value
	
	window.document.all["iBatch"].src="../GENSBCA/querydisplay1.aspx?st="+st
	
}
-->
</SCRIPT> 
<SCRIPT LANGUAGE=javascript FOR=DTexp EVENT=CloseUp>
<!--
 DTexp_CloseUp()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Abbcheck()">

<form name="frmPigmyUserCreation">
  <%appdate=formatdatetime(session("applicationdate"),1)%>
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="34%" align="center" height="22" class="subHeader"><h2>pigmy user creation</h2></td>
					<td width="26%" height="22" align="right" class="subHeader"><%=appdate%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>

  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain">
    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="89%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
          </table>

          </td>
        </tr>
      </table>

   

       
          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="25%" align="left">
                <font>&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</font>
                </td>
                <td width="50%"><input name="txtBrcode" size="9" class="txtautofill" readonly value="<%=session("branchcode")%>"><input type="button" value=" L " name="cmdbranch" class="button" onclick="branch()"><input name="txtBrdesc" size="16" readonly class="bgcolor1" value="<%=session("branchnarration")%>">&nbsp;</td>
                <td width="54%" align="left"><font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Group Code</font></td>
                <td width="32%" align="right"><input name="txtGr" size="9" class="txtautofill" readonly value="PIGMY"><input type="button" value=" L " name="cmdGroup" class="button" disabled onclick="GroupList()"><input name="txtGrNm" size="16" readonly class="bgcolor1" value="PIGMY"></td>
              </tr>
              <tr class="bgcolor">
                <td width="25%" align="left">
                <font>&nbsp;&nbsp;&nbsp;&nbsp;Module ID</font>
                </td>
                <td width="50%"><input name="txtModcode" size="9" readonly class="txtautofill" value="PIGMY"><input type="button" value=" L " name="cmdmod" class="button" disabled><input name="txtModdesc" class="bgcolor1" size="16" readonly value="Daily Deposits">&nbsp;</td>
                <td width="54%" align="left"><font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GL Code</font></td>
                <td width="32%" align="right"><input name="txtGlCode" size="9" class="txtautofill" onkeypress="Alphanum()"  maxlength="14" onblur="DescQry('Gl')" ><input type="button" value=" L " name="cmdGl" class="button" onclick="GlCode()"><input name="txtGldesc" class="bgcolor1" size="16" readonly></td>
              </tr>
            </table>

            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
                  <tr class="bgcolor1">
                    <td width="18%">
                    <p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>
                    New&nbsp;</font></p>
                    </td>
                    <td width="20%">
                    <p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">
                    Modify&nbsp;</font></p>
                    </td>
                    <td width="20%"  style="display:none">
                    <p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="DELETE">
                    &nbsp;Delete&nbsp;</font></p>
                    </td>
                    <td width="19%">
                    <p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="DELETE1">
                    View</font></td>
                    <td width="29%">
                    <font class="textblack">&nbsp;<input name="opt1" onclick="New()" type="radio" value="DELETE2">
                    Disable/Enable User</font></td>
                  </tr>
                </table>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" valign="top" height="10"></td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" height="10">
                      <div align="center" style="display:none" id="divdisable">
                        <center>
                        
                      <table border="0" cellpadding="0" cellspacing="0" width="475" class="tableborder2">
                        <tr>
                          <td width="467" colspan="2"></td>
                        </tr>
                        <tr>
                          <td width="195">&nbsp; Disable User</td>
                          <td width="270"><input type="checkbox" name="chkdisable" onclick="chkDisp()" value="ON"></td> <!--"window.document.frmPigmyUserCreation.txtreason.value=''"-->
                        </tr>
                        <tr>
                          <td width="195">&nbsp; Reason</td>
                          <td width="270"><textarea  rows=2 cols=10 name="txtreason" onkeypress="restrictLength()" class="txtautofill" size="32" maxlength=10></textarea></td>
                        </tr>
                      </table>
                        </center>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" valign="top" height="1">
                    <div align="center">
<!---
                      <table width="54%" cellpadding="0" height="257" class="tableborder2">
                        <tr>
                          <td width="100%" height="255">
-->
                          <table border="0" cellspacing="0" cellpadding="0" width="487"  class="tableborder2">
                            <tr class="bgcolor">
                              <td width="465" colspan="4">
                              <p align="left"><font class="subheading">&nbsp;User
                              Information</font></p>
                              </td>
                            </tr>
                            <tr>
                              <td width="196">&nbsp;User ID</td>
                              <td width="267" colspan="3"><input name="txtUserID" class="txtautofill" size="34" maxlength="12" onkeypress="Alphanum()"  style="HEIGHT: 22px; " onblur="CheckSpace()" ></td><!--TEXT-TRANSFORM: uppercase; -->
                            </tr>
                            <tr>
                              <td width="196">&nbsp;User Name</td>
                              <td width="267" colspan="3"><input name="txtUserName" size="34" class="txtautofill" onkeypress="Alphanum()"  maxlength="50" style="HEIGHT: 22px; " ><!--TEXT-TRANSFORM: uppercase; --></td>
                            </tr>                            
                            <tr>
                              <td width="196">&nbsp;AccNo</td>
                              <td width="367" colspan="3"><input type="text" name="txtAcc" size="9" class="txtautofill" maxlength="14" onkeypress="numeric()" onblur="DescQry('Acc')"><input type="button" value=" L " name="cmdAcc" class="button" onclick="Accno()"><input  type="text" class="bgcolor1" name="txtAccNm" size="20" readonly>&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="196">&nbsp;Password</td>
                              <td width="267" colspan="3"><input type="password" class="txtautofill" name="txtpwd" maxlength="12" size="34"></td>
                            </tr>
                            <tr style="display:none">
                              <td width="196">&nbsp;Second Password</td>
                              <td width="267" colspan="3"><input type="password" name="txtBio" size="34" maxlength="30"></td>
                            </tr>
                            <!---------------------
                            <tr>
                              <td width="196">&nbsp;Employee Code</td>

            </center>
                              <td width="107">
                                <p align="left"><input  name="txtEmpcode" size="12" style="TEXT-TRANSFORM: capitalize;" maxlength="12">&nbsp;&nbsp;</p>
                            </td>
                              <td width="109">
                                <p align="right">ABB User Y/N&nbsp;&nbsp;&nbsp;</td>
            <center>

                              <td width="51"> <input type="checkbox" name="chkAbb" onclick=AbbCheck() value="ON"></td>
                            </tr>
                            <tr>
                              <td width="465" colspan="4">
                                <table border="0" cellpadding="0" cellspacing="0" width="465" height="23">
                                  <tr>
                                    <td width="230" height="23">&nbsp;Restricted to a
                                Single Machine&nbsp;&nbsp;&nbsp; <input type="checkbox" name="chkmacid" onclick="DispMacid()" value="ON">&nbsp;</td>
                                    <td valign="middle"><span id="spsessions" style="display:none">No. Of
                                Sessions&nbsp;</span></td>
                                    <td width="124" height="23"><input  name="txtSessions" size="12" value=0 maxlength="2" style="visibility:hidden"></td>
                                  </tr>
                                 
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td width="196"><span id="spmacid" style="display:none">&nbsp;Machine IP&nbsp;</span></td>
                              <td width="267" colspan="3"><input name="txtMacid" readonly size="29" maxlength="30"><input type="button" value=" L " name="cmdMachine" class="button" style="visibility:hidden" onclick="Machine()"></td>
                            </tr> --------------------->
   <!--                         <tr class="bgcolor">
                              <td width="465" colspan="4" height="18"><font class="subheading">&nbsp;Personal
                              Information</font></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Designation</td>
                              <td width="267" height="25" colspan="3"><input name="txtDesig" size="32" style="TEXT-TRANSFORM: capitalize;"  maxlength="20" onkeypress="chkchar()"></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;Address</td>
                              <td width="267" height="25" colspan="3"><input name="txtAddress" maxlength="19" style="TEXT-TRANSFORM: capitalize;" size="32" onkeypress="addresschar()"></td>
                            </tr>
                            <tr>
                              <td width="196" height="25"></td>
                              <td width="267" height="25" colspan="3"><input name="txtAddress1" maxlength="19" style="TEXT-TRANSFORM: capitalize;" size="32" onkeypress="addresschar()"></td>
                            </tr>
                            <tr>
                              <td width="196" height="25">&nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                              <td width="267" height="25" colspan="3"><input name="txtCity" maxlength="20" size="32" style="TEXT-TRANSFORM: capitalize;" onkeypress="addresschar()"></td>
                            </tr>
                            <tr>
                              <td width="196" height="25" align="right">
                              <p align="left">&nbsp;E-mail ID</p>
                              </td>
                              <td width="267" height="25" colspan="3"><input name="txtEmail" size="32" maxlength="30" onblur="Checksymbols()" onkeypress="chkmailchar()"></td>
                            </tr>
                          </table>

                          </center>

                          </td>-->
                        </tr>
                      </table>

                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="63">
                    <div align="center">
                      <div id="profilediv" style="DISPLAY: block">

                        <table border="0" width="487" cellpadding="0" cellspacing="0" class="tableborder2">
                          <tr>
                            <td width="100%" >

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="3" height="18"><font class="subheading">&nbsp;Profile
                                Information</font></td>
                              </tr>
                              <tr colspan="2" >
                                <td width="26%" height="25" >&nbsp;Expiry Date</td>
                                <td width="10%"><input name="txtexpdate" value="<%=session("applicationdate")%>" class="txtautofill" style="TEXT-ALIGN: center" size="12" readonly></td><td width="22%">
                    <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="22" id="DTexp" style="HEIGHT: 22px; LEFT: 10px; TOP: 35px; WIDTH: 36px" >
                      <param name="_ExtentX" value="953">
                      <param name="_ExtentY" value="582">
                      <param name="_Version" value="393216">
                      <param name="MousePointer" value="0">
                      <param name="Enabled" value="1">
                      <param name="OLEDropMode" value="0">
                      <param name="CalendarBackColor" value="-2147483643">
                      <param name="CalendarForeColor" value="-2147483630">
                      <param name="CalendarTitleBackColor" value="-2147483633">
                      <param name="CalendarTitleForeColor" value="-2147483630">
                      <param name="CalendarTrailingForeColor" value="-2147483631">
                      <param name="CheckBox" value="1">
                      <param name="CustomFormat" value="dd-mm-yyyy">
                      <param name="DateIsNull" value="0">
                      <param name="Format" value="662831105">
                      <param name="UpDown" value="0">
                      <param name="CurrentDate" value="<%=session("applicationdate")%>">
                      <param name="MaxDate" value="2958465">
                      <param name="MinDate" value="-109205">
                    </object>
                    </td>
                              </tr>
                              <tr style="display:none">
                                <td width="42%" height="25">&nbsp;Failed Login attempts</td>
                                <td width="58%" height="25"><input name="txtFailed" size="15" maxlength="2" onkeypress="numeric()">&nbsp;</td>
                              </tr>
                              <tr  style="display:none">
                                <td width="42%" height="25">&nbsp;Password life time</td>
                                <td width="58%" height="25"><input name="txtLifeTime" size="15" maxlength="3" onkeypress="numeric()">&nbsp;Days</td>
                              </tr>
                              <tr  style="display:none">
                                <td width="42%" height="25">&nbsp;Password grace time</td>
                                <td width="58%" height="25"><input name="txtGraceTime" size="15" maxlength="1" onkeypress="numeric()">&nbsp;Days</td>
                              </tr>
                            </table>

                            <div>
                            </div>
                            </td>
                          </tr>
                        </table>

                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

          </div>
          </td>
        </tr>
        
        <tr>
          <td width="80%" height="32"><center>

          <table cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 1003px" class="tablebordermain">
            <tr>
              <td width="100%" align="center"><input name="cmdOk" onclick="Ok()" type="button" value="    Ok    " class="button"><input name="cmdcancel" onclick="Cancel()" type="button" value="Cancel" class="button"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
            </tr>
            <tr><td>
            <table>
				<tr>
					<td width="100%" height="128"></td>
				</tr>
			</table>
            </td></tr>
          </table>

          </center></td>
        </tr>
      </table>

      </td>
    </tr>
    <!--<tr><td>
    <table><tr><td height="100"></td></tr></table>
	</td></tr>-->
  </table>
  
  <input type="hidden" name="hmod" value="<%=session("module")%>">
  <input type="hidden" name="status">
  <input type="hidden" name="hidaccstatus">
  <input type="hidden" name="hidAbb">
  <input type="hidden" name="brchCd">
  <input type="hidden" name="atype">
  <input type="hidden" name="Modid">
	
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>


    <iframe style="display:none" id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="">
    </iframe>


</body>

</html>
