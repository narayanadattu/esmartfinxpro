<%@ Page CodeBehind="commonmodule.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.commonmodule1" %>
<%Response.Write Request.QueryString ("madhu")%>
<SCRIPT LANGUAGE=javascript>
<!--
function callme()
{

alert("No Form is alloted this User")
var varst
varst=location.pathname 
varst=varst.split("/")
location.replace ("http://" + location.hostname +"/" + varst[1] +"/back.asp")
}
//-->
</SCRIPT>

<html>

<%	Response.Write session("pwd")%>
<%
	dim usrid
	dim objfetch
	dim objwork
	dim recdtls
	dim vals
	dim title
	dim vmod
	dim chkstr
	dim recmod
	
	vmod=Request.Form("hmod")
	vmodx=split(Request.QueryString("record"),"~")
	if ubound(vmodx)>0 then
		vmod=vmodx(0)
		session("moddir")=vmodx(1)
	end if
	usrid=session("userid")
	
	
	usrid=session("userid")
	set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
	set recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir",  _
			"upper(trim(machinename))='" & ucase(session("serverid")) & "'")
		mainstr=trim(recdtls(0)) &"/" & trim(recdtls(1)) &"/" & "~" & mainstr
		session("moduledir")=trim(recdtls(0)) &"/" & trim(recdtls(1)) 
	if(usrid="") then
		
		Response.Redirect "http://" & recdtls(0) & "/" & _
		trim(recdtls(1)) & "/useridscreen.asp?record=" & _
		"Your session is timeout. Please login again.."
	end if	
	
	
	if len(vmod)<=0 then vmod=session("module")
	session("module")=trim(vmod)
	session("servername")=Request.ServerVariables("SERVER_NAME")
	session("module")=trim(vmod)
	set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
	set objwork=server.CreateObject("workallotment.allotment")
	vals=objwork.userworkallotment("DELETE",trim(cstr(usrid)),trim(cstr(vmod)),trim(cstr(session("branchcode"))))
	for icount=0 to ubound(vals)-1
		valstr=valstr&",'" & vals(icount) &"'"
	next
	'Response.Write valstr

	appdate=session("applicationdate")
	'if 1=2 then
	if len(valstr)>0 then 
		set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
		valstr=right(valstr,len(valstr)-1)
		set recdaybeg=server.CreateObject ("queryrecordsets.fetchrecordsets")
		brcode=session("branchcode")
		appdate=session("applicationdate")
		set recdaybeg=objfetch.singlerecordset("genapplicationdatemst", _
		"daybeginstatus,dayendstatus","applicationdate='" & appdate & "' and branchcode='" & _
		brcode & "'")
		if not recdaybeg.eof and not recdaybeg.bof then
			if recdaybeg(0)="O" and recdaybeg(1)="N" then
				daybeg="Yes"
			else
				daybeg="No"			
			end if
		else
			daybeg="No"			
		end if
				
		set recdtls=server.CreateObject("adodb.recordset")
		gcode=session("groupcode")
	
	if daybeg="Yes" then
			set recdtls=objfetch.singlerecordset("genmoduleidformsmst a", _
				"distinct a.menutitle,a.narration,a.forms,a.gendir,a.mainmenu,a.menuorder,a.FORMSORDER", _
				"(a.narration in( select narration from gengroupformsmst where groupcode='" & _
				gcode & "' and a.moduleid='" & trim(vmod) &"' and status='R') or " & _
				"a.narration in( select narration from genuseridformsmst where " & _
				" a.moduleid='" & trim(vmod) &"' and status='R' and addoreliminate='A'))" & _
				" and a.narration not in( select narration from genuseridformsmst where " & _
				" moduleid='" & trim(vmod) &"' and status='R' and addoreliminate='E'" & _
				" and userid='" & session("userid") & "')" & _
				"order by a.menuorder,a.FORMSORDER " )
				
				
	
		else
				set recdtls=objfetch.singlerecordset("genmoduleidformsmst a", _
				"distinct a.menutitle,a.narration,a.forms,a.gendir,a.mainmenu,a.menuorder,a.FORMSORDER", _
				"(a.narration in( select narration from gengroupformsmst where groupcode='" & _
				gcode & "' and a.moduleid='" & trim(vmod) &"' and status='R') or " & _
				"a.narration in( select narration from genuseridformsmst where " & _
				" a.moduleid='" & trim(vmod) &"' and status='R' and addoreliminate='A'))" & _
				" and a.narration not in( select narration from genuseridformsmst where " & _
				" moduleid='" & trim(vmod) &"' and status='R' and addoreliminate='E'" & _
				" and userid='" & session("userid") & "') " & _
				" and a.formstatus ='A' order by a.menuorder,a.FORMSORDER " )
		
			
		end if				
		
			
		set recmod=server.CreateObject("adodb.recordset")
		set recmod=objfetch.singlerecordset("genmodulemst", _
			"moduledir","moduleid='" & trim(vmod) &"'")
	
		if not recdtls.EOF or not recdtls.BOF then
			chkstr=recdtls(0)
			mainstr=chkstr
		end if
		do while not recdtls.EOF 
			if isnull(recdtls(3))=false then
				stdir=recdtls(3)
			else
				stdir=recmod(0)
			end if
			if recdtls(0)=chkstr then
				mainstr=mainstr & "," & recdtls(1) &"*" & stdir & "/" & recdtls(2)
			else
				chkstr=recdtls(0)
				mainstr=mainstr & "|" & recdtls(0) & "," & recdtls(1)&"*" & stdir & "/" & recdtls(2) 
			end if
			recdtls.MoveNext
		loop
		set recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir",  _
			"upper(trim(machinename))='" & ucase(session("serverid")) & "'")
		mainstr=trim(recdtls(0)) &"/" & trim(recdtls(1)) &"/" & "~" & mainstr
		session("moduledir")=trim(recdtls(0)) &"/" & trim(recdtls(1)) 
		session("menustring")=mainstr
%>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmart Banker - Administration</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>


<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmart Banker - Administration</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>


</head>
<body onload="GetMenu(&quot;<%=session("menustring")%>&quot;)" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">

<form name="frmcashmodule">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top">

      </form>
      <%if ucase(session("module"))="ADMIN"  then %>
		<p><img border="0" src="../cutimagesblue/Administration_scr.jpg">
		<%elseif ucase(session("module"))="ALM"  then %>
		<p><img border="0" src="../cutimagesblue/Administration_scr.jpg">
		<%elseif ucase(session("module"))="BILLS"  then %>
		<p><img border="0" src="../cutimagesblue/bills_scr.jpg">
		<%elseif ucase(session("module"))="CA"  then %>
		<p><img border="0" src="../cutimagesblue/currentaccount_scr.jpg">
		<%elseif ucase(session("module"))="CC"  then %>
		<p><img border="0" src="../cutimagesblue/cashcredit_scr.jpg">
		<%elseif ucase(session("module"))="CLG"  then %>
		<p><img border="0" src="../cutimagesblue/clearing_scr.jpg">
		<%elseif ucase(session("module"))="CUSTOMER"  then %>
		<p><img border="0" src="../cutimagesblue/customer_scr.jpg">
		<%elseif ucase(session("module"))="DEP"  then %>
		<p><img border="0" src="../cutimagesblue/deposits_scr.jpg">
		<%elseif ucase(session("module"))="GL"  then %>
		<p><img border="0" src="../cutimagesblue/gl_scr.jpg">
		<%elseif ucase(session("module"))="HO"  then %>
		<p><img border="0" src="../cutimagesblue/headoffice_scr.jpg">
		<%elseif ucase(session("module"))="LC"  then %>
		<p><img border="0" src="../cutimagesblue/lc_scr.jpg">
		<%elseif ucase(session("module"))="LG"  then %>
		<p><img border="0" src="../cutimagesblue/lg_scr.jpg">
		<%elseif ucase(session("module"))="LOAN"  then %>
		<p><img border="0" src="../cutimagesblue/loan_scr.jpg">
		<%elseif ucase(session("module"))="LOCKER"  then %>
		<p><img border="0" src="../cutimagesblue/lockers_scr.jpg">
		<%elseif ucase(session("module"))="REM"  then %>
		<p><img border="0" src="../cutimagesblue/remittance_scr.jpg">
		<%elseif ucase(session("module"))="SB"  then %>
		<p><img border="0" src="../cutimagesblue/sb_scr.jpg">
		<%elseif ucase(session("module"))="TM"  then %>
		<p><img border="0" src="../cutimagesblue/treasury_scr.jpg">
	  <%end if%>	
		
		
		
		
		</td>
		
    </tr>
  </table>

</body>


<% 
else
	session("menustring")=""
	if len( session("userid"))<1 then
	Response.Write "<center><font color=red><b>Machine is idle for longer than specified time...</b></font></center><br>"
	Response.Write "<center><a href='../homepage.htm'><b><font color=blue id =i onmouseover=javascript:document.all.i.color='red' onmouseout=javascript:document.all.i.color='blue'>Please Login</b></a></center>"
	session.abandon
	end if %>
	
<% end if%>


