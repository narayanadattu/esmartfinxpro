<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmBOMSalaryGen.aspx.vb" Inherits="eSmartDotNet.frmBOMSalaryGen"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>BOM Salary Generation</title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	
	<SCRIPT LANGUAGE=javascript>
		function Report(strrep)
	{
	
	var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
		
	strheadtype = "BOM Salary Generation REPORT"
	strheadsub = "Board of Members Salary Generation On " + window.document.frmEmpMast.selSalmon.options[window.document.frmEmpMast.selSalmon.selectedIndex].text + " " + window.document.frmEmpMast.selSalyear.value 
	StrHead= strheadsub + ",60,80"
	window.document.frmEmpMast.reptitle.value=strheadtype
	
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,0)+",5,L"+"~"  // slno
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,1)+",6,L"+"~" // Dir Code
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,2)+",36,L"+"~" //Dir Name
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,3)+",12,R"+"~" // BOM Salary
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,4)+",5,R"+"~" // TDSYN
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,5)+",10,R"+"~" // TDSAmount
			StrCol=StrCol+window.document.frmEmpMast.mfgSal.TextMatrix(0,6)+",6,R"+"|" // Execution YN
			for(icnt=1;icnt<=window.document.frmEmpMast.mfgSal.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmEmpMast.mfgSal.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmEmpMast.mfgSal.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
			
			window.document.frmEmpMast.hreport.value=StrArr
			//alert(StrArr)
			if (strrep == "HTML") 
			{
				window.document.frmEmpMast.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmBOMSalaryGen"
			}
			else
			{
				window.document.frmEmpMast.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmBOMSalaryGen"
			}
			
			window.document.frmEmpMast.method="post"
			window.document.frmEmpMast.submit() 
	}

	function resultmessage()
{

message="<%=Request.QueryString("record")%>"
	if(message!="")
	{
		alert(message)
		location.href="frmBOMSalaryGen.aspx"
	}
}
function selSalmonchng()
	{
		window.document.frmEmpMast.mfgSal.Rows=1 
	}
	
	function genSal()
	{
		if(window.document.frmEmpMast.selSalmon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmEmpMast.selSalyear.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		strVal="BOMSAL"+"|"+window.document.frmEmpMast.selSalmon.options[window.document.frmEmpMast.selSalmon.selectedIndex].text+"|"+window.document.frmEmpMast.selSalyear.options[window.document.frmEmpMast.selSalyear.selectedIndex].text
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
		function GetBOMSAL(str)
	{
		if(str=="No Records")
		{
			alert("Salary is Already Generated")
			return;
		}
		
		var stSal = str.split("|")
		
		window.document.frmEmpMast.mfgSal.Rows=1
		
		window.document.frmEmpMast.mfgSal.cols=7;
		window.document.frmEmpMast.mfgSal.formatstring="<Sno         |<Dir ID         |<DirName                                                          |>BOM Salary      |^TDSYN           |>    TDSAmount      |^ExecutionYN  ";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmEmpMast.mfgSal.rows=window.document.frmEmpMast.mfgSal.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,0)=aCnt+1
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,1)=strCols[0]
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,2)=strCols[1]
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,3)=strCols[2]
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,4)=strCols[3]
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,5)=strCols[4]
			window.document.frmEmpMast.mfgSal.textmatrix(aCnt+1,6)=strCols[5]
			
			
		}
		
	}
	function mfgSal_DblClick()
	{
		
		
		row=window.document.frmEmpMast.mfgSal.Row
		
		if(window.document.frmEmpMast.mfgSal.textmatrix(row,6)=="Y")
		{
			window.document.frmEmpMast.mfgSal.textmatrix(row,6)="N"
			
			for (d=0 ;d<window.document.frmEmpMast.mfgSal.Cols;d++) 
			{  
				window.document.frmEmpMast.mfgSal.Col=d				
				window.document.frmEmpMast.mfgSal.CellBackColor=8421616
			}
		}
		
		else if(window.document.frmEmpMast.mfgSal.textmatrix(row,6)=="N")
		{
			window.document.frmEmpMast.mfgSal.textmatrix(row,6)="Y"
			
			for (d=0 ;d<window.document.frmEmpMast.mfgSal.Cols;d++) 
			{  
				window.document.frmEmpMast.mfgSal.Col=d				
				window.document.frmEmpMast.mfgSal.CellBackColor=16777215
			}
		}
	}
	
	// BOM Salary Generation
function Ok()
{
	
var BOMSalDtls
var BOMSalDtls1
var dbltotBOMSal
dbltotBOMSal = 0
BOMSalDtls = ""
BOMSalDtls1 = ""
resmaxamt1 = confirm("Do You Want To Execute BOM Salalry Generation ?  Do you want to continue..")
				if (resmaxamt1 == true)
				{}
				else
				{
				
				return
				}
window.document.frmEmpMast.hdnsalmon.value = window.document.frmEmpMast.selSalmon.options[window.document.frmEmpMast.selSalmon.selectedIndex].text

window.document.frmEmpMast.hdnsalyear.value = window.document.frmEmpMast.selSalyear.options[window.document.frmEmpMast.selSalyear.selectedIndex].text

var rows1= window.document.frmEmpMast.mfgSal.Rows

	if(rows1>1)
	{
	for(icnt=1;icnt<rows1;icnt++)
		{
			if (window.document.frmEmpMast.mfgSal.TextMatrix(icnt,6) == 'Y')
			{
			 BOMSalDtls1= window.document.frmEmpMast.mfgSal.TextMatrix(icnt,1) +"~"+window.document.frmEmpMast.mfgSal.TextMatrix(icnt,3)+"~"+window.document.frmEmpMast.mfgSal.TextMatrix(icnt,4)+"~"+window.document.frmEmpMast.mfgSal.TextMatrix(icnt,5)
			dbltotBOMSal = eval(dbltotBOMSal) + eval(window.document.frmEmpMast.mfgSal.TextMatrix(icnt,3)) + eval(window.document.frmEmpMast.mfgSal.TextMatrix(icnt,5))
			 BOMSalDtls=BOMSalDtls+"|"+BOMSalDtls1
			 }
		}
		BOMSalDtls=BOMSalDtls.substr(1)
	}

	window.document.frmEmpMast.hdnBOMSalDtls.value=BOMSalDtls
	window.document.frmEmpMast.hdndbltotBOMSal.value=dbltotBOMSal
		window.document.frmEmpMast.method="post"
		window.document.frmEmpMast.action="frmBOMSalGenInsert.aspx"
		window.document.frmEmpMast.submit()
}
	</script>
	<SCRIPT LANGUAGE=javascript FOR=mfgSal EVENT=DblClick>
	<!--
	mfgSal_DblClick()
	//-->
	</script>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);resultmessage();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmEmpMast">
    
    <div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="40%" align="center" height="22" class="subHeader"><h2>BOD/BOM Salary Generation</h2></td>
				<td width="20%" height="22" align="right" class="subHeader"><%=appdate%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tblebordermain">
		<tr>
			<td width="100%">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" >
				<tr>
					<td width="100%" height=50 > &nbsp;
					</td>
				</tr>
					<tr>
						<td width="100%" >
							<!--<div style="text-align:center; width:100%; font-weight:bold; color:blue;"><%=Request.QueryString("record")%></div>-->
								
          <div align="center">
            <center>

            <table BORDER = 1 width="100%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="1" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
											<td width="100%" align="center">Month&nbsp;&nbsp;											
											<%
												dim mon,mon1,mon2,nmon,nmon1,nmon2
												
												mon = Month(session("applicationdate"))
												
												if mon = 1 then
													mon1 = 12
												else
													mon1 = mon-1
												end if
												
												if mon = 12 then
													mon2 = 1
												else
													mon2 = mon+1
												end if
												
												nmon = MonthName(mon)
												
												nmon1 = MonthName(mon1)
												
												nmon2 = MonthName(mon2)
												
											%>
											
											<select name="selSalmon" onchange="selSalmonchng()">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=mon%>" selected><%=nmon%></option>
												<option value="<%=mon1%>"><%=nmon1%></option>
												<option value="<%=mon2%>"><%=nmon2%></option>
											</select>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												dim yer,yer1,yer2
												
												yer = Year(session("applicationdate"))
												
												if mon = 1 then
													yer1 = yer-1
												else
													yer1 = ""
												end if
												
												if mon = 12 then
													yer2 = yer+1
												else
													yer2 = ""
												end if
												
											%>
											<select name="selSalyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=yer%>" selected><%=yer%></option>
												<option value="<%=yer1%>"><%=yer1%></option>
												<option value="<%=yer2%>"><%=yer2%></option>
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="GenSalrate" class="button" name="Generate" value=" Generate " onclick="genSal()">
											
											</td>
											
										</tr>
				  <tr>
                    <td colspan="6" width="100%">
                    <p align="center">
                    <OBJECT id=mfgSal style="LEFT: 0px; WIDTH: 850px; TOP: 0px; HEIGHT: 350px" 
	height=350 width=850 classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" name=mfgSal VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="18494">
	<PARAM NAME="_ExtentY" VALUE="2699">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="7">
	<PARAM NAME="ColWidth0" VALUE="810">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE="<Sno         |<Dir ID         |<DirName                                                          |>BOM Salary      |^TDSYN           |>    TDSAmount      |^ExecutionYN  ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="1">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="1">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Sno">
	<PARAM NAME="TextMatrix0" VALUE="Sno">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
                    </p>
                    </td>
                  </tr>
                  <tr>
					<td width="100%" height=50 colspan=6> &nbsp;
					</td>
				</tr>
				</table>  
	</td>
              </tr>
            </table>

            </center>
          
	<table width="100%" cellspacing="0" cellpadding="0"   class="tablebordermain" align=center>
	
		<tr>
			<td width="100%" align=center ><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input name="cmdok" type="button" value="   Post   " class="button" onclick="Ok();"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmBOMSalaryGen.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
		</tr>
		
  </table>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
	
	<input type="hidden" name="hdnsalmon">
	<input type="hidden" name="hdnsalyear">
	
	<input type="hidden" name="hdndbltotBOMSal">
	<input type="hidden" name="hiddirid">
	<input type="hidden" name="hdnmeetdtls">
	<input type="hidden" name="hreport">
    <input type="hidden" name="reptitle">
	<input type="hidden" name="hdnBOMSalDtls">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDetails.aspx"></iframe>
    </form>

  </body>
</html>					