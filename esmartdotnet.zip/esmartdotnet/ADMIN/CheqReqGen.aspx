<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CheqReqGen.aspx.vb" Inherits="eSmartDotNet.CheqReqGen"%>

<%
	dim ObjCust 
	dim strmsg
	dim brcode,curcode,modcode,glcode,accno,inscode,custcode,custname,rtype,chqtype 'to store textbox values
	dim startno,endno,chqno,bkorlf,noofleafs,appdate,userid,machineid,sysdate,appby,appmachine,sysyear
	dim strvalue,res,res1,chno,strmode,strval
	DIM TOCHNO 
	dim strmsttab
	
	dim obj1,rs1
	
	obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
	rs1=server.CreateObject("adodb.recordset")
	
	appdate=cstr(session("applicationdate"))
	userid=cstr(session("userid"))
	machineid=cstr(session("machineid"))
	
	strmode=Request.Form("mercust")
	strval=split(strmode,"~")
	
	Dim ObjTrans,strResult
	ObjTrans=server.CreateObject("GeneralTransactions.DBTransactions")	
	Dim arrTrans(4,4)
	Dim i,j
	Dim tranno
	
	brcode = strval(3)
	
	'strval(1)
	'modcode = strval(2)
		
	if strval(0)="FILEGEN" then
	
	
		rs1 = obj1.SingleRecordSet("DUAL","TO_CHAR(TO_DATE('" & appdate & "','DD-Mon-YYYY'), 'YYYYMMDD') date1","")
	
		if not rs1.EOF and not rs1.BOF then
					
			stReqDt  = rs1(0).value
		
		end if
		
		ArrTrans(0,0)="U" 
		ArrTrans(0,1)="CHQREQSTDTLS"
		ArrTrans(0,2)="AF2GENDATE"
		ArrTrans(0,3)="'" & stReqDt & "'"
		ArrTrans(0,4)="TRANSTATUS='A' AND STATUS='R' and AF2GENDATE is null " & strval(1) & " " & strval(2) & " "
		
		
		
		StrResult=ObjTrans.DataTransactions(arrTrans,cstr(brcode),cstr(userid),cstr(machineid),cstr(appdate),"Y")
		
		Response.Redirect ("frmCheqRestGen.aspx?record=" & StrResult & "~" & strval(1) & "#" & strval(2)& "|" & strval(0))
	
	
	else if strval(0)="BCGEN" then
	
	
		rs1 = obj1.SingleRecordSet("DUAL","TO_CHAR(TO_DATE('" & appdate & "','DD-Mon-YYYY'), 'YYYYMMDD') date1","")
	
		if not rs1.EOF and not rs1.BOF then
					
			stReqDt  = rs1(0).value
		
		end if
		
		ArrTrans(0,0)="U" 
		ArrTrans(0,1)="BCREQSTDTLS"
		ArrTrans(0,2)="AF2GENDATE"
		ArrTrans(0,3)="'" & stReqDt & "'"
		ArrTrans(0,4)="TRANSTATUS='A' AND STATUS='R' and AF2GENDATE is null " & strval(1) & " " 
		
		StrResult=ObjTrans.DataTransactions(arrTrans,cstr(brcode),cstr(userid),cstr(machineid),cstr(appdate),"Y")
		
		Response.Redirect ("frmCheqRestGen.aspx?record=" & StrResult & "~" & strval(1) & "|" & strval(0))
	
	else if strval(0)="GENYNSTAT" then
		
		ArrTrans(0,0)="U" 
		ArrTrans(0,1)="CHQREQSTDTLS"
		ArrTrans(0,2)="GENYN"
		ArrTrans(0,3)="'Y'"
		ArrTrans(0,4)="TRANSTATUS='A' AND STATUS='R' and AF2GENDATE is not null " & strval(1) & " " & strval(2) & " "
		
		
		
		StrResult=ObjTrans.DataTransactions(arrTrans,cstr(brcode),cstr(userid),cstr(machineid),cstr(appdate),"Y")
		
		if mid(StrResult,1,21)="Transaction Sucessful"
			StrResult="Sucessful."
		end if
		Response.Redirect ("frmCheqRestGen.aspx?record=" & StrResult & "|" & strval(0) )
		
		else if strval(0)="BCGENYNSTAT" then
		
		ArrTrans(0,0)="U" 
		ArrTrans(0,1)="BCREQSTDTLS"
		ArrTrans(0,2)="GENYN"
		ArrTrans(0,3)="'Y'"
		ArrTrans(0,4)="TRANSTATUS='A' AND STATUS='R' and AF2GENDATE is not null " & strval(1) & " " 
		
		StrResult=ObjTrans.DataTransactions(arrTrans,cstr(brcode),cstr(userid),cstr(machineid),cstr(appdate),"Y")
		
		if mid(StrResult,1,21)="Transaction Sucessful"
			StrResult="Sucessful."
		end if
		Response.Redirect ("frmCheqRestGen.aspx?record=" & StrResult  & "|" & strval(0))

	end if

%>
