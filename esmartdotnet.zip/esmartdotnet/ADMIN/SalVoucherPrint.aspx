<%@ Page Language="vb"  aspcompat="true" explicit="false"  AutoEventWireup="false" Codebehind="SalVoucherPrint.aspx.vb" Inherits="eSmartDotNet.SalVoucherPrint"%>

<HTML>
  <HEAD>
		<title>Salary Voucher Print</title>
<%

dim strQs=split(Request.QueryString("strVal"),"|")

if strQs(4)="XL" then
	Response.ContentType = "application/vnd.ms-excel"
	Response.AddHeader ("Content-Disposition","attachment;filename=" & "Voucher.xls")
end if

dim rsGrpCode, objGrpCode, rsaddress, objfetch, rsbr, rsDt,rsDt1, objDt, objGL, rsAppDt, objAppDt
dim strSqlGroup, strval, branchcode, scroltype, appdate, strTable,  currency3, strDt, strSysDt, result, strRepType, strBrCodeCons, strAppDt, strApplDate,repType,apdat,stBat
dim strGrandDr, strGrandCr as double
dim intRowCnt, intPageCnt as integer
dim stSeMon,stSeYear 
dim strsbDr,strclDr,strotDr, strsbCr,strclCr,strotCr as double
rsGrpCode = server.CreateObject("adodb.recordset")
objGrpCode =server.CreateObject("ReportPurposeOnly.Reportonly")
rsHeads = server.CreateObject("adodb.recordset")
objHeads =server.CreateObject("ReportPurposeOnly.Reportonly")
rsDt=server.CreateObject("adodb.recordset")
rsDt1=server.CreateObject("adodb.recordset")
objDt=server.CreateObject("ReportPurposeOnly.Reportonly")
rsBrCode=server.CreateObject("adodb.recordset")
objBrCode=server.CreateObject("ReportPurposeOnly.Reportonly")
rsLnsb=server.CreateObject("adodb.recordset")
objLnsb=server.CreateObject("ReportPurposeOnly.Reportonly")
rsDpsb=server.CreateObject("adodb.recordset")
objDpsb=server.CreateObject("ReportPurposeOnly.Reportonly")
rsNme=server.CreateObject("adodb.recordset")
objNme=server.CreateObject("ReportPurposeOnly.Reportonly")
rsRNme=server.CreateObject("adodb.recordset")
objRNme=server.CreateObject("ReportPurposeOnly.Reportonly")

objGL=server.CreateObject("GL.DailyReports")



apdat = cstr(ucase(session("applicationdate")))

crAmt=0
drAmt=0
crsb=0
crcl=0
crot=0
drsb=0
drcl=0
drot=0
strGrandDr=0
strGrandCr=0
intRowCnt=1
intPageCnt=1

branchcode = strQs(1)

rsaddress=server.CreateObject("adodb.recordset")
objfetch =server.CreateObject("queryrecordsets.fetchrecordsets")

rsaddress=objfetch.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & branchcode & "' and a.bankcode=b.bankcode")

rsbr = objfetch.singlerecordset("genbankbranchmst","branchcode,ADDR1", "branchcode='"& branchcode &"'")

totassests=0
totliabilities=0
totexpenses=0
totincome=0

if strQs(0) = "Reprint" then 

obj2= SERVER.CreateObject("GeneralTransactions.DBTransactions")
rscnt = Server.CreateObject("adodb.recordset")
Dim ArrTran(2,4)
p=0

dim strRes,sqlStr,Strmsg


stSeMon = strQs(2)
stSeYear = strQs(3)

strHeads = ""

strHeads=" SELECT paidbatch, TO_CHAR(applicationdate,'DD-MON-YYYY')apdat FROM salarypaiddtls WHERE paidmonth='" & stSeMon & "' AND paidyear='" & stSeYear & "' AND branchcode='" & branchcode & "' GROUP BY applicationdate, paidbatch "
					
			rsGrpCode = objGrpCode.SingleSelectStat(strHeads)
			if objGrpCode.ConnError="Connected" then
				if not rsGrpCode.bof and not rsGrpCode.eof then
					do until rsGrpCode.eof
					
					stBat = rsGrpCode(0).value
					appdate = rsGrpCode(1).value
					
					if apdat = appdate then
						strTable = "GENTRANSLOG"
					else
						strTable = "GENTRANSLOGBKP" 
					end if
					
					strHeads = ""
					
					strHeads=" SELECT glcode,accno,SUBSTR(name,0,25), (CASE WHEN balance<0 THEN balance ELSE NULL END) DrAmt ,(CASE WHEN balance>0 THEN balance ELSE NULL END) CrAmt FROM ( SELECT glcode,accno,name , SUM(amount) balance FROM " & strTable & " WHERE batchno='" & stBat & "' AND  APPLICATIONDATE='" & appdate & "' AND Branchcode = '" & branchcode & "' GROUP BY glcode,accno, name ORDER BY SUM(amount)) sal"
					
					rsRNme = objRNme.SingleSelectStat(strHeads)
					if objRNme.ConnError="Connected" then
						if not rsRNme.bof and not rsRNme.eof then
							do until rsRNme.eof
							
								strRes = strRes & "'" & branchcode & "','" & rsRNme(0).value & "','" & rsRNme(1).value & "','" & rsRNme(2).value & "','" & rsRNme(3).value & "','" & rsRNme(4).value & "'|"
							
							rsRNme.movenext()
							loop
						end if
					end if
					
					rsGrpCode.movenext()
					loop
					
				end if
			end if
			
			if strRes <> "" then
				strRes = mid(strRes,1,strRes.length-1)
				
				sqlStr = " SELECT count(*) cnt FROM REVOUCHERTEMP "
				
				rsNme=server.CreateObject("adodb.recordset")
				objNme=server.CreateObject("ReportPurposeOnly.Reportonly")
				
				rsNme = objNme.SingleSelectStat(sqlStr)
					if objNme.ConnError="Connected" then
						if not rsNme.bof and not rsNme.eof then
						
							if rsNme(0).value > 0 then
							
								ArrTran(p,0)="D"			
								ArrTran(p,1)="REVOUCHERTEMP"
								ArrTran(p,2)=""
								ArrTran(p,3)=""
								ArrTran(p,4)="BRANCHCODE='" & branchcode & "'"
								
								Strmsg = obj2.DataTransactions(ArrTran)
								
								if Strmsg = "Transaction Sucessful."  then
									
									ArrTran(p,0)="I"			
									ArrTran(p,1)="REVOUCHERTEMP"
									ArrTran(p,2)="BRANCHCODE,GLCODE, ACCNO, NAME, DRAMT, CRAMT"
									ArrTran(p,3)=strRes
									ArrTran(p,4)=""
									
									Strmsg1 = obj2.DataTransactions(ArrTran)
								
								end if
							else
							
								ArrTran(p,0)="I"			
								ArrTran(p,1)="REVOUCHERTEMP"
								ArrTran(p,2)="BRANCHCODE,GLCODE, ACCNO, NAME, DRAMT, CRAMT"
								ArrTran(p,3)=strRes
								ArrTran(p,4)=""
								
								Strmsg1 = obj2.DataTransactions(ArrTran)
								
							end if
						end if
					end if
				
			end if
	
end if 
%>
<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="Visual Basic .NET 7.1" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<style>.break { page-break-after: always }
	</style>
		<script language =javascript>
		
		function HandleBackFunctionality()
{
    if(window.event)
   {
        if(window.event.clientX < 40 && window.event.clientY < 0)
        {
		var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
        }
        else
        {
         //   alert("Browser refresh button is clicked...");
        }
    }
    else
    {
        if(event.currentTarget.performance.navigation.type == 1)
        {
          //   alert("Browser refresh button is clicked...");
     
        }
        if(event.currentTarget.performance.navigation.type == 2)
        {
           //  alert("Browser back button is clicked...");
                var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
        }
    }
}


function notAllowed()
{
//alert(event.keyCode)

   if(event.ctrlKey)
  {

    event.keyCode=0;
    return false;
  }
  if(parseInt(event.button)==2 ||parseInt(event.button)==3 )
  {
   alert("This Operation Is Not Allowed");
    return false;     
  }
} 


    function prnt()
	{
		window.document.all['divPrnt'].style.display="none";
		window.print()
		window.document.all['divPrnt'].style.display="block";
	}
	
	function SelCopy(){
    var copysuccess // var to check whether execCommand successfully executed
    try{
        copysuccess = document.execCommand("copy") // run command to copy selected text to clipboard
    } catch(e){
        copysuccess = false
    }
    return copysuccess
}

function selectText(containerid) 
{
    if (document.selection) {
        var range = document.body.createTextRange();
        range.moveToElementText(document.getElementById(containerid));
        range.select();
    } else if (window.getSelection()) {
        var range = document.createRange();
        range.selectNode(document.getElementById(containerid));
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
    }
}
		</script>
</HEAD>
	<body leftMargin="0" topMargin="0" onmousedown="notAllowed();" onkeydown="notAllowed();" onbeforeunload="HandleBackFunctionality();" >
			<form name="frmVoucher">
		<div id = "divselcopy">
			<table width="100%" border=0>
				<tr>
					<td align="center" width="100%" colSpan="4">
						<%''''' Report Headings%>
						<center><font color="#000000" size="3">
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
							</font>
							<br>
							<font color="#000000" size="3">
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value) & "," & iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
							</font>
							<br>
							<font color="#000000" size="3">
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
							</font>
						</center>
					</td>
				</tr>
			</table>
			<table width="100%">
				<tr>
					<td align="center" colSpan="2"><font face="courier new" color="#000000" size="2"><%=strRepTitle%><%=appdate%></font></td>
				</tr>
				<tr>
					<td align="left" width="50%"><font face="courier new" color="#000000" size="2">User ID&nbsp;:&nbsp;<%=session("userid")%></font></td>
					<td align="right" width="50%"><font face="courier new" color="#000000" size="2">Branch Code&nbsp;:&nbsp;
							<%=branchcode%>
						</font>
					</td>
				</tr>
			</table>
			<% if strQs(0) = "Reprint" then %>
			<table width="100%">
				<tr>
					<td align="center" colSpan="2"><font face="courier new" color="#000000" size="2">Salary Paid Voucher For The Month of <%=stSeMon%>  <%=stSeYear%></font></td>
				</tr>
			</table>
			
			<% end if%>
			<table width="100%" border="0">
				<tr>
					<td colSpan="5" width="100%"><font face="courier new" color="#000000" size="2">-----------------------------------------------------------------------------------------------</font></td>
				</tr>
				<tr>
					<td width="5%" align="left"><font face="courier new" color="#000000" size="2">GLCODE</font></td>
					<td width="10%" align="left"><font face="courier new" color="#000000" size="2">ACC NO</font></td>
					<td width="15%" align="left"><font face="courier new" color="#000000" size="2">NAME </font></td>
					<td width="10%" align="right"><font face="courier new" color="#000000" size="2">DR Amt </font></td>
					<td width="10%" align="right"><font face="courier new" color="#000000" size="2">CR Amt</font></td>
				</tr>
				<tr>
					<td colSpan="5" width="100%"><font face="courier new" color="#000000" size="2">-----------------------------------------------------------------------------------------------</font></td>
				</tr>
			<%
				
				if strQs(0) = "Reprint" then 
				
					if Strmsg1 = "Transaction Sucessful." then
						strHeads = " SELECT glcode, accno, name, SUM(Dramt) DrBal, SUM(Cramt) cRBal FROM REVOUCHERTEMP  where BRANCHCODE='" & branchcode & "' GROUP BY glcode,accno, name ORDER BY SUM(Dramt) "
					end if
					
				
				else
					
					branchcode = strQs(1)
					appdate = ucase(strQs(2))
					stBat = strQs(3)
					
					if apdat = appdate then
						strTable = "GENTRANSLOG"
					else
						strTable = "GENTRANSLOGBKP" 
					end if
					
					strHeads=" SELECT glcode,accno,SUBSTR(name,0,25), (CASE WHEN balance<0 THEN balance ELSE NULL END) DrAmt ,(CASE WHEN balance>0 THEN balance ELSE NULL END) CrAmt FROM ( SELECT glcode,accno,name , SUM(amount) balance FROM " & strTable & " WHERE batchno='" & stBat & "' AND  APPLICATIONDATE='" & appdate & "' AND Branchcode = '" & branchcode & "' GROUP BY glcode,accno, name ORDER BY SUM(amount)) sal"
				
				end if
					
					
			rsHeads = objHeads.SingleSelectStat(strHeads)
			if objHeads.ConnError="Connected" then
				if not rsHeads.bof and not rsHeads.eof then
					do until rsHeads.eof
					
					%>
						<tr>
							<td width="5%" align="left"><font face="courier new" color="#000000" size="2"><%=rsHeads(0).value%></font></td>
							<td width="10%" align="left"><font face="courier new" color="#000000" size="2"><%=rsHeads(1).value%></font></td>
							<td width="15%" align="left"><font face="courier new" color="#000000" size="2"><%=rsHeads(2).value%></font></td>
							<td width="10%" align="right"><font face="courier new" color="#000000" size="2"><%=rsHeads(3).value%></font></td>
							<td width="10%" align="right"><font face="courier new" color="#000000" size="2"><%=rsHeads(4).value%></font></td>
						</tr>
					
					
					<%				
					
					If IsDbNull(rsHeads(3).value) Then
						drAmt=0
					else
						drAmt=rsHeads(3).value
					end if
					
					If IsDbNull(rsHeads(4).value) Then
						crAmt=0
					else
						crAmt=rsHeads(4).value
					end if
					
					strGrandDr = strGrandDr + Math.Abs(cdbl(drAmt))
					strGrandCr =  strGrandCr + Math.Abs(cdbl(crAmt))
					
					rsHeads.movenext()
					loop
				
				else
				%>
					<tr>
							<td colSpan="5" width="100%"><font face="courier new" color="#000000" size="2">No Records Found </font></td>
					</tr>	
				<%
				end if
			rsHeads=nothing				 
			
		end if
		objHeads=nothing
		rsHeads=nothing
		
		%>
			<tr>
				<td colSpan="5" width="100%"><font face="courier new" color="#000000" size="2">-----------------------------------------------------------------------------------------------</font></td>
			</tr>
			<tr>
				<td width="5%" align="left"><font face="courier new" color="#000000" size="2"></font></td>
				<td width="10%" align="left"><font face="courier new" color="#000000" size="2"></font></td>
				<td width="15%" align="left"><font face="courier new" color="#000000" size="2">Total : </font></td>
				<td width="10%" align="right"><font face="courier new" color="#000000" size="2"><%=strGrandDr%></font></td>
				<td width="10%" align="right"><font face="courier new" color="#000000" size="2"><%=strGrandCr%></font></td>
			</tr>
	</table>
	<table align=center width = "100%" >
		<tr>
			<td align =center >
			<div id="divPrnt">
			<input type="button" value="  Select All   " name="butSelectAll" onclick="selectText('divselcopy')" class="button">
			<input type="button" value="  Copy   " name="butCopy" onclick="SelCopy()" class="button"><input onclick="prnt()" type="button" value="  Print   " name="butprnt"><input class="bgcolor" onclick="location.href='frmSalgenerate.aspx'" type="button" value="   Exit   "
											name="butok"></div>
			</td>
		</tr>
	</table>
		</form>
	</body>
			
</head>



		