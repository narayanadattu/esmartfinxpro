<%@ Page Language="vb" AutoEventWireup="false" aspcompat="true" explicit="false" Codebehind="frmCDparameter.aspx.vb" Inherits="eSmartDotNet.frmCDparameter" %>
<% dim strmessage

	strmessage=Request.QueryString("record") %>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
    <title>CD parameter</title>
    <SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
  
	<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
	
	function ShowDivision(str)
	{
		window.document.frmCdparm.mfgCDparm.Rows=1
		window.document.all.divCDparm.style.display="none"
		window.document.frmCdparm.mfgCRRSLRparm.Rows=1
		window.document.all.divCRRSLRparm.style.display="none"
		
		if(str=='0')
		{
			window.document.all.divCDparm.style.display="block"
			window.document.all.divCRRSLRparm.style.display="none"
		}
		
		if(str=='1')
		{
			window.document.all.divCDparm.style.display="none"
			window.document.all.divCRRSLRparm.style.display="block"
		}
		
		
	}
	
	function control()
	{
		window.document.frmCdparm.mfgCDparm.Rows=1
		window.document.frmCdparm.txtModId.value=""
		window.document.frmCdparm.txtModNm.value=""
		window.document.frmCdparm.txtGLcode.value=""
		window.document.frmCdparm.txtGLname.value=""
		window.document.frmCdparm.cmbCDFag.value=""
		window.document.frmCdparm.chkGlcd.disabled=false
		
		if(window.document.frmCdparm.optmode(0).checked==true)
		{
			window.document.frmCdparm.chkGlcd.disabled=false
		}
		if(window.document.frmCdparm.optmode(1).checked==true)
		{
			window.document.frmCdparm.chkGlcd.disabled=true
		}
		if(window.document.frmCdparm.optmode(2).checked==true)
		{
			window.document.frmCdparm.chkGlcd.disabled=true
		}
		
	}
	
	function module()
	{ 
		if(window.document.all.divCDparm.style.display=="block")
		{
			window.document.frmCdparm.txtModNm.value=""
			window.document.frmCdparm.txtModId.value=""
			stbr="<%=session("branchcode")%>"
			
			if(window.document.frmCdparm.optmode(0).checked==true)
			{
				stmod="TellCDmodule"; 
			}
			else
			{
				stmod="CDTellmodule"; 
			}
			
		}
		
		kstr=stmod+"|"+stbr
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
		
	}
	
	function modulecode(kstr)
	{
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divCDparm.style.display=="block")
		{
			window.document.frmCdparm.txtModNm.value=StrFld[0]
			window.document.frmCdparm.txtModId.value=StrFld[1]
			
			window.document.frmCdparm.txtGLcode.value=""
			window.document.frmCdparm.txtGLname.value=""
			window.document.frmCdparm.cmbCDFag.value=""
		}
		
	}
	function Glcode()
	{ 
		
		
		if(window.document.all.divCDparm.style.display=="block")
		{
			if(window.document.frmCdparm.txtModId.value=="")
			{
				alert("Please Select Module id")
				return;
			}
			else
			{
				brcode = "<%=session("branchcode")%>"
				modid = window.document.frmCdparm.txtModId.value.toUpperCase();
			}
			
			if(window.document.frmCdparm.optmode(0).checked==true)
			{
				telgl="TellCDglcode";
			}
			else
			{
				telgl="CDTellglcode";
			}
		}
		
		kstr=telgl+"|"+brcode+"|"+modid
		
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	}
	
	function Glcodeid(kstr)
	{ 
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divCDparm.style.display=="block")
		{
			window.document.frmCdparm.txtGLcode.value=StrFld[1]
			window.document.frmCdparm.txtGLname.value=StrFld[0]
			
			window.document.frmCdparm.cmbCDFag.value=""
			
			if((window.document.frmCdparm.optmode(1).checked==true) ||(window.document.frmCdparm.optmode(2).checked==true))
			{
				var strVal
				
				strVal="CDRATIO"+"|"+window.document.frmCdparm.txtModId.value.toUpperCase()+"|"+window.document.frmCdparm.txtGLcode.value
				
				window.document.all['iVinFrame'].src="../gen/getDtls.aspx?st="+strVal;
			}
		}
	}
	
	function popCdrat(str)
	{
		window.document.frmCdparm.cmbCDFag.value=str
	}
	
	function AddToGrid()
	{
		if(window.document.frmCdparm.txtModId.value=="")
		{
			alert("Please Select Module Id")
			window.document.frmCdparm.B1.focus();
			return;
		}
		if(window.document.frmCdparm.chkGlcd.checked==false)
		{
			if(window.document.frmCdparm.txtGLcode.value=="")
			{
				alert("Please select Gl Code")
				window.document.frmCdparm.B2.focus();
				return;
			}
		}
		if(window.document.frmCdparm.cmbCDFag.value=="")
		{
			alert("Please Select Flag")
			window.document.frmCdparm.cmbCDFag.focus();
			return;
		}
		
		window.document.frmCdparm.mfgCDparm.cols=4;
		window.document.frmCdparm.mfgCDparm.formatstring="<Slno   |<Module Id        |<Glcode        |<Flag    ;";
		
		
		if(window.document.frmCdparm.chkGlcd.checked==true)
		{
			var mod
			
			mod = window.document.frmCdparm.txtModId.value.toUpperCase()
			
			window.document.all['iBatch1'].src="../gen/glcodes.aspx?st=ALLGLCODES"+"~"+mod
		}
		else
		{
			addGrid()
		}
	}
	
	function addGrid()
	{
		var cnt
		
		cnt = 0
		
		rowidx = window.document.frmCdparm.mfgCDparm.rows;
		
		if(window.document.frmCdparm.mfgCDparm.rows > "1")
		{
			for(i=1;i<window.document.frmCdparm.mfgCDparm.rows;i++)
			{
				if((window.document.frmCdparm.txtModId.value.toUpperCase()==window.document.frmCdparm.mfgCDparm.textmatrix(i,1))&&(window.document.frmCdparm.txtGLcode.value.toUpperCase()==window.document.frmCdparm.mfgCDparm.textmatrix(i,2)))
				{
					alert("Already added")
					return;
				}
			}
		}
		
		cnt = rowidx
		
		window.document.frmCdparm.mfgCDparm.rows =  
				window.document.frmCdparm.mfgCDparm.rows+1;
				
				
		window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,0)=cnt //sl no
		window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,1)=
					window.document.frmCdparm.txtModId.value.toUpperCase();//moduleid
		window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,2)=
					window.document.frmCdparm.txtGLcode.value.toUpperCase();//glcode
		window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,3)=
					window.document.frmCdparm.cmbCDFag.value.toUpperCase(); //CD flag
		clear()
	}
	
	function glcodereturn(strGlCodes)
	{
	if(window.document.all.divCDparm.style.display=="block")
		{
			if (strGlCodes=="NOTEXISTS")
			{
				alert("No GlCodes Were Found")
			}
			else
			{
				FillDataIntoGrid(strGlCodes)
			}
		}
		
		if(window.document.all.divCRRSLRparm.style.display=="block")
		{
			if (strGlCodes=="NOTEXISTS")
			{
				alert("No GlCodes Were Found")
			}
			else
			{
				FillDataIntoGridCRRSLR(strGlCodes)
			}
		}
		
	}
	function FillDataIntoGrid(strGlCodes)
	{
		var arrglcodes,rowidx,count
		
		count = 0
		
		arrglcodes = strGlCodes.split("~");
		//alert(arrglcodes)
		var len = arrglcodes.length;
		//alert(len)
		
		rowidx=window.document.frmCdparm.mfgCDparm.rows;
		
		if(window.document.frmCdparm.mfgCDparm.rows > "1")
		{
			for(i=1;i<window.document.frmCdparm.mfgCDparm.rows;i++)
			{
				
				for(j=0;j<len-1;j++)
				{
					if(arrglcodes[j]==window.document.frmCdparm.mfgCDparm.textmatrix(i,2))
					{
						alert("Already added")
						return;
					}
				}
			}
			for(icnt=1;icnt<=window.document.frmCdparm.mfgCDparm.rows-1;icnt++)
			{
				for(jcnt=0;jcnt<=window.document.frmCdparm.mfgCDparm.Cols-1;jcnt++)
				{
					if(jcnt==0)
					{
						count = window.document.frmCdparm.mfgCDparm.TextMatrix(icnt,jcnt)
					}
					
				}
			}
		}
		
		count = parseInt(count)+1
			
		window.document.frmCdparm.mfgCDparm.rows = window.document.frmCdparm.mfgCDparm.rows+1;
		
		for(idx=0;idx<arrglcodes.length;idx++)
		{
			if(arrglcodes[idx]!="")
			{
				if((window.document.frmCdparm.mfgCDparm.rows-1) < rowidx)
				{
					window.document.frmCdparm.mfgCDparm.rows = window.document.frmCdparm.mfgCDparm.rows+1;			
				}
				
				window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,0) = parseInt(count) //slno
				window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,1) = window.document.frmCdparm.txtModId.value.toUpperCase(); //module id
				window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,2) = arrglcodes[idx].toUpperCase();//glcode
				window.document.frmCdparm.mfgCDparm.TextMatrix(rowidx,3) = window.document.frmCdparm.cmbCDFag.value.toUpperCase();
			
			rowidx = rowidx + 1
			count = count + 1
			}
		}
		
		clear()
		
	}
	
	function clear()
	{
		window.document.frmCdparm.txtModId.value=""
		window.document.frmCdparm.txtModNm.value=""
		window.document.frmCdparm.txtGLcode.value=""
		window.document.frmCdparm.txtGLname.value=""
		window.document.frmCdparm.cmbCDFag.value=""
	}
	
	function subtrans()
	{
		var mod=""
		var StrCols=""
		var StrColRow=""
		var StrCol=""
		var userid="'"+'<%=session("userid")%>'+"'"
		var macid="'"+'<%=session("machineid")%>'+"'"
		var status
		var appdat= "'"+'<%=session("applicationdate")%>'+"'"
		
		if(window.document.all.divCDparm.style.display=="block")
		{
			if(window.document.frmCdparm.mfgCDparm.rows > "1")
			{
				if(window.document.frmCdparm.optmode(0).checked==true)
				{
					status="'R'"
					
					window.document.frmCdparm.hmode.value="INSERT"+"|"+"CDPARM"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCDparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCDparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCDparm.TextMatrix(icnt,jcnt)+ "'" + ","
						}
						
						StrCols=StrCols+status+","+appdat+","+userid+","+macid+","
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
				if(window.document.frmCdparm.optmode(1).checked==true)
				{
					status="'R'"
					
					window.document.frmCdparm.hmode.value="MODIFY"+"|"+"CDPARM"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCDparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCDparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCDparm.TextMatrix(icnt,jcnt)+ "'" + "~"
						}
						
						StrCols=StrCols+status+"~"+appdat+"~"+userid+"~"+macid+"~"
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
				if(window.document.frmCdparm.optmode(2).checked==true)
				{
					status="'C'"
					
					window.document.frmCdparm.hmode.value="DELETE"+"|"+"CDPARM"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCDparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCDparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCDparm.TextMatrix(icnt,jcnt)+ "'" + "~"
						}
						
						StrCols=StrCols+status+"~"+appdat+"~"+userid+"~"+macid+"~"
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
			}
			else
			{
				alert("Please Enter the Values To Grid")
				return;
			}
		}
		
		
		if(window.document.all.divCRRSLRparm.style.display=="block")
		{
			if(window.document.frmCdparm.mfgCRRSLRparm.rows > "1")
			{
				if(window.document.frmCdparm.optCRRSLRmode(0).checked==true)
				{
					status="'R'"
					
					window.document.frmCdparm.hmode.value="INSERT"+"|"+"CRRSLR"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCRRSLRparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCRRSLRparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(icnt,jcnt)+ "'" + ","
						}
						
						StrCols=StrCols+status+","+appdat+","+userid+","+macid+","
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
				if(window.document.frmCdparm.optCRRSLRmode(1).checked==true)
				{
					status="'R'"
					
					window.document.frmCdparm.hmode.value="MODIFY"+"|"+"CRRSLR"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCRRSLRparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCRRSLRparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(icnt,jcnt)+ "'" + "~"
						}
						
						StrCols=StrCols+status+"~"+appdat+"~"+userid+"~"+macid+"~"
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
				if(window.document.frmCdparm.optCRRSLRmode(2).checked==true)
				{
					status="'C'"
					
					window.document.frmCdparm.hmode.value="DELETE"+"|"+"CRRSLR"
					
					for(icnt=1;icnt<=window.document.frmCdparm.mfgCRRSLRparm.rows-1;icnt++)
					{
						StrCols=""
						for(jcnt=1;jcnt<=window.document.frmCdparm.mfgCRRSLRparm.cols-1;jcnt++)
						{
							StrCols=StrCols + "'" + window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(icnt,jcnt)+ "'" + "~"
						}
						
						StrCols=StrCols+status+"~"+appdat+"~"+userid+"~"+macid+"~"
						StrCols=StrCols.substr(0,StrCols.length-1)
						StrColRow=StrColRow+StrCols+"|"
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
			}
			else
			{
				alert("Please Enter The Values To Grid")
				return;
			}
		}
		
		//alert(" StrColRow = "+StrColRow)
		window.document.frmCdparm.mercust.value=StrColRow
		window.document.frmCdparm.action="CDparmInsert.aspx"
		window.document.frmCdparm.method="post"   
		window.document.frmCdparm.submit()
	}
	
	function DispTranMsg()
	{
		if('<%=strmessage%>'!="")
		{
			var mess="<%=strmessage%>"
			alert(mess)
			location.replace("../ADMIN/frmCDparameter.aspx")
		}
	}
	
	function chkAllgl()
	{
		window.document.frmCdparm.txtGLcode.value=""
		window.document.frmCdparm.txtGLname.value=""
		if(window.document.frmCdparm.chkGlcd.checked==true)
		{
			window.document.frmCdparm.B2.disabled=true
			
		}
		else
		{
			window.document.frmCdparm.B2.disabled=false
		}
	}
	
	/*   Start CRR SLR   */
	
	function chkAllglCRRSLR()
	{
		window.document.frmCdparm.txtCRRSLRGLcode.value=""
		window.document.frmCdparm.txtCRRSLRGLname.value=""
		if(window.document.frmCdparm.chkCRRSLRGlcd.checked==true)
		{
			window.document.frmCdparm.B2CRRSLR.disabled=true
			
		}
		else
		{
			window.document.frmCdparm.B2CRRSLR.disabled=false
		}
	}
	
function moduleCRRSLR()
{

	if(window.document.all.divCRRSLRparm.style.display=="block")
		{
		
			window.document.frmCdparm.txtCRRSLRModNm.value=""
			window.document.frmCdparm.txtCRRSLRModId.value=""
			stbr="<%=session("branchcode")%>"
			
			if(window.document.frmCdparm.optCRRSLRmode(0).checked==true)
			{
				stmod="CRRSLRmodule"; 
			}
			else
			{
				stmod="ModCRRSLRmodule"; 
			}
		
		kstr=stmod+"|"+stbr
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");	
		}


		}


	function modulecodeCRRSLR(kstr)
	{
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divCRRSLRparm.style.display=="block")
		{
			window.document.frmCdparm.txtCRRSLRModNm.value=StrFld[0]
			window.document.frmCdparm.txtCRRSLRModId.value=StrFld[1]
			
			window.document.frmCdparm.txtCRRSLRGLcode.value=""
			window.document.frmCdparm.txtCRRSLRGLname.value=""
			window.document.frmCdparm.cmbCRRSLRFag.value=""
			window.document.frmCdparm.cmbCRRSLRSubType.value=""
		}
		
	}
	
	
	function GlcodeCRRSLR()
	{ 
	
		if(window.document.all.divCRRSLRparm.style.display=="block")
		{
			if(window.document.frmCdparm.txtCRRSLRModId.value=="")
			{
				alert("Please Select Module id")
				return;
			}
			else
			{
				brcode = "<%=session("branchcode")%>"
				modid = window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase();
			}
		
			if(window.document.frmCdparm.optCRRSLRmode(0).checked==true)
			{
				telgl="CRRSLRglcode";
			}
			else
			{
				telgl="ModCRRSLRglcode";
			}
	
		
		kstr=telgl+"|"+brcode+"|"+modid
		
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:480px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px");
		}
	}
	
	function GetGlcodeCRRSLR(kstr)
	{ 
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divCRRSLRparm.style.display=="block")
		{
			window.document.frmCdparm.txtCRRSLRGLcode.value=StrFld[1]
			window.document.frmCdparm.txtCRRSLRGLname.value=StrFld[0]
			
			window.document.frmCdparm.cmbCRRSLRFag.value=""
			
			if((window.document.frmCdparm.optCRRSLRmode(1).checked==true) ||(window.document.frmCdparm.optCRRSLRmode(2).checked==true))
			{
				var strVal
				
				strVal="CRRSLR"+"|"+window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase()+"|"+window.document.frmCdparm.txtCRRSLRGLcode.value
				
				window.document.all['iVinFrame'].src="../gen/getDtls.aspx?st="+strVal;
			}
		}
	}
	
	function popCRRSLRrat(str)
	{
	var StrFld=new String()
		StrFld=str.split("|")
		window.document.frmCdparm.cmbCRRSLRFag.value=StrFld[0]
		window.document.frmCdparm.cmbCRRSLRSubType.value=StrFld[1]
		
		if (StrFld[0] == "CRR") 
		{
		window.document.frmCdparm.cmbCRRSLRSubType.disabled = true
		}
		else
		{
		window.document.frmCdparm.cmbCRRSLRSubType.disabled = false
		}
	}

	function SetSubType()
	{
		if (window.document.frmCdparm.cmbCRRSLRFag.value == "CRR") 
		{
		window.document.frmCdparm.cmbCRRSLRSubType.disabled = true
		}
		else
		{
		window.document.frmCdparm.cmbCRRSLRSubType.disabled = false
		}
	}


	function AddToGridCRRSLR()
	{
		if(window.document.frmCdparm.txtCRRSLRModId.value=="")
		{
			alert("Please Select Module Id")
			window.document.frmCdparm.B1CRRSLR.focus();
			return;
		}
		if(window.document.frmCdparm.chkCRRSLRGlcd.checked==false)
		{
			if(window.document.frmCdparm.txtCRRSLRGLcode.value=="")
			{
				alert("Please select Gl Code")
				window.document.frmCdparm.B2CRRSLR.focus();
				return;
			}
		}
		if(window.document.frmCdparm.cmbCRRSLRFag.value=="")
		{
			alert("Please Select Flag")
			window.document.frmCdparm.cmbCRRSLRFag.focus();
			return;
		}
		
		if(window.document.frmCdparm.cmbCRRSLRFag.value=="SLR")
		{
		
			if(window.document.frmCdparm.cmbCRRSLRSubType.value=="")
			{	
			alert("Please Select Sub Type")
			window.document.frmCdparm.cmbCRRSLRSubType.focus();
			return;
			}
		}
		
		
		window.document.frmCdparm.mfgCRRSLRparm.cols=5;
		window.document.frmCdparm.mfgCRRSLRparm.formatstring="<Slno   |<Module Id        |<Glcode        |<Flag    |<Sub Type";
		
		
		if(window.document.frmCdparm.chkCRRSLRGlcd.checked==true)
		{
			var mod
			
			mod = window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase()
			
			window.document.all['iBatch1'].src="../gen/glcodes.aspx?st=ALLGLCODES"+"~"+mod
		}
		else
		{
			addCRRSLRGrid()
		}
	}
	
	function addCRRSLRGrid()
	{
		var cnt
		
		cnt = 0
		
		rowidx = window.document.frmCdparm.mfgCRRSLRparm.rows;
		
		if(window.document.frmCdparm.mfgCRRSLRparm.rows > "1")
		{
			for(i=1;i<window.document.frmCdparm.mfgCRRSLRparm.rows;i++)
			{
				if((window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase()==window.document.frmCdparm.mfgCRRSLRparm.textmatrix(i,1))&&(window.document.frmCdparm.txtCRRSLRGLcode.value.toUpperCase()==window.document.frmCdparm.mfgCRRSLRparm.textmatrix(i,2)))
				{
					alert("Already added")
					return;
				}
			}
		}
		
		cnt = rowidx
		
		window.document.frmCdparm.mfgCRRSLRparm.rows =  
				window.document.frmCdparm.mfgCRRSLRparm.rows+1;
				
				
		window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,0)=cnt //sl no
		window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,1)=
					window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase();//moduleid
		window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,2)=
					window.document.frmCdparm.txtCRRSLRGLcode.value.toUpperCase();//glcode
		window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,3)=
					window.document.frmCdparm.cmbCRRSLRFag.value.toUpperCase(); //CRR SLR flag
		window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,4)=
					window.document.frmCdparm.cmbCRRSLRSubType.value.toUpperCase(); //Sub Type
		clearCRRSLR()
	}
	
	
	function FillDataIntoGridCRRSLR(strGlCodes)
	{
		var arrglcodes,rowidx,count
		
		count = 0
		
		arrglcodes = strGlCodes.split("~");
		//alert(arrglcodes)
		var len = arrglcodes.length;
		//alert(len)
		
		rowidx=window.document.frmCdparm.mfgCRRSLRparm.rows;
		
		if(window.document.frmCdparm.mfgCRRSLRparm.rows > "1")
		{
			for(i=1;i<window.document.frmCdparm.mfgCRRSLRparm.rows;i++)
			{
				
				for(j=0;j<len-1;j++)
				{
					if(arrglcodes[j]==window.document.frmCdparm.mfgCRRSLRparm.textmatrix(i,2))
					{
						alert("Already added")
						return;
					}
				}
			}
			for(icnt=1;icnt<=window.document.frmCdparm.mfgCRRSLRparm.rows-1;icnt++)
			{
				for(jcnt=0;jcnt<=window.document.frmCdparm.mfgCRRSLRparm.Cols-1;jcnt++)
				{
					if(jcnt==0)
					{
						count = window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(icnt,jcnt)
					}
					
				}
			}
		}
		
		count = parseInt(count)+1
			
		window.document.frmCdparm.mfgCRRSLRparm.rows = window.document.frmCdparm.mfgCRRSLRparm.rows+1;
		
		for(idx=0;idx<arrglcodes.length;idx++)
		{
			if(arrglcodes[idx]!="")
			{
				if((window.document.frmCdparm.mfgCRRSLRparm.rows-1) < rowidx)
				{
					window.document.frmCdparm.mfgCRRSLRparm.rows = window.document.frmCdparm.mfgCRRSLRparm.rows+1;			
				}
				
				window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,0) = parseInt(count) //slno
				window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,1) = window.document.frmCdparm.txtCRRSLRModId.value.toUpperCase(); //module id
				window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,2) = arrglcodes[idx].toUpperCase();//glcode
				window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,3) = window.document.frmCdparm.cmbCRRSLRFag.value.toUpperCase();
				window.document.frmCdparm.mfgCRRSLRparm.TextMatrix(rowidx,4) = window.document.frmCdparm.cmbCRRSLRSubType.value.toUpperCase();
				
			rowidx = rowidx + 1
			count = count + 1
			}
		}
		
		clearCRRSLR()
		
	}
	
	function clearCRRSLR()
	{
		window.document.frmCdparm.txtCRRSLRModId.value=""
		window.document.frmCdparm.txtCRRSLRModNm.value=""
		window.document.frmCdparm.txtCRRSLRGLcode.value=""
		window.document.frmCdparm.txtCRRSLRGLname.value=""
		window.document.frmCdparm.cmbCRRSLRFag.value=""
	}
	
function controlCRRSLR()
{
		window.document.frmCdparm.txtCRRSLRModNm.value=""
		window.document.frmCdparm.txtCRRSLRModId.value=""
		window.document.frmCdparm.txtCRRSLRGLcode.value=""
		window.document.frmCdparm.txtCRRSLRGLname.value=""
		window.document.frmCdparm.cmbCRRSLRFag.value=""
		window.document.frmCdparm.cmbCRRSLRSubType.value= ""
		window.document.frmCdparm.mfgCRRSLRparm.rows =1
		window.document.frmCdparm.chkCRRSLRGlcd.checked=false
}

	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmCdparm">
		<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%">
				<tr>
					<td align="left" class="bankHeaderLogo"></td>
					<td align="right" class="esmartBankerLogo"></td>
				</tr>
			</table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" border="0" cellspacing="0" width="100%">
				<tr>
					<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="30%" align="center" height="22" class="subHeader"><h2>Report parameters&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol">
		</div><%appdate=formatdatetime(session("applicationdate"),1)%>
		<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
			<tr>
				<td width="16%" valign="top">
					<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">CD Parameter</font></a></td>
						</tr>
						<tr bgcolor="#99ccff">
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">CRR Parameter</font></a></td>
						</tr>
				<!---		<tr bgcolor="#99ccff">
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">Salary Deduction</font></a></td>
						</tr> --->
					</table>
				</td>
				<td width="84%" valign="top">
					<!---- Cd Parameter ----------->
					<div id="divCDparm" style="display:none">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="CD Parameter" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tableborder1">
							<tr class="bgcolor1">
								<td width="10%">
								<p align="right"><font class="textblack"><input checked name="optmode" type="radio" value="31" onclick="control()"></font></td>
								<td width="20%"><font class="textblack">Add</font></td>
								<td width="20%">
								<p align="right"><font class="textblack"><input name="optmode" type="radio" value="31" onclick="control()"></font></td>
								<td width="20%"><font class="textblack">Modify</font></td>
								<td width="20%">
								<p align="right"><font class="textblack"><input name="optmode" type="radio" value="32" onclick="control()"></font></td>
								<td width="20%"><font class="textblack">Delete</font></td>
								<td width="10%">
							</tr>
						</table>
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width = "15%" align="right"> Module ID&nbsp;&nbsp;&nbsp;</td>
								<td width="20%"><input name="txtModId" size="8" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="16" class="txtautofill" value="" onblur="Dataarrange(txtModId);DescrptionDisp(&quot;txtModId&quot;)" readonly><input type="button" value=" L " name="B1"  onclick="module()" class="button"><input name="txtModNm" class="bgcolor1" size="19" value="" readonly></td>
								<td width = "10%" align="right">GL Code&nbsp;&nbsp;&nbsp;</td>
								<td width = "55%" align="left"><input name="txtGLcode" onkeypress="Alphanum()" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill" onblur="Dataarrange(txtGLcode);DescrptionDisp(&quot;txtGLcode&quot;)" readonly><input type="button" value=" L " name="B2" onclick="Glcode()" class="button"  ><input name="txtGLname" size="16" class="bgcolor1" >&nbsp;&nbsp;&nbsp;ALL GLCode <input type="checkbox" name="chkGlcd" id="chkGlcd" onclick="chkAllgl()"></td>
							</tr>
							<tr>
								<td width = "15%" align="right">Flag&nbsp;&nbsp;&nbsp;</td>
								<td width = "30%" align="left"> 
									<select size="1" name="cmbCDFag" >
										<option value=""></option>
										<option value="A">DEP</option>
										<option value="B">LOAN</option>
										<option value="C">BDR</option>
									</select>
								</td>
								<td width = "15%" align="center">&nbsp;&nbsp;</td>
								<td width = "40%" align="center">&nbsp;&nbsp;</td>
							</tr>
							<tr>
								
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center"><input name="butCtrl"  id= "butCtrl" type="button" value="   Add   " class="button" onclick="AddToGrid()"></td>
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center">&nbsp;&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgCDparm name=mfgCDparm style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="Slno   |<Module Id        |<Glcode        |<Flag  ">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
					</div>
					<!---- CD Parameter End  ----------->
					
					<!---- CRR Parameter Start----------->
					<div id="divCRRSLRparm" style="display:none">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblCRRSLRothers" value="CRRSLR Parameter" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
						</table>
						<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tableborder1">
							<tr class="bgcolor1">
								<td width="10%">
								<p align="right"><font class="textblack"><input checked name="optCRRSLRmode" type="radio" value="31" onclick="controlCRRSLR()"></font></td>
								<td width="20%"><font class="textblack">Add</font></td>
								<td width="20%">
								<p align="right"><font class="textblack"><input name="optCRRSLRmode" type="radio" value="31" onclick="controlCRRSLR()"></font></td>
								<td width="20%"><font class="textblack">Modify</font></td>
								<td width="20%">
								<p align="right"><font class="textblack"><input name="optCRRSLRmode" type="radio" value="32" onclick="controlCRRSLR()"></font></td>
								<td width="20%"><font class="textblack">Delete</font></td>
								<td width="10%">
							</tr>
						</table>
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width = "15%" align="right"> Module ID&nbsp;&nbsp;&nbsp;</td>
								<td width="20%"><input name="txtCRRSLRModId" size="8" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="16" class="txtautofill" value="" onblur="Dataarrange(txtCRRSLRModId);DescrptionDisp(&quot;txtCRRSLRModId&quot;)" readonly><input type="button" value=" L " name="B1CRRSLR"  onclick="moduleCRRSLR()" class="button"><input name="txtCRRSLRModNm" class="bgcolor1" size="19" value="" readonly></td>
								<td width = "10%" align="right">GL Code&nbsp;&nbsp;&nbsp;</td>
								<td width = "55%" align="left"><input name="txtCRRSLRGLcode" onkeypress="Alphanum()" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill" onblur="Dataarrange(txtCRRSLRGLcode);DescrptionDisp(&quot;txtCRRSLRGLcode&quot;)" readonly><input type="button" value=" L " name="B2CRRSLR" onclick="GlcodeCRRSLR()" class="button"  ><input name="txtCRRSLRGLname" size="16" class="bgcolor1" >&nbsp;&nbsp;&nbsp;ALL GLCode <input type="checkbox" name="chkCRRSLRGlcd" id="chkCRRSLRGlcd" onclick="chkAllglCRRSLR()"></td>
							</tr>
							<tr>
								<td width = "15%" align="right">Flag&nbsp;&nbsp;&nbsp;</td>
								<td width = "30%" align="left"> 
									<select size="1" name="cmbCRRSLRFag" onchange = "SetSubType()" >
										<option value=""></option>
										<option value="CRR">CRR</option>
										<option value="SLR">SLR</option>
									</select>
								</td>
								<td width = "10%" align="right">Sub Type&nbsp;&nbsp;</td>
								<td width = "55%" align="left"> 
									<select size="1" name="cmbCRRSLRSubType" >
										<option value=""></option>
										<option value="CA">CA</option>
										<option value="DEP">DEP</option>
										<option value="GOVT">GOVT</option>
										<option value="OTHERS">OTHERS</option>
									</select>
								</td>
							</tr>
							<tr>
								
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center"><input name="butCtrlCRRSLR"  id= "butCtrlCRRSLR" type="button" value="   Add   " class="button" onclick="AddToGridCRRSLR()"></td>
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center">&nbsp;&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" colspan="4" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgCRRSLRparm name=mfgCRRSLRparm style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="5">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="Slno   |<Module Id        |<Glcode        |<Flag  |< Sub Type">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
					</div>
					<!---- CRRSLR Parameter End  ----------->
					
				</td>
			</tr>
		</table>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%">
				<div align="center">
					<center>	
					<table border="0" border="0" cellpadding="0" cellspacing="0" width="17%">
						<tr>
							<td width="100%" ><input name="cmdok" type="button" value="   OK   " class="button" onclick="subtrans();"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmCDparameter.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
						</tr>
					</table>
					</center>
				</div>
				</td>
			</tr>
		</table>
		<input type="hidden" name="hpr" value="<%=session("precision")%>">
		<input type="hidden" name="htabname" value>
		<input type="hidden" name="hfldname" value>
		<input type="hidden" name="hfldvalues" value>
		<input type="hidden" name="hmode" value>
		<input type="hidden" name="hdnrow" value>
		<input type="hidden" name="mercust">
		<input type="hidden" name="hidDate">
		<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0  src="..gen/getdtls.aspx"></iframe>
		<iframe id=iBatch1 align=center frameborder=0 framespacing=0 noresize height=1 width=3 valign="top" src="..gen/glcodes.aspx" style="BACKGROUND-COLOR: darkred; HEIGHT:0px; WIDTH:0px" ></iframe>
		<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
		</div>

    </form>

  </body>
</html>
