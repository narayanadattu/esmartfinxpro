Imports System.IO
Imports System.Web
Imports System.Web.UI.HtmlControls.HtmlInputFile


Public Class TenantRentCollection
    Inherits System.Web.UI.Page
    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim objtran As OracleClient.OracleTransaction
    'Protected WithEvents txtResult As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txtInputVals As System.Web.UI.WebControls.TextBox
    Dim objconn As New OracleClient.OracleConnection
    Dim errmsg As String
    Dim o_errmsg1 As String


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Try

            'txtResult.Text = ""
            Dim strCurrFileName, strCurrFileExt, filePath, strQS, strArrQS() As String

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If


            ' strQS = Request.QueryString("strVin")
            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")

            If strArrQS(0) = "OKCLICK" Then
                Dim impStatus As String
                impStatus = postTransaction()
            End If

        Catch ex As Exception
            'txtResult.Text = ex.Message()
        End Try

    End Sub

    Private Function postTransaction() As String
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        Dim dt As New DataTable

        Try
            Dim strCommServ, strCommMod, strCommGl, strCommBr, strCommGlDesc, strCommAcc, strCommAmt, strAdvInsAmt, strrecbrcode, strTenantid, strServMod, strServGl, strServGlDesc, strServAcc, strServPercent, strEffDate, strSrvTax, strAutoPostCharges, errmsg, strBatchNo, strTranNo1, strTranNo2, strTranNo3, commYN, servTaxYN, strtranno, strNam As String
            Dim brCode, curCode, drMod, drGl, drAcc, appDate, userId, machineID, brAbbcode, stOtalow As String
            Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg, stRefnum As String
            Dim dblComm, dblSrv, totDrAmt, stGstamt, stRevGstamt As Double
            Dim iCnt, jCnt, stMaxnum, stMxn As Integer
            Dim stPcgMod, stPcgGl, stPcgAcc, stPsgMod, stPsgGl, stPsgAcc, stExpMod, stExpGl, stExpAcc, stRcgMod, stRcgGl, stRcgAcc, stRsgMod, stRsgGl, stRsgAcc As String
            Dim strtemp, strbill, grdRows, grdCols, strBal, strQS, strArrQS, strVal, strValDr, StrQuery, strEmpno, strEmprPf, strEmprEsi
            Dim strPF, strPtax, strDep, strLoan, strAdv, strTds, strmn, stryr, strGip, strOthd, strESI, strVPF As String
            Dim strSqlAcc, strNftsYN, strPayfield, strPayVal, strCommMod1, strCommGl1, strCommAcc1 As String
            Dim stBnam, stImpyn, stPamt, strAmtGst, strAmtRevGst, stRevYn, stPremark, stBPos
            Dim strAssessYear As String
            Dim strTDSCustomerid, o_ErrMsg As String
            Dim strPanno, StrIndGrossAmt As String
            Dim strSalBrCode, strSalModId, strSalGlcode, strSalAccNo, strITForm As String

            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")
            strVal = strArrQS(1).Split("@")
            strValDr = strVal(0).Split("~")
            Dim strvalcol, strvalrow()
            strvalrow = strVal(1).Split("|")

            appDate = strValDr(0)
            userId = strValDr(1)
            machineID = strValDr(2)
            totDrAmt = strValDr(3)
            stGstamt = strValDr(4)
            stRevGstamt = strValDr(5)
            brCode = strValDr(6)
            strmn = strValDr(7)
            stryr = strValDr(8)

            strBatchNo = ""
            strTranNo1 = ""
            curCode = "INR"

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            objtran = objconn.BeginTransaction()

            ''for bank name 
            StrQuery = ""

            StrQuery = "SELECT depcertificate from genbankparm"

            Dim objBnk As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objBnk, StrQuery, objtran)

            If objBnk.HasRows = True Then
                objBnk.Read()

                stBnam = objBnk(0)

            End If

            objBnk.Close()
            objBnk.Dispose()
            objBnk = Nothing

            ''maxnum
            StrQuery = ""

            StrQuery = "SELECT NVL(MAX(TO_NUMBER(INVNO)),0)+1 val FROM TENANTPAIDDTLS"

            Dim objMax As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objMax, StrQuery, objtran)

            If objMax.HasRows = True Then
                objMax.Read()

                stMaxnum = objMax(0)

            End If

            objMax.Close()
            objMax.Dispose()
            objMax = Nothing

            ''for POS name 
            StrQuery = ""

            StrQuery = "SELECT  NVL(a.statecode||'-'||b.statename,'') POS  from genbankbranchmst a,GENSTATEMST b where a.statecode = b.statecode AND a.branchcode='" & brCode & "'"

            Dim objPOS As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objPOS, StrQuery, objtran)

            If objPOS.HasRows = True Then
                objPOS.Read()

                stBPos = objPOS(0)

            End If

            objPOS.Close()
            objPOS.Dispose()
            objPOS = Nothing

            ''for gst percentage
            StrQuery = ""
            StrQuery = "SELECT VALUE1 FROM genconfigmst WHERE CODE='GSTR'"

            Dim objPcf As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objPcf, StrQuery, objtran)

            If objPcf.HasRows = True Then
                objPcf.Read()

                stPamt = objPcf(0)
            End If

            objPcf.Close()
            objPcf.Dispose()
            objPcf = Nothing

            For iCnt = 0 To strvalrow.Length - 1

                'For iCnt = 0 To UBound(strvalrow)
                strvalcol = strvalrow(iCnt).Split("~")

                strCommBr = strvalcol(0)

                If brCode <> strCommBr Then

                    brAbbcode = "ABB"

                    Exit For

                End If

            Next


            If brAbbcode = "ABB" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            Else
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            End If

            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                        "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                        "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                        "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                        "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                        "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                        "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                        "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                        "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                        "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                        "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                        "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                        "ABBYN"

            If totDrAmt <> 0 Then '' debit amount

                StrQuery = "SELECT MODULEID, GLCODE, ACCNO FROM SALARYCTRLMST WHERE SALTYPE='RENT' AND drcrflg = 'D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='RENT' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                Dim objDr As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDr, StrQuery, objtran)

                If objDr.HasRows = True Then
                    objDr.Read()

                    drMod = objDr(0)
                    drGl = objDr(1)
                    drAcc = objDr(2)

                    StrQuery = "SELECT glcode,accno FROM " & drMod & "MST where GLCODE='" & drGl & "' and ACCNO='" & drAcc & "' and Branchcode='" & brCode & "'"
                    Dim objDrtab As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                    If objDrtab.HasRows = True Then
                        While objDrtab.Read

                            drGl = objDrtab(0)
                            drAcc = objDrtab(1)

                            strRemarksDr = "Rent Paid for the Month Of " & strmn & " " & stryr '& " "
                            'Salary Paid for the Month Of April 2016

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                            "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                            "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                            "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                            "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                            Else
                                StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing
                        End While
                    Else
                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)

                    End If

                    objDrtab.Close()
                    objDrtab.Dispose()
                    objDrtab = Nothing

                Else
                    Throw New Exception("ModuleId or Glcode Or Accno is null for Debit Rent Paid ")

                End If

                objDr.Close()
                objDr.Dispose()
                objDr = Nothing

            End If

            If stGstamt <> 0 Then '' debit Gst amount

                '' cgst 
                StrQuery = "SELECT NVL(a.MODULEID,''), NVL(a.GLCODE,''), NVL(a.ACCNO,'') FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTP' AND a.gsttype='CGST'"

                Dim objDrgip As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDrgip, StrQuery, objtran)

                If objDrgip.HasRows = True Then
                    While objDrgip.Read

                        strCommMod = objDrgip(0)
                        strCommGl = objDrgip(1)
                        strCommAcc = objDrgip(2)

                        stPcgMod = strCommMod
                        stPcgGl = strCommGl
                        stPcgAcc = strCommAcc

                        StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                        Dim objDrtab As OracleClient.OracleDataReader
                        ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                        If objDrtab.HasRows = True Then
                            While objDrtab.Read

                                strCommGl = objDrtab(0)
                                strCommAcc = objDrtab(1)
                                strCommAmt = CDbl(stGstamt) / 2

                                If brAbbcode = "ABB" Then
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                Else
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                End If

                                strRemarksDr = "CGST Rent for " & strmn & " " & stryr

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                                Else
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                                "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                                "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                                "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                                "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                                "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                                "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                                "NULL,NULL,'N',NULL,'Y'," & _
                                                "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                                "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                                "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                                End If



                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                           "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                           "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                           "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                           "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                           "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                           "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                           "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                           "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                           "NULL,NULL,'N',NULL,'Y'," & _
                                           "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                           "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                           "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                Else
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                           "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                           "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                           "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                           "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                           "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                           "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                           "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                           "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                           "NULL,NULL,'N',NULL,'Y'," & _
                                           "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                           "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                           "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                End If


                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing

                            End While
                        Else
                            Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                        End If

                        objDrtab.Close()
                        objDrtab.Dispose()
                        objDrtab = Nothing

                    End While
                Else
                    Throw New Exception("ModuleId or Glcode or Accno is null for CGST Debit GSTP")
                End If

                objDrgip.Close()
                objDrgip.Dispose()
                objDrgip = Nothing

                ''for sgst 
                StrQuery = "SELECT NVL(a.MODULEID,''), NVL(a.GLCODE,''), NVL(a.ACCNO,'') FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTP' AND a.gsttype='SGST'"

                Dim objDrpf As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDrpf, StrQuery, objtran)

                If objDrpf.HasRows = True Then
                    While objDrpf.Read


                        strCommMod = objDrpf(0)
                        strCommGl = objDrpf(1)
                        strCommAcc = objDrpf(2)

                        stPsgMod = strCommMod
                        stPsgGl = strCommGl
                        stPsgAcc = strCommAcc

                        StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                        Dim objDrtab As OracleClient.OracleDataReader
                        ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                        If objDrtab.HasRows = True Then
                            While objDrtab.Read

                                strCommGl = objDrtab(0)
                                strCommAcc = objDrtab(1)

                                strCommAmt = CDbl(stGstamt) / 2

                                If brAbbcode = "ABB" Then
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                Else
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                End If

                                'SGST Rent for "name" for Apr 2016
                                strRemarksDr = "SGST Rent for " & strmn & " " & stryr

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                             "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                             "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                             "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                             "NULL,NULL,'N',NULL,'Y'," & _
                                             "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                             "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                             "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                Else
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                             "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                             "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                             "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                             "NULL,NULL,'N',NULL,'Y'," & _
                                             "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                             "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                             "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                End If



                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                Else
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                End If


                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing

                            End While
                        Else
                            Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                        End If

                        objDrtab.Close()
                        objDrtab.Dispose()
                        objDrtab = Nothing


                    End While
                Else
                    Throw New Exception("ModuleId or Glcode or Accno is null for Credit PF")
                End If

                objDrpf.Close()
                objDrpf.Dispose()
                objDrpf = Nothing

            End If

            If stRevGstamt <> 0 Then
                ' reverse gst amount
                StrQuery = "SELECT NVL(a.MODULEID,''), NVL(a.GLCODE,''), NVL(a.ACCNO,'')  FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND gstcode='GSTP' AND gsttype='GSTEXP'"

                Dim objDrptax As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDrptax, StrQuery, objtran)

                If objDrptax.HasRows = True Then

                    While objDrptax.Read

                        strCommMod = objDrptax(0)
                        strCommGl = objDrptax(1)
                        strCommAcc = objDrptax(2)
                        strCommAmt = stRevGstamt

                        stExpMod = strCommMod
                        stExpGl = strCommGl
                        stExpAcc = strCommAcc

                        StrQuery = ""

                        StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & brCode & "'"
                        Dim objDrtab As OracleClient.OracleDataReader
                        ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                        If objDrtab.HasRows = True Then
                            While objDrtab.Read

                                strCommGl = objDrtab(0)
                                strCommAcc = objDrtab(1)

                                If brAbbcode = "ABB" Then
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                Else
                                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                    objCmd.Transaction = objtran
                                    strTranNo2 = objCmd.ExecuteScalar
                                End If

                                'Reverse GST Paid from "name" for Apr 2016
                                strRemarksDr = "Reverse GST Paid To Rent " & strNam & " for " & strmn & " " & stryr

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                             "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                             "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                             "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                             "NULL,NULL,'N',NULL,'Y'," & _
                                             "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                             "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                             "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                                Else
                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                             "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                             "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                             "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                             "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                             "NULL,NULL,'N',NULL,'Y'," & _
                                             "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                             "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                             "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                                End If



                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing

                                If brAbbcode = "ABB" Then
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                                Else
                                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                                            "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo2 & "',-" & strCommAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                            "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                            "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                                End If


                                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                                objCmd.Transaction = objtran
                                objCmd.ExecuteNonQuery()
                                objCmd.Dispose()
                                objCmd = Nothing
                            End While
                        Else
                            Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)
                        End If

                        objDrtab.Close()
                        objDrtab.Dispose()
                        objDrtab = Nothing

                    End While
                Else
                    Throw New Exception("Moduleid or Glcode or Accno is null for Debit Reverse GST")

                End If

                objDrptax.Close()
                objDrptax.Dispose()
                objDrptax = Nothing

                '' reverse credit CGst

                StrQuery = "SELECT NVL(a.MODULEID,''), NVL(a.GLCODE,''), NVL(a.ACCNO,'') FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='CGST'"

                Dim objDrothd As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objDrothd, StrQuery, objtran)

                If objDrothd.HasRows = True Then
                    While objDrothd.Read

                        stRcgMod = objDrothd(0)
                        stRcgGl = objDrothd(1)
                        stRcgAcc = objDrothd(2)

                    End While
                Else
                    Throw New Exception("ModuleId or Glcode or Accno is null for Credit CGST")
                End If

                objDrothd.Close()
                objDrothd.Dispose()
                objDrothd = Nothing

                '' reverse credit SGst

                StrQuery = "SELECT NVL(a.MODULEID,''), NVL(a.GLCODE,''), NVL(a.ACCNO,'') FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='SGST'"

                Dim objCrothd As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objCrothd, StrQuery, objtran)

                If objCrothd.HasRows = True Then
                    While objCrothd.Read

                        stRsgMod = objCrothd(0)
                        stRsgGl = objCrothd(1)
                        stRsgAcc = objCrothd(2)

                    End While
                Else
                    Throw New Exception("ModuleId or Glcode or Accno is null for Credit CGST")
                End If

                objCrothd.Close()
                objCrothd.Dispose()
                objCrothd = Nothing

            End If

            For iCnt = 0 To strvalrow.Length - 1

                strvalcol = strvalrow(iCnt).Split("~")

                strCommBr = strvalcol(0)
                strCommMod = strvalcol(1)
                strCommGl = strvalcol(2)
                strCommAcc = strvalcol(3)
                strSalBrCode = strvalcol(0)
                strSalModId = strvalcol(1)
                strSalGlcode = strvalcol(2)
                strSalAccNo = strvalcol(3)
                StrIndGrossAmt = strvalcol(4)
                'strCommAmt = strvalcol(4)
                strAdvInsAmt = strvalcol(8)
                strCommAmt = strvalcol(9)
                strTenantid = strvalcol(10)

                strAmtGst = strvalcol(5)
                strAmtRevGst = strvalcol(6)
                strTds = strvalcol(7)

                strCommAmt = CDbl(strCommAmt) + CDbl(strAmtGst)

                stMxn = CDbl(stMaxnum) + CDbl(iCnt)

                StrQuery = ""
                strCommAcc1 = ""
                StrQuery = "SELECT NAME FROM " & strCommMod & "MST  WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND  BRANCHCODE='" & strCommBr & "'"

                Dim objAcnam As OracleClient.OracleDataReader
                ExecuteSelectQuery1(objAcnam, StrQuery, objtran)

                If objAcnam.HasRows = True Then
                    objAcnam.Read()

                    strCommAcc1 = objAcnam(0)

                End If

                objAcnam.Close()
                objAcnam.Dispose()
                objAcnam = Nothing


                If strCommAmt <> 0 Then


                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    End If

                    'Salary for the Month of Apr 2016'
                    strRemarksDr = "Rent for the Month of " & strmn & " " & stryr

                    ''"Rent from MAHARAJA BANK 101 for the Month of October 2017"

                    strRemarksDr = "Rent from " & stBnam & " BANK " & brCode & " for the Month " & strmn & " " & stryr

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                    "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                End If

                If strTds <> 0 Then ''TDS

                    'StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='TDS' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='TDS' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                    StrQuery = "SELECT COMMMODULEID, COMMGLCODE, COMMACCNO FROM genchargespmt WHERE chargesid='TDS'"

                    Dim objDrtds As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrtds, StrQuery, objtran)

                    If objDrtds.HasRows = True Then
                        While objDrtds.Read

                            strCommMod = objDrtds(0)
                            strCommGl = objDrtds(1)
                            strCommAcc = objDrtds(2)
                            strCommAmt = strTds


                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            'TDS from "name" for Apr 2016
                            strRemarksDr = "TDS On Rent From " & strCommAcc1 & " for " & strmn & " " & stryr

                            If brAbbcode = "ABB" Then

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If



                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing


                            ''tdsdtls 

                            ' strITForm = "94I"
                            strITForm = getITformITCode(2, objconn, objtran)
                            strAssessYear = GetAssessYear(appDate)
                            strTDSCustomerid = GetCustomerid10(strSalBrCode, strSalModId, strSalGlcode, strSalAccNo, objconn, objtran, o_ErrMsg)
                            strPanno = GetCustomeridPanNo(strTDSCustomerid, objconn, objtran, o_ErrMsg)
                            StrInsert = "INSERT INTO tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, NAME, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, FROMDATE, TODATE, LNKMODULEID, LNKGLCODE, LNKACCNO, REMARKS, TRANSTATUS, STATUS, USERID, MACHINEID,  SYSTEMDATE, APPLICATIONDATE, CUSTOMERID, ASSESYEAR,  REFUNDYN, PANYN, ITFORM,VENDORPANNO, AMTPAID) VALUES('" & strSalBrCode & "','" & curCode & "','" & strSalModId & "','" & strSalGlcode & "','" & strSalAccNo & "','" & strCommAcc1 & "','" & strBatchNo & "','" & strTranNo2 & "','" & -1 * CDbl(strCommAmt) & "','3','" & appDate & "','" & appDate & "','" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "','" & strRemarksDr & "','A','R','" & userId & "','" & machineID & "',sysdate,'" & appDate & "', '" & strTDSCustomerid & "','" & strAssessYear & "','N','N', '" & strITForm & "', '" & strPanno & "','" & CDbl(StrIndGrossAmt) & "')"

                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing
                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit TDS")
                    End If

                    objDrtds.Close()
                    objDrtds.Dispose()
                    objDrtds = Nothing

                End If '' tds


                If strAdvInsAmt <> 0 Then ''Adv Ins Amt
                

                    StrQuery = "SELECT MODULEID, GLCODE, ACCNO,BRANCHCODE FROM TENANTADVRECVLNK WHERE TENANTID='" & strTenantid & "'"

                    Dim objDrtds As OracleClient.OracleDataReader
                    ExecuteSelectQuery1(objDrtds, StrQuery, objtran)

                    If objDrtds.HasRows = True Then
                        While objDrtds.Read
                            '   strrecbrcode = objDrtds(3)
                            strCommMod = objDrtds(0)
                            strCommGl = objDrtds(1)
                            strCommAcc = objDrtds(2)
                            strCommAmt = strAdvInsAmt


                            If brAbbcode = "ABB" Then
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            Else
                                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                                objCmd.Transaction = objtran
                                strTranNo2 = objCmd.ExecuteScalar
                            End If

                            'TDS from "name" for Apr 2016
                            strRemarksDr = "Adv Installment Amount On Rent From " & strCommAcc1 & " for " & strmn & " " & stryr

                            If brAbbcode = "ABB" Then

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"

                            Else
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                         "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                         "NULL,NULL,'N',NULL,'Y'," & _
                                         "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                         "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"

                            End If



                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"

                            Else
                                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & strCommBr & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & strCommBr & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"

                            End If


                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing



                        End While
                    Else
                        Throw New Exception("ModuleId or Glcode or Accno is null for Credit AdvInsAmt")
                    End If

                    objDrtds.Close()
                    objDrtds.Dispose()
                    objDrtds = Nothing

                End If '' AdvInsAmt





                If strAmtGst <> 0 Then

                    strCommAmt = strAmtGst

                    stRevYn = "N"

                    stPremark = "Rent Pay To " & strCommBr & " " & strCommGl & " " & strCommAcc & " For Month " & strmn & " " & stryr

                    stRefnum = "RENT" & stMxn

                    StrInsert = "INSERT INTO GSTTNXDTLS (BRANCHCODE, GSTCODE, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, INVOICETYPE, GSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, REVERSECHARGE,  BATCHNO, STATUS, CUSTOMERID, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE,REMARKS,RECPNAME) VALUES ('" & brCode & "','GSTP','" & stRefnum & "','" & appDate & "','" & strvalcol(4) & "','" & stBPos & "','Regular', (SELECT GSTIN FROM gencustinfomst WHERE customerid in (select Customerid from " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "') ),'" & stPamt & "', '" & CDbl(strvalcol(4)) + CDbl(strvalcol(5)) & "', '" & CDbl(strvalcol(5)) / 2 & "', '" & CDbl(strvalcol(5)) / 2 & "', '0','0', '" & stRevYn & "','" & strBatchNo & "','R',(select nvl(CUSTOMERID,1111111111) Customerid from " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "'),'" & appDate & "','" & userId & "','" & machineID & "',SYSDATE,'" & stPremark & "',(SELECT NAME FROM " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "'))"


                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                End If

                If strAmtRevGst <> 0 Then

                    strCommAmt = CDbl(strAmtRevGst) / 2

                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    End If

                    'Salary for the Month of Apr 2016'
                    strRemarksDr = "Reverse CGST for the Month of " & strmn & " " & stryr

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRcgMod & "'," & _
                                    "'" & stRcgGl & "','" & stRcgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRcgMod & "'," & _
                                    "'" & stRcgGl & "','" & stRcgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO " & stRcgMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRcgMod & "'," & _
                                    "'" & stRcgGl & "','" & stRcgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        StrInsert = "INSERT INTO " & stRcgMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRcgMod & "'," & _
                                    "'" & stRcgGl & "','" & stRcgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRcgMod & "MST " & _
                                    "WHERE ACCNO='" & stRcgAcc & "' AND GLCODE='" & stRcgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing


                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    End If

                    'Salary for the Month of Apr 2016'
                    strRemarksDr = "Reverse SGST for the Month of " & strmn & " " & stryr

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRsgMod & "'," & _
                                    "'" & stRsgGl & "','" & stRsgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRsgMod & "'," & _
                                    "'" & stRsgGl & "','" & stRsgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO " & stRsgMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRsgMod & "'," & _
                                    "'" & stRsgGl & "','" & stRsgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                    "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & stRsgMod & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        StrInsert = "INSERT INTO " & stRsgMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & brCode & "','" & curCode & "','" & stRsgMod & "'," & _
                                    "'" & stRsgGl & "','" & stRsgAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT nvl(CUSTOMERID,1111111111) FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & stRsgMod & "MST " & _
                                    "WHERE ACCNO='" & stRsgAcc & "' AND GLCODE='" & stRsgGl & "' AND " & _
                                    "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing


                    stRevYn = "Y"

                    stPremark = "Rent Reverse Pay To " & strCommBr & " " & strCommGl & " " & strCommAcc & " For Month " & strmn & " " & stryr

                    StrInsert = "INSERT INTO GSTTNXDTLS (BRANCHCODE, GSTCODE, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, INVOICETYPE, GSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, REVERSECHARGE,  BATCHNO, STATUS, CUSTOMERID, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE,REMARKS,RECPNAME) VALUES ('" & brCode & "','GSTR',(SELECT NVL(MAX(to_number(INVOICENO)),0)+1 val FROM GSTTNXDTLS where GSTCODE='GSTR'),'" & appDate & "','" & strvalcol(4) & "','" & stBPos & "','Regular', (SELECT GSTIN FROM gencustinfomst WHERE customerid in (select Customerid from " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "') ),'" & CDbl(stPamt) / 2 & "', '" & CDbl(strvalcol(4)) + CDbl(strvalcol(6)) & "', '" & CDbl(strvalcol(6)) / 2 & "', '" & CDbl(strvalcol(6)) / 2 & "', '0','0', '" & stRevYn & "','" & strBatchNo & "','R',(select nvl(CUSTOMERID,1111111111) Customerid from " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "'),'" & appDate & "','" & userId & "','" & machineID & "',SYSDATE,'" & stPremark & "',(SELECT NAME FROM " & strvalcol(1) & "MST WHERE ACCNO='" & strvalcol(3) & "' AND GLCODE='" & strvalcol(2) & "' AND BRANCHCODE='" & strCommBr & "'))"


                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                End If

                strPayfield = "CRBRANCHCODE, MODULEID, GLCODE, ACCNO, AMOUNT, GST, REVGST, NETPAY, PAIDMONTH, PAIDYEAR, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE, BRANCHCODE, PAIDBATCH, INVNO, TDS,Advinsamt,TENANTID "

                strPayVal = "'" & strvalcol(0) & "','" & strvalcol(1) & "','" & strvalcol(2) & "','" & strvalcol(3) & "','" & strvalcol(4) & "','" & strvalcol(5) & "','" & strvalcol(6) & "','" & CDbl(strvalcol(8)) + CDbl(strvalcol(5)) & "','" & strmn & "','" & stryr & "','" & appDate & "','" & userId & "','" & machineID & "',SYSDATE,'" & brCode & "','" & strBatchNo & "','" & stMxn & "','" & strvalcol(7) & "','" & strAdvInsAmt & "','" & strTenantid & "'"

                StrInsert = "INSERT INTO TENANTPAIDDTLS (" & strPayfield & ") VALUES (" & strPayVal & ")"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

            Next

            objtran.Commit()
            'postTransaction = "Posted SuccessFully|" & strBatchNo
            Response.Redirect("frmSalgenerate.aspx?record=Transaction Completed Batchno " & strBatchNo)

            Exit Function
        Catch ex As Exception
           
            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "").Replace("?", "")

            Response.Redirect("frmSalgenerate.aspx?record=" & o_errmsg1, False)

        End Try
    End Function

    Private Function executeScalar(ByVal strSql) As String
        Dim strResult As String
        strResult = ""

        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception("Database Connection Failed")
            End If
        End If

        objCmd = New OracleClient.OracleCommand
        objCmd.CommandText = strSql
        objCmd.Connection = objconn
        strResult = objCmd.ExecuteScalar
        objCmd.Dispose()
        objCmd = Nothing
        executeScalar = strResult
    End Function

    Public Function ExecuteSelectQuery1(ByRef objDrL As OracleClient.OracleDataReader, ByVal StrQuery As String, ByVal objtrn As OracleClient.OracleTransaction)

        objCmd = New OracleClient.OracleCommand(StrQuery, objconn)
        objCmd.Transaction = objtrn
        objDrL = objCmd.ExecuteReader()
        objCmd.Dispose()
        objCmd = Nothing
    End Function

End Class
