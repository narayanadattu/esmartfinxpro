<%@ Page Language="vb" CodeBehind="GenWorkAllotmentApproveDBOper.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotmentApproveDBOper" %>
<%
dim strmsg
dim struserid
dim strgroupcode
dim strmodule
dim strval
dim strwhere
dim transarray(0,4)
dim strfldval
dim strtab
dim obj, objQry, rsQry
dim userappryn
appdate=session("applicationdate")
strval=Request.Form("info")
'Response.Write strval
strval=split(strval,"|")
userappryn=server.CreateObject("adodb.recordset")
obj=server.CreateObject("GeneralTransactions.DBTransactions")
objQry=server.CreateObject("queryrecordsets.fetchrecordsets")
usrid=session("userid")
		
''objuserappryn=server.CreateObject("queryrecordsets.fetchrecordsets")
''userappryn=objQry.SingleRecordSet("GENBANKPARM","SAMEUSERAPPRYN","")

if Request.Form("stat")="approve" then
	strfldval="'A'~'" & session("userid") & "'~'" & session("machineid") & "'"
	strmode="U"
else
	strfldval="'D'~'" & session("userid") & "'~'" & session("machineid") & "'"
	strmode="U"
end if

if strval(0)="Group" then
	strgroupcode=ucase(strval(1))
	strmodule=ucase(strval(2))
	strtab="gengroupformsmst"
	mods=split(strmodule,",")
	
	if Request.Form("stat")<>"approve" then
		redim transarray(ubound(mods)-1+ubound(mods),4)
		
	else
		redim transarray(cint(ubound(mods)-1),4)
	end if 
	
	for icnt=1 to ubound(mods)
	
		strwhere="upper(moduleid)='" & mods(icnt) & "' and upper(groupcode)='" & _
				ucase(strgroupcode) &"'"
				
		rsQry = objQry.singlerecordset(strtab,"*", _
			strwhere & " and transtatus='D'")
			
		if rsQry.eof = true then ''' The following code to restrict same user approvel added by vinod 17-07-2013
			userappryn=objQry.SingleRecordSet("GENBANKPARM","SAMEUSERAPPRYN","")
			if userappryn(0).value="Y" then
				userappryn=objQry.SingleRecordSet("GENGROUPFORMSMST","distinct USERID",strwhere)
				if userappryn(0).value=usrid then
				strmsg="Same User Approval Not Allowed."
				response.Redirect ("Genworkallotmentapproval.aspx?record=" & strmsg )
				else
				transarray(icnt-1,0)=strmode
				transarray(icnt-1,1)=strtab
				transarray(icnt-1,2)="tranStatus,approvedby,approvedmachine," & _
					"applicationdate,systemdate"
				transarray(icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
				transarray(icnt-1,4)=strwhere
				end if
			else if userappryn(0).value="N" then
			transarray(icnt-1,0)=strmode
			transarray(icnt-1,1)=strtab
			transarray(icnt-1,2)="tranStatus,approvedby,approvedmachine," & _
				"applicationdate,systemdate"
			transarray(icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
			transarray(icnt-1,4)=strwhere
			end if
		else
			transarray(icnt-1,0)="D"
			transarray(icnt-1,1)=strtab
			transarray(icnt-1,2)=""
			transarray(icnt-1,3)=""
			transarray(icnt-1,4)=strwhere & " and transtatus='D'"
		end if
		
		Response.Write (transarray(icnt-1,1) & "<br>")
		Response.Write (transarray(icnt-1,2) & "<br>")
		Response.Write (transarray(icnt-1,3) & "<br>")
		Response.Write (transarray(icnt-1,4) & "<br>")
		
		
	next
	jcnt=icnt-1
	'Response.Write jcnt-icnt
	
	if Request.Form("stat")<>"approve" then
		for icnt=1 to ubound(mods)
			strwhere="upper(moduleid)='" & mods(icnt) &"' and upper(groupcode)='" & _
				ucase(strgroupcode) &"'"
			transarray(jcnt+icnt-1,0)="D"
			transarray(jcnt+icnt-1,1)=strtab
			transarray(jcnt+icnt-1,2)="tranStatus,approvedby,approvedmachine,applicationdate,systemdate"
			transarray(jcnt+icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
			transarray(jcnt+icnt-1,4)=strwhere
			
			Response.Write (transarray(jcnt+icnt-1,1) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,2) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,3) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,4) & "<br>")
		next
	end if
	'end if
else
	strtab="Genuseridformsmst"
	struserid=strval(1)
	strmodule=ucase(strval(2))
	mods=split(strmodule,",")
	'redim transarray(ubound(mods)-1,4)
	if Request.Form("stat")<>"approve" then
		redim transarray(ubound(mods)-1+ubound(mods),4)
		
	else
		redim transarray(cint(ubound(mods)-1),4)
	end if 
	
	for icnt=1 to ubound(mods)
		strwhere="upper(userid)='" & ucase(struserid) &"' and upper(moduleid)='" & _
			mods(icnt) & "'"
		userappryn=objQry.SingleRecordSet("GENBANKPARM","SAMEUSERAPPRYN","")
		''' The following code to restrict same user approvel added by vinod 17-07-2013
		if userappryn(0).value="Y" then
			userappryn=objQry.SingleRecordSet("GENUSERIDFORMSMST","distinct ALLOTEDUSERID",strwhere)
			if userappryn(0).value=usrid then
			strmsg="Same User Approval Not Allowed."
			response.Redirect ("Genworkallotmentapproval.aspx?record=" & strmsg )
			else
			transarray(icnt-1,0)=strmode
			transarray(icnt-1,1)=strtab
			transarray(icnt-1,2)="tranStatus,approvedby,approvedmachine,applicationdate,systemdate"
			transarray(icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
			transarray(icnt-1,4)=strwhere
			end if
		elseif userappryn(0).value="N" then
		transarray(icnt-1,0)=strmode
		transarray(icnt-1,1)=strtab
		transarray(icnt-1,2)="tranStatus,approvedby,approvedmachine,applicationdate,systemdate"
		transarray(icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
		transarray(icnt-1,4)=strwhere
		end if
	next
	
	if Request.Form("stat")<>"approve" then
		for icnt=1 to ubound(mods)
			strwhere="upper(userid)='" & ucase(struserid) &"' and upper(moduleid)='" & _
					mods(icnt) & "'"
			transarray(jcnt+icnt-1,0)="D"
			transarray(jcnt+icnt-1,1)=strtab
			transarray(jcnt+icnt-1,2)="tranStatus,approvedby,approvedmachine,applicationdate,systemdate"
			transarray(jcnt+icnt-1,3)=strfldval &"~'" & appdate & "'~sysdate"
			transarray(jcnt+icnt-1,4)=strwhere
			
			Response.Write (transarray(jcnt+icnt-1,1) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,2) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,3) & "<br>")
			Response.Write (transarray(jcnt+icnt-1,4) & "<br>")
		next
	end if
	
end if

	
	strmsg=obj.DataTransactions(transarray,,,,,"N")
	Response.Write (strmsg)
if 1=2 then
'if strval(0)="Group" then
	transarray(0,0)=strmode
	transarray(0,1)="genbankusergroupmst"
	transarray(0,2)="Status,approvedby,approvedmachine"
	transarray(0,3)=strfldval
	transarray(0,4)="groupcode='" & strgroupcode &"'"
	
	'strmsg=obj.DataTransactions(transarray)
end if
response.Redirect ("Genworkallotmentapproval.aspx?record=" & strmsg )
%>
	