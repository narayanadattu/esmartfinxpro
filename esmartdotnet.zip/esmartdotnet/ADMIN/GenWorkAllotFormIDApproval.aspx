 <%@ Page Language="vb" CodeBehind="GenWorkAllotFormIDApproval.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenWorkAllotFormIDApproval" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenWorkAllotFormIDApproval.ASP						*
'*	Purpose	  	     : To display available forms for the selected module  	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<SCRIPT LANGUAGE=javascript>
<!--

//-->
</SCRIPT>

</head>
<body bgcolor="#c7ba95" >
<form name="frmforms">
	<%
	''''Declaration of Variables
	
	Dim objfetch
	dim vark
	dim strdata
	dim recst
	dim cnt
	'''' Getting Module and user information from GenWorkallotmentapprove.asp
	strdata=Request.Form("hform")
	
	'''''' Creating the instances of objects
	 objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
	 recst=server.CreateObject("adodb.recordset")


'''''' Checking whether data is avaiable or not
 if len(strdata)>0 then
    ''''''' Split it using "|"  
    'Response.Write strdata
    vark=split(strdata,"|")
    '''''' if the data found in splitting
    if ubound(vark)>0 then  
	    '''''' if it is group bring all the forms and narrations for given group and module
	    mods=split(vark(2),",")
	    for icnt=1 to ubound(mods)
	    if vark(4)="group" then
			 recst=objfetch.singlerecordset("gengroupformsmst","forms,narration" , _
				"groupcode='" & vark(1) &"' and transtatus<>'A' and moduleid='" & mods(icnt) &"'")					    
			'Response.Write "gengroupformsmst" & " forms,narration" & _
			'	"groupcode='" & vark(1) &"' and status='P' and moduleid='" & mods(icnt) &"'"	
		'''''' if it is user bring all the forms and narrations for given user and module
		elseif vark(4)="user" then
			 recst=objfetch.singlerecordset("genuseridformsmst","forms,narration" , _
				"userid='" & vark(1) &"' and transtatus<>'A' and  moduleid='" & mods(icnt) &"'")					    
		end if
	
	
	   
  %>

      <table border="0" width="120" cellspacing="0" cellpadding="0">
      <tr>
      <td width="100%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<%=mods(icnt)%>&nbsp;&nbsp;&nbsp;Forms</font></td>
      </tr>
      </table>
      <table>
      
      	<%'''''' if records found 
      	'if 1=2 then
      	if not recst.EOF and not recst.BOF  then%>  
		    <%
		    '''''''' Print all the narrations of forms
		    do while not recst.EOF 
		     %>
			
		       <%cnt=cnt+1%>
				        <tr>
				        <td>
				 <font color=black face="MS Sans Serif" size="2"><%=recst(1).value%></font>
				</td>
				</tr>
		    <%
			  recst.MoveNext 
		     loop%>
		  
	   <%end if%>
	  <% next
	  end if%>
	
	<% obj=nothing%>
<%end if%>
<%'''''''' return the count of forms%>
<input type="hidden" name="hcnt" value="<%=cnt%>">
<input type="hidden" name="hform" id="hform">
<input type="hidden" name="hstatus" id="hstatus" value=<%=sts%>>
</form>
</body>
