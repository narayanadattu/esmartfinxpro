<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmGratuityReport.aspx.vb" Inherits="eSmartDotNet.frmGratuityReport"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
    <title>Gratuity Report</title>
    <SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
  
	<SCRIPT LANGUAGE="javascript">
	function QueryParam()
	{
	var strVal;

			strVal="GRATUITYREPORT"+"|"+window.document.frmSalgen.selGratuityFinyear.options[window.document.frmSalgen.selGratuityFinyear.selectedIndex].text
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popGRATUITYREPORT(str)
	{
		window.document.frmSalgen.mfgGratuity.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
			window.document.frmSalgen.mfgGratuity.cols = 4;
			window.document.frmSalgen.mfgGratuity.formatstring="<SLNO     |<EmpCode           |<Name                                                |>Gratuity Amt            ";
			
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgGratuity.rows = window.document.frmSalgen.mfgGratuity.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				//window.document.frmSalgen.mfgGratuity.textmatrix(aCnt+1,0) = aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgGratuity.textmatrix(aCnt+1,vCnt) = strCols[vCnt]
				}
			}
	}
	
	function Report(strrep)
	{
	
	var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
		
	strheadtype = "Gratuity REPORT"
	strheadsub = "Gratuity REPORT For The Financial Year "+ window.document.frmSalgen.selGratuityFinyear.options[window.document.frmSalgen.selGratuityFinyear.selectedIndex].text
	StrHead= strheadsub + ",60,80"
	window.document.frmSalgen.reptitle.value=strheadtype
	
	StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,0)+",5,L"+"~"  // slno
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,1)+",8,L"+"~" // empcode
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,2)+",30,L"+"~" //name
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,3)+",14,R"+"|" // Gratuity Amt
		
			for(icnt=1;icnt<=window.document.frmSalgen.mfgGratuity.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgGratuity.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgGratuity.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
			
			window.document.frmSalgen.hreport.value=StrArr
			//alert(StrArr)
			if (strrep == "HTML") 
			{
				window.document.frmSalgen.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmGratuityReport"
			}
			else
			{
				window.document.frmSalgen.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmGratuityReport"
			}
			///window.document.frmSalgen.action="../reportgridtemplate.aspx?strng="+"/Deposits/frmSalgen"
			window.document.frmSalgen.method="post"
			window.document.frmSalgen.submit() 
	}
	</script>
	</head>
   <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);onloadin();checkImplement();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>
	  <form name="frmSalgen">
</table>
</tr>
</td>
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%">
				<tr>
					<td align="left" class="bankHeaderLogo"></td>
					<td align="right" class="esmartBankerLogo"></td>
				</tr>
			</table>			
		</div>
		<div class="menuBar">
			<table cellpadding="0" border="0" cellspacing="0" width="100%">
				<tr>
					<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="30%" align="center" height="22" class="subHeader"><h2>Gratuity Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol">
		</div><%appdate=formatdatetime(session("applicationdate"),1)%>
		

								<div id="divGRAGEN" style="display:Block">
									<table border="1" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"></font></td>
										</tr>
										<tr>
										
<td width="100%" align="center">										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FinYear&nbsp;&nbsp;&nbsp;
											
											<%
												dim curfrmgrayer,curtograyer, curassessgrayer, curassessgrayer1,curassessgrayer2,gramon,grayer
												
												grayer = Year(session("applicationdate"))
												gramon = Month(session("applicationdate"))
												
												if gramon <= 3 then
												curfrmgrayer = cdate("01-Apr-" & cint(grayer) -1)
												curtograyer = cdate("31-Mar-" & cint(grayer))
												else
												curfrmgrayer = cdate("01-Apr-" & cint(grayer))
												curtograyer = cdate("31-Mar-" & cint(grayer)+1)
												end if
												curassessgrayer = Year(curfrmgrayer) & mid(Year(curtograyer),3,2)
												curassessgrayer1 = cint(Year(curfrmgrayer))+1 & cint(mid(Year(curtograyer),3,2))+1
												curassessgrayer2 = cint(Year(curfrmgrayer)) +2 & cint(mid(Year(curtograyer),3,2))+2
											%>
											<select name="selGratuityFinyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=curassessgrayer%>" selected><%=curassessgrayer%></option>
												<option value="<%=curassessgrayer1%>" ><%=curassessgrayer1%></option>
												<option value="<%=curassessgrayer2%>" ><%=curassessgrayer2%></option>
												
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="BtnQuery" class="button" name="BtnQuery" value=" Query " onclick="QueryParam()">
											
											</td>
											
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=150 id=mfgGratuity name=mfgGratuity style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT></td>
										<tr>
										<tr>
											<td width="100%"></td>
										</tr>
									</table>
								</div>
								
</td>
						</tr>
					</table>
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%">
							<div align="center">
								<center>	
								<table border="0" border="0" cellpadding="0" cellspacing="0" width="17%">
									<tr>
										<td width="100%" ><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmGratuityReport.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
									</tr>
								</table>
								</center>
							</div>
							</td>
						</tr>
					</table>
					<div class="footer">
						<div class="logo"></div>
						<div class="copyRight">
							&copy; E-Smart Banker - A Product of SAS Enterprises
						</div>
					</div>
					<input type="hidden" name="hreport">
					<input type="hidden" name="reptitle">
					<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
    </form>

  </body>
</html>
