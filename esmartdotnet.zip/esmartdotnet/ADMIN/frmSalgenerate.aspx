<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmSalgenerate.aspx.vb" Inherits="eSmartDotNet.frmSalgenerate"%>

<%
	dim strmessage

	strmessage=Request.QueryString("record")
	
	dim obj,rs
	
	dim impYn,brcod
	
	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	'rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE","CODE='EMPMOD'")
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE","CODE='HOTRAW'")
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
		brcod = rs(1).value
	end if
	
	Dim pBrCode

    pBrCode = Session("branchcode")
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
    <title>frmSalgenerate</title>
    <SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
  
	<SCRIPT LANGUAGE=javascript>
	function checkImplement()
	{
		var IMP="<%=impYn%>"
		var BCOD="<%=brcod%>"
		var stBrcd = window.document.frmSalgen.txtbranchcode.value
		
		if(IMP=="Y")
		{
			/*if(BCOD == stBrcd)
			{
			
			}
			else
			{
				alert("You are Not Authorised Branch. \n Please Contact Main Branch")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}*/
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
	}
	
	</script>
	
	<SCRIPT LANGUAGE=javascript>
	
	var strAppDt="<%=session("applicationdate")%>"
	var strUser="<%=session("userid")%>"
	var strMachine="<%=session("machineid")%>"
	//var strBr="<%=session("branchcode")%>"
	function Branch()
{  	

        telbr="Tellerbranch";
	   window.showModalDialog("../GEN/Listquery.aspx"+"?"+"st="+telbr,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
 }
 //Assign Selected Branch code and Branch desc to the Textboxes.
	 
function Branchcode(kstr)
 { 
 
	  assign(kstr,window.document.frmSalgen.txtbranchdesc,
	  window.document.frmSalgen.txtbranchcode)
	  
	 if (window.document.all.divSalReport.style.display=="block")
	 {
		SalRepclickMonth()		
			
	 }

if (window.document.all.divPayslip.style.display=="block")
	 {
		SalPaySlipSelEmployee()		
	 }
if (window.document.all.divGeneral.style.display=="block")
	 {
		GeneralRepSelEmployee()		
	 }	 
if (window.document.all.divEmDetail.style.display=="block")
	{
	EmployeeDetails()
	}
if (window.document.all.divRevoch.style.display=="block")
	{
	VoucherReprintclickMonth()	
	}
if (window.document.all.divTenRep.style.display=="block")
	{
	RentReportsclickMonth()
	}
 } 
// send Curr string to LIST.aspx for to get currencycode and currencydesc.

 function curr()
 {

	 st="Curr";	 
	window.showModalDialog("../GEN/Listquery.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:420px;DialogTop:200px");
 
 }
 //Assign Selected currency code and currency desc to the Textboxes.

function currency(kstr)
{
 	
	var k,p
    k=kstr.split("-----")
	window.document.frmSalgen.txtcurrencydesc.value =k[0]
	window.document.frmSalgen.txtcurrencycode.value =k[1]
	prn=k[2].length-1
  window.document.frmSalgen.hpr.value=prn
  p=""
  for(f=1;f<=prn;f++)
  {
    p=p + "0"
  }
  pres= "0." + p 
			
}	

	function ShowDivision(str)
	{
		window.document.frmSalgen.mfgSal.Rows=1
		window.document.frmSalgen.mfgRep.Rows=1
		window.document.frmSalgen.mfgGenRep.Rows=1
		window.document.frmSalgen.mfgEmpRep.Rows=1
		window.document.frmSalgen.mfgRealSal.Rows=1
		window.document.frmSalgen.mfgRent.Rows=1
		window.document.frmSalgen.mfgTenanrep.Rows = 1
		window.document.frmSalgen.mfgGratuity.Rows = 1
		
		window.document.all.divSalGen.style.display="none"
		window.document.all.divSalReport.style.display="none"
		window.document.all.divPayslip.style.display="none"
		window.document.all.divGeneral.style.display="none"
		window.document.all.divEmDetail.style.display="none"
		window.document.all.divRevoch.style.display="none"
		window.document.all.divTenRentGen.style.display="none"
		window.document.all.divTenRep.style.display="none"
		window.document.all.divGRAGEN.style.display="none"
		
		window.document.frmSalgen.selpayName1.value=""
		window.document.frmSalgen.selpayMon1.value=""
		window.document.frmSalgen.selMon.value=""
		window.document.frmSalgen.selpayName.value=""
		window.document.frmSalgen.selpayMon.value=""
		window.document.frmSalgen.selNm1.value=""
		window.document.frmSalgen.Opsel.value=""
		window.document.frmSalgen.selReMon.value=""
		window.document.frmSalgen.selVouchYer.value=""
		
		
		if(str=="0")
		{
			window.document.all.divSalGen.style.display="block"
		}
		
		if(str=="1")
		{
			window.document.all.divSalReport.style.display="block"
			SalRepclickMonth()	
			
			
		}
		
		if(str=="2")
		{
			window.document.all.divPayslip.style.display="block"
			window.document.frmSalgen.chkEmpAll.checked=false
			window.document.frmSalgen.selpayName.disabled=false
			SalPaySlipSelEmployee()
		}
		
		if(str=="3")
		{
			window.document.all.divGeneral.style.display="block"
			window.document.frmSalgen.radGentype(0).checked=true
			window.document.frmSalgen.chkGenEmpAll.checked=false
			window.document.frmSalgen.selpayName1.disabled=false
			GeneralRepSelEmployee()
		}
		
		if(str=="4")
		{
			window.document.all.divEmDetail.style.display="block"
			window.document.frmSalgen.chkEml.checked=false
			window.document.frmSalgen.selNm1.disabled=false
			EmployeeDetails()
		}
		if(str=="5")
		{
			window.document.all.divRevoch.style.display="block"
			VoucherReprintclickMonth()
		}
		if(str=="6")
		{
			window.document.all.divTenRentGen.style.display="block"
		}
		if(str=="7")
		{
			window.document.all.divTenRep.style.display="block"
			window.document.all.divCondRep.style.display="none"
			window.document.frmSalgen.radRentdetail(0).checked = true
			window.document.frmSalgen.chkConsol.checked = false
			RentReportsclickMonth()
		}
		
		if(str=="8")
		{
			window.document.all.divGRAGEN.style.display="block"
		}
	}
	
	function chkSol()
	{
		window.document.frmSalgen.mfgTenanrep.Rows = 1
	}
	function genChk()
	{
		window.document.frmSalgen.selpayName1.value=""
		window.document.frmSalgen.selpayMon1.value=""
		window.document.frmSalgen.mfgGenRep.Rows=1
		window.document.frmSalgen.chkGenEmpAll.checked=false
		window.document.frmSalgen.selpayName1.disabled=false
	}
	
	function genrat()
	{
		window.document.frmSalgen.mfgSal.Rows=1
		
		var StrCols,stEmp
		
		if(window.document.frmSalgen.selSalmon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selSalyear.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		if(window.document.frmSalgen.mfgRealSal.rows>1)
		{
			StrCols=""
			for(icnt=1;icnt<=window.document.frmSalgen.mfgRealSal.rows-1;icnt++)
			{
				if(window.document.frmSalgen.mfgRealSal.textmatrix(icnt,3)=="Y")
				{
					for(jcnt=0;jcnt<=window.document.frmSalgen.mfgRealSal.cols-1;jcnt++)
					{
						if (jcnt==1)
						{
							StrCols=StrCols+window.document.frmSalgen.mfgRealSal.TextMatrix(icnt,1)+","
						}
					}
				}
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
		}	
		
		if(StrCols=="")
		{
			alert("No records to Generate Salary")
			return;
		}
		
		stEmp = " AND EMPCODE IN ("+StrCols+")"
		
		strVal="SALGENRAT"+"|"+window.document.frmSalgen.selSalmon.options[window.document.frmSalgen.selSalmon.selectedIndex].text+"|"+window.document.frmSalgen.selSalyear.options[window.document.frmSalgen.selSalyear.selectedIndex].text+"|"+window.document.frmSalgen.txtbranchcode.value +"|"+ stEmp
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popSal(str)
	{
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		if(str=="EXIT")
		{
			alert("Salary is Already Generated")
			return;
		}
		
		var stTotDed,stNet
		
		stTotDed = 0
		stNet = 0
		
		var stSal = str.split("|")
		
		window.document.frmSalgen.mfgSal.Rows=1
		
		window.document.frmSalgen.mfgSal.cols=20;
		window.document.frmSalgen.mfgSal.formatstring="<SLNO|<Name                        |>Basic          |>DA          |>HRA          |> Allowance    |>Gross          |>PF          |>PTax          |>RD          |>LOAN          |>ADV          |>TDS          |> GIP           |>Oth Ded       |>Esi        |>VPF           |> Oth Allow    |>TDed          |>Net Pay           ";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmSalgen.mfgSal.rows=window.document.frmSalgen.mfgSal.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				/*window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,2)=strCols[1]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,2)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,3)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,4)=strCols[3]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,4)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,5)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,6)=strCols[5]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,6)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,7)=strCols[6]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,7)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,7)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,8)=strCols[7]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,8)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,8)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,9)=strCols[8]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,9)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,9)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,10)=strCols[9]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,10)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,10)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,11)=strCols[10]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,11)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,11)),2)
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,12)=strCols[11]
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,12)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,12)),2)*/
				
				stTotDed = 0
				
				stTotDed = parseFloat(strCols[6])+parseFloat(strCols[7])+parseFloat(strCols[8])+parseFloat(strCols[9])+parseFloat(strCols[10])+parseFloat(strCols[11])+parseFloat(strCols[12])+parseFloat(strCols[13])+parseFloat(strCols[14])+parseFloat(strCols[15])
		
		
		 
				//window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,17)=stTotDed
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,18)=stTotDed
				//window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,13)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,13)),2)
				
				stNet = 0
				
				stNet = (parseFloat(strCols[1])+parseFloat(strCols[2])+parseFloat(strCols[3])+parseFloat(strCols[4]))//-stTotDed
				
				if(stNet == 0)
				{
					stNet = parseFloat(strCols[5])
				}
				else
				{
					stNet = stNet
				}
				
				stNet = stNet - stTotDed 
				
				//window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,18)=stNet
				window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,19)=stNet
				//window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,14)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgSal.textmatrix(aCnt+1,14)),2)
			}
			
			
		}
		
var totbasic,totda,tothra,totallowance,totgross, totpf,totptax,totrd,totloan,totadv,tottds,totgip,totothded,totesi,totvpf,totothallow,tottded,totnetpay
totbasic = 0
totda = 0
tothra = 0
totallowance = 0
totgross = 0
 totpf = 0
totptax = 0
totrd = 0
totloan = 0
totadv = 0
tottds = 0
totgip = 0
totothded = 0
totesi = 0
totvpf = 0
totothallow = 0
tottded = 0
totnetpay = 0

	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
	var strCols=stSal[aCnt].split("~")
	totbasic =  parseFloat(totbasic) + parseFloat(strCols[1])
	totda =  parseFloat(totda) + parseFloat(strCols[2])
	tothra =  parseFloat(tothra) + parseFloat(strCols[3])
	totallowance =  parseFloat(totallowance) + parseFloat(strCols[4])
	totgross =  parseFloat(totgross) + parseFloat(strCols[5])
	totpf =  parseFloat(totpf) + parseFloat(strCols[6])
	totptax =  parseFloat(totptax) + parseFloat(strCols[7])
	totrd =  parseFloat(totrd) + parseFloat(strCols[8])
	totloan =  parseFloat(totloan) + parseFloat(strCols[9])
	totadv =  parseFloat(totadv) + parseFloat(strCols[10])
	tottds =  parseFloat(tottds) + parseFloat(strCols[11])
	totgip =  parseFloat(totgip) + parseFloat(strCols[12])
	totothded =  parseFloat(totothded) + parseFloat(strCols[13])
	totesi =  parseFloat(totesi) + parseFloat(strCols[14])
	totvpf =  parseFloat(totvpf) + parseFloat(strCols[15])
	totothallow =  parseFloat(totothallow) + parseFloat(strCols[16])

	
	}
	
	for(icnt=1;icnt<=window.document.frmSalgen.mfgSal.rows-1;icnt++)
	{
		tottded =  parseFloat(tottded) + parseFloat(window.document.frmSalgen.mfgSal.TextMatrix(icnt,18))

	totnetpay =  parseFloat(totnetpay) + parseFloat(window.document.frmSalgen.mfgSal.TextMatrix(icnt,19))
}

		window.document.frmSalgen.mfgSal.rows=window.document.frmSalgen.mfgSal.rows+2
var rowscnt
rowscnt = window.document.frmSalgen.mfgSal.rows

	window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,1)= "Total"
	window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,2)=totbasic
	
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,3) = totda
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,4) = tothra
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,5) = totallowance
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,6) = totgross
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,7) =  totpf
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,8) = totptax
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,9) = totrd
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,10) = totloan
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,11) = totadv
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,12) = tottds
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,13) = totgip
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,14) = totothded
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,15) = totesi
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,16) = totvpf
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,17) = totothallow
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,18) = tottded
window.document.frmSalgen.mfgSal.textmatrix(rowscnt-1,19) = totnetpay


	

		CheckLoanDepstatusYN()
	}
	
	function CheckLoanDepstatusYN()
	{
	var strempname,strdep,strloan
strempname = ""
strdep = ""
strloan = ""

for(icnt=1;icnt<=window.document.frmSalgen.mfgSal.rows-3;icnt++)
	{
strempname = strempname  + window.document.frmSalgen.mfgSal.TextMatrix(icnt,1) + ","	
strdep = strdep + window.document.frmSalgen.mfgSal.TextMatrix(icnt,9) + ","
strloan = strloan + window.document.frmSalgen.mfgSal.TextMatrix(icnt,10) + ","

	}
strempname=strempname.substr(0,strempname.length-1)
strdep=strdep.substr(0,strdep.length-1)
strloan=strloan.substr(0,strloan.length-1)

strVal="CheckLoanDepstatusYN"+"|"+strempname+"|"+strdep+"|"+strloan
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;

	}
	
	function popCheckLoanDepstatusYN(str)
	{
	if(str=="No Records")
		{
			alert("No Records Found")
			return;
		}
		else
		{
		var stRep
		var strresult
		strresult=""
		stRep =  str.split("|")
		
			for(aCnt=0;aCnt<=stRep.length-1;aCnt++)
			{
			strresult = strresult + stRep[aCnt] + "\r\n"
			}
			alert(strresult + "Goto --> Parmameters --> Salary Parameters ---> Salary Deduction ----> Modify")
		}
	}
	
	function genReport()
	{
	var strallempyn
		window.document.frmSalgen.mfgSal.Rows=1
		
		if(window.document.frmSalgen.selMon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selRepYer.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		if(window.document.frmSalgen.chkSalRepEmpAll.checked==true)
		{
		strallempyn = "Y"
		}
		else
		{
		strallempyn = "N"
		}
		strVal="SALREPRT"+"|"+window.document.frmSalgen.selMon.options[window.document.frmSalgen.selMon.selectedIndex].text+"|"+window.document.frmSalgen.selRepYer.options[window.document.frmSalgen.selRepYer.selectedIndex].text+"|"+window.document.frmSalgen.txtbranchcode.value +"|"+ strallempyn
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popSalRep(str)
	{
		window.document.frmSalgen.mfgSal.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var strTotded, strBa,strDa,strHra,strAlow,strGrss,strPf,strPtax,strRd,strLan,strAdv,strGip,strTds,strOtd,strTotd,strNetp,stEsi,stVpf,strOtalow
		
		strBa=0
		strDa=0
		strHra=0
		strAlow=0
		strGrss=0
		strPf=0
		strPtax=0
		strRd=0
		strLan=0
		strAdv=0
		strGip=0
		strTds=0
		strOtd=0
		strTotd=0
		strNetp=0
		stEsi=0
		stVpf=0
		strOtalow = 0
		
		var stRep = str.split("|")
		
		window.document.frmSalgen.mfgRep.Rows=1
		
		window.document.frmSalgen.mfgRep.cols=22;
		window.document.frmSalgen.mfgRep.formatstring="<SLNO|<EmpCode     |<Name           |>Basic          |>DA          |>HRA          |> Allowance    |>Gross          |>PF          |>PTax          |>RD          |>LOAN          |>ADV          |>GIP          |> TDS           |>Oth Ded       |>ESI          |>VPF            |>Oth Alow    |>TDed          |>Net Pay           |< Panno               ";
		
		for(aCnt=0;aCnt<=stRep.length-1;aCnt++)
		{
			window.document.frmSalgen.mfgRep.rows=window.document.frmSalgen.mfgRep.rows+1
			
			var strCols=stRep[aCnt].split("~")
			
			window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,1)=strCols[0]
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,2)=strCols[1]
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,3)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,4)=strCols[3]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,4)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,5)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,6)=strCols[5]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,6)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,7)=strCols[6]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,7)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,7)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,8)=strCols[7]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,8)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,8)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,9)=strCols[8]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,9)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,9)),2)
								
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,10)=strCols[9]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,10)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,10)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,11)=strCols[10]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,11)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,11)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,12)=strCols[11]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,12)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,12)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,13)=strCols[12]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,13)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,13)),2)
				
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,14)=strCols[13]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,14)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,14)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,15)=strCols[14]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,15)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,15)),2)
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,16)=strCols[15]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,16)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,16)),2)
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,17)=strCols[16]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,17)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,17)),2)
			
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,18)=strCols[17]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,18)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,18)),2)
			
				strTotded = 0
				strTotded = parseFloat(strCols[7])+parseFloat(strCols[8])+parseFloat(strCols[9])+parseFloat(strCols[10])+parseFloat(strCols[11])+parseFloat(strCols[12])+parseFloat(strCols[13])+parseFloat(strCols[14])+parseFloat(strCols[15])+parseFloat(strCols[16])
				
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,19)=strTotded
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,19)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,19)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,20)=strCols[18]
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,20)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,20)),2)
				
				window.document.frmSalgen.mfgRep.textmatrix(aCnt+1,21)=strCols[19] // panno
			}
			
			strBa = parseFloat(strBa) + parseFloat(strCols[2])
			strDa = parseFloat(strDa) + parseFloat(strCols[3])
			strHra = parseFloat(strHra) + parseFloat(strCols[4])
			strAlow = parseFloat(strAlow) + parseFloat(strCols[5])
			strGrss = parseFloat(strGrss) + parseFloat(strCols[6])
			strPf = parseFloat(strPf) + parseFloat(strCols[7])
			strPtax = parseFloat(strPtax) + parseFloat(strCols[8])
			strRd = parseFloat(strRd) + parseFloat(strCols[9])
			strLan = parseFloat(strLan) + parseFloat(strCols[10])
			strAdv = parseFloat(strAdv) + parseFloat(strCols[11])
			strGip = parseFloat(strGip) + parseFloat(strCols[12])
			strTds = parseFloat(strTds) + parseFloat(strCols[13])
			strOtd = parseFloat(strOtd) + parseFloat(strCols[14])
			stEsi = parseFloat(stEsi) + parseFloat(strCols[15])
			stVpf = parseFloat(stVpf) + parseFloat(strCols[16])
			strOtalow = parseFloat(strOtalow) + parseFloat(strCols[17])
			strTotd = parseFloat(strTotd) + parseFloat(strTotded)
			strNetp = parseFloat(strNetp) + parseFloat(strCols[18])
			
		}
			window.document.frmSalgen.hidBa.value = strBa
			window.document.frmSalgen.hidBa.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidBa.value),2)
			window.document.frmSalgen.hidDa.value = strDa
			window.document.frmSalgen.hidDa.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidDa.value),2)
			window.document.frmSalgen.hidHra.value = strHra
			window.document.frmSalgen.hidHra.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidHra.value),2)
			window.document.frmSalgen.hidAlw.value = strAlow
			window.document.frmSalgen.hidAlw.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidAlw.value),2)
			window.document.frmSalgen.hidGrs.value = strGrss
			window.document.frmSalgen.hidGrs.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidGrs.value),2)
			window.document.frmSalgen.hidPf.value = strPf
			window.document.frmSalgen.hidPf.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidPf.value),2)
			window.document.frmSalgen.hidPtax.value = strPtax
			window.document.frmSalgen.hidPtax.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidPtax.value),2)
			window.document.frmSalgen.hidRd.value = strRd
			window.document.frmSalgen.hidRd.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidRd.value),2)
			window.document.frmSalgen.hidLon.value = strLan
			window.document.frmSalgen.hidLon.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidLon.value),2)
			window.document.frmSalgen.hidAdv.value = strAdv
			window.document.frmSalgen.hidAdv.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidAdv.value),2)
			window.document.frmSalgen.hidGip.value = strGip
			window.document.frmSalgen.hidGip.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidGip.value),2)
			window.document.frmSalgen.hidTds.value = strTds
			window.document.frmSalgen.hidTds.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidTds.value),2)
			window.document.frmSalgen.hidOtd.value = strOtd
			window.document.frmSalgen.hidOtd.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidOtd.value),2)
			window.document.frmSalgen.hidEsi.value = stEsi 
			window.document.frmSalgen.hidEsi.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidEsi.value),2)
			window.document.frmSalgen.hidVpf.value = stVpf 
			window.document.frmSalgen.hidVpf.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidVpf.value),2)
			window.document.frmSalgen.hidTotd.value = strTotd
			window.document.frmSalgen.hidTotd.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidTotd.value),2)
			window.document.frmSalgen.hidNet.value = strNetp
			window.document.frmSalgen.hidNet.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidNet.value),2)
			window.document.frmSalgen.hidOtalow.value = strOtalow
			window.document.frmSalgen.hidOtalow.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidOtalow.value),2)
	}
	
	function Report(strrep)
	{
		var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
		
		if(window.document.all.divSalGen.style.display=="block")
		{
			strheadtype = "EMPLOYEE SALARY REPORT"
			strheadsub = "EMPLOYEE SALARY REPORT For The Month "+ window.document.frmSalgen.selSalmon.options.value 
		}
		if(window.document.all.divSalReport.style.display=="block")
		{
			strheadtype = "SALARY REPORT"
			strheadsub = "SALARY REPORT For The Month "+ window.document.frmSalgen.selMon.options.value 
		}
		
		if(window.document.all.divPayslip.style.display=="block")
		{
			PayslipGen(strrep)
		}
		
		if(window.document.all.divRevoch.style.display=="block")
		{
			ReVoucher(strrep)
		}
		
		if(window.document.all.divGeneral.style.display=="block")
		{
			if(window.document.frmSalgen.RadType(0).checked==true)
			{
				strheadtype = "ESI REPORT"
				strheadsub = "ESI REPORT For The Month "+ window.document.frmSalgen.selpayMon.options.value 
			}
			if(window.document.frmSalgen.RadType(1).checked==true)
			{
				strheadtype = "PF REPORT"
				strheadsub = "PF REPORT For The Month "+ window.document.frmSalgen.selpayMon.options.value 
			}
			if(window.document.frmSalgen.RadType(2).checked==true)
			{
				strheadtype = "VPF REPORT"
				strheadsub = "VPF REPORT For The Month "+ window.document.frmSalgen.selpayMon.options.value 
			}
		}
		
		if(window.document.all.divEmDetail.style.display=="block")
		{
			strheadtype = "Employee Detail Report"
			
			if(window.document.frmSalgen.Opsel.value=="")
			{
				strheadsub = "All Employee Detail Report "
			}
			if(window.document.frmSalgen.Opsel.value=="R")
			{
				strheadsub = "Running Employee Detail Report "
			}
			if(window.document.frmSalgen.Opsel.value=="C")
			{
				strheadsub = "Closed Employee Detail Report "
			}
		}
		
		if(window.document.all.divTenRentGen.style.display=="block")
		{
			strheadtype = "RENT REPORT"
			strheadsub = "RENT REPORT For The Month "+ window.document.frmSalgen.selTenanmon.options[window.document.frmSalgen.selTenanmon.selectedIndex].text
		}
		
		if(window.document.all.divTenRep.style.display=="block")
		{
			
			strheadtype = "RENT DETAIL REPORT"
			
			if(window.document.frmSalgen.radRentdetail(0).checked == true)
			{
				if(window.document.frmSalgen.chkConsol.checked==true)
				{
					strheadsub = "CONSOLIDATE RENT DETAIL REPORT "
				}
				else
				{
					strheadsub = "RENT DETAIL REPORT For The Branch "+ window.document.frmSalgen.txtbranchcode.value
				}
			}
			if(window.document.frmSalgen.radRentdetail(1).checked == true)
			{
				if(window.document.frmSalgen.chkConsol.checked==true)
				{
					strheadsub = "CONSOLIDATE RENT PAID DETAIL REPORT For The Month "+window.document.frmSalgen.selRentMon.options[window.document.frmSalgen.selRentMon.selectedIndex].text
				}
				else
				{
					strheadsub = "RENT PAID DETAIL REPORT For The Month "+window.document.frmSalgen.selRentMon.options[window.document.frmSalgen.selRentMon.selectedIndex].text
				}
			}
			
		}
		
		if(window.document.all.divGRAGEN.style.display=="block")
		{
			strheadtype = "Gratuity Generation REPORT"
			strheadsub = "Gratuity Generation REPORT For The Financial Year "+ window.document.frmSalgen.selGratuityFinyear.options[window.document.frmSalgen.selGratuityFinyear.selectedIndex].text
		}
	//	alert("hi")
			StrHead= strheadsub + ",60,80"
			window.document.frmSalgen.reptitle.value=strheadtype
		
		if(window.document.all.divSalGen.style.display=="block")
		{	
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,0)+",4,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,1)+",45,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,2)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,3)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,4)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,5)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,6)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,7)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,8)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,9)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,10)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,11)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,12)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,13)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,14)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,15)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,16)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,17)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,18)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgSal.TextMatrix(0,19)+",12,R"+"|"
		}
		
		if(window.document.all.divTenRentGen.style.display=="block")
		{	
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,0)+",4,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,1)+",8,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,2)+",8,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,3)+",8,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,4)+",17,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,5)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,6)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,7)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,8)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgTenanGen.TextMatrix(0,8)+",12,R"+"|"
		}
		
		if(window.document.all.divTenRep.style.display=="block")
		{
			if(window.document.frmSalgen.radRentdetail(0).checked == true)
			{
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,0)+",4,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,1)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,2)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,3)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,4)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,5)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,6)+",8,C"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,7)+",8,C"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,8)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,9)+",12,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,10)+",12,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,11)+",12,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,12)+",50,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,13)+",6,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,14)+",50,L"+"|"
			}
			if(window.document.frmSalgen.radRentdetail(1).checked == true)
			{
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,0)+",4,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,1)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,2)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,3)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,4)+",8,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,5)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,6)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,7)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,8)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,9)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,10)+",9,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgTenanrep.TextMatrix(0,11)+",50,L"+"|"
			}
		}
		
		if(window.document.all.divSalReport.style.display=="block")
		{	
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,0)+",4,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,1)+",17,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,2)+",25,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,3)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,4)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,5)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,6)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,7)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,8)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,9)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,10)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,11)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,12)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,13)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,14)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,15)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,16)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,17)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,18)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,19)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,20)+",12,R"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgRep.TextMatrix(0,21)+",12,L"+"|"
		}
		
		if(window.document.all.divGeneral.style.display=="block")
		{	
			if((window.document.frmSalgen.RadType(0).checked==true)||(window.document.frmSalgen.RadType(1).checked==true))
			{
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,0)+",4,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,1)+",30,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,2)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,3)+",12,R"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,4)+",12,R"+"|"
			}
			if(window.document.frmSalgen.RadType(2).checked==true)
			{
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,0)+",4,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,1)+",30,L"+"~"
				StrCol=StrCol+window.document.frmSalgen.mfgGenRep.TextMatrix(0,2)+",12,R"+"|"
			}
			
		}
		
		if(window.document.all.divEmDetail.style.display=="block")
		{
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,0)+",4,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,1)+",6,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,2)+",12,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,3)+",25,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,4)+",20,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,5)+",12,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,6)+",12,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,7)+",6,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,8)+",12,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,9)+",12,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,10)+",20,L"+"~"
			StrCol=StrCol+window.document.frmSalgen.mfgEmpRep.TextMatrix(0,11)+",12,L"+"|"
			
		}
	
		if(window.document.all.divGRAGEN.style.display=="block")
		{
		
		StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,0)+",4,L"+"~"  // sno
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,1)+",6,L"+"~" // empcode
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,2)+",20,L"+"~" //name
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,3)+",12,R"+"~" //basic
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,4)+",12,R"+"~" // DA
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,5)+",12,R"+"~" // Gratuity Amt
			StrCol=StrCol+window.document.frmSalgen.mfgGratuity.TextMatrix(0,6)+",6,R"+"|" // postyn
			
		}
	
		if(window.document.all.divSalGen.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgSal.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgSal.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgSal.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		}
		
		if(window.document.all.divTenRentGen.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgTenanGen.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgTenanGen.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgTenanGen.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		}
		
		if(window.document.all.divTenRep.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgTenanrep.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgTenanrep.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgTenanrep.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		}
		
		if(window.document.all.divGeneral.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgGenRep.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgGenRep.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgGenRep.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			
			if((window.document.frmSalgen.RadType(0).checked==true)||(window.document.frmSalgen.RadType(1).checked==true))
			{
				StrColRow=StrColRow+"|~------------------------~------------~------------~------------"
				StrColRow=StrColRow+"|~"+"Total : "+"~"+window.document.frmSalgen.hidEmpSum.value+"~"+window.document.frmSalgen.hidEmperSum.value+"~"+window.document.frmSalgen.hidEmpTot.value
			}
			if(window.document.frmSalgen.RadType(2).checked==true)
			{
				StrColRow=StrColRow+"|~------------------------~------------"
				StrColRow=StrColRow+"|~"+"Total : "+"~"+window.document.frmSalgen.hidEmpSum.value
			}
			
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		}
		
		if(window.document.all.divSalReport.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgRep.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgRep.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgRep.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			
			StrColRow=StrColRow+"|~~-------------------------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------~----------"
			StrColRow=StrColRow+"|~~"+"Total : "+"~"+window.document.frmSalgen.hidBa.value+"~"+window.document.frmSalgen.hidDa.value+"~"+window.document.frmSalgen.hidHra.value+"~"+window.document.frmSalgen.hidAlw.value+"~"+window.document.frmSalgen.hidGrs.value+"~"+window.document.frmSalgen.hidPf.value+"~"+window.document.frmSalgen.hidPtax.value+"~"+window.document.frmSalgen.hidRd.value+"~"+window.document.frmSalgen.hidLon.value+"~"+window.document.frmSalgen.hidAdv.value+"~"+window.document.frmSalgen.hidGip.value+"~"+window.document.frmSalgen.hidTds.value+"~"+window.document.frmSalgen.hidOtd.value+"~"+window.document.frmSalgen.hidEsi.value+"~"+window.document.frmSalgen.hidVpf.value+"~"+window.document.frmSalgen.hidOtalow.value+"~"+window.document.frmSalgen.hidTotd.value+"~"+window.document.frmSalgen.hidNet.value
			
			StrCol=StrCol+StrColRow
			
			StrArr=StrHead+"|"+StrCol
		}
		
		if(window.document.all.divEmDetail.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgEmpRep.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgEmpRep.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgEmpRep.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		
		}
			
		if(window.document.all.divGRAGEN.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmSalgen.mfgGratuity.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmSalgen.mfgGratuity.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgGratuity.TextMatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol
		}
		
		window.document.frmSalgen.hreport.value=StrArr
		//alert(StrArr)
		
		if (strrep == "HTML") 
		{
			window.document.frmSalgen.action="../ReportGridTemplate.aspx?strng="+"/ADMIN/frmSalgenerate"
		}
		else
		{
			window.document.frmSalgen.action="../ReportGridTemplateXL.aspx?strng="+"/ADMIN/frmSalgenerate"
		}
		///window.document.frmSalgen.action="../reportgridtemplate.aspx?strng="+"/Deposits/frmSalgen"
		window.document.frmSalgen.method="post"
		window.document.frmSalgen.submit() 
	
	}
	
	function subtrans()
	{
		var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
		var stGr =""
		var stGst = ""
		var stRevGst = ""
		strSum = 0
		stGr = 0
		stGst = 0
		stRevGst = 0
		
		var stmon
		var stYear
		var StNam
		
		if(window.document.all.divSalGen.style.display=="block")
		{
			StNam = "Salary"
		}
		if(window.document.all.divTenRentGen.style.display=="block")
		{
			StNam = "Rent"
		}
		
		if (confirm("Once "+StNam+" Generated it should not be Deleted or Modify\nDo You want to Continue ?") == true)
		{
			if(confirm("Are You Sure") == true)
			{
				if(confirm("Are You Sure") == true)
				{
				
				}
				else
				{
					return;
				}
			}
			else
			{
				return;
			}
		}
		else
		{
			return;
		}
		
		if(window.document.all.divSalGen.style.display=="block")
		{
			stmon = window.document.frmSalgen.selSalmon.options[window.document.frmSalgen.selSalmon.selectedIndex].text
			
			stYear = window.document.frmSalgen.selSalyear.options[window.document.frmSalgen.selSalyear.selectedIndex].text ///window.document.frmSalgen.selSalyear.value
			
			
			
			if(window.document.all.divSalGen.style.display=="block")
			{
				
				for(icnt=1;icnt<=window.document.frmSalgen.mfgSal.rows-1;icnt++)
				{
					StrCols=""
					for(jcnt=0;jcnt<=window.document.frmSalgen.mfgSal.Cols-1;jcnt++)
					{
						StrCols=StrCols+window.document.frmSalgen.mfgSal.TextMatrix(icnt,jcnt)+"~"
					}
					
					//strSum = eval(strSum) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,6)) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,17)) //- eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,15))
					
					if((eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,2))=="0") &&  (eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,3))=="0") && (eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,4))=="0") && (eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,5))=="0"))
					{
						stGr = eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,6))
					}
					else
					{
						stGr = eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,2)) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,3)) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,4)) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,5))
					}
					
					strSum = eval(strSum) + eval(stGr) + eval(window.document.frmSalgen.mfgSal.TextMatrix(icnt,17))
					
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"|"
				}
				StrColRow=StrColRow.substr(0,StrColRow.length-1)
				StrCol=StrCol+StrColRow
				
			}
			
			if(StrCol=="")
			{
				alert("Please Fill Data in Grid First")
				return;
			}
			
			var strPrm=strAppDt+"~"+strUser+"~"+strMachine+"~"+strSum+"~"+window.document.frmSalgen.txtbranchcode.value+"~"+stmon+"~"+stYear+"@"+StrCol
			
			window.document.frmSalgen.postdata.value="OKCLICK$"+strPrm
			window.document.frmSalgen.action="SalGen.aspx"
			window.document.frmSalgen.method="post"
			window.document.frmSalgen.submit()
		}
		
		if(window.document.all.divTenRentGen.style.display=="block")
		{
			stmon = window.document.frmSalgen.selTenanmon.options[window.document.frmSalgen.selTenanmon.selectedIndex].text
			
			stYear = window.document.frmSalgen.selTenanyear.options[window.document.frmSalgen.selTenanyear.selectedIndex].text
			
			for(icnt=1;icnt<=window.document.frmSalgen.mfgTenanGen.rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=1;jcnt<=window.document.frmSalgen.mfgTenanGen.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmSalgen.mfgTenanGen.TextMatrix(icnt,jcnt)+"~"
				}
				
				strSum = eval(strSum) + eval(window.document.frmSalgen.mfgTenanGen.TextMatrix(icnt,5))
				stGst = eval(stGst) + eval(window.document.frmSalgen.mfgTenanGen.TextMatrix(icnt,6))
				stRevGst = eval(stRevGst) + eval(window.document.frmSalgen.mfgTenanGen.TextMatrix(icnt,7))
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			
			if(StrCol=="")
			{
				alert("Please Fill Data in Grid First")
				return;
			}
			
			var strPrm=strAppDt+"~"+strUser+"~"+strMachine+"~"+strSum+"~"+stGst+"~"+stRevGst+"~"+window.document.frmSalgen.txtbranchcode.value+"~"+stmon+"~"+stYear+"@"+StrCol
			
			window.document.frmSalgen.postdata.value="OKCLICK$"+strPrm
			window.document.frmSalgen.action="TenantRentCollection.aspx"
			window.document.frmSalgen.method="post"
			window.document.frmSalgen.submit()
		}
		
		if(window.document.all.divGRAGEN.style.display=="block")
		{
		var strTotDrSum
		strTotDrSum=0
			stfinYear = window.document.frmSalgen.selGratuityFinyear.options[window.document.frmSalgen.selGratuityFinyear.selectedIndex].text
			
			for(icnt=1;icnt<=window.document.frmSalgen.mfgGratuity.rows-1;icnt++)
			{
				
			if (window.document.frmSalgen.mfgGratuity.textmatrix(icnt,6)=="Y")
				{
				
					StrCols=""
					for(jcnt=1;jcnt<=window.document.frmSalgen.mfgGratuity.Cols-1;jcnt++)
					{
						StrCols=StrCols+window.document.frmSalgen.mfgGratuity.TextMatrix(icnt,jcnt)+"~"
					}
					
				
				
				strTotDrSum = eval(strTotDrSum) + eval(window.document.frmSalgen.mfgGratuity.TextMatrix(icnt,5))
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
				}
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			
			if(StrCol=="")
			{
				alert("Please Fill Data in Grid First")
				return;
			}
	
			var strPrm=strAppDt+"~"+strUser+"~"+strMachine+"~"+strTotDrSum+"~"+window.document.frmSalgen.txtbranchcode.value+"~"+stfinYear+"@"+StrCol
			//alert(strPrm)
			window.document.frmSalgen.postdata.value="OKCLICK$"+strPrm
			window.document.frmSalgen.action="GratuityGenPost.aspx"
			window.document.frmSalgen.method="post"
			window.document.frmSalgen.submit()
		}
		
	}
	
	function onloadin()
	{
		if('<%=strmessage%>'!="")
		{
			var mess="<%=strmessage%>"
			alert(mess)
			
			if(window.document.all.divSalGen.style.display=="block")
			{
				var stBat,stmg
				
				stmg = mess.substr(0, 29)
				stBat = mess.substr(30, 35)
				
				if (stmg == "Transaction Completed Batchno")
				{
					if (confirm("Do You want to Take Voucer Printing ?") == true)
					{
						var str = "Print" +"|"+ window.document.frmSalgen.txtbranchcode.value + "|" + strAppDt + "|" + stBat +"|"+ "HTML"
						
						window.document.frmSalgen.action="SalVoucherPrint.aspx?strVal="+str
						window.document.frmSalgen.method="post"
						window.document.frmSalgen.submit()
					}
					else
					{
						location.replace("../ADMIN/frmSalgenerate.aspx")
					}
					
				}
				else
				{
					location.replace("../ADMIN/frmSalgenerate.aspx")
				}
			}
			else
			{
				location.replace("../ADMIN/frmSalgenerate.aspx")
			}
		}
	}
	
	function mfgSal_DblClick()
	{
		row=window.document.frmSalgen.mfgSal.Row
		
		window.document.frmSalgen.txtAditional.disabled=false
		window.document.frmSalgen.txtAlow.disabled=false
		
		window.document.frmSalgen.hidRow.value=row
		
		for (d=0 ;d<window.document.frmSalgen.mfgSal.Cols;d++) 
		{  
			window.document.frmSalgen.mfgSal.Col=d				
			window.document.frmSalgen.mfgSal.CellBackColor=5831256
		}
		
	}
	
	function AddOther()
	{
		var num
		
		num = window.document.frmSalgen.hidRow.value
		
		if(window.document.frmSalgen.txtAditional.value=="") 
		{
			alert("Please Enter the Deduction Value")
			return;
		}
		
		window.document.frmSalgen.mfgSal.textmatrix(num,14)=window.document.frmSalgen.txtAditional.value
		
		window.document.frmSalgen.txtAditional.value=""
		window.document.frmSalgen.txtAditional.disabled=true
		
		for (d=0 ;d<window.document.frmSalgen.mfgSal.Cols;d++) 
		{  
			window.document.frmSalgen.mfgSal.Col=d				
			window.document.frmSalgen.mfgSal.CellBackColor=16777215
		}
		
		recal(num)
	}
	
	function recal(num)
	{
		var rownm, gros, totalded, net
		
		rownm = num
		
		
		for (d=0 ;d<window.document.frmSalgen.mfgSal.Cols;d++) 
		{ 
			gros = eval(window.document.frmSalgen.mfgSal.textmatrix(num,2))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,3))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,4))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,5))
			
			if(gros == 0)
			{
				gros = eval(window.document.frmSalgen.mfgSal.textmatrix(num,6))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,17))
			}
			else
			{
				gros = eval(gros)+eval(window.document.frmSalgen.mfgSal.textmatrix(num,17))
			}
			
			totalded = eval(window.document.frmSalgen.mfgSal.textmatrix(num,7)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,8)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,9)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,10)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,11)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,12)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,13)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,14))+ eval(window.document.frmSalgen.mfgSal.textmatrix(num,15)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,16))
			
			net = eval(gros) - eval(totalded)
			
		}
		
		//window.document.frmSalgen.mfgSal.textmatrix(num,17) = totalded
		//window.document.frmSalgen.mfgSal.textmatrix(num,18) = net
		
		window.document.frmSalgen.mfgSal.textmatrix(num,18) = totalded
		window.document.frmSalgen.mfgSal.textmatrix(num,19) = net
	}
	
	function AlowOther()
	{
		var num
		
		num = window.document.frmSalgen.hidRow.value
		
		if(window.document.frmSalgen.txtAlow.value=="") 
		{
			alert("Please Enter the Allowance Value")
			return;
		}
		
		window.document.frmSalgen.mfgSal.textmatrix(num,17)=window.document.frmSalgen.txtAlow.value
		
		window.document.frmSalgen.txtAlow.value=""
		window.document.frmSalgen.txtAlow.disabled=true
		
		for (d=0 ;d<window.document.frmSalgen.mfgSal.Cols;d++) 
		{  
			window.document.frmSalgen.mfgSal.Col=d				
			window.document.frmSalgen.mfgSal.CellBackColor=16777215
		}
		
		reAlowcal(num)
	}
	
	function reAlowcal(num)
	{
		var alrownm, algros, altotalded, alnet
		
		alrownm = num
		
		for (d=0 ;d<window.document.frmSalgen.mfgSal.Cols;d++) 
		{ 
			algros = eval(window.document.frmSalgen.mfgSal.textmatrix(num,2))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,3))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,4))+eval(window.document.frmSalgen.mfgSal.textmatrix(num,5))
			
			if(algros == 0)
			{
				algros = eval(window.document.frmSalgen.mfgSal.textmatrix(num,6))
			}
			else
			{
				algros = eval(algros)
			}
			
			altotalded = eval(window.document.frmSalgen.mfgSal.textmatrix(num,7)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,8)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,9)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,10)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,11)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,12)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,13)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,14))+ eval(window.document.frmSalgen.mfgSal.textmatrix(num,15)) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,16))
			
			alnet = eval(algros) - eval(altotalded) + eval(window.document.frmSalgen.mfgSal.textmatrix(num,17))
			
		}
		
		window.document.frmSalgen.mfgSal.textmatrix(num,17) = eval(window.document.frmSalgen.mfgSal.textmatrix(num,17))
		window.document.frmSalgen.mfgSal.textmatrix(num,19) = alnet
	}
	
	function ChkAll()
	{
		if(window.document.frmSalgen.chkEmpAll.checked==true)
		{
			window.document.frmSalgen.selpayName.value=""
			window.document.frmSalgen.selpayName.disabled=true
			return;
		}
		else
		{
			window.document.frmSalgen.selpayName.disabled=false
			return;
		}
		
	}
	
	function ChkGenAll()
	{
		if(window.document.frmSalgen.chkGenEmpAll.checked==true)
		{
			window.document.frmSalgen.selpayName1.value=""
			window.document.frmSalgen.selpayName1.disabled=true
			return;
		}
		else
		{
			window.document.frmSalgen.selpayName1.disabled=false
			return;
		}
		
	}
	
	function ChkEmpl()
	{
		if(window.document.frmSalgen.chkEml.checked==true)
		{
			window.document.frmSalgen.selNm1.value=""
			window.document.frmSalgen.selNm1.disabled=true
			return;
		}
		else
		{
			window.document.frmSalgen.selNm1.disabled=false
			return;
		}
		
	}
	
	function Empgeneral()
	{
		var stEmp,stStat
		
		window.document.frmSalgen.mfgEmpRep.Rows=1
		
		if(window.document.frmSalgen.chkEml.checked==false)
		{
			if(window.document.frmSalgen.selNm1.value=="")
			{
				alert("Please Select Employee ")
				return;
			}
		}
		if(window.document.frmSalgen.chkEml.checked==true)
		{
			
		}
		
		if(window.document.frmSalgen.selNm1.value=="")
		{
			stEmp = ""
		}
		else
		{
			stEmp = " And EMPCODE = '"+window.document.frmSalgen.selNm1.value+"' "
		}
		
		if(window.document.frmSalgen.Opsel.value=="")
		{
			stStat = ""
		}
		else
		{
			stStat = " And Status = '"+window.document.frmSalgen.Opsel.value+"' "
		}
		
		strVal = "EMPDTLS"+"|"+stEmp+"|"+stStat+"|"+window.document.frmSalgen.txtbranchcode.value
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		
		
	}
	
	function popEmDtl(str)
	{
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stEdtl = str.split("|")
		
		window.document.frmSalgen.mfgEmpRep.Rows=1
		
		window.document.frmSalgen.mfgEmpRep.cols=12;
		window.document.frmSalgen.mfgEmpRep.formatstring="<SLNO  |<Emp Id     |<Emp UserID     |<Name                           |<Designation         |<Appoint Date        |<Permanent Date        |<Work Br Code     |<Letter Date      |<Leaving Date      |<Reason            |<Epf Accno ";
		
			for(aCnt=0;aCnt<=stEdtl.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgEmpRep.rows=window.document.frmSalgen.mfgEmpRep.rows+1
				
				var strCols=stEdtl[aCnt].split("~")
				
				window.document.frmSalgen.mfgEmpRep.textmatrix(aCnt+1,0)=aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgEmpRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
					
				}
			}
	}
	
	function general()
	{
		var strTy,strbrcode,stremp,strMon,strYr,strVal
		
		window.document.frmSalgen.mfgGenRep.Rows=1 
		
		if(window.document.frmSalgen.RadType(0).checked==true)
		{
			strTy = "ESI"
		}
		if(window.document.frmSalgen.RadType(1).checked==true)
		{
			strTy = "PF"
		}
		if(window.document.frmSalgen.RadType(2).checked==true)
		{
			strTy = "VPF"
		}
		
		if(window.document.frmSalgen.chkGenEmpAll.checked==true)
		{
			stremp = ""
		}
		else
		{
			if(window.document.frmSalgen.selpayName1.value=="")
			{
				alert("Please Select Employee ")
				return;
			}
			
			stremp = " and a.EMPCODE = '"+window.document.frmSalgen.selpayName1.value+"' "
			
		}
		
		if(window.document.frmSalgen.selpayMon1.value=="")
		{
			alert("Please Select month ")
			return;
		}
		else
		{
			strMon = window.document.frmSalgen.selpayMon1.value
		}
		
		if(window.document.frmSalgen.selPayYer1.value=="")
		{
			alert("Please Select Year ")
			return;
		}
		else
		{
			strYr = window.document.frmSalgen.selPayYer1.value
		}
		
		strVal = strTy+"|"+stremp+"|"+strMon+"|"+strYr+"|"+window.document.frmSalgen.txtbranchcode.value
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popESIPF(str)
	{	
		var stTot,stEmpval,stEmprval,strEmpTot
		
		stTot = 0 
		stEmpval = 0
		stEmprval = 0
		strEmpTot = 0
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stRep = str.split("|")
		
		window.document.frmSalgen.mfgGenRep.Rows=1
		
		if((window.document.frmSalgen.RadType(0).checked==true) || (window.document.frmSalgen.RadType(1).checked==true))
		{
			window.document.frmSalgen.mfgGenRep.cols=5;
			window.document.frmSalgen.mfgGenRep.formatstring="<SLNO  |<Name                        |>Employee      |>Employer     |>Total       ";
			
			for(aCnt=0;aCnt<=stRep.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgGenRep.rows=window.document.frmSalgen.mfgGenRep.rows+1
				
				var strCols=stRep[aCnt].split("~")
				
				window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,0)=aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,1)=strCols[0]
					
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)=strCols[1]
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)),2)
					
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,3)=strCols[2]
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,3)),2)
					
					stTot = 0
					stTot = parseFloat(strCols[1])+parseFloat(strCols[2])
					
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,4)=stTot
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,4)),2)
				}
				
				stEmpval = parseFloat(stEmpval) + parseFloat(strCols[1])
				stEmprval = parseFloat(stEmprval) + parseFloat(strCols[2])
				strEmpTot = parseFloat(strEmpTot) + parseFloat(stTot)
				
				window.document.frmSalgen.hidEmpSum.value = stEmpval
				window.document.frmSalgen.hidEmpSum.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidEmpSum.value),2)
				window.document.frmSalgen.hidEmperSum.value = stEmprval
				window.document.frmSalgen.hidEmperSum.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidEmperSum.value),2)
				window.document.frmSalgen.hidEmpTot.value = strEmpTot
				window.document.frmSalgen.hidEmpTot.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidEmpTot.value),2)
			}
		}
		
		if(window.document.frmSalgen.RadType(2).checked==true)
		{
			window.document.frmSalgen.mfgGenRep.cols=3;
			window.document.frmSalgen.mfgGenRep.formatstring="<SLNO  |<Name                        |>VPF Amount      ";
			
			for(aCnt=0;aCnt<=stRep.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgGenRep.rows=window.document.frmSalgen.mfgGenRep.rows+1
				
				var strCols=stRep[aCnt].split("~")
				
				window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,0)=aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,1)=strCols[0]
					
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)=strCols[1]
					window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.mfgGenRep.textmatrix(aCnt+1,2)),2)
				}
				
				stEmpval = parseFloat(stEmpval) + parseFloat(strCols[1])
				
				window.document.frmSalgen.hidEmpSum.value = stEmpval
				window.document.frmSalgen.hidEmpSum.value=ToIndianCurencyFormat(Math.abs(window.document.frmSalgen.hidEmpSum.value),2)
				
			}
		}

	}
	
	function ReVoucher(strrep)
	{
		var stRp
		
		stRp = strrep
		
		if(window.document.frmSalgen.selReMon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selVouchYer.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		var str = "Reprint" +"|"+ window.document.frmSalgen.txtbranchcode.value + "|" + window.document.frmSalgen.selReMon.options.value + "|" + window.document.frmSalgen.selVouchYer.options.value +"|"+ stRp
		//alert(" str= "+str)
		window.document.frmSalgen.action="SalVoucherPrint.aspx?strVal="+str
		window.document.frmSalgen.method="post"
		window.document.frmSalgen.submit()
		
	}
	
	function PayslipGen(strrep)
	{
		var rep , chk, strVel, selOption
		
		rep = strrep
		
		chk = "0"
		
		selOption = "0"
		
		if(window.document.frmSalgen.selpayMon.value=="")
		{
			alert("Please Select the Month")
			return;
		}
		
		if(window.document.frmSalgen.selPayYer.value=="")
		{
			alert("Please Select the Year")
			return;
		}
		
		if(window.document.frmSalgen.chkEmpAll.checked==true)
		{
			chk = 1
			selOption = "0"
		}
		else
		{
			chk = 0
			
			if(window.document.frmSalgen.selpayName.value=="")
			{
				alert("Please Select Employee Id")
				return;
			}
			selOption = window.document.frmSalgen.selpayName.value
		}
		
		strVel = selOption+"|"+window.document.frmSalgen.selpayMon.value+"|"+window.document.frmSalgen.selPayYer.value+"|"+chk+"|"+rep
		
		window.document.frmSalgen.hreptype.value = rep
		window.document.frmSalgen.hidSelop.value = selOption
		window.document.frmSalgen.hidSelmn.value = window.document.frmSalgen.selpayMon.value
		window.document.frmSalgen.hidSelyer.value = window.document.frmSalgen.selPayYer.value
		window.document.frmSalgen.hidChk.value = chk
		
		window.document.frmSalgen.action="Paysliprep.aspx?strng="+"/ADMIN/frmSalgenerate"
		window.document.frmSalgen.method="post"
		window.document.frmSalgen.submit();	
		
	}
	
	function selMonch()
	{
			window.document.frmSalgen.mfgRep.Rows=1 
	}
	
	function SalRepclickMonth()
	{
	strVal="SalRepSelMonth"+"|"+window.document.frmSalgen.txtbranchcode.value
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillSalRepSelMonth(str)
	{
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selMon");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{

selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}
		SalRepclickYear()
	}
	
	function SalRepclickYear()
	{
	strVal="SalRepSelYear"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillSalRepSelYear(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selRepYer");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{

selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}
		
	}
	
	function SalPaySlipSelEmployee()
	{
	strVal="SalPaySlipSelEmployee"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillSalPaySlipSelEmployee(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("|")
var selMon1=document.getElementById("selpayName");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
var stSal1 = stSal[aCnt].split("~")
selMon1.options[aCnt+1] = new Option(stSal1[1], stSal1[0]);
		}
	}


function GeneralRepSelEmployee()
	{
	strVal="GeneralRepSelEmployee"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillGeneralRepSelEmployee(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("|")
var selMon1=document.getElementById("selpayName1");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
var stSal1 = stSal[aCnt].split("~")
selMon1.options[aCnt+1] = new Option(stSal1[1], stSal1[0]);
		}
		SalRepclickYear1()
	}
	
		function SalRepclickYear1()
	{
	strVal="SalRepSelYear1"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillSalRepSelYear1(str)
	{
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selPayYer1");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}	
	}
	
	function EmployeeDetails()
	{
	strVal="EmployeeDetails"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillEmployeeDetails(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("|")
var selMon1=document.getElementById("selNm1");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
var stSal1 = stSal[aCnt].split("~")
selMon1.options[aCnt+1] = new Option(stSal1[1], stSal1[0]);
		}
	}
	
		function VoucherReprintclickMonth()
	{
	strVal="VoucherReprintclickMonth"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillVoucherReprintclickMonth(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selReMon");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{

selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}
		VoucherReprintclickYear()
	}

function VoucherReprintclickYear()
	{
	strVal="VoucherReprintSelYear"+"|"+window.document.frmSalgen.txtbranchcode.value
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillVoucherReprintSelYear(str)
	{
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selVouchYer");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}	
	}
	
	function RentReportsclickMonth()
	{
	strVal="RentReportsclickMonth"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillRentReportsclickMonth(str)
	{
	
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selRentMon");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{

selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}
		RentReportsclickYear()
	}

function RentReportsclickYear()
	{
	strVal="RentReportsSelYear"+"|"+window.document.frmSalgen.txtbranchcode.value
	
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function FillRentReportsSelYear(str)
	{
	var strfill
	strfill = ""
var stSal = str.split("~")
var selMon1=document.getElementById("selRentYer");
selMon1.options.length=0;
selMon1.options[0] = new Option('Select', '');
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
selMon1.options[aCnt+1] = new Option(stSal[aCnt], stSal[aCnt]);
		}	
	}
	
	function selSalmonchng()
	{
		window.document.frmSalgen.mfgSal.Rows=1 
	}
	
	function selTenanmonchng()
	{
		window.document.frmSalgen.mfgRent.Rows=1
	}
	
	function genSal()
	{
		if(window.document.frmSalgen.selSalmon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selSalyear.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		strVal="EMPLOYSAL"+"|"+window.document.frmSalgen.selSalmon.options[window.document.frmSalgen.selSalmon.selectedIndex].text+"|"+window.document.frmSalgen.selSalyear.options[window.document.frmSalgen.selSalyear.selectedIndex].text+"|"+window.document.frmSalgen.txtbranchcode.value
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popEmSal(str)
	{
		if(str=="No Records")
		{
			alert("Salary is Already Generated")
			return;
		}
		
		var stSal = str.split("|")
		
		window.document.frmSalgen.mfgRealSal.Rows=1
		
		window.document.frmSalgen.mfgRealSal.cols=4;
		window.document.frmSalgen.mfgRealSal.formatstring="<SLNO |<Emp Code |<Name                            |<Gen Y/N";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmSalgen.mfgRealSal.rows=window.document.frmSalgen.mfgRealSal.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmSalgen.mfgRealSal.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmSalgen.mfgRealSal.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				window.document.frmSalgen.mfgRealSal.textmatrix(aCnt+1,3)="Y"
			}
		}
		
	}
	
	function genTenant()
	{
		if(window.document.frmSalgen.selTenanmon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selTenanyear.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		strVal="TENANTGEN"+"|"+window.document.frmSalgen.selTenanmon.options[window.document.frmSalgen.selTenanmon.selectedIndex].text+"|"+window.document.frmSalgen.selTenanyear.options[window.document.frmSalgen.selTenanyear.selectedIndex].text+"|"+window.document.frmSalgen.txtbranchcode.value+"|"+strAppDt
		
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popTenant(str)
	{
		if(str=="No Records")
		{
			alert("Tenant Rent is Already Generated")
			return;
		}
		
		var stSal = str.split("|")
		
		window.document.frmSalgen.mfgRent.Rows=1
		
		window.document.frmSalgen.mfgRent.cols=9;
		window.document.frmSalgen.mfgRent.formatstring="<SLNO |<BrCode   |<Module      |<Glcode      |<AccNo                |>Amount              |<GSTY/N    |<Rev GSTY/N |<Gen Y/N";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmSalgen.mfgRent.rows=window.document.frmSalgen.mfgRent.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmSalgen.mfgRent.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmSalgen.mfgRent.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				window.document.frmSalgen.mfgRent.textmatrix(aCnt+1,8)="Y"
			}
		}
		
	}
	
	function genTenantrat()
	{
		window.document.frmSalgen.mfgTenanGen.Rows=1
		
		var StrCols,stEmp
		
		var StrCols=""
		var StrColRow=""
		var StrCol=""
		
		if(window.document.frmSalgen.selTenanmon.options.value=="")
		{
			alert("Please Select Month")
			return;
		}
		if(window.document.frmSalgen.selTenanyear.options.value=="")
		{
			alert("Please Select Year")
			return;
		}
		
		if(window.document.frmSalgen.mfgRent.rows>1)
		{
			StrCols=""
			for(icnt=1;icnt<=window.document.frmSalgen.mfgRent.rows-1;icnt++)
			{
				if(window.document.frmSalgen.mfgRent.textmatrix(icnt,8)=="Y")
				{
					StrCols = ""
					
					for(jcnt=0;jcnt<=window.document.frmSalgen.mfgRent.cols-1;jcnt++)
					{
						if ((jcnt==1) || (jcnt==2) || (jcnt==3) || (jcnt==4) || (jcnt==5))
						{
							StrCols=StrCols+window.document.frmSalgen.mfgRent.TextMatrix(icnt,jcnt)+"~"
						}
					}
					
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"$"
				}
			}
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
		}	
		
		if(StrColRow=="")
		{
			alert("No records to Generate Salary")
			return;
		}
		
		strVal="TENANTGENRAT"+"|"+StrColRow+"|"+window.document.frmSalgen.txtbranchcode.value +"|"+ strAppDt
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popTenRentdtls(str)
	{
		if(str=="No Records")
		{
			alert("No Records")
			return;
		}
		
		var stSal = str.split("|")
		
		window.document.frmSalgen.mfgTenanGen.Rows=1
		
		window.document.frmSalgen.mfgTenanGen.cols=13;
		window.document.frmSalgen.mfgTenanGen.formatstring="<SLNO |<BrCode   |<Module      |<Glcode      |<AccNo                |>Amount              |>GSTAmt    |>RevGSTAmt     |>TDS          |> Adv Ins Amt   |>NetAmt     |>TenantID    |< RecUpto      ";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmSalgen.mfgTenanGen.rows=window.document.frmSalgen.mfgTenanGen.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmSalgen.mfgTenanGen.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmSalgen.mfgTenanGen.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				//window.document.frmSalgen.mfgTenanGen.textmatrix(aCnt+1,8)="Y"
			}
		}
	}
	
	function mfgTenan_DblClick()
	{
		row=window.document.frmSalgen.mfgRent.Row
		
		if(window.document.frmSalgen.mfgRent.textmatrix(row,8)=="Y")
		{
			window.document.frmSalgen.mfgRent.textmatrix(row,8)="N"
			
			for (d=0 ;d<window.document.frmSalgen.mfgRent.Cols;d++) 
			{  
				window.document.frmSalgen.mfgRent.Col=d				
				window.document.frmSalgen.mfgRent.CellBackColor=8421616
			}
		}
		
		else if(window.document.frmSalgen.mfgRent.textmatrix(row,8)=="N")
		{
			window.document.frmSalgen.mfgRent.textmatrix(row,8)="Y"
			
			for (d=0 ;d<window.document.frmSalgen.mfgRent.Cols;d++) 
			{  
				window.document.frmSalgen.mfgRent.Col=d				
				window.document.frmSalgen.mfgRent.CellBackColor=16777215
			}
		}
	}
	
	function mfgRealSal_DblClick()
	{
		window.document.frmSalgen.mfgSal.Rows=1
		
		row=window.document.frmSalgen.mfgRealSal.Row
		
		if(window.document.frmSalgen.mfgRealSal.textmatrix(row,3)=="Y")
		{
			window.document.frmSalgen.mfgRealSal.textmatrix(row,3)="N"
			
			for (d=0 ;d<window.document.frmSalgen.mfgRealSal.Cols;d++) 
			{  
				window.document.frmSalgen.mfgRealSal.Col=d				
				window.document.frmSalgen.mfgRealSal.CellBackColor=8421616
			}
		}
		
		else if(window.document.frmSalgen.mfgRealSal.textmatrix(row,3)=="N")
		{
			window.document.frmSalgen.mfgRealSal.textmatrix(row,3)="Y"
			
			for (d=0 ;d<window.document.frmSalgen.mfgRealSal.Cols;d++) 
			{  
				window.document.frmSalgen.mfgRealSal.Col=d				
				window.document.frmSalgen.mfgRealSal.CellBackColor=16777215
			}
		}
	}
	
	function radRentchng()
	{
		window.document.frmSalgen.mfgTenanrep.Rows=1
		window.document.frmSalgen.chkConsol.checked = false
		
		if(window.document.frmSalgen.radRentdetail(0).checked==true)
		{
			window.document.all.divCondRep.style.display="none"
		}
		if(window.document.frmSalgen.radRentdetail(1).checked==true)
		{
			window.document.all.divCondRep.style.display="block"
			window.document.frmSalgen.selRentMon.value = ""
			window.document.frmSalgen.selRentYer.value = ""
		}
	}
	
	function RentDetailrep()
	{
		var stCond,stfield
		
		if(window.document.frmSalgen.radRentdetail(0).checked==true)
		{
			
			if(window.document.frmSalgen.chkConsol.checked== true)
			{
				stCond = ""
			}
			else
			{
				stCond = " where a.branchcode = '"+window.document.frmSalgen.txtbranchcode.value+"'"
			}
			
			strVal="RENTDETAILREP"+"|"+stCond
		}
		if(window.document.frmSalgen.radRentdetail(1).checked==true)
		{
			if(window.document.frmSalgen.selRentMon.value=="")
			{
				alert("Please Select The Month")
				return;
			}
			
			if(window.document.frmSalgen.selRentYer.value=="")
			{
				alert("Please Select The Month")
				return;
			}
			
			if(window.document.frmSalgen.chkConsol.checked== true)
			{
				stCond = ""
			}
			else
			{
				stCond = " and branchcode = '"+window.document.frmSalgen.txtbranchcode.value+"'"
			}
			
			strVal="RENTPAIDREP"+"|"+window.document.frmSalgen.selRentMon.options[window.document.frmSalgen.selRentMon.selectedIndex].text+"|"+window.document.frmSalgen.selRentYer.options[window.document.frmSalgen.selRentYer.selectedIndex].text+"|"+stCond
		}
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popRentdtls(str)
	{
		window.document.frmSalgen.mfgTenanrep.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
		if(window.document.frmSalgen.radRentdetail(0).checked==true)
		{
			window.document.frmSalgen.mfgTenanrep.cols = 15;
			window.document.frmSalgen.mfgTenanrep.formatstring="<SLNO  |<BrCode    |<ModId     |<GlCode     |<AccNo       |>Amount    |<GSTYN     |<RevGstYN |>TDS           |<OpDate         |<DueDate          |<CloseDate       |<Narration      |<Status   |<AccName                   ";
			
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgTenanrep.rows = window.document.frmSalgen.mfgTenanrep.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmSalgen.mfgTenanrep.textmatrix(aCnt+1,0) = aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgTenanrep.textmatrix(aCnt+1,vCnt+1) = strCols[vCnt]
				}
			}
		}
		
		if(window.document.frmSalgen.radRentdetail(1).checked==true)
		{
			window.document.frmSalgen.mfgTenanrep.cols = 12;
			window.document.frmSalgen.mfgTenanrep.formatstring="<SLNO  |<BrCode    |<ModId     |<GlCode     |<AccNo       |>Amount    |>GSTAmt     |>RevAmt    |>TDS        |>NetPaid     |<PaidBatch   |<AccName                   ";
			
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgTenanrep.rows = window.document.frmSalgen.mfgTenanrep.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmSalgen.mfgTenanrep.textmatrix(aCnt+1,0) = aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgTenanrep.textmatrix(aCnt+1,vCnt+1) = strCols[vCnt]
				}
			}
		}
	}
	
	function GenerateGratuity()
	{
			strVal="GENERATEGRATUITY"+"|"+window.document.frmSalgen.selGratuityFinyear.options[window.document.frmSalgen.selGratuityFinyear.selectedIndex].text
		
		//alert(" strVal = "+strVal)
		window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function popGratuitydtls(str)
	{
		window.document.frmSalgen.mfgGratuity.Rows=1
		
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
			window.document.frmSalgen.mfgGratuity.cols = 7;
			window.document.frmSalgen.mfgGratuity.formatstring="<SLNO  |<EmpCode     |<Name                                 |>Basic        |>DA        |>Gratuity Amt    |>PostYN   ";
			
			for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
			{
				window.document.frmSalgen.mfgGratuity.rows = window.document.frmSalgen.mfgGratuity.rows+1
				
				var strCols=stSal[aCnt].split("~")
				
				window.document.frmSalgen.mfgGratuity.textmatrix(aCnt+1,0) = aCnt+1
				
				for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
				{
					window.document.frmSalgen.mfgGratuity.textmatrix(aCnt+1,vCnt+1) = strCols[vCnt]
				}
			}
		
	}
	
	function mfgGratuity_DblClick()
	{

		row=window.document.frmSalgen.mfgGratuity.Row

		if(window.document.frmSalgen.mfgGratuity.textmatrix(row,6)=="Y")
		{
		
			window.document.frmSalgen.mfgGratuity.textmatrix(row,6)="N"
		
			for (d=0 ;d<window.document.frmSalgen.mfgGratuity.Cols;d++) 
			{  
				window.document.frmSalgen.mfgGratuity.Col=d				
				window.document.frmSalgen.mfgGratuity.CellBackColor=8421616
			}
		}
		else if(window.document.frmSalgen.mfgGratuity.textmatrix(row,6)=="N")
		{
			window.document.frmSalgen.mfgGratuity.textmatrix(row,6)="Y"
			
			for (d=0 ;d<window.document.frmSalgen.mfgGratuity.Cols;d++) 
			{  
				window.document.frmSalgen.mfgGratuity.Col=d				
				window.document.frmSalgen.mfgGratuity.CellBackColor=16777215
			}
		}
	}
	</script>
	
	<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmSalgen.txtFromDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmSalgen.txtFromDate.value=""
				window.document.frmSalgen.txtFromDate.focus()
			}
			
			
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
	
	
	
	</script>
	
	<SCRIPT LANGUAGE=javascript FOR=mfgSal EVENT=DblClick>
	<!--
	mfgSal_DblClick()
	//-->
	</script>
	<SCRIPT LANGUAGE=javascript FOR=mfgRealSal EVENT=DblClick>
	<!--
	mfgRealSal_DblClick()
	//-->
	</script>
	<SCRIPT LANGUAGE=javascript FOR=mfgRent EVENT=DblClick>
	<!--
	mfgTenan_DblClick()
	//-->
	</script>
	
	<SCRIPT LANGUAGE=javascript FOR=mfgGratuity EVENT=DblClick>
	<!--
	mfgGratuity_DblClick()
	//-->
	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);onloadin();checkImplement();">

	<%appdate = FormatDateTime(Session("applicationdate"), 1)%>

    <form name="frmSalgen">
		<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%">
				<tr>
					<td align="left" class="bankHeaderLogo"></td>
					<td align="right" class="esmartBankerLogo"></td>
				</tr>
			</table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" border="0" cellspacing="0" width="100%">
				<tr>
					<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="30%" align="center" height="22" class="subHeader"><h2>Salary Generation&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol">
		</div><%appdate=formatdatetime(session("applicationdate"),1)%>

		<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
				<td width="100%">
		  <table border="0" width="110%" cellspacing="0" cellpadding="0">
                      <tr class="bgcolor">
                        <td width="150" height="27"><font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch
                        Code</font></td>
                        <td width="270" height="27">&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtbranchcode" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"  readonly size="9" class="txtautofill" value="<%=session("branchcode")%>" maxlength="10" onblur="DescrptionDisp(&quot;txtbranchcode&quot;)"><input type="button" value=" L " name="buttbr" onclick="Branch()"  class="button"><input name="txtbranchdesc" class="bgcolor1" size="17" value="<%=session("branchnarration")%>" readonly></td>
                        <td width="120" height="37"><font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency
                        Code</font></td>
                        <td height="27" width="360"><input name="txtcurrencycode" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"  class="txtautofill" readonly value="<%=session("currencycode")%>" size="14" maxlength="10" onblur="DescrptionDisp(&quot;txtcurrencycode&quot;)"><input type="button" class="button" value=" L " name="buttcur" onclick="curr()" class="inputdim"><input name="txtcurrencydesc" size="13" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
                      </tr>
                    </table>
</td>
</tr>
			<tr>
				<td width="100%">
					<table align="center" cellspacing="0" cellpadding="0">
						<tr>
							<td height="15"><font class="textblue"></font></td>
						</tr>
					</table>
					
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
						<tr>
							<td width="16%" valign="top">
								<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
									<tr bgcolor="#99ccff" >
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">Salary Generation</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">Salary Report</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">Salary Pay Slip</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('3')">&nbsp;<font class="textbold">General Report</font></a></td>
									</tr>
									
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('4')">&nbsp;<font class="textbold">Employee Details</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('5')">&nbsp;<font class="textbold">Re-Voucher Print</font></a></td>
									</tr>
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('6')">&nbsp;<font class="textbold">Rent Generation</font></a></td>
									</tr> 
									<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('7')">&nbsp;<font class="textbold">Rent Reports</font></a></td>
									</tr>  
								
										<tr bgcolor="#99ccff">
											<td width="100%" height="18"><a href="#" onclick="ShowDivision('8')">&nbsp;<font class="textbold">Gratuity Generation</font></a></td>
										</tr>  
									<!---	<tr bgcolor="#99ccff">
											<td width="100%" height="18"><a href="#" onclick="ShowDivision('7')">&nbsp;<font class="textbold"></font></a></td>
										</tr> -->
								</table>
							</td>
							<td width="84%" valign="top">
								<div id="divSalGen" style="display:none"><!---- Salary Generate start --->
									<table border="1" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Salary Generate" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
											<td width="100%" align="center">Month&nbsp;&nbsp;											
											<%
												dim mon,mon1,mon2,nmon,nmon1,nmon2
												
												mon = Month(session("applicationdate"))
												
												if mon = 1 then
													mon1 = 12
												else
													mon1 = mon-1
												end if
												
												if mon = 12 then
													mon2 = 1
												else
													mon2 = mon+1
												end if
												
												nmon = MonthName(mon)
												
												nmon1 = MonthName(mon1)
												
												nmon2 = MonthName(mon2)
												
											%>
											
											<select name="selSalmon" onchange="selSalmonchng()">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=mon%>" selected><%=nmon%></option>
												<option value="<%=mon1%>"><%=nmon1%></option>
												<option value="<%=mon2%>"><%=nmon2%></option>
											</select>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												dim yer,yer1,yer2
												
												yer = Year(session("applicationdate"))
												
												if mon = 1 then
													yer1 = yer-1
												else
													yer1 = ""
												end if
												
												if mon = 12 then
													yer2 = yer+1
												else
													yer2 = ""
												end if
												
											%>
											<select name="selSalyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=yer%>" selected><%=yer%></option>
												<option value="<%=yer1%>"><%=yer1%></option>
												<option value="<%=yer2%>"><%=yer2%></option>
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="GenSalrate" class="button" name="Generate" value=" Generate " onclick="genSal()">
											
											</td>
											
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=150 id=mfgRealSal name=mfgRealSal style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 VIEWASTEXT>
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT></td>
										<tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >&nbsp;&nbsp;&nbsp;<input type="button" id="generate" class="button" name=" Proceed " value=" Proceed " onclick="genrat()">&nbsp;&nbsp;&nbsp;</td>
										</tr>
										<tr>
											<td width="100%" align="center">Other Deduction : <input type="text" id="txtAditional" onkeypress="numeric()" maxlength="12" align = "right" value="" disabled > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="cmdAdd" onclick="AddOther()" type="button" value=" Add " class="button">&nbsp;&nbsp;&nbsp;&nbsp;Other Allowance : <input type="text" id="txtAlow" onkeypress="numeric()" maxlength="12" align = "right" value="" disabled > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="cmdAlow" onclick="AlowOther()" type="button" value=" Add " class="button"></td>
										</tr>
										
											
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgSal name=mfgSal style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
								</div><!---- Salary Generate end --->
								
								<div id="divSalReport" style="display:none"> <!-- salary Report start-->
									<table border="1" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Salary Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
											<td width="100%" align="center">All Employee Sal Rep&nbsp;&nbsp;<input type="checkbox" name="chkSalRepEmpAll" id="chkSalRepEmpAll" onclick="ChkSalRepAll()">&nbsp;&nbsp;&nbsp;&nbsp; Month&nbsp;&nbsp;
											<select name="selMon" onchange="selMonch()" >
						<option value="" selected >Select</option>								
											<%
											
					dim rsTds, objTds

					rsTds=server.CreateObject("adodb.recordset")
					objTds=server.CreateObject("queryrecordsets.fetchrecordsets")
				'	rsTds=objTds.singlerecordset("SALARYPAIDDTLS","DISTINCT paidmonth","Branchcode='" & pBrCode & "'","")
					rsTds=objTds.singlerecordset("SALARYPAIDDTLS","DISTINCT paidmonth","","")				
						if objTds.ConnError="Connected" then
							if not rsTds.BOF and not rsTds.EOF then
								do until rsTds.EOF
						%>
						
					<!--	<option value="<%=rsTds(0).value%>"><%=rsTds(0).value%></option> -->
						<%		
								rsTds.movenext()
								loop
							end if
						end if
						
						dim mn,mn1,mn2,nmn,nmn1,nmn2
												
						mn = Month(session("applicationdate"))
						
						if mn = 1 then
							mn1 = 12
						else
							mn1 = mn-1
						end if
						
						if mn = 12 then
							mn2 = 1
						else
							mn2 = mn+1
						end if
						
						nmn = MonthName(mn)
						
						nmn1 = MonthName(mn1)
						
						nmn2 = MonthName(mn2)
						
						
												
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;<select name="selRepYer">
											<option value="" selected >Select</option> 
									<!--		<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> -->
											<%
												dim yr,yr1,yr2
												
												yr = Year(session("applicationdate"))
												
												if mn = 1 then
													yr1 = yr-1
												else
													yr1 = ""
												end if
												
												if mn = 12 then
													yr2 = yr+1
												else
													yr2 = ""
												end if
												
					dim rsTdsy, objTdsy

					rsTdsy=server.CreateObject("adodb.recordset")
					objTdsy=server.CreateObject("queryrecordsets.fetchrecordsets")
				'	rsTdsy=objTdsy.singlerecordset("SALARYPAIDDTLS","DISTINCT PAIDYEAR","Branchcode='" & pBrCode & "'","")
						rsTdsy=objTdsy.singlerecordset("SALARYPAIDDTLS","DISTINCT PAIDYEAR","","")			
						if objTdsy.ConnError="Connected" then
							if not rsTdsy.BOF and not rsTdsy.EOF then
								do until rsTdsy.EOF
												
											%>
											
											<!--	<option value="" selected >Select</option>
												<option value="<%=yr%>" selected><%=yr%></option>
												<option value="<%=yr1%>"><%=yr1%></option>
												<option value="<%=yr2%>"><%=yr2%></option> -->
												
						
					<!--	<option value="<%=rsTdsy(0).value%>"><%=rsTdsy(0).value%></option>  -->
						<%		
								rsTdsy.movenext()
								loop
							end if
						end if
										%>	</select>
											
											</td>
											
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center"><input type="button" id="SalReport" class="button" name="Generate" value=" Generate " onclick="genReport()"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgRep name=mfgRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
								</div> <!-- salary Report end-->
								
								<div id="divPayslip" style="display:none"> <!-- salary Pay Slip start-->
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Salary Pay Slip" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
											<td width="100%" align="left">Employee Name &nbsp;&nbsp;
											
											<select name="selpayName">
										<!--	<option value="" selected >Select</option> -->
											<%
											
					dim rsEmNam, objEmNam

					rsEmNam=server.CreateObject("adodb.recordset")
					objEmNam=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsEmNam=objEmNam.singlerecordset("EMPLOYEEMST","EMPCODE, EMPNAME","status='R' and WORKINGBRCODE='" & pBrCode & "'","TO_NUMBER(EMPCODE)")
								
						if objEmNam.ConnError="Connected" then
							if not rsEmNam.BOF and not rsEmNam.EOF then
								do until rsEmNam.EOF
						%>
						
					<!--	<option value="<%=rsEmNam(0).value%>"><%=rsEmNam(1).value%></option> -->
						<%		
								rsEmNam.movenext()
								loop
							end if
						end if
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Month&nbsp;&nbsp;
						<select name="selpayMon" onchange="selpayMonCh()">
						<option value="" selected >Select</option>											
											<%
											
					dim rsPay, objPay

					rsPay=server.CreateObject("adodb.recordset")
					objPay=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsPay=objPay.singlerecordset("SALARYPAIDDTLS","DISTINCT paidmonth","","")
								
						if objPay.ConnError="Connected" then
							if not rsPay.BOF and not rsPay.EOF then
								do until rsPay.EOF
						%>
						
						<option value="<%=rsPay(0).value%>"><%=rsPay(0).value%></option>
						<%		
								rsPay.movenext()
								loop
							end if
						end if
						
						dim mno,mno1,mno2,nmno,nmno1,nmno2
												
						mno = Month(session("applicationdate"))
						
						if mno = 1 then
							mno1 = 12
						else
							mno1 = mno-1
						end if
						
						if mno = 12 then
							mno2 = 1
						else
							mno2 = mno+1
						end if
						
						nmno = MonthName(mno)
						
						nmno1 = MonthName(mno1)
						
						nmno2 = MonthName(mno2)
												
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												'dim yrs,yrs1,yrs2
												
												'yrs = Year(session("applicationdate"))
												
											'	if mno = 1 then
											'		yrs1 = yrs-1
											'	else
											'		yrs1 = ""
											'	end if
											'	
											'	if mno = 12 then
											'		yrs2 = yrs+1
											'	else
											'		yrs2 = ""
											'	end if
					
											%>
											
											
											<select name="selPayYer">
											
											<%dim rsYarPay, objYarPay

					rsYarPay=server.CreateObject("adodb.recordset")
					objYarPay=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsYarPay=objYarPay.singlerecordset("SALARYPAIDDTLS","DISTINCT PAIDYEAR","","")
								
						if objYarPay.ConnError="Connected" then
							if not rsYarPay.BOF and not rsYarPay.EOF then
								do until rsYarPay.EOF
						%>
						
						<option value="<%=rsYarPay(0).value%>"><%=rsYarPay(0).value%></option>
						<%		
								rsYarPay.movenext()
								loop
							end if
						end if %>
												<!--<option value="" selected >Select</option>-->
												<!--<option value="<%=yrs%>" selected><%=yrs%></option>
												<option value="<%=yrs1%>"><%=yrs1%></option>
												<option value="<%=yrs2%>"><%=yrs2%></option> -->
											</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											</td>
											
										</tr>
										<tr>
											<td align="left" >All Employee Pay Slip&nbsp;&nbsp;
											<input type="checkbox" name="chkEmpAll" id="chkEmpAll" onclick="ChkAll()" ></td>
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
									</table>
								</div> <!-- salary Pay Slip end-->
								<div id="divGeneral" style="display:none"> <!--- General REPORT  Start--->
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="General Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
											<td align="center">
												<input type="radio" name="radGentype" id="RadType"  onclick=genChk() checked>&nbsp;ESI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radGentype" id="RadType" onclick=genChk()>&nbsp;PF&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radGentype" id="RadType" onclick=genChk()>&nbsp;VPF
											</td>
										</tr>
										<tr>
											<td align="center">&nbsp;</td>
										</tr>
										<tr>
											<td width="100%" align="left">Employee Name &nbsp;&nbsp;
											
											<select name="selpayName1">
								<!--		<option value="" selected >Select</option>  -->
											<%
											
					dim rsEmNam1, objEmNam1

					rsEmNam1=server.CreateObject("adodb.recordset")
					objEmNam1=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsEmNam1=objEmNam1.singlerecordset("EMPLOYEEMST","EMPCODE, EMPNAME","status='R' and WORKINGBRCODE='" & pBrCode & "'","TO_NUMBER(EMPCODE)")
								
						if objEmNam1.ConnError="Connected" then
							if not rsEmNam1.BOF and not rsEmNam1.EOF then
								do until rsEmNam1.EOF
						%>
						
				<!--		<option value="<%=rsEmNam1(0).value%>"><%=rsEmNam1(1).value%></option>  -->
						<%		
								rsEmNam1.movenext()
								loop
							end if
						end if
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Month&nbsp;&nbsp;
						<select name="selpayMon1" onchange="selpayMonCh1()">
						<option value="" selected >Select</option>											
											<%
											
					dim rsPay1, objPay1

					rsPay1=server.CreateObject("adodb.recordset")
					objPay1=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsPay1=objPay1.singlerecordset("SALARYPAIDDTLS","DISTINCT paidmonth","","")
								
						if objPay1.ConnError="Connected" then
							if not rsPay1.BOF and not rsPay1.EOF then
								do until rsPay1.EOF
						%>
						
						<option value="<%=rsPay1(0).value%>"><%=rsPay1(0).value%></option>
						<%		
								rsPay1.movenext()
								loop
							end if
						end if
						
						dim mnow,mnow1,mnow2,nmnow,nmnow1,nmnow2
												
						mnow = Month(session("applicationdate"))
						
						if mnow = 1 then
							mnow1 = 12
						else
							mnow1 = mnow-1
						end if
						
						if mnow = 12 then
							mnow2 = 1
						else
							mnow2 = mnow+1
						end if
						
						nmnow = MonthName(mnow)
						
						nmnow1 = MonthName(mnow1)
						
						nmnow2 = MonthName(mnow2)
												
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;<select name="selPayYer1">
										<!--		<option value="" selected >Select</option>   -->
											<%
											'	dim yrsw,yrsw1,yrsw2
											'	
											'	yrsw = Year(session("applicationdate"))
											'	
											'	if mnow = 1 then
											'		yrsw1 = yrsw-1
											'	else
											'		yrsw1 = ""
											''	end if
											'	
											'	if mnow = 12 then
											'		yrsw2 = yrsw+1
											'	else
											'		yrsw2 = ""
											'	end if
					
					dim rsTdsy1,objTdsy1		
					rsTdsy1=server.CreateObject("adodb.recordset")
					objTdsy1=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsTdsy1=objTdsy1.singlerecordset("SALARYPAIDDTLS","DISTINCT PAIDYEAR","Branchcode='" & pBrCode & "'","")
								
						if objTdsy1.ConnError="Connected" then
							if not rsTdsy1.BOF and not rsTdsy1.EOF then
								do until rsTdsy1.EOF
											%>
											
												<!--<option value="<%=yrsw%>" selected><%=yrsw%></option>
												<option value="<%=yrsw1%>"><%=yrsw1%></option>
												<option value="<%=yrsw2%>"><%=yrsw2%></option> -->
												
							<!--					<option value="<%=rsTdsy1(0).value%>"><%=rsTdsy1(0).value%></option>   -->
							<%		
									rsTdsy1.movenext()
									loop
								end if
							end if
											%>
											</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											</td>
										</tr>
										<tr>
											<td align="left" >All Employee &nbsp;&nbsp;<input type="checkbox" name="chkGenEmpAll" id="chkGenEmpAll" onclick="ChkGenAll()" ></td>
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center"><input type="button" id="GenReport" class="button" name="Generate" value=" Generate " onclick="general()"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgGenRep name=mfgGenRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									
									</table>
								
								</div> <!-- General REPORT end-->
								
								<div id="divEmDetail" style="display:none">
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Employee Detail Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
									</table>
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td width="100%" align="left">Employee Name &nbsp;&nbsp;
												<select name="selNm1">
											<!--	<option value="" selected >Select</option>  -->
												<%
												
												dim rsEmm1, objEmm1

												rsEmm1=server.CreateObject("adodb.recordset")
												objEmm1=server.CreateObject("queryrecordsets.fetchrecordsets")
												rsEmm1=objEmm1.singlerecordset("EMPLOYEEMST","EMPCODE, EMPNAME","WORKINGBRCODE='" & pBrCode & "'","TO_NUMBER(EMPCODE)")
															
													if objEmm1.ConnError="Connected" then
														if not rsEmm1.BOF and not rsEmm1.EOF then
															do until rsEmm1.EOF
													%>
													
										<!--			<option value="<%=rsEmm1(0).value%>"><%=rsEmm1(1).value%></option>       -->
													<%		
															rsEmm1.movenext()
															loop
														end if
													end if
													%>
													</select>
													&nbsp;&nbsp;Status&nbsp;&nbsp;
													<select name="Opsel">
														<option value="" selected>Select</option>
														<option value="R">Running</option>
														<option value="C">Close</option>
													</select>
													&nbsp;&nbsp; All Employee &nbsp;&nbsp;<input type="checkbox" name="chkEml" id="chkEml" onclick="ChkEmpl()" >
											</td>
										</tr>
										<tr>
											<td width="100%" align="center"><input type="button" id="GenRept" class="button" name="Generate" value=" Generate " onclick="Empgeneral()"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgEmpRep name=mfgEmpRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
								
								</div>
								<div id="divRevoch" style="display:none">
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Re-Voucher Printing" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
									<!---	<tr>
											<td height="15"><font color="#000000" size="3" >Batch No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtBatch" size="9" maxlength="20" onkeypress="numdec(window.document.frmSalgen.txtBatch.value,window.document.frmSalgen.hpr.value)" style="TEXT-TRANSFORM: uppercase" class="txtautofill" class="bgcolor1"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="txtFromDate" id="dtpFromDate" maxlength=10 onblur="datecheck(this)" size="11">(DDMMYYYY)</font></td>
										</tr> -->
										<tr>
											<td width="100%" align="center">Month&nbsp;&nbsp;
											<select name="selReMon" onchange="selReMonch()">
					<!--	<option value="" selected >Select</option>	-->								
											<%
											
					dim rsReTds, objReTds

					rsReTds=server.CreateObject("adodb.recordset")
					objReTds=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsReTds=objReTds.singlerecordset("SALARYPAIDDTLS","DISTINCT paidmonth","Branchcode='" & pBrCode & "'","")
								
						if objReTds.ConnError="Connected" then
							if not rsReTds.BOF and not rsReTds.EOF then
								do until rsReTds.EOF
						%>
						
				<!--		<option value="<%=rsReTds(0).value%>"><%=rsReTds(0).value%></option>   -->
						<%		
								rsReTds.movenext()
								loop
							end if
						end if
						
						dim Vomn,Vomn1,Vomn2,Vonmn,Vonmn1,Vonmn2
												
						Vomn = Month(session("applicationdate"))
						
						if Vomn = 1 then
							Vomn1 = 12
						else
							Vomn1 = Vomn-1
						end if
						
						if Vomn = 12 then
							Vomn2 = 1
						else
							Vomn2 = Vomn+1
						end if
						
						Vonmn = MonthName(Vomn)
						
						Vonmn1 = MonthName(Vomn1)
						
						Vonmn2 = MonthName(Vomn2)
												
						%>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;<select name="selVouchYer">
											<!--	<option value="" selected >Select</option>  -->
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												dim Voyr,Voyr1,Voyr2
												
												Voyr = Year(session("applicationdate"))
												
												if Vomn = 1 then
													Voyr1 = Voyr-1
												else
													Voyr1 = ""
												end if
												
												if Vomn = 12 then
													Voyr2 = Voyr+1
												else
													Voyr2 = ""
												end if
										
										dim rsTdsy2,objTdsy2		
					rsTdsy2=server.CreateObject("adodb.recordset")
					objTdsy2=server.CreateObject("queryrecordsets.fetchrecordsets")
					rsTdsy2=objTdsy2.singlerecordset("SALARYPAIDDTLS","DISTINCT PAIDYEAR","Branchcode='" & pBrCode & "'","")
								
						if objTdsy2.ConnError="Connected" then
							if not rsTdsy2.BOF and not rsTdsy2.EOF then
								do until rsTdsy2.EOF
											%>
											
								<!--			<option value="<%=rsTdsy2(0).value%>"><%=rsTdsy2(0).value%></option> -->
							<%		
									rsTdsy2.movenext()
									loop
								end if
							end if
											%>	
												<!--<option value="<%=Voyr%>" selected><%=Voyr%></option>
												<option value="<%=Voyr1%>"><%=Voyr1%></option>
												<option value="<%=Voyr2%>"><%=Voyr2%></option>-->
											</select>
											
											</td>
											
										</tr>
									</table>	
								</div>
								<!-- Tenant / Rent Generation -->
								<div id="divTenRentGen" style="display:none">
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Rent Generation" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
											<td width="100%" align="center">Month&nbsp;&nbsp;											
											<%
												dim Tenanmon,Tenanmon1,Tenanmon2,Tenannmon,Tenannmon1,Tenannmon2
												
												Tenanmon = Month(session("applicationdate"))
												
												if Tenanmon = 1 then
													Tenanmon1 = 12
												else
													Tenanmon1 = Tenanmon-1
												end if
												
												if Tenanmon = 12 then
													Tenanmon2 = 1
												else
													Tenanmon2 = Tenanmon+1
												end if
												
												Tenannmon = MonthName(Tenanmon)
												
												Tenannmon1 = MonthName(Tenanmon1)
												
												Tenannmon2 = MonthName(Tenanmon2)
												
											%>
											
											<select name="selTenanmon" onchange="selTenanmonchng()">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=Tenanmon%>" selected><%=Tenannmon%></option>
												<option value="<%=Tenanmon1%>"><%=Tenannmon1%></option>
												<option value="<%=Tenanmon2%>"><%=Tenannmon2%></option>
											</select>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;
											<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
											<%
												dim Tenanyer,Tenanyer1,Tenanyer2
												
												Tenanyer = Year(session("applicationdate"))
												
												if Tenanmon = 1 then
													Tenanyer1 = Tenanyer-1
												else
													Tenanyer1 = ""
												end if
												
												if Tenanmon = 12 then
													Tenanyer2 = Tenanyer+1
												else
													Tenanyer2 = ""
												end if
												
											%>
											<select name="selTenanyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=Tenanyer%>" selected><%=Tenanyer%></option>
												<option value="<%=Tenanyer1%>"><%=Tenanyer1%></option>
												<option value="<%=Tenanyer2%>"><%=Tenanyer2%></option>
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="GenTenantrate" class="button" name="Generate" value=" Generate " onclick="genTenant()">
											
											</td>
											
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=150 id=mfgRent name=mfgRent style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT></td>
										<tr>
										<tr>
											<td width="100%" align="center" >&nbsp;&nbsp;&nbsp;<input type="button" id="generate" class="button" name=" Proceed " value=" Proceed " onclick="genTenantrat()">&nbsp;&nbsp;&nbsp;</td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgTenanGen name=mfgTenanGen style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>	
								</div>
								
								<!-- Tenant / Rent Reports -->
								<div id="divTenRep" style="display:none">
									<table border="01" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Rent Reports" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font><input type="checkbox" id="chkConsol" name="chkConsol" onclick="chkSol()">&nbsp;Consolidate </td>
										</tr>
										<tr>
											<td width="100%" align="center">
												<input type="radio" id="radRentdetail" name="radRentdetail" onclick="radRentchng()" checked>&nbsp;Rent Member Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="radRentdetail" name="radRentdetail" onclick="radRentchng()">Rent Paid Details 
											</td>
										</tr>
										<tr>
											<td width="100%" align="center">
												<div id="divCondRep" style="display:none">
													<table>
														<tr>
															<td width="100%" align="center">Month&nbsp;&nbsp;
															<select name="selRentMon" onchange="selRentmon()">
									<!--	<option value="" selected >Select</option>		-->									
															<%
															
									dim rsRenTds, objRenTds

									rsRenTds=server.CreateObject("adodb.recordset")
									objRenTds=server.CreateObject("queryrecordsets.fetchrecordsets")
									rsRenTds=objRenTds.singlerecordset("TENANTPAIDDTLS","DISTINCT paidmonth","Branchcode='" & pBrCode & "'","")
												
										if objRenTds.ConnError="Connected" then
											if not rsRenTds.BOF and not rsRenTds.EOF then
												do until rsRenTds.EOF
										%>
										
									<!--	<option value="<%=rsRenTds(0).value%>"><%=rsRenTds(0).value%></option>  -->
										<%		
												rsRenTds.movenext()
												loop
											end if
										end if
										
										dim RenVomn,RenVomn1,RenVomn2,RenVonmn,RenVonmn1,RenVonmn2
																
										RenVomn = Month(session("applicationdate"))
										
										if RenVomn = 1 then
											RenVomn1 = 12
										else
											RenVomn1 = RenVomn-1
										end if
										
										if RenVomn = 12 then
											RenVomn2 = 1
										else
											RenVomn2 = RenVomn+1
										end if
										
										RenVonmn = MonthName(RenVomn)
										
										RenVonmn1 = MonthName(RenVomn1)
										
										RenVonmn2 = MonthName(RenVomn2)
																
										%>
										</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year&nbsp;&nbsp;&nbsp;<select name="selRentYer">
								<!--		<option value="" selected >Select</option>   -->
															<!--<input type="text" name="txtYear" value="<%=Year(session("applicationdate"))%>" size="5"> --->
															<%
																dim RenVoyr,RenVoyr1,RenVoyr2
																
																RenVoyr = Year(session("applicationdate"))
																
																if RenVomn = 1 then
																	RenVoyr1 = RenVoyr-1
																else
																	RenVoyr1 = ""
																end if
																
																if RenVomn = 12 then
																	RenVoyr2 = RenVoyr+1
																else
																	RenVoyr2 = ""
																end if
																
															
															dim rsRenTds1, objRenTds1

									rsRenTds1=server.CreateObject("adodb.recordset")
									objRenTds1=server.CreateObject("queryrecordsets.fetchrecordsets")
									rsRenTds1=objRenTds1.singlerecordset("TENANTPAIDDTLS","DISTINCT PAIDYEAR","Branchcode='" & pBrCode & "'","")
												
										if objRenTds1.ConnError="Connected" then
											if not rsRenTds1.BOF and not rsRenTds1.EOF then
												do until rsRenTds1.EOF
										%>
										
								<!--		<option value="<%=rsRenTds1(0).value%>"><%=rsRenTds1(0).value%></option>   -->
										<%		
												rsRenTds1.movenext()
												loop
											end if
										end if
										%>
															
																<!--<option value="" selected >Select</option>
																<option value="<%=RenVoyr%>" selected><%=RenVoyr%></option>
																<option value="<%=RenVoyr1%>"><%=RenVoyr1%></option>
																<option value="<%=RenVoyr2%>"><%=RenVoyr2%></option>-->
															</select>
															
															</td>
															
														</tr>
													</table>
												</div>
											</td>
										</tr>
										
										<tr>
											<td width="100%" align="center" >&nbsp;&nbsp;&nbsp;<input type="button" id="generate" class="button" name=" Proceed " value=" Proceed " onclick="RentDetailrep()">&nbsp;&nbsp;&nbsp;</td>
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=150 id=mfgTenanrep name=mfgTenan style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT></td>
										<tr>
										
									</table>	
								</div>
								<!-- end rent reports -->
								
								<!---- Gratuity Generate start --->
								<div id="divGRAGEN" style="display:none">
									<table border="1" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Gratuity Generate" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
										<tr>
										
<td width="100%" align="center">										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FinYear&nbsp;&nbsp;&nbsp;
											
											<%
												dim curfrmgrayer,curtograyer, curassessgrayer, curassessgrayer1,curassessgrayer2,gramon,grayer
												
												grayer = Year(session("applicationdate"))
												gramon = Month(session("applicationdate"))
												
												if gramon <= 3 then
												curfrmgrayer = cdate("01-Apr-" & cint(grayer) -1)
												curtograyer = cdate("31-Mar-" & cint(grayer))
												else
												curfrmgrayer = cdate("01-Apr-" & cint(grayer))
												curtograyer = cdate("31-Mar-" & cint(grayer)+1)
												end if
												curassessgrayer = Year(curfrmgrayer) & mid(Year(curtograyer),3,2)
												curassessgrayer1 = cint(Year(curfrmgrayer))+1 & cint(mid(Year(curtograyer),3,2))+1
												curassessgrayer2 = cint(Year(curfrmgrayer)) +2 & cint(mid(Year(curtograyer),3,2))+2
											%>
											<select name="selGratuityFinyear">
												<!--<option value="" selected >Select</option>-->
												<option value="<%=curassessgrayer%>" selected><%=curassessgrayer%></option>
												<option value="<%=curassessgrayer1%>" ><%=curassessgrayer1%></option>
												<option value="<%=curassessgrayer2%>" ><%=curassessgrayer2%></option>
												
											</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="GenGratuityrate" class="button" name="Generate" value=" Generate " onclick="GenerateGratuity()">
											
											</td>
											
										</tr>
										<tr>
											<td width="100%"></td>
										</tr>
										<tr>
											<td width="100%" align="center" >
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=150 id=mfgGratuity name=mfgGratuity style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 800px" width=800 >
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT></td>
										<tr>
										<tr>
											<td width="100%"></td>
										</tr>
									</table>
								</div>
								<!---- Gratuity Generate end --->
								
							</td>
						</tr>
					</table>
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%">
							<div align="center">
								<center>	
								<table border="0" border="0" cellpadding="0" cellspacing="0" width="17%">
									<tr>
										<td width="100%" ><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input name="cmdok" type="button" value="   Post   " class="button" onclick="subtrans();"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmSalgenerate.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
									</tr>
								</table>
								</center>
							</div>
							</td>
						</tr>
					</table>
					<input type="hidden" name="hpr" value="<%=session("precision")%>">
					<input type="hidden" name="htabname" value>
					<input type="hidden" name="hfldname" value>
					<input type="hidden" name="hfldvalues" value>
					<input type="hidden" name="hmode" value>
					<input type="hidden" name="hdnrow" value>
					<input type="hidden" name="mercust">
					<input type="hidden" name="reptitle">
					<input type=hidden name="postdata">
					<input type="hidden" name="hreport">
					<input type="hidden" name="hidDate">
					<input type="hidden" name="hidRow">
					<input type="hidden" name="hidow">
					<input type="hidden" name="hreptype">
					<input type="hidden" name="hidSelop">
					<input type="hidden" name="hidSelmn">
					<input type="hidden" name="hidSelyer">
					<input type="hidden" name="hidChk">
					<input type="hidden" name="hidBa" value="0">
					<input type="hidden" name="hidDa" value="0">
					<input type="hidden" name="hidHra" value="0">
					<input type="hidden" name="hidAlw" value="0">
					<input type="hidden" name="hidGrs" value="0">
					<input type="hidden" name="hidPf" value="0">
					<input type="hidden" name="hidPtax" value="0">
					<input type="hidden" name="hidRd" value="0">
					<input type="hidden" name="hidLon" value="0">
					<input type="hidden" name="hidAdv" value="0">
					<input type="hidden" name="hidGip" value="0">
					<input type="hidden" name="hidTds" value="0">
					<input type="hidden" name="hidOtd" value="0">
					<input type="hidden" name="hidEsi" value="0">
					<input type="hidden" name="hidVpf" value="0">
					<input type="hidden" name="hidTotd" value="0">
					<input type="hidden" name="hidNet" value="0">
					<input type="hidden" name="hidEmpSum" value="0">
					<input type="hidden" name="hidEmperSum" value="0">
					<input type="hidden" name="hidEmpTot" value="0">
					<input type="hidden" name="hidOtalow" value="0">
					<input type="text"  style="VISIBILITY: Hidden" readonly class="bgcolor1" name="txtMaxdate" size="20">
					<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
					<div class="footer">
						<div class="logo"></div>
						<div class="copyRight">
							&copy; E-Smart Banker - A Product of SAS Enterprises
						</div>
					</div>
					
				</td>
			</tr>
		</table>
	</form>

    

  </body>
</html>
