<%@ Page Language="vb" CodeBehind="GenUserDetails.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.GenUserDetails" %>

<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserDetails.ASP									*
'*	Purpose	  	     : A fly page used to get the given user details       	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
// This function will be called at the event of body onload
function List()
{
  var varstr
  // extract the value from hiddenvariable where the result is stored
  varstr= window.document.frmuser.hiduid.value 
  // raise the event of GENDISP of calling page --Genusercreation.asp or GenusercreationApproval.asp
  //if(varstr)
  window.attachEvent(window.parent.GenDisp(varstr))
  
  // Close the list window
  window.close()
 
}
//-->
</SCRIPT>

<%
 '''''Declaration of required variables
 dim objfetch
 dim objfetch1
 dim RecGen
 dim cnt
 dim userid
 dim brcode
 dim recrs1
 ''''' Set object variables
  objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
  RecGen=server.CreateObject("adodb.recordset")
 
 '''' Values from GENUSERCREATION.ASP
 varstr=Request.QueryString("st")
 ''''' Querying the values of User Informaion
 if len(varstr)>0 then
  RecGen=objfetch.singleRecordset("GenUserMst", _
		"BRANCHCODE,BIOMETRICS,GROUPID,GROUPNAME,DESIGNATION,ADDRESS,CITY,EMAILID," & _
		"USERMACHINEID,NOOFSESSIONS,nvl(accountstatus,'R')," & _
		"nvl(accountstatusnarration,'Running'),empcode,abbuseryn,mobileno,userdob", _
		" upper(userid)='" & ucase(varstr) &"'")
 userid=""
  if not RecGen.EOF and not RecGen.bof then  '''' If records found
	RecGen.MoveFirst
	brcode=RecGen(0).value
	'''' Store the information in Userid string
	for icount=0 to RecGen.Fields.Count - 1
		  userid=userid & RecGen(icount).value & "+}" & ""
	next
 end if
 
 '''' Getting branchcode and narration from GENBANKBRANCHMST
   objfetch1=server.CreateObject("queryrecordsets.fetchrecordsets")
   recrs1=server.CreateObject("adodb.recordset")
  recrs1=objfetch1.singlerecordset("GENBANKBRANCHMST","Branchcode,narration","branchcode='" & brcode & "'")
if not recrs1.EOF and not recrs1.bof then
	userid=userid & recrs1(1).value & "+}" & ""
end if
end if
Response.Write (userid & "ch")
%>
 
<title></title>
</head>
<body onload="List()">

<form name="frmuser">
  <input type="hidden" id="hiduid" name="hiduid" value="<%=userid%>">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%"><center><font class="textblue">Processing..........</font></center></td>
    </tr>
  </table>

</form>

</body>

</html>
