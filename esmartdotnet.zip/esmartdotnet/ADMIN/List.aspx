<%@ Page Language="vb" CodeBehind="List.aspx.vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.List2" %>
<% Response.CacheControl = "no-cache" %>
<% Response.AddHeader("Pragma", "no-cache") %>
<% Response.Expires = -1 %>
<HTML>
	<HEAD>
		<title>eSmartBanker</title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<%On error resume next
 strType=Request.QueryString("st")
 brchCd=Request.QueryString("brchCd")
 atype=Request.QueryString("atype")
 Modid=Request.QueryString("Modid")
 status="Y"
%>
			<SCRIPT LANGUAGE="javascript" src="proc.js">
			</SCRIPT>
			<SCRIPT LANGUAGE="javascript">
function List()
{
var callerWindowObj = dialogArguments;
var kstr,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else

 {
	kstr= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
			
if (type=="Branch")
{
	callerWindowObj.Branchid(kstr)
	window.close()
}
else if (type=="Currency")
{
	callerWindowObj.Currencyid(kstr)
	window.close()
}	
	else if (type=="BLevel")
{
	callerWindowObj.Levelid(kstr)
	window.close()
}
else if (type=="Curr")
{
	callerWindowObj.Currid(kstr)
	window.close()
}
else if (type=="Module")
{
	callerWindowObj.Moduleid(kstr)
	window.close()
}
else if (type.substring(0,6)=="Glcode")
{
	callerWindowObj.Glcodeid(kstr)
	window.close()
}
else if (type.substring(0,11)=="PigmyGlcode")
{
	callerWindowObj.Glcodeid(kstr)
	
	//window.attachEvent(window.opener.Glcodeid(kstr))
	window.close()
}
else if (type.substring(0,10)=="PigmyAccno")
{
	callerWindowObj.PigmyAccnoid(kstr)
	
	//window.attachEvent(window.opener.Accnoid(kstr))
	window.close()
}

else if (type.substring(0,5)=="Accno")
{
	callerWindowObj.Accnoid(kstr)
	window.close()
}
else if (type.substring(0,7)=="TransNo")
{
	callerWindowObj.TransNoid(kstr)
	window.close()
}
else if (type.substring(0,6)=="CustID")
{
	callerWindowObj.Custid(kstr)
	window.close()
}

else if (type.substring(0,11)=="Cashiertype")
{
	callerWindowObj.Cashiertype(kstr)
	window.close()
}
else if (type.substring(0,9)=="Cashierid")
{
	callerWindowObj.Cashierid(kstr)
	window.close()
}
else if (type.substring(0,10)=="Cashiermgt")
{
	callerWindowObj.CashierMgtid(kstr)
	window.close()
}
else if (type.substring(0,11)=="CutsoiledNo")
{
	callerWindowObj.CutSoiledid(kstr)
	window.close()
}
else if (type.substring(0,9)=="Allotment")
{
	callerWindowObj.Allotmentid(kstr)
	window.close()
}
else if (type.substring(0,7)=="Cashier")
{
	callerWindowObj.Cashiercd(kstr)
	window.close()
}
else if (type.substring(0,8)=="Bankcode")
{
	callerWindowObj.Bankid(kstr)
	window.close()
}
else if (type.substring(0,10)=="Cashierid1")
{
	callerWindowObj.Cashierid(kstr)
	window.close()
}
else if (type.substring(0,7)=="Cashacc")
{
	callerWindowObj.Cashieracc(kstr)
	window.close()
}
else if (type=="Groupid")
{
	callerWindowObj.UserCode(kstr)
	
	window.close()
}
else if (type.substring(0,8)=="Moduleid")
{
	callerWindowObj.Modulequery(kstr)
	window.close()
}
//else if (type.substring(0,6)=="Userid")
//{
//	callerWindowObj.UserCode(kstr))
	//window.close()
//}
else if ((type.substring(0,9)=="AppUserid") ||(type.substring(0,10)=="AppGroupid")||(type.substring(0,5)=="Work1") )
{
	
	callerWindowObj.UserCode(kstr)
	window.close()
}
else if (type.substring(0,14)=="AllotedCashier")
{
	callerWindowObj.AllotedCashierid(kstr)
	window.close()
}
else if (type.substring(0,16)=="Cashrefundaccept")
{
	callerWindowObj.Cashiercodeid(kstr)
	window.close()
}
else if (type.substring(0,12)=="Cashrefundno")
{
	callerWindowObj.Cashrefundid(kstr)
	window.close()
}
else if (type.substring(0,13)=="Cashcounterno")
{
	callerWindowObj.Cashcounterid(kstr)
	window.close()
}
else if ((type.substring(0,6)=="Userid")||(type.substring(0,7)=="WUserid"))
{
	callerWindowObj.UserCode(kstr)
	window.close()
}
else if (type.substring(0,7)=="Holiday")
{
	callerWindowObj.DisplayHoliday(kstr)
	
	window.close()
}

else if (type=="User")
{
	callerWindowObj.DisplayGroup(kstr)
	
	window.close()
}

else if (type=="Groups")
{
	callerWindowObj.DisplayGroups(kstr)
	
	window.close()
}

else if (type=="Group")
{
	
	callerWindowObj.DisplayGroup(kstr)
	
	window.close()
}
else if (type.substring(0,5)=="USRID")
{
	callerWindowObj.DisplayQuery(kstr)
	
	window.close()
}

else if (type.substring(0,5)=="Query")
{
	callerWindowObj.DisplayQuery(kstr)
	
	window.close()
}

else if (type.substring(0,6)=="PQuery")
{
	callerWindowObj.DisplayQuery(kstr)
	
	window.close()
}
else if (type.substring(0,5)=="Limit")
{
	callerWindowObj.DisplayLimits(kstr)
	
	window.close()
}
else if (type.substring(0,7)=="Machine")
{
	callerWindowObj.MachineIp(kstr)
	
	window.close()
}
}
}
			</SCRIPT>
			<%
dim obj,rs,k
  uid=session("userid")
   rs=server.CreateObject("adodb.recordset")
   rs1=server.CreateObject("adodb.recordset")
  obj=server.CreateObject("queryrecordsets.fetchrecordsets")

if strType ="Branch" then
	
	 obj1=server.CreateObject("GeneralTranQueries.TransactionQueries")
	 rs1=obj1.BranchCodes(cstr(uid))
	do while not rs1.EOF
		txt=txt & ",'" & rs1(0).value & "'"
		rs1.MoveNext 
	loop
	txt=right(txt,len(txt)-1)
	 rs=obj.singlerecordset("GENBANKBRANCHMST","branchcode,narration,branchtype","branchcode in (" & txt & ")")
	
elseif strType="BLevel" then
	 rs=obj.singlerecordset("GENBANKLEVELMST","code,narration")

elseif left(strType,7)="Machine" then
	kstr=split(strtype,"|")
	 rs=obj.singlerecordset("GENMACHINEDTLS","MACHINEIPADDRESS,MACHINEID","branchcode='" & _
			kstr(1) & "' and status='R' and machineipaddress not in(select NVL(usermachineid,'0') from genusermst where status='A')")	
	
elseif strType="Currency" then
	 rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration")
elseif strType="Curr" then
	 rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,precision")
	
elseif strType="Module" then
     rs=obj.singlerecordset("genmodulemst","moduleid,Narration","moduleid=moduleid order by narration")
   
elseif left(strType,6)="Glcode" then
   'stname=left(strType,2)
   'atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genglsheetmst","glcode,NARRATION","moduleid='"& atype    &"'")
    
'''''added by sharath 18-04-2008
elseif left(strType,11)="PigmyGlcode" then

   'PigmyGlcode|PIGMY
   k=split(strType,"|")
   atype=k(1)

    rs=obj.singlerecordset("genglsheetmst","glcode,NARRATION","moduleid='"& atype & "' and branchcode='" & k(2) & "'")
    
elseif left(strType,10)="PigmyAccno" then
	'PigmyAccno|104|PIGMY|102040
	k=split(strType,"|")
	brchCd=k(1)
	Modid=k(2)
	atype=k(3)
	
    dim objTrn
     'objTrn=Server.CreateObject("GeneralTranQueries.TransactionQueries")
     'rs=objTrn.AccountNumbers(cstr(brchCd),cstr(Modid),cstr(atype))
     rs=obj.singlerecordset(modid & "mst","Accno,Name","branchcode='" & _
	brchCd & "' and glcode='" & atype & "' and status='R' and accno " & _
	"not in (select distinct accno from pigmyagentmst where branchcode='" _
	& brchCd & "' and glcode='" & atype & "' and status='R')")
	
	 'objTrn=nothing 

'''''sharath 18-04-2008
            
elseif left(strType,5)="Accno" then
    'stname=left(strType,5)
    'atype=mid(strType,6,len(strType))
    dim objTrn
     objTrn=Server.CreateObject("GeneralTranQueries.TransactionQueries")
     rs=objTrn.AccountNumbers(cstr(brchCd),cstr(Modid),cstr(atype))
	 objTrn=nothing 
elseif left(strType,6)="CustID" then
    stname=left(strType,4)
    atype=mid(strType,7)
    rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","")
	
elseif left(strType,7)="TransNo" then
    stname=left(strType,5)
    atype=mid(strType,8)
     rs=obj.singlerecordset("translog","tranno,amount","glcode='"& atype &"'","tranno")
    
elseif strType="BGtype" then 
	stname=strType
	 rs=obj.singlerecordset("bgtypemst","bgtype,description","","description")
    
 elseif strType="Cashiertype" then
	stname=strType
	 rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration","","cashiertypeid")
    
  elseif strType="Cashier" then
	stname=strType
	strcond=" W.USERID = U.USERID AND W.USERID NOT IN (SELECT CASHIERID FROM CASHCOUNTERMST)"
	strfld="DISTINCT W.USERID,U.NAME"
	strtab="GENWORKALLOTMENTMST W,GENUSERMST U"
	 rs=obj.singlerecordset(cstr(strtab),cstr(strfld),cstr(strcond))
    
elseif left(strType,9)="Cashierid" then
	stname=strType
	k=split(strType,"*")
	 rs=obj.singlerecordset("cashcashierposmst cash,genusermst gen","cash.cashierid,gen.name","cash.cashierid=gen.userid and cash.cashierid <> 'V3'" )
	
elseif strType="Cashierid1" then
	stname=strType
	 rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid),gen.name","cash.cashierid=gen.userid")
elseif left(strType,14)="AllotedCashier" then
	stname=strType
	for i=1 to 2
	cash=split(stname,"*")
	next
	
	 rs=obj.singlerecordset("CASHALLOTMENTSTRN CASH,GENUSERMST GEN","DISTINCT(CASH.CASHIERID),GEN.NAME","CASH.CASHIERID=GEN.USERID AND CASH.BRANCHCODE='"& CASH(1) &"' AND CASH.CURRENCYCODE='" & CASH(2)&"'","CASH.CASHIERID")
	
elseif left(strType,9)="Allotment" then
	for i=1 to 2
	k=split(strType,"*")
	next
	 rs=obj.singlerecordset("cashallotmentstrn","Allotmentno","cashierid='" & k(1) &"' and counterno = '" & k(2) & "' and status='P'","allotmentno")	
elseif strtype="Bankcode" then
	 rs=obj.singlerecordset("Genbankmst","Bankname,BANKCODE")
	

elseif left(strtype,10)="Cashiermgt" then
	for i=1 to 3
	   k=split(strtype,"*")
	next
	 rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.cashierid=gen.userid and cash.cashierid not in ('" & k(3) &"')")
	'set rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid),gen.name,cash.counterno","cash.cashierid=gen.userid")
	elseif left(strtype,16)="Cashrefundaccept" then		
	k=split(strtype,"*")	
	 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen","distinct(cash.REFUNDEDUSERID),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.REFUNDEDUSERID=gen.userid  and cash.status='P' and cash.cashierid <> 'V4'" )	
	
elseif left(strtype,7)="Cashacc" then
	for i=1 to 2
		k=split(strtype,"*")
	next
	
	rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN cash,genusermst gen","distinct(cash.TOcashierid),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.TOcashierid=gen.userid and cash.status='P'","cash.TOcashierid")
	
elseif strtype="CutsoiledNo" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("CASHCUTNSPOILNOTESMST","CUTSOILTRANNO,custid,RECEIVEDFROM","branchcode='" & k(1) &"' and currencycode='" & k(2) &"'")

elseif left(strtype,7)="Holiday" then
	k=split(strtype,"|")
	rs=obj.singlerecordset("GENHOLIDAYSMST","Holidaydate,Narration","branchcode='" & k(1) &"' and typeofholiday='" & k(2) &"'")
elseif left(strtype,5)="Group" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='R'")
elseif left(strtype,6)="Groups" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='R'")
elseif left(strtype,4)="User" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENusermst","userid,name","STATUS='A'")
elseif left(strtype,5)="USRID" then
	'br=split(strtype,"|")
	'brcode=br(1)
	if mid(strtype,6,1)="N" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='A' and LOCKEDDATE is null and upper(userid) not in(select upper(userid) from genuserlogindtls)","Name")
	end if
elseif left(strtype,5)="Query" then
	br=split(strtype,"|")
	brcode=br(1)
	if mid(strtype,6,1)="N" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='A' and branchcode='" & brcode & "' and LOCKEDDATE is null and upper(userid) not in(select upper(userid) from genuserlogindtls)")
	elseif mid(strtype,6,1)="X" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='N' and branchcode='" & brcode & "' and upper(userid) not in(select upper(userid) from genuserlogindtls)")
	elseif mid(strtype,6,1)="M" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='P' and branchcode='" & brcode & "' and upper(userid) not in(select upper(userid) from genuserlogindtls)")
	elseif mid(strtype,6,1)="D" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='D' and branchcode='" & brcode & "' and upper(userid) not in(select upper(userid) from genuserlogindtls)")
		elseif mid(strtype,6,1)="U" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='A' and branchcode='" & brcode & "' and LOCKEDDATE is not null and upper(userid) not in(select upper(userid) from genuserlogindtls)")
	end if
elseif left(strtype,6)="PQuery" then
	br=split(strtype,"|")
	brcode=br(1)
	if mid(strtype,7,1)="N" then
		 rs=obj.singlerecordset("PIGMYAGENTMST a, pigmymst b","a.agentcode,a.agentName,a.accno,b.name,to_char(a.EXPIRYDATE,'DD-MON-YYYY')","a.status='R' and a.transtatus='A' and a.branchcode='" & brcode & "' and upper(a.userid) not in(select upper(userid) from PIGMYAGENTlogindtls) and b.glcode='" & br(2) & "' and b.accno=a.accno and a.branchcode=b.branchcode")
	elseif mid(strtype,7,1)="X" then
		 rs=obj.singlerecordset("PIGMYAGENTMST a, pigmymst b","a.agentcode,a.agentName,a.accno,b.name,to_char(a.EXPIRYDATE,'DD-MON-YYYY')||'~'||a.status","a.status in('R','F') and a.transtatus='A' and a.branchcode='" & brcode & "' and upper(a.userid) not in(select upper(userid) from PIGMYAGENTlogindtls) and b.glcode='" & br(2) & "' and b.accno=a.accno and a.branchcode=b.branchcode")
	elseif mid(strtype,7,1)="P" then
		 rs=obj.singlerecordset("PIGMYAGENTMST a, pigmymst b","a.agentcode,a.agentName,a.accno,b.name,to_char(a.EXPIRYDATE,'DD-MON-YYYY')","a.status='R'  and a.transtatus='P' and a.branchcode='" & brcode & "' and upper(a.userid) not in(select upper(userid) from PIGMYAGENTlogindtls) and b.glcode='" & br(2) & "' and b.accno=a.accno and a.branchcode=b.branchcode")
	elseif mid(strtype,7,1)="M" then
		 rs=obj.singlerecordset("PIGMYAGENTMSTTEMP a, pigmymst b","a.agentcode,a.agentName,a.accno,b.name,to_char(a.EXPIRYDATE,'DD-MON-YYYY')","a.status='P'  and a.transtatus='P' and a.branchcode='" & brcode & "' and upper(a.userid) not in(select upper(userid) from PIGMYAGENTlogindtls) and b.glcode='" & br(2) & "' and b.accno=a.accno and a.branchcode=b.branchcode")
	elseif mid(strtype,7,1)="D" then
		 rs=obj.singlerecordset("PIGMYAGENTMST a, pigmymst b","a.agentcode,a.agentName,a.accno,b.name,to_char(a.EXPIRYDATE,'DD-MON-YYYY')","a.status='D'  and a.transtatus='P' and a.branchcode='" & brcode & "' and upper(a.userid) not in(select upper(userid) from PIGMYAGENTlogindtls) and b.glcode='" & br(2) & "' and b.accno=a.accno and a.branchcode=b.branchcode")
	end if
elseif strType="Groupid" then
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","status='A'")		

elseif left(strType,6)="Userid" then
   atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genusermst","userid,name","branchcode='"& atype &"' and status='A'")

elseif left(strType,7)="WUserid" then
   atype=mid(strType,8,len(strType))
    rs=obj.singlerecordset("genusermst","userid,name","branchcode='"& atype &"' and status='A' " & _
					"and upper(userid) not in (select upper(userid) from GenUserLoginDtls)")
elseif strType="AppGroupid" then
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","groupcode in(select distinct(Groupcode) from gengroupformsmst where transtatus<>'A')")		

elseif left(strType,9)="AppUserid" then
   atype=mid(strType,7,len(strType))
   rs=obj.singlerecordset("genworkallotmentmst","userid,username","status<>'A'")

elseif left(strType,5)="Work1" then

   rs=obj.singlerecordset("genuseridformsmst a,genusermst b","distinct(a.userid),b.name","a.userid=b.userid and a.transtatus<>'A'")

elseif left(strtype,5)="Limit" then
	
	 rs=obj.singlerecordset("GENUSERGROUPLIMITTYPEMST","limittypecode,narration","STATUS<>'D'")
end if
%>
	</HEAD>
	<body>
		<form name="frmList">
			<div align="center">
				<center>
					<table border="0" cellspacing="0" cellpadding="0">
						<%	if len(strType)>8 then%>
						<tr class="bgcolor">
							<th>
								<font color="white">
									<%'=UCASE(stname)%>
									&nbsp;DESCRIPTION | CODE</font></th>
							<%else%>
							<th>
								<font color="white">
									<%'=UCASE(strType)%>
									&nbsp;DESCRIPTION | CODE</font></th>
							<%end if%>
						<tr>
							<td><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
									<% 
	if obj.ConnError="Connected" then 
		if not rs.EOF and not rs.BOF then
			do until rs.EOF
				if rs.Fields.Count < 2 then%>
									<option><%=rs(0).value%></option>
									<%elseif rs.Fields.Count=3 then%>
									<option><%=rs(1).value%>-----<%=rs(0).value%>-----<%=rs(2).value%></option>
									<%elseif rs.Fields.Count=4 then%>
									<option><%=rs(1).value%>-----<%=rs(0).value%>-----<%=rs(2).value%>-----<%=rs(3).value%></option>
									<%elseif rs.Fields.Count=5 then%>
									<option><%=rs(1).value%>-----<%=rs(0).value%>-----<%=rs(2).value%>-----<%=rs(3).value%>-----<%=rs(4).value%></option>
									<%else%>
									<option><%=rs(1).value%>-----<%=rs(0).value%></option>
									<%end if%>
									<%rs.MoveNext
			loop
		 else	
          %>
									<option>No Data Found...</option>
									<%		end if%>
									<%
	Response.Write ("<script language=vbscript>" & chr(13))
	Response.Write ("sub show()"& chr(13))  
	Response.Write ("window.document.frmList.cmbList.item(0).selected=true"& chr(13))      
	Response.Write ("end sub" & chr(13))  
	Response.Write ("call show()" & chr(13)) 
	Response.Write ("</script>" & chr(13)) 
  %>
									<%else%>
									<option><%=obj.ConnError%></option>
									<%	end if
 obj=nothing
          %>
								</select></td>
						</tr>
					</table>
				</center>
			</div>
			<center><input type="button" value="   OK   " name="butmd" onclick="List()" class="button"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="button"></center>
		</form>
		<b>
			<%=err.description%>
		</b>
		<p>&nbsp;</p>
		<% rs=nothing
Response.End()%>
	</body>
</HTML>
