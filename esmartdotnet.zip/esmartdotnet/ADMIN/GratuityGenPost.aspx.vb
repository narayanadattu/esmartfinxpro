Public Class GratuityGenPost
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim objtran As OracleClient.OracleTransaction
    'Protected WithEvents txtResult As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txtInputVals As System.Web.UI.WebControls.TextBox
    Dim objconn As New OracleClient.OracleConnection
    Dim errmsg As String
    Dim o_errmsg1 As String
    Dim objhotraw As New GENVALIDATIONS.Validations
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Try

            'txtResult.Text = ""
            Dim strCurrFileName, strCurrFileExt, filePath, strQS, strArrQS() As String

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If


            ' strQS = Request.QueryString("strVin")
            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")

            If strArrQS(0) = "OKCLICK" Then
                Dim impStatus As String
                impStatus = postTransaction()
            End If

        Catch ex As Exception
            'txtResult.Text = ex.Message()
        End Try
    End Sub


    Private Function postTransaction() As String
        Dim strNam As String
        Dim strtemp, strbill, grdRows, grdCols, strBal, strQS, strArrQS, strVal, strValDr, StrQuery, strEmpno, strEmprPf, strEmprEsi
        Dim str101BrCode, strSessBrCode, curCode, drMod, drGl, drAcc, appDate, userId, machineID, brAbbcode, stOtalow, strFinyr, strBatchNo, strTranNo1 As String
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        Dim dt As New DataTable
        Dim dblComm, dblSrv, totDrAmt As Double
        Dim objDrgip As OracleClient.OracleDataReader
        Dim strCommMod, strCommGl, strCommAcc As String
        Dim strCommBr As String
        Dim iCnt As Integer
        Dim objDrtab As OracleClient.OracleDataReader
        Dim strGraAmt, strTranNo2, strRemarksCr As String
        Dim strTranCols, StrInsert As String
        Dim strRemarksDr As String
        Dim strEmpCode, strEmpName, dblbasicamt, dbldaamt As String

        Try
            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")
            strVal = strArrQS(1).Split("@")
            strValDr = strVal(0).Split("~")
            Dim strvalcol, strvalrow()
            strvalrow = strVal(1).Split("|")

            appDate = strValDr(0)
            userId = strValDr(1)
            machineID = strValDr(2)
            totDrAmt = strValDr(3)
            strSessBrCode = strValDr(4)
            strFinyr = strValDr(5)

            ''  str101BrCode = "101"
            '' modified by dattu 24-nov-22
            '' HO Trans Allowed
            str101BrCode = objhotraw.GetHOTRALWBrCode()
            strBatchNo = ""
            strTranNo1 = ""
            curCode = "INR"
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            objtran = objconn.BeginTransaction()

            ''for bank name 
            StrQuery = ""
            Dim stBnam As String
            StrQuery = "SELECT depcertificate from genbankparm"

            Dim objBnk As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objBnk, StrQuery, objtran)

            If objBnk.HasRows = True Then
                objBnk.Read()

                stBnam = objBnk(0)

            End If

            objBnk.Close()
            objBnk.Dispose()
            objBnk = Nothing

            If strSessBrCode = str101BrCode Then
                brAbbcode = ""
            Else
                brAbbcode = "ABB"
            End If

            If brAbbcode = "ABB" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            Else
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & strSessBrCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strSessBrCode & ".NEXTVAL TranNo FROM dual", objconn)
                objCmd.Transaction = objtran
                strTranNo1 = objCmd.ExecuteScalar
            End If


            StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='GRADR' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='GRADR' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

            Dim objDr As OracleClient.OracleDataReader
            ExecuteSelectQuery1(objDr, StrQuery, objtran)

            If objDr.HasRows = True Then
                objDr.Read()
                drMod = objDr(0)
                drGl = objDr(1)
                drAcc = objDr(2)

                StrQuery = "SELECT glcode,accno FROM " & drMod & "MST where GLCODE='" & drGl & "' and ACCNO='" & drAcc & "' and Branchcode='" & strSessBrCode & "'"

                ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                If objDrtab.HasRows = True Then
                    objDrtab.Read()

                    drGl = objDrtab(0)
                    drAcc = objDrtab(1)

                    strRemarksDr = "GRATUITY FOR THE YEAR " & strFinyr
                    'GRATUITY DR

                    strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                                          "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                                          "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                                          "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                                          "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                                          "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                                          "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                                          "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                                          "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                                          "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                                          "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                                          "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                                          "ABBYN"

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strSessBrCode & "','" & curCode & "','" & drMod & "'," & _
                                    "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                    "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                    "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & strSessBrCode & "','" & appDate & "','Y')"
                    Else
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strSessBrCode & "','" & curCode & "','" & drMod & "'," & _
                                    "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                    "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                    "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If


                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strSessBrCode & "','" & curCode & "','" & drMod & "'," & _
                                    "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & strSessBrCode & "','" & appDate & "','Y',NULL)"
                    Else
                        StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strSessBrCode & "','" & curCode & "','" & drMod & "'," & _
                                    "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                    "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                    "BRANCHCODE='" & strSessBrCode & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If


                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                Else
                    Throw New Exception("glcode and accno is null for " & drMod & " in " & strSessBrCode)

                End If

                objDrtab.Close()
                objDrtab.Dispose()
                objDrtab = Nothing

            Else
                Throw New Exception("ModuleId or Glcode Or Accno is null for GRATUITY DR ")

            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing

            StrQuery = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='GRACR' and drcrflg='C' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='GRACR' and drcrflg='C' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

            ExecuteSelectQuery1(objDrgip, StrQuery, objtran)

            If objDrgip.HasRows = True Then
                objDrgip.Read()

                strCommMod = objDrgip(0)
                strCommGl = objDrgip(1)
                strCommAcc = objDrgip(2)

                StrQuery = "SELECT glcode,accno FROM " & strCommMod & "MST where GLCODE='" & strCommGl & "' and ACCNO='" & strCommAcc & "' and Branchcode='" & str101BrCode & "'"

                ExecuteSelectQuery1(objDrtab, StrQuery, objtran)

                If objDrtab.HasRows = True Then
                    objDrtab.Read()

                    strCommGl = objDrtab(0)
                    strCommAcc = objDrtab(1)



                    For iCnt = 0 To strvalrow.Length - 1

                        'For iCnt = 0 To UBound(strvalrow)
                        strvalcol = strvalrow(iCnt).Split("~")

                        strEmpCode = strvalcol(0)
                        strEmpName = strvalcol(1)
                        dblbasicamt = strvalcol(2)
                        dbldaamt = strvalcol(3)
                        strGraAmt = strvalcol(4)


                        If brAbbcode = "ABB" Then
                            objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                            objCmd.Transaction = objtran
                            strTranNo2 = objCmd.ExecuteScalar
                        Else
                            objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strSessBrCode & ".NEXTVAL TranNo FROM dual", objconn)
                            objCmd.Transaction = objtran
                            strTranNo2 = objCmd.ExecuteScalar
                        End If


                        'Gratuity Amount for the Year'
                        strRemarksCr = "Gratuity Amount for " & strEmpName & " for the Year " & strFinyr

                        If brAbbcode = "ABB" Then
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & str101BrCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strGraAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & strSessBrCode & "','" & appDate & "','Y')"
                        Else
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & str101BrCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strGraAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                        End If



                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                        If brAbbcode = "ABB" Then
                            StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & str101BrCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strGraAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & strSessBrCode & "','" & appDate & "','Y',NULL)"
                        Else
                            StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & str101BrCode & "','" & curCode & "','" & strCommMod & "'," & _
                                        "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                                        "'" & strTranNo2 & "'," & strGraAmt & ",'4',NULL,NULL,NULL," & _
                                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                                        "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                                        "BRANCHCODE='" & str101BrCode & "'),NULL,NULL,NULL," & _
                                        "NULL,NULL,'N',NULL,'Y'," & _
                                        "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                        "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                        End If



                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing


                        '' insert into GRATUITYDTLS
                        StrInsert = "INSERT INTO GRATUITYDTLS(SLNO, FINANCIALYEAR, EMPCODE, EMPNAME, BASIC, DA, GRATUITY) VALUES((SELECT NVL(MAX(slno),0)+1   FROM GRATUITYDTLS),'" & strFinyr & "','" & strEmpCode & "','" & strEmpName & "'," & dblbasicamt & "," & dbldaamt & "," & strGraAmt & ")"
                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                    Next iCnt
                End If
            End If

            objtran.Commit()
            'postTransaction = "Posted SuccessFully|" & strBatchNo
            Response.Redirect("frmSalgenerate.aspx?record=Transaction Completed Batchno " & strBatchNo)

        Catch ex As Exception
            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "").Replace("?", "")

            Response.Redirect("frmSalgenerate.aspx?record=" & o_errmsg1, False)
        End Try
    End Function

    Public Function ExecuteSelectQuery1(ByRef objDrL As OracleClient.OracleDataReader, ByVal StrQuery As String, ByVal objtrn As OracleClient.OracleTransaction)

        objCmd = New OracleClient.OracleCommand(StrQuery, objconn)
        objCmd.Transaction = objtrn
        objDrL = objCmd.ExecuteReader()
        objCmd.Dispose()
        objCmd = Nothing
    End Function

End Class
