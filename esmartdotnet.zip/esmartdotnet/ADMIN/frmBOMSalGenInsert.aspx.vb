Public Class frmBOMSalGenInsert
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim errmsg, o_errmsg, o_errmsg1 As String
    Dim icnt As Integer = 0
    Dim strBOMsalDtls As String

    Dim dbltotBOMSalAmt As Double
    Dim dbTDSAmt As Double

    Dim strSql As String
    Dim objtran As OracleClient.OracleTransaction
    Dim strdirid, strTDSyn As String
    Dim strselmonth, strselyear As String

    Dim dblBOMSalAmt As Double = 0
    Dim userId, machineID, appDate As String
    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim brAbbcode, strBatchNo, strMainBrCode, brCode, strTranNo1, totDrAmt, strTranNo2, strTranNoTDS As String
    Dim strvalcol, strvalrow()
    Dim objDr As OracleClient.OracleDataReader
    Dim drMod, drGl, drAcc As String
    Dim objDrtab As OracleClient.OracleDataReader
    Dim strCrBrID, strCrModid, strCrGLCode, strCraccno, strCrAccName As String
    Dim strCrLnkModid, strCrLnkGLCode, strCrLnkaccno, strCrLnkAccName As String
    Dim strRemarksDr, strRemarksCr, strTranCols, curCode As String
    Dim strpaymentmode, straccno As String
    Dim strDrbrCode, strAccFullName, stIfsc, stPynam, stPyAccno, stPyacTy, stPyBnk, stPyBnam, stPyamt, stChr, stSer, strTranStatus, stNft, stRmk, strMobileno, strMobileNoDr, strNeftRtgsRefno As String
    Dim objval As New GENVALIDATIONS.Validations
    Dim objDrtab2 As OracleClient.OracleDataReader
    Dim strCustomerid, strAssessYear As String
    Dim objhotraw As New GENVALIDATIONS.Validations
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            strDrbrCode = Session("branchcode")
            ' strMainBrCode = "101"
            '' modified by dattu 24-nov-22
            '' HO Trans Allowed
            strMainBrCode = objhotraw.GetHOTRALWBrCode()
            brCode = Session("branchcode")
            curCode = "INR"
            userId = Session("userid")
            machineID = Session("machineid")
            appDate = Session("applicationdate")
            strBOMsalDtls = Request.Form("hdnBOMSalDtls")
            strvalrow = strBOMsalDtls.Split("|")
            strselmonth = Request.Form("hdnsalmon")
            strselyear = Request.Form("hdnsalyear")
            dbltotBOMSalAmt = Request.Form("hdndbltotBOMSal")
            totDrAmt = dbltotBOMSalAmt

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            objtran = objconn.BeginTransaction()

            If totDrAmt <> 0 Then


                For icnt = 0 To strvalrow.Length - 1
                    strvalcol = strvalrow(icnt).Split("~")

                    strdirid = strvalcol(0)
                    dblBOMSalAmt = strvalcol(1)
                    strTDSyn = strvalcol(2)
                    dbTDSAmt = strvalcol(3)



                    strSql = "SELECT paymentmode,accno,PAYEENAME,IFSCCODE FROM GENDIRECTORDTLS WHERE DIRCODE = '" & strdirid & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDrtab2 = objCmd.ExecuteReader()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If objDrtab2.HasRows = True Then
                        objDrtab2.Read()

                        strpaymentmode = IIf(IsDBNull(objDrtab2!paymentmode), "", objDrtab2!paymentmode)
                        straccno = IIf(IsDBNull(objDrtab2!accno), "", objDrtab2!accno)
                        strAccFullName = IIf(IsDBNull(objDrtab2!PAYEENAME), "", objDrtab2!PAYEENAME)
                        stIfsc = IIf(IsDBNull(objDrtab2!IFSCCODE), "", objDrtab2!IFSCCODE)


                    End If ''objDrtab2


                    objDrtab2.Close()
                    objDrtab2 = Nothing

                    If strpaymentmode = "T" Then
                        GetCreditBrAcGlAcc(straccno, strCrBrID, strCrModid, strCrGLCode, strCraccno)
                        If brCode <> strCrBrID Then

                            brAbbcode = "ABB"

                            Exit For

                        End If
                    Else
                        strCrBrID = strMainBrCode
                        GetCreditInvGlcodeAccno(strCrModid, strCrGLCode, strCraccno)
                        brAbbcode = ""
                    End If


                Next
                If brAbbcode = "ABB" Then
                    objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strBatchNo = objCmd.ExecuteScalar

                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strTranNo1 = objCmd.ExecuteScalar
                Else
                    objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strBatchNo = objCmd.ExecuteScalar

                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                    objCmd.Transaction = objtran
                    strTranNo1 = objCmd.ExecuteScalar
                End If
                '' debit modid,glcode,accno

                strSql = "SELECT Moduleid,glcode,accno FROM SALARYCTRLMST where saltype='BOMSAL' and drcrflg='D' and status='R' AND APPLICATIONDATE = (SELECT MAX(APPLICATIONDATE) FROM SALARYCTRLMST WHERE saltype='BOMSAL' and drcrflg='D' and status='R' AND MODULEID IS NOT NULL AND GLCODE IS NOT NULL AND ACCNO IS NOT NULL AND DRCRFLG  IS NOT NULL)"

                objCmd = New OracleClient.OracleCommand(strSql, objconn)
                objCmd.Transaction = objtran
                objDr = objCmd.ExecuteReader()
                objCmd.Dispose()
                objCmd = Nothing
                If objDr.HasRows = True Then
                    objDr.Read()
                    drMod = objDr!Moduleid
                    drGl = objDr!glcode
                    drAcc = objDr!accno


                    objDr.Close()
                    objDr = Nothing


                    strSql = "SELECT glcode,accno FROM " & drMod & "MST where GLCODE='" & drGl & "' and ACCNO='" & drAcc & "' and Branchcode='" & brCode & "'"

                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDrtab = objCmd.ExecuteReader()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If objDrtab.HasRows = True Then
                        While objDrtab.Read

                            drGl = objDrtab(0)
                            drAcc = objDrtab(1)

                            strRemarksDr = "BOM Salary Paid for Month" & strselmonth & " And Year  " & strselyear


                            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                            "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                            "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                            "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                            "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                            "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                            "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                            "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                            "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                            "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                            "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                            "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                            "ABBYN"

                            If brAbbcode = "ABB" Then
                                strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                            "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                            "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                            Else
                                strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                            "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                            "SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                            End If


                            objCmd = New OracleClient.OracleCommand(strSql, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            If brAbbcode = "ABB" Then
                                strSql = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                            Else
                                strSql = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                            "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                            "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                            "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                            "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                            "BRANCHCODE='" & brCode & "'),NULL,NULL,NULL," & _
                                            "NULL,NULL,'N',NULL,'Y'," & _
                                            "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                            "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                            End If


                            objCmd = New OracleClient.OracleCommand(strSql, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing
                        End While
                    Else
                        Throw New Exception("glcode and accno is null for " & drMod & " in " & brCode)

                    End If

                    objDrtab.Close()
                    objDrtab.Dispose()
                    objDrtab = Nothing

                Else
                    Throw New Exception("ModuleId or Glcode Or Accno is null for Debit Sitting Fee Paid ")
                End If

            End If  '' totdramt

            For icnt = 0 To strvalrow.Length - 1
                strvalcol = strvalrow(icnt).Split("~")

                strdirid = strvalcol(0)
                dblBOMSalAmt = strvalcol(1)
                strTDSyn = strvalcol(2)
                dbTDSAmt = strvalcol(3)

                strAccFullName = ""
                stIfsc = ""


                If dblBOMSalAmt <> 0 Then


                    strSql = "SELECT paymentmode,accno,PAYEENAME,IFSCCODE FROM GENDIRECTORDTLS WHERE DIRCODE = '" & strdirid & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDrtab2 = objCmd.ExecuteReader()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If objDrtab2.HasRows = True Then
                        objDrtab2.Read()

                        strpaymentmode = IIf(IsDBNull(objDrtab2!paymentmode), "", objDrtab2!paymentmode)
                        straccno = IIf(IsDBNull(objDrtab2!accno), "", objDrtab2!accno)
                        strAccFullName = IIf(IsDBNull(objDrtab2!PAYEENAME), "", objDrtab2!PAYEENAME)
                        stIfsc = IIf(IsDBNull(objDrtab2!IFSCCODE), "", objDrtab2!IFSCCODE)

                    End If ''objDrtab2


                    objDrtab2.Close()
                    objDrtab2 = Nothing


                    If strpaymentmode = "T" Then
                        GetCreditBrAcGlAcc(straccno, strCrBrID, strCrModid, strCrGLCode, strCraccno)
                    Else
                        strCrBrID = strMainBrCode
                        GetCreditInvGlcodeAccno(strCrModid, strCrGLCode, strCraccno)
                    End If
                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNo2 = objCmd.ExecuteScalar
                    End If

                    strRemarksCr = "BOM Salary Paid for Month" & strselmonth & " And Year  " & strselyear

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblBOMSalAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblBOMSalAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If



                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblBOMSalAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNo2 & "'," & dblBOMSalAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If


                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing


                    If strpaymentmode = "T" Then
                    Else
                        stPyamt = totDrAmt
                        stNft = "NEFT"
                        strMobileno = objval.GetCustMobileNo(strCrBrID, curCode, strCrModid, strCrGLCode, strCraccno)
                        strMobileNoDr = ""
                        strNeftRtgsRefno = ""
                        strNeftRtgsRefno = objval.GetRefno(objconn, objtran, o_errmsg)
                        If o_errmsg <> "" Then
                            Throw New Exception(o_errmsg)
                        End If
                        ''for NeftRtgs Table insert
                        strSql = "INSERT INTO NEFTRTGSDTLS (BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME,AMOUNT, PAYEENAME, PAYEEACCNO,PAYEEACCTYPE, PAYEEBANK, PAYEEBRANCH,IFSCCODE, PAYEEAMT,CITY, COMM,SERVTAX, BATCHNO, TRANNO,TRANSTATUS, APPLICATIONDATE, USERID,MACHINEID, SYSTEMYEAR, SYSTEMDATE,NEFTRTGS,REMARKS,mobile,SENDMOBILENO,refno,FILEGENYN,sessbrcode) VALUES ('" & strDrbrCode & "','" & curCode & "','" & drMod & "','" & drGl & "','" & drAcc & "','" & strAccFullName & "','" & totDrAmt & "','" & stPynam & "', '" & stPyAccno & "','', '', '', '" & stIfsc & "', '" & stPyamt & "', '', '','','" & strBatchNo & "','" & strTranNo1 & "','" & strTranStatus & "','" & appDate & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')),SYSDATE,'" & stNft & "','" & stRmk & "','" & strMobileno & "','" & strMobileNoDr & "','" & strNeftRtgsRefno & "','Y','" & brCode & "')"


                        objCmd = New OracleClient.OracleCommand(strSql, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                    End If
                End If

                If strTDSyn = "Y" Then
                    strCrBrID = strMainBrCode
                    GetCreditTDSGlcodeAccno(strCrLnkModid, strCrLnkGLCode, strCrLnkaccno, strCrLnkAccName)

                    If brAbbcode = "ABB" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brAbbcode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNoTDS = objCmd.ExecuteScalar
                    Else
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                        objCmd.Transaction = objtran
                        strTranNoTDS = objCmd.ExecuteScalar
                    End If

                    strRemarksCr = "TDS for Month" & strselmonth & " And Year  " & strselyear

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoTDS & "'," & dbTDSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y')"
                    Else
                        strSql = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoTDS & "'," & dbTDSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N')"
                    End If

                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    If brAbbcode = "ABB" Then
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoTDS & "'," & dbTDSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),'" & brCode & "','" & appDate & "','Y',NULL)"
                    Else
                        strSql = "INSERT INTO " & strCrModid & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strCrBrID & "','" & curCode & "','" & strCrModid & "'," & _
                                    "'" & strCrGLCode & "','" & strCraccno & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoTDS & "'," & dbTDSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),(SELECT NAME FROM " & strCrModid & "MST " & _
                                    "WHERE ACCNO='" & strCraccno & "' AND GLCODE='" & strCrGLCode & "' AND " & _
                                    "BRANCHCODE='" & strCrBrID & "'),NULL,NULL,NULL," & _
                                    "NULL,NULL,'N',NULL,'Y'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,SYSDATE,SYSDATE,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','A',SYSDATE,'" & userId & "','" & machineID & "','" & userId & "','" & machineID & "',TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')),NULL,NULL,'N',NULL)"
                    End If


                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                    Dim strfrmdate, strtodate As String
                    Dim intmon, intyear As Integer
                    objval.GetCustomerIDName(strCrBrID, curCode, strCrModid, strCrGLCode, strCraccno, strCustomerid, strCrAccName)
                    intmon = Format(CDate(appDate), "MM")
                    intyear = Format(CDate(appDate), "yyyy")
                    ''  for jan ,feb,mar
                    If intmon <= 3 Then
                        strfrmdate = "01-Apr-" & CStr(intyear - 1)
                        strtodate = "31-Mar-" & CStr(intyear)
                        '' for rest of months
                    Else
                        strfrmdate = "01-Apr-" & CStr(intyear)
                        strtodate = "31-Mar-" & CStr(intyear + 1)
                    End If
                    '' assesment year
                    strAssessYear = Format(CDate(strfrmdate), "yyyy") & Format(CDate(strtodate), "yy")
                    ''for tdsdtls Table insert
                    strSql = "INSERT INTO tdsdtls (BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, NAME, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN, FROMDATE, TODATE,LNKMODULEID, LNKGLCODE, LNKACCNO, REMARKS, TRANSTATUS, STATUS, USERID, MACHINEID, SYSTEMDATE, APPLICATIONDATE, CUSTOMERID, ASSESYEAR, PANYN, ITFORM) VALUES ('" & strCrBrID & "','" & curCode & "','" & strCrModid & "','" & strCrGLCode & "','" & strCraccno & "','" & strCrAccName & "','" & strBatchNo & "','" & strTranNoTDS & "', '" & dbTDSAmt & "',3, '" & strfrmdate & "', '" & strtodate & "','" & strCrLnkModid & "','" & strCrLnkGLCode & "','" & strCrLnkaccno & "','" & strRemarksCr & "','A','R','" & userId & "','" & machineID & "',SYSDATE,'" & appDate & "','" & strCustomerid & "','" & strAssessYear & "','N','94A')"

                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                End If  ''strTDSyn = "Y"

                strSql = "INSERT INTO BOMSALPAIDDTLS (DIRCODE, BOMSALARY, TDS, PAIDMONTH, PAIDYEAR, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE, PAIDBATCH) VALUES ('" & strdirid & "'," & dblBOMSalAmt & "," & dbTDSAmt & ",'" & strselmonth & "'," & strselyear & ",'" & appDate & "','" & userId & "','" & machineID & "',SYSDATE,'" & strBatchNo & "')"

                objCmd = New OracleClient.OracleCommand(strSql, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

            Next

            objtran.Commit()
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmBOMSalaryGen.aspx?record=Transaction Completed Batchno " & strBatchNo, False)
            Exit Sub
        Catch ex As Exception
            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("http://" & Session("moduledir") & "/ADMIN/frmBOMSalaryGen.aspx?record=" & o_errmsg1, False)

        End Try

    End Sub

    Private Sub GetCreditBrAcGlAcc(ByVal strfullaccno2 As String, ByRef pstrBrId As String, ByRef pstrACTP As String, ByRef pstrGlcd As String, ByRef pstrAccNo As String)
        Dim strfullaccno1 As String

        Dim NFTSCONVYN As String
        Try
            strfullaccno1 = StrReverse(Mid(StrReverse(strfullaccno2), 1, 16))

            pstrBrId = Mid(strfullaccno1, 1, 3)
            pstrGlcd = Mid(strfullaccno1, 4, 6)

            '' for accno 16 digits only
            NFTSCONVYN = objval.GetNFTSCONVYN
            If NFTSCONVYN = "Y" Then
                pstrAccNo = pstrBrId & pstrGlcd & Mid(strfullaccno1, 10, 7)
            Else
                pstrAccNo = Mid(strfullaccno1, 10, 7).TrimStart("0")
            End If
            pstrACTP = objval.GetModuleID(pstrGlcd)
            Exit Sub
        Catch ex As Exception

        End Try
    End Sub



    Private Sub GetCreditInvGlcodeAccno(ByRef ModId As String, ByRef GlCode As String, ByRef AccNo As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strMobileNo As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "SELECT MODULEID, GLCODE, ACCNO FROM NEFTRTGSTYPEPMT WHERE trantype = 'NEFTOW'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)

            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()

                ModId = IIf(IsDBNull(dr!MODULEID), "", dr!MODULEID)
                GlCode = IIf(IsDBNull(dr!GLCODE), "", dr!GLCODE)
                AccNo = IIf(IsDBNull(dr!ACCNO), "", dr!ACCNO)
            Else
                ModId = ""
                GlCode = ""
                AccNo = ""
            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Sub
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GetCreditTDSGlcodeAccno(ByRef ModId As String, ByRef GlCode As String, ByRef AccNo As String, ByRef AccName As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strMobileNo As String = ""
        Dim dr, dr1 As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "SELECT MODULEID, GLCODE FROM GENGLMASTMST g WHERE moduleid = 'MISC' AND glcode = '105036'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)

            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()

                ModId = IIf(IsDBNull(dr!MODULEID), "", dr!MODULEID)
                GlCode = IIf(IsDBNull(dr!GLCODE), "", dr!GLCODE)
                strQuery = "SELECT accno,name FROM miscmst WHERE glcode = '" & GlCode & "' AND accno = 5081 AND branchcode = 101"
                objCmd = New OracleClient.OracleCommand(strQuery, objCon)
                dr1 = objCmd.ExecuteReader
                If dr1.HasRows = True Then
                    dr1.Read()
                    AccNo = IIf(IsDBNull(dr1!ACCNO), "", dr1!ACCNO)
                    AccName = IIf(IsDBNull(dr1!name), "", dr1!name)
                Else
                    AccNo = ""
                    AccName = ""
                End If
                dr1.Close()
                dr1 = Nothing
            Else
                ModId = ""
                GlCode = ""

            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Sub
        Catch ex As Exception

        End Try
    End Sub
End Class
