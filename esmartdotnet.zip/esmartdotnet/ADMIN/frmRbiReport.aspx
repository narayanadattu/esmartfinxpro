<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmRbiReport.aspx.vb" Inherits="eSmartDotNet.frmRbiReport" %>
<%

dim strSql, strNftsYn,strBnk as string
strNftsYn="N"
dim rsNFTS, objNFTS
rsNFTS=server.CreateObject("adodb.recordset")
objNFTS =server.CreateObject("queryrecordsets.fetchrecordsets")
rsNFTS=objNFTS.singlerecordset("GENBANKPARM","NFTSCONVYN","")
if objNFTS.ConnError<>"Connected" then
	if not rsNFTS.bof and not rsNFTS.eof then
		strNftsYn=rsNFTS(0).value
	end if
end if
rsNFTS= nothing
objNFTS=nothing

dim rsBnk, objBnk

rsBnk=server.CreateObject("adodb.recordset")
objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
rsBnk=objBnk.singlerecordset("GENBANKPARM","bankname","")

if objBnk.ConnError="Connected" then	
	if not rsBnk.EOF and not rsBnk.BOF then
		strBnk = rsBnk(0).value
	end if
end if

rsBnk= nothing
objBnk=nothing


%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>RBI AUDIT Report</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT ID=javascript LANGUAGE=javascript>

var strVal

function ShowDivision(str)
{
	window.document.all.divOwRep.style.display="none"
	window.document.all.divInwRep.style.display="none"
	window.document.all.divLastran.style.display="none"
	window.document.all.divKycdtls.style.display="none"
	window.document.all.divAadharlnk.style.display="none"
	window.document.all.divNachDtls.style.display="none"
	window.document.all.divSusTranRep.style.display="none"
	window.document.frmRbiReport.mfgOutRep.Rows=1
	window.document.frmRbiReport.mfgInwRep.Rows=1
	window.document.frmRbiReport.mfgLstrnRep.Rows=1 
	window.document.frmRbiReport.mfgKycdtls.Rows=1 
	window.document.frmRbiReport.mfgAadlnk.Rows=1 
	window.document.frmRbiReport.mfgNachDtlsRep.Rows = 1
	
	if(str=="0")
	{
		window.document.all.divOwRep.style.display="block"
		window.document.frmRbiReport.radBrsid(0).checked=true
		window.document.frmRbiReport.radOutype(0).checked=true
		window.document.frmRbiReport.txtFmDat.value=""
		window.document.frmRbiReport.txtToDat.value=""
		window.document.frmRbiReport.cmbLogOper.value="="
		window.document.frmRbiReport.txtToDat.disabled=true
	}
	
	if(str=="1")
	{
		window.document.all.divInwRep.style.display="block"
		window.document.frmRbiReport.radInwBrid(0).checked=true
		window.document.frmRbiReport.radInwtype(0).checked=true
		window.document.frmRbiReport.txtInwFmDat.value=""
		window.document.frmRbiReport.txtToDat.value=""
		window.document.frmRbiReport.cmbInwdOper.value="="
		window.document.frmRbiReport.txtInwToDat.disabled=true
	}
	if(str=="2")
	{
		window.document.all.divLastran.style.display="block"
		window.document.frmRbiReport.txtModId.value=""
		window.document.frmRbiReport.txtModNm.value=""
		window.document.frmRbiReport.txtLastFmDat.value=""
	}
	if(str=="3")
	{
		window.document.all.divKycdtls.style.display="block"
		window.document.frmRbiReport.radKycSub(0).checked=true
		window.document.frmRbiReport.radKycust(0).checked=true
	}
	if(str=="4")
	{
		window.document.all.divAadharlnk.style.display="block"
	}
	if(str=="5")
	{
		window.document.all.divNachDtls.style.display="block"
		window.document.frmRbiReport.radNACHDtlsBrid(0).checked=true
		window.document.frmRbiReport.radNachDtlstype(0).checked=true
		window.document.frmRbiReport.txtNachDtlsFmDat.value = "<%=session("applicationdate")%>"
		window.document.frmRbiReport.txtNachDtlsToDat.value = "<%=session("applicationdate")%>"
		window.document.frmRbiReport.cmbNachDtlsOper.value="="
		window.document.frmRbiReport.txtNachDtlsToDat.disabled=true
		
	}
	if(str=="6")
	{
		window.document.all.divSusTranRep.style.display="block"
		window.document.frmRbiReport.txtstrFmDat.value = "<%=session("applicationdate")%>"
		window.document.frmRbiReport.txtstrToDat.value = "<%=session("applicationdate")%>"
		window.document.frmRbiReport.cmbstrOper.value="="
		window.document.frmRbiReport.txtstrToDat.disabled=true
	
	}
}

function selWise()
{
	window.document.frmRbiReport.mfgOutRep.Rows=1
	window.document.frmRbiReport.radOutype(0).checked=true
	window.document.frmRbiReport.txtFmDat.value=""
	window.document.frmRbiReport.txtToDat.value=""
	window.document.frmRbiReport.cmbLogOper.value="="
}

function selType()
{
	window.document.frmRbiReport.mfgOutRep.Rows=1
	window.document.frmRbiReport.txtFmDat.value=""
	window.document.frmRbiReport.txtToDat.value=""
	window.document.frmRbiReport.cmbLogOper.value="="
}

function toLogDisp()
{
	if(window.document.frmRbiReport.cmbLogOper.value!="Between")
	{
		window.document.frmRbiReport.txtToDat.disabled=true
	}
	else
	{
		window.document.frmRbiReport.txtToDat.disabled=false
	}
	
	if(window.document.frmRbiReport.cmbInwdOper.value!="Between")
	{
		window.document.frmRbiReport.txtInwToDat.disabled=true
	}
	else
	{
		window.document.frmRbiReport.txtInwToDat.disabled=false
	}
}

function selInWise()
{
	window.document.frmRbiReport.mfgInwRep.Rows=1
	window.document.frmRbiReport.radInwtype(0).checked=true
	window.document.frmRbiReport.txtInwFmDat.value=""
	window.document.frmRbiReport.txtInwToDat.value=""
	window.document.frmRbiReport.cmbInwdOper.value="="
}

function selInwType()
{
	window.document.frmRbiReport.mfgInwRep.Rows=1
	window.document.frmRbiReport.txtInwFmDat.value=""
	window.document.frmRbiReport.txtInwToDat.value=""
	window.document.frmRbiReport.cmbInwdOper.value="="
}

function module()
{ 
	window.document.frmRbiReport.txtModNm.value=""
	window.document.frmRbiReport.txtModId.value=""
	stmod="modulegender";
	
	stbr=window.document.frmRbiReport.txtBrcode.value.toUpperCase()
	kstr=stmod+"|"+stbr
	window.showModalDialog("../gen/Listquery.aspx?st="+kstr,window,"status:no;"+
		"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
}

function modulecode(kstr)
{
	var StrFld=new String()
	StrFld=kstr.split("-----")
	
	window.document.frmRbiReport.txtModNm.value=StrFld[0]
	window.document.frmRbiReport.txtModId.value=StrFld[1]
		
}

function selKycsub()
{
	window.document.frmRbiReport.mfgKycdtls.Rows=1
	window.document.frmRbiReport.radKycust(0).checked=true
}

function selKyCust()
{
	window.document.frmRbiReport.mfgKycdtls.Rows=1 
}

function KycQuery()
{
	window.document.frmRbiReport.mfgKycdtls.Rows=1 
	
	var stKycTp,stFld
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	if(window.document.frmRbiReport.radKycSub(0).checked==true)
	{
		if(window.document.frmRbiReport.radKycust(0).checked==true)
		{
			stKycTp = "KYCSUBACC"
		}
		if(window.document.frmRbiReport.radKycust(1).checked==true)
		{
			stKycTp = "KYCSUBCUST"
		}
	}
	if(window.document.frmRbiReport.radKycSub(1).checked==true)
	{
		if(window.document.frmRbiReport.radKycust(0).checked==true)
		{
			stKycTp = "KYCNONSUBACC"
		}
		if(window.document.frmRbiReport.radKycust(1).checked==true)
		{
			stKycTp = "KYCNONSUBCUST"
		}
	}
	
	if ('<%=strNftsYn%>' == "Y")
	{
		stFld = "Y"
	}
	else
	{
		stFld = "N"
	}
	
	strVal = "KYCDETAIL"+"|"+stKycTp+"|"+window.document.frmRbiReport.txtBrcode.value+"|"+stFld
	//alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
}

function popKycdtls(str)
{
	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
	
	window.document.frmRbiReport.mfgKycdtls.Rows=1 
	
	if(window.document.frmRbiReport.radKycSub(0).checked==true)
	{
		if(window.document.frmRbiReport.radKycust(0).checked==true)
		{
			window.document.frmRbiReport.mfgKycdtls.cols=14;
			window.document.frmRbiReport.mfgKycdtls.formatstring="<SLNO   |<Customer Id        |<Acc Type            |<Acc No                         |<Name                      |<DOB           |<Mobile             |<Father Name                         |<Operator                |<Nominee Name             |<KYC        |<Kyc ID                    |<Aadhar          |<Address                               ";
		}
		if(window.document.frmRbiReport.radKycust(1).checked==true)
		{
			window.document.frmRbiReport.mfgKycdtls.cols=10;
			window.document.frmRbiReport.mfgKycdtls.formatstring="<SLNO   |<Customer Id        |<Name                      |<DOB           |<Mobile             |<Father Name                         |<KYC        |<Kyc ID                    |<Aadhar          |<Address                               ";
		}
	}
	if(window.document.frmRbiReport.radKycSub(1).checked==true)
	{
		if(window.document.frmRbiReport.radKycust(0).checked==true)
		{
			window.document.frmRbiReport.mfgKycdtls.cols=11;
			window.document.frmRbiReport.mfgKycdtls.formatstring="<SLNO   |<Customer Id        |<Acc Type            |<Acc No                         |<Name                      |<DOB           |<Mobile             |<Father Name                         |<Operator                |<Nominee Name             |<Address                               ";
		}
		if(window.document.frmRbiReport.radKycust(1).checked==true)
		{
			window.document.frmRbiReport.mfgKycdtls.cols=7;
			window.document.frmRbiReport.mfgKycdtls.formatstring="<SLNO   |<Customer Id          |<Name                      |<DOB           |<Mobile             |<Father Name                         |<Address                               ";
		}
	}
	
	var stSal = str.split("|")
	
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
	{
		window.document.frmRbiReport.mfgKycdtls.rows=window.document.frmRbiReport.mfgKycdtls.rows+1
		
		var strCols=stSal[aCnt].split("~")
		
		window.document.frmRbiReport.mfgKycdtls.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmRbiReport.mfgKycdtls.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
		}
		
	}
	
}

function OtwordQuery()
{
	var stDtcnd,stBr,stSeltyp
	window.document.frmRbiReport.mfgOutRep.Rows=1
	
	if(window.document.frmRbiReport.cmbLogOper.value!="Between")
	{
		if(window.document.frmRbiReport.txtFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtFmDat.focus()
			return;	
		}
		
		if(window.document.frmRbiReport.radOutype(2).checked==true)
		{
			stDtcnd = " A.LODGEMENTDATE "+window.document.frmRbiReport.cmbLogOper.value+" '"+window.document.frmRbiReport.txtFmDat.value+"'"
		}
		else
		{
			stDtcnd = " LODGEMENTDATE "+window.document.frmRbiReport.cmbLogOper.value+" '"+window.document.frmRbiReport.txtFmDat.value+"'"
		}
	}
	else
	{
		if(window.document.frmRbiReport.txtFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtFmDat.focus()
			return;	
		}
		if(window.document.frmRbiReport.txtToDat.value=="")
		{
			alert("Please Enter To Date")
			window.document.frmRbiReport.txtToDat.focus()
			return;	
		}
		
		if(window.document.frmRbiReport.radOutype(2).checked==true)
		{
			stDtcnd = " A.LODGEMENTDATE BETWEEN '"+window.document.frmRbiReport.txtFmDat.value+"' AND '"+window.document.frmRbiReport.txtToDat.value+"'"
		}
		else
		{
			stDtcnd = " LODGEMENTDATE BETWEEN '"+window.document.frmRbiReport.txtFmDat.value+"' AND '"+window.document.frmRbiReport.txtToDat.value+"'"
		}
	}
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	if(window.document.frmRbiReport.radBrsid(0).checked==true)
	{
		if(window.document.frmRbiReport.radOutype(2).checked==true)
		{
			stBr = " AND A.BRANCHCODE = '"+window.document.frmRbiReport.txtBrcode.value+"'"
		}
		else
		{
			stBr = " AND BRANCHCODE = '"+window.document.frmRbiReport.txtBrcode.value+"'"
		}
	}
	if(window.document.frmRbiReport.radBrsid(1).checked==true)
	{
		stBr = " "
	}
	
	if(window.document.frmRbiReport.radOutype(0).checked==true)
	{
		stSeltyp = "MONTH"
	}
	if(window.document.frmRbiReport.radOutype(1).checked==true)
	{
		stSeltyp = "DAY"
	}
	if(window.document.frmRbiReport.radOutype(2).checked==true)
	{
		stSeltyp = "INSTRWISE"
	}
	
	strVal = "RBIOUTWORD"+"|"+stSeltyp+"|"+stDtcnd+"|"+stBr
	//alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	
}

function popRbiOut(str)
{
	var stTotint,stTotamt,stClgno,stClgamt,stRtno,stRtamt,stInst
	
	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
	
	stTotint = 0
	stTotamt = 0
	stClgno = 0
	stClgamt = 0
	stRtno = 0
	stRtamt = 0
	stInst = 0 
	
	window.document.frmRbiReport.mfgOutRep.Rows=1
	
	var stSal = str.split("|")
	
	if(window.document.frmRbiReport.radOutype(2).checked==true)
	{
		window.document.frmRbiReport.mfgOutRep.cols=13;
		window.document.frmRbiReport.mfgOutRep.formatstring="<SLNO   |<Br Code |<Lodgement Dt                  |<Issue Date         |<Instr No         |>Amount          |<Status       |<Issued By                       |<Regularise Dt                |<Cheque Rtn Dt       |<Receive From        |<Bank Name                    |<Branch Name                               ";
	}
	else
	{
		window.document.frmRbiReport.mfgOutRep.cols=8;
		window.document.frmRbiReport.mfgOutRep.formatstring="<SLNO   |<Clg Date                   |<Tot Inst           |>Tot Amount       |<No Of Clg     |>Clg Amount          |<No Of Rtn             |>Return Amt         ";
	}
	
	if(window.document.frmRbiReport.radOutype(2).checked==true)
	{
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgOutRep.rows=window.document.frmRbiReport.mfgOutRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)),2)
			}
			
			stInst = stInst+parseFloat(strCols[4])
			
		}
		
		
		window.document.frmRbiReport.hIstrAmt.value = stInst
		window.document.frmRbiReport.hIstrAmt.value = ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hIstrAmt.value),2)
	
	}
	else
	{

		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgOutRep.rows=window.document.frmRbiReport.mfgOutRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,3)),2)
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,5)),2)
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,7)=strCols[6]
				window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,7)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgOutRep.textmatrix(aCnt+1,7)),2)
				
			}
			
			stTotint = stTotint+parseFloat(strCols[1])
			stTotamt = stTotamt+parseFloat(strCols[2])
			stClgno = stClgno+parseFloat(strCols[3])
			stClgamt = stClgamt+parseFloat(strCols[4])
			stRtno = stRtno+parseFloat(strCols[5])
			stRtamt = stRtamt+parseFloat(strCols[6])
		}
			
			window.document.frmRbiReport.hInsTot.value=stTotint
			
			window.document.frmRbiReport.hTotAmt.value=stTotamt
			window.document.frmRbiReport.hTotAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hTotAmt.value),2)
			
			window.document.frmRbiReport.hClgTot.value=stClgno
			
			window.document.frmRbiReport.hClgAmt.value=stClgamt
			window.document.frmRbiReport.hClgAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hClgAmt.value),2)
			
			window.document.frmRbiReport.hRtnTot.value=stRtno
			
			window.document.frmRbiReport.hRtnAmt.value=stRtamt
			window.document.frmRbiReport.hRtnAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hRtnAmt.value),2)
	}
}

function InwordQuery()
{
	var stDtcnd,stBr,stSeltyp
	window.document.frmRbiReport.mfgInwRep.Rows=1
	
	if(window.document.frmRbiReport.cmbInwdOper.value!="Between")
	{
		if(window.document.frmRbiReport.txtInwFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtInwFmDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE "+window.document.frmRbiReport.cmbInwdOper.value+" '"+window.document.frmRbiReport.txtInwFmDat.value+"'"
		
	}
	else
	{
		if(window.document.frmRbiReport.txtInwFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtInwFmDat.focus()
			return;	
		}
		if(window.document.frmRbiReport.txtInwToDat.value=="")
		{
			alert("Please Enter To Date")
			window.document.frmRbiReport.txtInwToDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE BETWEEN '"+window.document.frmRbiReport.txtInwFmDat.value+"' AND '"+window.document.frmRbiReport.txtInwToDat.value+"'"
		
	}
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	if(window.document.frmRbiReport.radInwBrid(0).checked==true)
	{
		stBr = " AND BRANCHCODE = '"+window.document.frmRbiReport.txtBrcode.value+"'"
		
	}
	if(window.document.frmRbiReport.radInwBrid(1).checked==true)
	{
		stBr = " "
	}
	
	if(window.document.frmRbiReport.radInwtype(0).checked==true)
	{
		stSeltyp = "MONTH"
	}
	if(window.document.frmRbiReport.radInwtype(1).checked==true)
	{
		stSeltyp = "DAY"
	}
	if(window.document.frmRbiReport.radInwtype(2).checked==true)
	{
		stSeltyp = "INSTRWISE"
	}
	
	strVal = "RBIINWORD"+"|"+stSeltyp+"|"+stDtcnd+"|"+stBr
	//alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	
}

function popRbiIN(str)
{
	var stTotint,stTotamt,stClgno,stClgamt,stRtno,stRtamt,stInst
	
	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
	
	stTotint = 0
	stTotamt = 0
	stClgno = 0
	stClgamt = 0
	stRtno = 0
	stRtamt = 0
	stInst = 0 
	
	window.document.frmRbiReport.mfgInwRep.Rows=1
	
	var stSal = str.split("|")
	
	if(window.document.frmRbiReport.radInwtype(2).checked==true)
	{
		window.document.frmRbiReport.mfgInwRep.cols=11;
		window.document.frmRbiReport.mfgInwRep.formatstring="<SLNO   |<Br Code |<App Date                  |<Glcode         |<Accno         |<Name                   |>Amount          |<Cheque No.                 |<Cheque Date                |<Cheque Favouring              |<Remarks                       ";
	}
	else
	{
		window.document.frmRbiReport.mfgInwRep.cols=8;
		window.document.frmRbiReport.mfgInwRep.formatstring="<SLNO   |<Clg Dt                   |<Total Inst           |>Total Amount       |<No Of Clg     |>Clg Amount          |<No Of Rtn             |>Return Amt         ";
	}
	
	if(window.document.frmRbiReport.radInwtype(2).checked==true)
	{
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgInwRep.rows=window.document.frmRbiReport.mfgInwRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,6)=strCols[5]
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,6)),2)
			}
			
			stInst = stInst+parseFloat(strCols[5])
			
		}
		
		
		window.document.frmRbiReport.hIstrAmt.value = stInst
		window.document.frmRbiReport.hIstrAmt.value = ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hIstrAmt.value),2)
	
	}
	else
	{

		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgInwRep.rows=window.document.frmRbiReport.mfgInwRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,3)),2)
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,5)),2)
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,7)=strCols[6]
				window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,7)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgInwRep.textmatrix(aCnt+1,7)),2)
				
			}
			
			stTotint = stTotint+parseFloat(strCols[1])
			stTotamt = stTotamt+parseFloat(strCols[2])
			stClgno = stClgno+parseFloat(strCols[3])
			stClgamt = stClgamt+parseFloat(strCols[4])
			stRtno = stRtno+parseFloat(strCols[5])
			stRtamt = stRtamt+parseFloat(strCols[6])
		}
			
			window.document.frmRbiReport.hInsTot.value=stTotint
			
			window.document.frmRbiReport.hTotAmt.value=stTotamt
			window.document.frmRbiReport.hTotAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hTotAmt.value),2)
			
			window.document.frmRbiReport.hClgTot.value=stClgno
			
			window.document.frmRbiReport.hClgAmt.value=stClgamt
			window.document.frmRbiReport.hClgAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hClgAmt.value),2)
			
			window.document.frmRbiReport.hRtnTot.value=stRtno
			
			window.document.frmRbiReport.hRtnAmt.value=stRtamt
			window.document.frmRbiReport.hRtnAmt.value=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.hRtnAmt.value),2)
	}
}

function LstTrnQuery()
{
	var stFeld
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	if(window.document.frmRbiReport.txtModId.value=="")
	{
		alert("Please Select The Module Id")
		return;
	}
	if(window.document.frmRbiReport.txtLastFmDat.value=="")
	{
		alert("Please Enter The Date")
		window.document.frmRbiReport.txtLastFmDat.focus();
		return;
	}
	
	if ('<%=strNftsYn%>' == "Y")
	{
		stFeld = "Y"
	}
	else
	{
		stFeld = "N"
	}
	
	
	strVal = "LSTRNDETAIL"+"|"+window.document.frmRbiReport.txtModId.value.toUpperCase()+"|"+window.document.frmRbiReport.txtLastFmDat.value.toUpperCase()+"|"+stFeld+"|"+window.document.frmRbiReport.txtBrcode.value
	///alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
}

function popLstrep(str)
{
	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
	
	window.document.frmRbiReport.mfgLstrnRep.Rows=1 
	
	var stSal = str.split("|")
	
	window.document.frmRbiReport.mfgLstrnRep.cols=7;
	window.document.frmRbiReport.mfgLstrnRep.formatstring="<SLNO   |<AccType       |<AccNo.                         |<Name                        |>Balance                    |<LastTranDate                        |>CurBalance                ";
	
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
	{
		window.document.frmRbiReport.mfgLstrnRep.rows=window.document.frmRbiReport.mfgLstrnRep.rows+1
		
		var strCols=stSal[aCnt].split("~")
		
		window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
			
			window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,4)=strCols[3]
			window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,4)),2)
			
			window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,6)=strCols[5]
			window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgLstrnRep.textmatrix(aCnt+1,6)),2)
		}
		
	}
}

function AadharQuery()
{
	var stConsol
	
	stConsol = "0"
	window.document.frmRbiReport.mfgAadlnk.Rows=1
	
	if(window.document.frmRbiReport.txtAaDat.value=="")
	{
		alert("Please Enter The Date ")
		window.document.frmRbiReport.txtAaDat.focus();
		return;
	}
	
	if(window.document.frmRbiReport.chkConsol.checked==true)
	{
		stConsol = "1"
	}
	
	strVal = "AADHARLYNK"+"|"+window.document.frmRbiReport.txtAaDat.value.toUpperCase()+"|"+stConsol
	///alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
}

function round(number, precision) 
{ 
	var pair = (number + 'e').split('e') 
	var value = Math.round(pair[0] + 'e' + (+pair[1] + precision)) 
	pair = (value + 'e').split('e') 
	return +(pair[0] + 'e' + (+pair[1] - precision)) 
}

function popAadtals(str)
{
	window.document.frmRbiReport.mfgAadlnk.Rows=1
	
	if(str=="")
	{
		alert("No Records")
		return;
	}
	
	var stBnknam 
	
	if(window.document.frmRbiReport.chkConsol.checked==true)
	{
		window.document.frmRbiReport.mfgAadlnk.cols = 7;
		window.document.frmRbiReport.mfgAadlnk.formatstring="<SLNO   |Name Of Bank                      |<TotalActs         |<AadharLnk           |<Pending       |<Perct(%) |<Remarks                         ";
	}
	else
	{
		window.document.frmRbiReport.mfgAadlnk.cols = 8;
		window.document.frmRbiReport.mfgAadlnk.formatstring="<SLNO   |Name Of Bank                      |<BrCode   |<TotalActs         |<AadharLnk           |<Pending       |<Perct(%) |<Remarks                         ";
	}
	
	var stSal = str.split("|")
	
	var stval,stper
	
	for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
	{
		window.document.frmRbiReport.mfgAadlnk.rows=window.document.frmRbiReport.mfgAadlnk.rows+1
		
		var strCols=stSal[aCnt].split("~")
		
		window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,0)=aCnt+1
		window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,1) = "<%=strBnk%>"
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			stval = "0"
			if(window.document.frmRbiReport.chkConsol.checked==true)
			{
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,2) = strCols[0] // total acc
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,3) = strCols[1] // link acc
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,4) = eval(strCols[0]) - eval(strCols[1]) // pending acc
				stval = eval((eval(strCols[1]) / eval(strCols[0]))*100)
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,5) = round((eval(stval)),2) // % link
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,6) = ""
			}
			else
			{
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,2) = strCols[0] //branch code
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,3) = strCols[1] // total acc
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,4) = strCols[2] // link acc
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,5) = eval(strCols[1]) - eval(strCols[2]) // pending acc
				stval = eval((eval(strCols[2]) / eval(strCols[1]))*100)
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,6) = round((eval(stval)),2) // % link
				window.document.frmRbiReport.mfgAadlnk.textmatrix(aCnt+1,7) = ""
			}
		}
		
	}
	
}

function Report(strrep)
{
	var StrCol=""
	var StrRow=""
	var StrHead=""
	var StrCols=""
	var StrColRow=""
	var strheadsub=""
	var strheadtype = ""
	var strSum = ""
	var stConsol = ""
	
	if(window.document.all.divOwRep.style.display=="block")
	{
		strheadtype = "OutWord Clearing REPORT"
		
		if(window.document.frmRbiReport.radBrsid(1).checked==true)
		{
			stConsol = "Consolidate "
		}
		else
		{
			stConsol = ""
		}
		
		if(window.document.frmRbiReport.cmbLogOper.value!="Between")
		{
			if(window.document.frmRbiReport.radOutype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise OutWord Clearing Report As On Date  "+ window.document.frmRbiReport.cmbLogOper.value + " "+window.document.frmRbiReport.txtFmDat.value
			}
			if(window.document.frmRbiReport.radOutype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise OutWord Clearing Report As On Date "+ window.document.frmRbiReport.cmbLogOper.value + " "+window.document.frmRbiReport.txtFmDat.value
			}
			if(window.document.frmRbiReport.radOutype(2).checked==true)
			{
				strheadsub = stConsol+"Instrument Wise OutWord Clearing Report As On Date "+ window.document.frmRbiReport.cmbLogOper.value + " "+window.document.frmRbiReport.txtFmDat.value
			}
		}
		else
		{
			if(window.document.frmRbiReport.radOutype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise OutWord Clearing Report As On Date  Between "+ window.document.frmRbiReport.txtFmDat.value + " to "+window.document.frmRbiReport.txtToDat.value
			}
			if(window.document.frmRbiReport.radOutype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise OutWord Clearing Report As On Date Between "+ window.document.frmRbiReport.txtFmDat.value + " to "+window.document.frmRbiReport.txtToDat.value
			}
			if(window.document.frmRbiReport.radOutype(2).checked==true)
			{
				strheadsub = stConsol+"Instrument Wise OutWord Clearing Report As On Date Between "+ window.document.frmRbiReport.txtFmDat.value + " to "+window.document.frmRbiReport.txtToDat.value
			}
		}
	}
	
	if(window.document.all.divInwRep.style.display=="block")
	{
		strheadtype = "InWord Clearing REPORT"
		
		if(window.document.frmRbiReport.radInwBrid(1).checked==true)
		{
			stConsol = "Consolidate "
		}
		else
		{
			stConsol = ""
		}
		
		if(window.document.frmRbiReport.cmbInwdOper.value!="Between")
		{
			if(window.document.frmRbiReport.radInwtype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise InWord Clearing Report As On Date  "+ window.document.frmRbiReport.cmbInwdOper.value + " "+window.document.frmRbiReport.txtInwFmDat.value
			}
			if(window.document.frmRbiReport.radInwtype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise InWord Clearing Report As On Date "+ window.document.frmRbiReport.cmbInwdOper.value + " "+window.document.frmRbiReport.txtInwFmDat.value
			}
			if(window.document.frmRbiReport.radInwtype(2).checked==true)
			{
				strheadsub = stConsol+"Instrument Wise InWord Clearing Report As On Date "+ window.document.frmRbiReport.cmbInwdOper.value + " "+window.document.frmRbiReport.txtInwFmDat.value
			}
		}
		else
		{
			if(window.document.frmRbiReport.radInwtype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise InWord Clearing Report As On Date  Between "+ window.document.frmRbiReport.txtInwFmDat.value + " to "+window.document.frmRbiReport.txtInwToDat.value
			}
			if(window.document.frmRbiReport.radInwtype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise InWord Clearing Report As On Date Between "+ window.document.frmRbiReport.txtInwFmDat.value + " to "+window.document.frmRbiReport.txtInwToDat.value
			}
			if(window.document.frmRbiReport.radInwtype(2).checked==true)
			{
				strheadsub = stConsol+"Instrument Wise InWord Clearing Report As On Date Between "+ window.document.frmRbiReport.txtInwFmDat.value + " to "+window.document.frmRbiReport.txtInwToDat.value
			}
		}
	}
	
	if(window.document.all.divLastran.style.display=="block")
	{
		strheadtype = "LAST TRANSACTION REPORT"
		strheadsub = "Last Transaction Report For Module : "+ window.document.frmRbiReport.txtModId.value.toUpperCase() + " As On Date "+window.document.frmRbiReport.txtLastFmDat.value
	}
	
	if(window.document.all.divKycdtls.style.display=="block")
	{
		strheadtype = "KYC DETAILS REPORT"
		
		if(window.document.frmRbiReport.radKycSub(0).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				strheadsub = "Account Wise KYC Submited  Detailed Report For Branch : "+ window.document.frmRbiReport.txtBrcode.value
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				strheadsub = "Customer Id Wise KYC Submited  Detailed Report For Branch : "+ window.document.frmRbiReport.txtBrcode.value
			}
		}
		if(window.document.frmRbiReport.radKycSub(1).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				strheadsub = "Account Wise KYC Non Submited  Detailed Report For Branch : "+ window.document.frmRbiReport.txtBrcode.value
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				strheadsub = "Customer Id Wise KYC Non Submited  Detailed Report For Branch : "+ window.document.frmRbiReport.txtBrcode.value
			}
		}
		
	}
	
	if(window.document.all.divAadharlnk.style.display=="block")
	{
		strheadtype = "AADHAR LINK REPORT"
		
		if(window.document.frmRbiReport.chkConsol.checked==true)
		{
			strheadsub = "Consolidate Aadhar Link Report As On Date : "+ window.document.frmRbiReport.txtAaDat.value
		}
		else
		{
			strheadsub = "Aadhar Link Report As On Date : "+ window.document.frmRbiReport.txtAaDat.value
		}
	}
	
		StrHead= strheadsub + ",60,80"
		window.document.frmRbiReport.reptitle.value=strheadtype
	
	if(window.document.all.divOwRep.style.display=="block")
	{
		
		if(window.document.frmRbiReport.radOutype(2).checked==true)
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,1)+",7,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,2)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,3)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,4)+",8,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,5)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,6)+",6,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,7)+",35,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,8)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,9)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,10)+",35,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,11)+",35,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,12)+",35,L"+"|"
		}
		else
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,1)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,2)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,3)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,4)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,5)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,6)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgOutRep.TextMatrix(0,7)+",16,R"+"|"
		}
	}
	
	if (window.document.all.divInwRep.style.display=="block")
	{
		
		if(window.document.frmRbiReport.radInwtype(2).checked==true)
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,1)+",7,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,2)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,3)+",8,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,4)+",17,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,5)+",35,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,6)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,7)+",8,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,8)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,9)+",35,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,10)+",35,L"+"|"

		}
		else
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,1)+",13,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,2)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,3)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,4)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,5)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,6)+",10,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgInwRep.TextMatrix(0,7)+",16,R"+"|"
		}
	}
	
	if(window.document.all.divLastran.style.display=="block")
	{
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,0)+",6,L"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,1)+",8,L"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,2)+",17,L"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,3)+",25,L"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,4)+",16,R"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,5)+",14,C"+"~"
		StrCol=StrCol+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(0,6)+",16,R"+"|"
	}
	
	if(window.document.all.divKycdtls.style.display=="block")
	{
		if(window.document.frmRbiReport.radKycSub(0).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,0)+",6,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,1)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,2)+",8,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,3)+",17,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,4)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,5)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,6)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,7)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,8)+",6,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,9)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,10)+",10,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,11)+",15,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,12)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,13)+",75,L"+"|"
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,0)+",6,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,1)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,2)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,3)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,4)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,5)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,6)+",10,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,7)+",15,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,8)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,9)+",75,L"+"|"
			}
		}
		if(window.document.frmRbiReport.radKycSub(1).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,0)+",6,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,1)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,2)+",8,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,3)+",17,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,4)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,5)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,6)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,7)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,8)+",8,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,9)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,10)+",75,L"+"|"
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,0)+",6,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,1)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,2)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,3)+",13,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,4)+",11,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,5)+",35,L"+"~"
				StrCol=StrCol+window.document.frmRbiReport.mfgKycdtls.TextMatrix(0,6)+",75,L"+"|"
			}
		}
	}
	
	if(window.document.all.divAadharlnk.style.display=="block")
	{
		if(window.document.frmRbiReport.chkConsol.checked==true)
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,1)+",50,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,2)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,3)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,4)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,5)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,6)+",30,L"+"|"
		}
		else
		{
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,1)+",50,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,2)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,3)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,4)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,5)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,6)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgAadlnk.TextMatrix(0,7)+",30,L"+"|"
		}
	}
	
	if(window.document.all.divOwRep.style.display=="block")
	{
		for(icnt=1;icnt<=window.document.frmRbiReport.mfgOutRep.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgOutRep.Cols-1;jcnt++)
			{
				StrCols=StrCols+window.document.frmRbiReport.mfgOutRep.TextMatrix(icnt,jcnt)+"~"
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
		
		var strSum
		
		if(window.document.frmRbiReport.radOutype(2).checked==true)
		{
			strSum="~~~~--------~----------------~~~~~~|"
			strSum=strSum+"~~~~"+"Total :"+"~"+window.document.frmRbiReport.hIstrAmt.value+"~~~~~~"
		}
		else
		{
			strSum="~-------------~----------~----------------~----------~----------------~----------~----------------|"
			strSum=strSum+"~"+"Total :"+"~"+window.document.frmRbiReport.hInsTot.value+"~"+window.document.frmRbiReport.hTotAmt.value+"~"+window.document.frmRbiReport.hClgTot.value+"~"+window.document.frmRbiReport.hClgAmt.value+"~"+window.document.frmRbiReport.hRtnTot.value+"~"+window.document.frmRbiReport.hRtnAmt.value
		}
			StrArr=StrArr+"|"+strSum
	}
	
	if(window.document.all.divInwRep.style.display=="block")
	{
		for(icnt=1;icnt<=window.document.frmRbiReport.mfgInwRep.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgInwRep.Cols-1;jcnt++)
			{
				StrCols=StrCols+window.document.frmRbiReport.mfgInwRep.TextMatrix(icnt,jcnt)+"~"
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
		
		var strSum
		
		if(window.document.frmRbiReport.radInwtype(2).checked==true)
		{
			strSum="~~~~~--------~----------------~~~~|"
			strSum=strSum+"~~~~~"+"Total :"+"~"+window.document.frmRbiReport.hIstrAmt.value+"~~~~"
		}
		else
		{
			strSum="~-------------~----------~----------------~----------~----------------~----------~----------------|"
			strSum=strSum+"~"+"Total :"+"~"+window.document.frmRbiReport.hInsTot.value+"~"+window.document.frmRbiReport.hTotAmt.value+"~"+window.document.frmRbiReport.hClgTot.value+"~"+window.document.frmRbiReport.hClgAmt.value+"~"+window.document.frmRbiReport.hRtnTot.value+"~"+window.document.frmRbiReport.hRtnAmt.value
		}
			StrArr=StrArr+"|"+strSum
	}
	
	if(window.document.all.divLastran.style.display=="block")
	{
		for(icnt=1;icnt<=window.document.frmRbiReport.mfgLstrnRep.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgLstrnRep.Cols-1;jcnt++)
			{
				if(jcnt==2)
				{
					if(strrep == "HTML")
					{
						StrCols=StrCols+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(icnt,jcnt)+"~"
					}
					else
					{
						StrCols=StrCols+"'"+ window.document.frmRbiReport.mfgLstrnRep.TextMatrix(icnt,jcnt)+"~"
					}
				}
				else
				{
					StrCols=StrCols+window.document.frmRbiReport.mfgLstrnRep.TextMatrix(icnt,jcnt)+"~"
				}
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
	}
	
	if(window.document.all.divKycdtls.style.display=="block")
	{
		if(window.document.frmRbiReport.radKycSub(0).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				for(icnt=1;icnt<=window.document.frmRbiReport.mfgKycdtls.rows-1;icnt++)
				{
					StrCols=""
					for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgKycdtls.Cols-1;jcnt++)
					{
						if((jcnt==1) || (jcnt==3) || (jcnt==12))
						{
							if(strrep == "HTML")
							{
								StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
							else
							{
								StrCols=StrCols+"'"+ window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
						}
						else
						{
							StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
						}
					}
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"|"
				}
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				for(icnt=1;icnt<=window.document.frmRbiReport.mfgKycdtls.rows-1;icnt++)
				{
					StrCols=""
					for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgKycdtls.Cols-1;jcnt++)
					{
						if((jcnt==1) || (jcnt==8))
						{
							if(strrep == "HTML")
							{
								StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
							else
							{
								StrCols=StrCols+"'"+ window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
						}
						else
						{
							StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
						}
					}
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"|"
				}
			}
		}
		if(window.document.frmRbiReport.radKycSub(1).checked==true)
		{
			if(window.document.frmRbiReport.radKycust(0).checked==true)
			{
				for(icnt=1;icnt<=window.document.frmRbiReport.mfgKycdtls.rows-1;icnt++)
				{
					StrCols=""
					for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgKycdtls.Cols-1;jcnt++)
					{
						if((jcnt==1) || (jcnt==3))
						{
							if(strrep == "HTML")
							{
								StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
							else
							{
								StrCols=StrCols+"'"+ window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
						}
						else
						{
							StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
						}
					}
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"|"
				}
			}
			if(window.document.frmRbiReport.radKycust(1).checked==true)
			{
				for(icnt=1;icnt<=window.document.frmRbiReport.mfgKycdtls.rows-1;icnt++)
				{
					StrCols=""
					for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgKycdtls.Cols-1;jcnt++)
					{
						if(jcnt==1)
						{
							if(strrep == "HTML")
							{
								StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
							else
							{
								StrCols=StrCols+"'"+ window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
							}
						}
						else
						{
							StrCols=StrCols+window.document.frmRbiReport.mfgKycdtls.TextMatrix(icnt,jcnt)+"~"
						}
					}
					StrCols=StrCols.substr(0,StrCols.length-1)
					StrColRow=StrColRow+StrCols+"|"
				}
			}
		}
		
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol
	}
	
	if(window.document.all.divAadharlnk.style.display=="block")
	{
		for(icnt=1;icnt<=window.document.frmRbiReport.mfgAadlnk.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgAadlnk.Cols-1;jcnt++)
			{
				StrCols=StrCols+window.document.frmRbiReport.mfgAadlnk.TextMatrix(icnt,jcnt)+"~"
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
	}
	
	// start nach details
if(window.document.all.divNachDtls.style.display=="block")
	{
		strheadtype = "NACH Details REPORT"
		
		if(window.document.frmRbiReport.radNACHDtlsBrid(1).checked==true)
		{
			stConsol = "Consolidate "
		}
		else
		{
			stConsol = ""
		}
		
		if(window.document.frmRbiReport.cmbNachDtlsOper.value!="Between")
		{
			if(window.document.frmRbiReport.radNachDtlstype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise NACH Details Report As On Date  "+ window.document.frmRbiReport.cmbNachDtlsOper.value + " "+window.document.frmRbiReport.txtNachDtlsFmDat.value
			}
			if(window.document.frmRbiReport.radNachDtlstype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise NACH Details Report As On Date "+ window.document.frmRbiReport.cmbNachDtlsOper.value + " "+window.document.frmRbiReport.txtNachDtlsFmDat.value
			}
					}
		else
		{
			if(window.document.frmRbiReport.radNachDtlstype(0).checked==true)
			{
				strheadsub = stConsol+"Month Wise NACH Details Report As On Date  Between "+ window.document.frmRbiReport.txtNachDtlsFmDat.value + " to "+window.document.frmRbiReport.txtNachDtlsToDat.value
			}
			if(window.document.frmRbiReport.radNachDtlstype(1).checked==true)
			{
				strheadsub = stConsol+"Day Wise NACH Details Report As On Date Between "+ window.document.frmRbiReport.txtNachDtlsFmDat.value + " to "+window.document.frmRbiReport.txtNachDtlsToDat.value
			}
			
		}
		StrHead= strheadsub + ",60,80"
		window.document.frmRbiReport.reptitle.value=strheadtype
		
		StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,0)+",6,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,1)+",12,L"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,2)+",13,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,3)+",16,R"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,4)+",13,C"+"~"
			StrCol=StrCol+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(0,5)+",16,R"+"|"
			
			for(icnt=1;icnt<=window.document.frmRbiReport.mfgNachDtlsRep.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmRbiReport.mfgNachDtlsRep.Cols-1;jcnt++)
			{
				StrCols=StrCols+window.document.frmRbiReport.mfgNachDtlsRep.TextMatrix(icnt,jcnt)+"~"
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
		
		
			
	}
	
// end nach details	
	

	if(window.document.all.divSusTranRep.style.display=="block")
	{
strheadtype = "No Suspicious Transactions Found"

if(window.document.frmRbiReport.cmbstrOper.value!="Between")
		{
				strheadsub = "Suspicious Transaction Report As On Date  "+ window.document.frmRbiReport.cmbstrOper.value + " "+window.document.frmRbiReport.txtstrFmDat.value
		}
		else
		{
				strheadsub = "Suspicious Transaction Report As On Date  Between "+ window.document.frmRbiReport.txtstrFmDat.value + " to "+window.document.frmRbiReport.txtstrToDat.value			
		}

StrHead= strheadsub + ",60,80"
		window.document.frmRbiReport.reptitle.value=strheadtype
		StrArr=StrHead+"|"+StrCol	
}
	
	window.document.frmRbiReport.hreport.value=StrArr

	
	if(window.document.all.divSusTranRep.style.display=="block")
	{
		if (strrep == "HTML") 
		{
			window.document.frmRbiReport.action="../ReportGridTemplate_str.aspx?strng="+"/Admin/frmRbiReport"
		}
		else
		{
			window.document.frmRbiReport.action="../ReportGridTemplate_strXL.aspx?strng="+"/Admin/frmRbiReport"
		}
	}
	else
	{
		if (strrep == "HTML") 
		{
			window.document.frmRbiReport.action="../ReportGridTemplate.aspx?strng="+"/Admin/frmRbiReport"
		}
		else
		{
			window.document.frmRbiReport.action="../ReportGridTemplateXL.aspx?strng="+"/Admin/frmRbiReport"
		}
	}
	
	window.document.frmRbiReport.method="post"
	window.document.frmRbiReport.submit()
	
}

</script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
			
			if (window.document.all.divInwRep.style.display=="block")
			{
				var intINDiff1=getDateDiff(window.document.frmRbiReport.txtInwFmDat.value, "<%=session("applicationdate")%>")
				
				if(intINDiff1>0)
				{
					alert("From Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtInwFmDat.value=""
					window.document.frmRbiReport.txtInwFmDat.focus()
				}
				
				var intINDiff3=getDateDiff(window.document.frmRbiReport.txtInwToDat.value,"<%=session("applicationdate")%>")
				
				if(intINDiff3>0)
				{
					alert("To Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtInwToDat.value=""
					window.document.frmRbiReport.txtInwToDat.focus()
				}
				
				var intINDiff2=getDateDiff(window.document.frmRbiReport.txtInwToDat.value,window.document.frmRbiReport.txtInwFmDat.value)
				
				if(intINDiff2<0)
				{
					if(window.document.frmRbiReport.txtInwFmDat.value=="")
					{
						alert("From Date Should Not be Null")
						window.document.frmRbiReport.txtInwFmDat.focus()
					}
					
					alert("To Date Should Not be Less Than From Date.")
					window.document.frmRbiReport.txtInwToDat.value=""
					window.document.frmRbiReport.txtInwToDat.focus()
				}
			}
			
			if(window.document.all.divOwRep.style.display=="block")
			{		
				var intDiff1=getDateDiff(window.document.frmRbiReport.txtFmDat.value, "<%=session("applicationdate")%>")
				
				if(intDiff1>0)
				{
					alert("From Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtFmDat.value=""
					window.document.frmRbiReport.txtFmDat.focus()
				}
				
				var intDiff3=getDateDiff(window.document.frmRbiReport.txtToDat.value,"<%=session("applicationdate")%>")
				
				if(intDiff3>0)
				{
					alert("To Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtToDat.value=""
					window.document.frmRbiReport.txtToDat.focus()
				}
				
				var intDiff2=getDateDiff(window.document.frmRbiReport.txtToDat.value,window.document.frmRbiReport.txtFmDat.value)
				
				if(intDiff2<0)
				{
					if(window.document.frmRbiReport.txtFmDat.value=="")
					{
						alert("From Date Should Not be Null")
						window.document.frmRbiReport.txtFmDat.focus()
					}
					
					alert("To Date Should Not be Less Than From Date.")
					window.document.frmRbiReport.txtToDat.value=""
					window.document.frmRbiReport.txtToDat.focus()
				}
			}
			
			if(window.document.all.divLastran.style.display=="block")
			{
				var intLastDiff1=getDateDiff(window.document.frmRbiReport.txtLastFmDat.value, "<%=session("applicationdate")%>")
				
				if(intLastDiff1>0)
				{
					alert("Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtLastFmDat.value=""
					window.document.frmRbiReport.txtLastFmDat.focus()
				}
			}
			
			if(window.document.all.divAadharlnk.style.display=="block")
			{	
				var intAaDiff1=getDateDiff(window.document.frmRbiReport.txtAaDat.value, "<%=session("applicationdate")%>")
				
				if(intAaDiff1>0)
				{
					alert("Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtAaDat.value=""
					window.document.frmRbiReport.txtAaDat.focus()
				}
			}
			
			if (window.document.all.divNachDtls.style.display=="block")
			{
				var intINDiff1=getDateDiff(window.document.frmRbiReport.txtNachDtlsFmDat.value, "<%=session("applicationdate")%>")
				
				if(intINDiff1>0)
				{
					alert("From Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtNachDtlsFmDat.value=""
					window.document.frmRbiReport.txtNachDtlsFmDat.focus()
				}
				
				var intINDiff3=getDateDiff(window.document.frmRbiReport.txtNachDtlsToDat.value,"<%=session("applicationdate")%>")
				
				if(intINDiff3>0)
				{
					alert("To Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtNachDtlsToDat.value=""
					window.document.frmRbiReport.txtNachDtlsToDat.focus()
				}
				
				var intINDiff2=getDateDiff(window.document.frmRbiReport.txtNachDtlsToDat.value,window.document.frmRbiReport.txtNachDtlsFmDat.value)
				
				if(intINDiff2<0)
				{
					if(window.document.frmRbiReport.txtNachDtlsFmDat.value=="")
					{
						alert("From Date Should Not be Null")
						window.document.frmRbiReport.txtNachDtlsFmDat.focus()
					}
					
					alert("To Date Should Not be Less Than From Date.")
					window.document.frmRbiReport.txtNachDtlsToDat.value=""
					window.document.frmRbiReport.txtNachDtlsToDat.focus()
				}
			}
			
			if (window.document.all.divSusTranRep.style.display=="block")
			{
				var intINDiff1=getDateDiff(window.document.frmRbiReport.txtstrFmDat.value, "<%=session("applicationdate")%>")
				
				if(intINDiff1>0)
				{
					alert("From Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtstrFmDat.value=""
					window.document.frmRbiReport.txtstrFmDat.focus()
				}
				
				var intINDiff3=getDateDiff(window.document.frmRbiReport.txtstrToDat.value,"<%=session("applicationdate")%>")
				
				if(intINDiff3>0)
				{
					alert("To Date Should Not be Greater Than Application Date.")
					window.document.frmRbiReport.txtstrToDat.value=""
					window.document.frmRbiReport.txtstrToDat.focus()
				}
				
				var intINDiff2=getDateDiff(window.document.frmRbiReport.txtstrToDat.value,window.document.frmRbiReport.txtstrFmDat.value)
				
				if(intINDiff2<0)
				{
					if(window.document.frmRbiReport.txtstrFmDat.value=="")
					{
						alert("From Date Should Not be Null")
						window.document.frmRbiReport.txtstrFmDat.focus()
					}
					
					alert("To Date Should Not be Less Than From Date.")
					window.document.frmRbiReport.txtstrToDat.value=""
					window.document.frmRbiReport.txtstrToDat.focus()
				}
			}
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	// start NACH Dtls
		function initialcheck()
		{
		
			window.document.frmRbiReport.txtNachDtlsFmDat.value = "<%=session("applicationdate")%>"
			window.document.frmRbiReport.txtNachDtlsToDat.value = "<%=session("applicationdate")%>"
			
			window.document.frmRbiReport.txtstrFmDat.value = "<%=session("applicationdate")%>"
			window.document.frmRbiReport.txtstrToDat.value = "<%=session("applicationdate")%>"
		}
		
		
		function NachDtlsDisp()
		{
			if(window.document.frmRbiReport.cmbNachDtlsOper.value!="Between")
			{
				window.document.frmRbiReport.txtNachDtlsToDat.disabled=true
			}
			else
			{
				window.document.frmRbiReport.txtNachDtlsToDat.disabled=false
			}
		}
		
		function NACHDtlsQuery()
		{

	var stDtcnd,stBr,stSeltyp
	window.document.frmRbiReport.mfgNachDtlsRep.Rows=1
	
	if(window.document.frmRbiReport.cmbNachDtlsOper.value!="Between")
	{
		if(window.document.frmRbiReport.txtNachDtlsFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtNachDtlsFmDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE "+window.document.frmRbiReport.cmbNachDtlsOper.value+" '"+window.document.frmRbiReport.txtNachDtlsFmDat.value+"'"
		
	}
	else
	{
		if(window.document.frmRbiReport.txtNachDtlsFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtNachDtlsFmDat.focus()
			return;	
		}
		if(window.document.frmRbiReport.txtNachDtlsToDat.value=="")
		{
			alert("Please Enter To Date")
			window.document.frmRbiReport.txtNachDtlsToDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE BETWEEN '"+window.document.frmRbiReport.txtNachDtlsFmDat.value+"' AND '"+window.document.frmRbiReport.txtNachDtlsToDat.value+"'"
		
	}
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	if(window.document.frmRbiReport.radNACHDtlsBrid(0).checked==true)
	{
		stBr = " AND substr(BENEACCNUM,1,3) = '"+window.document.frmRbiReport.txtBrcode.value+"'"
		
	}
	if(window.document.frmRbiReport.radNACHDtlsBrid(1).checked==true)
	{
		stBr = " "
	}
	
	if(window.document.frmRbiReport.radNachDtlstype(0).checked==true)
	{
		stSeltyp = "MONTH"
	}
	if(window.document.frmRbiReport.radNachDtlstype(1).checked==true)
	{
		stSeltyp = "DAY"
	}
	
	strVal = "NACHDTLS"+"|"+stSeltyp+"|"+stDtcnd+"|"+stBr +"|"+ window.document.frmRbiReport.cmbNACHType.value
	//alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;

}


function popNACHDTLS(str)
{

	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
		
	window.document.frmRbiReport.mfgNachDtlsRep.Rows=1
	
	var stSal = str.split("|")
	
	
		window.document.frmRbiReport.mfgNachDtlsRep.cols=6;
		window.document.frmRbiReport.mfgNachDtlsRep.formatstring="<SLNO   |<Date                 |<Noof Success Accs           |>Total Success Amount       |<NoOf Return Accs    |>Total Return Amount       ";
	
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgNachDtlsRep.rows=window.document.frmRbiReport.mfgNachDtlsRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,0)=aCnt+1 
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,1)=strCols[0]
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,2)=strCols[1]
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,4)=strCols[3]
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,5)=strCols[4]
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,3)),2)
				
				window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmRbiReport.mfgNachDtlsRep.textmatrix(aCnt+1,5)),2)
				
			}
		}
}

		
	// end NACH Dtls
	
	// suspicious transaction report
			function strDisp()
		{
			if(window.document.frmRbiReport.cmbstrOper.value!="Between")
			{
				window.document.frmRbiReport.txtstrToDat.disabled=true
			}
			else
			{
				window.document.frmRbiReport.txtstrToDat.disabled=false
			}
		}	
		
		function strdtlsQuery()
		{

	var stDtcnd,stBr,stSeltyp
	window.document.frmRbiReport.mfgstrdtlsRep.Rows=1
	
	if(window.document.frmRbiReport.cmbstrOper.value!="Between")
	{
		if(window.document.frmRbiReport.txtstrFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtstrFmDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE "+window.document.frmRbiReport.cmbstrOper.value+" '"+window.document.frmRbiReport.txtstrFmDat.value+"'"
		
	}
	else
	{
		if(window.document.frmRbiReport.txtstrFmDat.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtstrFmDat.focus()
			return;	
		}
		if(window.document.frmRbiReport.txtstrToDat.value=="")
		{
			alert("Please Enter To Date")
			window.document.frmRbiReport.txtstrToDat.focus()
			return;	
		}
		
		stDtcnd = " APPLICATIONDATE BETWEEN '"+window.document.frmRbiReport.txtstrFmDat.value+"' AND '"+window.document.frmRbiReport.txtstrToDat.value+"'"
		
	}
	
	
	if(window.document.frmRbiReport.cmbstraccbaloper.value!="Between")
	{
		if(window.document.frmRbiReport.txtstrAccBalAmt.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtstrAccBalAmt.focus()
			return;	
		}
		
		stDtcndAmt = " amount "+window.document.frmRbiReport.cmbstraccbaloper.value+" '"+window.document.frmRbiReport.txtstrAccBalAmt.value+"'"
		
	}
	else
	{
		if(window.document.frmRbiReport.txtstrAccBalAmt.value=="")
		{
			alert("Please Enter From Date")
			window.document.frmRbiReport.txtstrAccBalAmt.focus()
			return;	
		}
		if(window.document.frmRbiReport.txtstrAccToBalAmt.value=="")
		{
			alert("Please Enter To Date")
			window.document.frmRbiReport.txtstrAccToBalAmt.focus()
			return;	
		}
		
		stDtcndAmt = " amount BETWEEN '"+window.document.frmRbiReport.txtstrAccBalAmt.value+"' AND '"+window.document.frmRbiReport.txtstrAccToBalAmt.value+"'"
		
	}
	
	if(window.document.frmRbiReport.txtBrcode.value=="")
	{
		alert("Please Select Branchcode")
		return;
	}
	
	
	
	strVal = "STRDTLS"+"|"+stDtcnd+"|"+stDtcndAmt+"|"+stBr +"|"+ window.document.frmRbiReport.cmbNACHType.value
	//alert(" strVal = "+strVal)
	window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;

}


function popSTRDTLS(str)
{

	if(str=="")
	{
		alert(" No Records Found")
		return;
	}
		
	window.document.frmRbiReport.mfgstrdtlsRep.Rows=1
	
	var stSal = str.split("|")
	
	
		window.document.frmRbiReport.mfgstrdtlsRep.cols=7;
		window.document.frmRbiReport.mfgstrdtlsRep.formatstring="<SLNO    |<BRANCHCODE  |< MODULEID      |< GLCODE         |< ACCNO           |< CUSTOMERID         |< NAME                                      ";
	
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmRbiReport.mfgstrdtlsRep.rows=window.document.frmRbiReport.mfgstrdtlsRep.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,0)=aCnt+1 
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,1)=strCols[0] // branchcode
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,2)=strCols[1] // moduleid
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,3)=strCols[2] // glcode
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,4)=strCols[3] // accno
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,5)=strCols[4] // customerid
				window.document.frmRbiReport.mfgstrdtlsRep.textmatrix(aCnt+1,6)=strCols[5] // name
			}
		}
}


	</script>
<body onload="GetMenu(&quot;<%=session("menustring")%>&quot;);initialcheck();dispMsg();" topmargin="0" leftmargin="0">
    <%=Request.QueryString("record")%>
<form name="frmRbiReport">

    <div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar"><%appdate=formatdatetime(session("applicationdate"),1)%>
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="19%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="43%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rbi Audit Report</h2></td>
					<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div> 
		<div id="menucontrol"></div>
		
  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain">
    <tr>
      <td width="100%">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="1">
        <tr>
          <td width="100%" height="29">

          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="12%" align="left">
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</p>
                </td>
                <td width="38%"><input name="txtBrcode" size="9" readonly value="<%=session("branchcode")%>" class="txtautofill"><input type="button" value=" L " name="cmdbranch" onclick="Branch()" class="button"><input name="txtBrdesc" size="16" readonly value="<%=session("branchnarration")%>" class="bgcolor1">&nbsp;</td>
                
                <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency Code</td>
                <td width="35%"><input name="txtCrcode" size="9" value="<%=session("Currencycode")%>" readonly id="txtCrcode" maxlength="5" onblur="Dataarrange(txtCrcode)" class="txtautofill"><input type="button" value=" L "  class="button" name="butCurrency" onclick="Currency()" id="butCurrency"><input name="txtCrdesc" size="16" value="<%=session("Currencynarration")%>" readonly id="txtCrdesc" class="bgcolor1"></td>
              </tr>
            </table>

            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
              <!--- Left Part Start ---->
                <td width="16%" valign="top">
					<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">OutWord Clearing</font></a></td>
						</tr>
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">InWord Clearing</font></a></td>
						</tr>
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">Last Transaction Details</font></a></td>
						</tr>
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('3')">&nbsp;<font class="textbold">KYC Details</font></a></td>
						</tr>
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('4')">&nbsp;<font class="textbold">Aadhar Lnk</font></a></td>
						</tr>
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('5')">&nbsp;<font class="textbold">NACH Details</font></a></td>
						</tr>
							<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('6')">&nbsp;<font class="textbold">Suspicious Transaction Report</font></a></td>
						</tr>
					</table>
				</td>
				<!--- Left Part End ---->
				<!--- Right Part Start ---->
                <td width="84%" valign="top">
					<!-- Outword Clearing start -->                
					<div id="divOwRep" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="OutWord Clearing Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3" ><input type="radio" name="radBrsid" id="radBrsid" checked onclick="selWise()"> Branch Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radBrsid" id="radBrsid" onclick="selWise()"> Consolidate </font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3"><input type="radio" name="radOutype" id="radOutype" checked onclick="selType()"> Month Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radOutype" id="radOutype" onclick="selType()"> Day Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radOutype" id="radOutype" onclick="selType()"> Instrument Wise</font></td>
							</tr>
							<tr>
								<td width="100%" align="center">
									<table>
										<tr>
											<td width="20%" align="center">&nbsp;Operator&nbsp;
												<select size="1" name="cmbLogOper" onchange="toLogDisp()">
												<option value="=">=</option>
												<option value="&gt;">&gt;</option>
												<option value="&lt;">&lt;</option>
												<option value="Between">Between</option>
												</select>
											</td>
											<td width="40%">From Date&nbsp;&nbsp;<input type="text" name="txtFmDat" id=txtFmDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
											<td width="40%"> To Date&nbsp;&nbsp;<input type="text" name="txtToDat" id=txtToDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="center"><input type="button" id="butQuery" name="butQuery" value=" Query " onclick="OtwordQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgOutRep name=mfgOutRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
						
					</div>
					<!-- Outword Clearing End -->
					<!-- Inword Clearing Start -->
					<div id="divInwRep" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="InWord Clearing Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3" ><input type="radio" name="radInwBrid" id="radInwBrid" checked onclick="selInWise()"> Branch Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radInwBrid" id="radInwBrid" onclick="selInWise()"> Consolidate </font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3"><input type="radio" name="radInwtype" id="radInwtype" checked onclick="selInwType()"> Month Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radInwtype" id="radInwtype" onclick="selInwType()"> Day Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radInwtype" id="radInwtype" onclick="selInwType()"> Instrument Wise</font></td>
							</tr>
							<tr>
								<td width="100%" align="center">
									<table>
										<tr>
											<td width="20%" align="center">&nbsp;Operator&nbsp;
												<select size="1" name="cmbInwdOper" onchange="toLogDisp()">
												<option value="=">=</option>
												<option value="&gt;">&gt;</option>
												<option value="&lt;">&lt;</option>
												<option value="Between">Between</option>
												</select>
											</td>
											<td width="40%">From Date&nbsp;&nbsp;<input type="text" name="txtInwFmDat" id=txtInwFmDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
											<td width="40%"> To Date&nbsp;&nbsp;<input type="text" name="txtInwToDat" id=txtInwToDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="center"><input type="button" id="butInQuery" name="butInQuery" value=" Query " onclick="InwordQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgInwRep name=mfgInwRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
						
					</div>
					<!-- Inword Clearing End -->
					<!-- Last Transaction details start ---->
					<div id="divLastran" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Last Transaction Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%">
									<table>
										<tr>
											<td width="12%">&nbsp;&nbsp;&nbsp;Module ID</td>
											<td width="38%"><input name="txtModId" size="15" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" readonly maxlength="6" class="txtautofill" value="" onblur="Dataarrange(txtModId);DescrptionDisp(&quot;txtModId&quot;)"><input type="button" value=" L " name="B1" onclick="module()" class="button"><input name="txtModNm" class="bgcolor1" size="19" value="" readonly></td>
											<td width="15%"><p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date</p></td>
											<td width="35%"><input type="text" name="txtLastFmDat" id=txtLastFmDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="butLastQuery" name="butLastQuery" value=" Query " onclick="LstTrnQuery()" class="button"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgLstrnRep name=mfgLstrnRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
					</div>
					<!-- Last Transaction details End ---->
					<!-- Non KYC Details Start ---->
					<div id="divKycdtls" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="KYC Details" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center">
									<table border="0" width="50%" cellspacing="0" cellpadding="0" class="tableborder2">
										<tr>
											<td width="100%" height="15" align="center"><font color="#000000" size="3" ><input type="radio" name="radKycSub" id="radKycSub" checked onclick="selKycsub()"> Submited &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radKycSub" id="radKycSub" onclick="selKycsub()"> Non Submited </font></td>
										</tr>
									</table>
								</td>
							<tr>
								<td width="100%" height="15" align="center">
									<table border="0" width="50%" cellspacing="0" cellpadding="0" class="tableborder2">
										<tr>
											<td width="100%" height="15" align="center"><font color="#000000" size="3"><input type="radio" name="radKycust" id="radKycust" checked onclick="selKyCust()"> Account Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radKycust" id="radKycust" onclick="selKyCust()"> Customer Id Wise </font></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="center"><input type="button" id="butKycQuery" name="butKycQuery" value=" Query " onclick="KycQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgKycdtls name=mfgKycdtls style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
							
						</table>
					</div>
					<!-- Non KYC Details End ---->
					<!-- Aadhar Lnk Details Start ---->
					<div id="divAadharlnk" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Aadhar Link" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%" align="center"> Date&nbsp;&nbsp;<input type="text" name="txtAaDat" id=txtAaDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)&nbsp;<input type="checkbox" id="chkConsol" name="chkConsol" onclick="window.document.frmRbiReport.mfgAadlnk.Rows=1 ">&nbsp;Consolidate</td>
							</tr>
							<tr>
								<td width="100%" align="center"><input type="button" id="butAadQuery" name="butAadQuery" value=" Query " onclick="AadharQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgAadlnk name=mfgAadlnk style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
							
						</table>
					</div>
					<!-- Aadhar Lnk Details End ---->
					<!-- NACH Details Start -->
					<div id="divNachDtls" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblNachDtlsothers" value="NACH Details" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3" ><input type="radio" name="radNACHDtlsBrid" id="radNACHDtlsBrid" checked onclick="selNachDtlsWise()"> Branch Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radNACHDtlsBrid" id="radNACHDtlsBrid" onclick="selNachDtlsWise()"> Consolidate </font></td>
							</tr>
							<tr>
								<td width="100%" height="15" align="center"><font color="#000000" size="3"><input type="radio" name="radNachDtlstype" id="radNachDtlstype" checked onclick="selNachDtlsType()"> Month Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radNachDtlstype" id="radNachDtlstype" onclick="selNachDtlsType()"> Day Wise &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
							</tr>
							<tr>
						<td width="100%" align="center">
						<table >
						<tr class="bgcolor1">
                      
                    <td width="20%" align="middle"> 
&nbsp;Type
								<select size="1" name="cmbNACHType" onchange ="NACHClear()" >
									<option value=""></option>
									<option value="NACHDRIN">NACHDRIN</option>
									<option value="NACHDROUT">NACHDROUT</option>
									<option value="NACHCRIN">NACHCRIN</option>
																	
								</select>
					</td> 
                    </tr>
                    </table>
						</td>
						</tr>
						
							<tr>
								<td width="100%" align="center">
									<table>
										<tr>
											<td width="20%" align="center">&nbsp;Operator&nbsp;
												<select size="1" name="cmbNachDtlsOper" onchange="NachDtlsDisp()">
												<option value="=">=</option>
												<option value="&gt;">&gt;</option>
												<option value="&lt;">&lt;</option>
												<option value="Between">Between</option>
												</select>
											</td>
											<td width="40%">From Date&nbsp;&nbsp;<input type="text" name="txtNachDtlsFmDat" id=txtNachDtlsFmDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
											<td width="40%"> To Date&nbsp;&nbsp;<input type="text" name="txtNachDtlsToDat" id=txtNachDtlsToDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="center"><input type="button" id="butNachDtlsQuery" name="butNachDtlsQuery" value=" Query " onclick="NACHDtlsQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgNachDtlsRep name=mfgNachDtlsRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 750px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
						</table>
						
					</div>
					<!-- NACH Details End -->		
					<!-- suspicious transaction report Start -->
					<div id="divSusTranRep" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" height="15"><font color="#000000" size="3" class="textbold"><input name="lblstr" value="Suspicious Transaction Report " class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							
						
						
							<tr>
								<td width="100%" >
									<table border="0" width="100%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="20%" align="center">&nbsp;Operator&nbsp;
												<select size="1" name="cmbstrOper" onchange="strDisp()">
												<option value="=">=</option>
												<option value="&gt;">&gt;</option>
												<option value="&lt;">&lt;</option>
												<option value="Between">Between</option>
												</select>
											</td>
											<td width="40%">From Date&nbsp;&nbsp;<input type="text" name="txtstrFmDat" id=txtstrFmDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
											<td width="40%"> To Date&nbsp;&nbsp;<input type="text" name="txtstrToDat" id=txtstrToDat maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">(DDMMYYYY)</td>
										</tr>
									</table>
								</td>
							</tr>
<tr>
                      <td width="100%">
                                     
                              <table border="0" width="100%" cellspacing="0" cellpadding="0">                              
                                <tr>
                                  <td width="20%" align="center">&nbsp;Operator
                                  <select size="1" name="cmbstraccbaloper" onchange="toDateDisp()">
                                    <option value="=">=</option>
                                    <option value="&gt;">&gt;</option>
                                    <option value="&lt;">&lt;</option>
                                    <option value="Between">Between</option>
                                  </select></td>
                                  <td width="40%" >From Amt&nbsp;&nbsp;
                                 <input type="text" name="txtstrAccBalAmt" size="11" maxlength="16" 
                                  onkeypress="numdecminus(window.document.frmRbiReport.txtstrAccBalAmt.value,window.document.frmRbiReport.hpr.value)" 
                                  onblur="numbercheck(window.document.frmRbiReport.txtstrAccBalAmt);precision(window.document.frmRbiReport.txtstrAccBalAmt,
									window.document.frmRbiReport.hpr.value);" class="txtautofill"></td>
                                  <td width="40%" >To Amt&nbsp;&nbsp;<input type="text" name="txtstrAccToBalAmt"  size="11" maxlength="16" 
                                  onkeypress="numdecminus(window.document.frmRbiReport.txtstrAccToBalAmt.value,
                                  window.document.frmRbiReport.hpr.value)" 
                                  onblur="numbercheck(window.document.frmRbiReport.txtstrAccToBalAmt);precision(window.document.frmRbiReport.txtstrAccToBalAmt,
									window.document.frmRbiReport.hpr.value);tostrAccAmtCheck()" class="txtautofill"></td>
                                </tr>
                              </table>
                         
                     </td>
                    </tr>

 <td width="100%">
<tr>
								<td width="100%" align="center"><input type="button" id="butstrdtlsQuery" name="butstrdtlsQuery" value=" Query " onclick="strdtlsQuery()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center">&nbsp;</td>
							</tr>
							<tr>
								<td width="100%" align="center">
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=300 id=mfgstrdtlsRep name=mfgstrdtlsRep style="HEIGHT: 300px; LEFT: 0px; TOP: 0px; WIDTH: 1000px" width=1000 VIEWASTEXT>
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
							
  </td>
                    </tr>

						</table>
						
					</div>
					<!-- suspicious transaction report  End -->	
								
				</td>
				
				
				<!--- Right Part End ---->
			</tr>
		</table>
		<tr>
          <td width="100%" height="32" align="center"></td>
        </tr>
        <tr>
          <td width="100%" height="32"><center>

          <table width="10%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 187px" class="tablebordermain">
            <tr>
              <td width="100%"><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input type="reset" value="Cancel" name="cmdCancel" class="button" onclick="location.href=&quot;frmRbiReport.aspx&quot;"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module") & "module.aspx"%>&quot;"></td>
            </tr>
          </table>

			</center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>
  <table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%">
			<iframe id="iGetDtls" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDetails.aspx"></iframe>
			
			<input type="hidden" name="hInsTot" value="0">
			<input type="hidden" name="hTotAmt" value="0">
			<input type="hidden" name="hClgTot" value="0">
			<input type="hidden" name="hClgAmt" value="0">
			<input type="hidden" name="hRtnTot" value="0">
			<input type="hidden" name="hRtnAmt" value="0">
			<input type="hidden" name="hIstrAmt" value="0">
			<input type="hidden" name="reptype">
			<input type="hidden" name="ncnt">
			<input type="hidden" name="reptitle">
			<input type="hidden" name="hreport">
			<input type="hidden" name="hRepInfo">
		</td>
	</tr>
  </table>
  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</form>
</body>
</html>
 