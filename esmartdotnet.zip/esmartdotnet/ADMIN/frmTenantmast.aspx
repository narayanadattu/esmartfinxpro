<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmTenantmast.aspx.vb" Inherits="eSmartDotNet.frmTenantmast" %>
<%
	dim obj,rs
	
	dim impYn,brcod
	
	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	''rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE","CODE='EMPMOD'")
		rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN, BRANCHCODE","CODE='HOTRAW'")
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
		brcod = rs(1).value
	end if
	
	dim objTds,rsTds
	dim Tdsval
	
	Tdsval = "0"
	
	objTds = Server.CreateObject("queryrecordsets.fetchrecordsets")
	rsTds = objTds.SingleRecordSet("GENCONFIGMST","nvl(value1,0) val","CODE='TDSEXE'")
	
	if not rsTds.EOF and not rsTds.BOF then
		Tdsval = rsTds(0).value
	end if

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
 <head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
    <title>frmTenantmast</title>
    <SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT ID="clientEventHandlersJS" LANGUAGE="javascript">
	function datecheck(obj)
	{
		var dt,arrDt
		if(obj.value=="")
			return;

		dt = obj.value
		dt=dt.toUpperCase();
		arrDt = dt.split("-")
		if(eval(arrDt[0].length)!=2)
			arrDt = dt.split("/")

		if(eval(arrDt[0].length)==2)
		{
			switch(arrDt[1])
			{
				case "JAN" :	arrDt[1]= "01";
								break ; 
				case "Jan" :	arrDt[1]= "01";
								break ; 				
				case "FEB" :	arrDt[1]= "02";
								break ;
				case "Feb" :	arrDt[1]= "02";
								break ;				 
				case "MAR" :	arrDt[1]= "03";
								break ; 
				case "Mar" :	arrDt[1]= "03";
								break ; 				
				case "APR" :	arrDt[1]= "04";
								break ; 
				case "Apr" :	arrDt[1]= "04";
								break ; 				
				case "MAY" :	arrDt[1]= "05";
								break ;
				case "May" :	arrDt[1]= "05";
								break ; 				 
				case "JUN" :	arrDt[1]= "06";
								break ; 
				case "Jun" :	arrDt[1]= "06";
								break ;				
				case "JUL" :	arrDt[1]= "07";
								break ; 
				case "Jul" :	arrDt[1]= "07";
								break ; 				
				case "AUG" :	arrDt[1]= "08";
								break ; 
				case "Aug" :	arrDt[1]= "08";
								break ;
				case "SEP" :	arrDt[1]= "09";
								break ; 
				case "Sep" :	arrDt[1]= "09";
								break ; 				
				case "OCT" :	arrDt[1]= "10";
								break ; 
				case "Oct" :	arrDt[1]= "10";
								break ; 				
				case "NOV" :	arrDt[1]= "11";
								break ; 
				case "Nov" :	arrDt[1]= "11";
								break ; 				
				case "DEC" :	arrDt[1]= "12";
								break ; 
				case "Dec" :	arrDt[1]= "12";
								break ; 										
			}
			
			dt = arrDt[0]+arrDt[1]+arrDt[2]
			obj.value = dt
		}
		formatDate(obj)
		
		var intDiff=getDateDiff(window.document.frmTenant.txtNomon.value, "<%=session("applicationdate")%>")
		
		if(intDiff<0)
		{
			alert("Date Should Not Be Less Than Application Date.")
			window.document.frmTenant.txtNomon.value=""
			window.document.frmTenant.txtNomon.focus()
		}
		
			var intDiff1=getDateDiff(window.document.frmTenant.txtRecUpto.value, "<%=session("applicationdate")%>")
		
		if(intDiff1<0)
		{
			alert("Recovery Date Should Not Be Less Than Application Date.")
			window.document.frmTenant.txtRecUpto.value=""
			window.document.frmTenant.txtRecUpto.focus()
		}
		
		/*var intDiff1=getDateDiff(window.document.frmTenant.txtEmParmDate.value, "<%=session("applicationdate")%>")
		
		if(intDiff1>0)
		{
			alert("Date Should Not be Greater Than Application Date.")
			window.document.frmTenant.txtEmParmDate.value=""
			window.document.frmTenant.txtEmParmDate.focus()
		}*/
		
	}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	</script>
	<SCRIPT LANGUAGE="javascript">
	
	var userid = '<%=session("userid")%>'
	var macid = '<%=session("machineid")%>'
	var appdat = '<%=session("applicationdate")%>'
	var stBrcd = "<%=session("branchcode")%>"
		
	function checkImplement()
	{
		var IMP="<%=impYn%>"
		var BCOD="<%=brcod%>"
		
		
		if(IMP=="Y")
		{
			/*if(BCOD == stBrcd)
			{
			
			}
			else
			{
				alert("You are Not Authorised Branch. \n Please Contact Main Branch")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}*/
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
	}
	
	function DispTranMsg()
	{
		var strtran
			strtran='<%=Request.QueryString("record")%>'
		
		if(strtran!="")
		{
			alert(strtran)
			window.location.href="http://"+"<%=session("moduledir")& "/ADMIN/frmTenantmast.aspx"%>"
		}
	}
	
	function ShowDivision(str)
	{
		//for grid values
		window.document.frmTenant.mfgTenant.Rows=1
		
		window.document.all.divTenant.style.display="none"
		window.document.all.divStat.style.display="none" 
		
		if(str=="0")
		{
			window.document.all.divTenant.style.display="block"
			clear2()
		}	
	}
	
	function TenantBranch()
	{
		var branch="TenantBranch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user
		
		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}
	
	function TenantBranchid(kstr)
	{	
		assign(kstr,window.document.frmTenant.txttntBrdesc,window.document.frmTenant.txttntBrcode)
		window.document.frmTenant.txtBrdesc.value=""
		window.document.frmTenant.txtBrcode.value=""
		window.document.frmTenant.txtDedModId.value=""
		window.document.frmTenant.txtDedModNm.value=""
		window.document.frmTenant.txtDedGLcode.value=""
		window.document.frmTenant.txtDedGLname.value=""
		window.document.frmTenant.txtDedAccNo.value=""
		window.document.frmTenant.txtDedAccNm.value=""
		window.document.frmTenant.txtAmount.value = ""
		window.document.frmTenant.txtTdsAmt.value = ""
		window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
		window.document.frmTenant.chkGst.checked = false
	}
	
	function Branch()
	{
		var branch="Branch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user
		
		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}

	function Branchid(kstr)
	{	
		assign(kstr,window.document.frmTenant.txtBrdesc,window.document.frmTenant.txtBrcode)
		
		//window.document.frmTenant.mfgTenant.Rows=1
		window.document.frmTenant.txtDedModId.value=""
		window.document.frmTenant.txtDedModNm.value=""
		window.document.frmTenant.txtDedGLcode.value=""
		window.document.frmTenant.txtDedGLname.value=""
		window.document.frmTenant.txtDedAccNo.value=""
		window.document.frmTenant.txtDedAccNm.value=""
		window.document.frmTenant.txtAmount.value = ""
		window.document.frmTenant.txtTdsAmt.value = ""
		window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
		window.document.frmTenant.chkGst.checked = false
	}
	
	function module()
	{ 
		stmod="sbcaccmodule"; 
		if(window.document.all.divTenant.style.display=="block")
		{
			window.document.frmTenant.txtDedModId.value=""
			window.document.frmTenant.txtDedModNm.value=""
			
			if(window.document.frmTenant.txtBrcode.value=="")
			{
				alert("Please Select Branch Code")
				return;
			}
			else
			{
				stbr = window.document.frmTenant.txtBrcode.value.toUpperCase();
			}
		}
		
		kstr=stmod+"|"+stbr
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
	}
	function modulecode(kstr)
	{
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divTenant.style.display=="block")
		{
			window.document.frmTenant.txtDedModId.value=StrFld[1]
			window.document.frmTenant.txtDedModNm.value=StrFld[0]
			
			//window.document.frmTenant.mfgTenant.Rows=1
			window.document.frmTenant.txtDedGLcode.value=""
			window.document.frmTenant.txtDedGLname.value=""
			window.document.frmTenant.txtDedAccNo.value=""
			window.document.frmTenant.txtDedAccNm.value=""
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
		}
	}
	
	function Glcode()
	{ 
		telgl="TellGlaccno";
		
		if(window.document.all.divTenant.style.display=="block")
		{
			if(window.document.frmTenant.txtDedModId.value=="")
			{
				alert("Please Select Module id")
				return;
			}
			else
			{
				brcode = window.document.frmTenant.txtBrcode.value.toUpperCase();
				modid = window.document.frmTenant.txtDedModId.value.toUpperCase();
			}
			
		}
		
		kstr=telgl+"|"+modid+"|"+brcode
		
		window.showModalDialog("../gensbca/ListGlQuery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	}
	
	function glaccountid(kstr)
	{ 
	 
		if(window.document.all.divTenant.style.display=="block")
		{
			/*window.document.frmTenant.txtDedGLcode.value=StrFld[1]
			window.document.frmTenant.txtDedGLname.value=StrFld[0]*/
			
			assign(kstr,window.document.frmTenant.txtDedGLname,window.document.frmTenant.txtDedGLcode)
			
			//window.document.frmTenant.mfgTenant.Rows=1
			window.document.frmTenant.txtDedAccNo.value=""
			window.document.frmTenant.txtDedAccNm.value=""
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
		}
		
	}
	
	function AccCode()
	{
		if(window.document.all.divTenant.style.display=="block")
		{
			if(window.document.frmTenant.txtDedGLcode.value=="")
			{
				alert("Please Select Gl code")
				return;
			}
			else
			{
				brchCd=window.document.frmTenant.txtBrcode.value.toUpperCase();
				GlCd=window.document.frmTenant.txtDedGLcode.value.toUpperCase();
				ModId=window.document.frmTenant.txtDedModId.value.toUpperCase();
			}
			
		}
		
		var stacc="Telleraccno"
				
		var kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+"INR"+"|"+"='R'"
    
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		{
   			window.showModalDialog("../GENSBCA/Listquery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   		}
   		else
   		{
   			alert('Select Branch code,Currency code,Module id and GL code.')
   		}
		
	}
	function accountid(kstr)
	{ 
		if(window.document.all.divTenant.style.display=="block")
		{
			/*window.document.frmTenant.txtDedAccNo.value=StrFld[1]
			window.document.frmTenant.txtDedAccNm.value=StrFld[0]*/
			
			assign(kstr,window.document.frmTenant.txtDedAccNm,window.document.frmTenant.txtDedAccNo)
			
			//window.document.frmTenant.mfgTenant.Rows=1
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
		}
	}
	
	function AddToDed()
	{
		var stGst,stRevgst
		
		if(window.document.frmTenant.txttntBrcode.value=="")
		{
			alert("Please Select Tenant Branch Code")
			window.document.frmTenant.txttntBrcode.focus();
			return;
		}
		
		if(window.document.frmTenant.txtBrcode.value=="")
		{
			alert("Please Select Branch Code")
			window.document.frmTenant.txtBrcode.focus();
			return;
		}
		if(window.document.frmTenant.txtDedModId.value=="")
		{
			alert("Please Select Module Id")
			window.document.frmTenant.txtDedModId.focus();
			return;
		}
		if(window.document.frmTenant.txtDedGLcode.value=="")
		{
			alert("Please Select Gl Code")
			window.document.frmTenant.txtDedGLcode.focus();
			return;
		}
		if(window.document.frmTenant.txtDedAccNo.value=="")
		{
			alert("Please Select Account Number")
			window.document.frmTenant.txtDedAccNo.focus();
			return;
		}
		if(window.document.frmTenant.txtAmount.value=="")
		{
			alert("Please Enter Amount")
			window.document.frmTenant.txtAmount.focus();
			return;
		} 
		/*if(window.document.frmTenant.txtNaration.value=="")
		{
			alert("Please Enter txtTdsAmt")
			window.document.frmTenant.txtNaration.focus();
			return;
		}*/
		if(window.document.frmTenant.txtNomon.value=="")
		{
			alert("Please Enter Number Of Months")
			window.document.frmTenant.txtNomon.focus();
			return;
		}
		
		if((window.document.frmTenant.txtAmount.value=="0")||(window.document.frmTenant.txtAmount.value=="0.00"))
		{
			alert("Please Enter Amount must be Greater then 0")
			window.document.frmTenant.txtAmount.focus();
			return;
		}
		
		stRevgst = "N"
		
		if(window.document.frmTenant.chkGst.checked==true)
		{
			stGst = "Y"
			
			if(window.document.frmTenant.chkRevGst.checked==true)
			{
				stRevgst = "Y"
			}
		}
		else
		{
			stGst = "N"
		}
	
		if (window.document.frmTenant.chkAddRecovery.checked==true)
		{
			
			if (window.document.frmTenant.txtAddRecBrcode.value == "")
			{
				alert("Please Enter Advance Recovery Branchcode")
				window.document.frmTenant.txtAddRecBrcode.focus();
				return
			}
			
			if (window.document.frmTenant.txtAddRecModId.value == "")
			{
				alert("Please Enter Advance Recovery ModID")
				window.document.frmTenant.txtAddRecModId.focus();
				return
			}
			if (window.document.frmTenant.txtAddRecGLcode.value == "")
			{
				alert("Please Enter Advance Recovery GL Code")
				window.document.frmTenant.txtAddRecGLcode.focus();
				return
			}
			if (window.document.frmTenant.txtAddRecAccNo.value == "")
			{
				alert("Please Enter Advance Recovery Accno")
				window.document.frmTenant.txtAddRecAccNo.focus();
				return
			}
			if (window.document.frmTenant.txtAdvAmt.value == "")
			{
				alert("Please Enter Advance Amount")
				window.document.frmTenant.txtAdvAmt.focus();
				return
			}
			
			if (window.document.frmTenant.txtnoofins.value == "")
			{
				alert("Please Enter No Of Ins  ")
				window.document.frmTenant.txtnoofins.focus();
				return
			}
			
			if (window.document.frmTenant.txtadvinsamt.value == "")
			{
				alert("Please Enter Adv Ins Amount  ")
				window.document.frmTenant.txtadvinsamt.focus();
				return
			}
			if (window.document.frmTenant.txtRecUpto.value == "")
			{
				alert("Please Enter Rec Upto")
				window.document.frmTenant.txtRecUpto.focus();
				return
			}
				
		}
		
		var cnt
		
		cnt = 0
		
		if(window.document.frmTenant.optmode(0).checked == true)
		{
			rowidx = window.document.frmTenant.mfgTenant.rows;
			
			if(window.document.frmTenant.mfgTenant.rows > "1")
			{
				for(i=1;i<window.document.frmTenant.mfgTenant.rows;i++)
				{
					if((window.document.frmTenant.txtBrcode.value.toUpperCase()==window.document.frmTenant.mfgTenant.textmatrix(i,1))&&(window.document.frmTenant.txtDedModId.value.toUpperCase()==window.document.frmTenant.mfgTenant.textmatrix(i,2))&&(window.document.frmTenant.txtDedGLcode.value.toUpperCase()==window.document.frmTenant.mfgTenant.textmatrix(i,3))&&(window.document.frmTenant.txtDedAccNo.value.toUpperCase()==window.document.frmTenant.mfgTenant.textmatrix(i,4)))
					{
						alert("Already added")
						return;
					}
				}
			}
			
			cnt = rowidx
			
			window.document.frmTenant.mfgTenant.rows =  
					window.document.frmTenant.mfgTenant.rows+1;
					
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,0)=cnt //sl no
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,1)=
						window.document.frmTenant.txtBrcode.value.toUpperCase();//moduleid
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,2)=
						window.document.frmTenant.txtDedModId.value.toUpperCase();//glcode
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,3)=
						window.document.frmTenant.txtDedGLcode.value.toUpperCase(); //ACCNO
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,4)=
						window.document.frmTenant.txtDedAccNo.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,5)=
						window.document.frmTenant.txtAmount.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,6)= stGst
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,7)= stRevgst
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,8)=			
						window.document.frmTenant.txtTdsAmt.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,9)=
						window.document.frmTenant.txtNomon.value.toUpperCase();
						
			// recovery data
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,10)=window.document.frmTenant.txtAddRecBrcode.value.toUpperCase();	
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,11)=window.document.frmTenant.txtAddRecModId.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,12)=window.document.frmTenant.txtAddRecGLcode.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,13)=window.document.frmTenant.txtAddRecAccNo.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,14)=window.document.frmTenant.txtAdvAmt.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,15)=window.document.frmTenant.txtnoofins.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,16)=window.document.frmTenant.txtadvinsamt.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,17)=window.document.frmTenant.txtRecUpto.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,18)=window.document.frmTenant.cmbAdvRecFlag.value;	
			
			
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,19)=window.document.frmTenant.txttntBrcode.value;
				
		}
		if(window.document.frmTenant.optmode(1).checked == true)
		{
			rowidx = window.document.frmTenant.hdnrow.value
			
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,0)= rowidx //sl no
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,1)=
						window.document.frmTenant.txtBrcode.value.toUpperCase();//br code
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,2)=
						window.document.frmTenant.txtBrdesc.value.toUpperCase();//br desc
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,3)=
						window.document.frmTenant.txtDedModId.value.toUpperCase();//module
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,4)=
						window.document.frmTenant.txtDedModNm.value.toUpperCase();//module desc
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,5)=
						window.document.frmTenant.txtDedGLcode.value.toUpperCase(); //glcode
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,6)=
						window.document.frmTenant.txtDedGLname.value.toUpperCase(); //gl desc
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,7)=
						window.document.frmTenant.txtDedAccNo.value.toUpperCase();// acc no
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,8)=
						window.document.frmTenant.txtAmount.value.toUpperCase(); // amount
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,9)= stGst // gst
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,10)= stRevgst // rev gst
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,11)=			
						window.document.frmTenant.txtNomon.value.toUpperCase(); // up to date
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,12)=
						window.document.frmTenant.txtTdsAmt.value.toUpperCase(); // txtTdsAmt
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,13)=
						window.document.frmTenant.cmbCRFag.value.toUpperCase(); // status
			if(window.document.frmTenant.cmbCRFag.value.toUpperCase() == "C")
			{
				window.document.frmTenant.mfgTenant.TextMatrix(rowidx,14) = '<%=session("applicationdate")%>'
			}
			else
			{
				window.document.frmTenant.mfgTenant.TextMatrix(rowidx,14) = ""
			}
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,15) = "Y"
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,16)=
						window.document.frmTenant.txtDedAccNm.value.toUpperCase(); // acc name
			
			// recovery data
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,17)=window.document.frmTenant.txtAddRecBrcode.value.toUpperCase();	
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,18)=window.document.frmTenant.txtAddRecBrdesc.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,19)=window.document.frmTenant.txtAddRecModId.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,20)=window.document.frmTenant.txtAddRecModNm.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,21)=window.document.frmTenant.txtAddRecGLcode.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,22)=window.document.frmTenant.txtAddRecGLname.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,23)=window.document.frmTenant.txtAddRecAccNo.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,24)=window.document.frmTenant.txtAddRecAccNm.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,25)=window.document.frmTenant.txtAdvAmt.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,26)=window.document.frmTenant.txtnoofins.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,27)=window.document.frmTenant.txtadvinsamt.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,28)=window.document.frmTenant.txtRecUpto.value.toUpperCase();
			window.document.frmTenant.mfgTenant.TextMatrix(rowidx,29)=window.document.frmTenant.cmbAdvRecFlag.value;			
			
			
		}
		
		clear2()
		
	}
	
	function clear2()
	{
		//window.document.frmTenant.mfgTenant.Rows=1
		
		window.document.frmTenant.txttntBrcode.value = "<%=session("branchcode")%>"
		window.document.frmTenant.txttntBrdesc.value = "<%=session("branchnarration")%>"
		window.document.frmTenant.txtBrcode.value = "<%=session("branchcode")%>"
		window.document.frmTenant.txtBrdesc.value = "<%=session("branchnarration")%>"
		window.document.frmTenant.txtDedModId.value = ""
		window.document.frmTenant.txtDedModNm.value=""
		window.document.frmTenant.txtDedGLcode.value = ""
		window.document.frmTenant.txtDedGLname.value=""
		window.document.frmTenant.txtDedAccNo.value = ""
		window.document.frmTenant.txtDedAccNm.value=""
		window.document.frmTenant.txtAmount.value = ""
		window.document.frmTenant.txtTdsAmt.value = ""
		window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
		window.document.frmTenant.chkGst.checked = false
		window.document.all.divRevGst.style.display="none"
		window.document.all.divStat.style.display="none"
		window.document.frmTenant.chkRevGst.checked=false
		// recovery data
		window.document.frmTenant.txtAddRecBrcode.value  = ""
		window.document.frmTenant.txtAddRecBrdesc.value  = ""
		window.document.frmTenant.txtAddRecModId.value  = ""
		window.document.frmTenant.txtAddRecModNm.value  = ""
		window.document.frmTenant.txtAddRecGLcode.value  = ""
		window.document.frmTenant.txtAddRecGLname.value  = ""
		window.document.frmTenant.txtAddRecAccNo.value  = ""
		window.document.frmTenant.txtAddRecAccNm.value  = ""
		window.document.frmTenant.txtAdvAmt.value  = ""
		window.document.frmTenant.txtnoofins.value = ""
		window.document.frmTenant.txtadvinsamt.value = ""
		window.document.frmTenant.txtRecUpto.value  = "<%=session("applicationdate")%>"	
		window.document.frmTenant.cmbAdvRecFlag.selectedIndex=0
		
		
	}
	
	function GstChk()
	{
		if(window.document.frmTenant.chkGst.checked==true)
		{
			window.document.all.divRevGst.style.display="block"
			window.document.frmTenant.chkRevGst.checked=false
		}
		else
		{
			window.document.all.divRevGst.style.display="none"
			window.document.frmTenant.chkRevGst.checked=false
		}
	}
	
	function GetTDSAmt()
	{
	
var strVal

var strVal="GetTDSAmt"+"|"+window.document.frmTenant.txtBrcode.value+"|"+window.document.frmTenant.txtDedModId.value+"|"+window.document.frmTenant.txtDedGLcode.value+"|"+window.document.frmTenant.txtDedAccNo.value + "|" + window.document.frmTenant.txtAmount.value
		
window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
	}
	
	function SetTDSAmt(str)
	{
	window.document.frmTenant.txtTdsAmt.value = str
	}
	
	function subtrans()
	{
		var mod=""
		var StrCols=""
		var StrColRow=""
		var StrCol=""
		var status="R"
		var StrrecCols = ""
		var StrrecColRow=""
		if(window.document.all.divTenant.style.display=="block")
		{
		
			if(window.document.frmTenant.optmode(0).checked == true)
			{
			
				if(window.document.frmTenant.mfgTenant.rows > "1")
				{
					
					window.document.frmTenant.hmode.value="INSERT"+"|"+"TENANT"
						
					for(icnt=1;icnt<=window.document.frmTenant.mfgTenant.rows-1;icnt++)
					{
						StrCols = ""
								
							StrCols = window.document.frmTenant.mfgTenant.TextMatrix(icnt,19) + "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,1) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,2) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,3) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,4) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,5) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,6) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,7) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,8) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,9) +  "," +appdat+","+status+","+appdat+","+userid+","+macid+"," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,10) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,11) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,12) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,13) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,14) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,15) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,16)  +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,17) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,18) + ",sysdate" 
									
						StrColRow=StrColRow+StrCols+"|"
					}
						
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
					
				}
			}
			
			if(window.document.frmTenant.optmode(1).checked == true)
			{
				if(window.document.frmTenant.mfgTenant.rows > "1")
				{
					window.document.frmTenant.hmode.value="MODIFY"+"|"+"TENANT"
					
					for(icnt=1;icnt<=window.document.frmTenant.mfgTenant.rows-1;icnt++)
					{
						StrCols = ""
						if(window.document.frmTenant.mfgTenant.TextMatrix(icnt,15)=="Y")
						{
							
							StrCols = window.document.frmTenant.mfgTenant.TextMatrix(icnt,31)+ "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,1) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,3) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,5) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,7) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,8) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,9) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,10) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,11) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,12) +  "," +   window.document.frmTenant.mfgTenant.TextMatrix(icnt,13) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,14) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,17) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,19) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,21) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,23) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,25) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,26) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,27) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,28) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,29) +  "," +  window.document.frmTenant.mfgTenant.TextMatrix(icnt,30)
									
						StrColRow=StrColRow+StrCols+"|"
						}
					}
					
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
				}
			}
			
			window.document.frmTenant.mercust.value=StrColRow
			window.document.frmTenant.action="TenantMstInstr.aspx"
			window.document.frmTenant.method="post"   
			window.document.frmTenant.submit()
		}
	}
	
	function DescrptionDisp(strTxt)
	{
		sBr = window.document.frmTenant.txtBrcode.value.toUpperCase()
		sMod = window.document.frmTenant.txtDedModId.value.toUpperCase()
		sGL = window.document.frmTenant.txtDedGLcode.value.toUpperCase()
		sAccno = window.document.frmTenant.txtDedAccNo.value.toUpperCase()
		sCur = "INR"
		
		//window.document.frmTenant.mfgTenant.Rows=1
		
		if(strTxt=="txtBrcode")
		{
			if(sBr!="")
			{
				window.document.frmTenant.txtBrdesc.value=""
				st="DescDisplay~GENBANKBRANCHMST~"+"txtTdsAmt~branchcode='"+sBr+"'~~"+strTxt
				
				window.document.frmTenant.txtDedModId.value = ""
				window.document.frmTenant.txtDedModNm.value = ""
				window.document.frmTenant.txtDedGLcode.value = ""
				window.document.frmTenant.txtDedGLname.value=""
				window.document.frmTenant.txtDedAccNo.value = ""
				window.document.frmTenant.txtDedAccNm.value=""
				window.document.frmTenant.txtAmount.value = ""
				window.document.frmTenant.txtTdsAmt.value = ""
				window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
				window.document.frmTenant.chkGst.checked = false
				window.document.all.divRevGst.style.display="none"
				window.document.frmTenant.chkRevGst.checked=false
			}
				
		}
		
		if(strTxt=="txtDedModId")
		{ 
			if(window.document.frmTenant.txtDedModId.value=="")
			{
				return;
			}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"'~~"+strTxt
				
			window.document.frmTenant.txtDedGLcode.value = ""
			window.document.frmTenant.txtDedGLname.value=""
			window.document.frmTenant.txtDedAccNo.value = ""
			window.document.frmTenant.txtDedAccNm.value=""
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
			window.document.all.divRevGst.style.display="none"
			window.document.frmTenant.chkRevGst.checked=false
				
		}
		
		if(strTxt=="txtDedGLcode")
		{ 
			if(window.document.frmTenant.txtDedGLcode.value=="")
			{
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
			
			window.document.frmTenant.txtDedAccNo.value = ""
			window.document.frmTenant.txtDedAccNm.value=""
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
			window.document.all.divRevGst.style.display="none"
			window.document.frmTenant.chkRevGst.checked=false
		}
		
		if(strTxt=="txtDedAccNo")
		{ 
			if(window.document.frmTenant.txtDedAccNo.value=="")
			{
				return;
			}
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
			
			window.document.frmTenant.txtAmount.value = ""
			window.document.frmTenant.txtTdsAmt.value = ""
			window.document.frmTenant.txtNomon.value  = "<%=session("applicationdate")%>"	
			window.document.frmTenant.chkGst.checked = false
			window.document.all.divRevGst.style.display="none"
			window.document.frmTenant.chkRevGst.checked=false
		}
		
		//alert("st2 = "+st)
		window.document.all["iBatch"].src="../GENSBCA/querydisplay.aspx?st="+st
	}
	
	function DescDisplay(stri)
	{
		//alert("stri = "+stri)
		var strtype=new String()
		strtype=stri.split("~")
		
		var StrArrFld=new String()
		StrArrFld=strtype[0].split("|")
		
		if(strtype[1]=="txtBrcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Branch Code")
				window.document.frmTenant.txtBrcode.value=""
			}
			else
			{
				window.document.frmTenant.txtBrdesc.value=StrArrFld[0]
			}
			
		}
			
		if(strtype[1]=="txtDedModId")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid ModuleId")
				window.document.frmTenant.txtDedModId.value=""
				window.document.frmTenant.txtDedModNm.value=""
				window.document.frmTenant.txtDedModId.focus()
				return;
			}
			window.document.frmTenant.txtDedModNm.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtDedGLcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Glcode")
				window.document.frmTenant.txtDedGLcode.value=""
				window.document.frmTenant.txtDedGLname.value=""
				window.document.frmTenant.txtDedGLcode.focus()
				return;
			}
			window.document.frmTenant.txtDedGLname.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtDedAccNo")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Account No.")
				window.document.frmTenant.txtDedAccNo.value=""
				window.document.frmTenant.txtDedAccNm.value=""
				window.document.frmTenant.txtDedAccNo.focus()
				return;
			}
			window.document.frmTenant.txtDedAccNm.value=StrArrFld[0]
		
		}
	}
	
	function control()
	{	
		clear2()
		window.document.frmTenant.mfgTenant.Rows=1
		if(window.document.frmTenant.optmode(0).checked==true)
		{
			window.document.frmTenant.mfgTenant.Rows=1
		
		window.document.frmTenant.mfgTenant.cols = 20;
		window.document.frmTenant.mfgTenant.formatstring="Slno   |<Br  Code     |<Mod Id       |<Gl code     |<Acc  No.       |> Amount           |<Gst Y/N   |<Rev GstY/N  |< Tds                 |< Payed UPto     |<Rec BrCode     |< Rec ModID    |< Rec GLCode     |< Rec AccNo    |> Adv  Amt     |< No Of Ins |> Adv Ins Amt  |<   RecUpto   |<Rec Status |< Tenant Brcode"
		
		
			window.document.frmTenant.txtBrcode.readonly = false
			window.document.frmTenant.txtBrcode.disabled = false
			window.document.frmTenant.txtBrdesc.disabled = false
			window.document.frmTenant.txtDedModId.readonly = false
			window.document.frmTenant.txtDedModId.disabled = false
			window.document.frmTenant.txtDedModNm.disabled = false
			window.document.frmTenant.txtDedGLcode.readonly = false
			window.document.frmTenant.txtDedGLcode.disabled = false
			window.document.frmTenant.txtDedGLname.disabled = false
			window.document.frmTenant.txtDedAccNo.readonly = false
			window.document.frmTenant.txtDedAccNo.disabled = false
			window.document.frmTenant.txtDedAccNm.disabled = false
			window.document.frmTenant.cmdbranch.disabled = false
			window.document.frmTenant.D1.disabled = false
			window.document.frmTenant.D2.disabled = false
			window.document.frmTenant.D3.disabled = false
			
		}
		if(window.document.frmTenant.optmode(1).checked==true)
		{
			window.document.frmTenant.txtBrcode.readonly = true
			window.document.frmTenant.txtBrcode.disabled = true
			window.document.frmTenant.txtBrdesc.disabled = true
			window.document.frmTenant.txtDedModId.readonly = true
			window.document.frmTenant.txtDedModId.disabled = true
			window.document.frmTenant.txtDedModNm.disabled = true
			window.document.frmTenant.txtDedGLcode.readonly = true
			window.document.frmTenant.txtDedGLcode.disabled = true
			window.document.frmTenant.txtDedGLname.disabled = true
			window.document.frmTenant.txtDedAccNo.readonly = true
			window.document.frmTenant.txtDedAccNo.disabled = true
			window.document.frmTenant.txtDedAccNm.disabled = true
			window.document.frmTenant.cmdbranch.disabled = true
			window.document.frmTenant.D1.disabled = true
			window.document.frmTenant.D2.disabled = true
			window.document.frmTenant.D3.disabled = true
			
			window.document.all.divStat.style.display = "block"
			var strVal="TENANTMAST"+"|"+stBrcd
		
			//alert(" strVal = "+strVal)
			window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
		}
	}
	
	function popTenantdtls(str)
	{
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		var stSal = str.split("|")
		
		window.document.frmTenant.mfgTenant.Rows=1
		
		window.document.frmTenant.mfgTenant.cols = 32;
		window.document.frmTenant.mfgTenant.formatstring="<SLNO  |<BrCode    |<BrDesc     |<ModId     |<ModDesc     |<GlCode     |<GlDesc      |<AccNo       |>Amount    |<GSTYN     |<RevGstYN |<DueDate        |<TDS      |<Status   |<CloseDate    |<ModifyYN  |<AccName                   |<Rec BrCode     |<Rec Br Name           |< Rec ModID    |<Rec  Module    Name                |< Rec GLCode      |<Rec GL Desc                   |< Rec AccNo      |< Rec Acc Name               |> Adv  Amt      |<noofins    |< advinsmat |<   RecUpto   |<Rec Ststus|<Rec TenantID |< Tenant Brcode";
		
		for(aCnt=0;aCnt<=stSal.length-1;aCnt++)
		{
			window.document.frmTenant.mfgTenant.rows = window.document.frmTenant.mfgTenant.rows+1
			
			var strCols=stSal[aCnt].split("~")
			
			window.document.frmTenant.mfgTenant.textmatrix(aCnt+1,0) = aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmTenant.mfgTenant.textmatrix(aCnt+1,vCnt+1) = strCols[vCnt]
			}
		}
		
	}
	
	function mfgTenant_DblClick()
	{
	clear2()
		row=window.document.frmTenant.mfgTenant.Row
		
		window.document.frmTenant.hdnrow.value = row
		
		if(window.document.frmTenant.optmode(1).checked==true)
		{
			window.document.all.divStat.style.display = "block"
			window.document.frmTenant.txttntBrcode.value = window.document.frmTenant.mfgTenant.textmatrix(row,31)
			window.document.frmTenant.txtBrcode.value = window.document.frmTenant.mfgTenant.textmatrix(row,1)
			window.document.frmTenant.txtBrdesc.value = window.document.frmTenant.mfgTenant.textmatrix(row,2)
			window.document.frmTenant.txtDedModId.value = window.document.frmTenant.mfgTenant.textmatrix(row,3)
			window.document.frmTenant.txtDedModNm.value = window.document.frmTenant.mfgTenant.textmatrix(row,4)
			window.document.frmTenant.txtDedGLcode.value = window.document.frmTenant.mfgTenant.textmatrix(row,5)
			window.document.frmTenant.txtDedGLname.value = window.document.frmTenant.mfgTenant.textmatrix(row,6)
			window.document.frmTenant.txtDedAccNo.value = window.document.frmTenant.mfgTenant.textmatrix(row,7)
			window.document.frmTenant.txtDedAccNm.value = window.document.frmTenant.mfgTenant.textmatrix(row,16)
			window.document.frmTenant.txtAmount.value = window.document.frmTenant.mfgTenant.textmatrix(row,8)
			if( window.document.frmTenant.mfgTenant.textmatrix(row,9) == "Y")
			{
				window.document.frmTenant.chkGst.checked = true
			}
			else
			{
				window.document.frmTenant.chkGst.checked = false
			}
			
			if( window.document.frmTenant.mfgTenant.textmatrix(row,10) == "Y")
			{
				window.document.all.divRevGst.style.display="block"
				window.document.frmTenant.chkRevGst.checked = true
			}
			else
			{
				window.document.all.divRevGst.style.display="none"
				window.document.frmTenant.chkRevGst.checked = false
			}
			 
			window.document.frmTenant.txtNomon.value = window.document.frmTenant.mfgTenant.textmatrix(row,11)
			window.document.frmTenant.txtTdsAmt.value = window.document.frmTenant.mfgTenant.textmatrix(row,12)
			window.document.frmTenant.cmbCRFag.value = window.document.frmTenant.mfgTenant.textmatrix(row,13)
			
			// advance recovery amount details
		
window.document.frmTenant.txtAddRecBrcode.value = window.document.frmTenant.mfgTenant.textmatrix(row,17)
if (window.document.frmTenant.txtAddRecBrcode.value != "")
{
window.document.frmTenant.chkAddRecovery.checked = true
window.document.all.divRecAmt.style.display = "block"
}
else
{
window.document.frmTenant.chkAddRecovery.checked = false
window.document.all.divRecAmt.style.display = "none"
}

window.document.frmTenant.txtAddRecBrdesc.value = window.document.frmTenant.mfgTenant.textmatrix(row,18)
window.document.frmTenant.txtAddRecModId.value = window.document.frmTenant.mfgTenant.textmatrix(row,19)
window.document.frmTenant.txtAddRecModNm.value = window.document.frmTenant.mfgTenant.textmatrix(row,20)
window.document.frmTenant.txtAddRecGLcode.value = window.document.frmTenant.mfgTenant.textmatrix(row,21)
window.document.frmTenant.txtAddRecGLname.value = window.document.frmTenant.mfgTenant.textmatrix(row,22)
window.document.frmTenant.txtAddRecAccNo.value = window.document.frmTenant.mfgTenant.textmatrix(row,23)
window.document.frmTenant.txtAddRecAccNm.value = window.document.frmTenant.mfgTenant.textmatrix(row,24)
window.document.frmTenant.txtAdvAmt.value = window.document.frmTenant.mfgTenant.textmatrix(row,25)
window.document.frmTenant.txtnoofins.value = window.document.frmTenant.mfgTenant.TextMatrix(row,26)
window.document.frmTenant.txtadvinsamt.value = window.document.frmTenant.mfgTenant.TextMatrix(row,27)
window.document.frmTenant.txtRecUpto.value = window.document.frmTenant.mfgTenant.textmatrix(row,28)
if (window.document.frmTenant.mfgTenant.textmatrix(row,29) == "R")
{
window.document.frmTenant.cmbAdvRecFlag.selectedIndex = 0 
}
else
{
window.document.frmTenant.cmbAdvRecFlag.selectedIndex = 1
}
	}
		
	}

function GetInsAmt()
{


window.document.frmTenant.txtadvinsamt.value = Math.round(eval(window.document.frmTenant.txtAdvAmt.value)/ eval(window.document.frmTenant.txtnoofins.value))

var strVal

var strVal="RECUPTO"+"|"+window.document.frmTenant.txtnoofins.value
		
	
			window.document.all['iVinFrame'].src="getDetails.aspx?st="+strVal;
}

function popRECUPTO(kstr)
{
window.document.frmTenant.txtRecUpto.value = kstr
}

	function round(number, precision) 
	{ 
		var pair = (number + 'e').split('e') 
		var value = Math.round(pair[0] + 'e' + (+pair[1] + precision)) 
		pair = (value + 'e').split('e') 
		return +(pair[0] + 'e' + (+pair[1] - precision)) 
	}

	function TDS()
	{
		if(window.document.frmTenant.chkTds.checked==true)
		{
			window.document.frmTenant.txtTds.disabled = false
			
			if((window.document.frmTenant.txtAmount.value=="")||(window.document.frmTenant.txtAmount.value=="0")||(window.document.frmTenant.txtAmount.value=="0.00"))
			{
				alert("Please Enter The Amount")
				window.document.frmTenant.txtTds.disabled = true
				window.document.frmTenant.chkTds.checked = false
				return;
			}
			
			var stTdsval="<%=Tdsval%>"
			
			var stTds 
			
			stTds = eval(eval(window.document.frmTenant.txtAmount.value)*eval(stTdsval))/100
			
			window.document.frmTenant.txtTds.value = round(stTds,2)
			
			window.document.frmTenant.txtAmount.value = round(eval(eval(window.document.frmTenant.txtAmount.value) - eval(window.document.frmTenant.txtTds.value)),2)
			
		}
		else
		{
			window.document.frmTenant.txtTds.disabled = true;
			
			var stTot
			
			stTot = round(eval(eval(window.document.frmTenant.txtAmount.value) + eval(window.document.frmTenant.txtTds.value)),2)
			
			window.document.frmTenant.txtAmount.value = stTot
			window.document.frmTenant.txtTds.value = ""
		}
	}
	
	function chkTdsamt()
	{
		window.document.frmTenant.txtAmount.value = round(eval(eval(window.document.frmTenant.txtAmount.value) - eval(window.document.frmTenant.txtTds.value)),2)
	}
	
	function setchkAddRecovery()
	{
		if (window.document.frmTenant.chkAddRecovery.checked == true)
		{
			window.document.all.divRecAmt.style.display = "block"
		}
		else
		{
			window.document.all.divRecAmt.style.display = "none"
		}
	}

	function AddRecBranch()
	{
		var branch="AddRecBranch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user
		
		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}

	function AddRecBranchid(kstr)
	{	
		assign(kstr,window.document.frmTenant.txtAddRecBrdesc,window.document.frmTenant.txtAddRecBrcode)
		
		//window.document.frmTenant.mfgTenant.Rows=1
		window.document.frmTenant.txtAddRecModId.value=""
		window.document.frmTenant.txtAddRecModNm.value=""
		window.document.frmTenant.txtAddRecGLcode.value=""
		window.document.frmTenant.txtAddRecGLname.value=""
		window.document.frmTenant.txtAddRecAccNo.value=""
		window.document.frmTenant.txtAddRecAccNm.value=""
		window.document.frmTenant.txtAdvAmt.value = ""
		window.document.frmTenant.txtnoofins.value = ""
		window.document.frmTenant.txtadvinsamt.value = ""
		window.document.frmTenant.txtRecUpto.value  = "<%=session("applicationdate")%>"	

	}
	
	
	function AddRecmodule()
	{ 
		stmod="AddRecsbcaccmodule"; 
		if(window.document.all.divTenant.style.display=="block")
		{
			window.document.frmTenant.txtAddRecModId.value=""
			window.document.frmTenant.txtAddRecModNm.value=""
			
			if(window.document.frmTenant.txtAddRecBrcode.value=="")
			{
				alert("Please Select Add Rec Branch Code")
				return;
			}
			else
			{
				stbr = window.document.frmTenant.txtAddRecBrcode.value.toUpperCase();
			}
		}
		
		kstr=stmod+"|"+stbr
		window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
	}
	function AddRecmodulecode(kstr)
	{
		var StrFld=new String()
		StrFld=kstr.split("-----")
		
		if(window.document.all.divTenant.style.display=="block")
		{
			window.document.frmTenant.txtAddRecModId.value=StrFld[1]
			window.document.frmTenant.txtAddRecModNm.value=StrFld[0]
			
			//window.document.frmTenant.mfgTenant.Rows=1
			window.document.frmTenant.txtAddRecGLcode.value=""
			window.document.frmTenant.txtAddRecGLname.value=""
			window.document.frmTenant.txtAddRecAccNo.value=""
			window.document.frmTenant.txtAddRecAccNm.value=""
			window.document.frmTenant.txtAdvAmt.value = ""
			window.document.frmTenant.txtnoofins.value = ""
			window.document.frmTenant.txtadvinsamt.value = ""
			window.document.frmTenant.txtRecUpto.value  = "<%=session("applicationdate")%>"	
	
		}
	}
	
	function AddRecGlcode()
	{ 
		telgl="AddRecTellGlaccno";
		
	
			if(window.document.frmTenant.txtAddRecModId.value=="")
			{
				alert("Please Select Module id")
				return;
			}
			else
			{
				brcode = window.document.frmTenant.txtAddRecBrcode.value.toUpperCase();
				modid = window.document.frmTenant.txtAddRecModId.value.toUpperCase();
			}
			
	
		
		kstr=telgl+"|"+modid+"|"+brcode
		
		window.showModalDialog("../gensbca/ListGlQuery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	}
	
	function AddRecGetGLCode(kstr)
	{ 
	 
			assign(kstr,window.document.frmTenant.txtAddRecGLname,window.document.frmTenant.txtAddRecGLcode)		
			window.document.frmTenant.txtAddRecAccNo.value=""
			window.document.frmTenant.txtAddRecAccNm.value=""
			window.document.frmTenant.txtAdvAmt.value = ""
					window.document.frmTenant.txtnoofins.value = ""
		window.document.frmTenant.txtadvinsamt.value = ""
			window.document.frmTenant.txtRecUpto.value  = "<%=session("applicationdate")%>"	
	
	}
	
	function AddRecAccCode()
	{
	
			if(window.document.frmTenant.txtAddRecGLcode.value=="")
			{
				alert("Please Select Gl code")
				return;
			}
			else
			{
				brchCd=window.document.frmTenant.txtAddRecBrcode.value.toUpperCase();
				GlCd=window.document.frmTenant.txtAddRecGLcode.value.toUpperCase();
				ModId=window.document.frmTenant.txtAddRecModId.value.toUpperCase();
			}
			

		
		var stacc="AddRecTelleraccno"
				
		var kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+"INR"+"|"+"='R'"
    
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		{
   			window.showModalDialog("../GENSBCA/Listquery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   		}
   		else
   		{
   			alert('Select Branch code,Currency code,Module id and GL code.')
   		}
		
	}
	function AddRecaccountid(kstr)
	{ 
			assign(kstr,window.document.frmTenant.txtAddRecAccNm,window.document.frmTenant.txtAddRecAccNo)
			
			window.document.frmTenant.txtAdvAmt.value = ""
					window.document.frmTenant.txtnoofins.value = ""
		window.document.frmTenant.txtadvinsamt.value = ""
			window.document.frmTenant.txtRecUpto.value  = "<%=session("applicationdate")%>"	
	}
	
	function initialcheck()
	{

	window.document.frmTenant.txtNomon.value = "<%=session("applicationdate")%>"	

	window.document.frmTenant.txtRecUpto.value = "<%=session("applicationdate")%>"	
	}	
	</script>
	
	<SCRIPT LANGUAGE=javascript FOR=mfgTenant EVENT=DblClick>
	<!--
	mfgTenant_DblClick()
	//-->
	</script>
 </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();checkImplement();initialcheck()">

    <form name="frmTenant">
		<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%">
				<tr>
					<td align="left" class="bankHeaderLogo"></td>
					<td align="right" class="esmartBankerLogo"></td>
				</tr>
			</table>			
		</div>
		<div class="menuBar">
			<table cellpadding="0" border="0" cellspacing="0" width="100%">
				<tr>
					<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="30%" align="center" height="22" class="subHeader"><h2>Tenant Master&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol">
		</div><%appdate=formatdatetime(session("applicationdate"),1)%>

		<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
			<tr>
				<td width="100%">
					<!-- <table align="center" cellspacing="0" cellpadding="0">
						<tr>
							<td height="15"><font class="textblue"></font></td>
						</tr>
					</table> -->
					
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
						<tr>
							<td width="16%" valign="top">
								<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
									<tr bgcolor="#99ccff" >
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">Tenant Master</font></a></td>
									</tr>
									<!--<tr bgcolor="#99ccff">
										<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">Salary Parameter</font></a></td>
									</tr>-->
									
								
								</table>
							</td>
							<td width="84%" valign="top">
								<div id="divTenant" style="display:none">
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td width="100%" colspan="7" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Tenant Master" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
										</tr>
									</table>
									<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tableborder1">
										<tr class="bgcolor1">
											<td width="10%">
											<p align="right"><font class="textblack"><input checked name="optmode" type="radio" value="31" onclick="control()"></font></td>
											<td width="20%"><font class="textblack">Add</font></td>
											<td width="20%">
											<p align="right"><font class="textblack"><input name="optmode" type="radio" value="31" onclick="control()"></font></td>
											<td width="20%"><font class="textblack">Modify</font></td>
											<td width="10%">
										</tr>
									</table>
									<table>
									<tr>
											<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;Tenant Branch Code</p></td>
											<td width="30%"><input name="txttntBrcode" size="9" value="<%=session("branchcode")%>" class="txtautofill" onblur="DescrptionDisp(&quot;txttntBrcode&quot;)"><input type="button" value=" L " name="cmdtntbranch" onclick="TenantBranch()" class="button"><input name="txttntBrdesc" size="19" readonly value="<%=session("branchnarration")%>" class="bgcolor1">&nbsp;</td>
											<td width="20%" align="left" height="27">&nbsp;&nbsp;&nbsp;</td>
											<td width="30%">&nbsp;</td>
										</tr>
										<tr>
											<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;Branch Code</p></td>
											<td width="30%"><input name="txtBrcode" size="9" value="<%=session("branchcode")%>" class="txtautofill" onblur="DescrptionDisp(&quot;txtBrcode&quot;)"><input type="button" value=" L " name="cmdbranch" onclick="Branch()" class="button"><input name="txtBrdesc" size="19" readonly value="<%=session("branchnarration")%>" class="bgcolor1">&nbsp;</td>
											<td width="20%" align="left" height="27">&nbsp;&nbsp;&nbsp;Module ID</td>
											<td width="30%"><input name="txtDedModId" size="15" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"  maxlength="16" value="" onblur="DescrptionDisp(&quot;txtDedModId&quot;)" class="txtautofill"><input type="button" value=" L " name="D1"  onclick="module()" class="button"><input name="txtDedModNm" size="19" value="" readonly class="bgcolor1"></td>
										</tr>
										<tr>
											<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;GL Code</p></td>
											<td width="30%"><input name="txtDedGLcode" onkeypress="Alphanum()" class="txtautofill" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" onblur="DescrptionDisp(&quot;txtDedGLcode&quot;)" ><input type="button" value=" L " name="D2" onclick="Glcode()" class="button"  ><input name="txtDedGLname" size="19" class="bgcolor1"></td>
											<td width="20%" align="left">&nbsp;&nbsp;&nbsp;Acc. No</td>
											<td width="30%"><input name="txtDedAccNo" onkeypress="Alphanum()" class="txtautofill" maxlength="16" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" size="15" onblur="DescrptionDisp(&quot;txtDedAccNo&quot;)"><input type="button" value=" L " name="D3" onclick="AccCode()" class="button"><input name="txtDedAccNm" size="19" readonly class="bgcolor1"></td>
										</tr>
										<tr>
											<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;Amount</p> </td>
											<td width="30%">
											<div>
												<table width="100%" border="0">
													<tr>
														<td width="65%"><input type="text" align="right" name="txtAmount" size="10" class="txtautofill" onblur="precision(window.document.frmTenant.txtAmount,window.document.frmTenant.hpr.value);GetTDSAmt();" maxlength=16 onkeypress="numdec(window.document.frmTenant.txtAmount.value)">&nbsp;GST Y/N&nbsp;<input type="checkbox" id="chkGst" name="chkGst" onclick="GstChk()" size="2">
														</td>
														<td width="35%">
															<div id="divRevGst" style="display:none">
																<table>
																	<tr>
																		<td>
																			Rev GSTY/N<input type="checkbox" size="2" id="chkRevGst" name="chkRevGst">
																		</td>
																	</tr>
																</table>
															</div>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="20%" align="left">&nbsp;&nbsp;&nbsp;TDS</td>
											<td width="30%"><input type="text" name="txtTdsAmt" size="15" onblur="precision(window.document.frmTenant.txtTdsAmt,window.document.frmTenant.hpr.value);"  maxlength=13 onkeypress="numdec(window.document.frmTenant.txtTdsAmt.value)"></td>
											<!--<td width="20%" align="left">&nbsp;&nbsp;&nbsp;txtTdsAmt</td>
											<td width="30%"><input type="text" name="txtNaration" size="44"></td> 
											<td  width="50%" colspan="2">
												<table width="100%" border="0">
													<tr>
														<td width="20%" align="left">&nbsp;&nbsp;&nbsp;TDS<input type="checkbox" size="2" id="chkTds" name="chkTds" onclick="TDS()" size="2"></td>
														<td width="30%"><input type="text" name="txtTds" size="15" onblur="chkTdsamt()" disabled></td>
														<td width="20%" align="left">&nbsp;&nbsp;&nbsp;txtTdsAmt</td>
														<td width="30%"><input type="text" name="txtNaration" size="15"</td>
													</tr>
												</table>
											</td> -->
										</tr>
										<tr>
											<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;Pay UpTo</p> </td>
											<td width="30%"><input  type="text" id = "txtNomon" name="txtNomon" maxlength="15" size="12" style="TEXT-ALIGN: left" class="txtautofill" onblur="datecheck(this);">(DDMMYYYY)</td>
											<td width="50%" colspan='2' align="center">
												<div id="divStat" style="display:none">
													<table border="0" width="100%" cellspacing="0" cellpadding="0">
														<tr>
															<td width="20%">&nbsp;&nbsp;&nbsp;Status</td>
															<td width="30%"><select size="1" name="cmbCRFag" >
																				<option value="R">Running</option>
																				<option value="C">Close</option>
																			</select></td>
														</tr>
													</table>
												
												</div> 
											</td>
											
										</tr>
										<tr>
										<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;Adv Recovery <input type="checkbox" size="2" id="chkAddRecovery" name="chkAddRecovery" onclick="setchkAddRecovery()"> </p></td> <td width="30%">&nbsp;</td><td width="50%" colspan=2>&nbsp;</td>
										</tr>
										
										<tr>
										<td width="100%" colspan=4>
										<div id="divRecAmt" style="display:none">
													<table border="0" width="100%" cellspacing="0" cellpadding="0">
													<tr>
											<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;Branch Code</p></td>
											<td width="30%"><input name="txtAddRecBrcode" size="9" value="<%=session("branchcode")%>" class="txtautofill" onblur="DescrptionDisp(&quot;txtBrcode&quot;)"><input type="button" value=" L " name="cmdAddRecbranch" onclick="AddRecBranch()" class="button"><input name="txtAddRecBrdesc" size="19" readonly value="<%=session("branchnarration")%>" class="bgcolor1">&nbsp;</td>
											<td width="20%" align="left" height="27">&nbsp;&nbsp;&nbsp;Module ID</td>
											<td width="30%"><input name="txtAddRecModId" size="15" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"  maxlength="16" value="" onblur="DescrptionDisp(&quot;txtAddRecModId&quot;)" class="txtautofill"><input type="button" value=" L " name="AddRecD1"  onclick="AddRecmodule()" class="button"><input name="txtAddRecModNm" size="19" value="" readonly class="bgcolor1"></td>
										</tr>
										<tr>
											<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;GL Code</p></td>
											<td width="30%"><input name="txtAddRecGLcode" onkeypress="Alphanum()" class="txtautofill" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" onblur="DescrptionDisp(&quot;txtAddRecGLcode&quot;)" ><input type="button" value=" L " name="AddRecD2" onclick="AddRecGlcode()" class="button"  ><input name="txtAddRecGLname" size="19" class="bgcolor1"></td>
											<td width="20%" align="left">&nbsp;&nbsp;&nbsp;Acc. No</td>
											<td width="30%"><input name="txtAddRecAccNo" onkeypress="Alphanum()" class="txtautofill" maxlength="16" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" size="15" onblur="DescrptionDisp(&quot;txtAddRecAccNo&quot;)"><input type="button" value=" L " name="AddRecD3" onclick="AddRecAccCode()" class="button"><input name="txtAddRecAccNm" size="19" readonly class="bgcolor1"></td>
										</tr>
										<tr>
										<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;Adv Amount</p></td>
										<td width="30%"><input id ="txtAdvAmt" name="txtAdvAmt" size="9" value="" class="txtautofill"  maxlength=16 onkeypress="numdec(window.document.frmTenant.txtAdvAmt.value)"></td>
									
										<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;No Of Ins</p></td>
										<td width="30%"><input id ="txtnoofins" name="txtnoofins" size="9" value="" class="txtautofill" onblur="GetInsAmt()" maxlength = 2 onkeypress="numeric(window.document.frmTenant.txtnoofins.value)" ></td>
										</tr>	
										<tr>
										<td width="20%" align="left"><p>&nbsp;&nbsp;&nbsp;Adv Ins Amt</p></td>
										<td width="30%"><input id ="txtadvinsamt" name="txtadvinsamt" size="9" value="" class="txtautofill" readonly></td>				
										<td width="20%"><p align="left">&nbsp;&nbsp;&nbsp;Recovery UpTo</p> </td>
										
											<td width="30%"><input  type="text" name="txtRecUpto" maxlength="15" size="12" style="TEXT-ALIGN: left" class="txtautofill" onblur="datecheck(this);" readonly>(DDMMYYYY)</td>
										
															
														</tr>
														<tr>
														<td width="20%">&nbsp;&nbsp;&nbsp;Status</td>
															<td width="30%"><select size="1" name="cmbAdvRecFlag" >
																				<option value="R">Running</option>
																				<option value="C">Close</option>
																			</select></td>
														</tr>
													</table>
												
												</div> 
										</td>
										</tr>
									</table>
									
									<table>
										<tr>
											<td width="100%" align="center"><input name="butDedct" id = "butDedct" type="button" value="   Add   " class="button" onclick="AddToDed()"><input name="butCancel" id = "butCancel" type="button" value="   Cancel   " class="button" onclick="clear2()"></td>
										</tr>
										<tr>
											<td width="100%" align="center">&nbsp;&nbsp;</td>
										</tr>
										<tr>
											<td width="100%" align="center">
											<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgTenant name=mfgTenant style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 1000px" width=1000 VIEWASTEXT>
											<PARAM NAME="_ExtentX" VALUE="15055">
											<PARAM NAME="_ExtentY" VALUE="3757">
											<PARAM NAME="BackColor" VALUE="-2147483643">
											<PARAM NAME="ForeColor" VALUE="-2147483640">
											<PARAM NAME="Enabled" VALUE="-1">
											<PARAM NAME="BackStyle" VALUE="0">
											<PARAM NAME="BorderStyle" VALUE="1">
											<PARAM NAME="AllowBigSelection" VALUE="-1">
											<PARAM NAME="AllowUserResizing" VALUE="1">
											<PARAM NAME="Appearance" VALUE="1">
											<PARAM NAME="BackColorBkg" VALUE="8421504">
											<PARAM NAME="BackColorFixed" VALUE="-2147483633">
											<PARAM NAME="BackColorSel" VALUE="-2147483635">
											<PARAM NAME="CausesValidation" VALUE="-1">
											<PARAM NAME="Cols" VALUE="1">
											<PARAM NAME="ColWidth0" VALUE="1725">
											<PARAM NAME="DrawMode" VALUE="0">
											<PARAM NAME="FillStyle" VALUE="0">
											<PARAM NAME="FixedCols" VALUE="0">
											<PARAM NAME="FixedRows" VALUE="1">
											<PARAM NAME="FocusRect" VALUE="1">
											<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
											<PARAM NAME="ForeColorSel" VALUE="-2147483634">
											<PARAM NAME="FormatString" VALUE="Slno   |<Br  Code     |<Mod Id       |<Gl code     |<Acc  No.       |> Amount           |<Gst Y/N   |<Rev GstY/N  |< Tds                 |< Payed UPto     |<Rec BrCode     |< Rec ModID    |< Rec GLCode     |< Rec AccNo    |> Adv  Amt     |< No Of Ins |> Adv Ins Amt  |<   RecUpto   |<Rec Status |< Tenant Brcode ">
											<PARAM NAME="GridColor" VALUE="12632256">
											<PARAM NAME="GridColorFixed" VALUE="0">
											<PARAM NAME="GridLines" VALUE="1">
											<PARAM NAME="GridLinesFixed" VALUE="2">
											<PARAM NAME="GridLineWidth" VALUE="1">
											<PARAM NAME="MergeCells" VALUE="0">
											<PARAM NAME="MergeCol0" VALUE="0">
											<PARAM NAME="MergeRow0" VALUE="0">
											<PARAM NAME="MousePointer" VALUE="0">
											<PARAM NAME="OLEDropMode" VALUE="0">
											<PARAM NAME="PictureType" VALUE="0">
											<PARAM NAME="Redraw" VALUE="-1">
											<PARAM NAME="RightToLeft" VALUE="0">
											<PARAM NAME="RowHeightMin" VALUE="0">
											<PARAM NAME="Rows" VALUE="1">
											<PARAM NAME="ScrollBars" VALUE="3">
											<PARAM NAME="ScrollTrack" VALUE="0">
											<PARAM NAME="SelectionMode" VALUE="0">
											<PARAM NAME="TextStyle" VALUE="0">
											<PARAM NAME="TextStyleFixed" VALUE="0">
											<PARAM NAME="ToolTipText" VALUE="">
											<PARAM NAME="WhatsThisHelpID" VALUE="0">
											<PARAM NAME="WordWrap" VALUE="0">
											<PARAM NAME="ColAlignment0" VALUE="9">
											<PARAM NAME="ColData0" VALUE="0">
											<PARAM NAME="FixedAlignment0" VALUE="4">
											<PARAM NAME="FontWidth" VALUE="0">
											<PARAM NAME="hWnd" VALUE="0">
											<PARAM NAME="RowData0" VALUE="0">
											<PARAM NAME="RowHeight0" VALUE="240">
											<PARAM NAME="TextArray0" VALUE="S.No">
											<PARAM NAME="TextMatrix0" VALUE="S.No">
											<PARAM NAME="row" VALUE="">
											<PARAM NAME="col" VALUE="">
											<PARAM NAME="RowSel" VALUE="">
											<PARAM NAME="ColSel" VALUE="">
											<PARAM NAME="CellBackColor" VALUE="">
											<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
									
								
								</div>
							</td>
						</tr>
					</table>
					
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%">
							<div align="center">
								<center>	
								<table border="0" border="0" cellpadding="0" cellspacing="0" width="17%">
									<tr>
										<td width="100%" ><input name="cmdok" type="button" value="   OK   " class="button" onclick="subtrans();"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmTenantmast.aspx&quot;"><input type="button" value="  Exit  " name="cmdExit" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button"></td>
									</tr>
								</table>
								</center>
							</div>
							</td>
						</tr>
					</table>
					<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=300 width=300></iframe>
					<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="../GENSBCA/querydisplay.aspx"></iframe>
					<input type="hidden" name="hpr" value="<%=session("precision")%>">
					<input type="hidden" name="htabname" value>
					<input type="hidden" name="hfldname" value>
					<input type="hidden" name="hfldvalues" value>
					<input type="hidden" name="hmode" value>
					<input type="hidden" name="hdnrow" value>
					<input type="hidden" name="mercust">
					<input type="hidden" name="hidDate">
					<div class="footer">
						<div class="logo"></div>
						<div class="copyRight">
							&copy; E-Smart Banker - A Product of SAS Enterprises
						</div>
					</div>
				</td>
			</tr>
		</table>

    </form>

  </body>
</html>
