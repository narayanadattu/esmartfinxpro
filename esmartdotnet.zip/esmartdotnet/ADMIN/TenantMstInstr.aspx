<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="TenantMstInstr.aspx.vb" Inherits="eSmartDotNet.TenantMstInstr"%>
<%

dim obj,obj1,obj2,obj3,obj4,rs,rs1,rs2,rs3,Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno,strs
dim strtntbrcode
obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj2 = server.CreateObject("ReportPurposeOnly.Reportonly")

obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
obj3=server.CreateObject("queryrecordsets.fetchrecordsets")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")

dim Arrtrans(100,4)

appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("hmode")
strval=split(strmode,"|")

dim i
	strdelvar= split(Request.Form("mercust"),"|")

dim strsessbrcode,strbrcode ,strmodid ,strglcode ,straccno ,stramount ,strgstyn ,strrevgstyn ,strtds ,strpayedupto ,strrecbrcode ,strrecmodid ,strrecglcode ,strrecaccno ,stradvamount ,strrecupto ,strrecstatus,strrecsysdate
dim strTENANTID
dim strtenantvals,strtenantadvreclnkvals
strtenantvals = "" : strtenantadvreclnkvals = ""

if strval(0)="INSERT" then

strTENANTID = ""
  strsql = "SELECT 'T'  || LPAD(NVL(MAX(SUBSTR(TENANTID, 2)),0)+1,4,'0') FROM TENANTADVRECVLNK "
rs=obj2.SingleSelectStat(strsql)
if not rs.eof and not rs.bof then
	strTENANTID = rs(0).value
end if
rs.close()
rs = nothing

for k =  0 to ubound(strdelvar)
strsessbrcode = "" : strbrcode = "" : strmodid = "" : strglcode = "" : straccno = "" : stramount = "" : strgstyn = "" : strrevgstyn = "" : strtds = "" : strpayedupto = "" : strrecbrcode = "" : strrecmodid = "" : strrecglcode = "" : strrecaccno = "" : stradvamount = "" : strnoofins  = "" : stradvinsamt = "" : strrecupto = "" : strrecstatus = "" : strrecsysdate = "" : strtntbrcode = ""

strdtlval = split(strdelvar(k), ",")

strtntbrcode = strdtlval(0)
strbrcode = strdtlval(1)
strmodid = strdtlval(2)
strglcode = strdtlval(3)
straccno = strdtlval(4)
stramount = strdtlval(5)
strgstyn = strdtlval(6)
strrevgstyn = strdtlval(7)
strtds = strdtlval(8)
strpayedupto = strdtlval(9)
stropdate = strdtlval(10)
strstatus = strdtlval(11)
strappdate = strdtlval(12)
struserid =  strdtlval(13)
strmacid =  strdtlval(14)
strrecbrcode = strdtlval(15)
strrecmodid = strdtlval(16)
strrecglcode = strdtlval(17)
strrecaccno = strdtlval(18)
stradvamount = strdtlval(19)
strnoofins = strdtlval(20)
stradvinsamt = strdtlval(21)
strrecupto = strdtlval(22)
strrecstatus = strdtlval(23)
strrecsysdate = strdtlval(24)


if strrecbrcode <> "" then
strtenantvals = strtenantvals & "'" & strtntbrcode & "','" & strbrcode & "','" & strmodid & "','" & strglcode & "','" & straccno & "','" & stramount & "','" & strgstyn & "','" & strrevgstyn & "','" & strtds & "','" & strpayedupto  & "','" & stropdate  & "','" & strstatus  & "','" & strappdate  & "','" & struserid  & "','" & strmacid  & "','" & strTENANTID & "'" & "|"

strtenantadvreclnkvals = strtenantadvreclnkvals & "'" & strTENANTID & "','" & strrecbrcode & "','" & strrecmodid & "','" & strrecglcode & "','" & strrecaccno & "','" & stradvamount  & "','" & strnoofins  & "','" & stradvinsamt & "','" & strrecupto & "','" & strrecstatus  & "'," & strrecsysdate & "|"

strTENANTID = mid(strTENANTID,2,4) 
  strsql = "SELECT  'T'  ||   LPAD(to_number(" & strTENANTID & ")+1,4,'0') FROM  dual"
rs=obj2.SingleSelectStat(strsql)
if not rs.eof and not rs.bof then
	strTENANTID = rs(0).value
end if
rs.close()
rs = nothing

else
strtenantvals = strtenantvals & "'" & strtntbrcode & "','" & strbrcode & "','" & strmodid & "','" & strglcode & "','" & straccno & "','" & stramount & "','" & strgstyn & "','" & strrevgstyn & "','" & strtds & "','" & strpayedupto  & "','" & stropdate  & "','" & strstatus  & "','" & strappdate  & "','" & struserid  & "','" & strmacid  & "',''" & "|"
end if 

next k

strtenantvals = mid(strtenantvals,1,Len(strtenantvals)-1)
if Len(strtenantadvreclnkvals) > 0 then
	strtenantadvreclnkvals = mid(strtenantadvreclnkvals,1,Len(strtenantadvreclnkvals)-1)
end if


		if strval(1)="TENANT" then
				strcolnames="BRANCHCODE, CRBRANCHCODE, MODULEID, GLCODE, ACCNO, AMOUNT, GSTYN, REVGSTYN, TDS, DUEDATE, OPDATE , STATUS, APPLICATIONDATE, USERID, MACHINEID,TENANTID"
				strcolnamesrec = "TENANTID, BRANCHCODE, MODULEID, GLCODE, ACCNO,RECADVAMT, NOOFINST, ADVINSAMT, RECVUPTO, STATUS, SYSTEMDATE"
			 
				Arrtrans(0,0)="I"			
				Arrtrans(0,1)="TENANTMST"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strtenantvals
				Arrtrans(0,4)=""
				if strtenantadvreclnkvals <> "" then
				Arrtrans(1,0)="I"			
				Arrtrans(1,1)="TENANTADVRECVLNK"
				Arrtrans(1,2)=strcolnamesrec
				Arrtrans(1,3)=strtenantadvreclnkvals
				Arrtrans(1,4)=""
				end if
		end if
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
			
			Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
			Response.Write (Strmsg)	
			obj=nothing
end if 		 
	
if strval(0)="MODIFY" then


	
		if strval(1)="TENANT" then 
			
		
			strdelvar=Request.Form("mercust") 
			
			upval = split(strdelvar,"|")
			
			cnt=upval.length
			
			'dim i
			i=0
			k=0
				
		
			for i = 0 to cnt-1
				
				udata = split(upval(i),",")
				
				if udata(21) <> "" then
				strcolnames="AMOUNT, GSTYN, REVGSTYN, TDS, DUEDATE, CLOSEDATE , STATUS, USERID, MACHINEID"
				strcolnamesrec = "BRANCHCODE, MODULEID, GLCODE, ACCNO, RECADVAMT,NOOFINST, ADVINSAMT,  RECVUPTO, STATUS"
				
				strCondrec = " TENANTID = '"& udata(21) &"'"
				strtenantadvreclnkvals = "'"& udata(12) &"'~'"& udata(13) &"'~'"& udata(14) &"'~'"& udata(15) &"'~'"& udata(16)  &"'~'"& udata(17) &"'~'"& udata(18)  &"'~'"& udata(19) &"'~'"& udata(20) &"'"
				Arrtrans(k,0)="U"			
				Arrtrans(k,1)="TENANTADVRECVLNK"
				Arrtrans(k,2)=strcolnamesrec
				Arrtrans(k,3)=strtenantadvreclnkvals
				Arrtrans(k,4)=strCondrec
				
				k = k+1
				
			
				strCond = " STATUS='R' and ACCNO = '"& udata(4) &"' and GLCODE = '"& udata(3) &"' and MODULEID = '"& udata(2) &"' and CRBRANCHCODE = '"& udata(1) &"' and BRANCHCODE = '"& udata(0) &"'"
				
				strdelvar = "'"& udata(5) &"'~'"& udata(6) &"'~'"& udata(7) &"'~'"& udata(9) &"'~'"& udata(8) &"'~'"& udata(11) &"'~'"& udata(10) &"'~'" & userid & "'~'" & machineid & "'"
				
				Arrtrans(k,0)="U"			
				Arrtrans(k,1)="TENANTMST"
				Arrtrans(k,2)=strcolnames
				Arrtrans(k,3)=strdelvar
				Arrtrans(k,4)=strCond
		
				k = k +1
				
				
				
				else
				
				if udata(12) = "" then
						strCond = " STATUS='R' and ACCNO = '"& udata(4) &"' and GLCODE = '"& udata(3) &"' and MODULEID = '"& udata(2) &"' and CRBRANCHCODE = '"& udata(1) &"' and BRANCHCODE = '"& udata(0) &"'"
						
						strdelvar = "'"& udata(5) &"'~'"& udata(6) &"'~'"& udata(7) &"'~'"& udata(9) &"'~'"& udata(8) &"'~'"& udata(11) &"'~'"& udata(10) &"'~'" & userid & "'~'" & machineid & "'"
						
						Arrtrans(k,0)="U"			
						Arrtrans(k,1)="TENANTMST"
						Arrtrans(k,2)=strcolnames
						Arrtrans(k,3)=strdelvar
						Arrtrans(k,4)=strCond
				
						k = k +1
				else
				
				strTENANTID = ""
					strsql = "SELECT 'T'  || LPAD(NVL(MAX(SUBSTR(TENANTID, 2)),0)+1,4,'0') FROM TENANTADVRECVLNK "
					rs=obj2.SingleSelectStat(strsql)
					if not rs.eof and not rs.bof then
						strTENANTID = rs(0).value
					end if
					rs.close()
					rs = nothing
				
				strcolnames="AMOUNT, GSTYN, REVGSTYN, TDS, DUEDATE, CLOSEDATE , STATUS, USERID, MACHINEID,TENANTID"
				strcolnamesrec = "TENANTID,BRANCHCODE, MODULEID, GLCODE, ACCNO, RECADVAMT,NOOFINST, ADVINSAMT,  RECVUPTO, STATUS"
				strtenantadvreclnkvals = "'" & strTENANTID & "','"& udata(12) &"','"& udata(13) &"','"& udata(14) &"','"& udata(15) &"','"& udata(16)  &"','"& udata(17) &"','"& udata(18)  &"','"& udata(19) &"','"& udata(20) &"'"
				
				Arrtrans(k,0)="I"			
				Arrtrans(k,1)="TENANTADVRECVLNK"
				Arrtrans(k,2)=strcolnamesrec
				Arrtrans(k,3)=strtenantadvreclnkvals
				Arrtrans(k,4)=strCondrec
				
				k = k+1
				
				strCond = " STATUS='R' and ACCNO = '"& udata(4) &"' and GLCODE = '"& udata(3) &"' and MODULEID = '"& udata(2) &"' and CRBRANCHCODE = '"& udata(1) &"'" 
				
				strdelvar = "'"& udata(5) &"'~'"& udata(6) &"'~'"& udata(7) &"'~'"& udata(9) &"'~'"& udata(8) &"'~'"& udata(11) &"'~'"& udata(10) &"'~'" & userid & "'~'" & machineid & "'~'" & strTENANTID & "'"
				
				Arrtrans(k,0)="U"			
				Arrtrans(k,1)="TENANTMST"
				Arrtrans(k,2)=strcolnames
				Arrtrans(k,3)=strdelvar
				Arrtrans(k,4)=strCond
		
				k = k +1
				
				end if ''udata(12) = ""
				end if  ''udata(21) <> ""
			next 
			
		end if
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
		
	Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		 obj=nothing


end if

	Response.Redirect ("frmTenantmast.aspx?record=" & Strmsg)

%>
