<%@ Page Language="vb" explicit="false" aspcompat="true" AutoEventWireup="false" Codebehind="frmCardApprove.aspx.vb" Inherits="eSmartDotNet.frmCardApprove" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>frmCardApprove</title>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <SCRIPT LANGUAGE="javascript"   src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE="javascript"   src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="javaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="javaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="javaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	function Branch()
{  	
	
	window.document.frmCardAproval.mfgins.rows=1
        telbr="Tellerbranch";
	   window.showModalDialog("../GEN/Listquery.aspx"+"?"+"st="+telbr,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
 }
 //Assign Selected Branch code and Branch desc to the Textboxes.
	 
function Branchcode(kstr)
 { 
	  assign(kstr,window.document.frmCardAproval.txtbranchdesc,
	  window.document.frmCardAproval.txtbranchcode)
		
 }
	function Refresh()
	{
		var strType
		
		/*if(window.document.frmCardAproval.radType[0].checked==true)
			strType="R"
		else if(window.document.frmCardAproval.radType[1].checked==true)
			strType="C"*/
			
		window.document.frmCardAproval.mfgins.rows=1
		var st="ATMCARDTLS"+"|"+window.document.frmCardAproval.txtbranchcode.value+"|"
		st=st+window.document.frmCardAproval.txtcurrencycode.value//+"|"+strType
		
		window.document.all['idetails'].src = "../GEN/getDtls1.aspx?st="+st
	}
	
	function popGridDisplay(str)
	{ 
		if(str=="No Records")
		{
			alert("No Records Found.")
			return;
		}
		var arrStrRows,arrStrCols
		arrStrRows=str.split("|")
			for(iCnt=0;iCnt<=arrStrRows.length-1;iCnt++)
			{
			window.document.frmCardAproval.mfgins.rows=window.document.frmCardAproval.mfgins.rows+1
			arrStrCols=arrStrRows[iCnt].split("~")
				for(jCnt=0;jCnt<=arrStrCols.length-1;jCnt++)
				{
					window.document.frmCardAproval.mfgins.TextMatrix(iCnt+1,0)=iCnt+1
					window.document.frmCardAproval.mfgins.TextMatrix(iCnt+1,1)="A"
					window.document.frmCardAproval.mfgins.TextMatrix(iCnt+1,jCnt+2)=arrStrCols[jCnt]
				}
			}
		//window.document.frmCardAproval.mfgins.rows=window.document.frmCardAproval.mfgins.rows-1
	}
	
	function mfgins_DblClick()
	{
	var selRow=window.document.frmCardAproval.mfgins.Row
		if(window.document.frmCardAproval.mfgins.TextMatrix(selRow,1)=="A")
		{
		window.document.frmCardAproval.mfgins.TextMatrix(selRow,1)="P"
		//window.document.frmCardAproval.mfgins.Row.style.backgroundColor="blue"
		selRow.style.backgroundColor="blue"
		}
		else if(window.document.frmCardAproval.mfgins.TextMatrix(selRow,1)=="P")
		{
		window.document.frmCardAproval.mfgins.TextMatrix(selRow,1)="A"
		}
	}
	
	function Approve()
	{
	var strAccnos
	strAccnos=""
		if(window.document.frmCardAproval.mfgins.rows==1)
		{
		alert("Please Fill The Grid")
		return;
		}
		
		for(kCnt=1;kCnt<window.document.frmCardAproval.mfgins.rows;kCnt++)
		{
			if(window.document.frmCardAproval.mfgins.TextMatrix(kCnt,1)=="A")
			strAccnos=strAccnos+"'"+window.document.frmCardAproval.mfgins.TextMatrix(kCnt,2)+"',"
		}
		strAccnos=strAccnos.substring(0,strAccnos.length-1)
		
		if(strAccnos=="")
		{
			alert("Please Set Atleast One Tran Status 'A'")
			return;
		}
		
		var st="Approve"+"|"+window.document.frmCardAproval.txtbranchcode.value+"|"
		st=st+"|("+strAccnos+")"
		
		window.document.all['idetails'].src="CardAproval.aspx?st="+st;
	}
	
	function ApprStatus(str)
	{
	    alert(str)
	    location.href ="frmCardApprove.aspx"
	}
	
	function Cancel()
	{
		location.href ="frmCardApprove.aspx"
	}
	
	</script>
	<SCRIPT LANGUAGE=javascript FOR=mfgins EVENT=DblClick>
		mfgins_DblClick()
	</SCRIPT>
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;)">

    <form id="frmCardAproval" name="frmCardAproval">
     <div class="header">
        <table  cellpadding="0" cellspacing="0" width="99%">
			<tr>
				<td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td>
			</tr>
		</table>
	</div>
   
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY:visible"><%=vTotAmt%></span></td>
					<td width="40%" align="center" height="22" class="subHeader"><h2>ATM Card approval</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		 <div id="menucontrol"></div>
		<table border="0" width="100%" class="tablebordermain"><!-- table1-->
			<!---<tr>
				<td width="100%">
				<table border="0" width="100%" cellspacing="0" cellpadding="0"><!-- table2-->
				<!--	<tr class="bgcolor">
					<td width="100%" nowrap colspan="3" height="28"><img border="0" height="22" name="placeholder" src="transparent.gif" width="1"></td>
					</tr>
					
				</table><!-- table2-->
			<!--	</td></tr>
				<tr><td height="10"></td></tr> --->
				<tr><td>
				<table align="center" border="0" width="98%" cellspacing="0" cellpadding="0" class="tableborder2"><!-- table3-->
                  <tr class="bgcolor">
                    <td width="15%" height="27" align="center">&nbsp;Branch Code</td>
                    <td width="34%" height="27"><input name="txtbranchcode" size="9" onkeyup='window.document.frmTrans.txtbranchdesc.value=""' class="txtautofill" value="<%=session("branchcode")%>" onkeypress="Alphanum()" maxlength="10" onblur="Dataarrange(txtbranchcode);DescrptionDisp(&quot;txtbranchcode&quot;)"><input type="button" value=" L " name="buttbr" onclick="Branch()"  class="button"><input name="txtbranchdesc" class="bgcolor1" onmouseover='disptooltiptext(txtbranchdesc)' size="16" value="<%=session("branchnarration")%>" readonly></td>
                    <td width="19%" align="center" height="27">Currency Code&nbsp;</td>
                    <td width="30%" height="27"><input name="txtcurrencycode" onkeyup='window.document.frmTrans.txtcurrencydesc.value=""'  style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" class="txtautofill" value="<%=session("currencycode")%>" onkeypress="Alphanum()" size="9" maxlength="10" onblur="Dataarrange(txtcurrencycode);DescrptionDisp(&quot;txtcurrencycode&quot;)"><input type="button" value=" L " name="buttcur" onclick="curr()" class="button"><input name="txtcurrencydesc" onmouseover='disptooltiptext(txtcurrencydesc)' size="16" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
                  </tr>
                </table><!-- table3-->
                </td></tr>
                <tr><td height="10"></td></tr>
               <!--- <tr><td>
					<table align="center" width="98%" class="tableborder1">
						<tr>
							<td width="30%" align="right"><input type="radio" name="radType" onclick="ClrFlds()" checked>New</td>
							<td width="40%"></td>
							<td width="30%"><input type="radio" name="radType" onclick="ClrFlds()">Terminated</td>
						</tr>
					</table>
                </td></tr>
				<tr><td height="10"></td></tr>   --->
				<tr><td width="100%" align="center"><input type="button" value="Refresh" name="btnRefresh" class="button" onclick="Refresh()"></td></tr>
				<tr><td height="10"></td></tr>
				<tr><td width="100%">
				<table class="tableborder2" align="center" width="98%"><!-- table4-->
				<tr><td width="100%" align="center">
				<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=250 id=mfgins name=mfgins 
				style="HEIGHT: 250px; LEFT: 0px; TOP: 0px; WIDTH: 960px" width=960 VIEWASTEXT>
				<PARAM NAME="_ExtentX" VALUE="15055">
				<PARAM NAME="_ExtentY" VALUE="3757">
				<PARAM NAME="BackColor" VALUE="-2147483643">
				<PARAM NAME="ForeColor" VALUE="-2147483640">
				<PARAM NAME="Enabled" VALUE="-1">
				<PARAM NAME="BackStyle" VALUE="0">
				<PARAM NAME="BorderStyle" VALUE="1">
				<PARAM NAME="AllowBigSelection" VALUE="-1">
				<PARAM NAME="AllowUserResizing" VALUE="0">
				<PARAM NAME="Appearance" VALUE="1">
				<PARAM NAME="BackColorBkg" VALUE="8421504">
				<PARAM NAME="BackColorFixed" VALUE="-2147483633">
				<PARAM NAME="BackColorSel" VALUE="-2147483635">
				<PARAM NAME="CausesValidation" VALUE="-1">
				<PARAM NAME="Cols" VALUE="12">
				<PARAM NAME="ColWidth0" VALUE="1725">
				<PARAM NAME="DrawMode" VALUE="0">
				<PARAM NAME="FillStyle" VALUE="0">
				<PARAM NAME="FixedCols" VALUE="0">
				<PARAM NAME="FixedRows" VALUE="1">
				<PARAM NAME="FocusRect" VALUE="1">
				<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
				<PARAM NAME="ForeColorSel" VALUE="-2147483634">
				<PARAM NAME="FormatString" VALUE="S.No  |< Tran Status |<Ref Num    |< Title  |< Name                         |<  Acc No                 |<Glcode      |<Module Id  |< Address                                                                                 |< Mail Address                                                                  |<Name On Card                                              |< Card No                                  ">
				<PARAM NAME="GridColor" VALUE="12632256">
				<PARAM NAME="GridColorFixed" VALUE="0">
				<PARAM NAME="GridLines" VALUE="1">
				<PARAM NAME="GridLinesFixed" VALUE="2">
				<PARAM NAME="GridLineWidth" VALUE="1">
				<PARAM NAME="MergeCells" VALUE="0">
				<PARAM NAME="MergeCol0" VALUE="0">
				<PARAM NAME="MergeRow0" VALUE="0">
				<PARAM NAME="MousePointer" VALUE="0">
				<PARAM NAME="OLEDropMode" VALUE="0">
				<PARAM NAME="PictureType" VALUE="0">
				<PARAM NAME="Redraw" VALUE="-1">
				<PARAM NAME="RightToLeft" VALUE="0">
				<PARAM NAME="RowHeightMin" VALUE="0">
				<PARAM NAME="Rows" VALUE="1">
				<PARAM NAME="ScrollBars" VALUE="3">
				<PARAM NAME="ScrollTrack" VALUE="0">
				<PARAM NAME="SelectionMode" VALUE="0">
				<PARAM NAME="TextStyle" VALUE="0">
				<PARAM NAME="TextStyleFixed" VALUE="0">
				<PARAM NAME="ToolTipText" VALUE="">
				<PARAM NAME="WhatsThisHelpID" VALUE="0">
				<PARAM NAME="WordWrap" VALUE="0">
				<PARAM NAME="ColAlignment0" VALUE="9">
				<PARAM NAME="ColData0" VALUE="0">
				<PARAM NAME="FixedAlignment0" VALUE="9">
				<PARAM NAME="FontWidth" VALUE="0">
				<PARAM NAME="hWnd" VALUE="0">
				<PARAM NAME="RowData0" VALUE="0">
				<PARAM NAME="RowHeight0" VALUE="240">
				<PARAM NAME="TextArray0" VALUE="S.No">
				<PARAM NAME="TextMatrix0" VALUE="S.No">
				<PARAM NAME="row" VALUE="">
				<PARAM NAME="col" VALUE="">
				<PARAM NAME="RowSel" VALUE="">
				<PARAM NAME="ColSel" VALUE="">
				<PARAM NAME="CellBackColor" VALUE="">
				<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
				</td></tr>
				</table>
				</td></tr><!-- table4-->
			<tr><td align="center"><input type="button" value="Approve" name="btnApprove" class="button" onclick="Approve()"><input type="button" value=" Cancel " name="btnCancel" class="button" onclick="Cancel()"><input type="button" value="     Exit     " name="btnExit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td></tr>
							
			<tr><td>
			
			 <IFRAME src="SIApprQuery.aspx" id="idetails" align=center style="DISPLAY:none" frameBorder=0 frameSpacing=0 height=300 noResize style="COLOR: #c7ba95; HEIGHT: 300px; LEFT: 100px; TOP: 100px; WIDTH: 300px" width=300 valign="top"></td></tr></table>
						
		</table><!-- table1-->
		<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
    </form>

  </body>
</html>