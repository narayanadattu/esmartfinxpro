<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmBRIMPSRefTracking.aspx.vb" Inherits="eSmartDotNet.frmBRIMPSRefTracking"%>
<%

 Dim objhotraw As New GENVALIDATIONS.Validations
 dim strMainBrCode 
''strMainBrCode = "101"
'' modified by dattu 24-nov-22
        '' HO Trans Allowed
        strMainBrcode = objhotraw.GetHOTRALWBrCode()
        
        dim strvals
strvals = Request.QueryString("st")	

dim strmessage
strmessage=Request.QueryString("record")

dim rsAuto, objAuto
dim cntimp
rsAuto=Server.CreateObject("ADODB.Recordset")
objAuto=server.CreateObject("ReportPurposeOnly.Reportonly")

strSql="select count(*) from GENUSERMST where groupid in ('MGR','ADMIN') and branchcode = '"& strMainBrcode &"' and status in ('A') and userid = '"& session("userid") &"'"

rsAuto=objAuto.SingleSelectStat(strSql)
if objAuto.ConnError="Connected" then
	if not rsAuto.bof and not rsAuto.eof then
		cntimp=rsAuto(0).value
	end if
end if
dim impsmessage
impsmessage= "No"
objrep = server.CreateObject("ReportPurposeOnly.Reportonly")
rsins=server.CreateObject("adodb.recordset")
     rsins1=server.CreateObject("adodb.recordset")
 sqlStr="SELECT * FROM impsbrchanconntemp"
rsins1=objrep.SingleSelectStat(sqlStr)
if not rsins1.eof and not rsins1.bof  then
    
sqlStr="SELECT (b.sysdt-a.transdate)  * 1440 timediff1 FROM (SELECT MAX(transdate) transdate FROM impsbrchanconntemp) a,(SELECT SYSDATE sysdt FROM dual) b"
rsins=objrep.SingleSelectStat(sqlStr)
if rsins.EOF<>true and rsins.BOF<>true then
	if cint(iif(isdbnull(rsins(0).value),0,rsins(0).value)) <= 3 then
 		impsmessage= "Yes"
		else
		impsmessage= "No"
	end if		
	else
		impsmessage="No"	
end if
rsins =  nothing
end if
rsins1 =  nothing
%>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>IMPS Reference No Outward Reversal</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	
function toDateDisp()
{
	
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
			window.document.frmCardfilegen.txtToDate.disabled=true
		}
		else
		{
			window.document.frmCardfilegen.txtToDate.disabled=false
		}
	
}

function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)



var intRefnd=getDateDiff(window.document.frmCardfilegen.txtFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmCardfilegen.txtFromDate.value=""
				window.document.frmCardfilegen.txtFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmCardfilegen.txtToDate.value,window.document.frmCardfilegen.txtFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmCardfilegen.txtFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmCardfilegen.txtFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmCardfilegen.txtToDate.value=""
				window.document.frmCardfilegen.txtToDate.focus()
			}
		
}

	function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
//-->
	
	
	
	function Referenceno()
	{  
	var st;
	
	window.document.frmCardfilegen.txtrefcode.value =""
	window.document.frmCardfilegen.mfgatmtran.rows=1	
	
	
		//alert("hi")

		st="BRCHANIMPSRefTrack"
		
		
		
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:420px;DialogHeight:210px;DialogLeft:560px;DialogTop:190px")
	}
	
	function DisplayRefNo(kstr)
	{ 
	var kstr1  = kstr.split("-----")
	window.document.frmCardfilegen.txtrefcode.value = kstr1[1]
	}
		
	 function CheckIMPSConnection()
 {
 var strVal;
    strVal="CheckIMPSCon"+"~!~"
    window.document.all['iUpd'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"gendesc.aspx?strParam="+strVal
 }
 
	function GetCheckIMPSConnection(kstr)
 {
 window.document.frmCardfilegen.hdncheckimps.value = kstr
 if (kstr == "Yes")
 {
 document.getElementById("impscon").innerHTML = "IMPS Connected" 
 document.getElementById("impscon").style.color = "blue"
 QueRefTrans()
  }
 else
  {
 document.getElementById("impscon").innerHTML = "IMPS Not Connected" 
 document.getElementById("impscon").style.color = "red"
  }
 }
 
	
	function QueRefTrans()
	{
	
		window.document.frmCardfilegen.mfgatmtran.rows=1
		if(window.document.frmCardfilegen.rdmode(0).checked==true)
		{	
			if(window.document.frmCardfilegen.txtrefcode.value=="")
			{
				alert("Reference Code Should Not Be Null")
				window.document.frmCardfilegen.txtrefcode.focus()
				return;
			}
		strVal = "GetBRCHANIMPSByRefnoTrackDtls" + "|" + window.document.frmCardfilegen.txtrefcode.value
		}

		if(window.document.frmCardfilegen.rdmode(1).checked==true)
		{	
		strVal = "GetBRCHANIMPSByDateTrackDtls"+"|"+window.document.frmCardfilegen.cmbDate.value +"|"+ window.document.frmCardfilegen.txtFromDate.value +"|"+ window.document.frmCardfilegen.txtToDate.value
		}
	
	
	window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
	
	}	
	
	
	function DisplayIMPSDtls(str)
	{
	var strResult1=str.split("*")
var strResult=strResult1[1].split("|")
//alert(strResult1[0])
	// detail of IMPS
	if ((strResult1[0]  == "GetIMPSByDateDtls") || (strResult1[0]  == "GetBRCHANIMPSByRefnoTrackDtls")  || (strResult1[0]  == "GetBRCHANIMPSByDateTrackDtls"))
	{
		if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}

	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmCardfilegen.mfgatmtran.rows=window.document.frmCardfilegen.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,0) = "Y"
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,1)=aCnt+1   // sno
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,2)=strCols[0] // Refno
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,3)=Datepick1(strCols[1]) // app date
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,4)=strCols[2] // debit accno
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,5)=strCols[3] // acc name
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,6)=strCols[4] // ben accno
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,7)=strCols[5] // ben acc name
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,8)=strCols[6] // sentyn 
			window.document.frmCardfilegen.mfgatmtran.textmatrix(aCnt+1,9)=strCols[7] // serviceid
			
		}
		
	}
	
	}
	

	
	function initialcheck()
{
	window.document.frmCardfilegen.txtToDate.disabled=true
	window.document.frmCardfilegen.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmCardfilegen.txtToDate.value = "<%=session("applicationdate")%>"
}

	function Ok()
	{
	if (confirm("Once Approval Is Posted Records Are Not Deleted \n Do You want to Continue ?") == true)
			{
				if(confirm("Are You Sure") == true)
				{
					if(confirm("Are You Sure") == true)
					{
					
					}
					else
					{
						return;
					}
				}
				else
				{
					return;
				}
			}
			else
			{
				return;
			}

if(window.document.frmCardfilegen.rdmode(0).checked==true)
	{
		if(window.document.frmCardfilegen.txtrefcode.value=="")
		{
			alert("Reference Code Should Not Be Null")
			window.document.frmCardfilegen.txtrefcode.focus()
			return;
		}
	}

var RowCnt
RowCnt=window.document.frmCardfilegen.mfgatmtran.Rows;
var strPrm="";
    var strRow="";
    var strTot="";
    var flxRows=0
    var strPrm1 = ""
for(i=1;i<RowCnt;i++)
    {
       if(window.document.frmCardfilegen.mfgatmtran.TextMatrix(i,0) == "Y")   // 
       {
       strRow=""
			flxRows=eval(flxRows)+1
			strRow=strRow+window.document.frmCardfilegen.mfgatmtran.TextMatrix(i,2)+"~"+ //refno
			window.document.frmCardfilegen.mfgatmtran.TextMatrix(i,3) //appdate
			
       strPrm=strPrm+strRow+"|"
       }
     }  
	strPrm1 = strPrm + "~*~" + flxRows
	window.document.frmCardfilegen.hidpend.value =strPrm1;
	window.document.frmCardfilegen.action="frmBRIMPSRefTrackingInsert.aspx"
	window.document.frmCardfilegen.method="post"   
	window.document.frmCardfilegen.submit()
	}	


function message()
{
	if('<%=strmessage%>'!="")
	{
		var mess="<%=strmessage%>"
		alert(mess)
		location.replace("../ATM/frmIMPSRefNoOutwrdReversal.aspx")
	}
}

function GetReferenceno()
{
	if(window.document.frmCardfilegen.txtrefcode.value=="")
	{
		alert("Reference Code Should Not Be Null")
		return;
	}
window.document.frmCardfilegen.mfgatmtran.rows=1	

		

var vin= st +"|"+window.document.frmCardfilegen.txtrefcode.value 
window.document.all['iBatch'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function GetReferenceno1(kstr)
{
	if (kstr=="") 
	{
	alert("Invalid Reference No")
	window.document.frmCardfilegen.txtrefcode.value= ""
	
	return
	}
	else
	{

	}
}



function GetMode()
{
window.document.frmCardfilegen.txtFromDate.value = "<%=session("applicationdate")%>"
window.document.frmCardfilegen.txtToDate.value = "<%=session("applicationdate")%>"
window.document.frmCardfilegen.txtrefcode.value= ""
window.document.frmCardfilegen.mfgatmtran.Rows=1
window.document.frmCardfilegen.mfgatmtran.Cols=10

window.document.frmCardfilegen.mfgatmtran.formatstring = "AppYN|^S No   |<Ref No                   |< App Date               |< Debit Accno              |< Debit Name                                   |< Ben Accno              |< Ben Name                                              |> SentYN|<Serviceid"
 
	if(window.document.frmCardfilegen.rdmode(0).checked==true)
	{
	window.document.all.divrefno.style.display = "block"
	window.document.all.divbydate.style.display = "none"


	}

	if(window.document.frmCardfilegen.rdmode(1).checked==true)
	{
	window.document.all.divrefno.style.display = "none"
	window.document.all.divbydate.style.display = "block"
	
		
	}
}

function mfgatmtran_DblClick()
{
	var Rsel=window.document.frmCardfilegen.mfgatmtran.RowSel
	    var Csel=window.document.frmCardfilegen.mfgatmtran.ColSel

if (Csel == 0) // pend int to be postyn
		{
			if(window.document.frmCardfilegen.mfgatmtran.TextMatrix(Rsel,0)=="Y")
			{
					window.document.frmCardfilegen.mfgatmtran.TextMatrix(Rsel,0)="N"
		
			}
			else if(window.document.frmCardfilegen.mfgatmtran.TextMatrix(Rsel,0)=="N")
			{
					window.document.frmCardfilegen.mfgatmtran.TextMatrix(Rsel,0)="Y"
		
			}
		}
}

function form_load()
{
var strval = '<%=strvals%>'
	if (strval != '')
	{
		alert(strval)
	}
}

function IMPSMessage()
{

if('<%=impsmessage%>'=="Yes")
	{
 document.getElementById("impscon").innerHTML = "IMPS Connected" 
 document.getElementById("impscon").style.color = "blue"
 
  }
 else
  {
 document.getElementById("impscon").innerHTML = "IMPS Not Connected" 
 document.getElementById("impscon").style.color = "red"
  }

}
	</script>
	<SCRIPT LANGUAGE=javascript FOR=mfgatmtran EVENT=DblClick>
	<!--
	mfgatmtran_DblClick()
	//-->
	</script>
  </head>
    <body topmargin="0" leftmargin="0" onload="form_load();GetMenu(&quot;<%=session("menustring")%>&quot;);message();initialcheck();IMPSMessage();">
	<form name="frmCardfilegen">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<!--<td width="43%" align="left" height="22" class="subHeader"><h2>ATM/IMPS Branch Channel/ IMPS Mobile  Reference No Reversal</h2></td>-->
				<td width="43%" align="left" height="22" class="subHeader"><h2> Branch IMPS Reference Tracking</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
				<tr>
						<td width="100%" height="20" colspan="2">
						<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
						        <tr class="bgcolor1">
									<td width="30%" align="center"  ><input type="radio" name="rdmode" checked onclick="GetMode()"><font class="textblack">Ref No</font></td>  
									<td width="30%" align="center"  ><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">By Date</font></td>
								<td width = "30%" align ="center"> <b> <span id = "impscon"></span> </b> </td></tr>
						</table>
						</td>
				</tr>
					<tr>
						<td width="100%" height="20" colspan="2">&nbsp;</td>
					</tr>
					<tr>
						<td width="100%" height="20" colspan="2">
						<div id = "divrefno"  style = "display=block" > 
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr class="BGCOLOR">
									<td width="12%" align="right">Reference No&nbsp;&nbsp;</font></td>
									<td width="38%">&nbsp;<input name="txtrefcode" size="20" class="txtautofill" value="" maxlength="12" style="TEXT-ALIGN: right" onblur="GetReferenceno()" ><input type="button" value=" L " name="cmdrefno" onclick="Referenceno()" style="height: 22; width: 22" class="button"></td>
								</tr>
							</table>
							</div>
							<div id="divbydate"  style = "display=none">
							<table><tr>
								<td width="20%" align="right" height="27">Operator&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="10%"><select size="1" name="cmbDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select>
										</td>
										<td width="10%" align="left">&nbsp;From Date</td>
										<td width="10%"><input type="text" name="txtFromDate" id="txtFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
										<td width="10%">(DDMMYYYY)</td>
										<td width="10%"><p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p></td>
										<td width="10%">&nbsp;<input type="text" name="txtToDate" id="txtToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							</tr></table>
							</div>
													
						</td>
					</tr>
					<tr><td width="25%" colspan=2 align="center"><input type="button" name="btnQuery" value=" Query " onclick="CheckIMPSConnection()" class="button"></td></tr>
					<tr>
					<td colspan=2>
					<div id= "divmfgatmtran" style = "display=block">
				<table width ="100%">
						<tr>
							<td width="90%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=280 id=mfgatmtran name=mfgatmtran style="HEIGHT: 280px; LEFT: 0px; TOP: 0px; WIDTH: 1000px" width=1000 VIEWASTEXT>
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="9">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="AppYN|^S No   |<Ref No                   |< App Date               |< Debit Accno              |< Debit Name                                   |< Ben Accno              |< Ben Name                                              |> SentYN|<Serviceid">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="AppYN">
							<PARAM NAME="TextMatrix0" VALUE="AppYN">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
						</table>
						</div>
					</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center" colspan=2><input name="cmdOk" onclick="Ok()" type="button" value=" Post " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmIMPSRefNoOutwrdReversal.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
				 <tr>
                          <td width="100%" height="20" colspan="5">
                          <p align="center">
                 
                          </p>
                          </td>
                        </tr>
				</table>
			</div>
			</td>
		</tr>
		 <tr>
      <td width="100%">
                                              <iframe id="iUpd" align=center style="display:block"
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="gendesc.aspx">
                                              </iframe>
                                              
      </td>
          
    </tr>
	</table>
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<input type="hidden" name="hidRow">
	<input type = "hidden" name = "hidpend">
		<input type="hidden" name="hidServ">
		<input type = "hidden" name = "hdncheckimps" id ="hdncheckimps">
	 <iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDtls.aspx"></iframe>
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>
  </body>
</html>

