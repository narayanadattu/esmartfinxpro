Imports System.IO
Imports System.Web
Imports System.Web.UI.HtmlControls.HtmlInputFile

Public Class ReconcilReport
    Inherits System.Web.UI.Page

    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim objtran As OracleClient.OracleTransaction
    'Protected WithEvents txtResult As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txtInputVals As System.Web.UI.WebControls.TextBox
    Dim objconn As New OracleClient.OracleConnection
    Dim errmsg As String
    Dim o_errmsg1 As String
    Dim objStreamReader As StreamReader

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Try

            Dim strCurrFileName, strCurrFileExt, filePath, strQS, strArrQS() As String

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbConn.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If

            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")

            If strArrQS(0) = "READ" Then
                Dim impStatus As String
                impStatus = getDataForUpdate()

            ElseIf strArrQS(0) = "READEXCEL" Then
                Dim impStatus As String
                impStatus = getDataForInsert()
            End If

        Catch ex As Exception
            'txtResult.Text = ex.Message()
        End Try
    End Sub

    Private Function getDataForUpdate() As String
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        Dim dt As New DataTable

        Try

            Dim strCommServ, strCommMod, strCommGl, strCommBr, strCommGlDesc, strCommAcc, strCommAmt, strServMod, strServGl, strServGlDesc, strServAcc, strServPercent, strEffDate, strSrvTax, strAutoPostCharges, errmsg, strBatchNo, strTranNo1, strTranNo2, strTranNo3, commYN, servTaxYN, strtranno, strNam As String
            Dim brCode, curCode, drMod, drGl, drAcc, appDate, userId, machineID, brAbbcode, stOtalow As String
            Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg, stRefnum As String
            Dim dblComm, dblSrv, totDrAmt, stGstamt, stRevGstamt As Double
            Dim iCnt, jCnt, stMaxnum, stMxn As Integer
            Dim strtemp, strbill, grdRows, grdCols, strBal, strQS, strArrQS, strVal, strValDr, StrQuery, strEmpno, strEmprPf, strEmprEsi
            Dim strPF, strPtax, strDep, strLoan, strAdv, strTds, strmn, stryr, strGip, strOthd, strESI, strVPF As String
            Dim strSqlAcc, strNftsYN, strPayfield, strPayVal, strCommMod1, strCommGl1, strCommAcc1 As String
            Dim stBnam, stImpyn, stPamt, strAmtGst, strAmtRevGst, stRevYn, stPremark, stBPos
            Dim stPath, strLine, strData As String
            Dim r As Long
            Dim strDataArr As Object
            Dim strDataColArr As Object

            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")
            strVal = strArrQS(1).Split("|")
            brAbbcode = strVal(0)
            appDate = strVal(1)
            userId = strVal(2)
            machineID = strVal(3)
            brCode = strVal(4)
            stPath = strVal(5)

            objStreamReader = New StreamReader(stPath)

            'Read the first line of text.
            strLine = objStreamReader.ReadLine
            strData = ""
            'Continue to read until you reach the end of the file.
            Do While Not strLine Is Nothing

                'Write the line to the strdata
                strData = strData & strLine & "$"
                'Read the next line.
                strLine = objStreamReader.ReadLine
            Loop
            'Close the file.
            objStreamReader.Close()

            strValDr = Mid(strData, 1, strData.Length - 1)

            stBPos = strValDr.split("$")

            iCnt = UBound(stBPos)

            objtran = objconn.BeginTransaction()

            strPayfield = "BRANCHCODE, DRAWEEBANKMICR, PAYERDETAIL, SESSIONDATE, AMOUNT, CHEQUENO, EMPTY1, TC, EMPTY2, EMPTY3, NAME, EMPTY4, EMPTY5, SYSDATITEMBNKMICR, BASENO, APPLICATIONDATE, USERID, MACHINEID"

            For r = 0 To iCnt

                strDataColArr = Split(stBPos(r), "|")

                strPayVal = " '" & brCode & "','" & strDataColArr(0) & "','" & strDataColArr(1) & "','" & strDataColArr(2) & "','" & strDataColArr(3) & "','" & strDataColArr(4) & "','" & strDataColArr(5) & "','" & strDataColArr(6) & "','" & strDataColArr(7) & "','" & strDataColArr(8) & "','" & strDataColArr(9) & "','" & strDataColArr(10) & "','" & strDataColArr(11) & "','" & strDataColArr(12) & "','" & strDataColArr(13) & "'," & appDate & "," & userId & "," & machineID & ""

                StrInsert = "INSERT INTO INWCLGBULKDTLS (" & strPayfield & ") VALUES (" & strPayVal & ")"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

            Next

            objtran.Commit()
            'postTransaction = "Posted SuccessFully|" & strBatchNo
            Response.Redirect("atmwisereport.aspx?record=Transaction Completed")

        Catch ex As Exception

            objtran.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "").Replace("?", "")

            Response.Redirect("atmwisereport.aspx?record=" & o_errmsg1, False)

        End Try

    End Function

    Private Function getDataForInsert() As String
        Dim cn As System.Data.OleDb.OleDbConnection
        Dim cmd As System.Data.OleDb.OleDbDataAdapter
        Dim dt As New DataTable
        Dim vCnt, kCnt, recCnt As Integer
        Dim strColNames, strData, strResult, strSql, strSqlAcc, strNftsYN, strRel, strMod, strModres, strBGColor, strAcc, StrQuery, strAcct, strAccRes As String
        Dim strDataTab As System.Text.StringBuilder = New System.Text.StringBuilder
        Dim strQS, brAbbcode, appDate, userId, machineID, brCode, stPath, strArrQS, strVal, strPath

        Try
            strQS = Request.Form("postdata")
            strArrQS = strQS.Split("$")
            strVal = strArrQS(1).Split("|")
            brAbbcode = strVal(0)
            appDate = strVal(1)
            userId = strVal(2)
            machineID = strVal(3)
            brCode = strVal(4)
            strPath = strVal(5)

            ' objStreamReader = New StreamReader(stPath)

            cn = New System.Data.OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strPath & "; Extended Properties=Excel 12.0;Persist Security Info=False;")

            If cn.State = ConnectionState.Open Then cn.Close()

            cn.Open()

            Dim dtSheet As DataTable = cn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, Nothing)
            cmd = New System.Data.OleDb.OleDbDataAdapter("select * from [" & dtSheet.Rows(0).Item("TABLE_NAME") & "]", cn)
            cmd.Fill(dt)
            cn.Close()
            cn.Dispose()

            For Each row As DataRow In dt.Rows
                If dt.Rows.Item(0).ToString = "" Then
                    dt.Rows.Remove(row)
                ElseIf IsDBNull(dt.Rows.Item(0)) Then
                    dt.Rows.Remove(row)
                ElseIf dt.Rows.Item(0) Is Nothing Then
                    dt.Rows.Remove(row)
                End If
            Next
            strDataTab.Append("<table id=xlTab width=100% cellspacing=1 cellpadding=1>")
            strDataTab.Append("<tr>")

            strDataTab.Append("<th id=thData0 bgcolor=#BCF5A9>S No</th>")
            For vCnt = 0 To dt.Columns.Count() - 1
                strDataTab.Append("<th id=thData" & (vCnt + 1).ToString & " bgcolor=#BCF5A9>" & dt.Columns.Item(vCnt).ColumnName & "</th>")
            Next

            strDataTab.Append("</tr>")
            strData = ""

            Dim strRes As String

            For vCnt = 0 To dt.Rows.Count() - 1
                If Not IsDBNull(dt.Rows.Item(vCnt)(0)) Then

                    strRes = strRes & "'" & brCode & "',"

                    For kCnt = 0 To dt.Columns.Count() - 1
                        If kCnt = 6 Then
                            strRes = strRes & "TO_DATE('" & dt.Rows.Item(vCnt)(kCnt) & "','Mm-dd-yyyy hh:Mi:ss AM'),"
                        Else
                            strRes = strRes & "'" & dt.Rows.Item(vCnt)(kCnt) & "',"
                        End If


                    Next

                    strRes = Mid(strRes, 1, strRes.Length - 1)

                    strRes = strRes & "|"

                End If
            Next

            strRes = Mid(strRes, 1, strRes.Length - 1)

            Dim ArrTran(1, 4)
            Dim icnt

            icnt = 0

            Dim StrTabName, StrFldNames, StrFldValues, Strmsg, ObjTran, sqlStr

            ObjTran = Server.CreateObject("GeneralTransactions.DBTransactions")

            Dim obj2, condStbr, rscnt, rs, obj

            obj2 = Server.CreateObject("GeneralTransactions.DBTransactions")

            rscnt = Server.CreateObject("adodb.recordset")

            StrTabName = "ATMRECONCILATIONTEMP"
            StrFldNames = "BRANCHCODE, TRANSMODE, TERMINALID, CARDNUMBER, ACCNO, TRANSTYPE, AMOUNT, TRANSACTIONDATE, REFERENCENUMBER, RESPONSECODE, STATUS"
            StrFldValues = strRes

            StrQuery = "SELECT * from ATMRECONCILATIONTEMP"

            Dim objDr As OracleClient.OracleDataReader
            ExecuteSelectQuery(objDr, StrQuery)

            If objDr.HasRows = True Then
                objDr.Read()

                ArrTran(icnt, 0) = "D"         'passing the TransactionType
                ArrTran(icnt, 1) = StrTabName  'passing the tablename
                ArrTran(icnt, 2) = ""          'passing the FieldNames
                ArrTran(icnt, 3) = ""          'passing the Fieldvalues
                ArrTran(icnt, 4) = "1=1"
                icnt = icnt + 1

            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing

            ArrTran(icnt, 0) = "I"         'passing the TransactionType
            ArrTran(icnt, 1) = StrTabName  'passing the tablename
            ArrTran(icnt, 2) = StrFldNames 'passing the FieldNames
            ArrTran(icnt, 3) = StrFldValues 'passing the Fieldvalues
            ArrTran(icnt, 4) = ""

            Strmsg = obj2.DataTransactions(ArrTran)
            obj2 = Nothing

            cmd.Dispose()
            cmd = Nothing

            Response.Redirect("atmwisereport.aspx?record=" & Strmsg & "#" & strPath, False)

            Exit Function

        Catch ex As Exception
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "").Replace("?", "")

            Response.Redirect("atmwisereport.aspx?record=" & o_errmsg1 & "#" & strPath, False)
        End Try
    End Function

    Public Function ExecuteSelectQuery(ByRef objDrL As OracleClient.OracleDataReader, ByVal StrQuery As String)
        Dim errmsg As String
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If

        Dim objCmdES As OracleClient.OracleCommand

        objCmdES = New OracleClient.OracleCommand(StrQuery, objconn)
        objDrL = objCmdES.ExecuteReader()
        objCmdES.Dispose()
        objCmdES = Nothing

    End Function

    Private Function executeScalar(ByVal strSql) As String
        Dim strResult As String
        strResult = ""

        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception("Database Connection Failed")
            End If
        End If

        objCmd = New OracleClient.OracleCommand
        objCmd.CommandText = strSql
        objCmd.Connection = objconn
        strResult = objCmd.ExecuteScalar
        objCmd.Dispose()
        objCmd = Nothing
        executeScalar = strResult
    End Function



End Class
