<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmcbsfileformats.aspx.vb" Inherits="eSmartDotNet.frmcbsfileformats" %>
<%
dim newappdate
newprevappdate=format(DateAdd("d",-1,session("applicationdate")),"dd-MMM-yyyy")
newappdate=format(cdate(session("applicationdate")),"dd-MMM-yyyy")


  
   objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 
   rs=server.CreateObject("adodb.recordset")
   
   sqlstr = "SELECT bankname,depcertificate FROM genbankparm"
   
   rs=objfetch.SingleSelectStat(sqlstr)
  
	IF NOT rs.EOF AND NOT rs.BOF THEN
	strbankname= rs(0).value
	strbnkshrtname =  rs(1).value
	END IF
	
 sqlstr = " SELECT addr5 FROM genbankbranchmst WHERE branchcode = 999"
   
   rs=objfetch.SingleSelectStat(sqlstr)
  
	IF NOT rs.EOF AND NOT rs.BOF THEN
		strbankaddr = rs(0).value
	END IF
	   
	    
  
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>CBS File Generate</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	
	function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmCardfilegen.txtFromDate.value, "<%=session("applicationdate")%>")
			
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmCardfilegen.txtFromDate.value=""
			}
		
		var intRefTODt=getDateDiff(window.document.frmCardfilegen.txtToDate.value,window.document.frmCardfilegen.txtFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmCardfilegen.txtFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmCardfilegen.txtFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmCardfilegen.txtToDate.value=""
				window.document.frmCardfilegen.txtToDate.focus()
			}
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}


	function DispTranMsg()
	{
		var strtran = "<%=strmessage%>"
		
		if(strtran!="")
		{
			if(strtran=="Sucessful.")
			{
				window.location.href="frmcbsfileformats.aspx"
			}
		}
	}
	
	function GetMonthMM(strmon)
	{
	strmon=strmon.toUpperCase()
	var strmm
	if (strmon == "JAN")
	{
	strmm = "01"
	}
	else if (strmon == "FEB")
	{
	strmm = "02"
	}
	else if (strmon == "MAR")
	{
	strmm = "03"
	}
	else if (strmon == "APR")
	{
	strmm = "04"
	}
	else if (strmon == "MAY")
	{
	strmm = "05"
	}
	else if (strmon == "JUN")
	{
	strmm = "06"
	}
	else if (strmon == "JUL")
	{
	strmm = "07"
	}
	else if (strmon == "AUG")
	{
	strmm = "08"
	}
	else if (strmon == "SEP")
	{
	strmm = "09"
	}
	else if (strmon == "OCT")
	{
	strmm = "10"
	}
	else if (strmon == "NOV")
	{
	strmm = "11"
	}
	else if (strmon == "DEC")
	{
	strmm = "12"
	}
	return strmm;
	}
	
function Ok()
{
var st,Cond
var atmsucchk
var atmfailchk
var posfailchk
var possucchk


var stroper = window.document.frmCardfilegen.cmbDate.value
var frmdt = window.document.frmCardfilegen.txtFromDate.value
var todt =  window.document.frmCardfilegen.txtToDate.value


st="CBSFILES" + "|" + stroper + "|" + frmdt + "|" + todt


window.document.all['iGetDtls'].src="../GEN/getDtls.aspx?st="+st

}

function popCBSFiles(str)
	{
	var strfilename 
		if(str=="No Records")
		{
			alert("No records found to Generate file")
			return;
		}
		
		

		var strfile = str.split("*")
		var stratmsuc = strfile[0]  // ATM Successfull
		var stratmfail = strfile[1] // ATM Fail
		var strpossuc = strfile[2]  // POS successfull
		var strposfail = strfile[3] // POS Fail

		var frmdt = window.document.frmCardfilegen.txtFromDate.value
		var dd= frmdt.toString().substr(0,2);
		var mm = GetMonthMM(frmdt.toString().substr(3,3));
		var yy = frmdt.toString().substr(7,4);
		
		var todt = window.document.frmCardfilegen.txtToDate.value
		var todd= todt.toString().substr(0,2);
		var tomm = GetMonthMM(todt.toString().substr(3,3));
		var toyy = todt.toString().substr(7,4);
		
				
		// ATM Success
		if(stratmsuc=="No Records")
		{
			atmsucchk = "no"
			alert("No records found to Generate file ATM SUCC")
		//	return;
		}
		else
		{

		var stratmsucrec = stratmsuc.split("~");
		
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		filepath= "<%= strbnkshrtname%>" + "_SUCC_ATM_"+ yy + mm + dd
		}
		else
		{
		filepath= "<%= strbnkshrtname%>" + "_SUCC_ATM_"+ yy + mm + dd + toyy + tomm + todd
		}
		
		if (! fso.FolderExists("C://CBSFILES"))
		fso.CreateFolder("C://CBSFILES")
		
		strfilename = ""
		var strfilename =  "c://"+ "CBSFILES/"+filepath+".txt"
		if (fso.FileExists(strfilename))
		{
		fso.DeleteFile(strfilename)
		}
			
		var fh = fso.CreateTextFile(strfilename , true); 
		var strTemp=""

		fh.WriteLine(strTemp)
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " ATM SUCCESSFUL TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " RUN DATE: " + frmdt
		}
		else
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " ATM SUCCESSFUL TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " FROM DATE: " + frmdt + " TO DATE: "  + todt
		}
		
		fh.WriteLine(strTemp)
		strTemp=""
		fh.WriteLine(strTemp)
		
		for(aCnt=0;aCnt<=stratmsucrec.length-1;aCnt++)
		{
			strTemp=stratmsucrec[aCnt]
			fh.WriteLine(strTemp)

		}

		fh.Close();
		atmsucchk = "yes"
//		alert(strfilename + " : File Created")
				
		}

	
// ATM FAIL
		if(stratmfail=="No Records")
		{
			atmfailchk = "no"
			alert("No records found to Generate file ATM FAIL")
		//	return;
		}
		else
		{
		var stratmfailrec = stratmfail.split("~")
			
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		filepath="<%= strbnkshrtname%>" + "_FAIL_ATM_"+ yy + mm + dd
		}
		else
		{
		filepath= "<%= strbnkshrtname%>" + "_FAIL_ATM_"+ yy + mm + dd + toyy + tomm + todd
		}
		
		if (! fso.FolderExists("C://CBSFILES") )
		fso.CreateFolder("C://CBSFILES")
		
		
		strfilename = ""
		var strfilename =  "c://"+ "CBSFILES/"+filepath+".txt"
		if (fso.FileExists(strfilename))
		{
		fso.DeleteFile(strfilename)
		}
		var fh = fso.CreateTextFile(strfilename , true); 
		var strTemp=""
	
		fh.WriteLine(strTemp)
		strTemp=""
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " ATM FAILED TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " RUN DATE: " + frmdt
		}
		else
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " ATM FAILED TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " FROM DATE: " + frmdt + " TO DATE: "  + todt
		}
		fh.WriteLine(strTemp)
		
		strTemp=""
		fh.WriteLine(strTemp)
		for(aCnt=0;aCnt<=stratmfailrec.length-1;aCnt++)
		{
			strTemp=stratmfailrec[aCnt]
			fh.WriteLine(strTemp)
		}
		

		fh.Close();
		atmfailchk = "yes"
//		alert(strfilename + " : File Created")
				
		}


		// POS SUCCESS
		if(strpossuc=="No Records")
		{
			possucchk = "no"
			alert("No records found to Generate file POS SUCC")
		//	return;
		}
		else
		{

		var strpossucrec = strpossuc.split("~")

		var fso  = new ActiveXObject("Scripting.FileSystemObject");

		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		filepath="<%= strbnkshrtname%>" + "_SUCC_POS_"+ yy + mm + dd
		}
		else
		{
		filepath= "<%= strbnkshrtname%>" + "_SUCC_POS_"+ yy + mm + dd + toyy + tomm + todd
		}
		
		if (!fso.FolderExists("C://CBSFILES") )
		fso.CreateFolder("C://CBSFILES")
		

		strfilename = ""
		var strfilename =  "c://"+ "CBSFILES/"+filepath+".txt"
		if (fso.FileExists(strfilename))
		{
		fso.DeleteFile(strfilename)
		}

		var fh = fso.CreateTextFile(strfilename , true); 
		var strTemp=""

		fh.WriteLine(strTemp)
			
		strTemp=""
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		strTemp = "*** "  + "<%=strbnkshrtname%>" + " POS SUCCESSFUL TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " RUN DATE: " + frmdt
		}
		else
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " POS SUCCESSFUL TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " FROM DATE: " + frmdt + " TO DATE: "  + todt
		}
		fh.WriteLine(strTemp)

		strTemp=""
		fh.WriteLine(strTemp)
		for(aCnt=0;aCnt<=strpossucrec.length-1;aCnt++)
		{
			strTemp=strpossucrec[aCnt]
			fh.WriteLine(strTemp)
		}
		
		
		fh.Close();
		possucchk = "yes"
//		alert(strfilename  + " : File Created")
		}

		// POS FAIL
		if(strposfail=="No Records")
		{
		posfailchk = "no"
		alert("No records found to Generate file POS FAIL")
		//	return;
		}
		else
		{
				
		var strposfailrec = strposfail.split("~")
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		filepath="<%= strbnkshrtname%>" + "_FAIL_POS_"+ yy + mm + dd
		}
		else
		{
		filepath= "<%= strbnkshrtname%>" + "_FAIL_POS_"+ yy + mm + dd + toyy + tomm + todd
		}
		
		if (! fso.FolderExists("C://CBSFILES") )
		fso.CreateFolder("C://CBSFILES")
		
		strfilename = ""
		var strfilename =  "c://"+ "CBSFILES/"+filepath+".txt"
		if (fso.FileExists(strfilename))
		{
		fso.DeleteFile(strfilename)
		}

		
		var fh = fso.CreateTextFile(strfilename , true); 
		var strTemp=""

		fh.WriteLine(strTemp)

		strTemp=""
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " POS FAILED TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " RUN DATE: " + frmdt
		}
		else
		{
		strTemp = "*** " + "<%=strbnkshrtname%>" + " POS FAILED TRANSACTIONS "+ "<%= strbankaddr%>" + ' ' + "<%= strbankname%>" + " FROM DATE: " + frmdt + " TO DATE: "  + todt
		}
		
		fh.WriteLine(strTemp)

		strTemp=""
		fh.WriteLine(strTemp)
		
		for(aCnt=0;aCnt<=strposfailrec.length-1;aCnt++)
		{
			strTemp=strposfailrec[aCnt]
			fh.WriteLine(strTemp)
		}
		

		fh.Close();
		posfailchk = "yes"
//		alert(strfilename + " : File Created")
		}

		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{		
			if ((atmsucchk == "yes") || (atmfailchk == "yes") || (possucchk == "yes") || (posfailchk == "yes"))
			{		
				alert("Files Created In Folder " + "c://"+ "CBSFILES/" + " For Date " + frmdt)
			}
			else
			{
				alert("No Files Created In Folder " + "c://"+ "CBSFILES/" + " For Date " + frmdt)
			}
		}
		else
		{
			if ((atmsucchk == "yes") || (atmfailchk == "yes") || (possucchk == "yes") || (posfailchk == "yes"))
			{		
				alert("Files Created In Folder " + "c://"+ "CBSFILES/" + " From Date " + frmdt + " To Date " + todt)
			}
			else
			{
				alert("No Files Created In Folder " + "c://"+ "CBSFILES/" + " From Date " + frmdt + " To Date " + todt)
			}
		}
	}
	
function setDates()
{
window.document.frmCardfilegen.txtToDate.disabled=true
window.document.frmCardfilegen.txtFromDate.value='<%=newappdate%>'
window.document.frmCardfilegen.txtToDate.value='<%=newappdate%>'
}

function toDateDisp()
{
		if(window.document.frmCardfilegen.cmbDate.value!="Between")
		{
			window.document.frmCardfilegen.txtToDate.disabled=true
		}
		else
		{
			window.document.frmCardfilegen.txtToDate.disabled=false
		}
}

	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);setDates();DispTranMsg();">
	<form name="frmCardfilegen">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>ATM CBS FILE GENERATE</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
					<tr>
					
						<td width="70%"  colspan="2" align ="center">
							<table border="0" width="60%" cellspacing="0" cellpadding="0">
								<tr class="BGCOLOR">
									<td width="10%" align="right" height="27">Operator&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="10%"><select size="1" name="cmbDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="Between">Between</option>
											</select>
										</td>

									 <td width = "10%" align ="right">Date&nbsp;&nbsp;&nbsp;</td><td width="10%" valign="left" height="10" align="left">
<input type="text" name="txtFromDate" onblur="datecheck(this)" size="17" class="bgcolor1">(DDMMYYYY)
                </td>
                										<td width="10%"><p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p></td>
										<td width="10%">&nbsp;<input type="text" name="txtToDate" id="txtToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11" class="bgcolor1">(DDMMYYYY)</td>

									
								</tr>
								<tr>&nbsp;</tr>
								<tr>&nbsp;</tr>
							</table>
						</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center"><input name="cmdOk" onclick="Ok()" type="button" value=" Generate " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmCardfile.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
					
					
					
				</table>
			</div>
			</td>
		</tr>
	</table>
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<IFRAME id=iGetDtls style="DISPLAY: block" align=center frameSpacing=0 src="../gen/getDtls.aspx" frameBorder=0 width=0 height=0></IFRAME>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>
