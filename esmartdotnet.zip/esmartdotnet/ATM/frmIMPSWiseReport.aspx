<%@ Page aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Codebehind="frmIMPSWiseReport.aspx.vb" Inherits="eSmartDotNet.frmIMPSWiseReport"%>
<%
dim strmessage

	strmessage=Request.QueryString("record")
%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>IMPS Wise Report</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<!--
//this function is used to set mode status depending upon the the option buttons clicked

var userid = "'"+'<%=session("userid")%>'+"'"
var macid = "'"+'<%=session("machineid")%>'+"'"
var appdat = "'"+'<%=session("applicationdate")%>'+"'"
var stBrcd = "<%=session("branchcode")%>"
	
///for sending parameters to list form for branchCode

function Branch()
{

	var branch="Branch"	
	 var user="<%=userid%>" // log in userid
			
	st=branch;
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:180px;DialogLeft:225px;DialogTop:190px")
}

//-----------------------To Assign Branch details to text boxes----------------------

 function Branchid(kstr)
{	
	assign(kstr,window.document.frmatmwiserep.txtBranchDesc,window.document.frmatmwiserep.txtBranchCode)      	    

}
///for sending parameters to list form for CurrencyCode
function currency()
{	
if(window.document.frmatmwiserep.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
	st="Currency"
	window.showModalDialog("atmList.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:180px;DialogLeft:120px;DialogTop:320px")
			
	splitString("window.document.frmatmwiserep","txtcid,"+
				"txtcdesc")
}
//displaying cashiercode,name which are returned by list page
function  Currencyid(kstr)
{var p,prn,j,k
  var k=kstr.split("-----")
  window.document.frmatmwiserep.txtCurrencyDesc.value =k[0]
  window.document.frmatmwiserep.txtCurrencyCode.value =k[1]
  
  var prn=eval(k[2].length)-1
  window.document.frmatmwiserep.hpr.value=prn
  p=""
  for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	
	
 }	

function clearFormATMTrans()
{
window.document.frmatmwiserep.txtAccountno.value = ""
window.document.frmatmwiserep.txtNarration.value = ""
window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.cmbDate.selectedIndex=0
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgatmtran.Cols=8
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}

function clearFormATMCustTrans()
{

	window.document.frmatmwiserep.txtBrTnxToDate.disabled=true
	window.document.frmatmwiserep.cmbbrtnxDate.selectedIndex=0
	window.document.frmatmwiserep.txtBrTnxFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtBrTnxToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgBrtnxtran.Rows=1
	window.document.frmatmwiserep.mfgBrtnxtran.Cols=8
	window.document.frmatmwiserep.mfgBrtnxtran.formatstring = "^S No  |< App Date      |< Modid       |< GLcode   |<Accno           |< Name                               |> Amount           |< Remarks                              "

}

function ShowDivision(str)
{

	initialcheck()
	clearFormATMTrans()
	clearFormATMCustTrans()

	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgBrtnxtran.Rows=1
	window.document.frmatmwiserep.mfgBrChaChkTrnSta.Rows=1
	window.document.frmatmwiserep.mfgIntraFndsTrns.Rows=1
	window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.Rows=1
	
	window.document.all.divIntraFndsTrns.style.display="none"
	window.document.all.divatmtran.style.display="none"
	window.document.all.divbrtnxdtls.style.display="none"
	window.document.all.divbrchnChktrnstatus.style.display="none"
	window.document.all.divNEFTByMobileFrnTrns.style.display="none"

	if(str=="0")
	{
		window.document.all.divTran.style.display = "block"
		window.document.all.divatmtran.style.display="block"
		
		window.document.frmatmwiserep.rdmode(0).checked = true
	}
	if(str=="1")
	{
	
		window.document.all.divbrtnxdtls.style.display="block"
		
	}
	
	if(str=="2")
	{
	
		window.document.all.divbrchnChktrnstatus.style.display="block"
	
	}

	if(str=="3")
	{
	
		window.document.all.divIntraFndsTrns.style.display="block"
	
	}
	
	if(str=="4")
	{
	
		window.document.all.divNEFTByMobileFrnTrns.style.display="block"
	
	}

}


function initialcheck()
{
	window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtIMPSAccWiseToDate.disabled=true
	window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtIMPSAccWiseToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtBrTnxToDate.disabled=true
	window.document.frmatmwiserep.txtBrTnxFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtBrTnxToDate.value = "<%=session("applicationdate")%>"
		
	window.document.frmatmwiserep.txtIntraFndsTrnsToDate.disabled=true
	window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtIntraFndsTrnsToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.disabled=true
	window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.value = "<%=session("applicationdate")%>"
	
}

function toDateDisp()
{
	if(window.document.all.divatmtran.style.display=="block")
	{
		if(window.document.frmatmwiserep.cmbDate.value!="Between")
		{
			window.document.frmatmwiserep.txtToDate.disabled=true
		}
		else
		{
			window.document.frmatmwiserep.txtToDate.disabled=false
		}
		
					
		if(window.document.frmatmwiserep.IMPSAccWisecmbDate.value!="Between")
		{
			window.document.frmatmwiserep.txtIMPSAccWiseToDate.disabled=true
		}
		else
		{
			window.document.frmatmwiserep.txtIMPSAccWiseToDate.disabled=false
		}
		
	}
	
	
}


function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)


if(window.document.all.divatmtran.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtFromDate.value=""
				window.document.frmatmwiserep.txtFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtToDate.value,window.document.frmatmwiserep.txtFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtToDate.value=""
				window.document.frmatmwiserep.txtToDate.focus()
			}
			
			
			
			var intRefnd=getDateDiff(window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value=""
				window.document.frmatmwiserep.txtIMPSAccWiseFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtIMPSAccWiseToDate.value,window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtIMPSAccWiseFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtIMPSAccWiseToDate.value=""
				window.document.frmatmwiserep.txtIMPSAccWiseToDate.focus()
			}
			
}



if(window.document.all.divbrtnxdtls.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtBrTnxFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtBrTnxFromDate.value=""
				window.document.frmatmwiserep.txtBrTnxFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtBrTnxToDate.value,window.document.frmatmwiserep.txtBrTnxFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtBrTnxFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtBrTnxFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtBrTnxToDate.value=""
				window.document.frmatmwiserep.txtBrTnxToDate.focus()
			}
}


 if(window.document.all.divIntraFndsTrns.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value=""
				window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtIntraFndsTrnsToDate.value,window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtIntraFndsTrnsToDate.value=""
				window.document.frmatmwiserep.txtIntraFndsTrnsToDate.focus()
			}
}
			
			

if(window.document.all.divNEFTByMobileFrnTrns.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value=""
				window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.value,window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.value=""
				window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.focus()
			}
}

			
}

	function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
//-->

function clearATMTrans()
{
window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.cmbDate.selectedIndex=0
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgatmtran.Cols=8
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}

function GetAccountNo()
{

if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
clearATMTrans()

var vin="GetIMPSAccountNoIDS"+"|"+window.document.frmatmwiserep.txtBranchCode.value + "|" + window.document.frmatmwiserep.txtAccountno.value.toUpperCase()
window.document.all['iBatch'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function DisplayAccName(kstr)
{
	if (kstr=="") 
	{
		if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() == "ALL")
		{
			window.document.frmatmwiserep.txtNarration.value = "ALL"
			return;
		}
		else
		{
			alert("Invalid ATM AccNo")
			return;
		}
	}
	else
	{
		window.document.frmatmwiserep.txtNarration.value = kstr
	}
}

function Accountno()
{

if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
clearATMTrans()

var brcode=window.document.frmatmwiserep.txtBranchCode.value


	st="IMPSIDSAccNo"+"|"+brcode
	window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:380px;DialogHeight:170px;DialogLeft:560px;DialogTop:190px")
}

function DispAccNo(kstr)
{ 
var kstr1  = kstr.split("-----")

window.document.frmatmwiserep.txtNarration.value = kstr1[0]
window.document.frmatmwiserep.txtAccountno.value = kstr1[1]

}

function QueRefTrans()
{
/*	if(window.document.frmatmwiserep.txtRefnum.value=="")
	{
		alert("Please Enter The Ref Number")
		return;
	}
	
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	
	var strVal = "REFSERCHNUM"+"|"+window.document.frmatmwiserep.txtRefnum.value
	
	window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
	*/
	
	
window.document.frmatmwiserep.hdnrefno.value = window.document.frmatmwiserep.txtRefnum.value
window.open("frmRefnoReport.aspx?st="+window.document.frmatmwiserep.hdnrefno.value,"","width=600,height=400" )
//window.document.frmatmwiserep.action="frmRefnoReport.aspx"
///window.document.frmatmwiserep.method="post"   
//window.document.frmatmwiserep.submit()	
	
}

function GetPoprefNum(str)
{
	var strResult=str.split("|")
		
	if(strResult[0]=="")
	{
		alert("No Records Found")
		window.document.frmatmwiserep.txtRefnum.value = "";
		return;
	}
	
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
	{
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		
		var strCols=strResult[aCnt].split("~")
		
		window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
		}
	}
}


function IMPSTransMode()
{

window.document.all.divTran.style.display = "block"
window.document.all.divTrnRef.style.display = "none"
window.document.all.divImpsAccWise.style.display = "none"
	if(window.document.frmatmwiserep.rbtnIMPSTransMode(0).checked==true)
	{
	window.document.all.divTran.style.display = "block"
	window.document.all.divTrnRef.style.display = "none"
	window.document.all.divImpsAccWise.style.display = "none"
	}
else
{
window.document.all.divTran.style.display = "none"
window.document.all.divTrnRef.style.display = "none"
window.document.all.divImpsAccWise.style.display = "block"
}
}

function GetMode()
{
window.document.frmatmwiserep.txtAccountno.value = ""
window.document.frmatmwiserep.txtNarration.value = ""
window.document.frmatmwiserep.txtRefnum.value = ""
window.document.frmatmwiserep.cmbDate.selectedIndex=0
window.document.frmatmwiserep.txtToDate.disabled=true
window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
window.document.all.divTran.style.display = "block"
window.document.all.divTrnRef.style.display = "none"
window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
window.document.all.divmfgatmtran.style.display = "block"

window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{
window.document.all.divmfgatmtran.style.display = "block"
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< No Of Trans                                             "
}
if(window.document.frmatmwiserep.rdmode(2).checked==true)
{
	window.document.all.divTran.style.display = "none"
	window.document.all.divTrnRef.style.display = "block"
	window.document.all.divmfgatmtran.style.display = "none"
	
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< ATMACCNO       |< ATM Name                                       |<TNXDATE           |<APPDATE          |<BATCHNO    |<TRANNO       |> Amount                     |<MODID         |<GLCODE          |<ACCNO                   |<REFNUMBER          |< REMARKS                                             "
}
}

function SetATMs()
{

if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
	if (window.document.frmatmwiserep.txtAccountno.value != "")
	{
		if (window.document.frmatmwiserep.txtAccountno.value=="ALL")
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
		}
		else
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< Batchno                 |< Tranno                       |> Amount                            |< Remarks                                                                   "
		}
		
	}
}

if(window.document.frmatmwiserep.rdmode(1).checked==true)
{

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() != "")
	{
		if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="ALL")
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< No Of Trans                                             "
		}
		else
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=4
		window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                 |> Amount                     |< No Of Trans                                             "
		}
	}
}
}

function QueryIMPSTrans()
{
var strtrans
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="")
{
alert("Enter Atm ID")
return;
}

// Detail
if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=9

if(window.document.frmatmwiserep.rdtrans(0).checked==true)  // ALL
{
strtrans = "ALL"
}
else if (window.document.frmatmwiserep.rdtrans(1).checked==true)  // Mobile
{
//strtrans = "P2AO MOB"
strtrans = "MAPP"
}
else if (window.document.frmatmwiserep.rdtrans(2).checked==true) // INET
{
strtrans = "P2AO INET"
}
else if (window.document.frmatmwiserep.rdtrans(3).checked==true)  // Branch Channel
{
//strtrans = "P2AO BRC"
strtrans = "Mobile"
}


window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No    |< Tnx Date            |< Batchno        |< Tranno            |> Amount             |< Remarks                                          |<Beneficiary Remarks                 |> ReferenceNum     |> Channel ID      "
var strVal="IMPSTRANSDET"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value +"|"+ window.document.frmatmwiserep.txtAccountno.value.toUpperCase() +"|" + strtrans  + "|" + window.document.frmatmwiserep.cmbtnxtype.value

}

// Summary
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{
	if(window.document.frmatmwiserep.rdtrans(0).checked==true)  // ALL
	{
	strtrans = "ALL"
	}
	else if (window.document.frmatmwiserep.rdtrans(1).checked==true)  // Mobile
	{
	//strtrans = "P2AO MOB"
	strtrans = "MAPP"
	}
	else if (window.document.frmatmwiserep.rdtrans(2).checked==true) // INET
	{
	strtrans = "P2AO INET"
	}
	else if (window.document.frmatmwiserep.rdtrans(3).checked==true)  // Branch Channel
	{
	//strtrans = "P2AO BRC"
	strtrans = "Mobile"
	}

		window.document.frmatmwiserep.mfgatmtran.Rows=1
		window.document.frmatmwiserep.mfgatmtran.Cols=4

		window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |> Amount                     |< No Of Trans                                             "
var strVal="IMPSTRANSSUM"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value +"|"+ window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + "|" + strtrans + "|" + window.document.frmatmwiserep.cmbtnxtype.value

}
if ((window.document.frmatmwiserep.rdmode(0).checked==true) || (window.document.frmatmwiserep.rdmode(1).checked==true))
{
window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}

}

function DisplayATMTrans(str)
{

var strResult1=str.split("*")
var strResult=strResult1[1].split("|")

// detail of IMPS
if (strResult1[0]  == "IMPSTRANSDET")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // batchno 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // tranno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=strCols[4] // remarks
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=strCols[5] // beneficiary remarks
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,7)=strCols[6] // reference num
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,8)=strCols[7] // channel id
		if (eval(strCols[3]) < 0 )
		{
		totdramt = parseFloat(totdramt) + parseFloat(strCols[3])
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[3])
		}
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)),2)
		}

		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= Math.abs(totdramt)
		
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
		
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= totcramt
	
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
}


// summary of IMPS
if (strResult1[0]  == "IMPSTRANSSUM")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // no of trans
		
		
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)),2)
		}
}
}

function Report(strrep)
	{
		var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
// --------------Start ATM Transactions  ------------------------------

	if(window.document.all.divatmtran.style.display=="block")
	{
	// start ALL 
	if(window.document.frmatmwiserep.rbtnIMPSTransMode(0).checked==true)
	{
	// ----------- start Detail -----------------------
	if(window.document.frmatmwiserep.rdmode(0).checked==true)
	{
	
	
	// ------------start Not ALL IMPS Aaccounts IMPS Transaction Detailed -------------------------
	
		
		if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transaction Details For Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " And From "  + window.document.frmatmwiserep.txtFromDate.value + " to "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transaction Details For Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " AS ON DATE "+ window.document.frmatmwiserep.cmbDate.value + " " + window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",6,R"+"~" //batchno
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",6,R"+"~"  //tranno
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",15,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",36,L"+"~" //REMARKS
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",36,L"+"~" //Beneficairy REMARKS
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,7)+",16,L"+"~" //refrence num
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,8)+",16,L"+"|" //ChannelID
		
for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					
					if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt).substr(0,36) +"~"
					}
					else if (jcnt == 7)
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	
// ---------- end <> ALL ATM Accounts -------------------
	
	}
	// ---------------- end Detail --------------------------
	
// ---- start Summary  ---------------
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{

// ----- start Not ALL ATM trans summary report-----------------------
	
	if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transactions Summary Report For ATM Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " And From "  + window.document.frmatmwiserep.txtFromDate.value + " to "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transactions Summary Report For ATM Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " AS ON DATE "+ window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",17,R"+"~" //sum of AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",10,L"+"|" // no of trans

for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

		//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr

// ----- end Not ALL ----------------------------
}
// ---- end Summary  ---------------

} 
// end ALL
// start Acc No Wise
else
{
if(window.document.frmatmwiserep.IMPSAccWisecmbDate.value=="Between")
		{
			strheadsub = "IMPS Transaction For Accno " + window.document.frmatmwiserep.IMPSAccWiseAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.IMPSAccWiseAccNm.value + " And From "  + window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value + " to "+window.document.frmatmwiserep.txtIMPSAccWiseToDate.value
		}
		else
		{
			strheadsub = "IMPS Transaction For Accno " + window.document.frmatmwiserep.IMPSAccWiseAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.IMPSAccWiseAccNm.value + " AS ON DATE "+ window.document.frmatmwiserep.IMPSAccWisecmbDate.value + " " + window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",16,L"+"~" //Acc No
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",25,R"+"~" //Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",17,R"+"~"  //Amount
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",17,R"+"~" //Rater Ref Code
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",11,L"+"~" //Applicationdate
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",16,L"+"~" //Trans Type
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,7)+",50,L"+"|" //remarks
		
for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					
					if (jcnt == 1)
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	

}
// end Acc No Wise
}	

// ------------- end ATM Transactions ------------------

	// ------------- Start branch Transactions details------------------
	if(window.document.all.divbrtnxdtls.style.display=="block")
	{

		if(window.document.frmatmwiserep.cmbbrtnxDate.value=="Between")
		{
			strheadsub = "Branch Transaction Details From "  + window.document.frmatmwiserep.txtBrTnxFromDate.value + " to "+window.document.frmatmwiserep.txtBrTnxToDate.value
		}
		else
		{
			strheadsub = "Branch Transaction Details AS ON DATE "+ window.document.frmatmwiserep.cmbbrtnxDate.value + " " + window.document.frmatmwiserep.txtBrTnxFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,1)+",12,L"+"~" //Ref Num
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,2)+",17,L"+"~" //Accno
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,3)+",20,L"+"~"  //Remitter Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,4)+",12,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,5)+",11,L"+"~" //Ben IFSC Code
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,6)+",16,L"+"~" //Ben Accno Code
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,7)+",16,L"+"~" //Ben Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,8)+",4,L"+"~" //credit status
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,9)+",16,L"+"~" //Credit Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,10)+",11,L"+"~" //Applicationdate
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,11)+",12,L"+"~" //reference num
			StrCol=StrCol+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(0,12)+",20,L"+"|" // Remarks
			
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgBrtnxtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgBrtnxtran.Cols-1;jcnt++)
				{
					
					if (jcnt == 2)
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr



} // ------------- end of branch transaction details ------------------





	// ------------- Start Intra Funds Transfer------------------
	if(window.document.all.divIntraFndsTrns.style.display=="block")
	{

		if(window.document.frmatmwiserep.cmbIntraFndsTrnstnxDate.value=="Between")
		{
			strheadsub = "Intra Funds Transfer  From "  + window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value + " to "+window.document.frmatmwiserep.txtBrTnxToDate.value
		}
		else
		{
			strheadsub = "Intra Funds Transfer AS ON DATE "+ window.document.frmatmwiserep.cmbIntraFndsTrnstnxDate.value + " " + window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,1)+",12,L"+"~" //date
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,2)+",12,L"+"~" //refnum
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,3)+",16,L"+"~" //dr accno
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,4)+",20,L"+"~"  //Dr Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,5)+",16,L"+"~" //Cr Accno
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,6)+",20,L"+"~" //Cr Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,7)+",16,R"+"~" //Amount
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,8)+",25,L"+"~" //Dr Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,9)+",25,L"+"~" //Credit Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(0,10)+",25,L"+"|" //status
			
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgIntraFndsTrns.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgIntraFndsTrns.Cols-1;jcnt++)
				{
					
					if ((jcnt == 2) || (jcnt == 3) || (jcnt == 6))
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr



} // ------------- end Intra Funds Transfer ------------------



	// ------------- Start NEFT Funds Transfer------------------
	if(window.document.all.divNEFTByMobileFrnTrns.style.display=="block")
	{

		if(window.document.frmatmwiserep.cmbNEFTByMobileFrnTrnstnxDate.value=="Between")
		{
			strheadsub = "NEFT Funds Transfer  From "  + window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value + " to "+window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.value
		}
		else
		{
			strheadsub = "NEFT Funds Transfer AS ON DATE "+ window.document.frmatmwiserep.cmbNEFTByMobileFrnTrnstnxDate.value + " " + window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,1)+",12,L"+"~" //date
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,2)+",13,L"+"~" //refnum
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,3)+",12,L"+"~" //amount
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,4)+",17,L"+"~" //dr accno
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,5)+",20,L"+"~"  //Dr Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,6)+",17,L"+"~" //Cr Accno
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,7)+",20,L"+"~" //Cr Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,8)+",16,R"+"~" //Dr Refno
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,9)+",25,L"+"~" //Dr Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,10)+",25,L"+"~" //Credit Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(0,11)+",25,L"+"|" //status
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.Cols-1;jcnt++)
				{
					
					if ((jcnt == 2) || (jcnt == 3) || (jcnt == 4) || (jcnt == 6))
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr



} // ------------- end NEFT Funds Transfer ------------------



	if(strrep=="report")
		{
			window.document.frmatmwiserep.action="http://" + 
			"<%=session("moduledir")%>" +"/ReportGridTemplate.aspx?strng="+"/ATM/frmIMPSWiseReport"
		}
		else
		{
			window.document.frmatmwiserep.action="http://" + 
			"<%=session("moduledir")%>" +"/ReportGridTemplateXL.aspx?strng="+"/ATM/frmIMPSWiseReport"
		}
		window.document.frmatmwiserep.method="post"
		window.document.frmatmwiserep.submit();

}







function clearATMCustTrans()
{
window.document.frmatmwiserep.txtBrTnxToDate.disabled=true
	window.document.frmatmwiserep.cmbbrtnxDate.selectedIndex=0
	window.document.frmatmwiserep.txtBrTnxFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtBrTnxToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgBrtnxtran.Rows=1
	window.document.frmatmwiserep.mfgBrtnxtran.Cols=8
	window.document.frmatmwiserep.mfgBrtnxtran.formatstring = "^S No       |< App Date                |< Modid              |< GLcode   |<Accno                 |< Name                                                       |> Amount                     |< Remarks                                              "
	
}

function toBrTnxDateDisp()
{
if(window.document.frmatmwiserep.cmbbrtnxDate.value!="Between")
{
window.document.frmatmwiserep.txtBrTnxToDate.disabled=true
}
else
{
window.document.frmatmwiserep.txtBrTnxToDate.disabled=false
}
}

 
	
function QueryBrTnxDtlsTrans()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
var strchkval

if (window.document.frmatmwiserep.chkcon.checked == true)
{
strchkval = "Y"
}
else
{
strchkval = "N"
}

	window.document.frmatmwiserep.mfgBrtnxtran.Rows=1
window.document.frmatmwiserep.mfgBrtnxtran.Cols=13
	window.document.frmatmwiserep.mfgBrtnxtran.formatstring = "^S No    |< Reference Num           |<Accno                 |< Remitter Name                 |> Amount             |< Ben IFSC            |<  Ben Accno        |< Ben Name                 |< Credit Status    |< Credit Remarks          |< Application Date |< Trans Refno |< Remarks                                                                      "
	var strVal="BRCTNXDTLS" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbbrtnxDate.value +"|"+ window.document.frmatmwiserep.txtBrTnxFromDate.value +"|"+ window.document.frmatmwiserep.txtBrTnxToDate.value + "|" + strchkval

	//alert(strVal)

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}


function PopBRCTNXDTLS(str)
{
	var strResult1=str.split("*")
	var strResult=strResult1[1].split("|")
	if (strResult1[0]  == "BRCTNXDTLS")
	{
	if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
			for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
			{
				window.document.frmatmwiserep.mfgBrtnxtran.rows=window.document.frmatmwiserep.mfgBrtnxtran.rows+1
				var strCols=strResult[aCnt].split("~")
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,1)=strCols[0] // refnum
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,2)=strCols[1] // accno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,3)=strCols[2] // rem name
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,4)=strCols[3] // amount
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,5)=strCols[4] // ben ifsc code 
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,6)=strCols[5] // ben accno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,7)=strCols[6] // ben name
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,8)=strCols[7] // credit status
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,9)=strCols[8] // credit remarks
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,10)=strCols[9] // applicationdate
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,11)=strCols[10] // TRANSREFNO
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,12)=strCols[11] // remarks
			}			
		
	}
}


function QueryBrChaChkTrnSta()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}

	window.document.frmatmwiserep.mfgBrChaChkTrnSta.Rows=1
window.document.frmatmwiserep.mfgBrChaChkTrnSta.Cols=13
	window.document.frmatmwiserep.mfgBrChaChkTrnSta.formatstring = "^S No    |< Reference Num           |<Accno                 |< Remitter Name                 |> Amount             |< Ben IFSC            |<  Ben Accno        |< Ben Name                 |< Credit Status    |< Credit Remarks          |< Application Date |< Trans Refno |< Remarks                                                                      "
	var strVal="BrChaChkTrnSta" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbbrchnchktrnstatnxDate.value +"|"+ window.document.frmatmwiserep.txtBrChaChkTrnStaFromDate.value +"|"+ window.document.frmatmwiserep.txtBrChaChkTrnStaToDate.value 

	//alert(strVal)

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}


function PopBRCChkTrnSta(str)
{
	var strResult1=str.split("*")
	var strResult=strResult1[1].split("|")
	if (strResult1[0]  == "BrChaChkTrnSta")
	{
	if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
			for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
			{
				window.document.frmatmwiserep.mfgBrtnxtran.rows=window.document.frmatmwiserep.mfgBrtnxtran.rows+1
				var strCols=strResult[aCnt].split("~")
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,1)=strCols[0] // refnum
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,2)=strCols[1] // accno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,3)=strCols[2] // rem name
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,4)=strCols[3] // amount
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,5)=strCols[4] // ben ifsc code 
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,6)=strCols[5] // ben accno
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,7)=strCols[6] // ben name
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,8)=strCols[7] // credit status
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,9)=strCols[8] // credit remarks
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,10)=strCols[9] // applicationdate
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,11)=strCols[10] // TRANSREFNO
				window.document.frmatmwiserep.mfgBrtnxtran.textmatrix(aCnt+1,12)=strCols[11] // remarks
			}			
		
	}
}
function message()
{
	var mess="<%=strmessage%>"
	
	if(mess!="")
	{
		var strCnt = mess.split("#")
	
		if(strCnt[0]=="Transaction Sucessful.")
		{
			window.document.all.divatmtran.style.display="none"
			window.document.all.divbrtnxdtls.style.display="none"
			window.document.all.divatmtran.style.display = "block"
			window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
		}
		else
		{
			alert(strCnt[0])
			location.replace("../ATM/frmIMPSWiseReport.aspx")
		}
	}
}


// start IMPS Acc Wise
function IMPSAccWisemodule()
 { 
 	
 if(window.document.frmatmwiserep.txtBranchCode.value=="")
 {
	alert("Please Select Branchcode.")
	return
 }
 
 if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
 {
	alert("Please Select Currency Code.")
	return
 }

	splitString("window.document.frmatmwiserep","txtIMPSAccWiseModId,txtIMPSAccWiseModNm,txtIMPSAccWiseGLcode,"+
		"IMPSAccWiseGLname,IMPSAccWiseAccNo,IMPSAccWiseAccNm") 
		window.document.frmatmwiserep.mfgatmtran.Rows =1 
		stmod="sbcaccinvmiscplmodule"; 
		kstr=stmod
		window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
 }



function modulecode(kstr)
 {
	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmatmwiserep.txtIMPSAccWiseModNm.value=StrFld[0]
	window.document.frmatmwiserep.txtIMPSAccWiseModId.value=StrFld[1]
	
}




function IMPSAccWiseGlcode()
{ 

	if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	if(window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
		

		window.document.frmatmwiserep.mfgatmtran.Rows =1 
	splitString("window.document.frmatmwiserep","txtIMPSAccWiseGLcode,IMPSAccWiseGLname,IMPSAccWiseAccNo,IMPSAccWiseAccNm")
	window.document.frmatmwiserep.mfgatmtran.Rows =1 
	telgl="Tellerglcode";
	brcode=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
	modid=window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase();
	kstr=telgl+"|"+brcode+"|"+modid
	if(modid!=""){
		 window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	 } 
}
//Assign Selected GL code and GL desc to the Textboxes.	

function Glcodeid(kstr)
 { 
	
	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=StrFld[1]
	window.document.frmatmwiserep.IMPSAccWiseGLname.value=StrFld[0]

} 	 



function IMPSAccWiseAccCode()
{
	if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	
	strType =  window.document.frmatmwiserep.cmbIMPSAccWisetnxtype.value

	if(strType=="")
	{
		alert("Please Select Service Type.")
		return;
	}	

	if(window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	if(window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=="")
	{
		alert("Please Select Glcode.")
		return;
	}	
	

		
	splitString("window.document.frmatmwiserep","IMPSAccWiseAccNo,IMPSAccWiseAccNm")
	window.document.frmatmwiserep.mfgatmtran.Rows =1 
   	stacc="IMPSAccWiseAccno" 
	brchCd=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
    Crcd=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase();
    GlCd=window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value.toUpperCase();
    ModId=window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase();
	strType =  window.document.frmatmwiserep.cmbIMPSAccWisetnxtype.value

	kstr=stacc+"|"+brchCd+"|"+Crcd +"|"+ModId+"|"+GlCd +"|"+ strType +"|"+window.document.frmatmwiserep.IMPSAccWisecmbDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseToDate.value
	
	if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0) && (Crcd.length>0))
	{
   		window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
   	}
   	else
   	{
   		alert('Select Branch code,Currency code,Module id and GL code.')
   	}
 }

//Assign Selected Account NO and Account Name to the Textboxes.

function accountid(kstr)
{ 

	assign(kstr,window.document.frmatmwiserep.IMPSAccWiseAccNm,window.document.frmatmwiserep.IMPSAccWiseAccNo)
}

function IMPSAccWiseQueryIMPSTrans()
{

if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	
	strType =  window.document.frmatmwiserep.cmbIMPSAccWisetnxtype.value

	if(strType=="")
	{
		alert("Please Select Service Type.")
		return;
	}	

	if(window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	if(window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=="")
	{
		alert("Please Select Glcode.")
		return;
	}	
	

var stacc
 stacc="IMPSAccWiseRep" 
	brchCd=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
    Crcd=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase();
    GlCd=window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value.toUpperCase();
    ModId=window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase();
	accno = window.document.frmatmwiserep.IMPSAccWiseAccNo.value.toUpperCase();
	strType =  window.document.frmatmwiserep.cmbIMPSAccWisetnxtype.value

	window.document.frmatmwiserep.mfgatmtran.Rows =1 
	window.document.frmatmwiserep.mfgatmtran.Cols = 8
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< AccNo                |< Name                            |> Amount                |< Raterrefcode        |< Applicationdate     |<Trans Type      |<Remarks                                                                                                    "
	
	strVal=stacc+"|"+brchCd+"|"+Crcd +"|"+ModId+"|"+GlCd +"|"+ accno + "|" + strType +"|"+window.document.frmatmwiserep.IMPSAccWisecmbDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseToDate.value

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}


function DisplayIMPSAccWiseRepDtls(str)
{

var strResult1=str.split("*")
var strResult=strResult1[1].split("|")

if (strResult1[0]  == "IMPSAccWiseRep")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}

	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=strCols[0] // accno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // name 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // raterrefcode
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=Datepick1(strCols[4]) // applicationdate
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=strCols[5] // Trans Type
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,7)=strCols[6] // remarks	
			
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)),2)
		}
		
			
} 
}


function DescrptionDisp(strTxt)
 {
 sBr=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase()
 sMod=window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()
 sGL=window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value.toUpperCase()
 sCur=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase()
 sAccno=window.document.frmatmwiserep.IMPSAccWiseAccNo.value.toUpperCase()
 	/// for Branch Code
		if(strTxt=="txtBranchCode")
		{ 
		window.document.frmatmwiserep.txtbranchdesc.value=""
		if(window.document.frmatmwiserep.txtBranchCode.value=="")
		{
		return;
		}
				st="DescDisplay~GENBANKBRANCHMST~"+
				"NARRATION~branchcode='"+sBr+"'~~"+strTxt
		}

 	/// for currency
		
		if(strTxt=="txtCurrencyCode")
		{ 
		clearATMCustTrans()

		window.document.frmatmwiserep.txtcurrencydesc.value=""
		splitString("window.document.frmatmwiserep","txtModId,txtModNm,txtGLcode,"+
		"txtGLname,txtAccNo,txtAccNm") 
		if(sBr=="")
		{
			alert("Select Branch Code")
			window.document.frmatmwiserep.txtCurrencyCode.value=""
			return;
		}
		if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
		{
		return;
		}
				st="DescDisplay~GENCURRENCYTYPEMST~"+
				"NARRATION,PRECISION~currencycode='"+sCur+"'~~"+strTxt
		}
		
		
		
 	///for ModuleId 
 		
		if(strTxt=="txtIMPSAccWiseModId")
		{ 
		window.document.frmatmwiserep.mfgatmtran.Rows=1
	
	window.document.frmatmwiserep.txtIMPSAccWiseModNm.value=""
	window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=""
		window.document.frmatmwiserep.IMPSAccWiseGLname.value=""
		window.document.frmatmwiserep.IMPSAccWiseAccNo.value = ""
		window.document.frmatmwiserep.IMPSAccWiseAccNm.value = ""
		
	
		
		if(sBr=="")
 		{
 			alert("select Branch Code")
 			window.document.frmatmwiserep.txtIMPSAccWiseModId.value=""
 			return;
 		}
		if(window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()=="")
		{
		return;
		}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~M.IMPLEMENTEDYN='Y' and M.moduleid in ('SB','CA','CC','INV','MISC','PL','DEP','LOAN') and M.moduleid='"+sMod+"'~~"+strTxt
		}
		///for Gl Code
		
		if(strTxt=="txtIMPSAccWiseGLcode")
		{ 
		window.document.frmatmwiserep.mfgatmtran.Rows=1
	
		window.document.frmatmwiserep.IMPSAccWiseGLname.value=""
		window.document.frmatmwiserep.IMPSAccWiseAccNo.value = ""
		window.document.frmatmwiserep.IMPSAccWiseAccNm.value = ""
	
		if(sMod=="")
		{
			alert("Select Module Id")
			window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=""
			
			return;
		}
		if(window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=="")
		{
		return;
		}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
		}
		
		

	//alert(st)
	window.document.all["iBatch"].src="../GEN/reportdisplay.aspx?st="+st	
}

function DescDisplay(stri)
{
var strtype=new String()
strtype=stri.split("~")
//for description displaying  split the values
var StrArrFld=new String()
var StrArrFlds=new String()
StrArrFld=strtype[0].split("|")


///for displaying ModuleDesc
	if(strtype[1]=="txtIMPSAccWiseModId")
	{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Module Id")
					window.document.frmatmwiserep.txtIMPSAccWiseModId.value=""
					window.document.frmatmwiserep.txtIMPSAccWiseModNm.value=""
					return;
				}
		window.document.frmatmwiserep.txtIMPSAccWiseModNm.value=StrArrFld[0]
		
	}
	
	///for displaying gldesc
	if(strtype[1]=="txtIMPSAccWiseGLcode")
	{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid GLCode ")
					window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=""
					window.document.frmatmwiserep.IMPSAccWiseGLname.value=""
					return;
				}
		window.document.frmatmwiserep.IMPSAccWiseGLname.value=StrArrFld[0]
		
	}
	
}


function GetIMPSAccWiseCustTrnsAccName()
{
var strmode

if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	if(window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	if(window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=="")
	{
		alert("Please Select Glcode.")
		return;
	}	

	if(window.document.frmatmwiserep.IMPSAccWiseAccNo.value=="")
	{
		alert("Please Select Acc No.")
		return;
	}	
	var stacc
 stacc="GetIMPSAccWiseCustTrnsAccName" 
brchCd=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
    Crcd=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase();
    GlCd=window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value.toUpperCase();
    ModId=window.document.frmatmwiserep.txtIMPSAccWiseModId.value.toUpperCase();
	accno = window.document.frmatmwiserep.IMPSAccWiseAccNo.value.toUpperCase();
	strType =  window.document.frmatmwiserep.cmbIMPSAccWisetnxtype.value
	
	window.document.frmatmwiserep.IMPSAccWiseAccNm.value = ""
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	

strVal=stacc+"|"+brchCd+"|"+Crcd +"|"+ModId+"|"+GlCd +"|"+ accno + "|" + strType +"|"+window.document.frmatmwiserep.IMPSAccWisecmbDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseFromDate.value +"|"+ window.document.frmatmwiserep.txtIMPSAccWiseToDate.value

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;


}

function DisplayIMPSAccWiseCustTrnsAccName(kstr)
{
	
	if (kstr == "")
	{
		alert("Invalid Acc No")
		return;
	}
	else
	{
		window.document.frmatmwiserep.IMPSAccWiseAccNm.value = kstr
	}
	
}

function TransType()
{

window.document.frmatmwiserep.txtIMPSAccWiseModId.value=""
window.document.frmatmwiserep.txtIMPSAccWiseModNm.value=""
window.document.frmatmwiserep.txtIMPSAccWiseGLcode.value=""
window.document.frmatmwiserep.IMPSAccWiseGLname.value=""
window.document.frmatmwiserep.IMPSAccWiseAccNo.value = ""
window.document.frmatmwiserep.IMPSAccWiseAccNm.value = ""
window.document.frmatmwiserep.mfgatmtran.Rows=1
}

// end IMPS Acc Wise


// start intra funds transfer

function QueryIntraFndsTrns()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
var strchkval
if (window.document.frmatmwiserep.chkconintra.checked == true)
{
strchkval = "Y"
}
else
{
strchkval = "N"
}


	window.document.frmatmwiserep.mfgIntraFndsTrns.Rows=1
window.document.frmatmwiserep.mfgIntraFndsTrns.Cols=11
	window.document.frmatmwiserep.mfgIntraFndsTrns.formatstring = "^S No     |<Date             |<RefNum          |<Dr Accno           |< Dr Name                 |< Cr Accno               |<Cr Name                 |>Amount         |<Dr Remarks                                      |<Cr Remarks                                          |<Status                      "
	var strVal="IntraFndsTrns" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbIntraFndsTrnstnxDate.value +"|"+ window.document.frmatmwiserep.txtIntraFndsTrnsFromDate.value +"|"+ window.document.frmatmwiserep.txtIntraFndsTrnsToDate.value + "|" + strchkval

//	alert(strVal)

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}


function PopIntraFndsTrns(str)
{
	var strResult1=str.split("*")
	var strResult=strResult1[1].split("|")
	if (strResult1[0]  == "IntraFndsTrns")
	{
	if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
			for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
			{
				window.document.frmatmwiserep.mfgIntraFndsTrns.rows=window.document.frmatmwiserep.mfgIntraFndsTrns.rows+1
				var strCols=strResult[aCnt].split("~")
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,0)=aCnt+1   // sno
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // date
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,2)=strCols[1] // Refnum
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,3)=strCols[2] // Draccno
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,4)=strCols[3] // Dr name
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,5)=strCols[4] // Cr Accno
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,6)=strCols[5] // Cr Name 
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,7)=strCols[6] // amount
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,8)=strCols[7] // Dr Remarks
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,9)=strCols[8] // Cr Remarks
				window.document.frmatmwiserep.mfgIntraFndsTrns.textmatrix(aCnt+1,10)=strCols[9] // status
			}			
		
	}
}

function toIntraFndsTrnsDateDisp()
{
	if(window.document.frmatmwiserep.cmbIntraFndsTrnstnxDate.value!="Between")
	{
		window.document.frmatmwiserep.txtIntraFndsTrnsToDate.disabled=true
	}
	else
	{
		window.document.frmatmwiserep.txtIntraFndsTrnsToDate.disabled=false
	}
}



// end intra funds transfer


// start NEFT By Mobile Funds Transfer



function QueryNEFTByMobileFrnTrns()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
var strchkval
if (window.document.frmatmwiserep.chkconintra.checked == true)
{
strchkval = "Y"
}
else
{
strchkval = "N"
}


	window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.Rows=1
window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.Cols=12
	window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.formatstring = "^S No     |<Date             |<RefNum          |< amount       |<Dr Accno           |< Dr Name                 |< Cr Accno               |<Cr Name                  |<Dr Refno                |<Dr Remarks                                      |<Cr Remarks                                          |<Status                    "
	var strVal="NEFTByMobileFrnTrns" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbNEFTByMobileFrnTrnstnxDate.value +"|"+ window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsFromDate.value +"|"+ window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.value + "|" + strchkval

//	alert(strVal)

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}


function PopNEFTByMobileFrnTrns(str)
{

	var strResult1=str.split("*")
	var strResult=strResult1[1].split("|")
	if (strResult1[0]  == "NEFTByMobileFrnTrns")
	{
	if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
			for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
			{
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.rows=window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.rows+1
				var strCols=strResult[aCnt].split("~")
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,0)=aCnt+1   // sno
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // date
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,2)=strCols[1] // Refnum
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,3)=strCols[2] // amount
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,4)=strCols[3] // Draccno
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,5)=strCols[4] // Dr name
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,6)=strCols[5] // Cr Accno
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,7)=strCols[6] // Cr Name 
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,8)=strCols[7] // dr refno
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,9)=strCols[8] // Dr Remarks
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,10)=strCols[9] // Cr Remarks
				window.document.frmatmwiserep.mfgNEFTByMobileFrnTrns.textmatrix(aCnt+1,11)=strCols[10] // status
			}			
		
	}
}


function toNEFTByMobileFrnTrnsDateDisp()
{
	if(window.document.frmatmwiserep.cmbNEFTByMobileFrnTrnstnxDate.value!="Between")
	{
		window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.disabled=true
	}
	else
	{
		window.document.frmatmwiserep.txtNEFTByMobileFrnTrnsToDate.disabled=false
	}
}


// end NEFT By Mobile Funds Transfer
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" topmargin="0" leftmargin="0" 
onload="GetMenu(&quot;<%=session("menustring")%>&quot;);message();initialcheck();">

<form name="frmatmwiserep">
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="100%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
        <div class="menuBar">
            <table cellpadding="0" cellspacing="0" width="100%" border=0>
                <tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                   
                    <td width="39%" align="CENTER" height="22" class="subHeader">
                        <h2>IMPS Wise Report</h2>
                    </td>
                    <td width="39%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
                </tr>
            </table>
        </div>
        <div id="menucontrol"></div> 
  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain" border =1>
    <tr>
     <td>
    
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" valign="top" height="15">
          <p align="center">&nbsp;&nbsp;</p>
          </td>
        </tr>
      </table>

      <%appdate=formatdatetime(session("applicationdate"),1)%>


      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="1" >
        <tr>
          <td width="100%" height="29">

          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0" >
              <tr class="bgcolor">
                <td width="88" height="27">
                <p align="right"><font class="textbold">&nbsp;Branch Code&nbsp;</font></p>
                </td>
                <td width="282" height="27"><input class="txtautofill" name="txtBranchCode" style="TEXT-TRANSFORM: uppercase" 
                size="10" value="<%=session("branchcode")%>" onblur="Dataarrange(txtBranchCode);CashierDisp(&quot;txtBranchCode&quot;)" maxlength="10"><input type="button" value=" L " name="B3" onclick="Branch()"><input name="txtBranchDesc" size="18" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
                <td width="153" align="right" height="27"><font class="textbold">Currency
                Code &nbsp;&nbsp;</font></td>
                <td width="300" height="27"><input class="txtautofill" name="txtCurrencyCode" style="TEXT-TRANSFORM: 
                          uppercase" size="10" maxlength="10" onblur="Dataarrange(txtCurrencyCode);CashierDisp(&quot;txtCurrencyCode&quot;)" value="<%=session("currencycode")%>"><input type="button" value=" L " name="B9" onclick="currency()"><input name="txtCurrencyDesc" size="18" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
              <tr>
                <td width="88" height="10"></td>
                <td width="282" height="10"></td>
                <td width="153" align="right" height="10"></td>
                <td width="231" height="10"></td>
              </tr>
            </table>
            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain" border =0>
              <tr>
                <td width="14%" valign="top">

                <table border="0" width="100%" cellspacing="1" cellpadding="0">
                   <tr bgcolor="#99ccff" >
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">IMPS Transactions</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff">
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">BRC Tnx Details</font></a></td>
                  </tr>
                     <tr bgcolor="#99ccff">
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">BRC Check Trns Status</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff" >
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('3')">&nbsp;<font class="textbold">Intra Funds Transfer</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff" >
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('4')">&nbsp;<font class="textbold">NEFT By Mobile Funds Transfer</font></a></td>
                  </tr>
               <!--   <tr bgcolor="#99ccff" >
                    <td width="100%" height="18"><a href="#" onclick="ShowDivision('4')">&nbsp;<font class="textbold">ATM Cash Position</font></a></td>
                  </tr> -->
                </table>

                </td>
                <td width="86%" valign="top">
                <!------Start IMPS Transactions  ---->
                  <div id="divatmtran" style="display:block">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="IMPS Transactions" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
						</tr>
							<tr><td colspan=10><table width = "100%"  class="tableborder1">
						<tr class="bgcolor1">
                    <td width="20%" align="middle"><font class="textblack"><input type="radio"  name="rbtnIMPSTransMode" checked onclick="IMPSTransMode()"  value="ALL">  ALL</font> </td> 
                    <td width="20%" align="middle"><font class="textblack"><input type="radio"  name="rbtnIMPSTransMode"  onclick="IMPSTransMode()"  value="Single">  Acc Wise</font> </td> 
					</tr>
					</table></td></tr>
						
						
						<tr>
							<td colspan =10>
								<div id="divTran" style="display=block">
								<table width = "100%" class= "tableborder2" border=0>
								
								<tr>
						<td colspan = 10 >
						
							<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
                                <tr class="bgcolor1">
									<td width="30%"  align="middle"><input type="radio" name="rdmode" checked onclick="GetMode()"><font class="textblack">Details</font></td>
									<td width="30%"  align="middle"><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">Summary</font></td>
									<td width="30%"  align="middle"><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">RefNumber</font></td>
								</tr>
							</table>
						</td>
						</tr>
									<tr>
										<td colspan =5 align="right">
											<table border =0 width = "100%" cellpadding =0 cellspacing =0>
												<tr id = "divaccno" style="DISPLAY: Block">
													<td width = "32%" align ="right" >IMPS ID&nbsp;&nbsp;&nbsp;&nbsp;</td>
				        <td><input onkeypress="Alphanum()" name="txtAccountno" class="txtautofill"  maxlength=16 style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onblur="GetAccountNo()" size="15" value = "1"><input name="butAccno" onclick="Accountno()" type="button" value=" L " class="button"><input name="txtNarration" class=bgcolor1 readonly size="17" style="TEXT-TRANSFORM: capitalize" value = "IMPS"></td><td> TnxType<select size="1" name="cmbtnxtype""  >
											<option value="ALL">ALL</option>
											<option value="INWARD">INWARD</option>
											<option value="OUTWRD">OUTWARD</option>
											</select></td>
												</tr> 
											</table>
										</td>
										<td colspan =5>
										<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
                                <tr class="bgcolor1">
                                <td width="30%" align="middle"><input type="radio" name="rdtrans" checked onclick="GetTrans()"><font class="textblack">ALL</font></td><td width="30%"  align="middle"><input type="radio" name="rdtrans" onclick="GetTrans()"><font class="textblack">Mobile</font></td>								<td width="30%"  align="middle"><input type="radio" name="rdtrans" onclick="GetTrans()"><font class="textblack">INet</font></td>
								<td width="30%"  align="middle"><input type="radio" name="rdtrans" onclick="GetTrans()"><font class="textblack">BRC</font></td>
								</tr>
</table>
										</td>
									</tr>
									<tr id = "divdates" style="DISPLAY: Block">
										<td width="20%" align="right" height="27">Operator&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="10%"><select size="1" name="cmbDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select>
										</td>
										<td width="10%" align="left">&nbsp;From Date</td>
										<td width="10%"><input type="text" name="txtFromDate" id="txtFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
										<td width="10%">(DDMMYYYY)</td>
										<td width="10%"><p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p></td>
										<td width="10%">&nbsp;<input type="text" name="txtToDate" id="txtToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
										<td width="20%">(DDMMYYYY) &nbsp;&nbsp; <input type="button" name="btnQuery" value="Query" onclick="QueryIMPSTrans()" class="button"></td>  
							</td>
						</tr>
					</table>
					</div>
					<div id="divTrnRef" style="display=none">
						<table width="100%">
							<tr>
								<td width="25%" align="center"><font class="textblack" >REF Number</font></td>
								<td width="25%"><input type="text" name="txtRefnum" id="txtRefnum" maxlength=12 size="12" onkeypress="numeric()" class="txtautofill"></td>
								<td width="25%"><input type="button" name="btnQuery" value=" Query " onclick="QueRefTrans()" class="button"></td>
								<td width="25%"></td>
							</tr>
						</table>
					
					</div>
					<!-- start of ImpsAccwise -->
	
	<div id="divImpsAccWise" style="display=none">
<table border="0" width="100%" cellspacing="0" cellpadding="0"  class="tableborder2">

<tr>
<td>
<table border="0" width="100%" cellspacing="0" cellpadding="0"  class="tableborder2">
<tr>
										<td width="20%" align="right" height="27">Operator&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="10%"><select size="1" name="IMPSAccWisecmbDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select>
										</td>
										<td width="10%" align="left">&nbsp;From Date</td>
										<td width="10%"><input type="text" name="txtIMPSAccWiseFromDate" id="txtIMPSAccWiseFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
										<td width="10%">(DDMMYYYY)</td>
										<td width="10%"><p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p></td>
										<td width="10%">&nbsp;<input type="text" name="txtIMPSAccWiseToDate" id="txtIMPSAccWiseToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
										<td width="20%">(DDMMYYYY) &nbsp;&nbsp; </td>  
													
<td> TnxType<select size="1" name="cmbIMPSAccWisetnxtype" onchange = "TransType()">
											<option value="ALL">ALL</option>
											<option value="INWARD">INWARD</option>
											<option value="OUTWRD">OUTWARD</option>
											</select></td>
											
</tr>											
</table>	
</tr>
</td>
<tr>
<td>

<table border="0" width="100%" cellspacing="0" cellpadding="0"  class="tableborder2">
                  <tr>
                    <td width="12%" nowrap >&nbsp;&nbsp;&nbsp;&nbsp;ModuleID</td>
                    <td width="38%" align=left>&nbsp;<input name="txtIMPSAccWiseModId" size="16" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill" value="" onblur="DescrptionDisp(&quot;txtIMPSAccWiseModId&quot;)" ><input type="button" value=" L " name="IMPSAccWiseMod" onclick="IMPSAccWisemodule()" class="button"><input name="txtIMPSAccWiseModNm" class="bgcolor1" size="19" value="" readonly></td>
                    <td width="15%" nowrap >
                    <p align="right">GLCode&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </td>
                    <td width="35%%">&nbsp;&nbsp;&nbsp;<input name="txtIMPSAccWiseGLcode" onkeypress="Alphanum()" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill"  onblur="Dataarrange(txtIMPSAccWiseGLcode);DescrptionDisp(&quot;txtIMPSAccWiseGLcode&quot;)" ><input type="button" value=" L " name="IMPSAccWiseGL" onclick="IMPSAccWiseGlcode()" class="button"><input name="IMPSAccWiseGLname" size="16" class="bgcolor1" readonly></td>
                  </tr>
                  <tr>
                    <td width="12%" nowrap >&nbsp;&nbsp;&nbsp;&nbsp;Acc.No</td>
                    <td width="38%">&nbsp;<input name="IMPSAccWiseAccNo" class="txtautofill" onkeypress="Alphanum()" maxlength="16" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" size="16" onblur="GetIMPSAccWiseCustTrnsAccName()"><input type="button" value=" L " name="IMPSAccWiseAcc" onclick="IMPSAccWiseAccCode()" class="button"><input name="IMPSAccWiseAccNm" size="19" class="bgcolor1" readonly></td>
                <td width="15%"  align="left" valign="top"   height="5">	 </td>
               <td  width="35%"> &nbsp;&nbsp;&nbsp;<input type="button" name="btnIMPSAccWiseQuery" value="  Query  " onclick="IMPSAccWiseQueryIMPSTrans()" class="button"> 
				</td>
                  </tr>
 </table>
</tr>
</td>
		
</table>									
</div>
 
	
 <!-- end of imps Acc wise ---> 
					
									</td>
									</tr>
										<tr>
							<td width="90%" align="center" colspan='8'>
							
				<div id= "divmfgatmtran" style = "display=block">
				<table width ="100%">
						<tr>
							<td width="90%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=280 id=mfgatmtran name=mfgatmtran style="HEIGHT: 280px; LEFT: 0px; TOP: 0px; WIDTH: 840px" width=840 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="6">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S.No">
							<PARAM NAME="TextMatrix0" VALUE="S.No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
						</table>
						</div>
						</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end IMPS Transactions  ---->
                   
                   <!------ Start Branch Transaction Details  ---->
                  <div id="divbrtnxdtls" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Branch Channel Transactions" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font><input type ="checkbox" id = "chkcon" name = "chkcon" checked> Consolidated</td>
						</tr>
						<tr>
                <td  nowrap valign="top" colspan="10" align="center">
<table width = "100%" class= "tableborder2">
						<tr><td colspan =10>
                </td>
              </tr>
          			            
						<tr id = "divbrchandates" style="DISPLAY: Block">
							<td width="11%" align="left" height="27">&nbsp;&nbsp;&nbsp;&nbsp;Operator</td>
							<td width="10%">&nbsp;<select size="1" name="cmbbrtnxDate" onchange="toBrTnxDateDisp()">
							<option value="=">=</option>
							<option value="&gt;">&gt;</option>
							<option value="&lt;">&lt;</option>
							<option value="Between">Between</option>
							</select></td>
							<td width="10%" align="left">&nbsp;From Date</td>
							<td width="10%"><input type="text" name="txtBrTnxFromDate" id="txtBrTnxFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
							<td width="10%">(DDMMYYYY)</td>
							<td width="10%">
							<p align="center">&nbsp;&nbsp;To</p>
							</td>
							<td width="10%">&nbsp;&nbsp;<input type="text" name="txtBrTnxToDate" id="txtBrTnxToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							<td width="20%">(DDMMYYYY) &nbsp;&nbsp;<input type="button" name="btnQuery" value="Query" onclick="QueryBrTnxDtlsTrans()" class="button"></td>
						</tr>
						</td></tr></table>
									</td>
									</tr>

						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=255 id=mfgBrtnxtran name=mfgBrtnxtran style="HEIGHT: 255px; LEFT: 0px; TOP: 0px; WIDTH: 840px" width=840 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="6">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No |< App Date        |< ATMID        |< ATM Name                    |> Amount        |< Remarks                      ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S No">
							<PARAM NAME="TextMatrix0" VALUE="S No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end Branch Channel Transactions Details  ---->
                   
                   <!------ Start Branch Channel Check Transaction Status  ---->
                  <div id="divbrchnChktrnstatus" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Branch Channel Check Transaction Status" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
						</tr>
						<tr>
                <td  nowrap valign="top" colspan="10" align="center">
<table width = "100%" class= "tableborder2">
						<tr><td colspan =10>
                </td>
              </tr>
          			            
						<tr id = "divbrchanChkTrnStadates" style="DISPLAY: Block">
							<td width="11%" align="left" height="27">&nbsp;&nbsp;&nbsp;&nbsp;Operator</td>
							<td width="10%">&nbsp;<select size="1" name="cmbbrchnchktrnstatnxDate" onchange="toBrChanChkTrnStaDateDisp()">
							<option value="=">=</option>
							<option value="&gt;">&gt;</option>
							<option value="&lt;">&lt;</option>
							<option value="Between">Between</option>
							</select></td>
							<td width="10%" align="left">&nbsp;From Date</td>
							<td width="10%"><input type="text" name="txtBrChaChkTrnStaFromDate" id="txtBrChaChkTrnStaFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
							<td width="10%">(DDMMYYYY)</td>
							<td width="10%">
							<p align="center">&nbsp;&nbsp;To</p>
							</td>
							<td width="10%">&nbsp;&nbsp;<input type="text" name="txtBrChaChkTrnStaToDate" id="txtBrChaChkTrnStaToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							<td width="20%">(DDMMYYYY) &nbsp;&nbsp;<input type="button" name="btnQuery" value="Query" onclick="QueryBrChaChkTrnSta()" class="button"></td>
						</tr>
						</td></tr></table>
									</td>
									</tr>

						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=255 id=mfgBrChaChkTrnSta name=mfgBrChaChkTrnSta style="HEIGHT: 255px; LEFT: 0px; TOP: 0px; WIDTH: 840px" width=840 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="6">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No |< App Date        |< ATMID        |< ATM Name                    |> Amount        |< Remarks                      ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S No">
							<PARAM NAME="TextMatrix0" VALUE="S No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end Branch Channel Check Transaction Status  ---->
              
              
                   <!------ Start Intra Funds Transfer  ---->
                  <div id="divIntraFndsTrns" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Intra Funds Transfer" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font><input type ="checkbox" id = "chkconintra" name = "chkconintra" checked> Consolidated</td>
						</tr>
						<tr>
                <td  nowrap valign="top" colspan="10" align="center">
<table width = "100%" class= "tableborder2">
						<tr><td colspan =10>
                </td>
              </tr>
          			            
						<tr id = "divIntraFndsTrnsdates" style="DISPLAY: Block">
							<td width="11%" align="left" height="27">&nbsp;&nbsp;&nbsp;&nbsp;Operator</td>
							<td width="10%">&nbsp;<select size="1" name="cmbIntraFndsTrnstnxDate" onchange="toIntraFndsTrnsDateDisp()">
							<option value="=">=</option>
							<option value="&gt;">&gt;</option>
							<option value="&lt;">&lt;</option>
							<option value="Between">Between</option>
							</select></td>
							<td width="10%" align="left">&nbsp;From Date</td>
							<td width="10%"><input type="text" name="txtIntraFndsTrnsFromDate" id="txtIntraFndsTrnsFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
							<td width="10%">(DDMMYYYY)</td>
							<td width="10%">
							<p align="center">&nbsp;&nbsp;To</p>
							</td>
							<td width="10%">&nbsp;&nbsp;<input type="text" name="txtIntraFndsTrnsToDate" id="txtIntraFndsTrnsToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							<td width="20%">(DDMMYYYY) &nbsp;&nbsp;<input type="button" name="btnQuery" value="Query" onclick="QueryIntraFndsTrns()" class="button"></td>
						</tr>
						</td></tr></table>
									</td>
									</tr>

						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=255 id=mfgIntraFndsTrns name=mfgIntraFndsTrns style="HEIGHT: 255px; LEFT: 0px; TOP: 0px; WIDTH: 1000px" width=1000 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="9">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No      |<RefNum         |<Dr Accno          |< Dr Name               |< Cr Accno                 |<Cr Name                 |>Amount         |<Dr Remarks                         |<Cr Remarks                          ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S No">
							<PARAM NAME="TextMatrix0" VALUE="S No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end Intra funds Transfer ---->
                   
                            <!------ Start NEFT By Mobile Banking Funds Transfer  ---->
                  <div id="divNEFTByMobileFrnTrns" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="NEFT By Mobile Funds Transfer" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font><input type ="checkbox" id = "chkconNEFT" name = "chkconNEFT" checked> Consolidated</td>
						</tr>
						<tr>
                <td  nowrap valign="top" colspan="10" align="center">
<table width = "100%" class= "tableborder2">
						<tr><td colspan =10>
                </td>
              </tr>
          			            
						<tr id = "divNEFTByMobileFrnTrnsdates" style="DISPLAY: Block">
							<td width="11%" align="left" height="27">&nbsp;&nbsp;&nbsp;&nbsp;Operator</td>
							<td width="10%">&nbsp;<select size="1" name="cmbNEFTByMobileFrnTrnstnxDate" onchange="toNEFTByMobileFrnTrnsDateDisp()">
							<option value="=">=</option>
							<option value="&gt;">&gt;</option>
							<option value="&lt;">&lt;</option>
							<option value="Between">Between</option>
							</select></td>
							<td width="10%" align="left">&nbsp;From Date</td>
							<td width="10%"><input type="text" name="txtNEFTByMobileFrnTrnsFromDate" id="txtNEFTByMobileFrnTrnsFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
							<td width="10%">(DDMMYYYY)</td>
							<td width="10%">
							<p align="center">&nbsp;&nbsp;To</p>
							</td>
							<td width="10%">&nbsp;&nbsp;<input type="text" name="txtNEFTByMobileFrnTrnsToDate" id="txtNEFTByMobileFrnTrnsToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							<td width="20%">(DDMMYYYY) &nbsp;&nbsp;<input type="button" name="btnQuery" value="Query" onclick="QueryNEFTByMobileFrnTrns()" class="button"></td>
						</tr>
						</td></tr></table>
									</td>
									</tr>

						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=255 id=mfgNEFTByMobileFrnTrns name=mfgNEFTByMobileFrnTrns style="HEIGHT: 255px; LEFT: 0px; TOP: 0px; WIDTH: 1000px" width=1000 VIEWASTEXT>
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="9">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No      |<RefNum         |<Dr Accno          |< Dr Name               |< Cr Accno                 |<Cr Name                 |>Amount         |<Dr Remarks                         |<Cr Remarks                          ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S No">
							<PARAM NAME="TextMatrix0" VALUE="S No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end NEFT By Mobile Banking Funds Transfer ---->
                </td>
              </tr>
            </table>

            </center>
          </div>
              
                
                
          </td>
        </tr>
       
        <tr>
          <td width="100%" height="32"><center>
          <div align="center">
            <center>
     <table width="10%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 187px" class="tablebordermain">
            <tr>
              <td width="100%"><input name="cmdQuery" onclick="Report('report')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('excel')" type="button" value=" XLReport " class="button"><input type="button" value="Cancel" name="cmdCancel" class="button" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/frmIMPSWiseReport.aspx"%>&quot;"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
            </tr>
          </table>

          
            <input type="hidden" name="hpr" value="<%=session("PRECISION")%>">
            <input type="hidden" name="hreport" ><input type=hidden name="postdata">
            <input type="hidden" name="hdnrefno" id ="hdnrefno">
          
            </div>
          </center></center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="hmod" value="<%=session("module")%>"><input type="hidden" name="status">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
    <iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="getDtls.aspx"></iframe>
	<iframe id="iGetDtls" align="center" style="display: block" frameborder="0" framespacing="0" height="0" width="0" src="getAtmDtls.aspx"></iframe>
                                              
      </td>
    </tr>
  </table>
</form>
</body>
</html>
