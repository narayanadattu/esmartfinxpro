<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="ATMOpening.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.ATMOpening" %>
<html>
<%

'***********************************************************************************

'*	Name Of the File :  ATMOpening.aspx							  					
'*	Purpose	  	     : Closing accounts of SB,Current & Loan Modules				
'*	Other Forms used :  
'*	Other Forms used :  changelist.asp,changecounter.asp,changemasterdetails.asp,
'							changerequestconfirmation.asp						     *
' 		                (changemasterdetails.asp is to show the details of JointHolder,
'							Nominee,Guardian)'
' 		                (changerequestconfirmation.asp is to update the database)                      
'|----------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	                  
'|----------------------|------------------|------------|---------------------------|
'|				        |    03-JUL-2006   |   3.0      |		                    |     
'|				        |                  |	        |                           |
'|----------------------------------------------------------------------------------|
'************************************************************************************


appdate=session("applicationdate")
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")	
 dim userid	
	userid=session("userid")	
	strreturn=Request.QueryString("record")
	moduleid=session("module")	
	msgcnt=1
	if len(strreturn)>0 then
		
		strmsg=split(strreturn,"|")
		result = strmsg(0)

		if ubound(strmsg)>0 then	
			strval=strmsg(1)
			strreturn = strmsg(1)
		else
			strval=""
		end if
				
		
'		if ubound(strmsg)>0 then
'			strreturn=strmsg(1)
'			result=strmsg(0)		
'		else
'			'result="SUCCESS"
'			strval=strreturn
'		end if
'		
'		if ubound(strmsg)>0 then
'			strval=strmsg(1)
'		end if		

	end if

	  objfetch=server.CreateObject("queryrecordsets.fetchrecordsets")
	
	  rsfetch=server.CreateObject ("adodb.recordset")
	  rsfetch1=server.CreateObject ("adodb.recordset")
	
	'  rsfetch1=objfetch.singlerecordset("GenOperInstMst","narration,opercode")
	  rsfetch=objfetch.singlerecordset("GenAccountStatusMst","narration,statuscode")
	'  rsfetch2=server.CreateObject ("adodb.recordset")
	'  rsfetch2=objfetch.singlerecordset("GenCategoryMst","narration,categorycode")
%>


<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">

<title>ATM Opening</title>
<meta content="text/html; charset=windows-1252" http-equiv="Content-Type">
<meta content="Microsoft FrontPage 4.0" name="GENERATOR">
<meta content="FrontPage.Editor.Document" name="ProgId">

<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE="javascript">
<!--
var st
var accnocheck=""
var divstatus=""
var oldstring=""
var newstring=""
var key=""
var branchid=""
var currencyid=""
var moduleid=""
var glcodeid=""
var accnoid=""
var tablename=""
var rowcode=""
var colseffected=""
var cis=false

//getotherdetails()

function Branch()
{
	
	var branch="Branch"	
	 var user="<%=userid%>" // log in userid
			
	st=branch
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:150px;DialogLeft:225px;DialogTop:190px")
}

//-----------------------To Assign Branch details to text boxes----------------------

 function Branchid(kstr)
{	
	assign(kstr,window.document.frmAtmOpen.txtBrdesc,window.document.frmAtmOpen.txtBrcode)      	    

}

function Currency()
{
	st="Currency"	
	if(window.document.frmAtmOpen.txtBrcode.value=="")
	{    
		alert("Branch  Code should not be null..")
		return;
	}
	else
	{
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:150px;DialogLeft:560px;DialogTop:190px")
	}	
}

//------------------------To Assign Currrency details to text boxes-------------------

 function Currencyid(kstr)
{
    kstr=kstr.split("-----")
    
    window.document.frmAtmOpen.txtCrdesc.value=kstr[0]
    window.document.frmAtmOpen.txtCrcode.value=kstr[1]
 }


function Glcode()
{	
	var glcode="Glcode"
	var brcode=window.document.frmAtmOpen.txtBrcode.value
	var crcode=window.document.frmAtmOpen.txtCrcode.value.toUpperCase() 
	var modcode=window.document.frmAtmOpen.txtModcode.value.toUpperCase() 
	  
		 
	if(brcode=="")
	{
		alert("Branch Code should not be null..") 
		return;
	
	}
	else if(crcode=="")
	{
		alert("Currency Code should not be null..")
		return;
	}
	else if(modcode=="")
	{
		alert("ModuleId should not be null..") 
		return;
	
	}
	else if(modcode=="LOCKER")
	{
		st="LKRGL"+"|"+brcode +"|"+modcode+"|"+crcode
		window.showModalDialog("changelist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:150px;DialogLeft:560px;DialogTop:190px")
	}
	else
	{
	glcode="ATMGL"
	st=glcode+"|"+modcode+"|"+crcode
	window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:380px;DialogHeight:170px;DialogLeft:560px;DialogTop:190px")
	
	
	}
}

//--------------------------To Assign GLcode details to text boxes-------------------

function Glcodeid(kstr)
{ 
assign(kstr,window.document.frmAtmOpen.txtGldesc ,window.document.frmAtmOpen.txtGlcode)
	if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{
	 GetAccountNo()
	 }
}

function CheckATMID()
{
var vin="checkATMID"+"|"+window.document.frmAtmOpen.txtATMid.value
window.document.all['idetails'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function DisplaycheckATMID(kstr)
{
	if (kstr == "Yes")
	{
	alert("ATM ID Already Exits");
	window.document.frmAtmOpen.txtATMid.value = "";
	}
}

function GetAccountNo()
{
var vin="GetAccountNo"+"|"+window.document.frmAtmOpen.txtBrcode.value+"|"+window.document.frmAtmOpen.txtGlcode.value
window.document.all['idetails'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function DisplayAccNo(kstr)
{
window.document.frmAtmOpen.txtAccountno.value = kstr
}

function Accoutno()
{
var brcode=window.document.frmAtmOpen.txtBrcode.value
var glcode = window.document.frmAtmOpen.txtGlcode.value

	st="ATMAccNo"+"|"+brcode+"|"+glcode
	window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:380px;DialogHeight:170px;DialogLeft:560px;DialogTop:190px")
}

function DispAccNo(kstr)
{ 
var kstr1  = kstr.split("-----")

window.document.frmAtmOpen.txtNarration.value = kstr1[0]
window.document.frmAtmOpen.txtAccountno.value = kstr1[1]
window.document.frmAtmOpen.txtATMid.value = kstr1[2]

}

function OK()
{
	//alert("OK");
	var acno=window.document.frmAtmOpen.txtAccountno.value;
	var narration=window.document.frmAtmOpen.txtNarration.value;
	var brcode=window.document.frmAtmOpen.txtBrcode.value;
	var crcode=window.document.frmAtmOpen.txtCrcode.value.toUpperCase();
	var modcode=window.document.frmAtmOpen.txtModcode.value.toUpperCase();
	var glcode=window.document.frmAtmOpen.txtGlcode.value;
	var atmid = window.document.frmAtmOpen.txtATMid.value;
	
	if(brcode=="")
	{
		alert("Branch Code should not be null..") 
		return;
	
	}
	else if(crcode=="")
	{
		alert("Currency Code should not be null..")
		return;
	}
	else if(modcode=="")
	{
		alert("Module Id should not be null..") 
		return;
	
	}
	else if(glcode=="")
	{
		alert("Gl Code should not be null..") 
		return;
	
	}
	else if(acno=="")
	{
		alert("A/C No Should not be Null");
		return;
	}
	else if(narration=="")
	{
		alert("A/C No Narration Should not be Null");
		return;
	}
	else if(atmid == "")
	{
		alert("ATM ID Should not be Null");
		return;
	}
		
	if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{	
		st="ATMOpening";
		window.document.frmAtmOpen.action="ATMCashAllotInsert.aspx" + "?"+"st="+st //+ "?"+"st="+st
		window.document.frmAtmOpen.method ="post"
		window.document.frmAtmOpen.submit()
	}
	
	if(window.document.frmAtmOpen.rdCheckedMod.checked==true)
	{
		st="ATMModify";
		window.document.frmAtmOpen.action="ATMCashAllotInsert.aspx" + "?"+"st="+st //+ "?"+"st="+st
		window.document.frmAtmOpen.method ="post"
		window.document.frmAtmOpen.submit()
	}
	
}

function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="ATMOpening.aspx" 
		
	}
}	

//-->
</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function GetDateDif(kstr,str1)
{
	if (eval(kstr)>0)
	{
		alert("Date Of Request should not be greater than application date..")
		if(str1=="xxx")
			window.document.frmAtmOpen.txtAppdate.value="" 
		if(str1=="txtJdob")
			window.document.frmAtmOpen.txtJminordob.value=""
		if(str1=="txtDoc")
			window.document.frmAtmOpen.txtdocdate.value=""
	}
}

function dtpAppdate_CloseUp() 
{
Datepick(window.document.frmAtmOpen.dtpAppdate,window.document.frmAtmOpen.txtAppdate )
st=window.document.frmAtmOpen.txtAppdate.value + "|" + "xxx"

window.document.frames(1).frmacc.hFlds.value=st
window.document.frames(1).frmacc.action="datecheck.aspx"
window.document.frames(1).frmacc.method="post"
window.document.frames(1).frmacc.submit(); 
}

function dtpJointdob_CloseUp() 
{
Datepick(window.document.frmAtmOpen.dtpJointdob,window.document.frmAtmOpen.txtJminordob )
st=window.document.frmAtmOpen.txtJminordob.value + "|" + "txtJdob"
window.document.frames(1).frmacc.hFlds.value=st
window.document.frames(1).frmacc.action="datecheck.aspx"
window.document.frames(1).frmacc.method="post"
window.document.frames(1).frmacc.submit();
}

function document_onclick() {
window.document.all.result.style.visibility="hidden"
}

function dtpJointDt_CloseUp() {
Datepick(window.document.frmAtmOpen.dtpJointDt,
window.document.frmAtmOpen.txtJointDob)
}

function dtpDocDate_CloseUp() {
Datepick(window.document.frmAtmOpen.dtpDocDate,
window.document.frmAtmOpen.txtdocdate)
st=window.document.frmAtmOpen.txtdocdate.value + "|" + "txtDoc"

window.document.frames(1).frmacc.hFlds.value=st
window.document.frames(1).frmacc.action="datecheck.aspx"
window.document.frames(1).frmacc.method="post"
window.document.frames(1).frmacc.submit();
}

function modeState()
{
	if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{
	  window.document.frmAtmOpen.butAccno.disabled=true;
	  window.document.frmAtmOpen.txtATMid.disabled = false;
	  }
	if(window.document.frmAtmOpen.rdCheckedMod.checked==true)
	{
      window.document.frmAtmOpen.butAccno.disabled=false;
      window.document.frmAtmOpen.txtATMid.disabled = true;
	}	
}
function funformclear()
{
	window.document.frmAtmOpen.txtGlcode.value="";
	window.document.frmAtmOpen.txtGldesc.value="";
	window.document.frmAtmOpen.txtAccountno.value="";
	window.document.frmAtmOpen.txtNarration.value="";
	window.document.frmAtmOpen.txtATMid.value="";
}

function fillonload()
{
	var prec=eval('<%=session("PRECISION")%>')
	var precval="1"
	
     for(icnt=0;icnt<prec;icnt++)
 	  var precval=precval+"0"
      window.document.frmAtmOpen.hidprecision.value=prec //precval	  
	   
     //window.document.frmAtmOpen.butAccno.style.display="none"
     //window.document.frmAtmOpen.txtNarration.style.display="none"
}


//-->
</SCRIPT>
<SCRIPT language="javascript" event="DblClick" for="Mfgaccdtls">
<!--
 Mfgaccdtls_DblClick()
//-->
			</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=dtpAppdate EVENT=CloseUp>
<!--
 dtpAppdate_CloseUp()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpJointdob EVENT=CloseUp>
<!--
 dtpJointdob_CloseUp()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=document EVENT=onclick>
<!--
 document_onclick()
//-->

</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=dtpJointDt EVENT=CloseUp>
<!--
 dtpJointDt_CloseUp()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpDocDate EVENT=CloseUp>
<!--
 dtpDocDate_CloseUp()
//-->
</SCRIPT>
</head>
<body onload="fillonload();GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();" topmargin="0" leftmargin="0">

<form name="frmAtmOpen" action="AccountCloseDBOper.aspx">
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="100%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
        <div class="menuBar">
            <table cellpadding="0" cellspacing="0" width="100%" border=0>
                <tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                   
                    <td width="50%" align="CENTER" height="22" class="subHeader">
                        <h2>ATM Account Opening</h2>
                    </td>
                    <td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
                </tr>
            </table>
        </div>
        <div id="menucontrol"></div> 
  <input type="hidden" name="hmodify"><input type="hidden" name="hinsert"><input type="hidden" name="hreturn"><input type="hidden" name="hchange">
  <div align="center" >
    <center>
    <%appdate=formatdatetime(session("applicationdate"),1)%>

    <table border="0" cellpadding="0" cellspacing="0" width="100%" class="tablebordermain">
      <tbody>
        <tr>
          <td>
          <table border="0" width="100%" cellspacing="0" cellpadding="0" height="20">
            
          </table>
          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            
            <tr>
						<td width="400" align="right"><input type="radio" name="optCheck" id=rdCheckedNew onclick="modeState();funformclear()" checked>New</td>
						<td width="400" align="right"><input type="radio" name="optCheck" id=rdCheckedMod onclick="modeState();funformclear()" >Modify</td>
					</tr>
          </table>
          <table class="tablebordermain" cellpadding="0" cellspacing="0" width="100%">
            <tbody>
              <tr>
                <td>
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tbody>
                    <tr>
                      <td align="center" width="150%" height="15" colspan="2">
                      <font class="textblue">
                      <span id="result" style="display:none"><%=result%></span>
                      </font>
                      </td>
                      <td></td>
                    </tr>
                        </tr>
                  </tbody>
                </table>
                <div align="center">
                  <table cellpadding="0" cellspacing="0" width="100%" class="tablebordermain"  >
                    <tbody>
                      <tr>
                        <td valign="top" width="100%">
                        <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                          <tr>
                            <td valign="top" width="100%">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                              <tbody>
                                <tr>
                                  <td width="100%">
                                  <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                      <tr>
                                        <td valign="top" width="86%">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                          <tbody>
                                            <tr>
                                              <td valign="top" width="100%">
                                              <table border="0" width="100%" cellspacing="0" cellpadding="0" height="132">
                                                <tr>
                                                  <td align="left" width="12%" height="27">&nbsp;Branch Code</td>
                                                  <td align="left" width="38%" height="27"><input maxlength="10" name="txtBrcode" readonly class="txtautofill" size="10" style="text-align:left" readonly value="<%=SESSION("branchcode")%>"><input name="butBrid" onclick="Branch()" type="button" value=" L "><input class="bgcolor1" name="txtBrdesc" size="18" readonly value="<%=SESSION("branchnarration")%>" class="bgcolor1"></td>
                                                  <td width="13%" height="27">&nbsp;Currency Code</td>
                                                  <td align="left" width="35%" colspan="3" height="27"><input name="txtCrcode" readonly class="txtautofill" maxlength="10" size="10"  value="<%=session("currencycode")%>" ><input name="butCrid" onclick="Currency()" type="button" value=" L "><input name="txtCrdesc" class="bgcolor1" size="18" readonly value="<%=SESSION("currencynarration")%>" class="bgcolor1"></td>
                                                </tr>
                                                <tr>
                                                  <td align="left" width="12%" height="27">&nbsp;Module ID</td>
                                                  <td align="left" width="38%" height="27">    <input name="txtModcode" size="10" class="txtautofill" readonly maxlength="6" value="<%=session("module")%>" onblur="getModule()" style="text-transform:uppercase"><input name="butModid" onclick="Module()" type="button" value=" L " disabled><input name="txtModdesc" class="bgcolor1" size="18" readonly value="<%=session("modulenarration")%>"></td>
                                                  <td width="13%" height="27">&nbsp;GL Code</td>
                                                  <td align="left" width="35%" colspan="3" height="27">
                                                  <input name="txtGlcode"  onkeypress="Alphanum()"  size="10" class="txtautofill" maxlength="6" onkeyup='window.document.frmAtmOpen.txtGldesc.value=""' onblur="getGlcode()" style="text-transform:uppercase"><input name="butGlid" onclick="Glcode()" type="button" value=" L "><input name="txtGldesc" size="18" class="bgcolor1" readonly></td>
                                                </tr>
                                                <tr>
<td align="left" width="12%" height="27">&nbsp;Acc.No.</td><td align="left" width="38%" height="27"><input name="txtAccountno" class="txtautofill" size="10" maxlength="20" style="text-transform:uppercase" onkeyup='window.document.frmAtmOpen.txtNarration.value=""' onblur="getaccountno()" onkeypress="Alphanum()" readonly><input name="butAccno" onclick="Accoutno()" type="button" value=" L " disabled><input name="txtNarration" class="bgcolor1" size="18" style="text-transform:uppercase"></td><td align="left" width="13%" height="27">&nbsp;ATM ID</td><td align="left" width="35%" height="27"><input name="txtATMid" class="txtautofill" size="10" maxlength="8"  onkeypress="Alphanum()" onblur = "CheckATMID()" ></td>
</tr>

<tr><td></td><td></td></tr></table><div id="dstatus" style="width: 213; height:13">
                                      </div>
          </center></td>                                
                                          </tbody>
                                          <tr>
                                            <td>
                                              <div id="divFlex" style="display: none; width: 310; height: 19"></div>
                                            </td>
                                          </tr>
                                        </table>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            </td>
                          </tr>
                        </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                
            </tbody>
          </table>

	<table width = "100%" class="tablebordermain">
    <tr>
      <td align="center" width = "100%">       
       <input name="butok" onclick="OK()" type="button" value="  Ok  " class="button"><input name="butcancel" type="button" value=" Cancel " onclick="location.replace(&quot;ATMOpening.aspx&quot;)" class="button"><input id="Butexit" name="Butexit" type="button" value="    Exit    " onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button">
       </td>
       </tr>
       <tr>
       <td>
		
      </td>
    </tr>
  </table>
		  <input type="hidden" name="hbchk">
		  <input type="hidden" name="hbval">
          <input type="hidden" name="hidkey">
          <input type="hidden" name="hidoldstring">
          <input type="hidden" name="hidnewstring">
          <input type="hidden" name="hidtable">
          <input type="hidden" name="hidcols">
          <input type="hidden" name="hidrowcode">
          <input type="hidden" name="hidDiv">
          <input type="hidden" name="hidvals">
          <input type=hidden name="hMinor">
          <input type="hidden" name="hidMainstr">
          <input type="hidden" name="hidMode">
          <input type="hidden" name="hidrow">
          <input name="hidprecision" type="hidden"> 
          <input name="hidSaction" type="hidden">
          <input name="hidClosedDisb" type="hidden">  
          <input name="hidClosedDisbAmt" type="hidden"> 
          <input name="hidinsrt" type="hidden"> 
          <input type ="hidden" id="txtChk" name="txtChk">  
          <IFRAME id="idetails" align=center             
           style="COLOR: #c7ba95;  LEFT: 0px; TOP: 0px; WIDTH: 0px height=0px" height=0 width=0
                 valign="top"></IFRAME>          
          </form>
        </td>
      </tr>
    </table>
  </div>
   
  <iframe src="list.aspx" width=0 height=0></iframe>
 <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>

</body>

