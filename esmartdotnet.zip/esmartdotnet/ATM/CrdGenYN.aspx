<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CrdGenYN.aspx.vb" Inherits="eSmartDotNet.CrdGenYN" %>
<%
	dim ObjCust 
	dim strmsg
	dim brcode,curcode,modcode,glcode,accno,inscode,custcode,custname,rtype,chqtype 'to store textbox values
	dim startno,endno,chqno,bkorlf,noofleafs,appdate,userid,machineid,sysdate,appby,appmachine,sysyear
	dim strvalue,res,res1,chno,strmode,strval
	DIM TOCHNO 
	dim strmsttab
	
	dim obj1,rs1
	
	obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
	rs1=server.CreateObject("adodb.recordset")
	
	appdate=cstr(session("applicationdate"))
	userid=cstr(session("userid"))
	machineid=cstr(session("machineid"))
	
	strmode=Request.Form("mercust")
	strval=split(strmode,"~")
	
	Dim ObjTrans,strResult
	ObjTrans=server.CreateObject("GeneralTransactions.DBTransactions")	
	Dim arrTrans(4,4)
	Dim i,j
	Dim tranno
	
	brcode = strval(3)
	'strval(1)
	'modcode = strval(2)
		
	if strval(0)="GENYNSTAT" then
	
	
		ArrTrans(0,0)="U" 
		ArrTrans(0,1)="ATMCRDDTLS"
		ArrTrans(0,2)="GENYN"
		ArrTrans(0,3)="'Y'"
		ArrTrans(0,4)="TRANSTATUS='A' AND GENYN='N' " & strval(1) & " "
		
		ArrTrans(1,0)="I" 
		ArrTrans(1,1)="ATMFILEGEN"
		ArrTrans(1,2)="SEQNUM, FILENAME, FILECNT, APPLICATIONDATE, USERID, MACHINEID"
		ArrTrans(1,3)="'" & strval(2) & "','" & strval(3) & "','" & strval(4) & "','" & appdate & "','" & userid & "','" & machineid & "'"
		ArrTrans(1,4)=""
		
		StrResult=ObjTrans.DataTransactions(arrTrans,cstr(brcode),cstr(userid),cstr(machineid),cstr(appdate),"Y")
		
		if mid(StrResult,1,21)="Transaction Sucessful"
			StrResult="Sucessful."
		end if
		Response.Redirect ("frmCardfile.aspx?record=" & StrResult )
	
	end if

%>