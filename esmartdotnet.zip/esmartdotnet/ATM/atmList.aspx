<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="atmList.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.atmList" %>
<% Response.CacheControl = "no-cache" %>
<% Response.AddHeader("Pragma", "no-cache") %>
<% Response.Expires = -1 %>
<% hidsearch=request.form("hidsearch")%>
<HTML>
	<HEAD>
	<base target="_self">
		<title>eSmartBanker</title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<%
strType=Request.QueryString("st")
%>
<SCRIPT LANGUAGE="javascript">

function displaydiv()
	{
	var type="<%= strType%>"
	
	var requestType = type
//	alert(requestType)
		if((requestType=="IMPSReferenceNo") || (requestType=="ATMReferenceNo") || (requestType=="IMPSBRCHANReferenceNo") || (requestType=="IMPSMOBReferenceNo") || (requestType=="BRCHANIMPSReferenceNo") || (requestType=="BRCHANIMPSRefTrack"))
		{
		document.getElementById("divsearch").style.display="block"
		document.frmList.txtsearch.focus();
		}
		
     var hidstr="<%=hidsearch%>"
     var searchstr
     if(hidstr!="")
     {
     var searchstr=hidstr.split("|")
     document.getElementById("cmb_search").value=searchstr[0]
     window.document.frmList.txtsearch.value=searchstr[1]
     }
     
	}

	function funcsearch()
	{
	var strdata= "<%= strType%>" 
		if(window.document.frmList.cmbsearch.selectedIndex<0)
		{
		alert("Plaese select name or number");
		return
		}
		else if(window.document.frmList.txtsearch.value=="")
		{
		alert("plaese enter type for search");
		return
		}	
		else
		{		
		window.document.frmList.hidsearch.value=window.document.frmList.cmbsearch.options[window.document.frmList.cmbsearch.selectedIndex].value 
		+ "|" +window.document.frmList.txtsearch.value
				
		window.document.frmList.action="atmList.aspx?st=" + strdata
		window.document.frmList.method="post"
		window.document.frmList.submit();
		}
	}
 
 function cleartext()
    {
		document.frmList.txtsearch.value="";
    }
    
function List()
{

var callerWindowObj = dialogArguments;
var kstr,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else
 {
	kstr= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
////--------for GenGlParam.aspx(General Parameters)-------------------------------------------
///for branch code	
if (type=="Branch")
{
	//window.attachEvent(window.opener.Branchid(kstr))
	callerWindowObj.Branchid(kstr)
	window.close()
}
///-----------------------------------------------------------------------------
else if (type=="Currency")
{
	//window.attachEvent(window.opener.Currencyid(kstr))
	callerWindowObj.Currencyid(kstr)
	window.close()
}	
else if (type.substring(0,8)=="GETINVID")
{
	//window.attachEvent(window.opener.Currencyid(kstr))
	callerWindowObj.investmentid(kstr)
	window.close()
}	
else if (type.substring(0,10)=="TYPEINVGET")
{
	//window.attachEvent(window.opener.Currencyid(kstr))
	callerWindowObj.investmenttype(kstr)
	window.close()
}	
else if (type.substring(0,8)=="NOINVGET")
{
	//window.attachEvent(window.opener.Currencyid(kstr))
	callerWindowObj.investno(kstr)
	window.close()
}	
else if (type.substring(0,9)=="GLLNKCODE")
{
	callerWindowObj.GLLnkDesc(kstr)
	window.close()
}
else if (type.substring(0,11)=="GLLNKGLCODE")
{
	callerWindowObj.Glcodeid(kstr)
	window.close()
}
else if (type.substring(0,10)=="GLLNKACCNO")
{
	callerWindowObj.AccountDesc(kstr)
	window.close()
}
else if (type.substring(0,9)=="INVMISCPL")
{
	callerWindowObj.ModuleDesc(kstr)
	window.close()
}

else if (type.substring(0,12)=="VIEWNOINVGET")
{
	//window.attachEvent(window.opener.Currencyid(kstr))
	callerWindowObj.investno(kstr)
	window.close()
}


else if (type=="BLevel")
{
	window.attachEvent(window.opener.Levelid(kstr))
	window.close()
}
else if (type=="Curr")
{ //alert(kstr)
	callerWindowObj.Currid(kstr)
	window.close()
}
else if (type.substring(0,6)=="Module")
{
	window.attachEvent(window.opener.Moduleid(kstr))
	window.close()
}
else if (type=="Module")
{
	window.attachEvent(window.opener.Moduleid(kstr))
	window.close()
}

//---------------------------------------------------------------------
// for MinMaxBal.aspx in SBModule
else if (type.substring(0,6)=="Glcode")
{	
	//window.attachEvent(window.opener.Glcodeid(kstr))
	callerWindowObj.Glcodeid(kstr)
	window.close()
}
else if (type.substring(0,6)=="Glcode")
{	
	window.attachEvent(window.opener.Glcodeid(kstr))
	//callerWindowObj.Glcodeid(kstr)
	window.close()
}
else if (type.substring(0,12)=="ATMTELLERMOD")//use
{
	callerWindowObj.Modulecode(kstr);
	window.close()
}

else if(type.substring(0,12)=="Tellerglcode")//use
{
	callerWindowObj.Glcodeid(kstr);
	window.close()
}

else if(type.substring(0,9)=="ATMCRDTYP")//use
{
	callerWindowObj.Crdtyp(kstr);
	window.close()
}
else if(type.substring(0,9)=="ATMCATYPE")//use
{
	callerWindowObj.Catype(kstr);
	window.close()
}
else if(type.substring(0,11)=="ATMSCOPTYPE")//use
{
	callerWindowObj.sctype(kstr);
	window.close()
}
else if(type.substring(0,9)=="ATMRELION")//use
{
	callerWindowObj.stRlat(kstr);
	window.close()
}
else if(type.substring(0,6)=="CARDNO")//use
{
	callerWindowObj.stCrd(kstr);
	window.close()
}

else if (type.substring(0,5)=="ATMGL")
{	
	//window.attachEvent(window.opener.Glcodeid(kstr))
	callerWindowObj.Glcodeid(kstr)
	window.close()
}
else if ((type.substring(0,8)=="ATMAccNo") || (type.substring(0,11)=="ATMIDSAccNo")  || (type.substring(0,12)=="IMPSIDSAccNo"))
{	
	callerWindowObj.DispAccNo(kstr)
	window.close()
}
else if ((type.substring(0,15)=="IMPSReferenceNo") || (type.substring(0,14)=="ATMReferenceNo") || (type.substring(0,21)=="IMPSBRCHANReferenceNo") || (type.substring(0,18)=="IMPSMOBReferenceNo") || (type.substring(0,21)== "BRCHANIMPSReferenceNo")  || (type.substring(0,18)== "BRCHANIMPSRefTrack"))
{
	callerWindowObj.DisplayRefNo(kstr)
	window.close()
}
else if ((type.substring(0,14)=="TellerATMaccno")  || (type.substring(0,11)=="H2HRepAccno"))
{	
	callerWindowObj.accountid(kstr)
	window.close()
}
else if (type.substring(0,9)=="INVGlcode" || type.substring(0,10)=="RINVGlcode")
{	
	//window.attachEvent(window.opener.Glcodeid(kstr))
	callerWindowObj.Glcodeid(kstr)
	window.close()
}
///for ALL SB CA CC moduleid OR INV, MISC,PL
else if ((type.substring(0,15)=="allsbcaccmodule") || (type.substring(0,21)=="sbcaccinvmiscplmodule") )
	{
		callerWindowObj.modulecode(kstr)
		window.close()
	}
else if (type.substring(0,25)=="NACHsbcaccinvmiscplmodule") 
{
		callerWindowObj.NACHmodulecode(kstr)
		window.close()
}
else if (type.substring(0,32)=="NACHCBDTLICsbcaccinvmiscplmodule") 
{
		callerWindowObj.NACHCBDTLICmodulecode(kstr)
		window.close()
}
else if (type.substring(0,14)=="SameCardNumber")	
	{
		callerWindowObj.GetSameCards(kstr)
		window.close()
	}
else if (type.substring(0,8)=="INVAccno")
{	
	//window.attachEvent(window.opener.Glcodeid(kstr))
	callerWindowObj.GlAccno(kstr)
	window.close()
}

else if (type.substring(0,5)=="QryGl")
{
	
	window.attachEvent(window.opener.Glcodeid(kstr))
	window.close()
}

else if (type.substring(0,7)=="QueryGL")
{
	window.attachEvent(window.opener.QueryGlcodeid(kstr))
	window.close()
}

///for General parameters--------------------------------------------------------------
///for Inserting new record querying Moduleid
else if (type.substring(0,8)=="SBModule")
{
	//window.attachEvent(window.opener.ModuleId(kstr))
	callerWindowObj.ModuleId(kstr)
	window.close()
}
//// for querying the moduleid in glcodesparam.aspx form	while modification
else if(type.substring(0,13)=="QuerySBModule")
	{
		callerWindowObj.QueryModuleId(kstr)
		window.close()
	}
////---------------------------------------------------------------------------------------------
// for GenChages.aspx in SbModule

else if (type.substring(0,8)=="GLCharge")
{
	window.attachEvent(window.opener.GLChargeId(kstr))
	window.close()
}
else if (type.substring(0,7)=="GLParam")
{
	window.attachEvent(window.opener.GLParamId(kstr))
	window.close()
}
/// for CustCat.aspx(CustomerCategory) in Sbmodule
else if(type.substring(0,12)=="CustCategory")
	{
		window.attachEvent(window.opener.CategoryId(kstr))
		window.close()
	}	
	
///for Sbtypeparameters.aspx form in Sbbodule		
else if(type.substring(0,7)=="SBParam")
	{
		window.attachEvent(window.opener.SbparamId(kstr))
		window.close()
	}
	////for querying moduleid in minmaxbalpmt form	
else if(type.substring(0,11)=="QueryModule")
	{
		window.attachEvent(window.opener.QueryModuleId(kstr))
		window.close()
	}
	
	////for querying moduleid in gencharges form	
else if(type.substring(0,11)=="QueryChrgGl")
	{
		window.attachEvent(window.opener.QueryGlcode(kstr))
		window.close()
	}

			
else if(type.substring(0,9)=="BookAccNo")
	{
		window.attachEvent(window.opener.AccId(kstr))
		window.close()
	}		
/// for Stop payments Querying and to listout the stoppayno,accno,name	
else if(type.substring(0,9)=="QueryStop")
	{
		window.attachEvent(window.opener.QueryStopId(kstr))
		window.close()
	}	
	//for stop payments
else if (type=="StopBranch")
{
	window.attachEvent(window.opener.Branchid(kstr))
	window.close()
}
/// for BankBranchMaster form -------------------------------------------------------------
///branchcode
else if (type=="BankBranch")
{
	window.attachEvent(window.opener.Branchid(kstr))
	window.close()
}

///Currencycode
else if (type=="BankCurrency")
{
	window.attachEvent(window.opener.Currencyid(kstr))
	window.close()
}

//for bankid 
else if (type.substring(0,6)=="BankId")
{
	window.attachEvent(window.opener.Bankid(kstr))
	window.close()
}
///----------------------------------------------------------------------------------------	
else if (type=="QueryBranch")
{
	window.attachEvent(window.opener.Branchid(kstr))
	window.close()
}	

else if (type.substring(0,13)=="QueryCurrency")
{
	window.attachEvent(window.opener.Currencyid(kstr))
	window.close()
}	

else if (type.substring(0,8)=="StModule")
{
	callerWindowObj.ModuleId(kstr)
	window.close()
}	
else if ((type.substring(0,8)=="StUserId") || (type.substring(0,11)=="StAppUserId") ||
(type.substring(0,12)=="StWithGlCode") || (type.substring(0,11)=="StModGlCode") ||
(type.substring(0,8)=="StGlCode") || (type.substring(0,8)=="GlCodeIC"))
{
	callerWindowObj.GlcodeID(kstr)
	window.close()
}
else if (type.substring(0,8)=="StAccNos")
{
	callerWindowObj.Accnoid(kstr)
	window.close()
}
else if (type.substring(0,9)=="QryModule")
{
	window.attachEvent(window.opener.ModuleId(kstr))
	window.close()
}	
	
//----------------------------------------------------------------------------
else if (type.substring(0,5)=="Accno")
{
	window.attachEvent(window.opener.Accnoid(kstr))
	window.close()
}

else if (type.substring(0,7)=="ICAccno")
{
	callerWindowObj.AccnoIC(kstr)
	window.close()
}

else if (type.substring(0,7)=="TransNo")
{
	window.attachEvent(window.opener.TransNoid(kstr))
	window.close()
}
else if (type.substring(0,6)=="CustID")
{
	window.attachEvent(window.opener.Custid(kstr))
	window.close()
}

else if (type.substring(0,11)=="Cashiertype")
{
	window.attachEvent(window.opener.Cashiertype(kstr))
	window.close()
}
else if (type.substring(0,9)=="Cashierid")
{
	window.attachEvent(window.opener.Cashierid(kstr))
	window.close()
}


else if (type.substring(0,7)=="Cashier")
{
	window.attachEvent(window.opener.Cashiercd(kstr))
	window.close()
}

else if (type.substring(0,8)=="Bankcode")
{
	window.attachEvent(window.opener.Bankid(kstr))
	window.close()
}
//---------------------------------------------------
else if(type.substring(0,12)=="Tellermodule")
		{
		   	window.attachEvent(window.opener.modulecode(kstr))
			window.close()
		}
else if(type.substring(0,12)=="Tellerglcode")
		{
		   	callerWindowObj.Glcodeid(kstr)
			window.close()
        }
else if(type=="Tellerbranch")
		{
		    callerWindowObj.Branchcode(kstr)
			window.close()
		}
else if (type.substring(0,11)=="Telleraccno")
		{
		
		    window.attachEvent(window.opener.accountid(kstr))
			window.close()
		}
else if (type.substring(0,16)=="IMPSAccWiseAccno")
{
		    callerWindowObj.accountid(kstr)
			window.close()
}
else if(type.substring(0,10)=="PigmyAccno")
		{
		    //window.attachEvent(window.opener.accountid(kstr))
		    callerWindowObj.accountid(kstr)
			window.close()
		}	
else if(type.substring(0,10)=="PigmyAgent")
		{
		    //window.attachEvent(window.opener.accountid(kstr))
		    callerWindowObj.agentid(kstr)
			window.close()
		}				
else if(type.substring(0,13)=="TellerIssBank" || type.substring(0,16)=="ADDTellerIssBank")
		{
		    //window.attachEvent(window.parent.IssBankid(kstr))
		    callerWindowObj.IssBankid(kstr)
			window.close()
		}		
else if(type.substring(0,15)=="TellerIssBranch" || type.substring(0,18)=="ADDTellerIssBranch")
		{
		    callerWindowObj.IssBranchid(kstr)
			window.close()
		}		
else if(type.substring(0,14)=="TellerBnkAccno")
		{
		    callerWindowObj.BnkAccid(kstr)
			window.close()
		}		
else if(type.substring(0,18)=="TellerBnkAccGlCode")
		{
		    callerWindowObj.BankGlid(kstr)
			window.close()
		}
else if(type.substring(0,6)=="CashID")
		{
		    callerWindowObj.Cashierid(kstr)
			window.close()
		}
}
}
			</SCRIPT>
			<%
dim strTab
dim strCond
dim obj,rs
  rs=server.CreateObject("adodb.recordset")  
  obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  
  objrep = server.CreateObject("ReportPurposeOnly.Reportonly")


 modi=session("module")
''''''' for Stoppayment--------------------------------
if strType ="Branch" then
	rs=obj.singlerecordset("GENBANKBRANCHMST","Branchcode,narration")
elseif strType ="StopBranch" then
	rs=obj.singlerecordset("GENBANKBRANCHMST a,genusermst b","a.Branchcode,a.narration","b.ABBUSERYN='Y' and upper(trim(a.branchcode))=upper(trim(b.branchcode))")	
elseif strType ="QueryBranch" then
	rs=obj.singlerecordset("genstoppaymst a,GENBANKBRANCHMST b","distinct(a.Branchcode),b.narration","upper(trim(a.branchcode))=upper(trim(b.branchcode))")		
elseif strType ="StopBranch" then
	rs=obj.singlerecordset("GENBANKBRANCHMST a,genusermst b","a.Branchcode,a.narration","b.ABBUSERYN='Y' and upper(trim(a.branchcode))=upper(trim(b.branchcode))")
elseif strType="Currency" then
	rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,PRECISION")
elseif left(strType,13)="QueryCurrency" then
strflds=split(strType,"~")
	rs=obj.singlerecordset("genstoppaymst a,GENCURRENCYTYPEMST b","distinct(a.currencycode),b.narration", _
				"a.currencycode=b.currencycode and a.branchcode='" & strFlds(1) & "'")
elseif strType="Curr" then
	rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,precision")
elseif strType="Module" then
     rs=obj.singlerecordset("genmoduletypesmst","moduleid,Narration","implementedyn='Y'")
'''-------------------------------------------------------------------------------------	
'' for BankBranchMaster form -------------------------------------------------------------
''branchcode
elseif strType="BankBranch" then
	   rs=obj.singlerecordset("GENBANKBRANCHMST","Branchcode,narration")
''branchcode
elseif strType="BankCurrency" then
	  rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,precision")

elseif left(strType,6)="BankId" then
strArr=split(strtype,"*")
rs=obj.singlerecordset("GENOTHERBANKMST","BANKCODE,BANKNAME", _
		"upper(trim(branchcode))='" & strArr(1) & "'")
'''------------------------------------------------------------------------------------------
'''  For MinMaxBal.aspx from in SbModule 

elseif left(strType,6)="Glcode" then
	k=split(strType,"|")
	
 rs=obj.singlerecordset("GenGlsheetmst", _
						"distinct(glcode),narration","moduleid='"& k(1) &"'" )

elseif left(strType,12)="ATMTELLERMOD" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("genmodulemst","moduleid,narration","moduleid IN('CA','CC','SB')")

elseif left(strType,12)="Tellerglcode"  then
	 obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	k=split(strType,"|")
	 rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))

elseif left(strType,9)="ATMCRDTYP" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("GENCARDTYPEMST","CARDTYPE, DESCRIPTION","STATUS='R'")
elseif left(strType,9)="ATMCATYPE" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("GENCARDCATEGORYSMST","CARDCATEGORYTYPE, DESCRIPTION","STATUS='R'")
elseif left(strType,11)="ATMSCOPTYPE" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("GENCARDSCOPEMST","CARDSCOPETYPE, DESCRIPTION","STATUS='R'")
elseif left(strType,9)="ATMRELION" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("GENRELATIONSMST","CODE,NARRATION","")
elseif left(strType,6)="CARDNO" then 'using
	k=split(strType,"|")
	 rs=obj.singlerecordset("ATMCARDLNKDTLS","CARDNO","accno='" & k(3) & "' AND glcode='" & k(2) & "' AND cardtype='" & k(5) & "' AND STATUS='R' AND branchcode='" & k(4) & "'")
	 
elseif left(strType,9)="GLLNKCODE" then
k=split(strType,"|")
if k(1) = "NEW"  then
sqlstr="SELECT 'ATMREC' CODE ,'ATM RECONCILATION' DESCRIP FROM DUAL UNION SELECT 'SRVCHG' CODE ,'SERVICE CHARGES' DESCRIP FROM DUAL UNION SELECT 'SRVTAX' CODE ,'SERVICE TAX' DESCRIP FROM DUAL"
else
 sqlstr="SELECT code,code  FROM atmgllnk"
end if
rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,11)="GLLNKGLCODE" then
	k=split(strType,"|")

sqlstr="SELECT GLCODE,GLDESCRIPTION FROM GENGLMASTMST WHERE BRANCHCODE = '" & k(1) & "' AND MODULEID = '" & k(2) & "' AND  glcategory='A' AND  status='R'"
 
rs=objrep.SingleSelectStat(sqlStr)
	
elseif left(strType,10)="GLLNKACCNO" then	
	
	k=split(strType,"|")
	
	strsql = "SELECT distinct a.accno,a.name FROM " & k(1) & "MST a WHERE a.glcode='" & k(2) & "' AND a.status='R' ORDER BY to_number(a.accno)"
	
	rs=objrep.SingleSelectStat(strsql)
	 
''' for moduleid
elseif left(strType,9)="INVMISCPL" then

     k=split(strType,"|")
     rs=obj.singlerecordset("GENMODULEMST","MODULEID,NARRATION","MODULEID in ('INV','MISC','PL')")

elseif left(strType,5)="ATMGL" then
	k=split(strType,"|")
	
 rs=obj.singlerecordset("GenGlsheetmst", _
						"distinct(glcode),narration","moduleid='"& k(1) &"'" )		

elseif left(strType,8)="ATMAccNo" then
	k=split(strType,"|")
	
 rs=obj.singlerecordset("atmmst", _
						"distinct accno,name,atmid","branchcode='" & k(1) & "' and glcode ='"& k(2) &"'")

elseif left(strType,11)="ATMIDSAccNo" then
  k=split(strType,"|")
  if k(1) <> "" then
 sqlstr="SELECT 'ALL' accno ,'ALL' name FROM dual UNION SELECT accno,name FROM ATMMST where branchcode='" & k(1) & "' and glcode =  '201001' ORDER BY accno DESC"
 else
 sqlstr="SELECT 'ALL' accno ,'ALL' name FROM dual UNION SELECT accno,name FROM ATMMST where  glcode =  '201001' ORDER BY accno DESC"
 end if
 rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,12)="IMPSIDSAccNo" then
  k=split(strType,"|")
 sqlstr="SELECT accno,name FROM ATMMST WHERE glcode = '201002' ORDER BY accno DESC"
 rs=objrep.SingleSelectStat(sqlStr)

elseif  left(strType,21)="IMPSBRCHANReferenceNo" then

sqlstr= "SELECT REFNO37,LTRIM(RTRIM(i.TRANSREFNO))  FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD'  AND m.refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE status = 'Y' AND  SERVICEID ='OUTWRR' AND refnum = m.refnum) order by 1"

if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="refno"  then
			sqlstr= "SELECT REFNO37,LTRIM(RTRIM(i.TRANSREFNO)) FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD'  AND m.refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE status = 'Y' AND  SERVICEID ='OUTWRR' AND refnum = m.refnum) and REFNO37  like '" & Ucase(searchby(1)) & "%' order by 1"		
		else if searchby(0)="transrefno"  then
			sqlstr= "SELECT REFNO37,LTRIM(RTRIM(i.TRANSREFNO)) FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD'  AND m.refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE status = 'Y' AND  SERVICEID ='OUTWRR' AND refnum = m.refnum) and i.TRANSREFNO  like '" & Ucase(searchby(1)) & "%' order by 1"		
		end if		
end if			
rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,15)="IMPSReferenceNo" then


'sqlstr="SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' AND debitstatus = 'Y' AND NVL(creditstatus,'N') = 'N' ORDER BY TO_NUMBER(REFNO37)"

sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' AND debitstatus = 'Y' AND NVL(creditstatus,'N') = 'N'  AND REFNO37 NOT IN (SELECT REFNO37  FROM IMPSBRCHANFUNDSTRNSDTLS WHERE transtatus= 'A'  AND SERVICEID ='OUTWRR' AND debitstatus = 'N' AND NVL(creditstatus,'N') = 'Y') ORDER BY 1"



if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="name" then
			sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' AND debitstatus = 'Y' AND NVL(creditstatus,'N') = 'N' AND REFNO37 NOT IN (SELECT REFNO37  FROM IMPSBRCHANFUNDSTRNSDTLS WHERE transtatus= 'A'  AND SERVICEID ='OUTWRR' AND debitstatus = 'N' AND NVL(creditstatus,'N') = 'Y')  and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		else if searchby(0)="num" then
			sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' AND debitstatus = 'Y' AND NVL(creditstatus,'N') = 'N' AND REFNO37 NOT IN (SELECT REFNO37  FROM IMPSBRCHANFUNDSTRNSDTLS WHERE transtatus= 'A'  AND SERVICEID ='OUTWRR' AND debitstatus = 'N' AND NVL(creditstatus,'N') = 'Y')  and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		end if		
end if			
rs=objrep.SingleSelectStat(sqlStr)




elseif  left(strType,21)="BRCHANIMPSReferenceNo" then

'sqlstr="SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' AND debitstatus = 'Y' AND NVL(creditstatus,'N') = 'N' ORDER BY TO_NUMBER(REFNO37)"

sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'P' AND SERVICEID ='OUTWRD' and sentyn = 'N' ORDER BY 1"
if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="name" then
			sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'P' AND SERVICEID ='OUTWRD' and sentyn = 'N' and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		else if searchby(0)="num" then
			sqlstr =  "SELECT REFNO37,REFNO37 REFNO371 FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'P' AND SERVICEID ='OUTWRD' and sentyn = 'N' and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		end if		
end if			
rs=objrep.SingleSelectStat(sqlStr)

elseif  left(strType,18)="BRCHANIMPSRefTrack" then

sqlstr =  "SELECT REFNO37,TRANSREFNO  FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' and TRANSREFNO is not null ORDER BY 1"
if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="name" then
			sqlstr =  "SELECT REFNO37,TRANSREFNO  FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' STRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' and TRANSREFNO is not null and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		else if searchby(0)="num" then
			sqlstr =  "SELECT REFNO37,TRANSREFNO  FROM IMPSBRCHANFUNDSTRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' STRNSDTLS i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' and TRANSREFNO is not null and REFNO37  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		end if		
end if			
rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,14)="ATMReferenceNo" then
sqlstr =  "SELECT refnum,refnum FROM atmlogdtls a WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y' AND refnum NOT IN (SELECT refnum  FROM atmlogdtls WHERE status= a.status AND SERVICEID IN ('NDEBRV','FDEBRV','PSRREQ','ECRREQ','CHPRRQ') AND refnum = a.refnum) ORDER BY 1"

if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="name" then
sqlstr =  "SELECT refnum,refnum FROM atmlogdtls a WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y' AND refnum NOT IN (SELECT refnum  FROM atmlogdtls WHERE status= a.status AND SERVICEID IN ('NDEBRV','FDEBRV','PSRREQ','ECRREQ','CHPRRQ') AND refnum = a.refnum) and refnum  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		
		else if searchby(0)="num" then
sqlstr =  "SELECT refnum,refnum FROM atmlogdtls a WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y' AND refnum NOT IN (SELECT refnum  FROM atmlogdtls WHERE status= a.status AND SERVICEID IN ('NDEBRV','FDEBRV','PSRREQ','ECRREQ','CHPRRQ') AND refnum = a.refnum) and refnum  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
				
		end if
end if
rs=objrep.SingleSelectStat(sqlStr)
elseif left(strType,18)="IMPSMOBReferenceNo" then
sqlstr =  "SELECT refnum,refnum  FROM impslogdtls i WHERE  atmlocation = 'P2AO MOB' AND serviceid = 'OUTWRD' AND status = 'Y' AND  refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE SERVICEID ='OUTWRR' AND refnum = i.refnum) ORDER BY 1"

if not hidsearch="" then
		searchby=split(hidsearch,"|")
		if searchby(0)="name" then
sqlstr =  "SELECT refnum,refnum  FROM impslogdtls i WHERE  atmlocation = 'P2AO MOB' AND serviceid = 'OUTWRD'  AND status = 'Y' AND  refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE SERVICEID ='OUTWRR' AND refnum = i.refnum) and refnum  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
		
		else if searchby(0)="num" then
sqlstr =  "SELECT refnum,refnum  FROM impslogdtls i WHERE  atmlocation = 'P2AO MOB' AND serviceid = 'OUTWRD' AND status = 'Y' AND  refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE SERVICEID ='OUTWRR' AND refnum = i.refnum) and refnum  like '" & Ucase(searchby(1)) & "%' ORDER BY 1"
				
		end if
end if
rs=objrep.SingleSelectStat(sqlStr)
 

elseif left(strType,21)="sbcaccinvmiscplmodule" or left(strType,25)="NACHsbcaccinvmiscplmodule"  or left(strType,32)="NACHCBDTLICsbcaccinvmiscplmodule" then
  
sqlstr="SELECT MODULEID,NARRATION FROM GENMODULEMST WHERE MODULEID IN ('SB','CA','CC','INV','MISC','PL','DEP','LOAN') ORDER BY MODULEID"

 
 rs=objrep.SingleSelectStat(sqlStr)


elseif left(strType,15)="allsbcaccmodule" then
  
sqlstr="SELECT 'ALL' MODULEID ,'ALL' NARRATION FROM dual UNION SELECT MODULEID,NARRATION FROM GENMODULEMST WHERE MODULEID IN ('SB','CA','CC') ORDER BY MODULEID"

 
 rs=objrep.SingleSelectStat(sqlStr)
  
elseif left(strType,14)="SameCardNumber" then
   k=split(strType,"|")
sqlstr="SELECT cardnumber,firstname,account1 FROM atmcrddtls WHERE actioncode = 'U' AND status = 'R' AND cardnumber LIKE '%"& k(1) &"'"
 
 rs=objrep.SingleSelectStat(sqlStr)
 
 
 elseif left(strType,14)="TellerATMaccno" then
  k=split(strType,"|")
   
 sqlstr= "SELECT 'ALL' ACCNO,'ALL' NAME FROM DUAL UNION SELECT DISTINCT ACCNO,NAME   FROM " & k(2) &"tranday WHERE chqfvg = 'ATM' AND glcode ='"& k(3) &"' AND BRANCHCODE ='"& k(1) &"' AND CURRENCYCODE ='"& k(4) &"' UNION SELECT DISTINCT ACCNO,NAME   FROM " & k(2) &"tran WHERE chqfvg = 'ATM' AND glcode ='"& k(3) &"' AND BRANCHCODE ='"& k(1) &"' AND CURRENCYCODE ='"& k(4) &"' ORDER BY ACCNO DESC "

 rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,11)="H2HRepAccno" then
  k=split(strType,"|")
   
   	kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+Crcd + "|" + strmode +"|"+ strType
   
   if  k(6) = "OUTWARD" THEN
		
	sqlstr= "select distinct accno,name from neftrtgsdtls where neftrtgs = '"& k(5) &"' and refno is not null  and branchcode ='"& k(1) &"' and glcode ='"& k(3) &"'" 
'sqlstr= "SELECT DISTINCT ACCNO,NAME   FROM " & k(2) &"tranday WHERE RESPONDINGBANKCODE IN('NEFTOW','RTGSOW') AND chqfvg = '"& k(5) &"' AND glcode ='"& k(3) &"' AND BRANCHCODE ='"& k(1) &"' AND CURRENCYCODE ='"& k(4) &"' UNION SELECT DISTINCT ACCNO,NAME   FROM " & k(2) &"tran WHERE RESPONDINGBANKCODE IN('NEFTOW','RTGSOW') AND chqfvg = '"& k(5) &"' AND glcode ='"& k(3) &"' AND BRANCHCODE ='"& k(1) &"' AND CURRENCYCODE ='"& k(4) &"' ORDER BY ACCNO DESC "
	
	elseif k(6) = "INWARD" THEN
	
	if k(5) = "NEFT" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0'),BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTIW' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& k(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& k(3) &"'"
	
	else if  k(5) = "RTGS" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BC_RECACCNUM_F5561_1,10,7),'0') , BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSIW' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& k(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& k(3) &"'"
	end if
	
	elseif k(6) = "OUTWARDRETURN" THEN
	
	if k(5) = "NEFT" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0'),BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTOR' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& k(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& k(3) &"'"
	
	else if  k(5) = "RTGS" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BC_RECACCNUM_F5561_1,10,7),'0') , BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSOR' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& k(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& k(3) &"'"
	end if
	
	elseif k(6) = "INWARDRETURN" THEN
	
	if k(5) = "NEFT" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0'),BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTIR' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& k(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& k(3) &"'"
	
	else if  k(5) = "RTGS" then
	sqlstr= "SELECT distinct LTRIM(SUBSTR(BC_RECACCNUM_F5561_1,10,7),'0') , BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSIR' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& k(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& k(3) &"'"
	end if
	
   end if
   
 
 rs=objrep.SingleSelectStat(sqlStr)

elseif left(strType,9)="INVGlcode" then
	k=split(strType,"|")
	
 rs=obj.singlerecordset("GenGlsheetmst", _
						"distinct(glcode),narration","branchcode='" & k(1) & "'and moduleid='"& k(2) &"'" )
						
elseif left(strType,10)="RINVGlcode" then
	k=split(strType,"|")
	if k(1)="INS" then
 rs=obj.singlerecordset("GenGlsheetmst", _
						"distinct(glcode),narration","branchcode='" & k(2) & "' and moduleid='"& k(3) &"'" )
						else
rs=obj.singlerecordset("REMISSUEBANKMST a,GenGlsheetmst b", _
						"distinct a.invglcode,b.narration","a.branchcode='" & k(2) & "' and a.currencycode='" & k(3) & "' and a.remtype='" & k(4) & "' and a.OTHERBANKCODE='" & k(5) & "' AND a.OTHERBRANCHCODE='" & k(6) & "' and a.branchcode=b.branchcode  and a.invglcode=b.GLCODE" )
						end if						
						
elseif left(strType,8)="INVAccno" then
	k=split(strType,"|")
	
	if k(1)="INS" then
 rs=obj.singlerecordset("invmst", _
						"distinct(accno),name","branchcode='" & k(2) & "'and currencycode='" & k(3) & "' and glcode='" & k(4) & "' and status='R' and transtatus='A'")						
						else
						rs=obj.singlerecordset("REMISSUEBANKMST a,invmst b", _
						"distinct a.invaccno,b.name","a.branchcode='" & k(2) & "' and a.currencycode='" & k(3) & "' and a.remtype='" & k(4) & "' and a.OTHERBANKCODE='" & k(5) & "' AND a.OTHERBRANCHCODE='" & k(6) & "' and a.invglcode='" & k(7) & "' and a.branchcode=b.branchcode  and a.invglcode=b.GLCODE and a.invaccno=b.accno" )
						end if
						
						
elseif left(strType,10)="TYPEINVGET" then

rs=obj.singlerecordset("INVTYPEMST", _
						"INVTYPE, DESCRIPTION","status='R'" )
						
elseif left(strType,8)="NOINVGET" then
k=split(strType,"|")

rs=obj.singlerecordset("INVMST", _
						"ACCNO","branchcode='" & k(1) & "' and currencycode='" & k(2) & "' and glcode='" & k(3) & "' and status='R'" )

elseif left(strType,12)="VIEWNOINVGET" then
k=split(strType,"|")

rs=obj.singlerecordset("INVMST", _
						"ACCNO","branchcode='" & k(1) & "' and currencycode='" & k(2) & "' and glcode='" & k(3) & "'" )

elseif left(strType,8)="GETINVID" then
k=split(strType,"|")
	
 rs=obj.singlerecordset("invidinfomst", _
						"customerid,name","(globalyn='Y') or (globalyn='N' and branchcode='" & k(1) & "')" )

   
elseif left(strType,7)="QueryGL" then
	k=split(strType,"|")
    rs=obj.singlerecordset("genminmaxbalancepmt m,GenGlsheetmst g","distinct(m.glcode),g.narration","m.glcode=g.glcode and m.moduleid='" & k(1) &"' and m.currencycode='" & k(2) &"'and g.branchcode='" & k(3) &"'")
''''' for Genral parameters ------------------------------------------------------------------ 
''' for moduleid Querying while inserting new record      
elseif left(strType,8)="SBModule" then
    rs=obj.singlerecordset("GenModuletypesmst", _
					"moduleid,narration","upper(IMPLEMENTEDYN)='Y'")  
  ''''----------------------------------------------------------------------------------------------   
elseif left(strType,8)="StGlCode" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("GenGLSheetMst", _
					"glcode,narration","status='R' and branchcode='" & kstr(1) & "'")  
elseif left(strType,8)="GlCodeIC" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("GenGLSheetMst", _
					"glcode,narration","status='R' and branchcode='" & kstr(1) & "' and moduleid='" & kstr(2) & "' order by glcode") 		
					
elseif left(strType,11)="StModGlCode" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("GenGLSheetMst", _
					"glcode,narration","status='R' and branchcode='" & kstr(1) & "' and moduleid='" & kstr(2) & "' AND glcode IN(SELECT glcode FROM GENGLMASTMST WHERE glcategory='A')")  
					
elseif left(strType,8)="StAccNos" then 
	kstr=split(strtype,"|")
    rs=obj.singlerecordset( trim(kstr(3)) & "Mst", _
					"ACCNO, NAME","branchcode='" & kstr(1) & "' and CURRENCYCODE='" & _
					kstr(2) & "' and GLCODE='" & kstr(4) & "'" )  
					
elseif left(strType,12)="StWithGlCode" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("GENGLMASTMST", _
					"glcode,glDescription","status='R' and glcategory='A' and branchcode='" & kstr(1) & "'")  					
elseif left(strType,8)="StUserId" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("gentranslogbkp a,genusermst b", _
					"distinct a.userid,b.name","a.branchcode='" & kstr(1) & "' and a.Transtatus='A' and a.userid=b.userid and a.applicationdate='" & kstr(2) & "'")  					
elseif left(strType,11)="StAppUserId" then
	kstr=split(strtype,"|")
    rs=obj.singlerecordset("gentranslogbkp a,genusermst b", _
					"distinct a.approvedby,b.name","a.branchcode='" & kstr(1) & "' and a.Transtatus='A' and a.approvedby=b.userid and a.applicationdate='" & kstr(2) & "'")  					
elseif left(strType,8)="GLCharge" then
	k=split(strType,"|")
    rs=obj.singlerecordset("genchargespmt m,GenGlsheetmst g", _
    "distinct(m.glcode),g.narration", _
    "m.glcode=g.glcode and " & _
    "m.moduleid='" & k(1) &"' and " & _
    "m.currencycode='" & k(2) &"' and m.branchcode='" & k(3) & "'")    
    
'''''For GLParam.aspx in SbModule
elseif left(strType,7)="GLParam" then
	k=split(strType,"|")
    rs=obj.singlerecordset("GENGLCODESPMT m,GenGlsheetmst g", _
    "distinct(m.glcode),g.narration", _
    "m.glcode=g.glcode and m.moduleid='" & k(1) & "' and " & _
    "m.branchcode='" & k(2) &"'")
    
    
''' for CustCat.aspx(CustomerCategory) in Sbmodule
elseif left(strType,12)="CustCategory" then
	rs=obj.singlerecordset("GENMODULECATPMTMST","code,categoryname","")
	
'''for Sbtypeparameters.aspx form in Sbbodule
elseif left(strType,7)="SBParam" then
	k=split(strType,"|")
	rs=obj.singlerecordset("SBTYPEPMT m,GenGlsheetmst g","distinct(m.glcode),g.narration","m.glcode=g.glcode and m.moduleid='" & k(1) &"' and m.currencycode='" & k(2) &"' and m.branchcode='" & k(3) &"'")   	     
elseif left(strType,9)="BookAccNo" then
	k=split(strType,"|")
	if k(5)="ADD" then
	rs=obj.singlerecordset("sbmst","distinct(accno),name","branchcode='" & k(1) &"'" & _
								" and currencycode='" & k(2) &"' and glcode='" & k(4) &"' and CHEQUEBOOK='Y'")
	elseif k(5)="MODIFY" then
	
	rs=obj.singlerecordset("genstoppaymst a,sbmst b","distinct(a.accno),b.name","a.branchcode='" & k(1) &"'" & _
								" and a.currencycode='" & k(2) &"' and a.glcode='" & k(4) &"' and a.accno=b.accno")
	end if							
''' for Stop payments Querying and to listout the stoppayno,accno,name	
							
								
elseif left(strType,9)="QueryStop" then
	k=split(strType,"|")
		
	'rs=obj.singlerecordset("GENSTOPPAYMST g,sbmst s","distinct(g.accno),g.stopno,s.name","g.branchcode='" & k(1) &"'" & _
	'							" and g.currencycode='" & k(2) &"' and g.glcode='" & k(4) &"'" & _
	'							" and g.moduleid='" & k(3) &"' and g.accno='" & k(5) &"'" & _
	'							" and s.accno='" & k(5) &"'")								
 rs=obj.singlerecordset("GENSTOPPAYMST g,sbmst s","distinct(g.accno),g.stopno,s.name","g.branchcode='" & k(1) &"'" & _
								" and g.currencycode='" & k(2) &"' and g.glcode='" & k(4) &"'" & _
								" and g.moduleid='" & k(3) &"' " & _
								" and g.accno=s.accno")
 
 elseif left(strType,8)="StModule" then
 objMod=server.CreateObject("GeneralTranQueries.TransactionQueries")
	k=split(strType,"|")
	'rs=objMod.ModuleID(cstr(k(1)),"N")
	
	StrQuery = "trim(BranchCode)='" & Trim(k(1)) & "' and " & _
		" upper(IMPLEMENTEDYN)='Y' and ( upper(ModuleID) = 'CASH' OR " & _
        " upper(ModuleID) = 'REM' OR ModuleID in (select gmm.moduleid " & _
        " from genmodulemst gmm where trim(gmm.mastertable)is not null " & _
        " )) order by ModuleID"
	'and gmm.VOUCHINGYN='Y'
	rs=obj.singlerecordset("GenModuleTypesMST","ModuleID,Narration", _
		StrQuery)
    
elseif left(strType,9)="QryModule" then
strFlds=split(strType,"|")
    rs=obj.singlerecordset("genstoppaymst a,GenModuletypesmst b", _
					"distinct(a.moduleid),b.narration","a.moduleid=b.moduleid and " & _
					"a.branchcode='" & strFlds(1) &"' and " & _
					"a.currencycode='" & strFlds(2) & "'")
'''for querying moduleid in minmaxbalpmt form
elseif left(strType,11)="QueryModule" then
strFlds=split(strType,"*")
    rs=obj.singlerecordset("GENMINMAXBALANCEPMT a,GenModuletypesmst b ", _
					"distinct(a.moduleid),b.narration","a.moduleid=b.moduleid and " & _
					"a.branchcode='" & strFlds(1) &"' and " & _
					"a.currencycode='" & strFlds(2) & "'")	
	
elseif left(strType,11)="QueryChrgGl" then
strFlds=split(strType,"|")
    rs=obj.singlerecordset("GENchargesPMT a,GenModuletypesmst b ", _
					"distinct(a.moduleid),b.narration","a.moduleid=b.moduleid and " & _
					"a.branchcode='" & strFlds(1) &"' and " & _
					"a.currencycode='" & strFlds(2) & "'")
'''fetching moduleid,description in glparam.aspx form while querying
elseif left(strType,13)="QuerySBModule" then
strFlds=split(strType,"|")
    rs=obj.singlerecordset("GENGLCODESPMT a,GenModuletypesmst b ", _
					"distinct(a.moduleid),b.narration","a.moduleid=b.moduleid and " & _
					"a.branchcode='" & strFlds(1) &"'")
									   
elseif left(strType,5)="QryGl" then
	strFlds=split(strType,"|")
 rs=obj.singlerecordset("genstoppaymst a,GenGlsheetmst b", _
			"distinct(a.glcode),b.narration", _
			"a.glcode=b.glcode and a.branchcode='" & strFlds(1) &"' and " & _
			"a.currencycode='" & strFlds(2) &"' and " & _
			"a.moduleid='" & strFlds(3) &"'" )    
'''---------------------------------------------------------------------------------------    
elseif left(strType,5)="Accno" then
    
    k=split(strType,"|")
    rs=obj.singlerecordset("sbmst","accno,name,custid","glcode = '"& k(1) &"'","name")
    
elseif left(strType,7)="ICAccno" then

    k=split(strType,"|")
   dim str="branchcode='" & k(1) & "' and currencycode='" & k(2) & "' and glcode = '" & k(3) & "' order by to_number(accno)"
    rs=obj.singlerecordset(modi & "mst","accno,name",str)
    
elseif left(strType,6)="CustID" then
    stname=left(strType,4)
    atype=mid(strType,7)
    rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","")
	
elseif left(strType,7)="TransNo" then
    stname=left(strType,5)
    atype=mid(strType,8)
    rs=obj.singlerecordset("translog","tranno,amount","glcode='"& atype &"'","tranno")
elseif left(strType,13)="TellerIssBank" then
		
	k=split(strType,"|")
	strTab="GENBANKACCMST a, GENOTHERBANKMST b "
	strCond="a.BRANCHCODE='" & trim(ucase(k(2))) & _ 
	"' and a.CURRENCYCODE='" & trim(ucase(k(3))) & _ 
	"' and a.REMITANCEYN='Y' and a.STATUS='R'" & _ 
	" and a.BRANCHCODE=b.BRANCHCODE and a.OTHERBANKCODE = b.BANKCODE AND " & _
	"A.STATUS=B.STATUS"
	
	strflds="distinct a.OTHERBANKCODE,b.BANKNAME"
	if k(1)="del" then
	strTab="REMISSUEBANKMST a, GENOTHERBANKMST b "
	strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(4))) & "' and remtype='" & trim(ucase(k(2))) & _
	"' and a.STATUS='R'and a.BRANCHCODE=b.BRANCHCODE" & _ 
	" and a.OTHERBANKCODE = b.BANKCODE AND A.STATUS=B.STATUS"
	    
	    if k(2)="ADD" then
	    strTab="REMISSUEBANKMST a, Remtypemst b"
	    strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(4))) & "' and a.remtype='" & trim(ucase(k(2))) & _
	"' and a.STATUS='R' " & _ 
	" and a.OTHERBANKCODE = b.ISSUEDONBANKCODE AND A.STATUS=B.STATUS"
	   strflds="distinct issuedonbankcode,issuedonbankdesc"
	    end if
	    
	end if
		
	rs=obj.singlerecordset(strTab,strflds,strCond)
	 
elseif left(strType,15)="TellerIssBranch" then

	k=split(strType,"|")
	strTab="GENBANKACCMST a, GENOTHERBRANCHMST b"
	strflds=" distinct a.OTHERBRANCHCODE,b.BRANCHNAME"
	strCond="a.BRANCHCODE='" & trim(ucase(k(2))) & "' and " & _
	 "a.CURRENCYCODE='" & trim(ucase(k(3))) & _
	 "' and a.REMITANCEYN='Y' and a.STATUS='R' and " & _
	 "a.OTHERBANKCODE = b.BANKCODE AND A.OTHERBANKCODE='" & trim(ucase(k(4))) & _ 
	 "' AND A.OTHERBRANCHCODE=B.BRANCHCODE AND A.STATUS=B.STATUS"
	 
	if k(1)="del" then
	strTab="REMISSUEBANKMST a, GENOTHERBRANCHMST b"
	strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(4))) & "' and remtype='" & trim(ucase(k(2))) & _
	"' and a.STATUS='R' and a.OTHERBANKCODE = b.BANKCODE AND A.OTHERBANKCODE='" & _
	trim(ucase(k(5))) & "' AND A.OTHERBRANCHCODE=B.BRANCHCODE AND A.STATUS=B.STATUS"
	
	 if k(2)="ADD" then
	    strTab="REMISSUEBANKMST a, GENCORRESPBANKBRANCHESMST b"
	    strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(4))) & "' and remtype='" & trim(ucase(k(2))) & _
	"' and a.STATUS='R' and a.OTHERBANKCODE = b.BANKCODE AND A.OTHERBANKCODE='" & _
	trim(ucase(k(5))) & "' AND A.OTHERBRANCHCODE=B.BRANCHCODE AND A.STATUS=B.STATUS"
	
	   strflds="distinct a.otherbranchcode,b.branchname"
	    end if
	    
	end if
	
	 
	rs=obj.singlerecordset(strTab,strflds,strCond)

elseif left(strType,16)="ADDTellerIssBank" then
    k=split(strType,"|")
    
    if k(1)="ins" then
    rs=obj.singlerecordset("remtypemst","distinct issuedonbankcode,issuedonbankdesc","status='R' and remtype='" & k(2) & "'")
    end if
    
elseif left(strType,18)="ADDTellerIssBranch" then
  k=split(strType,"|")
  if k(1)="ins" then
  rs=obj.singlerecordset("GENCORRESPBANKBRANCHESMST","distinct branchcode,branchname","status='R' and bankcode='" & k(2) & "' and branchcode not in (select otherbranchcode from REMISSUEBANKMST where otherbankcode='" & k(2) & "')")
  end if
    
elseif left(strType,14)="TellerBnkAccno" then
  'dim str 
   k=split(strType,"|")
   strTab="GENBANKACCMST a, MISCMST b"
   strCond= "a.BRANCHCODE='" & trim(ucase(k(2))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(3))) & "' AND A.OTHERBANKCODE='" & trim(ucase(k(4))) & _
	"' AND A.OTHERBRANCHCODE='" & trim(ucase(k(5))) & "' AND A.MISCGLCODE='" & _
	trim(ucase(k(6))) & "' and a.REMITANCEYN='Y' and a.STATUS='R'" & _ 
	" and a.BRANCHCODE=b.BRANCHCODE AND A.CURRENCYCODE=B.CURRENCYCODE " & _ 
	"AND A.MISCGLCODE=B.GLCODE AND A.MISCACCNO=B.ACCNO AND A.STATUS=B.STATUS " & _
	"AND A.MISCACCNO NOT IN (SELECT DISTINCT MISCACCNO FROM REMISSUEBANKMST WHERE" & _
	" MISCGLCODE='" & trim(ucase(k(6))) & "')"	 
	
	 
	if k(1)="del" then
	strTab="REMISSUEBANKMST a, MISCMST b"
	strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and a.CURRENCYCODE='" & _
	trim(ucase(k(4))) & "' AND A.OTHERBANKCODE='" & trim(ucase(k(5))) & _
	"' AND A.OTHERBRANCHCODE='" & trim(ucase(k(6))) & "' AND " & _ 
	"A.MISCGLCODE='" & trim(ucase(k(7))) & "' and remtype='" & trim(ucase(k(2))) & _
	"' and a.STATUS='R' and a.BRANCHCODE=b.BRANCHCODE AND " & _
	"A.CURRENCYCODE=B.CURRENCYCODE AND A.MISCGLCODE=B.GLCODE AND " & _
	"A.MISCACCNO=B.ACCNO AND A.STATUS=B.STATUS" 
	end if
	 
	
	 rs=obj.singlerecordset(strTab, "b.ACCNO,b.NAME",strCond)
	 
	 	 
elseif left(strType,18)="TellerBnkAccGlCode" then

	k=split(strType,"|")
	strTab="GENBANKACCMST a, GENGLSHEETMST b "
	strCond= "a.BRANCHCODE='" & trim(ucase(k(2))) & "' and " & _
	 "b.MODULEID='" & trim(ucase(k(4))) & "' and a.CURRENCYCODE='" & _
	 trim(ucase(k(3))) & "' AND A.OTHERBANKCODE='" & trim(ucase(k(5))) & _
	 "' and a.OTHERBRANCHCODE='" & trim(ucase(k(6))) & _
	 "' and a.REMITANCEYN='Y' and a.STATUS='R' and " & _
	 "a.BRANCHCODE=b.BRANCHCODE AND A.MISCGLCODE=B.GLCODE AND A.STATUS=B.STATUS"
	 
	 if k(1)="del" then
	strTab="REMISSUEBANKMST a, GENGLSHEETMST b "
	strCond="a.BRANCHCODE='" & trim(ucase(k(3))) & "' and " & _
	 "b.MODULEID='" & trim(ucase(k(5))) & "' and a.CURRENCYCODE='" & _
	 trim(ucase(k(4))) & "' AND A.OTHERBANKCODE='" & trim(ucase(k(6))) & _
	 "' and a.OTHERBRANCHCODE='" & trim(ucase(k(7))) & _
	 "' and remtype='" & trim(ucase(k(2))) & "' and a.STATUS='R' and " & _
	 "a.BRANCHCODE=b.BRANCHCODE AND A.MISCGLCODE=B.GLCODE AND A.STATUS=B.STATUS"
	end if
	 
	 rs=obj.singlerecordset(strTab,"a.MISCGLCODE,b.NARRATION",strCond) 
	 	 
'--------------------------------------------    
elseif strType="Tellerbranch" then

	obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	
	rs=obj.BranchCodes(cstr(session("userid")))
	
elseif left(strType,12)="Tellermodule" then
    
	obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	
	k=split(strType,"|")
	
	rs=obj.ModuleID(cstr(k(1)),"N","N")
	
elseif left(strType,11)="Telleraccno" then

	k=split(strType,"|")
	obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	rs=obj.AccountNumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)))
	if obj.connerror<>"" then
		kstr="Norecords"
		Errstr=obj.ConnError
	end if	
	
elseif left(strType,16)="IMPSAccWiseAccno" then
	k=split(strType,"|")
	
	strtnxtype = ""
	strcond = ""
	if k(5) = "ALL" then
	strtnxtype = " "
	elseif  k(5) = "INWARD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'INWARD' "
	elseif  k(5) = "OUTWRD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'OUTWRD' "
	end if
	

	if k(6) <> "Between" then
	strcond = " and EFFECTIVEDATE " & k(6) & " '" &  k(7) &"' "
	else
	strcond = " and EFFECTIVEDATE between '" &  k(7) &"' and '" &  k(8) &"' "
	end if
''(select name from "& k(3) &"mst where branchcode = '"& k(1) &"' AND currencycode = '"& k(2) &"' And glcode = '"& k(4) &"' and accno = x.accno and rownum = 1)
 sqlstr="select x.accno, x.name from (SELECT DISTINCT  accno, name  FROM GENTRANSLOG WHERE CHQFVG = 'IMPS' AND branchcode = '"& k(1) &"' AND currencycode = '"& k(2) &"' and MODULEID = '"& k(3) &"' And glcode = '"& k(4) &"'"   & strtnxtype & " "  &  strcond  & _  
 " UNION " & _
 " SELECT DISTINCT  accno ,name   FROM GENTRANSLOGBKP WHERE CHQFVG = 'IMPS' AND branchcode = '"& k(1) &"' AND currencycode = '"& k(2) &"' and MODULEID = '"& k(3) &"' And glcode = '"& k(4) &"'"  & strtnxtype & " "  &  strcond &") x"
 
 rs=objrep.SingleSelectStat(sqlstr)	
	
elseif left(strType,10)="PigmyAccno" then

    k=split(strType,"|")
   dim str="branchcode='" & k(1) & "' and currencycode='" & k(2) & "' and glcode = '" & k(3) & "' and upper(agentcode) = upper('" & k(4) & "') and status='R' and " & _
   "nvl(curbal,0) >0 and TRANSTATUS='A' order by accno"
   
    rs=obj.singlerecordset("PIGMYACCOUNTSMST","accno,name",str)

elseif left(strType,10)="PigmyAgent" then

    k=split(strType,"|")
   dim str="branchcode='" & k(1) & "' and glcode = '" & k(2) & "' and status='R' order by agentcode"
    rs=obj.singlerecordset("PIGMYAGENTMST","agentcode,agentname",str)
    
elseif left(strType,6)="CashID" then

    k=split(strType,"|")
   dim str="branchcode='" & k(1) & "' and status='R' order by ACCNO"
    rs=obj.singlerecordset("ATMMST","ACCNO, NAME",str)

end if
%>
	</HEAD>
	<body onload="displaydiv()"> 
		<form name="frmList">
		   <div id="divsearch" style="DISPLAY:none">
		   <select id="cmb_search" name="cmbsearch" onchange="cleartext()">
		<% if left(strType,21)="IMPSBRCHANReferenceNo" then %>
					
						<option value="refno" selected>refno</option>
						<option value="transrefno">transrefno</option>
					
			<%else%>
				
						<option value="name" selected>Name</option>
						<option value="num">Number</option>
					
			<%end if %>		
			</select>
					<input name="txtsearch" size="25" class="txtxautofill" style="TEXT-TRANSFORM: uppercase;TEXT-ALIGN: left">
					<input type="button" class="button" name="btnsearch" onclick="funcsearch()" value="Search">
					<input type="hidden" name="hidsearch">
	</div>

			<div align="center">
				<center>&nbsp;
					<table class="tablebordermain">
						<tr class="bgcolor">
							<% if not rs.EOF then %>
							<%	if len(strType)>8 then	%>
							<th align="left">
								<font class="textbold">
									<%'=UCASE(stname)%>
									&nbsp;DESCRIPTION - CODE</font></th>
							<%	else	%>
							<th align="left">
								<font class="textbold">
									<%'=UCASE(strType)%>
									&nbsp;DESCRIPTION - CODE</font></th>
							<%end if

	    %>
						<tr>
							<td align="left"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
									<%  
	
	do until rs.EOF
	if rs.Fields.Count = 1 then%>
									<option><%=rs(0).value%></option>
									<%elseif rs.Fields.Count = 2 then%>
									<option><%=rs(1).value%>
										-----<%=rs(0).value%></option>
									<%elseif rs.Fields.Count=3 then%>
									<option><%=rs(1).value%>
										-----<%=rs(0).value%>
										-----<%=rs(2).value%></option>
									<%end if%>
									<%rs.MoveNext
	
  loop
  Response.Write ("<script language=vbscript>")
	  Response.Write ("window.document.frmList.cmbList.item(0).selected=true" & chr(13))
      Response.Write ("</script>")  
          %>
								</select></td>
						</tr>
					</table>
				</center>
			</div>
			<%
else
if strType ="StopBranch" then
  %>
			<div align="center">
				<center>
					<table class="tablebordermain">
						<tr class="bgcolor">
							<th>
								<font class="textbold">
									<%'=UCASE(stname)%>
									&nbsp;DESCRIPTION | CODE</font></th>
						<tr class="bgcolor">
							<td><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
									<option><%=session("branchcode")%>
										-----<%=session("branchnarration")%></option>
								</select></td>
						</tr>
					</table>
				</center>
			</div>
			<%
else
  %>
			<font class="textwhite">No Records </font>
			<%
end if
 end if 
 
  %>
			<div align="center">
				<center>
					<table border="0" cellpadding="0" cellspacing="0" width="10%" class="tablebordermain">
						<tr>
							<td width="100%"><input type="button" value="   OK   " name="butmd" onclick="List()" class="button"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="button"></td>
						</tr>
					</table>
				</center>
			</div>
		</form>
	</body>
</HTML>
