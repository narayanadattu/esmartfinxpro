<%@ Page Language="vb" explicit="false" aspcompat="true" AutoEventWireup="false" Codebehind="ATMModule.aspx.vb" Inherits="eSmartDotNet.ATMModule"%>
<%
		
	dim usrid
	dim objfetch
	dim recdtls
	dim vmod
	dim recmod
	vmod=Request.Form("hmod")
	vmodx=split(Request.QueryString("record"),"~")
	if ubound(vmodx)>0 then
		vmod=vmodx(0)
		session("moddir")=vmodx(1)
	end if
	usrid=session("userid")
	
	objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
	recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir",  _
			"upper(trim(machinename))='" & ucase(session("serverid")) & "'")
		mainstr=trim(recdtls(0).value) & "/" & trim(recdtls(1).value) & "/" & "~" & mainstr
		session("moduledir")=trim(recdtls(0).value) & "/" & trim(recdtls(1).value) 
	
	Response.Redirect  ("http://" & trim(recdtls(0).value) & "/" & _
					trim(recdtls(1).value) & "/commonmodule.aspx")
	

%>