<%@ Page aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Codebehind="frmRefnoReport.aspx.vb" Inherits="eSmartDotNet.frmRefnoReport"%>
<%
dim strrefno,objfetch,rs
dim strSql 
dim strRemarks 

objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 
rs=server.CreateObject("adodb.recordset")
rsrev=server.CreateObject("adodb.recordset")


strrefno=Request.QueryString("st")

strSql = "SELECT REFNO37, REMACCNO1022, REMNAME1252,TRNSAMOUNT4,  BENACCNO1032, BENNAME,BENIFSCCODE1272,nvl(debitstatus,'N') debitstatus, nvl(CREDITSTATUS,'N') CREDITSTATUS,to_char(APPLICATIONDATE,'dd-Mon-yyyy')  FROM IMPSBRCHANFUNDSTRNSDTLS WHERE SERVICEID ='OUTWRD' AND refno37 = '"& strrefno &"'"

rs=objfetch.SingleSelectStat(strSql)

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>Branch Channel IMPS Transaction Receipt</title>
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <SCRIPT LANGUAGE=javascript>

function prnt()
{
// hide all the buttons from the printing of report
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butSelectAll.style.visibility="hidden"
window.document.frmList.butCopy.style.visibility="hidden"
window.document.frmList.butSelectAll.style.visibility="hidden"
window.document.frmList.butCopy.style.visibility="hidden"
window.document.frmList.butSelectAll.style.visibility="hidden"
window.document.frmList.butCopy.style.visibility="hidden"

// Print the report 
window.print()
window.document.frmList.butok.style.visibility="visible"
window.document.frmList.butprnt.style.visibility="visible"
window.document.frmList.butSelectAll.style.visibility="visible"
window.document.frmList.butCopy.style.visibility="visible"
}

    </SCRIPT>
  </head>
  <body >

<form id="frmList">
<table border=1 width="80%" align="left">
<tr>
<td align="center"><h3>Branch Channel IMPS Transaction Receipt</h3></td>
</tr>
<tr> 
<td>
<%if not rs.eof and not rs.bof then %>
<table border=0 width="100%" align=center>

<tr><td align ="right" width = "30%"> Ref No : </td><td width="2%">&nbsp;</td></td> <td align ="left"  width = "70%"> <%=rs(0).value %> </td></tr>
<tr><td align ="right" width = "30%"> Acc No : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=rs(1).value %> </td></tr>
<tr><td align ="right" width = "30%"> Name : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=rs(2).value %> </td></tr>
<tr><td align ="right" width = "30%"> Amount : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=cdbl(rs(3).value) %> </td></tr>
<tr><td align ="right" width = "30%"> Benf Accno : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=rs(4).value %> </td></tr>
<tr><td align ="right" width = "30%"> Benf Name : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=ucase(rs(5).value) %> </td></tr>
<tr><td align ="right" width = "30%"> Benf IFSC : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=ucase(rs(6).value) %> </td></tr>
<tr><td align ="right" width = "30%"> Tnx Date : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=rs(9).value %> </td></tr>
<% 
if rs(7).value = "Y" then
if rs(8).value = "Y" then
strRemarks= " Debit and Credit Transaction Successful"
else if rs(8).value = "N" then
strRemarks= " Debit Transaction Successful Credit Transaction Not Successful"

strSql = "SELECT nvl(CREDITSTATUS,'N') CREDITSTATUS FROM IMPSBRCHANFUNDSTRNSDTLS WHERE SERVICEID ='OUTWRR' AND refno37 = '"& strrefno &"'"

rsrev=objfetch.SingleSelectStat(strSql)

	if not rsrev.eof and not rsrev.bof then

		if rsrev(0).value = "Y" then
		strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Successfull"
		else
		strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Not Successfull"
		end if
	else
		strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Not Successfull"
	end if

end if
else if rs(7).value = "N" 
strRemarks= " Debit Transaction Not Successful"
end if
 %>
<tr><td align ="right" width = "30%"> Status : </td><td width="2%">&nbsp;</td> <td align ="left"  width = "70%"> <%=strRemarks %> </td></tr>
</table>


<% end if%>
</td>
</tr>
<tr>
<td>
<table  border=0 width="100%" align=center>
<tr>
<td align ="center">
 <input type="button" value="  Print   " name="butprnt" onclick="prnt()" class="button"><input type="button" value="   Exit   " name="butok" onclick="window.close()" class="button"></td>
 
</tr>
</table>
</td>
</tr>
 </table>
 </form>
 </body>
</html>
