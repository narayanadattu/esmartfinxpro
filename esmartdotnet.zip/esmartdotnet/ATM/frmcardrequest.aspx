<%@ Page aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Codebehind="frmcardrequest.aspx.vb" Inherits="eSmartDotNet.frmcardrequest1"%>
<%
	dim strmessage

	strmessage=Request.QueryString("record")
	
	dim obj, rs, obj1, rs1, obj2, rs2
	
	dim impYn,brcod,Refnm,lef,multi,Sln

	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN","CODE='CARDISS'")
	
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
	end if
	
	obj1 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs1 = obj1.SingleRecordSet("ATMCRDREQUESTDTLS","NVL(MAX(REFNUM),0) refno","")
	
	if not rs1.EOF and not rs1.BOF then
		Refnm = rs1(0).value
	end if


%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>Card Request</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	
	function Display()
	{
		var IMP="<%=impYn%>"
		
		if(IMP=="Y")
		{
			
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
		
		var stRef,Ref,stSnl
		
		stRef = "<%=Refnm%>"
		
		
		Ref = parseInt(stRef)+1
		
		window.document.frmCardRequst.hidRef.value = Ref
	}
	
	function DispTranMsg()
	{
		if('<%=strmessage%>'!="")
		{
			var mess="<%=strmessage%>"
			alert(mess)
			location.replace("../ATM/frmcardrequest.aspx")
		}
	}
	
	
	function Branch()
	{
		var branch="Branch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user

		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}

	function Branchid(kstr)
	{	
		assign(kstr,window.document.frmCardRequst.txtBrdesc,window.document.frmCardRequst.txtbranchcode)
	}
	
	function Tellmodule()
	{	clear()
		if(window.document.frmCardRequst.txtbranchcode.value=="")
		{
			alert("Please Select Branch Code.")
			return
		}
		stmod="ModuleTell"; 
		stbr=window.document.frmCardRequst.txtbranchcode.value.toUpperCase();
		kstr=stmod+"|"+stbr
		
		window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function modulecode(kstr)
	{
		var strMod=kstr.split("-----")
		window.document.frmCardRequst.txtModid.value=strMod[1]
		window.document.frmCardRequst.txtModiddesc.value=strMod[0]
		window.document.frmCardRequst.txtGlcodedesc.value=""
		window.document.frmCardRequst.txtGlcode.value=""
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtAccNo.value=""
	}
	
	function TellerGl()
	{
		clear()
		if(window.document.frmCardRequst.txtModid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmCardRequst.txtbranchcode.value.toUpperCase();
		modid=window.document.frmCardRequst.txtModid.value.toUpperCase();
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmCardRequst.txtGlcodedesc,window.document.frmCardRequst.txtGlcode)
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtAccNo.value=""
	}
	
	function Acccode()
	{	
		clear()
		if(window.document.frmCardRequst.txtGlcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		stacc="Telleraccno"
		brchCd=window.document.frmCardRequst.txtbranchcode.value;
		ModId=window.document.frmCardRequst.txtModid.value.toUpperCase();
		GlCd=window.document.frmCardRequst.txtGlcode.value.toUpperCase();
		
		kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+window.document.frmCardRequst.txtcurrencycode.value.toUpperCase()+"|"+"='R'"
		
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		
		window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	}

	function accountid(kstr)
	{
		assign(kstr,window.document.frmCardRequst.txtAccNm,window.document.frmCardRequst.txtAccNo)
		
		window.document.frmCardRequst.txtFirstnam.value = window.document.frmCardRequst.txtAccNm.value.substring(0, 25);
		getData()
	}
	
	function getData()
	{
		var st="GETCARDDAT"+"|"+window.document.frmCardRequst.txtbranchcode.value+"|"+window.document.frmCardRequst.txtModid.value.toUpperCase()+"|"+window.document.frmCardRequst.txtGlcode.value.toUpperCase()+"|"+window.document.frmCardRequst.txtAccNo.value+"|"+"ATMCRDREQUESTDTLS"
		
		window.document.all['iGetDtls'].src="../GEN/getDtls.aspx?st="+st
	}
	
	function getCard(str)
	{
		//alert(" str =  "+str)
		
		if(str == "No Data")
		{
			alert("For These Account Card Request Is Already Generated")
			return;
		}
		
		window.document.frmCardRequst.hidAdd.value = ""
		
		var kStr=str.split("~")
		window.document.frmCardRequst.txtMobphon.value = kStr[1]
		window.document.frmCardRequst.txtAdd1.value = kStr[3].substring(0, 25);
		window.document.frmCardRequst.txtAdd2.value = kStr[3].substring(25, 50);
		window.document.frmCardRequst.txtAdd3.value = kStr[3].substring(50, 75);
		window.document.frmCardRequst.txtCitycode.value = kStr[4]
		window.document.frmCardRequst.txtZipcod.value = kStr[5]
		
	}
	
	function DescrptionDisp(strTxt)
	{
		sBr = window.document.frmCardRequst.txtbranchcode.value.toUpperCase()
		sMod = window.document.frmCardRequst.txtModid.value.toUpperCase()
		sGL = window.document.frmCardRequst.txtGlcode.value.toUpperCase()
		sAccno = window.document.frmCardRequst.txtAccNo.value.toUpperCase()
		sCur = window.document.frmCardRequst.txtcurrencycode.value.toUpperCase()
		 clear()
		if(strTxt=="txtModid")
		{ 
			if(window.document.frmCardRequst.txtModid.value=="")
			{
				return;
			}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"'~~"+strTxt
				
			window.document.frmCardRequst.txtModiddesc.value = ""
			window.document.frmCardRequst.txtGlcode.value = ""
			window.document.frmCardRequst.txtGlcodedesc.value = ""
			window.document.frmCardRequst.txtAccNo.value = ""
			window.document.frmCardRequst.txtAccNm.value = ""
		}
		
		if(strTxt=="txtGlcode")
		{ 
			if(window.document.frmCardRequst.txtGlcode.value=="")
			{
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
				
			window.document.frmCardRequst.txtGlcodedesc.value = ""
			window.document.frmCardRequst.txtAccNo.value = ""
			window.document.frmCardRequst.txtAccNm.value = ""	
		}
		
		if(strTxt=="txtAccNo")
		{
			if(window.document.frmCardRequst.txtAccNo.value=="")
			{
				return;
			}
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
			window.document.frmCardRequst.txtAccNm.value = ""
		}
		
		//alert("st2 = "+st)
		window.document.all["iBatch"].src="../GENSBCA/querydisplay.aspx?st="+st
	}
	
	function DescDisplay(stri)
	{
		//alert("stri = "+stri)
		var strtype=new String()
		strtype=stri.split("~")
		
		var StrArrFld=new String()
		StrArrFld=strtype[0].split("|")
			
		if(strtype[1]=="txtModid")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid ModuleId")
				window.document.frmCardRequst.txtModid.value=""
				window.document.frmCardRequst.txtModiddesc.value=""
				window.document.frmCardRequst.txtModid.focus()
				return;
			}
			window.document.frmCardRequst.txtModiddesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtGlcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Glcode")
				window.document.frmCardRequst.txtGlcode.value=""
				window.document.frmCardRequst.txtGlcodedesc.value=""
				window.document.frmCardRequst.txtGlcode.focus()
				return;
			}
			window.document.frmCardRequst.txtGlcodedesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtAccNo")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Account No.")
				window.document.frmCardRequst.txtAccNo.value=""
				window.document.frmCardRequst.txtAccNm.value=""
				window.document.frmCardRequst.txtAccNo.focus()
				return;
			}
			window.document.frmCardRequst.txtAccNm.value=StrArrFld[0]
			window.document.frmCardRequst.txtFirstnam.value = window.document.frmCardRequst.txtAccNm.value.substring(0, 25);
			getData()
		}
		
	}
	
	function clear()
	{
		window.document.frmCardRequst.txtFirstnam.value=""
		window.document.frmCardRequst.txtMothnam.value=""
		window.document.frmCardRequst.txtCrdlmt.value=""
		window.document.frmCardRequst.txtMobphon.value=""
		window.document.frmCardRequst.txtAdd1.value=""
		window.document.frmCardRequst.txtAdd2.value=""
		window.document.frmCardRequst.txtAdd3.value=""
		window.document.frmCardRequst.txtCitycode.value=""
		window.document.frmCardRequst.txtZipcod.value=""
		window.document.frmCardRequst.txtState.value=""
		
	}
	
	function Ok()
	{
		var St
		
		if(window.document.frmCardRequst.txtModid.value=="")
		{
			alert("Please Enter Module Id")
			window.document.frmCardRequst.txtModid.focus();
			return;
		}
		if(window.document.frmCardRequst.txtGlcode.value=="")
		{
			alert("Please Enter GLCode")
			window.document.frmCardRequst.txtGlcode.focus();
			return;
		}
		if(window.document.frmCardRequst.txtAccNo.value=="")
		{
			alert("Please Enter Account No.")
			window.document.frmCardRequst.txtAccNo.focus();
			return;
		}
		
		if(window.document.frmCardRequst.txtFirstnam.value=="")
		{
			alert("Please Enter Name On Card")
			window.document.frmCardRequst.txtFirstnam.focus();
			return;
		}
		if(window.document.frmCardRequst.txtMothnam.value=="")
		{
			alert("Please Enter Mother Name")
			window.document.frmCardRequst.txtMothnam.focus();
			return;
		}
		if(window.document.frmCardRequst.txtCrdlmt.value=="")
		{
			alert("Please Enter Cars Limit")
			window.document.frmCardRequst.txtCrdlmt.focus();
			return;
		}
		if(window.document.frmCardRequst.txtMobphon.value=="")
		{
			alert("Please Enter Mobile")
			window.document.frmCardRequst.txtMobphon.focus();
			return;
		}
		if(window.document.frmCardRequst.txtAdd1.value=="")
		{
			alert("Please Enter Address1")
			window.document.frmCardRequst.txtAdd1.focus();
			return;
		}
		if(window.document.frmCardRequst.txtAdd2.value=="")
		{
			alert("Please Enter Address2")
			window.document.frmCardRequst.txtAdd2.focus();
			return;
		}
		if(window.document.frmCardRequst.txtAdd3.value=="")
		{
			alert("Please Enter Address3")
			window.document.frmCardRequst.txtAdd3.focus();
			return;
		}
		if(window.document.frmCardRequst.txtCitycode.value=="")
		{
			alert("Please Enter City")
			window.document.frmCardRequst.txtCitycode.focus();
			return;
		}
		if(window.document.frmCardRequst.txtZipcod.value=="")
		{
			alert("Please Enter Zip Code")
			window.document.frmCardRequst.txtZipcod.focus();
			return;
		}
		if(window.document.frmCardRequst.txtState.value=="")
		{
			alert("Please Enter State")
			window.document.frmCardRequst.txtState.focus();
			return;
		}
		
		St = "I"+"~"+window.document.frmCardRequst.hidRef.value+"~"+
			window.document.frmCardRequst.txtbranchcode.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtcurrencycode.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtModid.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtGlcode.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtAccNo.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtAccNm.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtFirstnam.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtMothnam.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtCrdlmt.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtMobphon.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtAdd1.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtAdd2.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtAdd3.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtCitycode.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtZipcod.value.toUpperCase()+"~"+
			window.document.frmCardRequst.txtState.value.toUpperCase()
		
		//alert(" St = "+St)
		window.document.frmCardRequst.mercust.value=St
		window.document.frmCardRequst.action="cardRequstinsert.aspx"
		window.document.frmCardRequst.method="post"   
		window.document.frmCardRequst.submit()
	}
	
	function New()
	{
		window.document.frmCardRequst.hidRef.value=""
		window.document.frmCardRequst.txtModid.value=""
		window.document.frmCardRequst.txtModiddesc.value=""
		window.document.frmCardRequst.txtGlcodedesc.value=""
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtGlcode.value=""
		window.document.frmCardRequst.txtAccNo.value=""
		window.document.frmCardRequst.txtFirstnam.value=""
		window.document.frmCardRequst.txtMothnam.value=""
		window.document.frmCardRequst.txtCrdlmt.value=""
		window.document.frmCardRequst.txtMobphon.value=""
		window.document.frmCardRequst.txtAdd1.value=""
		window.document.frmCardRequst.txtAdd2.value=""
		window.document.frmCardRequst.txtAdd3.value=""
		window.document.frmCardRequst.txtCitycode.value=""
		window.document.frmCardRequst.txtZipcod.value=""
		window.document.frmCardRequst.txtState.value=""
		
		
	}
	
	
	</script>
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display();DispTranMsg();">

    <form name="frmCardRequst">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>Customer Card Request</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" cellspacing="0" border="0" cellpadding="0" class="tablebordermain">
					<tr>
						<td width="100%">
							<div align="center">
							<center>
							<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor1">
												<td width="10%">
												<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>New&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">Modify&nbsp;</font></p></td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							</center>
							</div>
							<div align="center">
							<center>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=txtautofill onkeypress=addresschar() id=txtbranchcode onblur='Dataarrange(txtbranchcode);DescrptionDisp("txtbranchcode")' onkeyup='window.document.frmCardRequst.txtBrdesc.value=""' style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: right" tabIndex=1 maxLength=6 size=16 value="<%=session("branchcode")%>" name=txtbranchcode ><INPUT class=button id=btnBr onclick=Branch() type=button value=" L " name=butBranch><INPUT class=bgcolor1 onkeypress=addresschar() readOnly size=20 value="<%=session("branchnarration")%>" name=txtBrdesc></FONT></td>
										<td align=left width="15%"><P align=left>Currency Code&nbsp;&nbsp;</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=addresschar() id=txtcurrencycode onblur='Dataarrange(txtcurrencycode);DescCheck("txtcurrencycode")' onkeyup='window.document.frmCardRequst.txtCrdesc.value=""' style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" tabIndex=2 type=text size=10 value="<%=session("currencycode")%>" name=txtcurrencycode ><INPUT class=button disabled onclick=Currency() type=button value=" L " name=butCur><INPUT class=bgcolor1 onkeypress=addresschar() readOnly size=23 value="<%=session("currencynarration")%>" name=txtCrdesc></FONT></td>
									</tr>
									<tr>
										<td align=left width="15%"><P align=left >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module Id</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtModid')" style="TEXT-TRANSFORM: uppercase" maxLength=16 onchange="return txtModid_onchange()" size=16 name=txtModid ><INPUT class=button onclick=Tellmodule() type=button value=" L " name=butdbtmodid><INPUT class=bgcolor1 readOnly type=text size=20 name=txtModiddesc ></FONT></td>
										<td align=left width="15%"><P align=left>GL Code&nbsp;&nbsp;</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtGlcode')" style="TEXT-TRANSFORM: uppercase" type=text maxLength=6 onchange="return txtGlcode_onchange()" size=10 name=txtGlcode ><INPUT class=button onclick=TellerGl() type=button value=" L " name=butdbtglcode><INPUT class=bgcolor1 readOnly type=text size=23 name=txtGlcodedesc ></FONT></td>
									</tr>
									<tr>
										<td width="13%" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Acc.No</td>
										<td width="35%"><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtAccNo')" type=text maxLength=16 size=16 name=txtAccNo><INPUT class=button onclick=Acccode() type=button value=" L " name=butdbtaccno><INPUT class=bgcolor1 readOnly type=text size=20 name=txtAccNm ></td>
										<td align=left width="15%"><!--<P align=left>Cur Balance&nbsp;&nbsp;</P> ---></td>
										<td width="35%"><!--<FONT color=#000000 size=2 ><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: right" readOnly type=text maxLength=6 size=19 name=txtCurBal ></FONT> ---></td>
									</tr>
								</table>
							</center>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%">
							<div align="center">
							<center>
								<fieldset style="width:950px;">
								<legend><font color="blue">Applicant Details</font></legend>
									<table width="100%" border='0'>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;NAME ON CARD&nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtFirstnam" ></font></td>
											<td width="12%"><font color=#000000 size=2>&nbsp;&nbsp;MOTHER NAME&nbsp;&nbsp;</font></td>
											<td width="23%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtMothnam" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;CARD LIMIT &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=5 size=20 name="txtCrdlmt" onkeypress="numdec(this.value)" ></font></td>
										</tr>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;MOBILE </font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=10 size=20 name="txtMobphon" onkeypress="numdec(this.value)" ></font></td>
											<td width="12%"><font color=#000000 size=2>&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
											<td width="23%"><font color=#000000 size=2></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2></font></td>
										</tr>
									</table>
								</fieldset>
							</center>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%">
							<div align="center">
							<center>
								<fieldset style="width:950;">
								<legend><font color="blue">Permanent Address</font></legend>
									<table width="100%" border='0'>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS1 &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtAdd1" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS2&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtAdd2" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS3&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtAdd3" ></font></td>
										</tr>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;CITY &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtCitycode" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ZIP CODE&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=6 size=20 name="txtZipcod" onkeypress="numdec(this.value)" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;STATE&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtState" ></font></td>
										</tr>
									</table>
								</fieldset>
							</center>
							</div>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<div>
							<center>
							<table width="100%" border='01'>
								
							</table>
							</center>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center"><input name="cmdOk" onclick="Ok()" type="button" value="   Ok   " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmcardrequest.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
				</table>
			</div>
			</td>
		</tr>
	</table>
					
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<input type="hidden" name="hidAdd">
	<input type="hidden" name="hidcit">
	<input type="hidden" name="hidZip">
	<input type="hidden" name="hidRef">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<IFRAME id=iGetDtls style="DISPLAY: block" align=center frameSpacing=0 src="../gen/getDtls.aspx" frameBorder=0 width=0 height=0></IFRAME>
	<iframe id="iBatch" frameBorder=0 frameSpacing=0  height=0 width=0 src="../GENSBCA/querydisplay.aspx"></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>