<%@ Page aspcompat="true" explicit="false" CodeBehind="atmwisereport.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.atmwisereport" %>
<%
dim strmessage

	strmessage=Request.QueryString("record")
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>ATM Wise Report</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<!--
//this function is used to set mode status depending upon the the option buttons clicked

var userid = "'"+'<%=session("userid")%>'+"'"
var macid = "'"+'<%=session("machineid")%>'+"'"
var appdat = "'"+'<%=session("applicationdate")%>'+"'"
var stBrcd = "<%=session("branchcode")%>"
	
///for sending parameters to list form for branchCode

function Branch()
{
	
	var branch="Branch"	
	 var user="<%=userid%>" // log in userid
			
	st=branch;
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:180px;DialogLeft:225px;DialogTop:190px")
}

//-----------------------To Assign Branch details to text boxes----------------------

 function Branchid(kstr)
{	
	assign(kstr,window.document.frmatmwiserep.txtBranchDesc,window.document.frmatmwiserep.txtBranchCode)      	    

}
///for sending parameters to list form for CurrencyCode
function currency()
{	
if(window.document.frmatmwiserep.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
	st="Currency"
	window.showModalDialog("atmList.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:180px;DialogLeft:120px;DialogTop:320px")
			
	splitString("window.document.frmatmwiserep","txtcid,"+
				"txtcdesc")
}
//displaying cashiercode,name which are returned by list page
function  Currencyid(kstr)
{var p,prn,j,k
  var k=kstr.split("-----")
  window.document.frmatmwiserep.txtCurrencyDesc.value =k[0]
  window.document.frmatmwiserep.txtCurrencyCode.value =k[1]
  
  var prn=eval(k[2].length)-1
  window.document.frmatmwiserep.hpr.value=prn
  p=""
  for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	
	
 }	

function clearFormATMTrans()
{
window.document.frmatmwiserep.txtAccountno.value = ""
window.document.frmatmwiserep.txtNarration.value = ""
window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.cmbDate.selectedIndex=0
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgatmtran.Cols=8
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}

function clearFormATMCustTrans()
{
window.document.frmatmwiserep.txtModId.value = ""
window.document.frmatmwiserep.txtModNm.value = ""
window.document.frmatmwiserep.txtGLcode.value= ""
window.document.frmatmwiserep.txtGLname.value = ""
window.document.frmatmwiserep.txtAccNo.value = ""
window.document.frmatmwiserep.txtAccNm.value = ""
	window.document.frmatmwiserep.txtCustToDate.disabled=true
	window.document.frmatmwiserep.cmbcustDate.selectedIndex=0
	window.document.frmatmwiserep.txtCustFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtCustToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmCusttran.Rows=1
	window.document.frmatmwiserep.mfgatmCusttran.Cols=8
	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No  |< App Date      |< Modid       |< GLcode   |<Accno           |< Name                               |> Amount           |< Remarks                              "

}

function CrdDetail()
{
	initialcheck()
	window.document.frmatmwiserep.mfgtran.Rows=1
	window.document.all.divCrdAcount.style.display="none"
	window.document.all.divCrdDate.style.display="none"
	window.document.all.divIsDate.style.display="none"
	window.document.all.divcardWise.style.display="none"
	
	window.document.frmatmwiserep.chkIsall.checked = false
	window.document.frmatmwiserep.txtdbtmodid.value = ""
	window.document.frmatmwiserep.txtdbtmodiddesc.value = ""
	window.document.frmatmwiserep.txtdbtglcode.value = ""
	window.document.frmatmwiserep.txtdbtglcodedesc.value = ""
	window.document.frmatmwiserep.txtdbtaccno.value = ""
	window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
	
	if(window.document.frmatmwiserep.radAcctype(0).checked==true)
	{
		window.document.all.divIsDate.style.display="block"
	}
	if(window.document.frmatmwiserep.radAcctype(1).checked==true)
	{
		window.document.all.divCrdDate.style.display="block"
	}
	if(window.document.frmatmwiserep.radAcctype(2).checked==true)
	{
		window.document.all.divCrdAcount.style.display="block"
	}
	if(window.document.frmatmwiserep.radAcctype(3).checked==true)
	{
		window.document.all.divCrdDate.style.display="block"
	}
	if(window.document.frmatmwiserep.radAcctype(4).checked==true)
	{
		window.document.all.divcardWise.style.display="block"
	}
	
	
}

function Tellermodule()
	{
		window.document.frmatmwiserep.mfgtran.Rows=1
		stmod="ATMTELLERMOD"; 
		stbr=window.document.frmatmwiserep.txtBranchCode.value
		kstr=stmod+"|"+stbr
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}

	function Modulecode(kstr)
	{
		assign(kstr,window.document.frmatmwiserep.txtdbtmodiddesc,window.document.frmatmwiserep.txtdbtmodid)
		window.document.frmatmwiserep.txtdbtglcode.value = ""
		window.document.frmatmwiserep.txtdbtglcodedesc.value = ""
		window.document.frmatmwiserep.txtdbtaccno.value = ""
		window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
	}
	
	function TellerGl()
	{
		window.document.frmatmwiserep.mfgtran.Rows=1
		if(window.document.frmatmwiserep.txtdbtmodid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmatmwiserep.txtBranchCode.value
		modid=window.document.frmatmwiserep.txtdbtmodid.value.toUpperCase() 
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog("../CUSTOMER/silist.aspx" + "?"+"st="+kstr,window,"status:no;"+
			"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	/*function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmatmwiserep.txtdbtglcodedesc,window.document.frmatmwiserep.txtdbtglcode)
		window.document.frmatmwiserep.txtdbtaccno.value = ""
		window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
		
	}*/
	
	function Acccode()
	{
		window.document.frmatmwiserep.mfgtran.Rows=1
		if(window.document.frmatmwiserep.txtdbtglcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
	     
		stacc="Telleraccno"
		 
		brchCd=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
		ModId=window.document.frmatmwiserep.txtdbtmodid.value.toUpperCase();
		GlCd=window.document.frmatmwiserep.txtdbtglcode.value.toUpperCase();
		Crcd=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase();
		
			kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+Crcd+"|"+"='R'"
		
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0) && (Crcd.length>0))
		{
   			window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
				"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   		}
	    
	    
	}
	/*function accountid(kstr)
	{ 
		assign(kstr,window.document.frmatmwiserep.txtdbtaccnodesc,window.document.frmatmwiserep.txtdbtaccno)
	}*/
	
	function DescrptionDisp1(strTxt)
	{
		sBr = window.document.frmatmwiserep.txtBranchCode.value.toUpperCase()
		sMod = window.document.frmatmwiserep.txtdbtmodid.value.toUpperCase()
		sGL = window.document.frmatmwiserep.txtdbtglcode.value.toUpperCase()
		sAccno = window.document.frmatmwiserep.txtdbtaccno.value.toUpperCase()
		sCur = window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase()
		
		if(strTxt=="txtdbtmodid")
		{ 
			window.document.frmatmwiserep.txtdbtglcode.value = ""
			window.document.frmatmwiserep.txtdbtglcodedesc.value = ""
			window.document.frmatmwiserep.txtdbtaccno.value = ""
			window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
		
			if(window.document.frmatmwiserep.txtdbtmodid.value=="")
			{
				return;
			}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"' and m.moduleid in ('CA','CC','SB')~~"+strTxt
				
		}
		
		if(strTxt=="txtdbtglcode")
		{ 
			window.document.frmatmwiserep.txtdbtaccno.value = ""
			window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
			
			if(window.document.frmatmwiserep.txtdbtglcode.value=="")
			{
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
		}
		
		if(strTxt=="txtdbtaccno")
		{ 
			if(window.document.frmatmwiserep.txtdbtaccno.value=="")
			{
				return;
			}
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
		}
		
		//alert("st2 = "+st)
		window.document.all["iBatch"].src="../GENSBCA/querydisplay.aspx?st="+st
		
	}
	
	function QueryTrans()
	{
		var st, strdatewhere, Datecon, stfield, stStat,stFed
		
		window.document.frmatmwiserep.mfgtran.Rows=1
	// card request	
		if(window.document.frmatmwiserep.radAcctype(0).checked==true)
		{
			if(window.document.frmatmwiserep.cmbIsDate.value!="Between")
			{
				if(window.document.frmatmwiserep.txtIsFromDate.value=="")
				{
					alert("Please Enter From Date")
					return;
				}

				strdatewhere = " AND applicationdate "+window.document.frmatmwiserep.cmbIsDate.value+" '"+window.document.frmatmwiserep.txtIsFromDate.value+"'"
				
				Datecon=strdatewhere	
			}
			else
			{
				if((window.document.frmatmwiserep.txtIsFromDate.value=="")||
					(window.document.frmatmwiserep.txtIsToDate.value==""))
				{
					alert("Enter both From And To Dates")
					return;
				}
				
					strdatewhere = " AND applicationdate >= '"+window.document.frmatmwiserep.txtIsFromDate.value+"' AND applicationdate <='"+window.document.frmatmwiserep.txtIsToDate.value+"'"
					
					Datecon=strdatewhere
			}
			
			if(window.document.frmatmwiserep.chkIsall.checked == true)
			{
				stStat = " "
			}
			else
			{
				stStat = " AND CARDNUMBER IS NULL "
			}
			
			window.document.frmatmwiserep.mfgtran.Cols=9
			window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<BrCode     |<ModId      |<Glcode       |<Acc No.             |<Name                           |< Mobile No         |< Card Number  ";
			
			st = "CRDDETAILS"+"|"+window.document.frmatmwiserep.txtBranchCode.value.toUpperCase()+"|"+strdatewhere+"|"+stStat
				
		}
		
		//Card Status
		if(window.document.frmatmwiserep.radAcctype(1).checked==true)
		{
			if(window.document.frmatmwiserep.selAcType.value=="")
			{
				alert("Please Select Status Type")
				return;
			}
			
			if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				stFed = "ISSUEDATE"
			}
			else if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				stFed = "ISSUEDATE"
			}
			else if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				stFed = "VALIDUPTODATE"
			}
			else
			{
				stFed = "CLOSEDATE"
			}
			
			
			if(window.document.frmatmwiserep.cmbcrdDate.value!="Between")
			{
				if(window.document.frmatmwiserep.txtcrdFromDate.value=="")
				{
					alert("Please Enter From Date")
					return;
				}

				strdatewhere = " AND a."+stFed+window.document.frmatmwiserep.cmbcrdDate.value+"'"+window.document.frmatmwiserep.txtcrdFromDate.value+"'"
				
				Datecon=strdatewhere	
			}
			else
			{
				if((window.document.frmatmwiserep.txtcrdFromDate.value=="")||
					(window.document.frmatmwiserep.txtcrdToDate.value==""))
				{
					alert("Enter both From And To Dates")
					return;
				}
				
					strdatewhere = " AND a."+stFed+" >= '"+window.document.frmatmwiserep.txtcrdFromDate.value+"' AND a."+stFed+" <='"+window.document.frmatmwiserep.txtcrdToDate.value+"'"
					
					Datecon=strdatewhere
			}
			
			//Running
			if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				window.document.frmatmwiserep.mfgtran.Cols=11
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date  |< Card Number         |< Card Limit     |< Cash Limit    |< Card Type                    |< Mobile No    | Status ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name,TO_CHAR(a.issuedate, 'dd-Mon-yyyy') , a.CARDNO, a.CARDLIMIT, a.CASHLIMIT,  b.DESCRIPTION crdtyp ,  nvl((SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid),'') mobileno,a.status"
				
					stStat = " AND a.Status='R' "
			}
			
			//issue
			if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				window.document.frmatmwiserep.mfgtran.Cols=11
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date  |< Card Number         |< Card Limit     |< Cash Limit    |< Card Type                    |< Mobile No    | Status ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name,TO_CHAR(a.issuedate, 'dd-Mon-yyyy') , a.CARDNO, a.CARDLIMIT, a.CASHLIMIT,  b.DESCRIPTION crdtyp ,  nvl((SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid),'') mobileno,a.status"
				
				stStat = " "
			}
			// Closed
			if(window.document.frmatmwiserep.selAcType.value=="C")
			{
				window.document.frmatmwiserep.mfgtran.Cols=12
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date           |<Expired Date        |<Close Date       |< Card Number         |< Card Type            |Mobile No      |Status      |<Reason         ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name, TO_CHAR(issuedate, 'DD-Mon-YYYY'), TO_CHAR(VALIDUPTODATE, 'DD-Mon-YYYY'),TO_CHAR(closedate, 'DD-Mon-YYYY') ,a.CARDNO,  b.DESCRIPTION crdtyp ,  nvl((SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid),'') mobileno,a.status,a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			// Lost
			if(window.document.frmatmwiserep.selAcType.value=="L")
			{
				window.document.frmatmwiserep.mfgtran.Cols=12
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date           |<Expired Date        |<Lost Date        |< Card Number         |< Card Type            |Mobile No      |Status      |<Reason         ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name, TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY')  LOSTDATE, a.CARDNO,  b.DESCRIPTION crdtyp ,(SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid) mobileno,a.status,REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			//Expired 
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				window.document.frmatmwiserep.mfgtran.Cols=11
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date           |<Expired Date        |< Card Number         |< Card Type            |Mobile No      |Status      |<Reason         ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name, TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  ExpireDATE, a.CARDNO,  b.DESCRIPTION crdtyp ,(SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid) mobileno,a.status, a.REMARKS "
				
				stStat = " "
			}
			//Block
			if(window.document.frmatmwiserep.selAcType.value=="B")
			{
				window.document.frmatmwiserep.mfgtran.Cols=12
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.                   |<Name                           |< Issue Date           |<Expired Date        |<Blocked Date        |< Card Number         |< Card Type            |Mobile No      |Status      |<Reason         ";
				
				stfield = " a.SNO, a.branchcode ,a.glcode , lpad(a.accno,7,'0'), substr(a.name,0,25) name, TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY')  BLOCKDATE, a.CARDNO,  b.DESCRIPTION crdtyp ,(SELECT custmobile FROM gencustinfomst WHERE customerid =  a.customerid) mobileno,a.status, a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			
			st = "CARDSTATUS"+"|"+Datecon+"|"+stfield+"|"+stStat+"|"+stFed
		}

		//account wise
		if(window.document.frmatmwiserep.radAcctype(2).checked==true)
		{
			if(window.document.frmatmwiserep.txtdbtmodid.value=="")
			{
				alert("Please Select Module Id")
				return;
			}
			if(window.document.frmatmwiserep.txtdbtglcode.value=="")
			{
				alert("Please Select Glcode")
				return;
			}
			if(window.document.frmatmwiserep.txtdbtaccno.value=="")
			{
				alert("Please Select Account No.")
				return;
			}
			
			window.document.frmatmwiserep.mfgtran.Cols=11
			window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo   |< Crd Number         |< Crd Type            |< Category Type         |< Scope              |< Issue Date           |<Expired Date        |< Close Date         |<Status              |< Remarks                                      "
			
			st = "ACRDTAIL"+"|"+window.document.frmatmwiserep.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmatmwiserep.txtdbtaccno.value.toUpperCase()+"|"+window.document.frmatmwiserep.txtBranchCode.value.toUpperCase()
			
		}
		//date wise
		if(window.document.frmatmwiserep.radAcctype(3).checked==true)
		{
			if(window.document.frmatmwiserep.selAcType.value=="")
			{
				alert("Please Select Status Type")
				return;
			}
			
			if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				stFed = "ISSUEDATE"
			}
			else if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				stFed = "ISSUEDATE"
			}
			else if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				stFed = "VALIDUPTODATE"
			}
			else
			{
				stFed = "CLOSEDATE"
			}
			
			if(window.document.frmatmwiserep.cmbcrdDate.value!="Between")
			{
				if(window.document.frmatmwiserep.txtcrdFromDate.value=="")
				{
					alert("Please Enter From Date")
					return;
				}

				strdatewhere = " AND a."+stFed+window.document.frmatmwiserep.cmbcrdDate.value+"'"+window.document.frmatmwiserep.txtcrdFromDate.value+"'"
				
				Datecon=strdatewhere	
			}
			else
			{
				if((window.document.frmatmwiserep.txtcrdFromDate.value=="")||
					(window.document.frmatmwiserep.txtcrdToDate.value==""))
				{
					alert("Enter both From And To Dates")
					return;
				}
				
					strdatewhere = " AND a."+stFed+" >= '"+window.document.frmatmwiserep.txtcrdFromDate.value+"' AND a."+stFed+" <='"+window.document.frmatmwiserep.txtcrdToDate.value+"'"
					
					Datecon=strdatewhere
			}
				if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				window.document.frmatmwiserep.mfgtran.Cols=9
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<ValidFrom  |<ValidTo         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(TO_DATE(a.VALIDFROMDATE, 'dd-MON-YYYY'), 'MMYY') VALIDFROMDATE , TO_CHAR(TO_DATE(a.VALIDUPTODATE, 'dd-MON-YYYY'), 'MMYY') VALIDUPTODATE "
				
				stStat = " AND a.Status='R' "
			}
			if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				window.document.frmatmwiserep.mfgtran.Cols=9
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<ValidFrom  |<ValidTo         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(TO_DATE(a.VALIDFROMDATE, 'dd-MON-YYYY'), 'MMYY') VALIDFROMDATE , TO_CHAR(TO_DATE(a.VALIDUPTODATE, 'dd-MON-YYYY'), 'MMYY') VALIDUPTODATE "
				
				stStat = " "
			}
			if(window.document.frmatmwiserep.selAcType.value=="C")
			{
				window.document.frmatmwiserep.mfgtran.Cols=10
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<Expired Date        |<Close Date        |<Reason         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY')  CLOSEDATE, a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			if(window.document.frmatmwiserep.selAcType.value=="L")
			{
				window.document.frmatmwiserep.mfgtran.Cols=10
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<Expired Date        |<Lost Date        |<Reason         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY')  LOSTDATE, a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				window.document.frmatmwiserep.mfgtran.Cols=9
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<Expired Date        |<Reason         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  ExpireDATE, a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			if(window.document.frmatmwiserep.selAcType.value=="B")
			{
				window.document.frmatmwiserep.mfgtran.Cols=10
				window.document.frmatmwiserep.mfgtran.formatstring = "< SNo  |< SLNo      |<Acc No.             |<Name                           |< Card Number         |< Card Type            |< Issue Date           |<Expired Date        |<Blocked Date        |<Reason         ";
				
				stfield = " a.SNO, a.accno, substr(a.name,0,25) name, a.CARDNO,  b.DESCRIPTION crdtyp , TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY')  BLOCKDATE, a.REMARKS "
				
				stStat = " AND a.Status="+"'"+window.document.frmatmwiserep.selAcType.value+"'"
			}
			
			st = "LISTDETAILS"+"|"+Datecon+"|"+stfield+"|"+stStat+"|"+stFed
			
		}
		// card wise
		if(window.document.frmatmwiserep.radAcctype(4).checked==true)
		{
		if (window.document.frmatmwiserep.txtSCardNum.value=="")
		{
			alert("Select Card Number")
			return;
		}
		
		window.document.frmatmwiserep.mfgtran.Rows=1
		window.document.frmatmwiserep.mfgtran.Cols=9
		window.document.frmatmwiserep.mfgtran.formatstring = "^S No    |< Txn Date            |<Modid     |<AccNo                       |< Batchno              |< Tranno                     |> Amount                     |< Remarks                                |<  Ref Num                       "
		
		st="ATMCARDWISEACCNO" +"|"+ window.document.frmatmwiserep.hidcwaccno.value + "|" + window.document.frmatmwiserep.txtCWDate.value
		}
		window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+st
	}
	
	
	function popLstdtail(str)
	{
		var strResult=str.split("|")
		
		if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
			
			var strCols=strResult[aCnt].split("~")
			
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
			}
		}
		
	}
	
	function DisplayATMCardWise(str)
{
var strResult1=str.split("*")
var strResult=strResult1[1].split("|")
var totdramt 
totdramt=0
var totcramt 
totcramt = 0
 if  (strResult1[0]  == "ATMCARDWISEACCNO")
  {
  
  	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,2)=strCols[1] // modid 
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,3)=strCols[2] // glcode 
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,4)=strCols[3] // batchno 
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,5)=strCols[4] // tranno
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,6)=strCols[5] // amount
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,7)=strCols[6] // remarks
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,8)=strCols[7] // refnum
		
		if (eval(strCols[5]) > 0 )
		{
	
		totdramt = parseFloat(totdramt) + parseFloat(strCols[5])
			
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[5])
			
		}
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,6)=strCols[5] 
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,6)),2)
		}

		window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
		window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,5)= "Total Reversals"
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)= Math.abs(totdramt)
		
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)),2)
		
		window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,5)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)= totcramt
	
		window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgtran.textmatrix(window.document.frmatmwiserep.mfgtran.rows-1,6)),2)
  
  }
}	
	function popAcdtail(str)
	{
		var strResult=str.split("|")
		
		if(strResult[0]=="")
		{
			alert("No Records Found")
			return;
		}
		
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgtran.rows=window.document.frmatmwiserep.mfgtran.rows+1
			
			var strCols=strResult[aCnt].split("~")
			
			window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmatmwiserep.mfgtran.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
			}
		}
		
	}

function ShowDivision(str)
{
	initialcheck()
	clearFormATMTrans()
	clearFormATMCustTrans()

	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgtran.Rows=1
	window.document.frmatmwiserep.mfgReconciltran.Rows=1
	window.document.frmatmwiserep.mfgAtmposi.Rows=1
	window.document.all.divatmtran.style.display="none"
	window.document.all.divAtmissue.style.display="none"
	window.document.all.divCrdAcount.style.display="none"
	window.document.all.divCrdDate.style.display="none"
	window.document.all.divatmcusttran.style.display="none"
	window.document.all.divTrnRef.style.display = "none"
	window.document.all.divReconsol.style.display = "none"
	window.document.all.divAtmPosition.style.display="none"

	window.document.frmatmwiserep.txtdbtmodid.value = ""
	window.document.frmatmwiserep.txtdbtmodiddesc.value = ""
	window.document.frmatmwiserep.txtdbtglcode.value = ""
	window.document.frmatmwiserep.txtdbtglcodedesc.value = ""
	window.document.frmatmwiserep.txtdbtaccno.value = ""
	window.document.frmatmwiserep.txtdbtaccnodesc.value = ""

	if(str=="0")
	{
		window.document.all.divTran.style.display = "block"
		window.document.all.divatmtran.style.display="block"
		window.document.all.divatmcusttran.style.display="none"
		window.document.frmatmwiserep.rdmode(0).checked = true
	}
	if(str=="1")
	{
		window.document.all.divatmcusttran.style.display="block"
		window.document.all.divatmtran.style.display="none"
	}
	if(str=="2")
	{
		window.document.all.divAtmissue.style.display="block"
		window.document.frmatmwiserep.radAcctype(0).checked=true
		window.document.all.divIsDate.style.display="block"
	}
	if(str=="3")
	{
		window.document.all.divReconsol.style.display="block"
	}
	if(str=="4")
	{
		window.document.all.divAtmPosition.style.display="block"
	}

}


function initialcheck()
{
	window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtcrdToDate.disabled=true
	window.document.frmatmwiserep.txtcrdFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtcrdToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtIsToDate.disabled=true
	window.document.frmatmwiserep.txtIsFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtIsToDate.value = "<%=session("applicationdate")%>"
	
	window.document.frmatmwiserep.txtAtmDate.value = "<%=session("applicationdate")%>"
}

function Clschange()
{
	window.document.frmatmwiserep.mfgtran.Rows=1	
	window.document.frmatmwiserep.cmbcrdDate.value="="
	initialcheck()
}

function toDateDisp()
{
	if(window.document.all.divatmtran.style.display=="block")
	{
		if(window.document.frmatmwiserep.cmbDate.value!="Between")
		{
			window.document.frmatmwiserep.txtToDate.disabled=true
		}
		else
		{
			window.document.frmatmwiserep.txtToDate.disabled=false
		}
	}
	if(window.document.all.divIsDate.style.display=="block")
	{
		if(window.document.frmatmwiserep.cmbIsDate.value!="Between")
		{
			window.document.frmatmwiserep.txtIsToDate.disabled=true
		}
		else
		{
			window.document.frmatmwiserep.txtIsToDate.disabled=false
		}
	}
	if(window.document.all.divCrdDate.style.display=="block")
	{
		if(window.document.frmatmwiserep.cmbcrdDate.value!="Between")
		{
			window.document.frmatmwiserep.txtcrdToDate.disabled=true
		}
		else
		{
			window.document.frmatmwiserep.txtcrdToDate.disabled=false
		}
	}
	
}

// card wise
function SCardNum()
{

if (window.document.frmatmwiserep.txtCardNum.value == "")
{
	alert("Enter Card Number")
	return;
}

window.document.frmatmwiserep.mfgtran.Rows=1
window.document.frmatmwiserep.txtSCardNum.value= ""
window.document.frmatmwiserep.txtCWAccNm.value = ""
window.document.frmatmwiserep.txtCWDate.value = ""
var	kstr = "SameCardNumber" + "|" + window.document.frmatmwiserep.txtCardNum.value
		window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:480px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px");

}
//

function GetSameCards(kstr)
{

	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmatmwiserep.hidcwaccno.value = ""
	window.document.frmatmwiserep.txtSCardNum.value=StrFld[1]
	window.document.frmatmwiserep.txtCWAccNm.value=StrFld[0]
	window.document.frmatmwiserep.hidcwaccno.value = StrFld[2]
}

function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)


if(window.document.all.divatmtran.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtFromDate.value=""
				window.document.frmatmwiserep.txtFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtToDate.value,window.document.frmatmwiserep.txtFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtToDate.value=""
				window.document.frmatmwiserep.txtToDate.focus()
			}
}

if(window.document.all.divatmcusttran.style.display=="block")
{
var intRefnd=getDateDiff(window.document.frmatmwiserep.txtCustFromDate.value, "<%=session("applicationdate")%>")
			
			if(intRefnd>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmatmwiserep.txtCustFromDate.value=""
				window.document.frmatmwiserep.txtCustFromDate.focus()
			}
			
			var intRefTODt=getDateDiff(window.document.frmatmwiserep.txtCustToDate.value,window.document.frmatmwiserep.txtCustFromDate.value)
			
			if(intRefTODt<0)
			{
				if(window.document.frmatmwiserep.txtCustFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmatmwiserep.txtCustFromDate.focus()
				}
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmatmwiserep.txtCustToDate.value=""
				window.document.frmatmwiserep.txtCustToDate.focus()
			}
}

if(window.document.all.divAtmPosition.style.display=="block")
{
	var intRefnd=getDateDiff(window.document.frmatmwiserep.txtAtmDate.value, "<%=session("applicationdate")%>")
			
	if(intRefnd>0)
	{
		alert("Date Should Not be Greater Than Application Date.")
		window.document.frmatmwiserep.txtAtmDate.value=""
		window.document.frmatmwiserep.txtAtmDate.focus()
	}
			
}

			
}

	function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
//-->

function clearATMTrans()
{
window.document.frmatmwiserep.txtToDate.disabled=true
	window.document.frmatmwiserep.cmbDate.selectedIndex=0
	window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	window.document.frmatmwiserep.mfgatmtran.Cols=8
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}

function GetAccountNo()
{

if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
clearATMTrans()

var vin="GetAccountNoIDS"+"|"+window.document.frmatmwiserep.txtBranchCode.value + "|" + window.document.frmatmwiserep.txtAccountno.value.toUpperCase()
window.document.all['iBatch'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function DisplayAccName(kstr)
{
	if (kstr=="") 
	{
		if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() == "ALL")
		{
			window.document.frmatmwiserep.txtNarration.value = "ALL"
			return;
		}
		else
		{
			alert("Invalid ATM AccNo")
			return;
		}
	}
	else
	{
		window.document.frmatmwiserep.txtNarration.value = kstr
	}
}

function Accountno()
{

if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}
clearATMTrans()

var brcode=window.document.frmatmwiserep.txtBranchCode.value


	st="ATMIDSAccNo"+"|"
	window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:380px;DialogHeight:170px;DialogLeft:560px;DialogTop:190px")
}

function DispAccNo(kstr)
{ 
var kstr1  = kstr.split("-----")

window.document.frmatmwiserep.txtNarration.value = kstr1[0]
window.document.frmatmwiserep.txtAccountno.value = kstr1[1]

}

function QueRefTrans()
{
var strVal
	if(window.document.frmatmwiserep.txtRefnum.value=="")
	{
		alert("Please Enter The Ref Number")
		return;
	}
	
	window.document.frmatmwiserep.mfgatmtran.Rows=1
	
	if(window.document.frmatmwiserep.rdmode(2).checked==true)
	{
	strVal = "REFSERCHNUM"+"|"+window.document.frmatmwiserep.txtRefnum.value
	}

	if(window.document.frmatmwiserep.rdmode(3).checked==true)
	{
	strVal = "LOGREFSERCHNUM"+"|"+window.document.frmatmwiserep.txtRefnum.value
	}
	
	window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}

function GetPoprefNum(str)
{
	var strResult=str.split("|")
		
	if(strResult[0]=="")
	{
		alert("No Records Found")
		window.document.frmatmwiserep.txtRefnum.value = "";
		return;
	}
	
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
	{
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		
		var strCols=strResult[aCnt].split("~")
		
		window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
		}
	}
}

function GetMode()
{
window.document.frmatmwiserep.txtAccountno.value = ""
window.document.frmatmwiserep.txtNarration.value = ""
window.document.frmatmwiserep.txtRefnum.value = ""
window.document.frmatmwiserep.cmbDate.selectedIndex=0
window.document.frmatmwiserep.txtToDate.disabled=true
window.document.frmatmwiserep.txtFromDate.value = "<%=session("applicationdate")%>"
window.document.frmatmwiserep.txtToDate.value = "<%=session("applicationdate")%>"
window.document.all.divTran.style.display = "block"
window.document.all.divTrnRef.style.display = "none"
window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
}
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< No Of Trans                                             "
}
if(window.document.frmatmwiserep.rdmode(2).checked==true)
{
	window.document.all.divTran.style.display = "none"
	window.document.all.divTrnRef.style.display = "block"
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< ATMACCNO       |< ATM Name                                       |<TNXDATE           |<APPDATE          |<BATCHNO    |<TRANNO       |> Amount                     |<MODID         |<GLCODE          |<ACCNO                   |<REFNUMBER          |< REMARKS                                             "
}
// log refnum
if(window.document.frmatmwiserep.rdmode(3).checked==true)
{
	window.document.all.divTran.style.display = "none"
	window.document.all.divTrnRef.style.display = "block"
	window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No |< Br code|< GL Code |<Acc No     |<Batch No  |<Status      |>Amount      |< Ref Num         |<Service                         |<Remarks                           |<ATMID           |<ATM Location                      |< App Date      |<System Date           "
}

}

function SetATMs()
{

if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
	if (window.document.frmatmwiserep.txtAccountno.value != "")
	{
		if (window.document.frmatmwiserep.txtAccountno.value=="ALL")
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              "
		}
		else
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< Batchno                 |< Tranno                       |> Amount                            |< Remarks                                                                   "
		}
		
	}
}

if(window.document.frmatmwiserep.rdmode(1).checked==true)
{

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() != "")
	{
		if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="ALL")
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=6
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< No Of Trans                                             "
		}
		else
		{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=4
		window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                 |> Amount                     |< No Of Trans                                             "
		}
	}
}
}

function QueryATMTrans()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="")
{
alert("Enter Atm ID")
return;
}

// Detail
if(window.document.frmatmwiserep.rdmode(0).checked==true)
{
window.document.frmatmwiserep.mfgatmtran.Rows=1
window.document.frmatmwiserep.mfgatmtran.Cols=7

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() =="ALL")
{
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< Tnx Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                        |> ReferenceNum              "
var strVal="ATMTRANSDETALL"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value   +"|"+ window.frmatmwiserep.cmbtnxtype.value
}

if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase() !="ALL")
{
window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< Tnx Date                |< Batchno                 |< Tranno                       |> Amount                            |< Remarks                                                           |> ReferenceNum        "
var strVal="ATMTRANSDETATM"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value +"|"+ window.document.frmatmwiserep.txtAccountno.value.toUpperCase()   +"|"+  window.frmatmwiserep.cmbtnxtype.value
}
}

// Summary
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{
	if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="ALL")
	{
	alert("hi")
		window.document.frmatmwiserep.mfgatmtran.Rows=1
		window.document.frmatmwiserep.mfgatmtran.Cols=8

		window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date                |< ATMID              |< ATM Name                                                       |>With Drwl Amount           |>Recon Amount          |> Difference              |< No Of Trans                                             "
		var strVal="ATMTRANSSUMALL"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value  +"|"+  window.frmatmwiserep.cmbtnxtype.value   +"|"+  window.frmatmwiserep.cmbtnxtype.value
	}

	if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()!="ALL")
	{
		window.document.frmatmwiserep.mfgatmtran.Rows=1
		window.document.frmatmwiserep.mfgatmtran.Cols=6

		window.document.frmatmwiserep.mfgatmtran.formatstring = "^S No       |< App Date             |>With Drwl Amount           |>Recon Amount          |> Difference              |< No Of Trans            "
		var strVal="ATMTRANSSUMATM"+"|"+window.document.frmatmwiserep.txtBranchCode.value+"|"+window.document.frmatmwiserep.txtCurrencyCode.value+"|"+window.document.frmatmwiserep.cmbDate.value +"|"+ window.document.frmatmwiserep.txtFromDate.value +"|"+ window.document.frmatmwiserep.txtToDate.value +"|"+ window.document.frmatmwiserep.txtAccountno.value.toUpperCase()  +"|"+  window.frmatmwiserep.cmbtnxtype.value
	}
}

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}

function DisplayATMTrans(str)
{

var strResult1=str.split("*")
var strResult=strResult1[1].split("|")

// detail all
if (strResult1[0]  == "ATMTRANSDETALL")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // accno 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // name
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=strCols[4] // remarks
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=strCols[5] // reference num		
				
		if (eval(strCols[3]) < 0 )
		{
	
		totdramt = parseFloat(totdramt) + parseFloat(strCols[3])
			
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[3])
			
		}
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)),2)
		}

		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= Math.abs(totdramt)
		
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
		
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= totcramt
	
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
}

// detail of ATMID
if (strResult1[0]  == "ATMTRANSDETATM")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // accno 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // batchno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // tranno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=strCols[4] // remarks
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=strCols[5] // reference num
		if (eval(strCols[3]) < 0 )
		{
		totdramt = parseFloat(totdramt) + parseFloat(strCols[3])
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[3])
		}
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] 
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)),2)
		}

		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= Math.abs(totdramt)
		
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
		
		window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,3)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)= totcramt
	
		window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(window.document.frmatmwiserep.mfgatmtran.rows-1,4)),2)
}

// summary of all ATMIDs
if (strResult1[0]  == "ATMTRANSSUMALL")
{
alert("hi")
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // ATMID
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // name
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // with drawal amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=strCols[4] // recon amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=strCols[5] // difference
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,7)=strCols[6] // no of trans
				
		
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)),2)
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)),2)
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,6)),2)
		}

		
}

// summary of ATMs
if (strResult1[0]  == "ATMTRANSSUMATM")
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
var totdramt
var totcramt
totdramt = 0
totcramt=0
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmtran.rows=window.document.frmatmwiserep.mfgatmtran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=strCols[1] // with drawal amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=strCols[2] // recon amount
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=strCols[3] // difference
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,5)=strCols[4] // no of trans
		
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,2)),2)
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,3)),2)
			window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmtran.textmatrix(aCnt+1,4)),2)
		}
		
}

}

function Report(strrep)
	{
		var StrCol=""
		var StrRow=""
		var StrHead=""
		var StrCols=""
		var StrColRow=""
		var strheadsub=""
		var strheadtype = ""
		var strSum = ""
// --------------Start ATM Transactions  ------------------------------

	if(window.document.all.divatmtran.style.display=="block")
	{
	// ----------- start Detail -----------------------
	if(window.document.frmatmwiserep.rdmode(0).checked==true)
	{
	// ----------------- start ALL --------------------
	
	if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="ALL")
	{
		if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transactions Detailed Report For All ATM Accounts "+ window.document.frmatmwiserep.txtFromDate.value + " To "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transactions Detailed Report  For All ATM Accounts AS ON DATE "+ window.document.frmatmwiserep.cmbDate.value + window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",5,L"+"~" //ATMid
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",23,L"+"~"  //NAME
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",11,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",25,L"+"~" //REMARKS
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",16,L"+"|" //Reference Num
			
for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					if (jcnt == 3)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt).substr(0,23) +"~"
					}	
					else if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt).substr(0,25) +"~"
					}
					else if (jcnt == 6)
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
					}	
					
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr

	}
	
	// ---------------- end ALL ATM Aaccounts ATM Transaction Detailed -------------------------
	
	// ------------start Not ALL ATM Aaccounts ATM Transaction Detailed -------------------------
	
		if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()!="ALL")
		{
		if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transaction Details For Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " And From "  + window.document.frmatmwiserep.txtFromDate.value + " to "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transaction Details For Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " AS ON DATE "+ window.document.frmatmwiserep.cmbDate.value + " " + window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",6,R"+"~" //batchno
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",6,R"+"~"  //tranno
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",15,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",36,L"+"~" //REMARKS
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",16,L"+"|" //refrence num

for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					
					if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt).substr(0,36) +"~"
					}
					else if (jcnt == 6)
					{
						if (strrep == 'report')
						{					
							StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}
						else
						{
							StrCols=StrCols+ "'" + window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
						}	
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	}
// ---------- end <> ALL ATM Accounts -------------------
	
	}
	// ---------------- end Detail --------------------------
	
// ---- start Summary  ---------------
if(window.document.frmatmwiserep.rdmode(1).checked==true)
{
// ----- start ALL -----------------------
	if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()=="ALL")
	{
		if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transactions Summary Report For All ATM Accounts From "+ window.document.frmatmwiserep.txtFromDate.value + " to "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transactions Summary Report  For All ATM Accounts AS ON DATE "+ window.document.frmatmwiserep.cmbDate.value + window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",5,L"+"~" //ATM ID
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",19,L"+"~"  //ATM NAME
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",15,R"+"~" //with drawal AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",15,R"+"~" //recon AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",15,R"+"~" //difference AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,7)+",15,L"+"|" // no of trans

for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					if (jcnt == 3)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt).substr(0,19) +"~"
					}	
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr

	}
// ----- end ALL Summary Report ----------------------------

// ----- start Not ALL ATM trans summary report-----------------------
	if (window.document.frmatmwiserep.txtAccountno.value.toUpperCase()!="ALL")
	{
	
	if(window.document.frmatmwiserep.cmbDate.value=="Between")
		{
			strheadsub = "ATM Transactions Summary Report For ATM Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " And From "  + window.document.frmatmwiserep.txtFromDate.value + " to "+window.document.frmatmwiserep.txtToDate.value
		}
		else
		{
			strheadsub = "ATM Transactions Summary Report For ATM Accno " + window.document.frmatmwiserep.txtAccountno.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtNarration.value + " AS ON DATE "+ window.document.frmatmwiserep.txtFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",15,R"+"~" //with drawal AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",15,R"+"~" //recon AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",15,R"+"~" //difference AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",10,L"+"|" // no of trans

for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
				{
					StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

		//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	}
// ----- end Not ALL ----------------------------
}
// ---- end Summary  ---------------
// --- start ref number---------
if(window.document.frmatmwiserep.rdmode(2).checked==true)
{
	strheadsub = "ATM Transactions Report For Ref Number "+ window.document.frmatmwiserep.txtRefnum.value 
		
	StrHead= strheadsub + ",60,80"

	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",16,L"+"~" //Atm accno
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",30,L"+"~" //ATM name
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",12,L"+"~"  //tnx date
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",12,L"+"~"  //app date
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",8,L"+"~" //batchno
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",8,L"+"~" //tranno
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,7)+",12,R"+"~" //Amount
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,8)+",8,L"+"~" //Moduleid
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,9)+",8,L"+"~" //glcode
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,10)+",17,L"+"~" //accno
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,11)+",13,L"+"~" //Refnum
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,12)+",50,L"+"|" // Remarks

	for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
	{
		StrCols=""
			for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
			{
				if((jcnt==10) || (jcnt==11))
				{
					if(strrep=="report")
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
					}
					else
					{
						StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
					}
				}
				else
				{
					StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
				}
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
	}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr	
}
/// --- end of ref number

// --- start Log Ref Number---------
if(window.document.frmatmwiserep.rdmode(3).checked==true)
{
	strheadsub = "ATM Transactions Report For Log Ref Number "+ window.document.frmatmwiserep.txtRefnum.value 
		
	StrHead= strheadsub + ",60,80"

	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,0)+",5,^"+"~" //sl no
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,1)+",6,L"+"~" //Br Code
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,2)+",8,L"+"~" //GL Code
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,3)+",8,L"+"~"  //Acc No
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,4)+",8,L"+"~"  //Batch no
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,5)+",10,L"+"~" //Status
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,6)+",12,R"+"~" //Amount
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,7)+",12,L"+"~" //Ref Num
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,8)+",20,L"+"~" //Service
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,9)+",20,L"+"~" //Remarks
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,10)+",8,L"+"~" //ATMID
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,11)+",20,L"+"~" //ATM Location
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,12)+",12,L"+"~" // APP Date
	StrCol=StrCol+window.document.frmatmwiserep.mfgatmtran.textmatrix(0,13)+",20,L"+"|" // System Date

	for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmtran.Rows-1;icnt++)
	{
		StrCols=""
			for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmtran.Cols-1;jcnt++)
			{
				if((jcnt==10) || (jcnt==11))
				{
					if(strrep=="report")
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
					}
					else
					{
						StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
					}
				}
				else
				{
					StrCols=StrCols+window.document.frmatmwiserep.mfgatmtran.textmatrix(icnt,jcnt)+"~"
				}
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
	}

//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr	
}
/// --- end of Log ref number
 
}	
// ------------- end ATM Transactions ------------------

	// ------------- Start ATM Customer Transactions ------------------
	if(window.document.all.divatmcusttran.style.display=="block")
	{
		// ----------- start Detail -----------------------
	if(window.document.frmatmwiserep.rdcustmode(0).checked==true)
	{
	
	// ----------------- start MOD ALL --------------------
	if (window.document.frmatmwiserep.txtModId.value.toUpperCase()=="ALL")
	{
		if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
			strheadsub = "ATM Customer Transactions Detailed Report For All Modules From "+ window.document.frmatmwiserep.txtCustFromDate.value + " To "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Detailed Report For All Modules AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}
	
			StrHead= strheadsub + ",60,80"
			
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",5,L"+"~" // MOD ID
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",6,L"+"~"  //GL CODE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,4)+",16,L"+"~" //ACCNO
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,5)+",12,L"+"~" //NAME
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,6)+",13,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,7)+",12,L"+"|" //REMARKS
		
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
					if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,12) +"~"
					}	
					else if (jcnt == 7)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,12) +"~"
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
					}	
					
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr

	}
	
	// ---------------- end MOD ALL ATM Customer Transaction Detailed Report---------------------------
	else // ---------------- start not MOD ALL ---------------------------
	{
	// ----------------- start Accno ALL (Atm Customer trns Detailed Report)--------------------
	if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()=="ALL")
	{
	if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
			strheadsub = "ATM Customer Transactions Detailed Report For All Accounts From " + window.document.frmatmwiserep.txtCustFromDate.value + " To "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Detailed Report For All Accounts AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}

		StrHead= strheadsub + ",60,80"
			
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",16,L"+"~" //ACCNO
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",15,L"+"~" //NAME
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,4)+",15,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,5)+",15,L"+"|" //REMARKS
		
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
					if (jcnt == 3)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,15) +"~"
					}	
					else if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,15) +"~"
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
					}	
					
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	}
// ---------- end Accno ALL (Atm Customer trns Detailed Report)--------------------
	
	
// ----------------- start Not ALL Accno (Atm Customer trns Detailed Report)--------------------------------------
	if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()!="ALL")
	{
	if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
		strheadsub = "ATM Customer Transactions Detailed Report For Acc No " + window.document.frmatmwiserep.txtAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtAccNm.value +"  And  From "  + window.document.frmatmwiserep.txtCustFromDate.value + " to "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Detailed Report For Acc No " + window.document.frmatmwiserep.txtAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtAccNm.value +" And AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}

		StrHead= strheadsub + ",60,80"
			
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",6,L"+"~" //modid
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",6,L"+"~" //glcode 
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,4)+",10,L"+"~" //batchno 
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,5)+",10,L"+"~" //tranno
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,6)+",15,R"+"~" //AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,7)+",15,L"+"|" //REMARKS
		
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
					if (jcnt == 7)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,15) +"~"
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
					}	
					
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	}// ---------- end Not ALL Accno  (Atm Customer trns Detailed Report)-------------------------------------
		
	} // ---------------- end not MOD ALL ---------------------------
}// ---- end Detail  ---------------

// -----------------start of Summary (ATM Customer Transaction)
if(window.document.frmatmwiserep.rdcustmode(1).checked==true)
{
// ------------------- start of mod ALL -------------------------
	if (window.document.frmatmwiserep.txtModId.value.toUpperCase()  == "ALL")
	{
	if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
			strheadsub = "ATM Customer Transactions Summary Report For All Modules From "  + window.document.frmatmwiserep.txtCustFromDate.value + " to "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Summary Report For All Modules AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}

		StrHead= strheadsub + ",60,80"

			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",6,L"+"~" //modid
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",6,L"+"~" //glcode 
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,4)+",16,L"+"~" //Accno 
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,5)+",16,L"+"~" //name
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,6)+",15,R"+"~" // sum of AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,7)+",5,C"+"|" //no of trans
		
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
					if (jcnt == 5)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,16) +"~"
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	}
// ------------------- end of mod ALL -------------------------	
else // ------------------- Start of Not mod ALL -------------------------	
{
// ----------------- start ALL Accno (summary Report) --------------------------------------
	if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()=="ALL")
	{
		if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
			strheadsub = "ATM Customer Transactions Summary Report For All Accounts From "  + window.document.frmatmwiserep.txtCustFromDate.value + " to "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Summary Report For All Accounts AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}

		StrHead= strheadsub + ",60,80"
		
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",16,L"+"~" //Accno 
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",28,L"+"~" //name
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,4)+",15,R"+"~" // sum of AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,5)+",5,C"+"|" //no of trans

			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
					if (jcnt == 3)
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt).substr(0,28) +"~"
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
					}	
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
		
		//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	
	}
// ----------------- end ALL Accno (summary report)--------------------------------------


// ----------------- start Not ALL Accno (Summary Report)--------------------------------------
	if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()!="ALL")
	{
		if(window.document.frmatmwiserep.cmbcustDate.value=="Between")
		{
			strheadsub = "ATM Customer Transactions Summary Report For Accno " + window.document.frmatmwiserep.txtAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtAccNm.value + " And From Date "  + window.document.frmatmwiserep.txtCustFromDate.value + " to Date "+window.document.frmatmwiserep.txtCustToDate.value
		}
		else
		{
			strheadsub = "ATM Customer Transactions Summary Report For Accno " + window.document.frmatmwiserep.txtAccNo.value.toUpperCase() + " Name " + window.document.frmatmwiserep.txtAccNm.value + " AS ON DATE "+ window.document.frmatmwiserep.cmbcustDate.value + window.document.frmatmwiserep.txtCustFromDate.value
		}

		StrHead= strheadsub + ",60,80"
		
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,0)+",5,^"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,1)+",11,L"+"~" //APP DATE
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,2)+",17,R"+"~" // sum of AMOUNT
			StrCol=StrCol+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(0,3)+",7,C"+"|" //no of trans

			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgatmCusttran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgatmCusttran.Cols-1;jcnt++)
				{
				
						StrCols=StrCols+window.document.frmatmwiserep.mfgatmCusttran.textmatrix(icnt,jcnt) +"~"
						
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}
		
		//sending total at the last of the report data
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
	
	}// ----------------- end Not ALL Accno (Summary Report)--------------------------------------

} // ------------------- end of Not mod ALL -------------------------	

}// --------------end of Summary (ATM Customer Transaction)

} // ------------- end of ATM Customer Transactions ------------------

// Start ATM Card
if(window.document.all.divAtmissue.style.display=="block")
	{
		strheadtype = "ATM WISE REPORT"
		// start card request
		if(window.document.frmatmwiserep.radAcctype(0).checked==true)
		{
			strheadtype = "ATM CARD REPORT"
			
			if (window.document.frmatmwiserep.cmbcrdDate.value!="Between")
			{
				strheadsub = "ATM CARD REQUEST REPORT FOR AS ON DATE  "+ window.document.frmatmwiserep.cmbIsDate.value + window.document.frmatmwiserep.txtIsFromDate.value
			}
			else
			{
				strheadsub = "ATM CARD REQUEST REPORT FOR  AS ON DATE BETWEEN "+ window.document.frmatmwiserep.txtIsFromDate.value +" TO "+ window.document.frmatmwiserep.txtIsToDate.value
			}
			
		StrHead= strheadsub + ",60,80"
				
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",8,L"+"~" //Brcode
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",8,L"+"~" //Mod Id
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",8,L"+"~" //Glcode
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",17,L"+"~"  //Acc No
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",30,L"+"~" //Name
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",12,L"+"~" //Mobile No
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",17,L"+"|"//Card No
			
			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if((jcnt==5) || (jcnt==7) || (jcnt==8))
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			
			}
						
					StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
		} 
		// end card request
		
		// start card status
		if(window.document.frmatmwiserep.radAcctype(1).checked==true)
		{
			strheadtype = "ATM CARD REPORT"
			if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				stFed = "RUNNING"
			}
			if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				stFed = "ISSUE"
			}
			if(window.document.frmatmwiserep.selAcType.value=="C")
			{
				stFed = "CLOSED"
			}
			if(window.document.frmatmwiserep.selAcType.value=="B")
			{
				stFed = "BLOCK"
			}
			if(window.document.frmatmwiserep.selAcType.value=="L")
			{
				stFed = "LOST"
			}
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				stFed = "EXPIRED"
			}
			if (window.document.frmatmwiserep.cmbcrdDate.value!="Between")
			{
				strheadsub = "CARD STATUS REPORT FOR "+ stFed +" AS ON DATE  "+ window.document.frmatmwiserep.cmbcrdDate.value + window.document.frmatmwiserep.txtcrdFromDate.value
			}
			else
			{
				strheadsub = "CARD STATUS REPORT FOR "+ stFed +" AS ON DATE BETWEEN "+ window.document.frmatmwiserep.txtcrdFromDate.value +" TO "+ window.document.frmatmwiserep.txtcrdToDate.value
			}
		
		
			StrHead= strheadsub + ",60,80"	
			if ((window.document.frmatmwiserep.selAcType.value=="R1") || (window.document.frmatmwiserep.selAcType.value=="R"))
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //NAme
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",17,L"+"~" //Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",14,L"+"~" //Card LIMIT    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",14,L"+"~" //CASH LIMIT    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,9)+",10,L"+"~" //MOBILE NO
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,10)+",6,L"+"|" //STATUS
				
			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
				
					if((jcnt==2) || (jcnt==5))
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
						
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
				
			}
			if((window.document.frmatmwiserep.selAcType.value=="C") || (window.document.frmatmwiserep.selAcType.value=="B") || (window.document.frmatmwiserep.selAcType.value=="L"))
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //Name
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",12,L"+"~" //Expire Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Block/close/loat Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",17,L"+"~" // Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,9)+",10,L"+"~" //MOBILE NO
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,10)+",6,L"+"~" //STATUS
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,11)+",30,L"+"|" //Reason
				
				for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if((jcnt==2) || (jcnt==7))
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			}
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //NAme
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",12,L"+"~" //Expire Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",17,L"+"~" // Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",10,L"+"~" //MOBILE NO
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,9)+",6,L"+"~" //STATUS
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,10)+",30,L"+"|" //Reason
				
			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if((jcnt==2) || (jcnt==6))
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			}
			
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
		} 
		
		// end card STATUS
				
		
		// start account wise
		if((window.document.frmatmwiserep.radAcctype(2).checked==true) || (window.document.frmatmwiserep.radAcctype(3).checked==true))
		{

		if(window.document.all.divCrdAcount.style.display=="block")
		{
			strheadsub = "ATM REPORT FOR Module "+ window.document.frmatmwiserep.txtdbtmodid.value +" GLCODE "+ window.document.frmatmwiserep.txtdbtglcode.value + " ACC NO. "+ window.document.frmatmwiserep.txtdbtaccno.value
			
		}
	
		if(window.document.all.divCrdDate.style.display=="block")
		{
		
		if(window.document.frmatmwiserep.selAcType.value=="R1")
			{
				stFed = "RUNNING"
			}
			
			if(window.document.frmatmwiserep.selAcType.value=="R")
			{
				stFed = "ISSUE"
			}
			if(window.document.frmatmwiserep.selAcType.value=="C")
			{
				stFed = "CLOSED"
			}
			if(window.document.frmatmwiserep.selAcType.value=="B")
			{
				stFed = "BLOCK"
			}
			if(window.document.frmatmwiserep.selAcType.value=="L")
			{
				stFed = "LOST"
			}
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				stFed = "EXPIRED"
			}
			if (window.document.frmatmwiserep.cmbcrdDate.value!="Between")
			{
				strheadsub = "ATM REPORT FOR "+ stFed +" AS ON DATE  "+ window.document.frmatmwiserep.cmbcrdDate.value + window.document.frmatmwiserep.txtcrdFromDate.value
			}
			else
			{
				strheadsub = "ATM REPORT FOR "+ stFed +" AS ON DATE BETWEEN "+ window.document.frmatmwiserep.txtcrdFromDate.value +" TO "+ window.document.frmatmwiserep.txtcrdToDate.value
			}
		}
		
			StrHead= strheadsub + ",60,80"
			
		if(window.document.all.divCrdAcount.style.display=="block")
		{
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Card No
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",8,L"+"~" //Card type 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",8,L"+"~" //Category Type
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",10,L"+"~"  //Scope 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Issue Date 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",12,L"+"~" //Expire Date 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",12,L"+"~"//Close Date
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,9)+",8,L"+"~"// Status
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,10)+",30,L"+"|"// Remarks
		}
		
		if(window.document.all.divCrdDate.style.display=="block")
		{
			if((window.document.frmatmwiserep.selAcType.value=="R1") || (window.document.frmatmwiserep.selAcType.value=="R"))
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //NAme
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",17,L"+"~" // Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",10,L"+"~" //validfrom
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",10,L"+"|" //validTo
			}
			if((window.document.frmatmwiserep.selAcType.value=="C") || (window.document.frmatmwiserep.selAcType.value=="B") || (window.document.frmatmwiserep.selAcType.value=="L"))
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //NAme
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",17,L"+"~" // Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",12,L"+"~" //Expire Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",12,L"+"~" //Block/close/loat Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,9)+",30,L"+"|" //Reason
			}
			if(window.document.frmatmwiserep.selAcType.value=="E")
			{
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",5,L"+"~" //Card Sno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",17,L"+"~" //Accno
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",25,L"+"~" //NAme
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",17,L"+"~" // Card No    
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",10,L"+"~"  //Card type
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Issue Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",12,L"+"~" //Expire Date 
				StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",30,L"+"|" //Reason
			}
		}
		
		if(window.document.all.divCrdAcount.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if(jcnt==2)
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
		}
		
		if(window.document.all.divCrdDate.style.display=="block")
		{
			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if(jcnt==4)
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
		}
		
		
		
		
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr

	} // acount wise and date wise
	}

// start of card wise
		if(window.document.frmatmwiserep.radAcctype(4).checked==true)
		{
		
		if(window.document.all.divcardWise.style.display=="block")
		{
			strheadsub = "Card Wise REPORT FOR Card No  "+ window.document.frmatmwiserep.txtSCardNum.value
			
		
		
			StrHead= strheadsub + ",60,80"
			
		
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,0)+",5,C"+"~" //sl no
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,1)+",11,L"+"~" //txn date
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,2)+",6,L"+"~" //modid
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,3)+",16,L"+"~" //accno 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,4)+",8,L"+"~" //batchno
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,5)+",8,L"+"~"  //tranno 
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,6)+",12,L"+"~" //Amount
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,7)+",25,L"+"~"//Remarks
			StrCol=StrCol+window.document.frmatmwiserep.mfgtran.textmatrix(0,8)+",12,L"+"|"// Ref Num
			
		
		

			for(icnt=1;icnt<=window.document.frmatmwiserep.mfgtran.Rows-1;icnt++)
			{
				StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgtran.Cols-1;jcnt++)
				{
					if(jcnt==3)
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
					}
					//StrCols=StrCols+window.document.frmatmwiserep.mfgtran.textmatrix(icnt,jcnt)+"~"
				}
				
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
			}
			
			
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol

		window.document.frmatmwiserep.hreport.value=StrArr
		 }		

		
		}
		// end of card wise

	
	/// Reconcilation Report start
	if(window.document.all.divReconsol.style.display=="block")
	{
		strheadsub = "ATM Reconcilation Report "
		
		StrHead= strheadsub + ",60,80"

		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,0)+",5,^"+"~" //sl no
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,1)+",9,L"+"~" //Tran Mode
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,2)+",10,L"+"~" //Terminal Id
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,3)+",17,L"+"~"  //Card number
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,4)+",20,L"+"~" //Acc no
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,5)+",8,L"+"~" //Tran type
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,6)+",12,R"+"~" //Amount
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,7)+",22,L"+"~" //Tnx Date
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,8)+",13,L"+"~" //Refnum
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,9)+",8,L"+"~" //accno
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,10)+",10,L"+"~" //Status
		StrCol=StrCol+window.document.frmatmwiserep.mfgReconciltran.textmatrix(0,11)+",10,L"+"|" // Match

		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgReconciltran.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgReconciltran.Cols-1;jcnt++)
				{
					if((jcnt==3) || (jcnt==4) || (jcnt==8))
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgReconciltran.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgReconciltran.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgReconciltran.textmatrix(icnt,jcnt)+"~"
					}
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

	//sending total at the last of the report data
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol

			window.document.frmatmwiserep.hreport.value=StrArr	
	}
	// end of Reconcilation
	
	//start of Atm Cash Position Report
	if(window.document.all.divAtmPosition.style.display=="block")
	{
		strheadsub = "ATM Cash Position Report As On Date "+window.document.frmatmwiserep.txtAtmDate.value
		
		StrHead= strheadsub + ",60,80"

		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,0)+",5,^"+"~" //sl no
		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,1)+",8,L"+"~" //brcode
		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,2)+",8,L"+"~" //glcode
		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,3)+",17,L"+"~"  //accno
		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,4)+",30,L"+"~" //Name
		StrCol=StrCol+window.document.frmatmwiserep.mfgAtmposi.textmatrix(0,5)+",16,R"+"|" //Amount
		
		for(icnt=1;icnt<=window.document.frmatmwiserep.mfgAtmposi.Rows-1;icnt++)
		{
			StrCols=""
				for(jcnt=0;jcnt<=window.document.frmatmwiserep.mfgAtmposi.Cols-1;jcnt++)
				{
					if(jcnt==3)
					{
						if(strrep=="report")
						{
							StrCols=StrCols+window.document.frmatmwiserep.mfgAtmposi.textmatrix(icnt,jcnt)+"~"
						}
						else
						{
							StrCols=StrCols+"'"+ window.document.frmatmwiserep.mfgAtmposi.textmatrix(icnt,jcnt)+"~"
						}
					}
					else
					{
						StrCols=StrCols+window.document.frmatmwiserep.mfgAtmposi.textmatrix(icnt,jcnt)+"~"
					}
				}
				StrCols=StrCols.substr(0,StrCols.length-1)
				StrColRow=StrColRow+StrCols+"|"
		}

	//sending total at the last of the report data
			StrColRow=StrColRow.substr(0,StrColRow.length-1)
			StrCol=StrCol+StrColRow
			StrArr=StrHead+"|"+StrCol

			window.document.frmatmwiserep.hreport.value=StrArr	
	}
	// end of Atm Cash Position



	if(strrep=="report")
		{
			window.document.frmatmwiserep.action="http://" + 
			"<%=session("moduledir")%>" +"/ReportGridTemplate.aspx?strng="+"/ATM/atmwisereport"
		}
		else
		{
			window.document.frmatmwiserep.action="http://" + 
			"<%=session("moduledir")%>" +"/ReportGridTemplateXL.aspx?strng="+"/ATM/atmwisereport"
		}
		window.document.frmatmwiserep.method="post"
		window.document.frmatmwiserep.submit();

}



// -- Start ATM Customer Transactions ---------------


function GetCustMode()
{
window.document.frmatmwiserep.txtModId.value = ""
window.document.frmatmwiserep.txtModNm.value = ""
window.document.frmatmwiserep.txtGLcode.value= ""
window.document.frmatmwiserep.txtGLname.value = ""
window.document.frmatmwiserep.txtAccNo.value = ""
window.document.frmatmwiserep.txtAccNm.value = ""

window.document.frmatmwiserep.cmbcustDate.selectedIndex=0
window.document.frmatmwiserep.txtCustToDate.disabled=true
window.document.frmatmwiserep.txtCustFromDate.value = "<%=session("applicationdate")%>"
window.document.frmatmwiserep.txtCustToDate.value = "<%=session("applicationdate")%>"
window.document.frmatmwiserep.mfgatmCusttran.Rows=1
window.document.frmatmwiserep.mfgatmCusttran.Cols=8

	if(window.document.frmatmwiserep.rdcustmode(0).checked==true)
	{
	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |<Modid                 |<GL Code           |< ACCNO              |< Name                                                       |> Amount                     |< Remarks                                              "
	}

	if(window.document.frmatmwiserep.rdcustmode(1).checked==true)
	{
	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date             |<Modid             |<GL Code          |< ACCNO              |< Name                                   |> Sum of Amount               |> No Of Trans           "
	}

}

function clearATMCustTrans()
{
window.document.frmatmwiserep.txtCustToDate.disabled=true
	window.document.frmatmwiserep.cmbcustDate.selectedIndex=0
	window.document.frmatmwiserep.txtCustFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.txtCustToDate.value = "<%=session("applicationdate")%>"
	window.document.frmatmwiserep.mfgatmCusttran.Rows=1
	window.document.frmatmwiserep.mfgatmCusttran.Cols=8
	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |< Modid              |< GLcode   |<Accno                 |< Name                                                       |> Amount                     |< Remarks                                              "
	
}


function module()
 { 
 clearATMCustTrans()
 	
 if(window.document.frmatmwiserep.txtBranchCode.value=="")
 {
	alert("Please Select Branchcode.")
	return
 }
 
 if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
 {
	alert("Please Select Currency Code.")
	return
 }

	splitString("window.document.frmatmwiserep","txtModId,txtModNm,txtGLcode,"+
		"txtGLname,txtAccNo,txtAccNm") 
		stmod="allsbcaccmodule"; 
		kstr=stmod
		window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
 }



function modulecode(kstr)
 {
	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmatmwiserep.txtModNm.value=StrFld[0]
	window.document.frmatmwiserep.txtModId.value=StrFld[1]
	
	disableglacc()
}

function disableglacc()
{
if (window.document.frmatmwiserep.txtModId.value.toUpperCase() == "ALL")
	{
		window.document.frmatmwiserep.txtGLcode.disabled =  true
		window.document.frmatmwiserep.B2.disabled =  true
		window.document.frmatmwiserep.txtGLname.disabled =  true
		window.document.frmatmwiserep.txtAccNo.disabled =  true
		window.document.frmatmwiserep.B4.disabled =  true
		window.document.frmatmwiserep.txtAccNm.disabled =  true
	}
	else
	{
		window.document.frmatmwiserep.txtGLcode.disabled =  false
		window.document.frmatmwiserep.B2.disabled =  false
		window.document.frmatmwiserep.txtGLname.disabled =  false
		window.document.frmatmwiserep.txtAccNo.disabled =  false
		window.document.frmatmwiserep.B4.disabled =  false
		window.document.frmatmwiserep.txtAccNm.disabled =  false
	}
}

function Glcode()
{ 

	if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	if(window.document.frmatmwiserep.txtModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	clearATMCustTrans()
	
	
	splitString("window.document.frmatmwiserep","txtGLcode","txtGLname,txtAccNo,txtAccNm")
	telgl="Tellerglcode";
	brcode=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
	modid=window.document.frmatmwiserep.txtModId.value.toUpperCase();
	kstr=telgl+"|"+brcode+"|"+modid
	if(modid!=""){
		 window.showModalDialog("../GEN/Listquery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	 } 
}
//Assign Selected GL code and GL desc to the Textboxes.	

function Glcodeid(kstr)
 { 
	
	if(window.document.all.divAtmissue.style.display=="block")
	{
		assign(kstr,window.document.frmatmwiserep.txtdbtglcodedesc,window.document.frmatmwiserep.txtdbtglcode)
		window.document.frmatmwiserep.txtdbtaccno.value = ""
		window.document.frmatmwiserep.txtdbtaccnodesc.value = ""
	}
	
	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmatmwiserep.txtGLcode.value=StrFld[1]
	window.document.frmatmwiserep.txtGLname.value=StrFld[0]
	
	
} 	 


function AccCode()
{
	if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	if(window.document.frmatmwiserep.txtModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	if(window.document.frmatmwiserep.txtGLcode.value=="")
	{
		alert("Please Select Glcode.")
		return;
	}	
	clearATMCustTrans()
	
	splitString("window.document.frmatmwiserep","txtAccNo,txtAccNm")
   	stacc="TellerATMaccno" 
	brchCd=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase();
    Crcd=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase();
    GlCd=window.document.frmatmwiserep.txtGLcode.value.toUpperCase();
    ModId=window.document.frmatmwiserep.txtModId.value.toUpperCase();
	
	kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+Crcd //+"|"+"='R'"
	
	if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0) && (Crcd.length>0))
	{
   		window.showModalDialog("atmlist.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   	}
   	else
   	{
   		alert('Select Branch code,Currency code,Module id and GL code.')
   	}
 }

//Assign Selected Account NO and Account Name to the Textboxes.

function accountid(kstr)
{ 
	if(window.document.all.divAtmissue.style.display=="block")
	{
		assign(kstr,window.document.frmatmwiserep.txtdbtaccnodesc,window.document.frmatmwiserep.txtdbtaccno)
	}
	assign(kstr,window.document.frmatmwiserep.txtAccNm,window.document.frmatmwiserep.txtAccNo)
}

function GetCustTrnsAccName()
{

if(window.document.frmatmwiserep.txtBranchCode.value=="")
	{
		alert("Please Select Branchcode.")
		return
	}
	 
	if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
	{
		alert("Please Select Currency Code.")
		return
	}
	if(window.document.frmatmwiserep.txtModId.value.toUpperCase()=="")
	{
		alert("Please Select Module Id.")
		return;
	}
	if(window.document.frmatmwiserep.txtGLcode.value=="")
	{
		alert("Please Select Glcode.")
		return;
	}	
	
clearATMCustTrans()

var vin="GetCustTrnsAccName"+"|"+window.document.frmatmwiserep.txtBranchCode.value +"|"+window.document.frmatmwiserep.txtCurrencyCode.value +"|"+window.document.frmatmwiserep.txtModId.value.toUpperCase() +"|"+window.document.frmatmwiserep.txtGLcode.value +"|"+window.document.frmatmwiserep.txtAccNo.value.toUpperCase() 
window.document.all['iBatch'].src='<%="http://" & session("moduledir")& "/ATM/"%>'+"getDtls.aspx?st="+vin;
}

function DisplayCustTrnsAccName(kstr)
{
	if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()  == "ALL")
	{
	window.document.frmatmwiserep.txtAccNm.value = "ALL"
	}
	else
	{
	if (kstr == "")
	{
		alert("No Records In Trans Table")
		return;
	}
	else
	{
		window.document.frmatmwiserep.txtAccNm.value = kstr
	}
	}
}

function toCustDateDisp()
{
if(window.document.frmatmwiserep.cmbcustDate.value!="Between")
{
window.document.frmatmwiserep.txtCustToDate.disabled=true
}
else
{
window.document.frmatmwiserep.txtCustToDate.disabled=false
}
}

 function DescrptionDisp(strTxt)
 {
 sBr=window.document.frmatmwiserep.txtBranchCode.value.toUpperCase()
 sMod=window.document.frmatmwiserep.txtModId.value.toUpperCase()
 sGL=window.document.frmatmwiserep.txtGLcode.value.toUpperCase()
 sCur=window.document.frmatmwiserep.txtCurrencyCode.value.toUpperCase()
 sAccno=window.document.frmatmwiserep.txtAccNo.value.toUpperCase()
 	/// for Branch Code
		if(strTxt=="txtBranchCode")
		{ 
		window.document.frmatmwiserep.txtbranchdesc.value=""
		if(window.document.frmatmwiserep.txtBranchCode.value=="")
		{
		return;
		}
				st="DescDisplay~GENBANKBRANCHMST~"+
				"NARRATION~branchcode='"+sBr+"'~~"+strTxt
		}

 	/// for currency
		
		if(strTxt=="txtCurrencyCode")
		{ 
		clearATMCustTrans()

		window.document.frmatmwiserep.txtcurrencydesc.value=""
		splitString("window.document.frmatmwiserep","txtModId,txtModNm,txtGLcode,"+
		"txtGLname,txtAccNo,txtAccNm") 
		if(sBr=="")
		{
			alert("Select Branch Code")
			window.document.frmatmwiserep.txtCurrencyCode.value=""
			return;
		}
		if(window.document.frmatmwiserep.txtCurrencyCode.value=="")
		{
		return;
		}
				st="DescDisplay~GENCURRENCYTYPEMST~"+
				"NARRATION,PRECISION~currencycode='"+sCur+"'~~"+strTxt
		}
		
		
		
 	///for ModuleId 
 		
		if(strTxt=="txtModId")
		{ 
		clearATMCustTrans()
	
		splitString("window.document.frmatmwiserep","txtGLcode,"+
		"txtGLname,txtAccNo,txtAccNm")
		if(sBr=="")
 		{
 			alert("select Branch Code")
 			window.document.frmatmwiserep.txtModId.value=""
 			return;
 		}
		if(window.document.frmatmwiserep.txtModId.value.toUpperCase()=="")
		{
		return;
		}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~M.IMPLEMENTEDYN='Y' and M.moduleid in ('SB','CA','CC') and M.moduleid='"+sMod+"'~~"+strTxt
		}
		///for Gl Code
		
		if(strTxt=="txtGLcode")
		{ 
		clearATMCustTrans()
	
		window.document.frmatmwiserep.txtGLname.value=""
	
		if(sMod=="")
		{
			alert("Select Module Id")
			window.document.frmatmwiserep.txtGLcode.value=""
			
			return;
		}
		if(window.document.frmatmwiserep.txtGLcode.value=="")
		{
		return;
		}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
		}
		
		if(strTxt=="txtCardNum")
		{ 
			window.document.frmatmwiserep.mfgtran.Rows=1
			window.document.frmatmwiserep.txtSCardNum.value= ""
			window.document.frmatmwiserep.txtCWAccNm.value = ""
			window.document.frmatmwiserep.txtCWDate.value = ""
		}

	//alert(st)
	window.document.all["iBatch"].src="../GEN/reportdisplay.aspx?st="+st	
}

function DescDisplay(stri)
{
var strtype=new String()
strtype=stri.split("~")
//for description displaying  split the values
var StrArrFld=new String()
var StrArrFlds=new String()
StrArrFld=strtype[0].split("|")

///for displaying ModuleDesc
	if(strtype[1]=="txtModId")
	{
		if (window.document.frmatmwiserep.txtModId.value.toUpperCase() == "ALL")
		{
			window.document.frmatmwiserep.txtModNm.value="ALL"
			disableglacc()
			return;
		}
	else
		{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Module Id")
					window.document.frmatmwiserep.txtModId.value=""
					window.document.frmatmwiserep.txtModNm.value=""
					return;
				}
		window.document.frmatmwiserep.txtModNm.value=StrArrFld[0]
		}
	}	
	
///for Currencycode
	if(strtype[1]=="txtcurrencycode")
	{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Currency Code")
				window.document.frmatmwiserep.txtcurrencycode.value=""
				window.document.frmatmwiserep.txtcurrencydesc.value=""
				return;
			}
			window.document.frmatmwiserep.txtcurrencydesc.value=StrArrFld[0]
	
	}
	
if(strtype[1]=="txtGLcode")
{

		if(StrArrFld[0]=="No")
			{
				alert("Invalid GL Code")
				window.document.frmatmwiserep.txtGLcode.value=""
				window.document.frmatmwiserep.txtGLname.value=""
				window.document.frmatmwiserep.txtAccNo.value=""
				window.document.frmatmwiserep.txtAccNm.value=""
			
	                        
				return;
			}
	window.document.frmatmwiserep.txtGLname.value=StrArrFld[0]

	}
	
	if(strtype[1]=="txtdbtmodid")
		{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid ModuleId")
					window.document.frmatmwiserep.txtdbtmodid.value=""
					window.document.frmatmwiserep.txtdbtmodiddesc.value=""
					window.document.frmatmwiserep.txtdbtmodid.focus()
					return;
				}
				window.document.frmatmwiserep.txtdbtmodiddesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtdbtglcode")
		{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Glcode")
					window.document.frmatmwiserep.txtdbtglcode.value=""
					window.document.frmatmwiserep.txtdbtglcodedesc.value=""
					window.document.frmatmwiserep.txtdbtglcode.focus()
					return;
				}
				window.document.frmatmwiserep.txtdbtglcodedesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtdbtaccno")
		{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Account No.")
					window.document.frmatmwiserep.txtdbtaccno.value=""
					window.document.frmatmwiserep.txtdbtaccnodesc.value=""
					window.document.frmatmwiserep.txtdbtaccno.focus()
					return;
				}
				window.document.frmatmwiserep.txtdbtaccnodesc.value=StrArrFld[0]
		}
}
	
function QueryATMCustTrans()
{
if (window.document.frmatmwiserep.txtBranchCode.value == "")
{
alert("Enter Branch Code")
return;
}
if (window.document.frmatmwiserep.txtCurrencyCode.value == "")
{
alert("Enter Currency Code")
return;
}

if (window.document.frmatmwiserep.txtModId.value.toUpperCase()=="ALL")
	{
	}
	else
	{
		if(window.document.frmatmwiserep.txtModId.value.toUpperCase()=="")
		{
			alert("Please Select Module Id.")
			return;
		}
		if(window.document.frmatmwiserep.txtGLcode.value=="")
		{
			alert("Please Select Glcode.")
			return;
		}	
	}

	
// Detail
if(window.document.frmatmwiserep.rdcustmode(0).checked==true)
{


	if (window.document.frmatmwiserep.txtModId.value.toUpperCase()  == "ALL")
	{
	window.document.frmatmwiserep.mfgatmCusttran.Rows=1
window.document.frmatmwiserep.mfgatmCusttran.Cols=8
	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |<Modid                 |<GL Code           |< ACCNO              |< Name                                                       |> Amount                     |< Remarks                                              "
	var strVal="ATMCUSTTRANSDETMODALL" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value 
	}
	else
	{
		if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()=="ALL")
		{
		window.document.frmatmwiserep.mfgatmCusttran.Rows=1
window.document.frmatmwiserep.mfgatmCusttran.Cols=6
		window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |< ACCNO              |< Name                                                       |> Amount                     |< Remarks                                              "
		var strVal="ATMCUSTTRANSDETACCALL" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value +"|"+ window.document.frmatmwiserep.txtModId.value.toUpperCase() +"|"+ window.document.frmatmwiserep.txtGLcode.value
		
		}

		if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()!="ALL")
		{
		window.document.frmatmwiserep.mfgatmCusttran.Rows=1
		window.document.frmatmwiserep.mfgatmCusttran.Cols=8
		window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |<Modid                 |<GL Code           |< Batchno              |< Tranno                     |> Amount                     |< Remarks                                              "
		var strVal="ATMCUSTTRANSDETACCSIN" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value +"|"+ window.document.frmatmwiserep.txtModId.value.toUpperCase() +"|"+ window.document.frmatmwiserep.txtGLcode.value +"|"+window.document.frmatmwiserep.txtAccNo.value.toUpperCase()
		}

	}
}

// Summary
if(window.document.frmatmwiserep.rdcustmode(1).checked==true)
{

	if (window.document.frmatmwiserep.txtModId.value.toUpperCase()  == "ALL")
	{
	window.document.frmatmwiserep.mfgatmCusttran.Rows=1
	window.document.frmatmwiserep.mfgatmCusttran.Cols=8

	window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date             |<Modid             |<GL Code          |< ACCNO              |< Name                                   |> Sum of Amount               |> No Of Trans           "
	var strVal="ATMCUSTTRANSSUMMODALL" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value 
	}
	else
	{
		if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()=="ALL")
		{
		window.document.frmatmwiserep.mfgatmCusttran.Rows=1
window.document.frmatmwiserep.mfgatmCusttran.Cols=6

		window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date              |< ACCNO              |< Name                                   |> Sum of Amount               |> No Of Trans           "
		var strVal="ATMCUSTTRANSSUMACCALL" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value +"|"+ window.document.frmatmwiserep.txtModId.value.toUpperCase() +"|"+ window.document.frmatmwiserep.txtGLcode.value
		}
		if (window.document.frmatmwiserep.txtAccNo.value.toUpperCase()!="ALL")
		{
		window.document.frmatmwiserep.mfgatmCusttran.Rows=1
window.document.frmatmwiserep.mfgatmCusttran.Cols=4
		window.document.frmatmwiserep.mfgatmCusttran.formatstring = "^S No       |< App Date                |> Amount                     |> NoOfTrans                      "
		var strVal="ATMCUSTTRANSSUMACCSIN" +"|"+ window.document.frmatmwiserep.txtBranchCode.value +"|"+ window.document.frmatmwiserep.txtCurrencyCode.value  +"|"+ window.document.frmatmwiserep.cmbcustDate.value +"|"+ window.document.frmatmwiserep.txtCustFromDate.value +"|"+ window.document.frmatmwiserep.txtCustToDate.value +"|"+ window.document.frmatmwiserep.txtModId.value.toUpperCase() +"|"+ window.document.frmatmwiserep.txtGLcode.value +"|"+window.document.frmatmwiserep.txtAccNo.value.toUpperCase()
		}
	}
}

window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}

function DisplayATMCustTrans(str)
{
var strResult1=str.split("*")
var strResult=strResult1[1].split("|")
var totdramt 
totdramt=0
var totcramt 
totcramt = 0
// detail all
if ((strResult1[0]  == "ATMCUSTTRANSDETMODALL"))
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // modid 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // glcode 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] // accno 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,5)=strCols[4] // name
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,7)=strCols[6] // remarks
		
		if (eval(strCols[5]) < 0 )
		{
		totdramt = parseFloat(totdramt) + parseFloat(strCols[5])
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[5])
		}
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)),2)
		}

		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,5)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)= Math.abs(totdramt)

		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)),2)
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1

		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,5)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)= totcramt
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)),2)
}


if ((strResult1[0]  == "ATMCUSTTRANSDETACCALL"))
{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // accno 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // name
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,5)=strCols[4] // remarks
		
		if (eval(strCols[3]) < 0 )
		{
		totdramt = parseFloat(totdramt) + parseFloat(strCols[3])
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[3])
		}
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)),2)
		}

		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,3)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)= Math.abs(totdramt)

		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)),2)
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1

		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,3)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)= totcramt
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,4)),2)
}



  if  (strResult1[0]  == "ATMCUSTTRANSDETACCSIN")
  {
  
  	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // modid 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // glcode 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] // batchno 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,5)=strCols[4] // tranno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,7)=strCols[6] // remarks
		
		if (eval(strCols[5]) < 0 )
		{
	
		totdramt = parseFloat(totdramt) + parseFloat(strCols[5])
			
		}
		else
		{
		totcramt = parseFloat(totcramt) + parseFloat(strCols[5])
			
		}
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)),2)
		}

		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,5)= "Total Reversals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)= Math.abs(totdramt)
		
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)),2)
		
		window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,5)= "Total Withdrawals"
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)= totcramt
	
		window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(window.document.frmatmwiserep.mfgatmCusttran.rows-1,6)),2)
  
  }
  // Summary 
  if (strResult1[0]  == "ATMCUSTTRANSSUMMODALL")
	{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // modid 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // glcode 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] // accno 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,5)=strCols[4] // name
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,7)=strCols[6] // no of trans
		
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=strCols[5] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,6)),2)
		}
		
}
  
  if (strResult1[0]  == "ATMCUSTTRANSSUMACCALL")
	{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // accno 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // name
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,5)=strCols[4] // no of trans
		
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=strCols[3] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,4)),2)
		}
		
}
  
  if ((strResult1[0]  == "ATMCUSTTRANSSUMACCSIN") )
	{
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			window.document.frmatmwiserep.mfgatmCusttran.rows=window.document.frmatmwiserep.mfgatmCusttran.rows+1
			var strCols=strResult[aCnt].split("~")
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,0)=aCnt+1   // sno
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,1)=Datepick1(strCols[0]) // app date
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] // amount
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,3)=strCols[2] // no of trans
		
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=strCols[1] 
			window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmatmwiserep.mfgatmCusttran.textmatrix(aCnt+1,2)),2)
		}
		
}
}

// ---- End ATM Customer Transactions

function submit_click()
{
	var strPath = window.document.frmatmwiserep.fileUploader.value
	
	if((strPath.substring(strPath.length-3,strPath.length).toUpperCase()!="XLS") && (strPath.substring(strPath.length-3,strPath.length).toUpperCase()!="LSX"))
	{
		alert("Please Select XLS File.")
		window.document.frmatmwiserep.fileUploader.value=""
		return;
	}
	
	var strInputs = stBrcd+"|"+appdat+"|"+userid+"|"+macid+"|"+stBrcd+"|"+strPath
	
	if(strPath.substring(strPath.length-3,strPath.length).toUpperCase() == "TXT")
	{
		window.document.frmatmwiserep.postdata.value="READ$"+strInputs
	}
	else
	{
		window.document.frmatmwiserep.postdata.value="READEXCEL$"+strInputs
	}
	
	//alert(" Reddy = "+window.document.frmatmwiserep.postdata.value)
	window.document.frmatmwiserep.action="../ATM/ReconcilReport.aspx"
	window.document.frmatmwiserep.method="post"
	window.document.frmatmwiserep.submit()
}

function message()
{
	var mess="<%=strmessage%>"
	
	if(mess!="")
	{
		var strCnt = mess.split("#")
	
		if(strCnt[0]=="Transaction Sucessful.")
		{
			window.document.all.divatmtran.style.display="none"
			window.document.all.divAtmissue.style.display="none"
			window.document.all.divCrdAcount.style.display="none"
			window.document.all.divCrdDate.style.display="none"
			window.document.all.divatmcusttran.style.display="none"
			window.document.all.divTrnRef.style.display = "none"
			window.document.all.divAtmPosition.style.display="none"
			window.document.all.divReconsol.style.display = "block"
			window.document.frmatmwiserep.fileUploader.value = strCnt[1]
			window.document.frmatmwiserep.mfgReconciltran.Rows=1
			
			var strVal = "RECONCILREP"
	
			window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
		}
		else
		{
			alert(strCnt[0])
			location.replace("../ATM/atmwisereport.aspx")
		}
	}
}

function GetPopreconcil(str)
{
	var strResult=str.split("|")
		
	if(strResult[0]=="")
	{
		alert("All Records Matched")
		return;
	}
	
	window.document.frmatmwiserep.mfgReconciltran.Rows=1
	
	window.document.frmatmwiserep.mfgReconciltran.Cols = 12
	window.document.frmatmwiserep.mfgReconciltran.formatstring = "^S No       |<TranMode    |<TerminalId              |<CardNumber                        |<AccNo                   |<Trantype              |>Amount                  |<TnxDate               |<RefNumber          |<ResponseCode|<Status     |<Match    ";
	
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
	{
		window.document.frmatmwiserep.mfgReconciltran.rows=window.document.frmatmwiserep.mfgReconciltran.rows+1
		
		var strCols=strResult[aCnt].split("~")
		
		window.document.frmatmwiserep.mfgReconciltran.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmatmwiserep.mfgReconciltran.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
		}
	}
}

function AtmPosiTrans()
{
	if(window.document.frmatmwiserep.txtAtmDate.value=="")
	{
		alert("Please Enter the Date")
		return;
	}
	
	var strVal = "ATMPOSITION"+"|"+window.document.frmatmwiserep.txtAtmDate.value
	
	window.document.all['iBatch'].src="getDtls.aspx?st="+strVal;
}

function PopAtmposi(str)
{
	var strResult=str.split("|")
		
	if(strResult[0]=="")
	{
		alert("No Records Found")
		return;
	}
	window.document.frmatmwiserep.mfgAtmposi.Rows=1
	window.document.frmatmwiserep.mfgAtmposi.Cols = 6
	window.document.frmatmwiserep.mfgAtmposi.formatstring = "^S No       |<BrCode    |<Glcode            |<AccNo                   |<Name                     |>Balance                  ";
	
	for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
	{
		window.document.frmatmwiserep.mfgAtmposi.rows=window.document.frmatmwiserep.mfgAtmposi.rows+1
		
		var strCols=strResult[aCnt].split("~")
		
		window.document.frmatmwiserep.mfgAtmposi.textmatrix(aCnt+1,0)=aCnt+1
		
		for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
		{
			window.document.frmatmwiserep.mfgAtmposi.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
			
			if(strCols[4] > 0)
			{
				window.document.frmatmwiserep.mfgAtmposi.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(strCols[4]),2)+" Cr"
			}
			else if(strCols[4] < 0)
			{
				window.document.frmatmwiserep.mfgAtmposi.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(strCols[4]),2)+" Dr"
			}
			else
			{
				window.document.frmatmwiserep.mfgAtmposi.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(strCols[4]),2)
			}
		}
	}
}

</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" topmargin="0" leftmargin="0" 
onload="GetMenu(&quot;<%=session("menustring")%>&quot;);message();initialcheck();">

<form name="frmatmwiserep">
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="100%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
        <div class="menuBar">
            <table cellpadding="0" cellspacing="0" width="100%" border=0>
                <tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                   
                    <td width="39%" align="CENTER" height="22" class="subHeader">
                        <h2>ATM Wise Report</h2>
                    </td>
                    <td width="39%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
                </tr>
            </table>
        </div>
        <div id="menucontrol"></div> 
  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain" border =1>
    <tr>
     <td>
    
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" valign="top" height="15">
          <p align="center">&nbsp;&nbsp;</p>
          </td>
        </tr>
      </table>

      <%appdate=formatdatetime(session("applicationdate"),1)%>


      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="1" >
        <tr>
          <td width="100%" height="29">

          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0" >
              <tr class="bgcolor">
                <td width="88" height="27">
                <p align="right"><font class="textbold">&nbsp;Branch Code&nbsp;</font></p>
                </td>
                <td width="282" height="27"><input class="txtautofill" name="txtBranchCode" style="TEXT-TRANSFORM: uppercase" 
                size="10" value="<%=session("branchcode")%>" onblur="Dataarrange(txtBranchCode);CashierDisp(&quot;txtBranchCode&quot;)" maxlength="10"><input type="button" value=" L " name="B3" onclick="Branch()"><input name="txtBranchDesc" size="18" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
                <td width="153" align="right" height="27"><font class="textbold">Currency
                Code &nbsp;&nbsp;</font></td>
                <td width="300" height="27"><input class="txtautofill" name="txtCurrencyCode" style="TEXT-TRANSFORM: 
                          uppercase" size="10" maxlength="10" onblur="Dataarrange(txtCurrencyCode);CashierDisp(&quot;txtCurrencyCode&quot;)" value="<%=session("currencycode")%>"><input type="button" value=" L " name="B9" onclick="currency()"><input name="txtCurrencyDesc" size="18" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
              <tr>
                <td width="88" height="10"></td>
                <td width="282" height="10"></td>
                <td width="153" align="right" height="10"></td>
                <td width="231" height="10"></td>
              </tr>
            </table>
            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain" border =0>
              <tr>
                <td width="14%" valign="top">

                <table border="0" width="100%" cellspacing="1" cellpadding="0">
                   <tr bgcolor="#99ccff" >
                    <td width="100%" height="18" nowrap><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">ATM Transactions</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff">
                    <td width="100%" height="18" nowrap><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">ATM Customer Trns</font></a></td>
                  </tr>
                   <tr bgcolor="#99ccff" >
                    <td width="100%" height="18" nowrap><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold">ATM Card Details</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff" >
                    <td width="100%" height="18" nowrap><a href="#" onclick="ShowDivision('3')">&nbsp;<font class="textbold">Reconciliation Report</font></a></td>
                  </tr>
                  <tr bgcolor="#99ccff" >
                    <td width="100%" height="18" nowrap><a href="#" onclick="ShowDivision('4')">&nbsp;<font class="textbold">ATM Cash Position</font></a></td>
                  </tr>
                </table>

                </td>
                <td width="86%" valign="top">
                <!------Start ATM Transactions  ---->
                  <div id="divatmtran" style="display:block">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="ATM Transactions" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
						</tr>
						<tr>
						<td colspan = 10 >
							<table width="97%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
                                <tr class="bgcolor1">
									<td width="25%"  align="middle"><input type="radio" name="rdmode" checked onclick="GetMode()"><font class="textblack">Details</font></td>
									<td width="25%"  align="middle"><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">Summary</font></td>
									<td width="25%"  align="middle"><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">RefNumber</font></td>
									<td width="25%"  align="middle"><input type="radio" name="rdmode" onclick="GetMode()"><font class="textblack">Log RefNumber</font></td>
								</tr>
							</table>
						</td>
						</tr>
						
						
						<tr>
							<td colspan =10>
								<div id="divTran" style="display=block">
								<table width = "99%" class= "tableborder2">
									<tr>
										<td colspan =10>
											<table border =0 width = "100%" cellpadding =0 cellspacing =0>
												<tr id = "divaccno" style="DISPLAY: Block">
													<td width = "20%" align =right >ATM ID&nbsp;&nbsp;&nbsp;&nbsp;</td>
				        <td><input onkeypress="Alphanum()" name="txtAccountno" class="txtautofill"  maxlength=16 style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onblur="GetAccountNo()" size="15"><input name="butAccno" onclick="Accountno()" type="button" value=" L " class="button"><input name="txtNarration" class=bgcolor1 readonly size="17" style="TEXT-TRANSFORM: capitalize"></td>
													<td width = "30%" align="left">Tnx Type<select size="1" name="cmbtnxtype" >
											<option value="ALL">ALL</option>
											<option value="ONUS">ONUS</option>
											<option value="OFFUS">OFFUS</option>
											<option value="LORO">LORO</option>
											</select></td>
												</tr> 
											</table>
										</td>
									</tr>
									<tr id = "divdates" style="DISPLAY: Block">
										<td width="20%" align="right" height="27">Operator&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="10%"><select size="1" name="cmbDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select>
										</td>
										<td width="10%" align="left">&nbsp;From Date</td>
										<td width="10%"><input type="text" name="txtFromDate" id="txtFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
										<td width="10%">(DDMMYYYY)</td>
										<td width="10%"><p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p></td>
										<td width="10%">&nbsp;<input type="text" name="txtToDate" id="txtToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
										<td width="20%">(DDMMYYYY) &nbsp;&nbsp; <input type="button" name="btnQuery" value="Query" onclick="QueryATMTrans()" class="button"></td>  
							</td>
						</tr>
					</table>
					</div>
					<div id="divTrnRef" style="display=none">
						<table width="100%">
							<tr>
								<td width="25%" align="center"><font class="textblack" >REF Number</font></td>
								<td width="25%"><input type="text" name="txtRefnum" id="txtRefnum" maxlength=12 size="12" onkeypress="numeric()" class="txtautofill"></td>
								<td width="25%"><input type="button" name="btnQuery" value=" Query " onclick="QueRefTrans()" class="button"></td>
								<td width="25%"></td>
							</tr>
						</table>
					
					</div>
									</td>
									</tr>
										<tr>
							<td width="90%" align="Left" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=280 id=mfgatmtran name=mfgatmtran style="HEIGHT: 280px; LEFT: 0px; TOP: 0px; WIDTH: 860x" width=860 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="6">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No       |< App Date                |< ATMID              |< ATM Name                                                       |> Amount                     |< Remarks                                              ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S.No">
							<PARAM NAME="TextMatrix0" VALUE="S.No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end ATM Transactions  ---->
                   
                   <!------ Start ATM Customer Transactions  ---->
                  <div id="divatmcusttran" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
						<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="ATM Customer Transactions" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
						</tr>
						<tr>
						<td colspan = 10 >
						<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
                                      <tr class="bgcolor1">
										<td width="30%"  align="middle"><input type="radio" name="rdcustmode" checked onclick="GetCustMode()"><font class="textblack">Details
                                        </font></td>
                                        <td width="30%"  align="middle"><input type="radio" name="rdcustmode" onclick="GetCustMode()"><font class="textblack">
                                        Summary</font></td>
                                      </tr>
                                    </table>
						</td>
						</tr>
						
						
						<tr>
                <td  nowrap valign="top" colspan="10" align="center">
<table width = "100%" class= "tableborder2">
						<tr><td colspan =10>
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="12%">&nbsp;&nbsp;&nbsp;&nbsp;Module ID</td>
                    <td width="38%" align=left>&nbsp;<input name="txtModId" size="16" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill" value="" onblur="DescrptionDisp(&quot;txtModId&quot;)"><input type="button" value=" L " name="B1" onclick="module()" class="button"><input name="txtModNm" class="bgcolor1" size="19" value="" readonly></td>
                    <td width="15%">
                    <p align="right">GL Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </td>
                    <td width="35%%">&nbsp;&nbsp;&nbsp;<input name="txtGLcode" onkeypress="Alphanum()" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="6" class="txtautofill"  onblur="Dataarrange(txtGLcode);DescrptionDisp(&quot;txtGLcode&quot;)"><input type="button" value=" L " name="B2" onclick="Glcode()" class="button"><input name="txtGLname" size="16" class="bgcolor1" readonly></td>
                  </tr>
                  <tr>
                    <td width="12%">&nbsp;&nbsp;&nbsp;&nbsp;Acc. No</td>
                    <td width="38%">&nbsp;<input name="txtAccNo" class="txtautofill" onkeypress="Alphanum()" maxlength="16" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" size="16" onblur="GetCustTrnsAccName()"><input type="button" value=" L " name="B4" onclick="AccCode()" class="button"><input name="txtAccNm" size="19" class="bgcolor1" readonly></td>
                <td width="65%"  align="right" valign="top" colspan=2  height="5">
				</td>
                  </tr>
				  </table>
                </td>
              </tr>
          			            
						<tr id = "divCustdates" style="DISPLAY: Block">
							<td width="11%" align="left" height="27">&nbsp;&nbsp;&nbsp;&nbsp;Operator</td>
							<td width="10%">&nbsp;<select size="1" name="cmbcustDate" onchange="toCustDateDisp()">
							<option value="=">=</option>
							<option value="&gt;">&gt;</option>
							<option value="&lt;">&lt;</option>
							<option value="Between">Between</option>
							</select></td>
							<td width="10%" align="left">&nbsp;From Date</td>
							<td width="10%"><input type="text" name="txtCustFromDate" id="txtCustFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
							<td width="10%">(DDMMYYYY)</td>
							<td width="10%">
							<p align="center">&nbsp;&nbsp;To</p>
							</td>
							<td width="10%">&nbsp;&nbsp;<input type="text" name="txtCustToDate" id="txtCustToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
							<td width="20%">(DDMMYYYY) &nbsp;&nbsp;<input type="button" name="btnQuery" value="Query" onclick="QueryATMCustTrans()" class="button"></td>
						</tr>
						</td></tr></table>
									</td>
									</tr>

						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=255 id=mfgatmCusttran name=mfgatmCusttran style="HEIGHT: 255px; LEFT: 0px; TOP: 0px; WIDTH: 840px" width=840 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="3">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="6">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No |< App Date        |< ATMID        |< ATM Name                    |> Amount        |< Remarks                      ">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S No">
							<PARAM NAME="TextMatrix0" VALUE="S No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
					</table>
                    
                  </div>
                   <!------end ATM Customer Transactions  ---->
                   <!---- ATM Card Details Start ------>
                   <div id="divAtmissue" style="display:none">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
						<tr>
							<td colspan="8"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="ATM Card Details" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
						</tr>
						<tr>
							<td colspan="8" align="center"><input type="radio" id="radAcctype" name="AccType" checked onclick="CrdDetail()">Card Request&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="radAcctype" name="AccType" onclick="CrdDetail()" >Card Status&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="radAcctype" name="AccType" onclick="CrdDetail()">Account Wise&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="radAcctype" name="AccType" onclick="CrdDetail()">Date Wise&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="radAcctype" name="AccType" onclick="CrdDetail()">Card Wise</td>
						</tr>
						<tr>
							<td colspan="8">
								<div id="divCrdAcount" style="display:none">
									<table class="tableborder2">
										<tr>
											<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module ID</td>
											<td width="17%"><input type="text" name="txtdbtmodid" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp1(&quot;txtdbtmodid&quot;)" size="16" onchange="return txtdbtmodid_onchange()"><input type="button" class="button" value=" L " name="butdbtmodid" onclick="Tellermodule()"><input type="text" name="txtdbtmodiddesc" class="bgcolor1" readonly size="28"></td>
											<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GL Code</td>
											<td width="17%"><input type="text" name="txtdbtglcode" class="txtautofill" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp1(&quot;txtdbtglcode&quot;)" size="9" onchange="return txtdbtglcode_onchange()" maxlength=6><input type="button" class="button" value=" L " name="butdbtglcode" onclick="TellerGl()"><input type="text" name="txtdbtglcodedesc" class="bgcolor1" readonly size="16"></td>
										</tr>
										<tr>
											<td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Acc.No</td>
											<td width="35%"><input type="text" name="txtdbtaccno" class="txtautofill" onkeypress="Alphanum()" onblur="DescrptionDisp1(&quot;txtdbtaccno&quot;)" size="16" maxlength="16"><input type="button" class="button" value=" L " name="butdbtaccno" onclick="Acccode()"><input type="text" name="txtdbtaccnodesc" class="bgcolor1" readonly size="28"></td>
											<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
											<td width="37%"></td>
										</tr> 
									
									</table>
								</div>
								
								<div id="divIsDate" style="display:none">
									<table class="tableborder2" border="0">
										<tr>
											<td width="10%" align="center" height="27">Operator</td>
											<td width="10%"><select size="1" name="cmbIsDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select></td>
											<td width="10%" align="left">&nbsp;From Date</td>
											<td width="10%"><input type="text" name="txtIsFromDate" id="dtpIsFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
											<td width="10%">(DDMMYYYY)</td>
											<td width="10%">
											<p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p>
											</td>
											<td width="10%">&nbsp;<input type="text" name="txtIsToDate" id="dtpIsToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
											<td width="10%">(DDMMYYYY)</td>
											<td width="20%"><input type="checkbox" id="chkIsall" name="chkIsall" >All Details </td>
										</tr>
									</table>
								</div>
								
								<div id="divCrdDate" style="display:none">
									<table class="tableborder2" border="0">
										<tr>
											<td width="10%" align="center" height="27">Status</td>
											<td width="10%" align="left"><select name="selAcType" onchange="Clschange()">
													<option value="" selected ></option>
													<option value="R1">Running</option>
													<option value="R">Issue</option>
													<option value="C">Closed</option>
													<option value="L">Lost</option>
													<option value="E">Expired</option>
													<option value="B">Block</option>
													</select></td>
											<td width="10%" align="center" height="27">Operator</td>
											<td width="10%"><select size="1" name="cmbcrdDate" onchange="toDateDisp()">
											<option value="=">=</option>
											<option value="&gt;">&gt;</option>
											<option value="&lt;">&lt;</option>
											<option value="Between">Between</option>
											</select></td>
											<td width="10%" align="left">&nbsp;From Date</td>
											<td width="10%"><input type="text" name="txtcrdFromDate" id="dtpcrdFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
											<td width="10%">(DDMMYYYY)</td>
											<td width="10%">
											<p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p>
											</td>
											<td width="10%">&nbsp;<input type="text" name="txtcrdToDate" id="dtpcrdToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
											<td width="10%">(DDMMYYYY)</td>
										</tr>
									</table>
								</div>
								
								<div id="divcardWise" style="display:none">
					
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="12%">Card Number</td>
                    <td width="38%" align=left><input name="txtCardNum" size="11" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="4" class="txtautofill" value="" onblur="DescrptionDisp(&quot;txtCardNum&quot;)">(Enter 4 Digits)</td>
					
                    <td width="10%">
                    <p align="right">Card Nos</p>
                    </td>
                    <td width="45%%" align =left ><input name="txtSCardNum" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" maxlength="22" size = "22" class="txtautofill"  onblur="Dataarrange(txtSCardNum);DescrptionDisp(&quot;txtSCardNum&quot;)" readonly><input type="button" value=" L " name="B2" onclick="SCardNum()" class="button"><input name="txtCWAccNm" size="22" maxlength = "25" class="bgcolor1" readonly></td>
                  </tr>
                  <tr>
                    <td width="12%">Date&nbsp;:&nbsp;</td><td width = "38%"><input type="text" name="txtCWDate" id="txtCWDate" maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">&nbsp;(DDMMYYYY)
				
					</td>
				</td>
                  </tr>
				  </table>
                
					
                  </div>
                   
								
							</td>
						</tr>

						<tr><td colspan='8'>&nbsp;</td></tr>
						<tr>
							<td colspan='8' align="center"><input type="button" name="btnQuery" value="Query" onclick="QueryTrans()" class="button"></td>
						</tr>
						<tr><td colspan='8'>&nbsp;</td></tr>
						<tr>
							<td width="100%" align="center" colspan='8'>
							<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgtran name=mfgtran style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 850px" width=950 >
							<PARAM NAME="_ExtentX" VALUE="15055">
							<PARAM NAME="_ExtentY" VALUE="3757">
							<PARAM NAME="BackColor" VALUE="-2147483643">
							<PARAM NAME="ForeColor" VALUE="-2147483640">
							<PARAM NAME="Enabled" VALUE="-1">
							<PARAM NAME="BackStyle" VALUE="0">
							<PARAM NAME="BorderStyle" VALUE="1">
							<PARAM NAME="AllowBigSelection" VALUE="-1">
							<PARAM NAME="AllowUserResizing" VALUE="1">
							<PARAM NAME="Appearance" VALUE="1">
							<PARAM NAME="BackColorBkg" VALUE="8421504">
							<PARAM NAME="BackColorFixed" VALUE="-2147483633">
							<PARAM NAME="BackColorSel" VALUE="-2147483635">
							<PARAM NAME="CausesValidation" VALUE="-1">
							<PARAM NAME="Cols" VALUE="1">
							<PARAM NAME="ColWidth0" VALUE="1725">
							<PARAM NAME="DrawMode" VALUE="0">
							<PARAM NAME="FillStyle" VALUE="0">
							<PARAM NAME="FixedCols" VALUE="0">
							<PARAM NAME="FixedRows" VALUE="1">
							<PARAM NAME="FocusRect" VALUE="1">
							<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
							<PARAM NAME="ForeColorSel" VALUE="-2147483634">
							<PARAM NAME="FormatString" VALUE="^S No">
							<PARAM NAME="GridColor" VALUE="12632256">
							<PARAM NAME="GridColorFixed" VALUE="0">
							<PARAM NAME="GridLines" VALUE="1">
							<PARAM NAME="GridLinesFixed" VALUE="2">
							<PARAM NAME="GridLineWidth" VALUE="1">
							<PARAM NAME="MergeCells" VALUE="0">
							<PARAM NAME="MergeCol0" VALUE="0">
							<PARAM NAME="MergeRow0" VALUE="0">
							<PARAM NAME="MousePointer" VALUE="0">
							<PARAM NAME="OLEDropMode" VALUE="0">
							<PARAM NAME="PictureType" VALUE="0">
							<PARAM NAME="Redraw" VALUE="-1">
							<PARAM NAME="RightToLeft" VALUE="0">
							<PARAM NAME="RowHeightMin" VALUE="0">
							<PARAM NAME="Rows" VALUE="1">
							<PARAM NAME="ScrollBars" VALUE="3">
							<PARAM NAME="ScrollTrack" VALUE="0">
							<PARAM NAME="SelectionMode" VALUE="0">
							<PARAM NAME="TextStyle" VALUE="0">
							<PARAM NAME="TextStyleFixed" VALUE="0">
							<PARAM NAME="ToolTipText" VALUE="">
							<PARAM NAME="WhatsThisHelpID" VALUE="0">
							<PARAM NAME="WordWrap" VALUE="0">
							<PARAM NAME="ColAlignment0" VALUE="9">
							<PARAM NAME="ColData0" VALUE="0">
							<PARAM NAME="FixedAlignment0" VALUE="4">
							<PARAM NAME="FontWidth" VALUE="0">
							<PARAM NAME="hWnd" VALUE="0">
							<PARAM NAME="RowData0" VALUE="0">
							<PARAM NAME="RowHeight0" VALUE="240">
							<PARAM NAME="TextArray0" VALUE="S.No">
							<PARAM NAME="TextMatrix0" VALUE="S.No">
							<PARAM NAME="row" VALUE="">
							<PARAM NAME="col" VALUE="">
							<PARAM NAME="RowSel" VALUE="">
							<PARAM NAME="ColSel" VALUE="">
							<PARAM NAME="CellBackColor" VALUE="">
							<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
							</td>
						</tr>
                    </table>
                    
                  </div>
                   <!----- ATM Card Details End of Report  ------>
                   <!--- Reconcilation Report Start --->
                   
                   <div id="divReconsol" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="ATM Reconcilation Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td colspan = 10 >
									<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
										<tr class="bgcolor1">
											<td width="20%" align="left" height="27">&nbsp;&nbsp;&nbsp;Choose Excel File</td>
											<td width="80%"><input type="file" id="fileUploader" name="fileUploader" ><input name="cmdSubmit" type="button" value="Submit" class="button" onclick="submit_click();"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td colspan = 10 width="100%">
									<table class=tableborder1 cellSpacing=0 cellPadding=0 width="100%" align=center>
										<tr>
											<td width="100%" align="center" colspan='8'>
												<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgReconciltran name=mfgReconciltran style="HEIGHT: 350px; LEFT: 0px; TOP: 0px; WIDTH: 950px" width=950 >
												<PARAM NAME="_ExtentX" VALUE="15055">
												<PARAM NAME="_ExtentY" VALUE="3757">
												<PARAM NAME="BackColor" VALUE="-2147483643">
												<PARAM NAME="ForeColor" VALUE="-2147483640">
												<PARAM NAME="Enabled" VALUE="-1">
												<PARAM NAME="BackStyle" VALUE="0">
												<PARAM NAME="BorderStyle" VALUE="1">
												<PARAM NAME="AllowBigSelection" VALUE="-1">
												<PARAM NAME="AllowUserResizing" VALUE="1">
												<PARAM NAME="Appearance" VALUE="1">
												<PARAM NAME="BackColorBkg" VALUE="8421504">
												<PARAM NAME="BackColorFixed" VALUE="-2147483633">
												<PARAM NAME="BackColorSel" VALUE="-2147483635">
												<PARAM NAME="CausesValidation" VALUE="-1">
												<PARAM NAME="Cols" VALUE="1">
												<PARAM NAME="ColWidth0" VALUE="1725">
												<PARAM NAME="DrawMode" VALUE="0">
												<PARAM NAME="FillStyle" VALUE="0">
												<PARAM NAME="FixedCols" VALUE="0">
												<PARAM NAME="FixedRows" VALUE="1">
												<PARAM NAME="FocusRect" VALUE="1">
												<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
												<PARAM NAME="ForeColorSel" VALUE="-2147483634">
												<PARAM NAME="FormatString" VALUE="^S No">
												<PARAM NAME="GridColor" VALUE="12632256">
												<PARAM NAME="GridColorFixed" VALUE="0">
												<PARAM NAME="GridLines" VALUE="1">
												<PARAM NAME="GridLinesFixed" VALUE="2">
												<PARAM NAME="GridLineWidth" VALUE="1">
												<PARAM NAME="MergeCells" VALUE="0">
												<PARAM NAME="MergeCol0" VALUE="0">
												<PARAM NAME="MergeRow0" VALUE="0">
												<PARAM NAME="MousePointer" VALUE="0">
												<PARAM NAME="OLEDropMode" VALUE="0">
												<PARAM NAME="PictureType" VALUE="0">
												<PARAM NAME="Redraw" VALUE="-1">
												<PARAM NAME="RightToLeft" VALUE="0">
												<PARAM NAME="RowHeightMin" VALUE="0">
												<PARAM NAME="Rows" VALUE="1">
												<PARAM NAME="ScrollBars" VALUE="3">
												<PARAM NAME="ScrollTrack" VALUE="0">
												<PARAM NAME="SelectionMode" VALUE="0">
												<PARAM NAME="TextStyle" VALUE="0">
												<PARAM NAME="TextStyleFixed" VALUE="0">
												<PARAM NAME="ToolTipText" VALUE="">
												<PARAM NAME="WhatsThisHelpID" VALUE="0">
												<PARAM NAME="WordWrap" VALUE="0">
												<PARAM NAME="ColAlignment0" VALUE="9">
												<PARAM NAME="ColData0" VALUE="0">
												<PARAM NAME="FixedAlignment0" VALUE="4">
												<PARAM NAME="FontWidth" VALUE="0">
												<PARAM NAME="hWnd" VALUE="0">
												<PARAM NAME="RowData0" VALUE="0">
												<PARAM NAME="RowHeight0" VALUE="240">
												<PARAM NAME="TextArray0" VALUE="S.No">
												<PARAM NAME="TextMatrix0" VALUE="S.No">
												<PARAM NAME="row" VALUE="">
												<PARAM NAME="col" VALUE="">
												<PARAM NAME="RowSel" VALUE="">
												<PARAM NAME="ColSel" VALUE="">
												<PARAM NAME="CellBackColor" VALUE="">
												<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</div>
                  
                  <!---- end Reconcilation report --->
                   
                     <!--- ATM Cash Position Report Start --->
                   
                   <div id="divAtmPosition" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="636" colspan="6" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="ATM Cash Position Report" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
							</tr>
							<tr>
								<td colspan = 10 >
									<table width="100%" align="Center" cellspacing="0" cellpadding="0" class="tableborder1">
										<tr class="bgcolor1">
											<td width="50%" align="center">&nbsp;Date&nbsp;:&nbsp;<input type="text" name="txtAtmDate" id="txtAtmDate" maxlength=10 onblur="datecheck(this)" size="11" class="txtautofill">&nbsp;(DDMMYYYY)</td>
											<td width="50%" align="left"><input type="button" name="btnAtmQuery" value="Query" onclick="AtmPosiTrans()" class="button"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td colspan = 10 width="100%">
									<table class=tableborder1 cellSpacing=0 cellPadding=0 width="100%" align=center>
										<tr>
											<td width="100%" align="center" colspan='8'>
												<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgAtmposi name=mfgAtmposi style="HEIGHT: 350px; LEFT: 0px; TOP: 0px; WIDTH: 950px" width=950 >
												<PARAM NAME="_ExtentX" VALUE="15055">
												<PARAM NAME="_ExtentY" VALUE="3757">
												<PARAM NAME="BackColor" VALUE="-2147483643">
												<PARAM NAME="ForeColor" VALUE="-2147483640">
												<PARAM NAME="Enabled" VALUE="-1">
												<PARAM NAME="BackStyle" VALUE="0">
												<PARAM NAME="BorderStyle" VALUE="1">
												<PARAM NAME="AllowBigSelection" VALUE="-1">
												<PARAM NAME="AllowUserResizing" VALUE="1">
												<PARAM NAME="Appearance" VALUE="1">
												<PARAM NAME="BackColorBkg" VALUE="8421504">
												<PARAM NAME="BackColorFixed" VALUE="-2147483633">
												<PARAM NAME="BackColorSel" VALUE="-2147483635">
												<PARAM NAME="CausesValidation" VALUE="-1">
												<PARAM NAME="Cols" VALUE="1">
												<PARAM NAME="ColWidth0" VALUE="1725">
												<PARAM NAME="DrawMode" VALUE="0">
												<PARAM NAME="FillStyle" VALUE="0">
												<PARAM NAME="FixedCols" VALUE="0">
												<PARAM NAME="FixedRows" VALUE="1">
												<PARAM NAME="FocusRect" VALUE="1">
												<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
												<PARAM NAME="ForeColorSel" VALUE="-2147483634">
												<PARAM NAME="FormatString" VALUE="^S No">
												<PARAM NAME="GridColor" VALUE="12632256">
												<PARAM NAME="GridColorFixed" VALUE="0">
												<PARAM NAME="GridLines" VALUE="1">
												<PARAM NAME="GridLinesFixed" VALUE="2">
												<PARAM NAME="GridLineWidth" VALUE="1">
												<PARAM NAME="MergeCells" VALUE="0">
												<PARAM NAME="MergeCol0" VALUE="0">
												<PARAM NAME="MergeRow0" VALUE="0">
												<PARAM NAME="MousePointer" VALUE="0">
												<PARAM NAME="OLEDropMode" VALUE="0">
												<PARAM NAME="PictureType" VALUE="0">
												<PARAM NAME="Redraw" VALUE="-1">
												<PARAM NAME="RightToLeft" VALUE="0">
												<PARAM NAME="RowHeightMin" VALUE="0">
												<PARAM NAME="Rows" VALUE="1">
												<PARAM NAME="ScrollBars" VALUE="3">
												<PARAM NAME="ScrollTrack" VALUE="0">
												<PARAM NAME="SelectionMode" VALUE="0">
												<PARAM NAME="TextStyle" VALUE="0">
												<PARAM NAME="TextStyleFixed" VALUE="0">
												<PARAM NAME="ToolTipText" VALUE="">
												<PARAM NAME="WhatsThisHelpID" VALUE="0">
												<PARAM NAME="WordWrap" VALUE="0">
												<PARAM NAME="ColAlignment0" VALUE="9">
												<PARAM NAME="ColData0" VALUE="0">
												<PARAM NAME="FixedAlignment0" VALUE="4">
												<PARAM NAME="FontWidth" VALUE="0">
												<PARAM NAME="hWnd" VALUE="0">
												<PARAM NAME="RowData0" VALUE="0">
												<PARAM NAME="RowHeight0" VALUE="240">
												<PARAM NAME="TextArray0" VALUE="S.No">
												<PARAM NAME="TextMatrix0" VALUE="S.No">
												<PARAM NAME="row" VALUE="">
												<PARAM NAME="col" VALUE="">
												<PARAM NAME="RowSel" VALUE="">
												<PARAM NAME="ColSel" VALUE="">
												<PARAM NAME="CellBackColor" VALUE="">
												<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</div>
                  
                  <!---- ATM Cash Position report end --->
                
                </td>
              </tr>
            </table>

            </center>
          </div>
              
                
                
          </td>
        </tr>
       
        <tr>
          <td width="100%" height="32"><center>
          <div align="center">
            <center>
     <table width="10%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 187px" class="tablebordermain">
            <tr>
              <td width="100%"><input name="cmdQuery" onclick="Report('report')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('excel')" type="button" value=" XLReport " class="button"><input type="button" value="Cancel" name="cmdCancel" class="button" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/atmwisereport.aspx"%>&quot;"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
            </tr>
          </table>

          
            <input type="hidden" name="hpr" value="<%=session("PRECISION")%>">
            <input type="hidden" name="hreport" ><input type=hidden name="postdata">
            <input type = "hidden" name = "hidcwaccno">
            </div>
          </center></center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="hmod" value="<%=session("module")%>"><input type="hidden" name="status">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
    <iframe id="iBatch" align=center frameBorder=0 frameSpacing=0  height="0" width="0" src="getDtls.aspx"></iframe>
	<iframe id="iGetDtls" align="center" style="display: block" frameborder="0" framespacing="0" height="0" width="0" src="getAtmDtls.aspx"></iframe>
                                              
      </td>
    </tr>
  </table>
</form>
</body>
</html>
