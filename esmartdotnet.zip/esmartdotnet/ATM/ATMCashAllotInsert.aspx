<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="ATMCashAllotInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.ATMCashAllotInsert" %>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<%userid=session("userid")%>
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<SCRIPT LANGUAGE="javascript">
			</SCRIPT>


<%	

	Dim kstr
	kstr=Request.QueryString("st")
	
	Dim objTrans
	Dim objmsg
	Dim Objfetchrec
	Dim CounterNo
	Dim strDataFlds
	Dim strDataVals
	Dim strATMFlds
	Dim strATMVls
	Dim BrCode,CurCode,GlCode,AcNo,GlName
	Dim appdate
	Dim RecAllot
	Dim RecATMCshPsMst
	Dim objfetchrecATM
	Dim strNartn	
	if kstr="ATMOpening" then
		Dim transarray(1,4)
		Dim ExitstedAcNo
				'------------------Assigning the  values------------------------
		BrCode=Request.Form("txtBrcode")
		CurCode=Request.Form("txtCrcode")
		GlCode=Request.Form("txtGlcode")
		AcNo=Request.Form("txtAccountno")
		GlName=Request.Form("txtGldesc")
		strNartn=Request.Form("txtNarration")
		appdate=session("applicationdate")
		atmid = Request.Form("txtATMid")
		
		'--------------------------------------------------------------------------
		RecAllot=server.CreateObject("adodb.recordset")
		RecATMCshPsMst=server.CreateObject("adodb.recordset")
		'''calling general query component
		Objfetchrec=server.CreateObject("queryrecordsets.fetchrecordsets")
		RecAllot=ObjFetchRec.singlerecordset("ATMMST", "nvl(ACCNO,0)", "branchcode='" & ucase(trim(BrCode)) & "' and GLCODE = '" & GlCode & "' and " & "ACCNO='" & AcNo & "'") 'nvl(ACCNO,0)
		
		if not RecAllot.EOF and not RecAllot.BOF then
			Response.Redirect ("ATMOpening.aspx?record=" & "A/C No. Already Exists")
		end if
		
		objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")
		
		if len(Brcode)<>0 and len(CurCode)>0 and  len(GlCode)>0 and  len(AcNo)>0 and  len(GlName)>0 then
			
			strDataFlds="BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, NAME, OPDATE," & _
				"OPBAL, EFFECTIVEDATE, NARRATION, APPROVEDDATE, CATEGORYCODE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, STATUS, SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, APPROVEDMACHINE,atmid,customerid" 

			strDataVals= "'" & ucase(trim(BrCode)) & "','" & ucase(trim(CurCode)) & "','" & trim(GlCode) & "','" & trim(AcNo) & "','" & ucase(trim(strNartn)) & "',to_date('" & appdate & "','dd-Mon-yyyy'),0,to_date('" & appdate & "','dd-Mon-yyyy'),'" & ucase(trim(GlName)) & "',to_date('" & appdate & "','dd-Mon-yyyy'),'01',to_date('" & appdate & "','dd-Mon-yyyy'),'" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','A','R',SYSDATE,'" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','"& ucase(trim(atmid)) &"','1111111111'"
								
		'----------- Calling the Component	--------------------
				
				'strDataVals="TOTAMOUNT-" & AmtAllot
				
				transarray(0,0)="I"	             'passing the TransactionType
				transarray(0,1)="ATMMST"         'passing the tablename
				transarray(0,2)=strDataFlds		 'passing the FieldNames	
				transarray(0,3)=strDataVals      'passing the Fieldvalues
				transarray(0,4)=""				 'passing the Condition
				
				
				strATMFlds = "BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CURBAL, CASHIERID,APPROVEDDATE, SANCTIONAMOUNT, APPLICATIONDATE, USERID, MACHINEID, STATUS, SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, APPROVEDMACHINE" 

			strATMVls = "'" & ucase(trim(BrCode)) & "','" & ucase(trim(CurCode)) & "','" & trim(GlCode) & "','" & trim(AcNo) & "',0,'" & ucase(trim(GlCode)) & "'," & "to_date('" & appdate & "','dd-Mon-yyyy'),0," & "to_date('" & appdate & "','dd-Mon-yyyy'),'" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','R',SYSDATE,'" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "'"
				
				transarray(1,0)="I"	             'passing the TransactionType
				transarray(1,1)="ATMBALANCE"     'passing the tablename
				transarray(1,2)=strATMFlds		 'passing the FieldNames	
				transarray(1,3)=strATMVls        'passing the Fieldvalues
				transarray(1,4)=""				 'passing the Condition
				
				
				objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			
			if objmsg="Transaction Sucessful." then
				
				'Response.Write (objmsg)
				Response.Redirect ("ATMOpening.aspx?record=" & objmsg)
			else
				Response.Redirect ("ATMOpening.aspx?record=" & objmsg)
			end if
			
			objmsg=nothing
		else
			Response.Redirect ("Fields should not be empty")
		end if
		
	elseif kstr="ATMModify" then
	
	Dim transarray(0,4)
	objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")

		BrCode=Request.Form("txtBrcode")
		GlCode=Request.Form("txtGlcode")
		AcNo=trim(Request.Form("txtAccountno"))
		strNartn=Request.Form("txtNarration")

	strcon = "accno = '"& AcNo &"' and glcode ='"& GlCode &"' and branchcode ='"& BrCode &"'"

		transarray(0,0)="U"	             'passing the TransactionType
		transarray(0,1)="ATMMST"         'passing the tablename
		transarray(0,2)="NAME"		 'passing the FieldNames	
		transarray(0,3)="'"& ucase(trim(strNartn)) &"'"     'passing the Fieldvalues
		transarray(0,4)=strcon			 'passing the Condition

	objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			
			if objmsg="Transaction Sucessful." then
				Response.Redirect ("ATMOpening.aspx?record=" & objmsg)
			else
				Response.Redirect ("ATMOpening.aspx?record=" & objmsg)
			end if
			
			objmsg=nothing
			
	else if kstr="atmcashallot" then
		Dim transarray(2,4), ArrTrans(1,4)
		'------------------Assigning the  values------------------------
	    
		BrCode=Request.Form("txtbranchcode")
		CurCode=Request.Form("txtcurrencycode")
		CashId=Request.Form("txtCashierId")
		CashIdDesc=Request.Form("txtCashierDesc")
		TotAvlBal=Request.Form("txtavtotal")
		AmtAllot=Request.Form("txtAmount")
		appdate=session("APPLICATIONDATE")
			
		objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")
			
	'---------------------------------------------------------------------
		Dim ATMTotAmt
		Dim Allotno
		dim strvalues
		
		RecAllot=server.CreateObject("adodb.recordset")
		RecATMCshPsMst=server.CreateObject("adodb.recordset")
		'''calling general query component
		Objfetchrec=server.CreateObject("queryrecordsets.fetchrecordsets")
		RecAllot=ObjFetchRec.singlerecordset("CASHALLOTMENTSTRN", _
										"nvl(max(ALLOTMENTNO),0)+1", _
										"branchcode='" & ucase(trim(BrCode)) & "' and " & _
										"cashierid='" & ucase(trim(CashId)) & "'")
		if not RecAllot.EOF and not RecAllot.BOF then
			Allotno=RecAllot(0).value
		end if
		CounterNo="A1"		

		objfetchrecATM=server.CreateObject("queryrecordsets.fetchrecordsets")
		RecATMCshPsMst=ObjFetchRec.singlerecordset("ATMCASHPOSMST", _
									"nvl(TOTAMOUNT,0)", _
									"branchcode='" & ucase(trim(BrCode)) & "' and " & _
									"cashierid='" & ucase(trim(CashId)) & "'")
		if not RecATMCshPsMst.EOF and not RecATMCshPsMst.BOF then
			ATMTotAmt=RecATMCshPsMst(0).value
		else
			ATMTotAmt=0
		end if		
		
		''''''-----------------------------------------------------------------------
		if len(Brcode)<>0 and len(CurCode)>0 and  len(CashId)>0 then

			kstr="BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,CASHIERID,ALLOTMENTNO,COUNTERNO," & _
					"ACCEPTEDDATE, ACCEPTEDUSERID,ALLOTEDUSERID,MACHINEID,ACCEPTEDMACHINEID,AMOUNTALLOTED,ALLOTMENTDATE," & _
					"STATUS,SYSTEMDATE,USERID" 

				strvalues="'" & ucase(trim(BrCode)) & "','" & ucase(trim(CurCode)) & "'," & _
						"to_date('" & appdate & "','dd-Mon-yyyy')," & _
						"'" & ucase(trim(CashId)) & "', " & Allotno & _
						",'" & CounterNo & "',to_date('" & appdate & "','dd-mm-yyyy'),'SYS','" & ucase(trim(session("USERID"))) & "'," & _
						"'" & ucase(trim(session("MACHINEID"))) & "','SYS'," & AmtAllot & "," & _
						"to_date('" & appdate & "','dd-mm-yyyy'),'A',SYSDATE,'" & session("userid") & "'"
								
		'----------- Calling the Component	--------------------
		
			transarray(0,0)="I"	
			transarray(0,1)="CASHALLOTMENTSTRN"
			transarray(0,2)=kstr
			transarray(0,3)=strvalues
			transarray(0,4)=""
			
			strDataVals="TOTAMOUNT-" & AmtAllot
			
			transarray(1,0)="U"	             'passing the TransactionType
			transarray(1,1)="CASHVAULTMST"   'passing the tablename
			transarray(1,2)="TOTAMOUNT"		 'passing the FieldNames	
			transarray(1,3)=strDataVals      'passing the Fieldvalues
											'passing the Condition
			transarray(1,4)="BRANCHCODE='" & ucase(trim(BrCode)) & "' and CURRENCYCODE='" & ucase(trim(CurCode)) & "'"
			
			if ATMTotAmt=0 then
				
				strATMFlds="BRANCHCODE, CURRENCYCODE, CASHIERID, COUNTERNO, TOTAMOUNT, ALLOTMENTNO, APPLICATIONDATE, USERID, MACHINEID, SYSTEMDATE"
				
				strATMVls="'" & ucase(trim(BrCode)) & "','" & ucase(trim(CurCode)) & "','" & ucase(trim(CashId)) & "','" & CounterNo & "'," & AmtAllot & "," & Allotno & ",to_date('" & appdate & "','dd-mm-yyyy'),'" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "',SYSDATE"
				
				transarray(2,0)="I"	
				transarray(2,1)="ATMCASHPOSMST"
				transarray(2,2)=strATMFlds
				transarray(2,3)=strATMVls
				transarray(2,4)=""
			else
				strATMVls= "TOTAMOUNT+" & AmtAllot
				
				transarray(2,0)="U"	             'passing the TransactionType
				transarray(2,1)="ATMCASHPOSMST"   'passing the tablename
				transarray(2,2)="TOTAMOUNT"		 'passing the FieldNames	
				transarray(2,3)=strATMVls      'passing the Fieldvalues
											'passing the Condition
				transarray(2,4)="BRANCHCODE='" & ucase(trim(BrCode)) & "' and CURRENCYCODE='" & ucase(trim(CurCode)) & "'"
				
			end if
			
			'' inserting into GENTRANSLOG --code written by Monica on 13-Mar-2012
			
			dim ArrStr(100,60), ArrDenom(100,60)
			dim batchNo,tranNos
			dim strCshGlcode, strATMGlcode, strCshInsVals, strATMInsVals
			dim strRow, strCol
			dim strbatchno, strtranno, strtranno1
			
			objfetchrecATM=server.CreateObject("queryrecordsets.fetchrecordsets")
		RecATMCshPsMst=ObjFetchRec.singlerecordset("GENGLMASTMST", _
									"nvl(glcode,0)", _
									"moduleid='CASH' and " & _
									"glcode not in ('TCASH','SCASH')")
		
		if not RecATMCshPsMst.EOF and not RecATMCshPsMst.BOF then
			strCshGlcode=RecATMCshPsMst(0).value
		else
			strCshGlcode=0
		end if
		
		objfetchrecATM=nothing
		
		RecATMCshPsMst=ObjFetchRec.singlerecordset("GENGLMASTMST", _
									"nvl(glcode,0)", _
									"moduleid='ATM' and " & _
									"glcode not in ('TCASH','SCASH')")
		
		if not RecATMCshPsMst.EOF and not RecATMCshPsMst.BOF then
			strATMGlcode=RecATMCshPsMst(0).value
		else
			strATMGlcode=0
		end if
		
		RecATMCshPsMst=nothing
				
		ObjBatchNo=Server.CreateObject("GeneralTranQueries.TransactionQueries")
							
		batchNo=""
		tranNos=""
		strbatchno=""
		strtranno=""
		strtranno1=""
		
		strbatchno=ObjBatchNo.GetBatchno(cstr(brCode))
		strtranno=ObjBatchNo.GetTranNo(cstr(brCode))
		strtranno1=ObjBatchNo.GetTranNo(cstr(brCode))
			
			dim strvals1,strvals,strfldnms
			
			strfldnms="BATCHNO,TRANNO,GLCODE,GLDESC,ACCNO,NAME,AMOUNT,ENTEREDTIMEBAL,APPLICATIONDATE,CUSTOMERID,MODEOFTRAN,MODEOFTRANDESC,ABBAPPLICATIONDATE,TRANSTATUS,CURRENCYCODE,USERID,MACHINEID,MODULEID,BRANCHCODE,TOKENNO,REMARKS,CHQSERIESNO,CHQNO,CHQDATE,CHQFVG,SYSTEMGENERATEDYN,MODULEDESC,EFFECTIVEDATE,CLGRATETYPE,RATE,FCURRENCYCODE,FAMOUNT,LINKMODULEID,LINKMODULEDESC,LINKGLCODE,LINKGLDESC,LINKACCTYPE,LINKACCNO,LINKACCNAME,SERVICEID,SERVICEDESC,RESPONDINGBRANCHCODE,RESPONDINGBRANCHDESC,RESPONDINGSECTIONCODE,RESPONDINGSECTIONDESC,ABBBRANCHCODE,BRANCHNARRATION,DISPOSALBATCHNO,DISPOSALTRANNO,ACCOUNTCHECKYN,EXCEPTIONYN,EXCEPTIONCODES,respondingbankcode,respondingbankdesc,STANDINSTRYN,COUNTERNO,CASHIERID,SCROLLNO,RATEREFCODE,RATEREFDESC,C61,C62,C63,C64,C65,C66,C67,C68,C69,C70,C71,C72,C73,C74,C75,C76,C77,C78,C79,C80,C81,C82,C83,C84,C85,C86,C87,C88,C89,C90,C91,C92,C93,C94,C95,C96,C97,C98,C99,C100,abbyn"
      
   
   strvals= strbatchno & "," & strtranno 	& ",'" & strCshGlcode & "','CASH',' ',' '," & (AmtAllot) & "," & TotAvlBal & ",to_date('" & appdate & "','dd-mm-yyyy'),' ',2,' ',null,'P','INR','" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','CASH','" & ucase(trim(BrCode)) & "',null,' ',' ',' ',to_date('" & appdate & "','dd-mm-yyyy'),'','Y','CASH',to_date('" & appdate & "','dd-mm-yyyy'),' ',null,' ',null,'ATM',' ','" & strATMGlcode  &"',' ',' ','" & ucase(trim(CashId)) & "','" & ucase(trim(CashIdDesc)) & "',1,'TRANSACTION',' ',' ',' ',' ',' ',' ',null,null,'N','N',' ',' ',' ','N',null,'" & ucase(trim(session("USERID"))) & "',null,' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','N'" 

		ArrTrans(0,0)="I"
		ArrTrans(0,1)="GENTEMPTRANSLOG"  'passing the table name
		ArrTrans(0,2)=strfldnms		     'passing columns
		ArrTrans(0,3)=strvals		     'passing values
		ArrTrans(0,4)=""	
		
		strvals1=  strbatchno & "," & strtranno1 	& ",'" & strATMGlcode & "','ATM','" & ucase(trim(CashId)) & "',' '," & (-AmtAllot) & "," & ATMTotAmt & ",to_date('" & appdate & "','dd-mm-yyyy'),' ',1,' ',null,'P','INR','" & ucase(trim(session("USERID"))) & "','" & ucase(trim(session("MACHINEID"))) & "','ATM','" & ucase(trim(BrCode)) & "',null,' ',' ',' ',to_date('" & appdate & "','dd-mm-yyyy'),'','Y','ATM',to_date('" & appdate & "','dd-mm-yyyy'),' ',null,' ',null,' ',' ',' ',' ',' ',' ',' ',1,'TRANSACTION',' ',' ',' ',' ',' ',' ',null,null,'N','N',' ',' ',' ','N',null,'" & ucase(trim(session("USERID"))) & "',null,' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','N'" 
		
		ArrTrans(1,0)="I"
		ArrTrans(1,1)="GENTEMPTRANSLOG"  'passing the table name
		ArrTrans(1,2)=strfldnms		     'passing columns
		ArrTrans(1,3)=strvals1		     'passing values
		ArrTrans(1,4)=""	
			
		objmsg= ObjTrans.DataTransactions(ArrTrans,,,,,"N")
		
		if objmsg="Transaction Sucessful." then
		else
			Response.Redirect ("atmcashallot.aspx?record=" & objmsg)
		end if
			
			strCshInsVals= strbatchno & "~" & strtranno	& "~" & strCshGlcode & "~CASH~~~" & (AmtAllot) & "~" & TotAvlBal & "~" & appdate & "~~2~~~A~INR~" & ucase(trim(session("USERID"))) & "~" & ucase(trim(session("MACHINEID"))) & "~CASH~" & ucase(trim(BrCode)) & "~~~~~" & appdate & "~~Y~CASH~" & appdate & "~~~~~~~~~~~~1~TRANSACTION~~~~~~~~~N~N~~~~N~~" & ucase(trim(session("USERID"))) & "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~N~|" & strbatchno & "~" & strtranno1	& "~" & strATMGlcode & "~ATM~" & ucase(trim(CashId)) & "~~" & (-AmtAllot) & "~" & ATMTotAmt & "~" & appdate & "~~1~~~A~INR~" & ucase(trim(session("USERID"))) & "~" & ucase(trim(session("MACHINEID"))) & "~ATM~" & ucase(trim(BrCode)) & "~~~~~" & appdate & "~~Y~ATM~" & appdate & "~~~~~~~~~~~~1~TRANSACTION~~~~~~~~~N~N~~~~N~~" & ucase(trim(session("USERID"))) & "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~N~|" 

			    strRow=Split(strCshInsVals,"|")
	    
    		for i=0 to UBound(strRow)-1
				strCol=Split(strRow(i),"~")
				if i=0 then 
		 			Redim ArrStr(UBound(strRow),UBound(strCol))
				end if
				for J=0 to UBound(strCol)-1
					ArrStr(i,j)=strCol(j)	
				next	
			next   
															
			Obj=Server.CreateObject("TransferTransactions.transaction")
			kstr =obj.TranInsert(ArrStr,ArrDenom)
			
			if Left(kstr,8)="Batch No" and Right(kstr,9)="Completed" then
			else
				obj=nothing
				Response.Redirect ("atmcashallot.aspx?record=" & kstr)
			end if
			
		    kstr = replace(kstr,chr(10)," ")
		    kstr = replace(kstr,chr(13)," ")
		    obj=nothing
		     
		objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
		
		if objmsg="Transaction Sucessful." then
			Response.Redirect ("atmcashallot.aspx?record=" & objmsg)
		else
			Response.Redirect ("atmcashallot.aspx?record=" & objmsg)
		end if
		
		objmsg=nothing
		'obj=server.CreateObject("CashTransaction.Transactions")	
			
		'response.write("<br><br>'" & cstr(CurCode) & "','" & cstr(BrCode) & "'")
		'response.write("<br><br>'" & cstr(CashId) & "','" & cstr(CntCode) & "'")
		'response.end
		
		'strmsg=obj.CashTRNInserts("CASHALLOTMENTSTRN",cstr(kstr), _
				'cstr(strvalues),cstr(CurCode),Arrtrans)  
		'strmsg=obj.CashTRNInserts("CASHALLOTMENTSTRN",cstr(kstr), _
				'cstr(strvalues),cstr(CurCode),Arrtrans,cstr(BrCode),cstr(session("userid")), _
				'cstr(session("machineid")),cstr(session("applicationdate")),"O", _
				'ucase(cstr(CashId)),cstr(CntCode))  
		'obj=nothing
		'''strmsg = replace(strmsg,chr(10)," ") 
		'''strmsg = replace(strmsg,chr(13)," ")
		'Response.Write (strmsg)
		'strmsg= strmsg '& " -:" & session("APPLICATIONDATE")
		
		'strmsg= strmsg & ". Allotment No is " & Allotno  
	'-------------------------------------------------------
		
		'Response.Redirect ("atmcashallot.aspx?record=" & strmsg)
		else
			Response.Redirect ("Fields should not be empty")
		end if
	else
		Response.Redirect ("Fields should not be empty")
	end if

%>

<title></title>
	</head>
	<body>
		<form name="frmacc">
			<input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>
		</form>
	</body>
</html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
