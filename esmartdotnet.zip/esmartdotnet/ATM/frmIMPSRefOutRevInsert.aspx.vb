Public Class frmIMPSRefOutRevInsert
    Inherits System.Web.UI.Page
    Dim StrErrorMessage As String
    Dim strEODProgress As String
    Dim strInvAccNum As String
    Dim strDupTrnsCode As String
    Dim strExitsRefNum As String
    Dim strDupRefServTrnsCode As String

    Dim strFinalMessage As String
    Dim strResult As String
    Dim strRequest As String
    Dim strTranStatus As String
    Dim strMobileNo As String

    Dim sQuery As String
    Dim sqlStr As String
    Dim strBenName As String
    Dim strMTIReq As String
    Dim dblbalAmt As Double
    Dim strRespStaCd As String
    Dim lngbatchno As Long

    Dim pRefNum As String
    Dim strServiceid As String
    Dim strRemarksOutWrd1 As String

    Public AppDate As Date
    Public UserId As String
    Public MachineId As String

    Dim strDelChanConID As String
    Dim strProcedureName As String
    Dim strBrId As String
    Dim strAccNo As String
    Dim strGlcd As String
    Dim strACTP As String

    Dim ObjDbConn As New DatabaseConnection.cDBConnection
    Dim objCmd As OracleClient.OracleCommand
    Dim objconn As New OracleClient.OracleConnection
    Dim objTransaction As OracleClient.OracleTransaction

    Dim errmsg As String
    Dim o_errmsg1 As String


    Dim strMTI As String
    Dim strMTIRes As String
    Dim strBitMap_1 As String
    Dim strBrBen_2_1 As String
    Dim strBrBen_2_2 As String
    Dim strBenAccNo_103_1 As String
    Dim strBenAccNo_103_2 As String
    Dim strBenIFSCCode_127_1 As String
    Dim strBenIFSCCode_127_2 As String
    Dim strProCd_3 As String '' processing code
    Dim strTrnAmt_4 As String ''transaction amount
    Dim strATMID As String
    Dim strSysTraAudNum_11 As String ''System Trace Audit Number
    Dim strLocTranDtTime_12 As String ''Local Transaction Date and Time
    Dim strCapDt_17 As String '' Capture Date
    Dim strFuncCd_24 As String ''Function Code
    Dim strAcqInsIdenCd_32_1 As String ''Acquiring Institution Identification Code
    Dim strAcqInsIdenCd_32_2 As String ''Acquiring Institution Identification Code
    Dim strExtPriAccNum_34_1 As String ''Extended Primary Account Number
    Dim strExtPriAccNum_34_2 As String ''Extended Primary Account Number
    Dim strTrack2Data_35_1 As String '' Track 2 Data
    Dim strTrack2Data_35_2 As String '' Track 2 Data
    Dim strRefNum_37 As String ''Reference Number
    Dim strTRANSREFNO, StrREMITTERNBIN, strSESSIONBRCODE As String
    Dim strResponseCode_39 As String '' Response Code
    Dim strRespCode1 As String
    Dim strCardAccTerID_41 As String ''Card Acceptor Terminal Id
    Dim strCardAccIden_42 As String  ''Card Acceptor Identification
    Dim strCardAccTermName_43_1 As String  ''Card Acceptor Identification
    Dim strCardAccTermName_43_2 As String  ''Card Acceptor Identification

    Dim strchrgsAmt_46_1 As String  '' charges / transaction amount
    Dim strchrgsAmt_46_2 As String  '' charges / transaction amount


    Dim strTranCurrCd_49 As String  ''Transaction Currency Code
    Dim strField56ForRev_56_1 As String  ''Field 56 For Reversal
    Dim strField56ForRev_56_2 As String  ''Field 56 For Reversal
    Dim strTrnsData_59_1 As String   '' Transport Data
    Dim strTrnsData_59_2 As String  '' Transport Data

    Dim strNetwrkMngtInfCode_70 As String   ''Network Management Information Code

    Dim strTransDest_93_1 As String   '' Transaction Destination  Institution Identification Code 
    Dim strTransDest_93_2 As String   '' Transaction Destination  Institution Identification Code 

    Dim strTransOrigin_94_1 As String   '' Transaction Originator  Institution Identification Code 
    Dim strTransOrigin_94_2 As String   '' Transaction Originator  Institution Identification Code 

    Dim strRepAmtParRev_95 As String  ''Replacement Amount(Partial Reversal)
    Dim strAccIden_102 As String
    Dim strAccIden_102_1 As String ''Account Identification 1
    Dim strAccIden_102_2 As String ''Account Identification 2
    Dim strAccIden_103 As String ''Account Identification 1
    Dim strDelChanConID_123_1 As String ''Delivery Channel Controller ID
    Dim strDelChanConID_123_2 As String ''Delivery Channel Controller ID
    Dim strTempDelChanConID_123_2 As String ''Temp Delivery Channel Controller ID
    Dim strTempTermType_124_2 As String '' Temp Terminal Type

    Dim strTermType_124_1 As String ''Terminal Type
    Dim strTermType_124_2 As String ''Terminal Type

    Dim strResrvPrvUse_125_1 As String ''Reserved For Private Use
    Dim strResrvPrvUse_125_2 As String ''Reserved For Private Use

    Dim strPrivFld_126_1 As String '' Private Field
    Dim strPrivFld_126_2 As String ''Private Field

    Dim strServ As String
    Dim recnfts As OracleClient.OracleDataReader

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region




    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strRefno As String

        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbConn.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Sub
            End If
        End If
        strRefno = ""

        strServ = Request.Form("hidServ")

        If strServ = "IMPSBRCHAN" Then
            strRefno = Request.Form("txttransrefcode")
            strRefno = strRefno.Trim()
            IMPSOutWardReversal(strRefno)
        ElseIf strServ = "ATM" Then
            strRefno = Request.Form("txtrefcode")
            strRefno = strRefno.Trim()
            ATMOutwardReversal(strRefno)
        ElseIf strServ = "IMPSMOB" Then
            strRefno = Request.Form("txtrefcode")
            strRefno = strRefno.Trim()
            IMPSMOBOutWardReversal(strRefno)
        End If
    End Sub

    Private Sub IMPSMOBOutWardReversal(ByVal strRefno As String)
        Try

            sqlStr = "SELECT BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, BATCHNO, AMOUNT, REFNUM, ATMLOCATION,ATMID, SERVICEID, CARDNO, SYSTRAAUDNUM, MOBILENO, AQUIRERID FROM impslogdtls i WHERE  atmlocation = 'P2AO MOB' AND serviceid = 'OUTWRD' AND status = 'Y' AND  refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE SERVICEID ='OUTWRR' AND refnum = i.refnum) and refnum = '" & strRefno & "' order by to_number(refnum)"

            objCmd = New OracleClient.OracleCommand(sqlStr, objconn)

            recnfts = objCmd.ExecuteReader

            If recnfts.HasRows = True Then
                recnfts.Read()
                strBrId = ""
                strAccNo = ""
                strGlcd = ""
                strACTP = ""
                strTrnAmt_4 = ""
                strMobileNo = ""
                strTrack2Data_35_2 = ""
                strCardAccTerID_41 = ""
                strRefNum_37 = ""

                strBrId = IIf(IsDBNull(recnfts!BRANCHCODE), "", recnfts!BRANCHCODE)
                strAccNo = IIf(IsDBNull(recnfts!ACCNO), "", recnfts!ACCNO)
                strGlcd = IIf(IsDBNull(recnfts!GLCODE), "", recnfts!GLCODE)
                GetMODID(strGlcd, strACTP)
                If strACTP = "" Then
                    Throw New Exception("Modid Not Present For The GLcode")
                End If
                strTrnAmt_4 = IIf(IsDBNull(recnfts!AMOUNT), "", recnfts!AMOUNT)
                strMobileNo = IIf(IsDBNull(recnfts!MOBILENO), "", recnfts!MOBILENO)
                strTrack2Data_35_2 = IIf(IsDBNull(recnfts!ATMLOCATION), "", recnfts!ATMLOCATION)
                strCardAccTerID_41 = IIf(IsDBNull(recnfts!ATMID), "", recnfts!ATMID)
                strRefNum_37 = IIf(IsDBNull(recnfts!REFNUM), "", recnfts!REFNUM)

                AppDate = Session("applicationdate")
                dblbalAmt = 0
                strRespStaCd = ""
                lngbatchno = 0
                strRemarksOutWrd1 = ""

                strServiceid = ""
                strServiceid = "OUTWRR"

                GetIMPSMOBOutwardReversal(strBrId, strAccNo, strGlcd, strACTP, CDbl(CDbl(strTrnAmt_4) * 100), strMobileNo, strTrack2Data_35_2, strCardAccTerID_41, strRefNum_37, strProCd_3, strServiceid, dblbalAmt, strRespStaCd, lngbatchno, strRemarksOutWrd1)

                strFinalMessage = ""
                If strRespStaCd = "000" Or strRespStaCd = "00" Then
                    strFinalMessage = "Transaction Completed Batchno  " & lngbatchno & " Reference No " & strRefNum_37
                Else
                    strFinalMessage = strRemarksOutWrd1
                    GoTo End1
                End If

                objTransaction = objconn.BeginTransaction()

                '' inserting record in impsbrchanfundstrnsdtls for outward reversal transaction

                strResult = InsertToIMPSLogDtls(strRequest, strBrId, strGlcd, strAccNo, strRespStaCd, CDbl(strTrnAmt_4), strRefNum_37, strCardAccTerID_41, strTrack2Data_35_2, strServiceid, lngbatchno, strRemarksOutWrd1, 0, "", "", "", "", strMobileNo, AppDate, "", "")

                If strResult = "Fail" Then
                    strFinalMessage = strFinalMessage & " InsertToIMPSLogDtls " & strResult
                    objTransaction.Rollback()
                    GoTo End1
                End If

                objTransaction.Commit()
End1:
            End If
            recnfts.Close()
            recnfts = Nothing
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & strFinalMessage, False)
            Exit Sub
        Catch ex As Exception
            objTransaction.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & o_errmsg1, False)
        End Try
    End Sub
    Private Sub ATMOutwardReversal(ByVal strRefno As String)
        Dim dblbalance1 As Double
        Dim strRespCd_39, lngbatchno1, strRemarksoutwrd, strProcCode1, strProcCode, pstrRevReqMode As String
        Dim strResCd As String
        Dim strBalance, strRemarks, strcardno, strsystraaudnum As String
        Dim strchrgsamt, strDELCHANCONID As String
        Try
            sqlStr = "SELECT y.refnum,y.applicationdate,y.branchcode,y.glcode,y.accno,y.amount,'' , x.accno benaccno,x.name,y.batchno,y.serviceid,y.ATMID, y.ATMLOCATION,y.CARDNO, y.SYSTRAAUDNUM ,x.chqfvg DELCHANCONID FROM (SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE,chqfvg FROM atmtran a where modeoftran = 2 union all SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE,chqfvg FROM atmtranday a where modeoftran = 2) x,(SELECT refnum,applicationdate,branchcode, glcode,accno ,Amount,serviceid,BATCHNO,ATMID, ATMLOCATION,CARDNO, SYSTRAAUDNUM  FROM atmlogdtls WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y') y  WHERE x.RATEREFCODE = y.refnum AND x.RESPONDINGBANKCODE = y.serviceid AND x.batchno = y.batchno and y.refnum = '" & strRefno & "'"

            objCmd = New OracleClient.OracleCommand(sqlStr, objconn)
            recnfts = objCmd.ExecuteReader

            If recnfts.HasRows = True Then
                recnfts.Read()
                strBrId = IIf(IsDBNull(recnfts!branchcode), "", recnfts!branchcode)
                strGlcd = IIf(IsDBNull(recnfts!glcode), "", recnfts!glcode)
                strAccNo = IIf(IsDBNull(recnfts!accno), "", recnfts!accno)
                strProcCode1 = IIf(IsDBNull(recnfts!serviceid), "", recnfts!serviceid)
          
                strTrnAmt_4 = IIf(IsDBNull(recnfts!amount), "", recnfts!amount)
                strCardAccTerID_41 = IIf(IsDBNull(recnfts!ATMID), "", recnfts!ATMID)
                strCardAccTermName_43_2 = IIf(IsDBNull(recnfts!ATMLOCATION), "", recnfts!ATMLOCATION)
                strcardno = IIf(IsDBNull(recnfts!CARDNO), "", recnfts!CARDNO)
                strsystraaudnum = IIf(IsDBNull(recnfts!SYSTRAAUDNUM), "", recnfts!SYSTRAAUDNUM)
                ''    strchrgsamt = IIf(IsDBNull(recnfts!CHRGSAMT), "", recnfts!CHRGSAMT)
                strchrgsamt = "0"

                strDELCHANCONID = IIf(IsDBNull(recnfts!DELCHANCONID), "", recnfts!DELCHANCONID)

                If IsDBNull(recnfts!DELCHANCONID) = True Then
                    If strProcCode1 = "NWDRRQ" Or strProcCode1 = "FWDRRQ" Then
                        strDELCHANCONID = "ATM"
                    ElseIf strProcCode1 = "CHPREQ" Or strProcCode1 = "POSREQ" Then
                        strDELCHANCONID = "POS"
                    End If
                Else
                        strDELCHANCONID = recnfts!DELCHANCONID
                    End If
                    GetMODID(strGlcd, strACTP)
                    GetMode(strProcCode1, pstrRevReqMode)
                    GetServiceCd(strProcCode1, strProcCode)
                    strEODProgress = GetEODProgress(strBrId)

                    If strEODProgress = "" Then

                        '' check For Invalid Account Number
                        strInvAccNum = GetATMCheckInvAccNum(strBrId, strGlcd, strAccNo)
                        If strInvAccNum = "" Then
                            '' Check For Duplicate Transactions
                            strDupTrnsCode = GetATMCodeCheckDupRefNumRevParRev(strRefno, strProcCode)

                            '' check for Exits
                            strExitsRefNum = GetATMCodeCheckExitsRefNum(strRefno, strProcCode)
                            If strDupTrnsCode = "" And strExitsRefNum = "" Then
                                '    If objconn.State <> ConnectionState.Open Then
                                '      objconn = objCon.GetDbConnection(errMsg)
                                'End If
                                strDupRefServTrnsCode = GetATMCodeCheckDupRefNumServTran(strRefno, strProcCode)
                                If strDupRefServTrnsCode = "" Then

                                    If objconn.State = ConnectionState.Closed Then
                                        '   MsgBox("DataBase Connection Failed", MsgBoxStyle.Critical, "Esmart Utilities")
                                        '  Exit Function
                                    Else

                                        If CDbl(strTrnAmt_4) = 0 Then
                                            strBalance = "0"
                                            strResCd = "904"
                                            lngbatchno = "0"
                                        Else

                                            strProcedureName = "Proc_Debitreversal_TrnP"
                                            objCmd = New OracleClient.OracleCommand(strProcedureName, objconn)
                                            objCmd.CommandType = CommandType.StoredProcedure

                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("pMode", OracleClient.OracleType.VarChar, 20)).Value = pstrRevReqMode
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("BrId", OracleClient.OracleType.VarChar, 20)).Value = strBrId
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("AcNo", OracleClient.OracleType.VarChar, 20)).Value = strAccNo
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("pGlCode", OracleClient.OracleType.VarChar, 20)).Value = strGlcd
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("AcTp", OracleClient.OracleType.VarChar, 20)).Value = strACTP
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("WthDrAmt", OracleClient.OracleType.VarChar, 20)).Value = CDbl(strTrnAmt_4)  'CInt(strMsgDtls(42))
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("ChrgsAmt", OracleClient.OracleType.VarChar, 20)).Value = CDbl(strchrgsamt) '' chrgs Amt
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("ATMId", OracleClient.OracleType.VarChar, 20)).Value = Trim(strCardAccTerID_41)
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("ATMName", OracleClient.OracleType.VarChar, 40)).Value = GetFreeFrmSplChars(Trim(strCardAccTermName_43_2))

                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("DelChanConID", OracleClient.OracleType.VarChar, 3)).Value = Trim(strDELCHANCONID) '' Terminal Type -- (Delivery Channel Controller ID)
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("referencenum", OracleClient.OracleType.VarChar, 12)).Value = Trim(strRefno)  '' reference number 
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("pserviceid", OracleClient.OracleType.VarChar, 10)).Value = Trim(strProcCode)  ''service id / proccode
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("strBalAfterOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("strResCdOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                                            objCmd.Parameters.Add(New OracleClient.OracleParameter("lngBatchNoOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output

                                            objCmd.ExecuteNonQuery()

                                            strBalance = IIf(IsDBNull(objCmd.Parameters("strBalAfterOUT").Value), 0, objCmd.Parameters("strBalAfterOUT").Value)
                                            strResCd = IIf(IsDBNull(objCmd.Parameters("strResCdOUT").Value), "", objCmd.Parameters("strResCdOUT").Value)
                                            lngbatchno = IIf(IsDBNull(objCmd.Parameters("lngBatchNoOUT").Value), 0, objCmd.Parameters("lngBatchNoOUT").Value)
                                            ' dblBalance = CDbl(strBalance)

                                            objCmd.Dispose()
                                            objCmd = Nothing


                                        End If
                                        'If objconn.State = ConnectionState.Open Then
                                        '    objconn.Close()
                                        'End If
                                    End If
                                End If '' duplicate reference and serviceid 
                            End If ''strDupTrnsCode = ""
                        End If '' invalid account number
                    End If '' EOD in Progress



                    If strEODProgress = "" Then
                        If strInvAccNum = "" Then
                            If strExitsRefNum = "" Then
                                If strDupTrnsCode = "" Then
                                    If strDupRefServTrnsCode = "" Then
                                        If Trim(strResCd) = "000" Then
                                            strRespCd_39 = "000"  ''  transaction approved
                                        Else
                                            If Trim(strResCd) = "" Then
                                                strRespCd_39 = "912"  '' Processing host cannot be reached
                                            Else
                                                strRespCd_39 = Trim(strResCd)
                                            End If
                                        End If
                                    Else
                                        strRespCd_39 = Trim(strDupRefServTrnsCode) '' Check For Duplicate reference and serviceid Transactions
                                    End If
                                Else
                                    strRespCd_39 = Trim(strDupTrnsCode) '' Check For Duplicate Transactions
                                End If
                            Else
                                strRespCd_39 = Trim(strExitsRefNum) '' Check For Exists Ref Num
                            End If
                        Else
                            strRespCd_39 = strInvAccNum '' Invalid Account Number
                        End If
                    Else
                        strRespCd_39 = strEODProgress '' EOD in Progress
                    End If

                    strRemarks = GetRemarks(strRespCd_39)  '' Remarks 

                    If strRespCd_39 = "000" Then
                        strRemarks = "Reversal  Request Successful With Batchno " & lngbatchno & " And Reference No " & strRefno
                    ElseIf strRespCd_39 = "119" Then
                    strRemarks = strRemarks & " , There Is No With Drawal With This Reference Number " & strRefno
                ElseIf strRespCd_39 = "913" Then
                    strRemarks = strRemarks & " , Outward Reversal Already Executed For This Ref No " & strRefno
                Else
                    strRemarks = strRemarks & " , Error For This Ref No " & strRefno
                End If

                ''     If strRespCd_39 = "000" Then

                InsertToATMLogDtls(strBrId, strGlcd, strAccNo, strRefno, strCardAccTerID_41, strCardAccTermName_43_2, Now, strProcCode, strcardno, strsystraaudnum, lngbatchno, strRespCd_39, CDbl(strTrnAmt_4), strRemarks, StrErrorMessage)

                '' End If
            End If
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & strRemarks, False)
        Catch ex As Exception
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & o_errmsg1, False)
        End Try
    End Sub

    Private Sub IMPSOutWardReversal(ByVal strRefno As String)
        Try


            sqlStr = "select  i.BRANCHCODE, i.CURRENCYCODE,i.MODULEID, i.GLCODE, i.ACCNO, i.TRNSAMOUNT4,m.mobileno, m.ATMID,m.SYSTRAAUDNUM,  m.AQUIRERID, m.REMITTERNBIN , m.refnum,m.SESSIONBRCODE from impsbrchanfundstrnsdtls i,  impslogdtls m  where i.TRANSREFNO = m.refnum and  m.refnum = '" & strRefno & "' and  m.serviceid = 'OUTWRD'"
            objCmd = New OracleClient.OracleCommand(sqlStr, objconn)

            recnfts = objCmd.ExecuteReader

            If recnfts.HasRows = True Then
                recnfts.Read()


                SetClear()
                strTRANSREFNO = "" : StrREMITTERNBIN = "" : strSESSIONBRCODE = ""

                strBrId = IIf(IsDBNull(recnfts!BRANCHCODE), "", recnfts!BRANCHCODE)
                strAccNo = IIf(IsDBNull(recnfts!ACCNO), "", recnfts!ACCNO)
                strGlcd = IIf(IsDBNull(recnfts!GLCODE), "", recnfts!GLCODE)
                strACTP = IIf(IsDBNull(recnfts!MODULEID), "", recnfts!MODULEID)
                strTrnAmt_4 = IIf(IsDBNull(recnfts!TRNSAMOUNT4), "", recnfts!TRNSAMOUNT4)
                strSysTraAudNum_11 = IIf(IsDBNull(recnfts!SYSTRAAUDNUM), "", recnfts!SYSTRAAUDNUM)
                strATMID = IIf(IsDBNull(recnfts!ATMID), "", recnfts!ATMID)
                strAcqInsIdenCd_32_2 = IIf(IsDBNull(recnfts!AQUIRERID), "", recnfts!AQUIRERID)

                strMobileNo = IIf(IsDBNull(recnfts!mobileno), "", recnfts!mobileno)
              
                strTRANSREFNO = IIf(IsDBNull(recnfts!refnum), "", recnfts!refnum)
                StrREMITTERNBIN = IIf(IsDBNull(recnfts!REMITTERNBIN), "", recnfts!REMITTERNBIN)
                strSESSIONBRCODE = IIf(IsDBNull(recnfts!SESSIONBRCODE), "", recnfts!SESSIONBRCODE)
                strServiceid = ""
                strServiceid = "OUTWRR"
                dblbalAmt = 0
                strRespStaCd = ""
                lngbatchno = 0
                strRemarksOutWrd1 = ""
                strTranStatus = "A"

                AppDate = Session("applicationdate")

                GetIMPSBrnChanOutwardReversal(strBrId, strAccNo, strGlcd, strACTP, strTrnAmt_4, strMobileNo, strTrack2Data_35_2, strAcqInsIdenCd_32_2, strATMID, strTRANSREFNO, strServiceid, strSysTraAudNum_11, StrREMITTERNBIN, dblbalAmt, strRespStaCd, lngbatchno, strRemarksOutWrd1)

                strFinalMessage = ""
                If strRespStaCd = "000" Or strRespStaCd = "00" Then
                    strFinalMessage = "Transaction Completed Batchno  " & lngbatchno & " Reference No " & strTRANSREFNO
                Else
                    strFinalMessage = strRemarksOutWrd1
                    GoTo End1
                End If

                objTransaction = objconn.BeginTransaction()


                '' insert record into impslogdtls for outward reversal transaction

                strResult = InsertToIMPSLogDtls(strRequest, strBrId, strGlcd, strAccNo, strRespStaCd, CDbl((CDbl(strTrnAmt_4) / 100)), strTRANSREFNO, strATMID, strTrack2Data_35_2, strServiceid, lngbatchno, strRemarksOutWrd1, 0, "", "", "", strSysTraAudNum_11, strMobileNo, AppDate, strAcqInsIdenCd_32_2, StrREMITTERNBIN, strSESSIONBRCODE)

                If strResult = "Fail" Then
                    strFinalMessage = strFinalMessage & " InsertToIMPSLogDtls " & strResult
                    objTransaction.Rollback()
                    GoTo End1
                End If



                objTransaction.Commit()
End1:
            End If
            recnfts.Close()
            recnfts = Nothing
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & strFinalMessage, False)
            Exit Sub
        Catch ex As Exception
            objTransaction.Rollback()
            o_errmsg1 = ex.Message
            o_errmsg1 = o_errmsg1.Replace("\n\r", "").Replace("\n", "").Replace("\r", "").Replace(Chr(13), "").Replace(Chr(10), "")
            Response.Redirect("frmIMPSRefNoOutwrdReversal.aspx?record=" & o_errmsg1, False)
        End Try

    End Sub
    Private Sub GetIMPSOutwardDtls(ByVal strRefnum As String, ByRef strATMID As String, ByRef strSYSTRAAUDNUM As String, ByRef strMOBILENO As String, ByRef strAQUIRERID As String, ByRef strREMITTERNBIN As String)


        Try
            sQuery = "select  ATMID,SYSTRAAUDNUM, MOBILENO, AQUIRERID, REMITTERNBIN from impslogdtls where refnum = '" & strRefnum & "' and   serviceid = 'OUTWRD'"

            objCmd = New OracleClient.OracleCommand(sQuery, objconn)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                recnfts.Read()
                strATMID = IIf(IsDBNull(recnfts!SYSTRAAUDNUM), "", recnfts!SYSTRAAUDNUM)
                strSYSTRAAUDNUM = IIf(IsDBNull(recnfts!SYSTRAAUDNUM), "", recnfts!SYSTRAAUDNUM)
                strMOBILENO = IIf(IsDBNull(recnfts!MOBILENO), "", recnfts!MOBILENO)
                strAQUIRERID = IIf(IsDBNull(recnfts!AQUIRERID), "", recnfts!AQUIRERID)
                strREMITTERNBIN = IIf(IsDBNull(recnfts!REMITTERNBIN), "", recnfts!REMITTERNBIN)

            End If
            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing


            Exit Sub
        Catch ex As Exception

        End Try
    End Sub
    Private Function updateOutWrdIMPSVrnChanFundsTrnDtls(ByVal strrefno As String, ByVal strserviceid As String) As String
        Dim result As String
        Try
            Dim strSql As String
            Dim cnt As Integer

            '' R for rejected 

            strSql = "update impsbrchanfundstrnsdtls set sentyn= 'R' where refno37='" & strrefno & "' and serviceid = '" & strserviceid & "'"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.Transaction = objTransaction
            cnt = objCmd.ExecuteNonQuery()
            objCmd.Dispose()
            objCmd = Nothing

            result = "Success"
        Catch ex As Exception
            result = "Fail"
        End Try
        updateOutWrdIMPSVrnChanFundsTrnDtls = result
    End Function

    Private Function GetIMPSMOBOutwardReversal(ByVal strBrId1 As String, ByVal strAccNo1 As String, ByVal strGlcd1 As String, ByVal strACTP1 As String, ByVal pstrTrnAmt_4 As String, ByVal pstrMobileNo As String, ByVal pstrTrack2Data_35_2 As String, ByVal pstrCardAccTerID_41 As String, ByVal strRRNo1 As String, ByVal strProcCode As String, ByVal pserviceid2 As String, ByRef dblbalance1 As Double, ByRef strRespCd_39 As String, ByRef lngbatchno1 As String, ByRef strRemarksoutwrd As String) As String
        Dim strResCd1 As String
        Dim strResult As String
        Try


            strEODProgress = ""
            strDupTrnsCode = ""
            strExitsRefNum = ""
            strDupRefServTrnsCode = ""

            '' EOD in progress
            strEODProgress = GetEODProgress(strBrId)
            If strEODProgress = "" Then


                '' Check For Duplicate Transactions
                strDupTrnsCode = GetCodeMobCheckDupRefNumRevParRev(strRefNum_37, pserviceid2)

                '' check for Exits
                strExitsRefNum = GetCodeMobCheckExitsRefNum(strRefNum_37, pserviceid2)

                If strDupTrnsCode = "" And strExitsRefNum = "" Then

                    strDupRefServTrnsCode = GetCodeCheckDupRefNumServTran(strRefNum_37, pserviceid2)
                    If strDupRefServTrnsCode = "" Then


                        strDelChanConID = "IMPS"
                        strProcedureName = "Proc_ImpsOutWardRevTrnsP"

                        objCmd = New OracleClient.OracleCommand(strProcedureName, objconn)
                        objCmd.CommandType = CommandType.StoredProcedure

                        objCmd.Parameters.Add(New OracleClient.OracleParameter("BrId", OracleClient.OracleType.VarChar, 20)).Value = strBrId1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("AcNo", OracleClient.OracleType.VarChar, 20)).Value = strAccNo1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("pGlCode", OracleClient.OracleType.VarChar, 20)).Value = strGlcd1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("AcTp", OracleClient.OracleType.VarChar, 20)).Value = UCase(strACTP1)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("WthDrAmt", OracleClient.OracleType.VarChar, 20)).Value = CDbl(CDbl(pstrTrnAmt_4) / 100)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("MobileNo", OracleClient.OracleType.VarChar, 20)).Value = Trim(pstrMobileNo) '' Mobile no
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("MobID", OracleClient.OracleType.VarChar, 20)).Value = Trim(pstrTrack2Data_35_2)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("ATMId", OracleClient.OracleType.VarChar, 20)).Value = Trim(pstrCardAccTerID_41)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("DelChanConID", OracleClient.OracleType.VarChar, 4)).Value = Trim(strDelChanConID) '' Delivery Channel Controller ID
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("referencenum", OracleClient.OracleType.VarChar, 12)).Value = Trim(strRRNo1) ''reference number
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("pserviceid", OracleClient.OracleType.VarChar, 10)).Value = Trim(pserviceid2)  ''service id / proccode
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("strBalAfterOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("strResCdOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("lngBatchNoOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output


                        objCmd.ExecuteNonQuery()

                        dblbalance1 = IIf(IsDBNull(objCmd.Parameters("strBalAfterOUT").Value), 0, objCmd.Parameters("strBalAfterOUT").Value)
                        strResCd1 = IIf(IsDBNull(objCmd.Parameters("strResCdOUT").Value), "", objCmd.Parameters("strResCdOUT").Value)
                        lngbatchno1 = IIf(IsDBNull(objCmd.Parameters("lngBatchNoOUT").Value), 0, objCmd.Parameters("lngBatchNoOUT").Value)
                        '                dblBalance = CDbl(strBalance)

                        objCmd.Dispose()
                        objCmd = Nothing

                        ' '' insert into transaction log as insert statements to insert the records in database in future, if database crashes
                        'WriteToTransactionLog(lngbatchno)

                        'If objconn.State = ConnectionState.Open Then
                        '    objconn.Close()
                        'End If


                        If strEODProgress = "" Then
                            If strExitsRefNum = "" Then
                                If strDupTrnsCode = "" Then
                                    If strDupRefServTrnsCode = "" Then
                                        If Trim(strResCd1) = "000" Then
                                            strRespCd_39 = "000"  ''  transaction approved
                                        Else
                                            If Trim(strResCd1) = "" Then
                                                strRespCd_39 = "912"  '' Processing host cannot be reached
                                            Else
                                                strRespCd_39 = Trim(strResCd1)
                                            End If
                                        End If
                                    Else
                                        strRespCd_39 = Trim(strDupRefServTrnsCode) '' Check For Duplicate reference and serviceid Transactions
                                    End If
                                Else
                                    strRespCd_39 = Trim(strDupTrnsCode) '' Check For Duplicate Transactions
                                End If  ''strDupTrnsCode = ""
                            Else
                                strRespCd_39 = Trim(strExitsRefNum) '' Check For Exists Ref Num
                            End If
                        Else
                            strRespCd_39 = strEODProgress '' EOD in Progress
                        End If

                    End If
                End If ''strDupTrnsCode = ""

            End If '' EOD in Progress


            strRemarksoutwrd = GetRemarks(strRespCd_39)  '' Remarks 
            strResult = "Success"

        Catch ex As Exception
            strRespCd_39 = "912"  '' Processing host cannot be reached
            strResult = "Fail"

        End Try

        GetIMPSMOBOutwardReversal = strResult

    End Function

    Private Sub GetIMPSBrnChanOutwardReversal(ByVal strBrId1 As String, ByVal strAccNo1 As String, ByVal strGlcd1 As String, ByVal strACTP1 As String, ByVal pstrTrnAmt_4 As String, ByVal pstrMobileNo As String, ByVal pstrTrack2Data_35_2 As String, ByVal pstrAcqInsIdenCd_32_2 As String, ByVal pstrATMID As String, ByVal pstrTRANSREFNO As String, ByVal pserviceid2 As String, ByVal pstrSysTraAudNum_11 As String, ByVal pStrREMITTERNBIN As String, ByRef dblbalance1 As Double, ByRef strRespCd_39 As String, ByRef lngbatchno1 As String, ByRef strRemarksoutwrd As String)
        Dim strResCd1 As String

        Try


            strEODProgress = ""
            strDupTrnsCode = ""
            strExitsRefNum = ""
            strDupRefServTrnsCode = ""

            '' EOD in progress
            strEODProgress = GetEODProgress(strBrId)
            If strEODProgress = "" Then


                '' Check For Duplicate Transactions
                strDupTrnsCode = GetCodeCheckDupRefNumRevParRev(pstrTRANSREFNO, pserviceid2, strBrId1, strGlcd1, strAccNo1)

                '' check for Exits
                strExitsRefNum = GetCodeCheckExitsRefNum(pstrTRANSREFNO, pserviceid2, strBrId1, strGlcd1, strAccNo1)

                If strDupTrnsCode = "" And strExitsRefNum = "" Then
                    '    If objconn.State <> ConnectionState.Open Then
                    '      objconn = objCon.GetDbConnection(errMsg)
                    'End If
                    strDupRefServTrnsCode = GetCodeCheckDupRefNumServTran_OUTWRR(pstrTRANSREFNO, pserviceid2, pstrSysTraAudNum_11, StrREMITTERNBIN)
                    If strDupRefServTrnsCode = "" Then




                        strDelChanConID = "IMPS"
                        ''   strProcedureName = "Proc_ImpsOutWardRevTrnsP"
                        strProcedureName = "Proc_ImpsOutWardRevTrns"
                        objCmd = New OracleClient.OracleCommand(strProcedureName, objconn)
                        objCmd.CommandType = CommandType.StoredProcedure

                        objCmd.Parameters.Add(New OracleClient.OracleParameter("BrId", OracleClient.OracleType.VarChar, 20)).Value = strBrId1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("AcNo", OracleClient.OracleType.VarChar, 20)).Value = strAccNo1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("pGlCode", OracleClient.OracleType.VarChar, 20)).Value = strGlcd1
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("AcTp", OracleClient.OracleType.VarChar, 20)).Value = UCase(strACTP1)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("WthDrAmt", OracleClient.OracleType.VarChar, 20)).Value = CDbl(CDbl(pstrTrnAmt_4) / 100)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("MobileNo", OracleClient.OracleType.VarChar, 20)).Value = Trim(pstrMobileNo) '' Mobile no
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("MobID", OracleClient.OracleType.VarChar, 20)).Value = "Mobile"
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("ATMId", OracleClient.OracleType.VarChar, 20)).Value = Trim(pstrATMID)
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("DelChanConID", OracleClient.OracleType.VarChar, 4)).Value = Trim(strDelChanConID) '' Delivery Channel Controller ID
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("referencenum", OracleClient.OracleType.VarChar, 12)).Value = Trim(pstrTRANSREFNO) ''reference number
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("pserviceid", OracleClient.OracleType.VarChar, 20)).Value = Trim(pserviceid2) & Trim(pstrSysTraAudNum_11) & Trim(StrREMITTERNBIN)  ''service id / proccode
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("strBalAfterOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("strResCdOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                        objCmd.Parameters.Add(New OracleClient.OracleParameter("lngBatchNoOUT", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output


                      

                        objCmd.ExecuteNonQuery()

                        dblbalance1 = IIf(IsDBNull(objCmd.Parameters("strBalAfterOUT").Value), 0, objCmd.Parameters("strBalAfterOUT").Value)
                        strResCd1 = IIf(IsDBNull(objCmd.Parameters("strResCdOUT").Value), "", objCmd.Parameters("strResCdOUT").Value)
                        lngbatchno1 = IIf(IsDBNull(objCmd.Parameters("lngBatchNoOUT").Value), 0, objCmd.Parameters("lngBatchNoOUT").Value)
                        '                dblBalance = CDbl(strBalance)

                        objCmd.Dispose()
                        objCmd = Nothing

                        ' '' insert into transaction log as insert statements to insert the records in database in future, if database crashes
                        'WriteToTransactionLog(lngbatchno)

                        'If objconn.State = ConnectionState.Open Then
                        '    objconn.Close()
                        'End If


                        If strEODProgress = "" Then
                            If strExitsRefNum = "" Then
                                If strDupTrnsCode = "" Then
                                    If strDupRefServTrnsCode = "" Then
                                        If Trim(strResCd1) = "000" Then
                                            strRespCd_39 = "000"  ''  transaction approved
                                        Else
                                            If Trim(strResCd1) = "" Then
                                                strRespCd_39 = "912"  '' Processing host cannot be reached
                                            Else
                                                strRespCd_39 = Trim(strResCd1)
                                            End If
                                        End If
                                    Else
                                        strRespCd_39 = Trim(strDupRefServTrnsCode) '' Check For Duplicate reference and serviceid Transactions
                                    End If
                                Else
                                    strRespCd_39 = Trim(strDupTrnsCode) '' Check For Duplicate Transactions
                                End If  ''strDupTrnsCode = ""
                            Else
                                strRespCd_39 = Trim(strExitsRefNum) '' Check For Exists Ref Num
                            End If
                        Else
                            strRespCd_39 = strEODProgress '' EOD in Progress
                        End If

                    End If
                End If ''strDupTrnsCode = ""

            End If '' EOD in Progress


            strRemarksoutwrd = GetRemarks1(strRespCd_39, strRespCd_39) '' Remarks 


        Catch ex As Exception
            strRespCd_39 = "912"  '' Processing host cannot be reached


        End Try



    End Sub


    Private Function InsertOutwrdRevIntoIMPSBrnchChannelFundsTrnsDtls(ByVal strrefno As String, ByVal strserviceid As String, ByVal strbrcode As String, ByVal strcurcode As String, ByVal pmodid As String, ByVal strGlcode As String, ByVal strAccno As String, ByVal pbatchno As String, ByVal pbalamount As Double, ByVal pstrRespStaCd As String, ByVal strbrben22 As String, ByVal strproccd3 As String, ByVal stramount4 As String, ByVal strstan11 As String, ByVal strdatetime12 As String, ByVal strdate17 As String, ByVal strfuncd24 As String, ByVal stracquirer321 As String, ByVal stracquirer322 As String, ByVal strtranchan351 As String, ByVal strtranchan352 As String, ByVal strrespcd39 As String, ByVal strstationid41 As String, ByVal strbnkremmobno43 As String, ByVal strcurcd49 As String, ByVal strremaccno1021 As String, ByVal strremaccno1022 As String, ByVal strbenaccno1031 As String, ByVal strbenaccno1032 As String, ByVal strnetwrk1231 As String, ByVal strnetwrk1232 As String, ByVal strimp1241 As String, ByVal strimp1242 As String, ByVal strremname1251 As String, ByVal strremname1252 As String, ByVal strremarks1261 As String, ByVal strremarks1262 As String, ByVal strbenifsccode1271 As String, ByVal strbenifsccode1272 As String, ByVal strAppDate As Date, ByVal strUserId As String, ByVal strMachineId As String, ByVal pstrTranStatus As String, ByVal pstrcrremarks As String) As String
        Dim result As String
        Try
            Dim recnfts As OracleClient.OracleDataReader
            Dim strSql As String
            Dim cnt As Integer
            Dim crstatus As String
            crstatus = ""
            If pstrRespStaCd = "000" Then
                crstatus = "Y"
            Else
                crstatus = "N"
            End If
            pstrcrremarks = pstrcrremarks & " Reversal"
            strSql = "insert into impsbrchanfundstrnsdtls(refno37,BRANCHCODE,CURRENCYCODE,moduleid,GLCODE,ACCNO,batchno,balamount,DEBITSTATUS,CREDITSTATUS,CRREMARKS,brben2,proccd3,trnsamount4,stan11, datetime12,date17, funcd24,acquirer321, acquirer322,tranchan351,tranchan352,respcd39, stationid41,bnkremmobno43,curcd49,remaccno1021,remaccno1022,benaccno1031, benaccno1032,netwrk1231,netwrk1232,imp1241, imp1242, remname1251, remname1252,remarks1261,remarks1262,benifsccode1271,benifsccode1272,serviceid, TRANSTATUS,applicationdate, USERID,MACHINEID,SYSTEMDATE) values('" & strrefno & "','" & strbrcode & "','" & strcurcode & "','" & pmodid & "','" & strGlcode & "','" & strAccno & "',  '" & pbatchno & "'," & pbalamount & ",'N','" & crstatus & "','" & pstrcrremarks & "','" & strbrben22 & "','" & strproccd3 & "','" & stramount4 & "','" & strstan11 & "','" & strdatetime12 & "','" & strdate17 & "','" & strfuncd24 & "','" & stracquirer321 & "','" & stracquirer322 & "','" & strtranchan351 & "','" & strtranchan352 & "','" & strrespcd39 & "','" & strstationid41 & "','" & strbnkremmobno43 & "','" & strcurcd49 & "','" & strremaccno1021 & "','" & strremaccno1022 & "','" & strbenaccno1031 & "','" & strbenaccno1032 & "','" & strnetwrk1231 & "','" & strnetwrk1232 & "','" & strimp1241 & "','" & strimp1242 & "','" & strremname1251 & "','" & strremname1252 & "','" & strremarks1261 & "','" & strremarks1262 & "','" & strbenifsccode1271 & "','" & strbenifsccode1272 & "','" & strserviceid & "','" & pstrTranStatus & "','" & Format(CDate(strAppDate), "dd-MMM-yyyy") & "','" & strUserId & "','" & strMachineId & "',sysdate)"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.Transaction = objTransaction
            cnt = objCmd.ExecuteNonQuery()
            result = "Success"
            objCmd.Dispose()
            objCmd = Nothing
        Catch ex As Exception
            result = "Fail"
        End Try
        InsertOutwrdRevIntoIMPSBrnchChannelFundsTrnsDtls = result
    End Function



    Private Function InsertToIMPSLogDtls(ByVal dataFromClient As String, ByVal qstrbrid As String, ByVal qstrglcd As String, ByVal qstraccno As String, ByVal qstatus As String, ByVal qdbbal As Double, ByVal pstrTRANSREFNO As String, ByVal qatmid As String, ByVal qatmloc As String, ByVal strservid As String, ByVal lngbatchno As Long, ByVal strRemarks As String, ByVal pintRec As Long, ByVal pdataFromClientHexa As String, ByVal pstrOutMsgHexa As String, ByVal qcardno As String, ByVal qsystraaudnum As String, ByVal pmobileno As String, ByVal dtappdate As Date, Optional ByVal strAcqInsIdenCd_32_2 As String = "", Optional ByVal StrREMITTERNBIN As String = "", Optional ByVal strSESSIONBRCODE As String = "") As String

        Dim strSql As String
        Dim intinstr As Integer = 0
        Dim lngRec1 As Long
        Dim result As String
        Try
            Dim sentyn As String
            '  If objconn.State <> ConnectionState.Open Then
            ' objconn = objCon.GetDbConnection(errMsg)
            '  End If

            Dim strOutMsg1 As String = ""

            If qstatus = "000" Or qstatus = "00" Then
                sentyn = "Y"
            Else
                sentyn = "N"
            End If

            'dataFromClient1 = CStr(Mid(dataFromClient, 1, InStr(dataFromClient, "SWT") + 2))
            'strOutMsg1 = CStr(Mid(strOutMsg, 1, InStr(strOutMsg, "SWT") + 3))


            strSql = "insert into IMPSLOGDTLS(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO,BATCHNO, AMOUNT,REFNUM, ATMID, ATMLOCATION, REQDATETIME,  SERVICEID, REQDATA, RESDATA, STATUS, APPLICATIONDATE,REMARKS,responsenum,REQDATAHEXA,RESDATAHEXA,cardno,systraaudnum,mobileno,systemdate,slno,AQUIRERID, REMITTERNBIN,SESSIONBRCODE) values ('" & qstrbrid & "','INR','" & qstrglcd & "','" & qstraccno & "'," & lngbatchno & "," & qdbbal & ",'" & pstrTRANSREFNO & "','" & qatmid & "','" & qatmloc & "',to_date('" & Format(Now, "dd-MMM-yyyy HHmmss") & "','dd-Mon-yyyy hh24Miss'),'" & strservid & "','" & dataFromClient & "','" & strOutMsg1 & "','" & sentyn & "',to_date('" & Format(dtappdate, "dd-MMM-yyyy") & "','dd-Mon-yyyy'),'" & strRemarks & "'," & lngRec1 & ",'" & pdataFromClientHexa & "','" & pstrOutMsgHexa & "','" & qcardno & "','" & qsystraaudnum & "','" & pmobileno & "',sysdate,(SELECT nvl(max(slno),0) +1  FROM impslogdtls),'" & strAcqInsIdenCd_32_2 & "','" & StrREMITTERNBIN & "','" & strSESSIONBRCODE & "')"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.Transaction = objTransaction
            objCmd.ExecuteNonQuery()
            objCmd.Dispose()
            objCmd = Nothing

            result = "Success"
        Catch ex As Exception
            result = "Fail"
        End Try
        InsertToIMPSLogDtls = result
    End Function

    Public Sub SetClear()
        Try
            sQuery = ""
            strServiceid = ""
            strBrId = ""
            strGlcd = ""
            strAccNo = ""
            strACTP = ""

            strMTI = ""
            strMTIRes = ""
            strBitMap_1 = ""
            strBrBen_2_1 = ""
            strBrBen_2_2 = ""
            strBenAccNo_103_1 = ""
            strBenAccNo_103_2 = ""
            strBenIFSCCode_127_1 = ""
            strBenIFSCCode_127_2 = ""

            strDelChanConID = ""
            strProcedureName = ""
            strResult = ""
            strRequest = ""
            strMobileNo = ""
            strMTIReq = ""
            strRespStaCd = ""
            pRefNum = ""
            strProCd_3 = "" '' processing code
            strTrnAmt_4 = "" ''transaction amount
            strSysTraAudNum_11 = "" ''System Trace Audit Number
            strLocTranDtTime_12 = "" ''Local Transaction Date and Time
            strCapDt_17 = "" '' Capture Date
            strFuncCd_24 = "" ''Function Code
            strAcqInsIdenCd_32_1 = "" ''Acquiring Institution Identification Code
            strAcqInsIdenCd_32_2 = "" ''Acquiring Institution Identification Code
            strExtPriAccNum_34_1 = "" ''Extended Primary Account Number
            strExtPriAccNum_34_2 = "" ''Extended Primary Account Number
            strTrack2Data_35_1 = "" '' Track 2 Data
            strTrack2Data_35_2 = "" '' Track 2 Data
            strRefNum_37 = "" ''Reference Number
            strResponseCode_39 = "" ' Response Code
            strCardAccTerID_41 = "" ''Card Acceptor Terminal Id
            strCardAccIden_42 = "" ''Card Acceptor Identification
            strCardAccTermName_43_1 = ""  ''Card Acceptor Identification
            strCardAccTermName_43_2 = ""  ''Card Acceptor Identification
            strchrgsAmt_46_1 = "" '' Charges / Transaction Fee
            strchrgsAmt_46_2 = "" '' Charges / Transaction Fee
            strTranCurrCd_49 = ""  ''Transaction Currency Code
            strField56ForRev_56_1 = ""  ''Field 56 For Reversal
            strField56ForRev_56_2 = ""  ''Field 56 For Reversal

            strNetwrkMngtInfCode_70 = "" ''Network Management Information Code
            strRepAmtParRev_95 = "" ''Replacement Amount(Partial Reversal)

            strAccIden_102_1 = "" ''Account Identification 1
            strAccIden_102_2 = "" ''Account Identification 1
            strAccIden_103 = "" ''Account Identification 1
            strDelChanConID_123_1 = "" ''Delivery Channel Controller ID
            strDelChanConID_123_2 = "" ''Delivery Channel Controller ID
            strTempDelChanConID_123_2 = ""
            strTempTermType_124_2 = ""
            strTermType_124_1 = ""
            strTermType_124_2 = ""
            strDelChanConID = "" '' deliver channel id
            strPrivFld_126_1 = ""
            strPrivFld_126_2 = ""

            strResrvPrvUse_125_1 = "" ''Reserved For Private Use
            strResrvPrvUse_125_2 = "" ''Reserved For Private Use


            strBenName = ""
            strMTIReq = ""
            strMTIRes = ""

            strProcedureName = ""

            'Dim strarrstmtbal(6) As String  'array for ministatement details
            'Dim strarrstmtdet(5) As String  ' array for ministatement each column details

            strTrnsData_59_1 = ""
            strTrnsData_59_2 = ""
            strTransDest_93_1 = ""
            strTransDest_93_2 = ""
            strTransOrigin_94_1 = ""
            strTransOrigin_94_2 = ""

            dblbalAmt = 0
            lngbatchno = 0

            Exit Sub
        Catch ex As Exception

        End Try
    End Sub

    Public Function GetEODProgress(ByVal pBrCode As String) As String
        Try
            ' If objconn.State <> ConnectionState.Open Then
            '    objconn = objCon.GetDbConnection(errMsg)
            '  End If
            Dim recnfts As OracleClient.OracleDataReader
            Dim strDayBeginStatus As String
            Dim strDayEndStatus As String
            Dim strHOdayBeginStatus As String
            Dim strHODayEndStatus As String

            strDayBeginStatus = ""
            strDayEndStatus = ""
            strHOdayBeginStatus = ""
            strHODayEndStatus = ""

            sQuery = "SELECT DAYBEGINSTATUS, DAYENDSTATUS, HODAYBEGINSTATUS, HODAYENDSTATUS FROM genapplicationdatemst WHERE branchcode = '" & pBrCode & "'"

            objCmd = New OracleClient.OracleCommand(sQuery, objconn)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                recnfts.Read()
                strDayBeginStatus = IIf(IsDBNull(recnfts!DAYBEGINSTATUS), "", recnfts!DAYBEGINSTATUS)
                strDayEndStatus = IIf(IsDBNull(recnfts!DAYENDSTATUS), "", recnfts!DAYENDSTATUS)
                strHOdayBeginStatus = IIf(IsDBNull(recnfts!HODAYBEGINSTATUS), "", recnfts!HODAYBEGINSTATUS)
                strHODayEndStatus = IIf(IsDBNull(recnfts!HODAYENDSTATUS), "", recnfts!HODAYENDSTATUS)

                If strDayBeginStatus = "O" And strDayEndStatus = "N" And strHOdayBeginStatus = "O" And strHODayEndStatus = "N" Then
                    GetEODProgress = ""
                Else
                    GetEODProgress = "906"
                End If
            Else
                GetEODProgress = ""
            End If

            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing


            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function GetCodeCheckDupRefNumRevParRev(ByVal strrefnum As String, ByVal strPrcsCode As String, ByVal strBrCode3 As String, ByVal strGlCode3 As String, ByVal strAccno3 As String) As String

        Try
            Dim recnfts As OracleClient.OracleDataReader

            If strPrcsCode = "OUTWRR" Then
                '  sQuery = "SELECT count(*) cnt FROM impsbrchanfundstrnsdtls WHERE refno37 = '" & strrefnum & "' and serviceid = '" & strPrcsCode & "'  and debitstatus = 'Y'"
                sQuery = "SELECT count(*) cnt FROM impslogdtls WHERE refnum = '" & strrefnum & "' and serviceid = '" & strPrcsCode & "'  and status = 'Y' and  branchcode = '" & strBrCode3 & "' and glcode = '" & strGlCode3 & "' and accno = '" & strAccno3 & "'"
                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeCheckDupRefNumRevParRev = "913"
                    Else
                        GetCodeCheckDupRefNumRevParRev = ""
                    End If
                Else
                    GetCodeCheckDupRefNumRevParRev = ""
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeCheckDupRefNumRevParRev = ""
            End If
            Exit Function
        Catch ex As Exception
            '' GetCodeCheckDupRefNumRevParRev = "913"
        End Try
    End Function

    'Public Function GetCodeCheckDupRefNumServTran(ByVal strrefnum As String, ByVal strPrcsCode As String, ByVal pstrAcqInsIdenCd As String) As String
    '    Try
    '        Dim strInwrdprccode As String = ""
    '        ' If objDBCon.State <> ConnectionState.Open Then
    '        '    objDBCon = objCon.GetDbConnection(errMsg)
    '        '  End If
    '        If strPrcsCode = "INWARD" Or strPrcsCode = "OUTWRD" Or strPrcsCode = "OUTWRR" Or strPrcsCode = "OWITRA" Or strPrcsCode = "OWITRR" Then
    '            strInwrdprccode = strPrcsCode & pstrAcqInsIdenCd

    '            sQuery = "SELECT COUNT(*) cnt FROM (SELECT accno FROM atmtranday WHERE RESPONDINGBANKCODE = '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "' UNION SELECT accno FROM atmtran WHERE RESPONDINGBANKCODE= '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "')"


    '            objCmd = New OracleClient.OracleCommand(sQuery, objconn)
    '            recnfts = objCmd.ExecuteReader
    '            If recnfts.HasRows = True Then
    '                recnfts.Read()
    '                If recnfts!cnt > 0 Then
    '                    GetCodeCheckDupRefNumServTran = "094"
    '                Else
    '                    GetCodeCheckDupRefNumServTran = ""
    '                End If
    '            Else
    '                GetCodeCheckDupRefNumServTran = ""
    '            End If

    '            objCmd.Dispose()
    '            objCmd = Nothing
    '            recnfts.Close()
    '            recnfts = Nothing
    '        Else
    '            GetCodeCheckDupRefNumServTran = ""
    '        End If

    '        Exit Function
    '    Catch ex As Exception
    '        '  WriteToErrorLogFile("GetCodeCheckDupRefNumServTran", ex.Message)
    '    End Try
    'End Function
    Public Function GetCodeMobCheckDupRefNumRevParRev(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Try
            Dim recnfts As OracleClient.OracleDataReader

            If strPrcsCode = "OUTWRR" Then
                sQuery = "SELECT COUNT(*) cnt FROM impslogdtls WHERE refnum = '" & strrefnum & "' AND serviceid = '" & strPrcsCode & "'  AND status = 'Y'"
                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeMobCheckDupRefNumRevParRev = "913"
                    Else
                        GetCodeMobCheckDupRefNumRevParRev = ""
                    End If
                Else
                    GetCodeMobCheckDupRefNumRevParRev = ""
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeMobCheckDupRefNumRevParRev = ""
            End If
            Exit Function
        Catch ex As Exception
            ''GetCodeMobCheckDupRefNumRevParRev = "913"
        End Try
    End Function
    Public Function GetCodeCheckExitsRefNum(ByVal strrefnum As String, ByVal strPrcsCode As String, ByVal strBrCode3 As String, ByVal strGlCode3 As String, ByVal strAccno3 As String) As String
        Try

            '     If objconn.State <> ConnectionState.Open Then
            '   objconn = objCon.GetDbConnection(errMsg)
            '   End If
            Dim recnfts As OracleClient.OracleDataReader
            Dim strPrccode_comp As String
            '' inter bank reversal and intra bank reversal 
            If strPrcsCode = "OUTWRR" Or strPrcsCode = "OWITRR" Then
                If strPrcsCode = "OUTWRR" Then
                    strPrccode_comp = "OUTWRD"  '' inter bank 
                Else
                    strPrccode_comp = "OWITRA"  '' intra bank
                End If

                '     sQuery = "SELECT count(*) cnt FROM impsbrchanfundstrnsdtls WHERE refno37 = '" & strrefnum & "' and serviceid = 'OUTWRD'  and debitstatus = 'Y'"
                sQuery = "SELECT count(*) cnt FROM impslogdtls WHERE refnum = '" & strrefnum & "' and serviceid = '" & strPrccode_comp & "'  and status = 'Y' and  branchcode = '" & strBrCode3 & "' and glcode = '" & strGlCode3 & "' and accno = '" & strAccno3 & "'"


                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeCheckExitsRefNum = ""
                    Else
                        GetCodeCheckExitsRefNum = 119 '' transaction not permitted
                    End If
                Else
                    GetCodeCheckExitsRefNum = 119 '' transaction not permitted
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeCheckExitsRefNum = ""
            End If
            Exit Function
        Catch ex As Exception
            '' GetCodeCheckExitsRefNum = 119 '' transaction not permitted
        End Try
    End Function


    Public Function GetCodeMobCheckExitsRefNum(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Try
            '     If objconn.State <> ConnectionState.Open Then
            '   objconn = objCon.GetDbConnection(errMsg)
            '   End If
            Dim recnfts As OracleClient.OracleDataReader
            If strPrcsCode = "OUTWRR" Then
                If strPrcsCode = "OUTWRR" Then
                    sQuery = "SELECT COUNT(*) cnt FROM impslogdtls WHERE refnum = = '" & strrefnum & "' and serviceid = 'OUTWRD'  and status = 'Y'"
                End If

                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeMobCheckExitsRefNum = ""
                    Else
                        GetCodeMobCheckExitsRefNum = 119 '' transaction not permitted
                    End If
                Else
                    GetCodeMobCheckExitsRefNum = 119 '' transaction not permitted
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeMobCheckExitsRefNum = ""
            End If
            Exit Function
        Catch ex As Exception
            '' GetCodeMobCheckExitsRefNum = 119 '' transaction not permitted
        End Try
    End Function

    Public Function GetCodeCheckDupRefNumServTran_OUTWRR(ByVal strrefnum As String, ByVal strPrcsCode As String, ByVal pstrSysTraAudNum_11 As String, ByVal pStrREMITTERNBIN As String) As String
        Dim recnfts As OracleClient.OracleDataReader
        Try
            Dim strInwrdprccode As String
            ' If objconn.State <> ConnectionState.Open Then
            '    objconn = objCon.GetDbConnection(errMsg)
            '  End If
            If strPrcsCode = "OUTWRR" Then
                strInwrdprccode = strPrcsCode & pstrSysTraAudNum_11 & pStrREMITTERNBIN
                sQuery = "SELECT COUNT(*) cnt FROM (SELECT accno FROM atmtranday WHERE RESPONDINGBANKCODE= '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "' UNION SELECT accno FROM atmtran WHERE RESPONDINGBANKCODE= '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "')"

                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeCheckDupRefNumServTran_OUTWRR = "094"
                    Else
                        GetCodeCheckDupRefNumServTran_OUTWRR = ""
                    End If
                Else
                    GetCodeCheckDupRefNumServTran_OUTWRR = ""
                End If

                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeCheckDupRefNumServTran_OUTWRR = ""
            End If

            Exit Function
        Catch ex As Exception
            'GetCodeCheckDupRefNumServTran = "094"
        End Try
    End Function

    Public Function GetCodeCheckDupRefNumServTran(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Dim recnfts As OracleClient.OracleDataReader
        Try
            Dim strInwrdprccode As String
            ' If objconn.State <> ConnectionState.Open Then
            '    objconn = objCon.GetDbConnection(errMsg)
            '  End If
            If strPrcsCode = "OUTWRR" Then
                strInwrdprccode = strPrcsCode
                sQuery = "SELECT COUNT(*) cnt FROM (SELECT accno FROM atmtranday WHERE RESPONDINGBANKCODE= '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "' UNION SELECT accno FROM atmtran WHERE RESPONDINGBANKCODE= '" & strInwrdprccode & "' AND RATEREFCODE = '" & strrefnum & "')"

                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetCodeCheckDupRefNumServTran = "094"
                    Else
                        GetCodeCheckDupRefNumServTran = ""
                    End If
                Else
                    GetCodeCheckDupRefNumServTran = ""
                End If

                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetCodeCheckDupRefNumServTran = ""
            End If

            Exit Function
        Catch ex As Exception
            'GetCodeCheckDupRefNumServTran = "094"
        End Try
    End Function
    Public Function GetRemarks(ByVal strRespCode) As String
        Try
            Dim strRem As String
            strRem = ""
            If strRespCode = "000" Then
                strRem = "000 - Transaction Approved"
            ElseIf strRespCode = "0M1" Then
                strRem = "0M1 - Invalid Account Number"
            ElseIf strRespCode = "0M3" Then
                strRem = "0M3 - Account Inoperative / Frozen"
            ElseIf strRespCode = "0M5" Then
                strRem = "0M5 - Closed Account Number"
            ElseIf strRespCode = "0M2" Then
                strRem = "0M2 - Amount Limit Exceed For Customer"
            ElseIf strRespCode = "0M0" Then
                strRem = "0M0 - Transaction Failed"
            ElseIf strRespCode = "092" Then
                strRem = "092 - Invalid IFSC Code First 4 digits"
            ElseIf strRespCode = "0M6" Then
                strRem = "0M6 - Net Debit Cap Check at NPCI"
            ElseIf strRespCode = "0MP" Then
                strRem = "0MP - Banks Not Enabled Account Numbers, IFSC based Funds transfer"
            ElseIf strRespCode = "036" Then
                strRem = "036 - Restricted Card "
            ElseIf strRespCode = "116" Then
                strRem = "116 - Insufficient Funds"
            ElseIf strRespCode = "119" Then
                strRem = "119 - Transaction Not Permitted"
            ElseIf strRespCode = "121" Then
                strRem = "121 - Withdrawal limit exceeded"
            ElseIf strRespCode = "180" Then
                strRem = "180 - Transfer limit exceeded"
            ElseIf strRespCode = "904" Then
                strRem = "904 - Message incorrectly formatted"
            ElseIf strRespCode = "906" Then
                strRem = "906 - Cut over end of day in progress"
            ElseIf strRespCode = "008" Then
                strRem = "008 - Processing host is down"
            ElseIf strRespCode = "008" Then
                strRem = "008 - Processing host cannot be reached"
            ElseIf strRespCode = "909" Then
                strRem = "909 - System Malfunction"
            ElseIf strRespCode = "008" Then
                strRem = "008 - Host timed out"
            ElseIf strRespCode = "008" Then
                strRem = "008 - Bank Host Not Available"
            ElseIf strRespCode = "181" Then
                strRem = "181 - Cheque not in same book"
            ElseIf strRespCode = "182" Then
                strRem = "182 - Not all cheques can be stopped"
            ElseIf strRespCode = "183" Then
                strRem = "183 - Cheque belongs to different account"
            ElseIf strRespCode = "094" Then
                strRem = "094 - Duplicate Transactions"
            ElseIf strRespCode = "800" Then
                strRem = "800 - OK"
            ElseIf strRespCode = "100" Then
                strRem = "100- Posting Restrictions"
            End If
            GetRemarks = strRem
            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function GetRemarks1(ByVal strRespCode As String, ByRef qstrRespCode As String) As String
        Try
            Dim strRem As String
            strRem = ""
            If strRespCode = "000" Or strRespCode = "00" Then
                qstrRespCode = "00"
                strRem = "000 - Transaction Approved"
            ElseIf strRespCode = "0M1" Then
                '   qstrRespCode = "21"
                qstrRespCode = "M1"
                strRem = "0M1 - Invalid Account Number"
            ElseIf strRespCode = "0M3" Then
                qstrRespCode = "M3"
                strRem = "0M3 - Account Inoperative / Frozen"
            ElseIf strRespCode = "0M5" Then
                qstrRespCode = "M5"
                strRem = "0M5 - Closed Account Number"
            ElseIf strRespCode = "0M2" Then
                qstrRespCode = "M2"
                strRem = "0M2 - Amount Limit Exceed For Customer"
            ElseIf strRespCode = "0M0" Then
                qstrRespCode = "M0"
                strRem = "0M0 - Transaction Failed"
            ElseIf strRespCode = "0M4" Then
                qstrRespCode = "M4"
                strRem = "0M4 - NRE Account"
            ElseIf strRespCode = "116" Then
                qstrRespCode = "51"
                strRem = "51 - Insufficient Funds"
            ElseIf strRespCode = "119" Then
                qstrRespCode = "01"
                strRem = "01 - Transaction Not Permitted"
            ElseIf strRespCode = "121" Then
                qstrRespCode = "01"
                strRem = "01 - Withdrawal limit exceeded"
            ElseIf strRespCode = "180" Then
                qstrRespCode = "78"
                strRem = "78 - Transfer limit exceeded"
            ElseIf strRespCode = "904" Then
                qstrRespCode = "01"
                strRem = "01 - Incorrect string Format"
            ElseIf strRespCode = "906" Then
                qstrRespCode = "01"
                strRem = "01 - Cut over end of day in progress"
                'ElseIf strRespCode = "008" Then
                '    strRem = "008 - Processing host is down"
                'ElseIf strRespCode = "008" Then
                '    strRem = "008 - Processing host cannot be reached"
            ElseIf strRespCode = "909" Then
                qstrRespCode = "01"
                strRem = "01 - System Malfunction"
                'ElseIf strRespCode = "008" Then
                '    strRem = "008 - Host timed out"
                'ElseIf strRespCode = "008" Then
                '    strRem = "008 - Bank Host Not Available"
            ElseIf strRespCode = "181" Then
                qstrRespCode = "01"
                strRem = "01 - Cheque not in same book"
            ElseIf strRespCode = "182" Then
                qstrRespCode = "01"
                strRem = "01 - Not all cheques can be stopped"
            ElseIf strRespCode = "183" Then
                qstrRespCode = "01"
                strRem = "01 - Cheque belongs to different account"
            ElseIf strRespCode = "094" Then
                qstrRespCode = "94"
                strRem = "094 - Duplicate Transactions"
            ElseIf strRespCode = "051" Then
                qstrRespCode = "24"
                strRem = "051 - Insufficient funds in Beneficiary Pool"
            ElseIf strRespCode = "800" Then
                qstrRespCode = "01"
                strRem = "01 - OK"
            ElseIf strRespCode = "100" Then
                qstrRespCode = "01"
                strRem = "01- Posting Restrictions"
            ElseIf strRespCode = "0MJ" Then
                qstrRespCode = "MJ"
                strRem = "MJ- INVALID BENEFICIARY IFSC CODE OR NBIN"
            ElseIf strRespCode = "62" Then
                qstrRespCode = "62"
                strRem = "62-  Account restricted"
            End If
            GetRemarks1 = strRem
            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function GetATMCodeCheckDupRefNumRevParRev(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Try
            '     If objconn.State <> ConnectionState.Open Then
            '   objconn = objCon.GetDbConnection(errMsg)
            '    End If
            ' PDBREV -- debit partial reversal
            'NDEBREV --ON US debit reversal
            'FDEBREV --OFF US debit reversal
            'LDEBRV --  LORO debit reversal 
            'PSRREQ -- pos reversal request
            '' ECRREQ -- ecom reversal request 
            '' CHPRRQ -- cash pos reversal request
            '' CBPRRQ -- cash back pos reversal request

            If strPrcsCode = "PDBREV" Or strPrcsCode = "NDEBRV" Or strPrcsCode = "FDEBRV" Or strPrcsCode = "LDEBRV" Or strPrcsCode = "PSRREQ" Or strPrcsCode = "ECRREQ" Or strPrcsCode = "CHPRRQ" Or strPrcsCode = "CBPRRQ" Then
                sQuery = "SELECT count(*) cnt FROM atmlogdtls WHERE refnum = '" & strrefnum & "' and serviceid = '" & strPrcsCode & "'  and status = 'Y'"
                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetATMCodeCheckDupRefNumRevParRev = "913"
                    Else
                        GetATMCodeCheckDupRefNumRevParRev = ""
                    End If
                Else
                    GetATMCodeCheckDupRefNumRevParRev = ""
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetATMCodeCheckDupRefNumRevParRev = ""
            End If
            Exit Function
        Catch ex As Exception

        End Try
    End Function

    Public Function GetATMCodeCheckExitsRefNum(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Try
            '     If objconn.State <> ConnectionState.Open Then
            '   objconn = objCon.GetDbConnection(errMsg)
            '   End If
            If strPrcsCode = "PDBREV" Or strPrcsCode = "NDEBRV" Or strPrcsCode = "FDEBRV" Or strPrcsCode = "LDEBRV" Then
                If strPrcsCode = "NDEBRV" Then
                    sQuery = "SELECT count(*) cnt FROM atmlogdtls WHERE refnum = '" & strrefnum & "' and serviceid = 'NWDRRQ'  and status = 'Y'"
                ElseIf strPrcsCode = "FDEBRV" Then
                    sQuery = "SELECT count(*) cnt FROM atmlogdtls WHERE refnum = '" & strrefnum & "' and serviceid = 'FWDRRQ'  and status = 'Y'"
                ElseIf strPrcsCode = "LDEBRV" Then
                    sQuery = "SELECT count(*) cnt FROM atmlogdtls WHERE refnum = '" & strrefnum & "' and serviceid = 'LWDRRQ'  and status = 'Y'"
                Else
                    sQuery = "SELECT count(*) cnt FROM atmlogdtls WHERE refnum = '" & strrefnum & "' and serviceid = 'WDRREQ'  and status = 'Y'"
                End If

                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetATMCodeCheckExitsRefNum = ""
                    Else
                        GetATMCodeCheckExitsRefNum = 119 '' transaction not permitted
                    End If
                Else
                    GetATMCodeCheckExitsRefNum = 119 '' transaction not permitted
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetATMCodeCheckExitsRefNum = ""
            End If
            Exit Function
        Catch ex As Exception

        End Try
    End Function

    Public Function GetATMCodeCheckDupRefNumServTran(ByVal strrefnum As String, ByVal strPrcsCode As String) As String
        Try
            ' If objconn.State <> ConnectionState.Open Then
            '    objconn = objCon.GetDbConnection(errMsg)
            '  End If
            If strPrcsCode = "NWDRRQ" Or strPrcsCode = "FWDRRQ" Or strPrcsCode = "LWDRRQ" Or strPrcsCode = "POSREQ" Or strPrcsCode = "ECMREQ" Or strPrcsCode = "NDEBRV" Or strPrcsCode = "FDEBRV" Or strPrcsCode = "LDEBRV" Or strPrcsCode = "PSRREQ" Or strPrcsCode = "ECRREQ" Or strPrcsCode = "PDBREV" Or strPrcsCode = "BALENQ" Or strPrcsCode = "PINCHG" Or strPrcsCode = "MINSTA" Or strPrcsCode = "CHPRRQ" Or strPrcsCode = "CBPREQ" Or strPrcsCode = "POSREQ" Or strPrcsCode = "CBPRRQ" Or strPrcsCode = "ECMREQ" Or strPrcsCode = "PSRREQ" Or strPrcsCode = "ECRREQ" Or strPrcsCode = "CHPREQ" Or strPrcsCode = "NCSDRQ" Or strPrcsCode = "FCSDRQ" Or strPrcsCode = "LCSDRQ" Then


                sQuery = "SELECT COUNT(*) cnt FROM (SELECT accno FROM atmtranday WHERE RESPONDINGBANKCODE= '" & strPrcsCode & "' AND RATEREFCODE = '" & strrefnum & "' UNION SELECT accno FROM atmtran WHERE RESPONDINGBANKCODE= '" & strPrcsCode & "' AND RATEREFCODE = '" & strrefnum & "')"

                objCmd = New OracleClient.OracleCommand(sQuery, objconn)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    If recnfts!cnt > 0 Then
                        GetATMCodeCheckDupRefNumServTran = "913"
                    Else
                        GetATMCodeCheckDupRefNumServTran = ""
                    End If
                Else
                    GetATMCodeCheckDupRefNumServTran = ""
                End If

                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing
            Else
                GetATMCodeCheckDupRefNumServTran = ""
            End If

            Exit Function
        Catch ex As Exception

        End Try
    End Function

    Private Function GetATMCheckInvAccNum(ByVal strbrcd1 As String, ByVal strglcd1 As String, ByVal straccno1 As String) As String
        Try
            Dim strfullaccno As String = ""
            strfullaccno = strbrcd1 & strglcd1 & straccno1.PadLeft(7, "0")

            If strfullaccno.Trim.Length <> 16 Then
                GetATMCheckInvAccNum = "114" ''Invalid Account Number
            Else
                GetATMCheckInvAccNum = ""
            End If
            Exit Function
        Catch ex As Exception

        End Try
    End Function

    Private Sub GetMODID(ByVal pstrGlcd As String, ByRef pstrACTP As String)
        Try
            If pstrGlcd = "102020" Then
                pstrACTP = "SB"
            ElseIf pstrGlcd = "102030" Then
                pstrACTP = "CA"
            ElseIf Mid(pstrGlcd, 1, 3) = "206" Then
                pstrACTP = "CC"
            End If
            Exit Sub
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GetMode(ByVal strProcCode As String, ByRef strRevReqMode As String)
        If strProcCode = "NWDRRQ" Then
            strRevReqMode = "ONUS"
        ElseIf strProcCode = "FWDRRQ" Then
            strRevReqMode = "OFFUS"
        ElseIf strProcCode = "POSREQ" Or strProcCode = "ECMREQ" Then
            strRevReqMode = "POS"
        ElseIf strProcCode = "CHPREQ" Then
            strRevReqMode = "CASHPOS"
        End If
    End Sub

    Private Sub GetServiceCd(ByVal strProcCode1 As String, ByRef strProcCode As String)
        If strProcCode1 = "NWDRRQ" Then
            strProcCode = "NDEBRV"
        ElseIf strProcCode1 = "FWDRRQ" Then
            strProcCode = "FDEBRV"
        ElseIf strProcCode1 = "POSREQ" Then
            strProcCode = "PSRREQ"
        ElseIf strProcCode1 = "ECMREQ" Then
            strProcCode = "ECRREQ"
        ElseIf strProcCode1 = "CHPREQ" Then
            strProcCode = "CHPRRQ"
        End If
    End Sub

    Private Function GetFreeFrmSplChars(ByVal str As String) As String
        Try

            Dim array1() As String = {"!", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", ".", "@", "[", "\", "]", "^", "_", "`", "{", "|", "}", "~"}

            For Each Item As String In array1
                str = str.Replace(Item, "")
            Next

            GetFreeFrmSplChars = str

            Exit Function
        Catch ex As Exception
            GetFreeFrmSplChars = ""

        End Try
    End Function

    Private Sub InsertToATMLogDtls(ByVal qstrbrid As String, ByVal qstrglcd As String, ByVal qstraccno As String, ByVal qrefnum As String, ByVal qatmid As String, ByVal qatmloc As String, ByVal qreqdate As DateTime, ByVal pstrservid As String, ByVal qcardno As String, ByVal qsystraaudnum As String, ByVal lngbatchno As String, ByVal pstrRespCd_39 As String, ByVal pstrTrnAmt As Double, ByVal strRemarks As String, ByRef StrError As String)
        Dim strSql As String
        Dim plngsnlno As Long = 0
        Dim sentyn As String
        Dim plngrespno As Long = 0


        Try
            If pstrRespCd_39 = "000" Then
                sentyn = "Y"
            Else
                sentyn = "N"
            End If


            strSql = "SELECT NVL(MAX(slno),0) +1  FROM atmlogdtls"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            plngsnlno = objCmd.ExecuteScalar
            GetResponse_38(plngsnlno, plngrespno)

            strSql = "insert into ATMLOGDTLS(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO,REFNUM, ATMID, ATMLOCATION, REQDATETIME,RESDATETIME, SERVICEID, REQDATA, STATUS, APPLICATIONDATE,cardno,systraaudnum,slno,BATCHNO, AMOUNT, REMARKS,RESPONSENUM ) values ('" & qstrbrid & "','INR','" & qstrglcd & "','" & qstraccno & "','" & qrefnum & "','" & qatmid & "','" & qatmloc & "',to_date('" & Format(qreqdate, "dd-MMM-yyyy HHmmss") & "','dd-Mon-yyyy hh24Miss'),to_date('" & Format(qreqdate, "dd-MMM-yyyy HHmmss") & "','dd-Mon-yyyy hh24Miss'),'" & pstrservid & "','','" & sentyn & "',to_date('" & Format(AppDate, "dd-MMM-yyyy") & "','dd-Mon-yyyy'),'" & qcardno & "','" & qsystraaudnum & "'," & plngsnlno & "," & lngbatchno & "," & pstrTrnAmt & ",'" & strRemarks & "'," & plngrespno & ")"

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objCmd.ExecuteNonQuery()
            objCmd.Dispose()
            objCmd = Nothing

            Exit Sub
        Catch ex As Exception
            StrError = ex.Message
        End Try
    End Sub
    Public Sub GetResponse_38(ByVal sslno As Long, ByRef intRecTemp1 As Long)
        Dim intRecTemp As Long
        Try

            If CStr(sslno).Length > 5 Then
                intRecTemp = StrReverse(StrReverse(CStr(sslno)).Substring(0, 5))
            Else
                intRecTemp = sslno
            End If

            If intRecTemp = 99999 Then
                intRecTemp = 1
            End If
            intRecTemp1 = CStr(intRecTemp).PadLeft(5, "0")

            Exit Sub
        Catch ex As Exception
            intRecTemp1 = CStr(intRecTemp).PadLeft(5, "0")

        End Try
    End Sub
End Class
