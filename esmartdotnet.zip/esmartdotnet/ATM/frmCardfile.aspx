<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmCardfile.aspx.vb" Inherits="eSmartDotNet.frmCardfile" %>
<%
   Dim objhotraw As New GENVALIDATIONS.Validations
  '' modified by dattu 24-nov-22
        '' HO Trans Allowed
        strMainBrcode = objhotraw.GetHOTRALWBrCode()
	dim strmessage

	strmessage=Request.QueryString("record")
	
	dim obj, rs, obj1, rs1, obj2, rs2
	
	dim impYn,brcod,Refnm,lef,multi,Sln

	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN","CODE='CARDISS'")
	
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
	end if
	
	obj1 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs1 = obj.SingleRecordSet("genbankbranchmst","LPAD(SUBSTR(ATMBIN,0,6),6,0) brcode","branchcode='" & session("branchcode") & "'")
	
	if not rs1.EOF and not rs1.BOF then
		brcod = rs1(0).value
	end if
	
	obj2 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs2 = obj2.SingleRecordSet("ATMFILEGEN","(CASE WHEN MAX(SEQNUM) IS NULL THEN LPAD(NVL(MAX(SEQNUM),'0')+1,6,'0') WHEN MAX(SEQNUM)<'999999' THEN LPAD(NVL(MAX(SEQNUM),'0')+1,6,'0') WHEN MAX(SEQNUM)='999999' THEN '000001' END) SQUNUM","")
	
	if not rs2.EOF and not rs2.BOF then
		StSeq = rs2(0).value
	end if
	
	dim rsBnk,objBnk,frmname,staccond
	rsBnk=server.CreateObject("adodb.recordset")
	objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsBnk=objBnk.singlerecordset("genbankparm","depcertificate","")
	
	if objBnk.ConnError="Connected" then	
		if not rsBnk.EOF and not rsBnk.BOF then
			frmname=rsBnk(0).value
		end if
	end if
	
%>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>Card File Generate</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	var stBnk
	
	stBnk = "<%=frmname%>"
	
	function Display()
	{
		var BRCD="<%=session("branchcode")%>"
		
		var IMP="<%=impYn%>"
	//	alert("<%=strMainBrcode%>")
		if(IMP=="Y")
		{
			if(BRCD=="<%=strMainBrcode%>")
			{
				
			}
			else
			{
				alert("This Branch is not Authorized to do File Generation\n Please Contact H O ")
				location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
			}
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
		
		
	}
	
	
	function branch()
	{  
		telbr="Tellerbranch";
		window.showModalDialog("../GEN/Listquery.aspx"+"?"+"st="+telbr,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
	}
	function Branchcode(kstr)
	{ 
		assign(kstr,window.document.frmCardfilegen.txtbranchdesc,window.document.frmCardfilegen.txtbranchcode)		
	} 
	
	var stBr,br,actyp,stActyp,actp,strVal
	
	function Ok()
	{
		var st,Cond,stId
		
	if ((stBnk == "MAHARAJA") || (stBnk == "ELURU") || (stBnk == "PCUB"))
		{
			
			if (window.document.frmCardfilegen.opt1(0).checked==true)
			{
				stId = "I"
				
				if (window.document.frmCardfilegen.chkAllbr.checked==true)
				{
					Cond = " and ACTIONCODE='I' "
				}
				else
				{
					Cond = " and Branchcode='"+window.document.frmCardfilegen.txtbranchcode.value+"' and ACTIONCODE='I' "
				}
				
				st="CARDFILEGEN"+"|"+Cond+"|"+stId
			}
			
			if (window.document.frmCardfilegen.opt1(1).checked==true)
			{
				stId = "U"
				
				if (window.document.frmCardfilegen.chkAllbr.checked==true)
				{
					Cond = " and ACTIONCODE='U' "
				}
				else
				{
					Cond = " and Branchcode='"+window.document.frmCardfilegen.txtbranchcode.value+"' and ACTIONCODE='U' "
				}
				st="CARDFILEGEN"+"|"+Cond+"|"+stId
				//st="CARDUPDATFILEGEN"+"|"+Cond+"|"+stId
			}
			
			
			//alert("st = "+st)
		}
		
		if((stBnk == "SALUR") || (stBnk == "DMM"))
		{
		
			if (window.document.frmCardfilegen.chkAllbr.checked==true)
			{
				Cond = ""
			}
			else
			{
				Cond = " and Branchcode='"+window.document.frmCardfilegen.txtbranchcode.value+"'"
			}
			
			st="CARDREQUEST"+"|"+Cond
		}
		
		window.document.all['iGetDtls'].src="../GEN/getDtls.aspx?st="+st
	}
	
	function popReqcust(str)
	{
		if(str=="No Records")
		{
			alert("No records found to Generate file")
			return;
		}
		
		var strCnt = str.split("~")
		
		var time = new Date();
		
		var month = new Array();
		month[0] = "01";
		month[1] = "02";
		month[2] = "03";
		month[3] = "04";
		month[4] = "05";
		month[5] = "06";
		month[6] = "07";
		month[7] = "08";
		month[8] = "09";
		month[9] = "10";
		month[10] = "11";
		month[11] = "12";

		var D = ("0" + time.getDate()).slice(-2)
		var M = month[time.getMonth()];
		var Y = time.getFullYear().toString().substr(2,2);
		var hh = ("0" + time.getHours()).slice(-2)
		var mm = ("0" + time.getMinutes()).slice(-2)
		var ss = ("0" + time.getSeconds()).slice(-2)
		
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		
		filepath="CRD"+""+M+""+D+""+Y+""+hh+""+mm+""+ss
		
		if (! fso.FolderExists("C://CardRequest") )
		fso.CreateFolder("C://CardRequest")
		
		var fh = fso.CreateTextFile("c://"+ "CardRequest/"+filepath+".txt" , true); 
		var�strTemp=""
		
		for(aCnt=0;aCnt<=strCnt.length-1;aCnt++)
		{
			strTemp=strCnt[aCnt]
			fh.WriteLine(strTemp)
			//strTemp=""
		}
		
		//fh.WriteLine(strTemp)
		fh.Close();
		alert("c://"+ "CardRequest/"+filepath+".txt: File Created")
		
	}
	
	function popCardfile(str)
	{
		if(str=="No Records")
		{
			alert("No records found to Generate file")
			return;
		}
		
		var br = "<%=brcod%>"
		
		var seQu = "<%=StSeq%>"
		
		var strCnt = str.split("~")
		var strResult = strCnt[1].split("|")
		
		var time = new Date();
		
		var month = new Array();
		month[0] = "01";
		month[1] = "02";
		month[2] = "03";
		month[3] = "04";
		month[4] = "05";
		month[5] = "06";
		month[6] = "07";
		month[7] = "08";
		month[8] = "09";
		month[9] = "10";
		month[10] = "11";
		month[11] = "12";

		var D = ("0" + time.getDate()).slice(-2)
		var M = month[time.getMonth()];
		var Y = time.getFullYear().toString().substr(2,2);
		var yr  = time.getFullYear().toString();
		var hh = ("0" + time.getHours()).slice(-2)
		var mm = ("0" + time.getMinutes()).slice(-2)
		var ss = ("0" + time.getSeconds()).slice(-2)
		
		var fso  = new ActiveXObject("Scripting.FileSystemObject");
		//br = "607214"
		//br = "608389"
		
		if (window.document.frmCardfilegen.opt1(0).checked==true)
		{
			filepath="CRD"+""+br+M+""+D+""+Y+""+hh+""+mm+""+ss
		}
		if (window.document.frmCardfilegen.opt1(1).checked==true)
		{
			filepath="UCD"+""+br+M+""+D+""+Y+""+hh+""+mm+""+ss
		}
		
		
		if (! fso.FolderExists("C://CardRequest") )
		fso.CreateFolder("C://CardRequest")
		
		var fh = fso.CreateTextFile("c://"+ "CardRequest/"+filepath+".DAT" , true); 
		var�strTemp=""
		
		// for file Header
		// Eg : HD0607511001387130620130513542.0
		// HD --> fixed  , 0 --> fixed , 607511 --> bank/branch code , 001387 --> sequance number , 13062013051354 --> date and time (ddmmyyyyhh24miss), 2.0 -->fixed
		
		// for footer 
		// Eg : EOF000002
		// EOF --> Fixed, 000002 --> count of records
		var stfoter,stheader, strTemp
		
		stheader = "HD0"+br+""+seQu+""+M+""+D+""+yr+""+hh+""+mm+""+ss+"2.0"
		
		stfoter = "EOF" + strCnt[0]
		
		strTemp = stheader
		
		fh.WriteLine(strTemp)
		
		for(aCnt=0;aCnt<=strResult.length-1;aCnt++)
		{
			strTemp=strResult[aCnt]
			
			var strRt = strTemp.split("")
			
			var stTt,stEtot, stCh, stAchval, stFva, stLn
			var stAva, stDiv
			
			stDiv = 1449
			
			stEtot = 0;
			
			for (bCnt=0; bCnt<=strRt.length-1; bCnt++) 
			{
				stCh = strRt[bCnt]
				
				stAchval  = stCh.charCodeAt();
				
				stTt = 0;
				
				stTt = eval(stAchval) - 1;
				
				stEtot = eval(stEtot) + eval(stTt)
				
			}
			
			stAva = eval(stEtot) % eval(stDiv)
			
				
			stLn = stAva.toString().length;
			
						
			if(stLn == 1)
			{
				stFva = "0000000"+""+stAva
			}
			else if(stLn == 2)
			{
				stFva = "000000"+""+stAva
			}
			else if(stLn == 3)
			{
				stFva = "00000"+""+stAva
			}
			else if(stLn == 4)
			{
				stFva = "0000"+""+stAva
			}
			else if(stLn == 5)
			{
				stFva = "000"+""+stAva
			}
			else if(stLn == 6)
			{
				stFva = "00"+""+stAva
			}
			else if(stLn == 7)
			{
				stFva = "0"+""+stAva
			}
			else if(stLn == 8)
			{
				stFva = stAva
			}
			
			strTemp = strTemp +""+stFva
			
			fh.WriteLine(strTemp)
			strTemp=""
		}
		
		strTemp = stfoter
		
		fh.WriteLine(strTemp)
		fh.Close();
		alert("c://"+ "CardRequest/"+filepath+".DAT: File Created")
		
		
		var stCnd
		
		if (window.document.frmCardfilegen.opt1(0).checked==true)
		{
			if (window.document.frmCardfilegen.chkAllbr.checked==true)
			{
				stCnd = " and ACTIONCODE='I' "
			}
			else
			{
				stCnd = " and Branchcode='"+window.document.frmCardfilegen.txtbranchcode.value+"' and ACTIONCODE='I' "
			}
		}
		
		if (window.document.frmCardfilegen.opt1(1).checked==true)
		{
			if (window.document.frmCardfilegen.chkAllbr.checked==true)
			{
				stCnd = " and ACTIONCODE='U' "
			}
			else
			{
				stCnd = " and Branchcode='"+window.document.frmCardfilegen.txtbranchcode.value+"' and ACTIONCODE='U' "
			}
		}
		
		strVal = "GENYNSTAT"+"~"+stCnd+"~"+seQu+"~"+filepath+"~"+strCnt[0]
		
		window.document.frmCardfilegen.mercust.value=strVal
		window.document.frmCardfilegen.action="CrdGenYN.aspx"
		window.document.frmCardfilegen.method="post"   
		window.document.frmCardfilegen.submit()
		
	}
	
	function DispTranMsg()
	{
		var strtran = "<%=strmessage%>"
		
		if(strtran!="")
		{
			if(strtran=="Sucessful.")
			{
				window.location.href="frmCardfile.aspx"
			}
		}
		
		if ((stBnk == "MAHARAJA") || (stBnk == "ELURU") || (stBnk == "PCUB"))
		{
			window.document.all.divCrdMod.style.display = "block"
		}
		else
		{
			window.document.all.divCrdMod.style.display = "none"
		}
			
	}
	
	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display();DispTranMsg();">
	<form name="frmCardfilegen">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>ATM CARD FILE GENERATE</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
					<tr>
						<td width="100%" height="20" colspan="2">
							<div align="center" id="divCrdMod" style="display:none">
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="BGCOLOR">
										<td width="10%">
												<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>CRD File&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">UCD File&nbsp;</font></p></td>
										
									</tr>
								</table>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%" height="20" colspan="2">
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr class="BGCOLOR">
									<td width="12%" align="right">Branch Code&nbsp;&nbsp;</font></td>
									<td width="38%">&nbsp;<input name="txtbranchcode" size="9" readonly class="txtautofill" value="<%=session("branchcode")%>" maxlength="4" style="TEXT-ALIGN: right"><input type="button" value=" L " name="cmdbranch" onclick="branch()" style="height: 22; width: 22" class="button"><input name="txtbranchdesc" size="16" readonly class="bgcolor1" value="<%=session("branchnarration")%>"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;All Branches<input type="checkbox" name="chkAllbr" ></td>
									
								</tr>
							</table>
						</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center"><input name="cmdOk" onclick="Ok()" type="button" value=" Generate " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmCardfile.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
					
					
					
				</table>
			</div>
			</td>
		</tr>
	</table>
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<IFRAME id=iGetDtls style="DISPLAY: block" align=center frameSpacing=0 src="../gen/getDtls.aspx" frameBorder=0 width=0 height=0></IFRAME>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>
