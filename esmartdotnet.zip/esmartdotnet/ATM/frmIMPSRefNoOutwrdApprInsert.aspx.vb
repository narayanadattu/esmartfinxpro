Public Class frmIMPSRefNoOutwrdApprInsert
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strmode As Object
    Dim mystr As String
    Dim strvalues As Object
    Dim rows As Integer
    Dim strcols As Object
    Dim strRefno As String
    Dim appdate1 As String
    Dim i As Integer
    Dim objCon As New OracleClient.OracleConnection
    Dim dbCon As New DatabaseConnection.cDBConnection
    Dim o_errmsg As String
    Dim objCmd As New OracleClient.OracleCommand
    Dim drint As OracleClient.OracleDataReader
    Dim strResult, strResult1 As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strsql As String
        Try

        
        mystr = Request.Form("hidpend")
        '' database connection
        objCon = dbCon.GetDbConnection(o_errmsg)
        If o_errmsg <> "" Then
            o_errmsg = "Failed To Connect To DataBase"
            Throw New Exception(o_errmsg)
        End If
            strResult = "" : strResult1 = ""
            If Len(mystr) > 0 Then
                strmode = Split(mystr, "~*~")
                strvalues = Split(strmode(0), "|")
                rows = strmode(1)

                For i = 0 To UBound(strvalues) - 1

                    strcols = Split(strvalues(i), "~")
                    strRefno = strcols(0)
                    appdate1 = strcols(1)



                    strsql = "select ACCNO from impsbrchanfundstrnsdtls where sentyn = 'N' and  APPLICATIONDATE = '" & Format(CDate(appdate1), "dd-MMM-yyyy") & "' and REFNO37 = '" & strRefno & "' and SERVICEID = 'OUTWRD' and  TRANSTATUS='P'"
                    objCmd = New OracleClient.OracleCommand(strsql, objCon)
                    drint = objCmd.ExecuteReader
                    objCmd.Dispose()
                    objCmd = Nothing
                    If drint.HasRows = True Then
                        strsql = "update impsbrchanfundstrnsdtls set TRANSTATUS = 'A' where sentyn = 'N' and  APPLICATIONDATE = '" & Format(CDate(appdate1), "dd-MMM-yyyy") & "' and REFNO37 = '" & strRefno & "' and SERVICEID = 'OUTWRD' and  TRANSTATUS='P'"
                        objCmd = New OracleClient.OracleCommand(strsql, objCon)
                        objCmd.ExecuteNonQuery()

                    End If
                    drint.Close()
                    drint = Nothing
                    strResult1 = strResult1 & strRefno & ", "
                Next
                strResult = "Transaction Approved Successfull For Reference No " & strResult1
            End If
            Response.Redirect("frmIMPSRefNoOutwrdApprovals.aspx?st=" & strResult, False)
            Exit Sub
        Catch ex As Exception
            Response.Redirect("frmIMPSRefNoOutwrdApprovals.aspx?st=" & ex.Message, False)
        End Try
    End Sub

End Class
