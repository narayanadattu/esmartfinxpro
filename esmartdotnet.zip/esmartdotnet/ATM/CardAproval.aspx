<%@ Page Language="vb" explicit="false" aspcompat="true" AutoEventWireup="false" Codebehind="CardAproval.aspx.vb" Inherits="eSmartDotNet.CardAproval" %>
<%

  dim QryStr,strResult
  dim arrParam
  dim iCnt
  dim arrtrans(0,4)
  rs=server.CreateObject("adodb.recordset")
  obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  objTran=SERVER.CreateObject("GeneralTransactions.DBTransactions")
  
  appdate=session("applicationdate")
  userid=session("userid")
  machineid=session("machineid")
  
  QryStr=request.QueryString("st")
  arrParam=split(QryStr,"|")
  strResult=""

  if arrParam(0)="Approve" then
    
    arrtrans(0,0)="U"
    arrtrans(0,1)="ATMCRDDTLS"
    arrtrans(0,2)="TRANSTATUS,APPROVEDBY, APPROVEDMACHINE"
    arrtrans(0,3)="'A'~'" & userid & "'~'" & machineid & "' "
    arrtrans(0,4)="BRANCHCODE='" & arrParam(1) & "' AND " & _
				  "REFNUM IN "& arrParam(3)
	strResult=objTran.DataTransactions(arrtrans)
	
  end if
	
%>
<html>
  <head>
    <title>CardApproval</title>
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <script language="javascript">
    function List()
    {
      	var strQuery="<%=QryStr%>"
		var arrStrVal
		arrStrVal=strQuery.split("|")
		var type=arrStrVal[0]
		
		if(type=="Approve")
		{
		window.attachEvent(window.parent.ApprStatus('<%=strResult%>'))
		window.close()
		}
		
	}
    </script>
  </head>
  
   <body onload="List()">

    <form name="frmApprQry">
        <input type="hidden" name="hdnapprQry" value="">
    </form>

  </body>
</html>