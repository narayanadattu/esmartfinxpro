<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmATMGLLink.aspx.vb" Inherits="eSmartDotNet.frmATMGLLink"%>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">

<title>ATM GL Link</title>
<meta content="text/html; charset=windows-1252" http-equiv="Content-Type">
<meta content="Microsoft FrontPage 4.0" name="GENERATOR">
<meta content="FrontPage.Editor.Document" name="ProgId">

<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE="javascript">

function GLLnkCode()
{
var mode
window.document.frmAtmOpen.txtGLLnkcode.value = ""
window.document.frmAtmOpen.txtGLLnkDesc.value = ""
window.document.frmAtmOpen.txtModcode.value = ""
window.document.frmAtmOpen.txtModdesc.value = ""
window.document.frmAtmOpen.txtGlcode.value = ""
window.document.frmAtmOpen.txtGldesc.value = ""
window.document.frmAtmOpen.txtAccountno.value = ""
window.document.frmAtmOpen.txtNarration.value = ""

if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{	
	mode = "NEW"
	}
if(window.document.frmAtmOpen.rdCheckedMod.checked==true)
	{
	mode = "MODIFY"
	}
if(window.document.frmAtmOpen.rdCheckedDel.checked==true)
	{
	mode = "DELETE"
	}
	
	st="GLLNKCODE"+ "|" + mode
		window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:350px;DialogHeight:180px;DialogLeft:225px;DialogTop:190px")

		

}

 function GLLnkDesc(kstr)
{	
	assign(kstr,window.document.frmAtmOpen.txtGLLnkDesc,window.document.frmAtmOpen.txtGLLnkcode)      	    
	if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{
	}
	else
	{
	GetATMGLLNKDetails()
	}
}

function GetATMGLLNKDetails()
{
var gllnkcode = window.document.frmAtmOpen.txtGLLnkcode.value
st="ATMGLLNKDTLS|" + gllnkcode
window.document.all['iGetDtls'].src="getDtls.aspx?st="+st
}

function GetGLLNKDETAILS(kstr)
{
	var StrFld=new String()
	StrFld=kstr.split("~")
	window.document.frmAtmOpen.txtGLLnkcode.value = StrFld[0]
	window.document.frmAtmOpen.txtGLLnkDesc.value = StrFld[1]
	window.document.frmAtmOpen.txtModcode.value = StrFld[2]
	window.document.frmAtmOpen.txtModdesc.value = StrFld[3]
	window.document.frmAtmOpen.txtGlcode.value = StrFld[4]
	window.document.frmAtmOpen.txtGldesc.value = StrFld[5]
	window.document.frmAtmOpen.txtAccountno.value = StrFld[6]
	window.document.frmAtmOpen.txtNarration.value = StrFld[7]
}

 function Module()
 {
 window.document.frmAtmOpen.txtModcode.value = ""
window.document.frmAtmOpen.txtModdesc.value = ""
window.document.frmAtmOpen.txtGlcode.value = ""
window.document.frmAtmOpen.txtGldesc.value = ""
window.document.frmAtmOpen.txtAccountno.value = ""
window.document.frmAtmOpen.txtNarration.value = ""

 	var gllnkcode=window.document.frmAtmOpen.txtGLLnkcode.value
	
	if(gllnkcode=="")
	{
		alert("GL Lnk Code should not be null..") 
		return;
	}

	st="INVMISCPL"
	window.showModalDialog("atmlist.aspx" + "?"+"st="+st,window,"status:no;"+
		"DialogWidth:380px;DialogHeight:170px;DialogLeft:560px;DialogTop:190px")

 }
 
function ModuleDesc(kstr)
{	
	assign(kstr,window.document.frmAtmOpen.txtModdesc,window.document.frmAtmOpen.txtModcode)      	    
}
 

function Glcode()
{ 

window.document.frmAtmOpen.txtGlcode.value = ""
window.document.frmAtmOpen.txtGldesc.value = ""
window.document.frmAtmOpen.txtAccountno.value = ""
window.document.frmAtmOpen.txtNarration.value = ""
		
	if(window.document.frmAtmOpen.txtGLLnkcode.value=="")
	{
		alert("GL Lnk Code should not be null..") 
		return
	}
	 
	if(window.document.frmAtmOpen.txtModcode.value=="")
	{
		alert("Please Select Module Code")
		return;
	}


	telgl="GLLNKGLCODE";
	gllnkcode=window.document.frmAtmOpen.txtGLLnkcode.value.toUpperCase();
	modcode=window.document.frmAtmOpen.txtModcode.value.toUpperCase();
	
	kstr=telgl+"|999"+"|"+modcode
	
	if(modcode!=""){
		 window.showModalDialog("atmList.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	 } 
}
//Assign Selected GL code and GL desc to the Textboxes.	

function Glcodeid(kstr)
 {
 
  
	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmAtmOpen.txtGlcode.value=StrFld[1]
	window.document.frmAtmOpen.txtGldesc.value=StrFld[0]
} 	 


function getGlcode()
{
var st

	if(window.document.frmAtmOpen.txtGLLnkcode.value=="")
	{
		alert("GL Lnk Code should not be null..") 
		return
	}
	 
	if(window.document.frmAtmOpen.txtModcode.value=="")
	{
		alert("Please Select Module Code")
		return;
	}
	
	if(window.document.frmAtmOpen.txtGlcode.value=="")
	{
		alert("Please Select GL Code")
		return;
	}


modcode=window.document.frmAtmOpen.txtModcode.value.toUpperCase();
glcode = window.document.frmAtmOpen.txtGlcode.value
st="GETGLLNKGLCODE|999|" + modcode+"|"+glcode
window.document.all['iGetDtls'].src="getDtls.aspx?st="+st
}

function getglcodedescription(kstr)
{
if (kstr == "No Record")
{
	alert("Invalid GL Code")
	window.document.frmAtmOpen.txtGlcode.value=""
	return
}
else
{
window.document.frmAtmOpen.txtGldesc.value = kstr
}
}


function Accountno()
{ 

window.document.frmAtmOpen.txtAccountno.value = ""
window.document.frmAtmOpen.txtNarration.value = ""

		
	if(window.document.frmAtmOpen.txtGLLnkcode.value=="")
	{
		alert("GL Lnk Code should not be null..") 
		return
	}
	 
	if(window.document.frmAtmOpen.txtModcode.value=="")
	{
		alert("Please Select Module Code")
		return;
	}

	if(window.document.frmAtmOpen.txtGlcode.value=="")
	{
		alert("Please Select GL Code")
		return;
	}


	telgl="GLLNKACCNO";
	gllnkcode = window.document.frmAtmOpen.txtGLLnkcode.value.toUpperCase();
	modcode = window.document.frmAtmOpen.txtModcode.value.toUpperCase();
	glcode = window.document.frmAtmOpen.txtGlcode.value.toUpperCase();
	
	kstr=telgl+"|"+modcode+"|"+glcode
	
	if(glcode!=""){
		 window.showModalDialog("atmList.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	 } 
}

//Assign Selected account no and account desc to the Textboxes.	

function AccountDesc(kstr)
 { 
 	var StrFld=new String()
	StrFld=kstr.split("-----")
	window.document.frmAtmOpen.txtAccountno.value=StrFld[1]
	window.document.frmAtmOpen.txtNarration.value=StrFld[0]
} 	 

function getaccountno()
{
	
	if(window.document.frmAtmOpen.txtGLLnkcode.value=="")
	{
		alert("GL Lnk Code should not be null..") 
		return
	}
	if(window.document.frmAtmOpen.txtModcode.value=="")
	{
		alert("Please Select Module Code")
		return;
	}
	if(window.document.frmAtmOpen.txtGlcode.value=="")
	{
		alert("Please Select GL Code")
		return;
	}
	if (window.document.frmAtmOpen.txtAccountno.value == "")
	{
		alert("A/C No Should not be Null");
		return;
	}
	
	telgl="GETGLLNKACCNO";
	gllnkcode = window.document.frmAtmOpen.txtGLLnkcode.value.toUpperCase();
	modcode = window.document.frmAtmOpen.txtModcode.value.toUpperCase();
	glcode = window.document.frmAtmOpen.txtGlcode.value.toUpperCase();
	accno = window.document.frmAtmOpen.txtAccountno.value.toUpperCase();
	
	st= telgl +"|"+ modcode +"|"+ glcode + "|" + accno
	
	if(accno!=""){
	window.document.all['iGetDtls'].src="getDtls.aspx?st="+st
	 } 
}

function GetAccountDesc(kstr)
 { 
	window.document.frmAtmOpen.txtNarration.value=kstr
} 	 


function fillonload()
{
	var prec=eval('<%=session("PRECISION")%>')
	var precval="1"
	
     for(icnt=0;icnt<prec;icnt++)
 	  var precval=precval+"0"
      window.document.frmAtmOpen.hidprecision.value=prec //precval	  
	   
     //window.document.frmAtmOpen.butAccno.style.display="none"
     //window.document.frmAtmOpen.txtNarration.style.display="none"
}

function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="frmATMGLLink.aspx" 
		
	}
}	

function OK()
{
	var GLLnkcode = window.document.frmAtmOpen.txtGLLnkcode.value;
	var Modcode =window.document.frmAtmOpen.txtModcode.value;
	var Glcode =window.document.frmAtmOpen.txtGlcode.value;
	var Accountno =window.document.frmAtmOpen.txtAccountno.value;

	if(GLLnkcode=="")
	{
		alert("GL Link Code should not be null..") 
		return;
	}
	else if(Modcode=="")
	{
		alert("Module Id should not be null..") 
		return;
	}
	else if(Glcode=="")
	{
		alert("Gl Code should not be null..") 
		return;
	}
	else if(Accountno=="")
	{
		alert("A/C No Should not be Null");
		return;
	}

	if(window.document.frmAtmOpen.rdCheckedNew.checked==true)
	{	
		st="ATMGLLnknew";
		window.document.frmAtmOpen.action="frmATMGLLinkinsert.aspx" + "?"+"st="+st 
		window.document.frmAtmOpen.method ="post"
		window.document.frmAtmOpen.submit()
	}
	
	if(window.document.frmAtmOpen.rdCheckedMod.checked==true)
	{
		st="ATMGLLnkmodify";
		window.document.frmAtmOpen.action="frmATMGLLinkinsert.aspx" + "?"+"st="+st 
		window.document.frmAtmOpen.method ="post"
		window.document.frmAtmOpen.submit()
	}
	if(window.document.frmAtmOpen.rdCheckedDel.checked==true)
	{
		st="ATMGLLnkdelete";
		window.document.frmAtmOpen.action="frmATMGLLinkinsert.aspx" + "?"+"st="+st 
		window.document.frmAtmOpen.method ="post"
		window.document.frmAtmOpen.submit()
	}
}

function funformclear()
{
	window.document.frmAtmOpen.txtGLLnkcode.value="";
	window.document.frmAtmOpen.txtGLLnkDesc.value="";
	window.document.frmAtmOpen.txtModcode.value="";
	window.document.frmAtmOpen.txtModdesc.value="";
	window.document.frmAtmOpen.txtGlcode.value="";
	window.document.frmAtmOpen.txtGldesc.value="";
	window.document.frmAtmOpen.txtAccountno.value="";
	window.document.frmAtmOpen.txtNarration.value="";
}

</SCRIPT>
</head>
<body onload="fillonload();GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();" topmargin="0" leftmargin="0">

<form name="frmAtmOpen" >
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="100%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
        <div class="menuBar">
            <table cellpadding="0" cellspacing="0" width="100%" border=0>
                <tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                   
                    <td width="50%" align="CENTER" height="22" class="subHeader">
                        <h2>ATM GL Link</h2>
                    </td>
                    <td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
                </tr>
            </table>
        </div>
        <div id="menucontrol"></div> 
  <input type="hidden" name="hmodify"><input type="hidden" name="hinsert"><input type="hidden" name="hreturn"><input type="hidden" name="hchange">
  <div align="center" >
    <center>
    <%appdate=formatdatetime(session("applicationdate"),1)%>

    <table border="0" cellpadding="0" cellspacing="0" width="100%" class="tablebordermain">
      <tbody>
        <tr>
          <td>
          <table border="0" width="100%" cellspacing="0" cellpadding="0" height="20">
          </table>
          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
						<td width="300" align="right"><input type="radio" name="optCheck" id=rdCheckedNew onclick="modeState();funformclear()" checked>New</td>
						<td width="300" align="right"><input type="radio" name="optCheck" id=rdCheckedMod onclick="modeState();funformclear()" >Modify</td>
						<td width="300" align="right"><input type="radio" name="optCheck" id=rdCheckedDel onclick="modeState();funformclear()" >Delete</td>
					</tr>
          </table>
          <table class="tablebordermain" cellpadding="0" cellspacing="0" width="100%">
            <tbody>
              <tr>
                <td>
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tbody>
                    <tr>
                      <td align="center" width="150%" height="15" colspan="2">
                      <font class="textblue">
                      <span id="result" style="display:none"><%=result%></span>
                      </font>
                      </td>
                      <td></td>
                    </tr>
                        </tr>
                  </tbody>
                </table>
                <div align="center">
                  <table cellpadding="0" cellspacing="0" width="100%" class="tablebordermain">
                    <tbody>
                      <tr>
                        <td valign="top" width="100%">
                        <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                          <tr>
                            <td valign="top" width="100%">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                              <tbody>
                                <tr>
                                  <td width="100%">
                                  <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                      <tr>
                                        <td valign="top" width="86%">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                          <tbody>
                                            <tr>
                                              <td valign="top" width="100%">
                                              <table border="0" width="100%" cellspacing="0" cellpadding="0" height="132">
                                                <tr>
                                                  <td align="left" width="12%" height="27">&nbsp;GL Lnk Code</td>
                                                  <td align="left" width="38%" height="27"><input maxlength="10" name="txtGLLnkcode" readonly class="txtautofill" size="10" style="text-align:left" readonly value=""><input name="butgllnkcd" onclick="GLLnkCode()" type="button" value=" L "><input class="bgcolor1" name="txtGLLnkDesc" size="18" readonly value="" class="bgcolor1"></td>
                                                  <td align="left" width="12%" height="27">&nbsp;Module ID</td>
                                                  <td align="left" width="38%" height="27">    <input name="txtModcode" size="10" class="txtautofill" maxlength="6" value="" onblur="getModule()" style="text-transform:uppercase"><input name="butModid" onclick="Module()" type="button" value=" L " ><input name="txtModdesc" class="bgcolor1" size="18"  value=""></td>
                                                </tr>
                                                <tr>
                                                  <td width="13%" height="27">&nbsp;GL Code</td>
                                                  <td align="left" width="38%" height="27">
                                                  <input name="txtGlcode"  onkeypress="Alphanum()"  size="10" class="txtautofill" maxlength="6" onkeyup='window.document.frmAtmOpen.txtGldesc.value=""' onblur="getGlcode()" style="text-transform:uppercase"><input name="butGlid" onclick="Glcode()" type="button" value=" L "><input name="txtGldesc" size="18" class="bgcolor1" readonly></td>
                                                  <td align="left" width="13%" height="27">&nbsp;Acc.No.</td><td align="left" width="38%" height="27"><input name="txtAccountno" class="txtautofill" size="10" maxlength="20" style="text-transform:uppercase" onkeyup='window.document.frmAtmOpen.txtNarration.value=""' onblur="getaccountno()" onkeypress="Alphanum()" ><input name="butAccno" onclick="Accountno()" type="button" value=" L " ><input name="txtNarration" class="bgcolor1" size="18" style="text-transform:uppercase"></td>
                                                </tr>

<tr><td></td><td></td></tr></table><div id="dstatus" style="width: 213; height:13">
                                      </div>
          </center></td>                                
                                          </tbody>
                                          <tr>
                                            <td>
                                              <div id="divFlex" style="display: none; width: 310; height: 19"></div>
                                            </td>
                                          </tr>
                                        </table>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            </td>
                          </tr>
                        </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                
            </tbody>
          </table>

	<table width = "100%" class="tablebordermain">
    <tr>
      <td align="center" width = "100%">       
       <input name="butok" onclick="OK()" type="button" value="  Ok  " class="button"><input name="butcancel" type="button" value=" Cancel " onclick="location.replace(&quot;ATMOpening.aspx&quot;)" class="button"><input id="Butexit" name="Butexit" type="button" value="    Exit    " onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;" class="button">
       </td>
       </tr>
       <tr>
       <td>
		
      </td>
    </tr>
  </table>
          
          <input name="hidprecision" type="hidden"> 
          <input type ="hidden" id="txtChk" name="txtChk">  
          <IFRAME id=iGetDtls style="DISPLAY: block" align=center frameSpacing=0 src="getDtls.aspx" frameBorder=0 width=0 height=0></IFRAME>      
          </form>
        </td>
      </tr>
    </table>
  </div>

  <iframe src="list.aspx" width=0 height=0></iframe>
 <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
</body>
</html>
