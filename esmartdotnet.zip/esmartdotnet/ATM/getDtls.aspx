<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="getDtls.aspx.vb" Inherits="eSmartDotNet.getDtls2"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<%
dim strcond_mob,strcondbrcode , craccno,crname,crremarks
strVal=request.querystring("st")
if Len(strVal) > 0 then
strArr=split(strVal,"|")
obj = server.CreateObject("ReportPurposeOnly.Reportonly")
rs = Server.CreateObject("adodb.recordset")
rs1 = Server.CreateObject("adodb.recordset")
dim strNFTSCONVYN
	dim rsBnk,objBnk,frmname
	rsBnk=server.CreateObject("adodb.recordset")
	objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsBnk=objBnk.singlerecordset("genbankparm","depcertificate,NFTSCONVYN","")
	
	if objBnk.ConnError="Connected" then	
		if not rsBnk.EOF and not rsBnk.BOF then
			frmname=rsBnk(0).value
			strNFTSCONVYN = iif(isdbnull(rsBnk(1).value),"N",rsBnk(1).value)
		end if
	end if
	
if strArr(0)="GetAccountNo" then
sqlstr="SELECT NVL(MAX(accno),0)+1 FROM atmmst WHERE glcode = '"& strArr(2) &"'"
rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetAccountNoIDS" then
sqlstr="SELECT name FROM atmmst WHERE  glcode = '201001' and branchcode = '"& strArr(1) &"' and accno = '"& strArr(2) &"'"
rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetIMPSAccountNoIDS" then
sqlstr="SELECT name FROM atmmst WHERE glcode = '201002' and branchcode = '"& strArr(1) &"' and accno = '"& strArr(2) &"'"
rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetIMPSValidReferenceNo" then

sqlstr= "SELECT REFNO37,REFNO37 REFNO371 FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE REFNO37 = '"& strArr(1) &"' and  m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD'  AND m.refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE status = 'Y' AND  SERVICEID ='OUTWRR' AND refnum = m.refnum)"


rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetATMValidReferenceNo" then

sqlstr = "SELECT refnum FROM atmlogdtls a WHERE refnum = '"& strArr(1) &"' and  serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y' AND refnum NOT IN (SELECT refnum  FROM atmlogdtls WHERE status= a.status AND SERVICEID IN ('NDEBRV','FDEBRV','PSRREQ','ECRREQ','CHPRRQ') AND refnum = a.refnum) ORDER BY 1"

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetIMPSMOBValidReferenceNo" then


sqlStr =  "SELECT refnum  FROM impslogdtls i WHERE refnum = '"& strArr(1) &"' and  atmlocation = 'P2AO MOB' AND serviceid = 'OUTWRD'  AND status = 'Y' AND  refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE SERVICEID ='OUTWRR' AND refnum = i.refnum)  ORDER BY 1"
rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetCustTrnsAccName" then

sqlstr="SELECT  DISTINCT NAME   FROM "& strArr(3) &"tranday WHERE BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"' AND glcode = '"& strArr(4) &"' AND accno = '"& strArr(5) &"' AND chqfvg = 'ATM' " & _
" UNION " & _
" SELECT DISTINCT NAME   FROM "& strArr(3) &"tran WHERE BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"' AND glcode = '"& strArr(4) &"' AND accno = '"& strArr(5) &"' AND chqfvg = 'ATM'"

rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			

elseif strArr(0)="GetNACHTransAccName"  then


sqlStr = "select  BENEFICIARYNAME  from nachtrandtls where BENEACCNUM = '"& strArr(5) &"' and substr(BENEACCNUM,1,3) = '"& strArr(1) &"' and substr(BENEACCNUM,4,6) = '"& strArr(4) &"' and nachtype = '"& strArr(6) &"'"


rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if		
elseif strArr(0)="GetNACHCBDTLICTransAccName" then
if strArr(6) = "CBDT" then
sqlStr = "select  PRIACCHOLDNAME   from NACHCBDTINPTRANDTLS where ACCOUNTNO = '"& strArr(5) &"' and substr(ACCOUNTNO,1,3) = '"& strArr(1) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(4) &"' and nachtype = 'CBDT'"
else if strArr(6) = "LIC" then
sqlStr = "select  BENENAMERESP   from NACHLICIINPTRANDTLS where ACCOUNTNO = '"& strArr(5) &"' and substr(ACCOUNTNO,1,3) = '"& strArr(1) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(4) &"' and nachtype = 'LICI'"
else if strArr(6) = "GSTD" then
sqlStr = "select  PRIACCHOLDNAME   from NACHGSTDINPTRANDTLS where ACCOUNTNO = '"& strArr(5) &"' and substr(ACCOUNTNO,1,3) = '"& strArr(1) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(4) &"' and nachtype = 'GSTD'"
end if

rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if		

elseif strArr(0)="GetH2HTransAccName" then

'sqlstr="SELECT  DISTINCT NAME   FROM "& strArr(3) &"tranday WHERE BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"' AND glcode = '"& strArr(4) &"' AND accno = '"& strArr(5) &"' AND  RESPONDINGBANKCODE IN ('NEFTOW','RTGSOW') " & _
'" UNION " & _
'" SELECT DISTINCT NAME   FROM "& strArr(3) &"tran WHERE BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"' AND glcode = '"& strArr(4) &"' AND accno = '"& strArr(5) &"' AND  RESPONDINGBANKCODE IN ('NEFTOW','RTGSOW') "
''AND chqfvg = '"& strArr(6) &"'"

if  strArr(7) = "OUTWARD" THEN
		
		sqlstr= "select name from neftrtgsdtls where neftrtgs = '"& strArr(6) &"' and refno is not null  and branchcode ='"& strArr(1) &"' and glcode ='"& strArr(4) &"' AND accno = '"& strArr(5) &"'" 
	elseif strArr(7) = "INWARD" THEN
	
	if strArr(6) = "NEFT" then
	sqlstr= "SELECT BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTIW' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& strArr(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& strArr(4) &"'  AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	
	else if  strArr(6) = "RTGS" then
	sqlstr= "SELECT BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSIW' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& strArr(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& strArr(4) &"'  AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	end if
	
	elseif strArr(7) = "OUTWARDRETURN" THEN
	
	if strArr(6) = "NEFT" then
	sqlstr= "SELECT BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTOR' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& strArr(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& strArr(4) &"' AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	
	else if  strArr(6) = "RTGS" then
	sqlstr= "SELECT BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSOR' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& strArr(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& strArr(4) &"'   AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	end if
	
	elseif strArr(7) = "INWARDRETURN" THEN
	
	if strArr(6) = "NEFT" then
	sqlstr= "SELECT BENCUSTACCNAME FROM neftinwarddtls WHERE trantype = 'NEFTIR' AND SUBSTR(BENCUSTACCNUM,1,3) =  '"& strArr(1) &"' AND SUBSTR(BENCUSTACCNUM,4,6) =  '"& strArr(4) &"'   AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	
	else if  strArr(6) = "RTGS" then
	sqlstr= "SELECT BC_RECNAMEADD_F5561_2  FROM RTGSINWARDDTLS WHERE trantype = 'RTGSIR' AND SUBSTR(BC_RECACCNUM_F5561_1,1,3) =  '"& strArr(1) &"' AND SUBSTR(BC_RECACCNUM_F5561_1,4,6) =  '"& strArr(4) &"'   AND LTRIM(SUBSTR(BENCUSTACCNUM,10,7),'0') = '"& strArr(5) &"'"
	end if
	
   end if
   

rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if			


elseif strArr(0)="ATMCUSTTRANSDETMODALL" then

if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM sbtranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
'" UNION ALL " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM sbtran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond &  _
'" UNION ALL " & _
'"SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM catranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM catran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & _ 
'"  UNION ALL  " & _
'"SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM cctranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM cctran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by APPLICATIONDATE,ACCNO "

sqlstr="SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM sbtranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
" UNION ALL " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM sbtran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond &  _
" UNION ALL " & _
"SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM catranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM catran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & _ 
"  UNION ALL  " & _
"SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM cctranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM cctran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by EFFECTIVEDATE,ACCNO "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMCUSTTRANSDETACCALL" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by APPLICATIONDATE,ACCNO "

sqlstr="SELECT EFFECTIVEDATE, to_number(ACCNO) ACCNO,NAME, AMOUNT,remarks   FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE, to_number(ACCNO),NAME, AMOUNT,remarks   FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by EFFECTIVEDATE,ACCNO "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMCUSTTRANSDETACCSIN" then

if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE,MODULEID, GLCODE, Batchno,tranno, AMOUNT,remarks   FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' and accno = '"& strArr(8) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE,Batchno,tranno,AMOUNT,remarks   FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' and accno = '"& strArr(8) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by APPLICATIONDATE,Batchno,tranno"

sqlstr="SELECT EFFECTIVEDATE,MODULEID, GLCODE, Batchno,tranno, AMOUNT,remarks   FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' and accno = '"& strArr(8) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE,Batchno,tranno,AMOUNT,remarks   FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' and accno = '"& strArr(8) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " order by EFFECTIVEDATE,Batchno,tranno"

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMCUSTTRANSSUMMODALL" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM sbtranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM sbtran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME " & _
'"  UNION ALL  " & _
'"SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM catranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM catran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME " & _
'"  UNION ALL  " & _
'"SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM cctranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM cctran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME order by APPLICATIONDATE,ACCNO "

sqlstr="SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM sbtranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM sbtran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME " & _
"  UNION ALL  " & _
"SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM catranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM catran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME " & _
"  UNION ALL  " & _
"SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM cctranday WHERE chqfvg = 'ATM' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM cctran WHERE chqfvg = 'ATM' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME order by EFFECTIVEDATE,ACCNO "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMCUSTTRANSSUMACCALL" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE,ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME order by APPLICATIONDATE,ACCNO "

sqlstr="SELECT EFFECTIVEDATE, ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,ACCNO ,NAME, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME order by EFFECTIVEDATE,ACCNO "


rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMCUSTTRANSSUMACCSIN" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
	
'sqlstr="SELECT APPLICATIONDATE, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and accno = '"& strArr(8) &"' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
'"  UNION ALL  " & _
'" SELECT APPLICATIONDATE, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and accno = '"& strArr(8) &"' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by APPLICATIONDATE,MODULEID, GLCODE, ACCNO ,NAME order by APPLICATIONDATE "

sqlstr="SELECT EFFECTIVEDATE, SUM(AMOUNT) Amount,COUNT(*) nooftrans FROM " & strArr(6) & "tranday WHERE chqfvg = 'ATM' and accno = '"& strArr(8) &"' and glcode = '"& strArr(7) &"' AND BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond  & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME  " &  _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE, SUM(AMOUNT) Amount,COUNT(*) nooftrans  FROM " & strArr(6) & "tran WHERE chqfvg = 'ATM' and accno = '"& strArr(8) &"' and glcode = '"& strArr(7) &"' AND  BRANCHCODE ='"& strArr(1) &"' AND CURRENCYCODE ='"& strArr(2) &"'" & strcond & " group by EFFECTIVEDATE,MODULEID, GLCODE, ACCNO ,NAME order by EFFECTIVEDATE "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			


elseif strArr(0)="ATMTRANSDETALL" then
if strArr(3) <> "Between" then
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
else
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
end if
if strArr(6) = "ALL" then
	strtnxtypecond = ""
elseif strArr(6) = "ONUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'NWDRRQ'"
elseif strArr(6) = "OFFUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'FWDRRQ'"
elseif strArr(6) = "LORO" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'LWDRRQ'"
end if
'sqlstr="SELECT APPLICATIONDATE,ACCNO, name, AMOUNT, REMARKS,RATEREFCODE  FROM atmtranday  WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & _
'" union all " & _
'"SELECT APPLICATIONDATE,ACCNO, name, AMOUNT, REMARKS,RATEREFCODE  FROM atmtran  WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & " order by APPLICATIONDATE,ACCNO "

sqlstr="SELECT EFFECTIVEDATE,ACCNO, name, AMOUNT, REMARKS,RATEREFCODE  FROM atmtranday WHERE CHQFVG != 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & " " & strtnxtypecond &  _
" union all " & _
"SELECT EFFECTIVEDATE,ACCNO, name, AMOUNT, REMARKS,RATEREFCODE  FROM atmtran WHERE CHQFVG != 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & " " & strtnxtypecond & " order by EFFECTIVEDATE,ACCNO"

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMTRANSDETATM" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if


 if strArr(7) = "ALL" then
	strtnxtypecond = ""
elseif strArr(7) = "ONUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'NWDRRQ'"
elseif strArr(7) = "OFFUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'FWDRRQ'"
elseif strArr(7) = "LORO" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'LWDRRQ'"
end if
'sqlstr="SELECT APPLICATIONDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,mstno  FROM atmtranday  WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & _
'" union all " & _
'"SELECT APPLICATIONDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,mstno  FROM atmtran  WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " order by  APPLICATIONDATE,mstno"

sqlstr="SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,mstno  FROM atmtranday  WHERE  CHQFVG != 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " " & strtnxtypecond & _
" union all " & _
"SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,mstno  FROM atmtran  WHERE CHQFVG != 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " " & strtnxtypecond & " order by  EFFECTIVEDATE,mstno"

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			

elseif strArr(0)="IMPSTRANSDET" then
dim strBenRemarks

if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
if strArr(8) = "ALL" then
strcondtnxtype = ""
else
strcondtnxtype = " and substr(RESPONDINGBANKCODE,1,6) = '"& strArr(8) &"'"
end if 
if strArr(7) = "ALL" then
sqlstr="SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,RESPONDINGSECTIONCODE,mstno, LINKMODULEID, LINKGLCODE, LINKACCNO, applicationdate  FROM atmtranday  WHERE CHQFVG = 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " " & strcondtnxtype & _
" union all " & _
"SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,RESPONDINGSECTIONCODE,mstno, LINKMODULEID, LINKGLCODE, LINKACCNO, applicationdate  FROM atmtran  WHERE CHQFVG = 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype & " order by  EFFECTIVEDATE,mstno"
else
sqlstr="SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,RESPONDINGSECTIONCODE,mstno, LINKMODULEID, LINKGLCODE, LINKACCNO, applicationdate  FROM atmtranday  WHERE CHQFVG = 'IMPS' and RESPONDINGSECTIONCODE = '"& strArr(7) &"' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype &  _
" union all " & _
"SELECT EFFECTIVEDATE,batchno,tranno, AMOUNT, REMARKS,RATEREFCODE,RESPONDINGSECTIONCODE,mstno, LINKMODULEID, LINKGLCODE, LINKACCNO, applicationdate  FROM atmtran  WHERE CHQFVG = 'IMPS' and RESPONDINGSECTIONCODE = '"& strArr(7) &"' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype &  " order by  EFFECTIVEDATE,mstno"
end if

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				strBenRemarks = ""
				sqlstr= " SELECT remarks FROM gentranslog WHERE batchno ='"& rs(1).value &"' AND moduleid ='"& rs(8).value &"' AND glcode ='"& rs(9).value &"'  AND accno ='"& rs(10).value &"' AND applicationdate ='"& format(cdate(rs(11).value),"dd-MMM-yyyy") &"'" & _ 
" UNION ALL " & _ 
" SELECT remarks FROM gentranslogbkp WHERE batchno ='"& rs(1).value &"' AND moduleid ='"& rs(8).value &"' AND glcode ='"& rs(9).value &"'  AND accno ='"& rs(10).value &"' AND applicationdate ='"& format(cdate(rs(11).value),"dd-MMM-yyyy") &"'"

					rs1=obj.SingleSelectStat(sqlstr)				
				if obj.ConnError="Connected" then
					if not rs1.BOF and not rs1.EOF then
						strBenRemarks =  rs1(0).value
					end if
				end if
				
				
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & strBenRemarks & "~" & rs(5).value & "~" & rs(6).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			

else if strArr(0)="GetIMPSByDateDtls" then

if strArr(1) <> "Between" then
strcond = " and TO_DATE(TO_CHAR(i.APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')  " & strArr(1) & " '" &  strArr(2) &"'"
else
strcond = " and TO_DATE(TO_CHAR(i.APPLICATIONDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy')  between '" &  strArr(2) &"' and  '" &  strArr(3) &"'"
end if


sqlstr= "SELECT REFNO37,i.APPLICATIONDATE, REMACCNO1022,REMNAME1252, BENACCNO1032, BENNAME,m.BATCHNO,m.serviceid,m.refnum FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD' " & strcond & " AND m.refnum NOT IN (SELECT refnum  FROM impslogdtls WHERE status = 'Y' AND  SERVICEID ='OUTWRR' AND refnum = m.refnum) "

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value   & "~" & rs(8).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if
	
	
	else if strArr(0)="GetBRCHANIMPSByRefnoTrackDtls" then

sqlstr= "SELECT REFNO37,APPLICATIONDATE, REMACCNO1022,REMNAME1252, BENACCNO1032, BENNAME,sentyn,serviceid FROM impsbrchanfundstrnsdtls WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y' and REFNO37 ='"& strArr(1) &"' ORDER BY APPLICATIONDATE,ACCNO"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if		
else if strArr(0)="GetBRCHANIMPSByDateTrackDtls" then

if strArr(1) <> "Between" then
strcond = " and APPLICATIONDATE " & strArr(1) & " '" &  strArr(2) &"'"
else
strcond = " and APPLICATIONDATE between '" &  strArr(2) &"' and  '" &  strArr(3) &"'"
end if


sqlstr= "SELECT REFNO37,APPLICATIONDATE, REMACCNO1022,REMNAME1252, BENACCNO1032, BENNAME,sentyn,serviceid FROM impsbrchanfundstrnsdtls i WHERE transtatus= 'A' AND SERVICEID ='OUTWRD' and sentyn = 'Y'   " & strcond & ""

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value & "~" & rs(7).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if	
	
else if strArr(0)="GetBRCHANIMPSByRefnoDtls" then

sqlstr= "SELECT REFNO37,APPLICATIONDATE, MODULEID, GLCODE, ACCNO,REMNAME1252, BENACCNO1032, BENNAME,sentyn,serviceid,(TRNSAMOUNT4/100) trnsamount, BENIFSCCODE1272,CHQEQUENO FROM impsbrchanfundstrnsdtls WHERE transtatus= 'P' AND SERVICEID ='OUTWRD' and sentyn = 'N' and REFNO37 ='"& strArr(1) &"' and branchcode = '"& strArr(2) &"'  ORDER BY APPLICATIONDATE,ACCNO"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value  & "~" & rs(8).value  & "~" & rs(9).value & "~" & rs(10).value  & "~" & rs(11).value  & "~" & rs(12).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

else if strArr(0)="GetBRCHANIMPSByDateDtls" then

if strArr(1) <> "Between" then
strcond = " and APPLICATIONDATE " & strArr(1) & " '" &  strArr(2) &"'"
else
strcond = " and APPLICATIONDATE between '" &  strArr(2) &"' and  '" &  strArr(3) &"'"
end if


sqlstr= "SELECT REFNO37,APPLICATIONDATE, MODULEID, GLCODE, ACCNO,REMNAME1252, BENACCNO1032, BENNAME,sentyn,serviceid,(TRNSAMOUNT4/100) trnsamount, BENIFSCCODE1272,CHQEQUENO FROM impsbrchanfundstrnsdtls i WHERE transtatus= 'P' AND SERVICEID ='OUTWRD' and sentyn = 'N'   " & strcond & "  and branchcode = '"& strArr(4) &"'"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value & "~" & rs(7).value  & "~" & rs(8).value  & "~" & rs(9).value & "~" & rs(10).value  & "~" & rs(11).value  & "~" & rs(12).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if	
else if strArr(0)="GetIMPSMOBByRefnoDtls" then


sqlstr=  "SELECT y.refnum,y.applicationdate,y.branchcode|| y.glcode || LPAD(y.accno,7,'0')  fullaccno,'' , x.accno benaccno,x.name,y.batchno,y.serviceid,y.branchcode, y.glcode, y.accno  FROM (SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201002 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtran a where  modeoftran = 4 UNION ALL SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201002 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtranday a where  modeoftran = 4) x,(SELECT refnum,applicationdate,branchcode, glcode, accno ,serviceid,BATCHNO  FROM impslogdtls WHERE atmlocation = 'P2AO MOB' and serviceid IN ('OUTWRD')  AND status = 'Y') y  WHERE x.RATEREFCODE = y.refnum AND  substr(x.RESPONDINGBANKCODE,1,6) = y.serviceid AND x.batchno = y.batchno and y.refnum = '"& strArr(1) &"'"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				strname = ""
				modid = ""
				modid =  GetModid(rs(9).value)
				sqlstr= "select name from " & modid &"mst where accno = '"& rs(10).value &"' and glcode = '"& rs(9).value &"' and branchcode = '"& rs(8).value &"'"
				
				rs1=obj.SingleSelectStat(sqlstr)				
				if obj.ConnError="Connected" then
					if not rs1.BOF and not rs1.EOF then
						strname =  rs1(0).value
					end if
				end if
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & strname & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value & "~" & rs(7).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if		
	
	else if strArr(0)="GetIMPSMOBByDateDtls" then

		if strArr(1) <> "Between" then
strcond = " and y.APPLICATIONDATE " & strArr(1) & " '" &  strArr(2) &"'"
else
strcond = " and y.APPLICATIONDATE between '" &  strArr(2) &"' and  '" &  strArr(3) &"'"
end if
sqlstr=  "SELECT y.refnum,y.applicationdate,y.branchcode|| y.glcode || LPAD(y.accno,7,'0')  fullaccno,'' , x.accno benaccno,x.name,y.batchno,y.serviceid,y.branchcode, y.glcode, y.accno  FROM (SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201002 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtran a where  modeoftran = 4 UNION ALL SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201002 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtranday a where  modeoftran = 4) x,(SELECT refnum,applicationdate,branchcode, glcode, accno ,serviceid,BATCHNO  FROM impslogdtls WHERE atmlocation = 'P2AO MOB' and serviceid IN ('OUTWRD')  AND status = 'Y') y  WHERE x.RATEREFCODE = y.refnum AND substr(x.RESPONDINGBANKCODE,1,6) = y.serviceid AND x.batchno = y.batchno " & strcond &"" 

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				strname = ""
				modid = ""
					modid =  GetModid(rs(9).value)
					
				sqlstr= "select name from " & modid &"mst where accno = '"& rs(10).value &"' and glcode = '"& rs(9).value &"' and branchcode = '"& rs(8).value &"'"
				
				rs1=obj.SingleSelectStat(sqlstr)				
				if obj.ConnError="Connected" then
					if not rs1.BOF and not rs1.EOF then
						strname =  rs1(0).value
					end if
				end if
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & strname & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value & "~" & rs(7).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if		
	
else if strArr(0)="GetIMPSByRefnoDtls" then

sqlstr= "SELECT REFNO37,i.APPLICATIONDATE, REMACCNO1022,REMNAME1252, BENACCNO1032, BENNAME,m.BATCHNO,m.serviceid,m.refnum FROM impsbrchanfundstrnsdtls i, impslogdtls m  WHERE m.refnum = i.TRANSREFNO AND  transtatus= 'A'   AND i.SERVICEID ='OUTWRD' and REFNO37 ='"& strArr(1) &"'" 

rs=obj.SingleSelectStat(sqlstr)


	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value  & "~" & rs(8).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

else if strArr(0)="GetATMByRefnoDtls" then

sqlstr= "SELECT y.refnum,y.applicationdate,y.accno,'' , x.accno benaccno,x.name,y.batchno,y.serviceid FROM (SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtran a where  modeoftran = 2 UNION ALL SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtranday a where  modeoftran = 2) x,(SELECT refnum,applicationdate,branchcode|| glcode || LPAD(accno,7,'0') accno ,serviceid,BATCHNO  FROM atmlogdtls WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y') y  WHERE x.RATEREFCODE = y.refnum AND x.RESPONDINGBANKCODE = y.serviceid AND x.batchno = y.batchno and y.refnum = '"& strArr(1) &"'"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				strfullaccno=""
				strbrcode =""
				strglcode =""
				straccno = ""
				modid = ""
				strfullaccno = rs(2).value 
				strbrcode =  mid(strfullaccno,1,3)
				strglcode =  mid(strfullaccno,4,6)
				straccno =  clng(mid(strfullaccno,10,7))
				modid =  GetModid(strglcode)
				
				strname = ""
				sqlstr= "select name from " & modid &"mst where accno = '"& straccno &"' and glcode = '"& strglcode &"' and branchcode = '"& strbrcode &"'"
				rs1=obj.SingleSelectStat(sqlstr)				
				if obj.ConnError="Connected" then
					if not rs1.BOF and not rs1.EOF then
						strname =  rs1(0).value
					end if
				end if
				
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & strname & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

	
else if strArr(0)="GetATMByDateDtls" then

if strArr(1) <> "Between" then
strcond = " and y.APPLICATIONDATE " & strArr(1) & " '" &  strArr(2) &"'"
else
strcond = " and y.APPLICATIONDATE between '" &  strArr(2) &"' and  '" &  strArr(3) &"'"
end if

sqlstr = "SELECT y.refnum,y.applicationdate,y.accno,'' , x.accno,x.name,y.batchno,y.serviceid FROM (SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtran a where  modeoftran = 2 UNION ALL SELECT accno, (SELECT DISTINCT name FROM atmmst WHERE glcode = 201001 AND accno = a.ACCNO ) name, batchno,RATEREFCODE,RESPONDINGBANKCODE FROM atmtranday a where  modeoftran = 2) x,(SELECT refnum,applicationdate,branchcode|| glcode || LPAD(accno,7,'0') accno ,serviceid,BATCHNO  FROM atmlogdtls WHERE serviceid IN ('NWDRRQ','FWDRRQ','POSREQ','ECMREQ','CHPREQ')  AND status = 'Y') y  WHERE x.RATEREFCODE = y.refnum AND x.RESPONDINGBANKCODE = y.serviceid AND x.batchno = y.batchno " & strcond &""

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				strfullaccno=""
				strbrcode =""
				strglcode =""
				straccno = ""
				modid = ""
				strfullaccno = rs(2).value 
				strbrcode =  mid(strfullaccno,1,3)
				strglcode =  mid(strfullaccno,4,6)
				straccno =  clng(mid(strfullaccno,10,7))
				modid =  GetModid(strglcode)
				
				strname = ""
				sqlstr= "select name from " & modid &"mst where accno = '"& straccno &"' and glcode = '"& strglcode &"' and branchcode = '"& strbrcode &"'"
				rs1=obj.SingleSelectStat(sqlstr)				
				if obj.ConnError="Connected" then
					if not rs1.BOF and not rs1.EOF then
						strname =  rs1(0).value
					end if
				end if
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & strname & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			
elseif strArr(0)="getreferencedtls" then

sqlstr = "SELECT T.branchcode,T.BATCHNO,T.TRANNO,T.MODULEID,INITCAP(G.GLDESCRIPTION),T.ACCNO,INITCAP(T.NAME),T.amount,INITCAP(S.NARRATION),INITCAP(M.NARRATION),DECODE(T.transtatus,'P','Pending'),INITCAP(T.REMARKS),T.SYSTEMGENERATEDYN,T.EXCEPTIONYN,INITCAP(T.USERID),INITCAP(T.MACHINEID),G.Glcode,T.serviceid,T.modeoftran,NVL((SELECT NVL(EXCEPTIONCODES,'') FROM  GENTEMPTRANSLOG L WHERE t.BRANCHCODE=L.BRANCHCODE AND  t.CURRENCYCODE=L.CURRENCYCODE AND t.BATCHNO=L.BATCHNO  AND t.TRANNO = L.TRANNO),'')  EXCEPTIONCODES FROM GENTRANSLOG T,GENGLMASTMST G,GENSERVICETYPESPMT S,GENTRANMODES M WHERE UPPER(T.BATCHNO) = "& strArr(2) &"  AND UPPER(G.GLCODE)=UPPER(T.GLCODE) AND  UPPER(M.CODE)=UPPER(T.MODEOFTRAN) AND  UPPER(S.CODE)=UPPER(T.SERVICEID) and SUBSTR(RESPONDINGBANKCODE,1,6) = '"& strArr(3) &"' AND RATEREFCODE =  '"& strArr(1) &"' union all SELECT T.branchcode,T.BATCHNO,T.TRANNO,T.MODULEID,INITCAP(G.GLDESCRIPTION),T.ACCNO,INITCAP(T.NAME),T.amount,INITCAP(S.NARRATION),INITCAP(M.NARRATION),DECODE(T.transtatus,'P','Pending'),INITCAP(T.REMARKS),T.SYSTEMGENERATEDYN,T.EXCEPTIONYN,INITCAP(T.USERID),INITCAP(T.MACHINEID),G.Glcode,T.serviceid,T.modeoftran,NVL((SELECT NVL(EXCEPTIONCODES,'') FROM  GENTEMPTRANSLOG L WHERE t.BRANCHCODE=L.BRANCHCODE AND  t.CURRENCYCODE=L.CURRENCYCODE AND t.BATCHNO=L.BATCHNO  AND t.TRANNO = L.TRANNO),'')  EXCEPTIONCODES FROM GENTRANSLOGbkp T,GENGLMASTMST G,GENSERVICETYPESPMT S,GENTRANMODES M WHERE UPPER(T.BATCHNO) = "& strArr(2) &"  AND UPPER(G.GLCODE)=UPPER(T.GLCODE) AND  UPPER(M.CODE)=UPPER(T.MODEOFTRAN) AND  UPPER(S.CODE)=UPPER(T.SERVICEID) and SUBSTR(RESPONDINGBANKCODE,1,6) = '"& strArr(3) &"' AND RATEREFCODE =  '"& strArr(1) &"' ORDER BY 2,3"



rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value  & "~" & rs(6).value  & "~" & rs(7).value  & "~" & rs(8).value  & "~" & rs(9).value  & "~" & rs(10).value  & "~" & rs(11).value  & "~" & rs(12).value  & "~" & rs(13).value  & "~" & rs(14).value & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			
	
elseif strArr(0)="ATMTRANSSUMALL" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if

'sqlstr="SELECT APPLICATIONDATE,ACCNO,(SELECT DISTINCT NAME FROM ATMMST WHERE ACCNO = A.ACCNO) NAME, SUM(AMOUNT),COUNT(*)  FROM atmtranday A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond & " GROUP BY APPLICATIONDATE,ACCNO " & _
'" UNION all " & _
'" SELECT APPLICATIONDATE,ACCNO,(SELECT DISTINCT NAME FROM ATMMST WHERE ACCNO = A.ACCNO) NAME, SUM(AMOUNT),COUNT(*)  FROM atmtran A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond & " GROUP BY APPLICATIONDATE,ACCNO ORDER BY APPLICATIONDATE,ACCNO" 

 if strArr(6) = "ALL" then
	strtnxtypecond = ""
elseif strArr(6) = "ONUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'NWDRRQ'"
elseif strArr(6) = "OFFUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'FWDRRQ'"
elseif strArr(6) = "LORO" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'LWDRRQ'"
end if


sqlstr="SELECT x.effectivedate,x.accno,(SELECT DISTINCT NAME FROM ATMMST WHERE rownum = 1 and ACCNO = x.ACCNO) NAME,SUM(x.withdrawamt),SUM(x.Reconamt),SUM(x.withdrawamt) - SUM(x.Reconamt) difference,COUNT(*)   FROM( SELECT to_date(to_char(EFFECTIVEDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') EFFECTIVEDATE ,accno,(SELECT SUM(amount) FROM atmtranday WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND  effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) withdrawamt,(SELECT SUM(amount) FROM atmtranday WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) Reconamt   FROM atmtranday A WHERE CHQFVG != 'IMPS' AND branchcode =  '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & " " & strtnxtypecond & " UNION ALL SELECT to_date(to_char(EFFECTIVEDATE,'dd-Mon-yyyy'),'dd-Mon-yyyy') EFFECTIVEDATE,accno,(SELECT SUM(amount) FROM atmtran WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) withdrawamt,(SELECT SUM(amount) FROM atmtran WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) Reconamt  FROM atmtran A WHERE CHQFVG != 'IMPS' AND branchcode =  '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"'" & strcond  & " " & strtnxtypecond & " ) x GROUP BY EFFECTIVEDATE,accno  ORDER BY EFFECTIVEDATE "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value  & "~" & rs(6).value   & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

elseif strArr(0)="ATMTRANSSUMATM" then
if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if

'sqlstr="SELECT APPLICATIONDATE,SUM(AMOUNT),COUNT(*)  FROM atmtranday A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " GROUP BY APPLICATIONDATE " & _
'" UNION all " & _
'" SELECT APPLICATIONDATE,SUM(AMOUNT),COUNT(*)  FROM atmtran A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " GROUP BY APPLICATIONDATE  ORDER BY APPLICATIONDATE"

 if strArr(7) = "ALL" then
	strtnxtypecond = ""
elseif strArr(7) = "ONUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'NWDRRQ'"
elseif strArr(7) = "OFFUS" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'FWDRRQ'"
elseif strArr(7) = "LORO" then
	strtnxtypecond = " and RESPONDINGBANKCODE = 'LWDRRQ'"
end if

sqlstr="SELECT x.effectivedate,SUM(x.withdrawamt),SUM(x.Reconamt),SUM(x.withdrawamt) - SUM(x.Reconamt) difference,COUNT(*)   FROM( SELECT EFFECTIVEDATE,(SELECT SUM(amount) FROM atmtranday WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND  effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) withdrawamt,(SELECT SUM(amount) FROM atmtranday WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) Reconamt   FROM atmtranday A WHERE CHQFVG != 'IMPS' AND branchcode =  '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' AND accno = '"& strArr(6) &"'" & strcond  & " " & strtnxtypecond & " UNION ALL SELECT EFFECTIVEDATE,(SELECT SUM(amount) FROM atmtran WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) withdrawamt,(SELECT SUM(amount) FROM atmtran WHERE CHQFVG != 'IMPS' AND branchcode = a.branchcode AND currencycode = a.currencycode AND accno = a.accno AND effectivedate = a.effectivedate AND modeoftran IN (2,4,6)) Reconamt  FROM atmtran A WHERE CHQFVG != 'IMPS' AND branchcode =  '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' AND accno = '"& strArr(6) &"'" & strcond  & " " & strtnxtypecond & " ) x GROUP BY EFFECTIVEDATE  ORDER BY EFFECTIVEDATE "

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value  & "~" & rs(3).value  & "~" & rs(4).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			


elseif strArr(0)="IMPSTRANSSUM" then

if strArr(3) <> "Between" then
'strcond = " and applicationdate " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
else
'strcond = " and applicationdate between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if
if strArr(8) = "ALL" then
strcondtnxtype = ""
else
strcondtnxtype = " and substr(RESPONDINGBANKCODE,1,6) = '"& strArr(8) &"'"
end if 
'sqlstr="SELECT APPLICATIONDATE,SUM(AMOUNT),COUNT(*)  FROM atmtranday A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " GROUP BY APPLICATIONDATE " & _
'" UNION all " & _
'" SELECT APPLICATIONDATE,SUM(AMOUNT),COUNT(*)  FROM atmtran A WHERE branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " GROUP BY APPLICATIONDATE  ORDER BY APPLICATIONDATE"
if strArr(7) = "ALL" then
sqlstr="SELECT EFFECTIVEDATE,SUM(AMOUNT),COUNT(*)  FROM atmtranday A WHERE CHQFVG = 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond & " " & strcondtnxtype &  " GROUP BY EFFECTIVEDATE " & _
" UNION all " & _
" SELECT EFFECTIVEDATE,SUM(AMOUNT),COUNT(*)  FROM atmtran A WHERE CHQFVG = 'IMPS' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype & " GROUP BY EFFECTIVEDATE  ORDER BY EFFECTIVEDATE"
else
sqlstr="SELECT EFFECTIVEDATE,SUM(AMOUNT),COUNT(*)  FROM atmtranday A WHERE CHQFVG = 'IMPS' and RESPONDINGSECTIONCODE = '"& strArr(7) &"' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype & " GROUP BY EFFECTIVEDATE " & _
" UNION all " & _
" SELECT EFFECTIVEDATE,SUM(AMOUNT),COUNT(*)  FROM atmtran A WHERE CHQFVG = 'IMPS' and RESPONDINGSECTIONCODE = '"& strArr(7) &"' and branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and accno = '"& strArr(6) &"'" & strcond  & " " & strcondtnxtype & " GROUP BY EFFECTIVEDATE  ORDER BY EFFECTIVEDATE"
end if

rs=obj.SingleSelectStat(sqlStr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value  & "|"
					rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
			strResult= strArr(0) & "*" & strResult
	end if			


elseif strArr(0)="checkATMID" then
sqlstr="SELECT accno FROM atmmst WHERE atmid = '"& strArr(1) &"'"

rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
		strResult="Yes"
		else
		strResult="No"
		end if
	end if	


	elseif strArr(0)="GETGLLNKGLCODE" then
	sqlstr="SELECT GLDESCRIPTION FROM GENGLMASTMST WHERE BRANCHCODE = '" & strArr(1) & "' AND MODULEID = '" & strArr(2) & "' AND  glcategory='A' AND  status='R' and glcode = '"& strArr(3) &"'"
	rs=obj.SingleSelectStat(sqlStr)
	
		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult="No Record"
			end if
		end if
	
	
		elseif strArr(0)="GETGLLNKACCNO" then
	strsql = "SELECT distinct a.name,a.accno FROM " & strArr(1) & "MST a WHERE a.glcode='" & strArr(2) & "' AND a.accno='" & strArr(3) & "' AND a.status='R' ORDER BY to_number(a.accno)"
	
		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult="No Record"
			end if
		end if
	
		
elseif strArr(0)="ATMGLLNKDTLS" then
 strsql = "SELECT code,CASE WHEN code = 'ATMREC' THEN 'ATM RECONCIALATION' WHEN CODE = 'SRVCHG' THEN 'SERVICE CAHRGES'  WHEN CODE = 'SRVTAX' THEN 'SERVICE TAX' END DESCRIPTION, A.MODULEID , (SELECT DISTINCT  NARRATION FROM GENMODULEMST WHERE MODULEID = A.MODULEID) MODDESC,A.GLCODE, (SELECT GLDESCRIPTION FROM GENGLMASTMST WHERE BRANCHCODE = '999' AND MODULEID = A.MODULEID AND  glcategory='A' AND  status='R' AND glcode = A.GLCODE) GLDESC, A.ACCNO FROM atmgllnk A WHERE code = '"& strArr(1) &"'"

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
		
			if not rs.BOF and not rs.EOF then
			
			strsql = "SELECT DISTINCT B.name FROM " & rs(2).value & "MST B WHERE B.glcode='"& rs(4).value &"' AND B.accno='"& rs(6).value &"' AND B.status='R'"
			rs1=obj.SingleSelectStat(strsql)
			strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~"
			
			if not rs1.eof and not rs1.bof then
				strResult=strResult & rs1(0).value
			end if			
				strResult=strResult & "|"
				else
				strResult="No Record"
			end if
		end if
		
elseif strArr(0)="REFSERCHNUM" then
	
	strsql = " SELECT ACCNO atmaccno, NAME atmname,TO_CHAR(EFFECTIVEDATE,'DD-Mon-YYYY') tnxdate, TO_CHAR(APPLICATIONDATE,'DD-Mon-YYYY') appdat, BATCHNO, TRANNO, AMOUNT,  LINKMODULEID modid, LINKGLCODE glcode, LINKACCNO accno ,raterefcode, REMARKS   FROM ATMtranday WHERE chqfvg = 'ATM' AND raterefcode = '"& strArr(1) &"' UNION ALL  SELECT ACCNO atmaccno, NAME atmname,TO_CHAR(EFFECTIVEDATE,'DD-Mon-YYYY') tnxdate, TO_CHAR(APPLICATIONDATE,'DD-Mon-YYYY') appdat, BATCHNO, TRANNO, AMOUNT,  LINKMODULEID modid, LINKGLCODE glcode, LINKACCNO accno ,raterefcode, REMARKS   FROM ATMtran WHERE chqfvg = 'ATM' AND raterefcode = '"& strArr(1) &"'"

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "|"
						rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		end if	

elseif strArr(0)="LOGREFSERCHNUM" then
	
	strsql = "SELECT branchcode,glcode,accno,batchno,(case when status= 'Y' then 'Success'  when status = 'N' then 'Failed' else '' end),amount,refnum,        CASE WHEN serviceid = 'BALENQ' THEN 'Balance Enquiry' WHEN serviceid = 'NWDRRQ' THEN 'ON US With Draw Request' WHEN serviceid = 'FWDRRQ' THEN 'OFF US WITH DRAW REQUEST' WHEN serviceid = 'LWDRRQ' THEN 'LORO With Drawal REQUEST' WHEN serviceid = 'MINSTA' THEN 'Mini Statement' WHEN serviceid = 'NDEBRV' THEN 'ON US Debit Reversal' WHEN serviceid = 'FDEBRV' THEN 'OFF US Debit Reversal' WHEN serviceid = 'POSREQ' THEN 'POS Request' WHEN serviceid = 'ECMREQ' THEN 'ECM Request'      WHEN serviceid = 'CHPREQ' THEN 'Cash POS Request' WHEN serviceid = 'CHPRRQ' THEN 'Cash At Reversal Request' WHEN serviceid = 'PSRREQ' THEN 'POS Reversal Request' WHEN serviceid = 'ECRREQ' THEN 'ECM Reversal Request' WHEN serviceid = 'NETMSG' THEN 'Network Message' WHEN serviceid = 'CBPREQ ' THEN 'CASH BACK at POS Request' WHEN serviceid = 'CBPRRQ ' THEN 'CASH BACK POS Reversal Request' WHEN serviceid = ' ENQNME' THEN 'Enquiry Name' WHEN serviceid = ' NCSDRQ ' THEN 'ON US Cash Deposit Request' WHEN serviceid = ' FCSDRQ ' THEN 'OFF US CASH DEPOSIT REQUEST' WHEN serviceid = ' LCSDRQ' THEN 'Loro Cash Deposit Request' ELSE '' END,remarks,atmid,atmlocation,to_char(applicationdate,'dd-Mon-yyyy'),to_char(systemdate,'dd-Mon-yyyy HH24:Mi:ss') FROM atmlogdtls WHERE refnum = '"& strArr(1) &"' ORDER BY slno"

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "|"
						rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		end if	


elseif strArr(0)="RECONCILREP" then
	
	strsql = " SELECT TRANSMODE, TERMINALID, CARDNUMBER, ACCNO, TRANSTYPE, AMOUNT, TRANSACTIONDATE, REFERENCENUMBER, RESPONSECODE, STATUS, 'Not Match' match FROM ATMRECONCILATIONTEMP WHERE REFERENCENUMBER NOT IN (SELECT RATEREFCODE FROM atmtran WHERE RATEREFCODE IS NOT NULL UNION ALL SELECT RATEREFCODE FROM atmtranday WHERE RATEREFCODE IS NOT NULL) "

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "|"
						rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		end if	

elseif   strArr(0) = "BrChaChkTrnSta" then

if strArr(3) = "Between" then
 
strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),TRANSREFNO FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'CTRNST' AND APPLICATIONDATE BETWEEN '"& strArr(4) &"' AND  '"& strArr(5) &"' and branchcode = '"& strArr(1) &"' and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
else
 
strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),TRANSREFNO FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'CTRNST' AND APPLICATIONDATE "& strArr(3) &" '"& strArr(4) &"'  and branchcode = '"& strArr(1) &"' and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
end if

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
					do until rs.EOF
					
						strRemarks = ""	: strRemarksCR = ""
					
						if rs(7).value = "Y" then
					strRemarksCR = "Cr Trans Success"
					else
					strRemarksCR = "Cr Trans Not Success"
					end if 
					
					
					strRemarks = strRemarksCR
	strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & strRemarks & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				
			end if
					strResult= strArr(0) & "*" & strResult
		end if	

'elseif strArr(0) = "BRCTNXDTLS" then

'if strArr(3) = "Between" then
 
'strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),(SELECT nvl(CREDITSTATUS,'N') CREDITSTATUS FROM IMPSBRCHANFUNDSTRNSDTLS WHERE SERVICEID ='OUTWRR' AND refno37 = a.refno37)  ReverseYN  FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'OUTWRD' AND APPLICATIONDATE BETWEEN '"& strArr(4) &"' AND  '"& strArr(5) &"' and branchcode = '"& strArr(1) &"' and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
'else
 
'strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),(SELECT nvl(CREDITSTATUS,'N') CREDITSTATUS FROM IMPSBRCHANFUNDSTRNSDTLS WHERE SERVICEID ='OUTWRR' AND refno37 = a.refno37)  ReverseYN  FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'OUTWRD' AND APPLICATIONDATE "& strArr(3) &" '"& strArr(4) &"'  and branchcode = '"& strArr(1) &"' and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
'end if

'		rs=obj.SingleSelectStat(strsql)

'		if obj.ConnError="Connected" then
'			if not rs.BOF and not rs.EOF then
'					do until rs.EOF
'	strRemarks = ""					
'	if rs(7).value = "N" then						
'						strSql = "SELECT nvl(CREDITSTATUS,'N') CREDITSTATUS FROM IMPSBRCHANFUNDSTRNSDTLS WHERE SERVICEID ='OUTWRR' AND refno37 = '"& strrefno &"'"
'	rsrev=obj.SingleSelectStat(strSql)
'				rsrev=obj.SingleSelectStat(strsql)

'			if not rsrev.eof and not rsrev.bof then
'					if rsrev(0).value = "Y" then
'						strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Successfull"
'					else
'						strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Not Successfull"
'					end if
'			else
'				strRemarks= " Debit Transaction Successful and Credit Transaction Not Successful, Outward Reversal Not Successfull"
'			end if
'	end if
	
'	strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & strRemarks & "|"
'					rs.movenext()
'					loop
'					strResult=mid(strResult,1,strResult.length-1)
				
'			end if
'					strResult= strArr(0) & "*" & strResult
'		end if	


elseif strArr(0) = "BRCTNXDTLS" then
dim strcond5
if strArr(6) = "Y" then
strcond5 = " and 1=1 "
else
strcond5 = " and branchcode = '"& strArr(1) &"'"
end if 

if strArr(3) = "Between" then
 
strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),TRANSREFNO FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'OUTWRD' AND APPLICATIONDATE BETWEEN '"& strArr(4) &"' AND  '"& strArr(5) &"'" & strcond5 & " and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
else
 
strsql = "SELECT REFNO37, BRANCHCODE || GLCODE || lpad(ACCNO,7,'0')  ,REMNAME1252,TRNSAMOUNT4,BENIFSCCODE1272,BENACCNO1032, BENNAME,nvl(CREDITSTATUS,'N') CREDITSTATUS, CRREMARKS,to_char(APPLICATIONDATE,'dd-Mon-yyyy'),TRANSREFNO FROM impsbrchanfundstrnsdtls a WHERE sentyn = 'Y' AND serviceid = 'OUTWRD' AND APPLICATIONDATE "& strArr(3) &" '"& strArr(4) &"'" & strcond5 & "  and currencycode = '"& strArr(2) &"' ORDER BY applicationdate,REFNO37"
end if

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
					do until rs.EOF
					
						strRemarks = ""	: strRemarksDr = "" : 	strRemarksDrRev = "" : strRemarksCR = ""
					
						if rs(7).value = "Y" then
					strRemarksCR = "Cr Trans Success"
					else
					strRemarksCR = "Cr Trans Not Success"
					end if 
					
					strsql = "SELECT STATUS,remarks  FROM impslogdtls WHERE serviceid =  'OUTWRD' AND refnum = '"& rs(10).value &"'" 
						rsrev=obj.SingleSelectStat(strSql)
					if obj.ConnError="Connected" then
						if not rsrev.eof and not rsrev.bof then
							if rsrev(0).value = "Y" then
							strRemarksDr = " Dr Tran Success"
							else
							strRemarksDr = " Dr Trans Not Success"
							end if
							else
						
						end if 				
					end if

				strsql = "SELECT STATUS,remarks FROM impslogdtls WHERE serviceid =  'OUTWRR' AND refnum =  '"& rs(10).value &"'" 
				rsrev=obj.SingleSelectStat(strsql)
		if obj.ConnError="Connected" then
			if not rsrev.eof and not rsrev.bof then
					if rsrev(0).value = "Y" then
						strRemarksDrRev = " Dr Reversal Success"
					else
						strRemarksDrRev = " Dr Reversal Not Success"
					end if
			else
				
			end if
		end if
		
					strRemarks = strRemarksDr & "," & strRemarksDrRev & "," & strRemarksCR
	strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & strRemarks & "|"
					rs.movenext()
					loop
					strResult=mid(strResult,1,strResult.length-1)
				
			end if
					strResult= strArr(0) & "*" & strResult
		end if	


elseif strArr(0)="ATMPOSITION" then
 
	strsql = " SELECT BRANCHCODE, GLCODE, ACCNO FROM ATMMST WHERE STATUS='R' ORDER BY BRANCHCODE, GLCODE, ACCNO "

		rs=obj.SingleSelectStat(strsql)

		if obj.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				do until rs.EOF
				
					strsql = "select x.BRANCHCODE, x.GLCODE, x.ACCNO, x.NAME,x.bal from(SELECT BRANCHCODE, GLCODE, ACCNO, NAME, GETANYDAYBAL('" & rs(0).value & "','INR','ATM','" & rs(1).value & "','" & rs(2).value & "','" & strArr(1) & "') bal FROM ATMMST WHERE accno='" & rs(2).value & "' AND glcode='" & rs(1).value & "' AND  branchcode='" & rs(0).value & "') x where x.bal <> 0"
					
					rs1=obj.SingleSelectStat(strsql)
			
					if not rs1.eof and not rs1.bof then
						strResult=strResult & rs1(0).value & "~" & rs1(1).value & "~" & rs1(2).value & "~" & rs1(3).value & "~" & rs1(4).value & "|"
					end if			
				
				rs.movenext()
				loop
				strResult=mid(strResult,1,strResult.length-1)
			end if
		end if
 
 elseif strArr(0)="NACHDRINREPQUERY" or strArr(0)="NACHCRINREPQUERY" then
 
 if strArr(1)="ALL" then
 sqlstr= "select BENEACCNUM,BENEFICIARYNAME, DESCRIPTION, AMOUNT, CASE WHEN status != 'SUCCESS' THEN 'RETURN'  ELSE 'PASS' END  status,ITEMSEQNO, DESBNKIFSCCODE,  SPONSERBANKIFSCCODE, USRNUMREGNUM, TRANSREFNUM, UNQMANREFNUM,APPLICATIONDATE   from nachtrandtls where nachtype = '"& strArr(2) &"'" &  strArr(6) &  strArr(7) & " order by UNQMANREFNUM,TRANSREFNUM "
 elseif strArr(1)="ACCWISE" then
 sqlstr= "select BENEACCNUM,BENEFICIARYNAME, DESCRIPTION, AMOUNT,CASE WHEN status != 'SUCCESS' THEN 'RETURN' ELSE 'PASS' END  status, ITEMSEQNO, DESBNKIFSCCODE,  SPONSERBANKIFSCCODE, USRNUMREGNUM, TRANSREFNUM, UNQMANREFNUM,APPLICATIONDATE  from nachtrandtls where nachtype = '"& strArr(2) &"'"  & " and  substr(BENEACCNUM,1,3) = '"& strArr(3) &"' and substr(BENEACCNUM,4,6) = '"& strArr(4) &"' and  BENEACCNUM = '"& strArr(5) &"' order by UNQMANREFNUM,TRANSREFNUM "
 
 end if
 
 rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value   & "~" & rs(6).value   & "~" & rs(7).value   & "~" & rs(8).value   & "~" & rs(9).value  & "~" & rs(10).value & "~" & rs(11).value  & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
	
 elseif strArr(0)="NACHDROUTREPQUERY" then
 
 if strArr(1)="ALL" then
 sqlstr= "SELECT UMRN,INSTNO,DRACCNO,CRACCNO, (SELECT beneficiaryname FROM nachtrandtls WHERE rownum = 1 and TRANSREFNUM = d.REFNO AND UNQMANREFNUM = d.UMRN ) name,Amount,refno,filename, CASE WHEN status = 'R' AND FileGENYN = 'Y' AND remarks IS NULL THEN 'Processing' WHEN status = 'R' AND FileGENYN = 'N'  THEN 'Pending' WHEN status = 'R' AND FileGENYN = 'Y' AND remarks IS NOT NULL THEN Remarks  WHEN status = 'C' then 'Terminate' END   status , EXECDATE  FROM NACHSIEXECDTLS d where 1=1  " & strArr(6) &  strArr(7) & " order by UMRN,INSTNO "
 
 elseif strArr(1)="ACCWISE" then
 sqlstr= "SELECT UMRN,INSTNO,DRACCNO,CRACCNO, (SELECT beneficiaryname FROM nachtrandtls WHERE rownum = 1 and TRANSREFNUM = d.REFNO AND UNQMANREFNUM = d.UMRN ) name,Amount,refno,filename, CASE WHEN status = 'R' AND FileGENYN = 'Y' AND remarks IS NULL THEN 'Processing' WHEN status = 'R' AND FileGENYN = 'N'  THEN 'Pending' WHEN status = 'R' AND FileGENYN = 'Y' AND remarks IS NOT NULL THEN Remarks  WHEN status = 'C' then 'Terminate' END   status,EXECDATE   FROM NACHSIEXECDTLS d  where 1=1  and  substr(CRACCNO,1,3) = '"& strArr(3) &"' and substr(CRACCNO,4,6) = '"& strArr(4) &"' and  CRACCNO = '"& strArr(5) &"' order by UMRN,INSTNO "
 
 end if
 
 rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value   & "~" & rs(6).value   & "~" & rs(7).value   & "~" & rs(8).value   & "~" & rs(9).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
	
elseif strArr(0)="NACHCBDT" then
 
 if strArr(1)="ALL" then
 sqlstr= "SELECT FILENAME, RECORDREFERENCENO, IFSCCODE, ACCOUNTNO, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN JOINTACCOUNTFLAG = '00' THEN 'Pass' WHEN JOINTACCOUNTFLAG = '01' THEN 'Single' ELSE 'Fail'  END JOINTACCOUNTFLAG, PRIACSHOLDPANNO, SECACSHOLDPANNO, PRIACCHOLDNAME, SECACCHOLDNAME, ACCTYPE,applicationdate FROM NACHCBDTINPTRANDTLS WHERE " & strArr(5) & " order by ACCOUNTNO "
 
 elseif strArr(1)="ACCWISE" then
 sqlstr= "SELECT FILENAME, RECORDREFERENCENO, IFSCCODE, ACCOUNTNO, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN JOINTACCOUNTFLAG = '00' THEN 'Pass' WHEN JOINTACCOUNTFLAG = '01' THEN 'Single' ELSE 'Fail'  END JOINTACCOUNTFLAG, PRIACSHOLDPANNO, SECACSHOLDPANNO, PRIACCHOLDNAME, SECACCHOLDNAME, ACCTYPE,applicationdate FROM NACHCBDTINPTRANDTLS WHERE   substr(ACCOUNTNO,1,3) = '"& strArr(2) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(3) &"' and  ACCOUNTNO = '"& strArr(4) &"' order by ACCOUNTNO "
 
 end if
 
 rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value   & "~" & rs(6).value   & "~" & rs(7).value   & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value  & "~" & rs(11).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
	
elseif strArr(0)="NACHLIC" then
 
 if strArr(1)="ALL" then
 sqlstr= "SELECT FILENAME, RECORDORIGINATOR, IFSCCODE, ACCOUNTNO, BENENAMEORG, CUSTOMERID, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN BENENAMEMATCHFLAG = '00' THEN 'Pass' WHEN BENENAMEMATCHFLAG = '01' THEN 'Single' ELSE 'Fail'  END BENENAMEMATCHFLAG, BENENAMERESP, AADHARNO, MOBILENO, MAILID,applicationdate FROM NACHLICIINPTRANDTLS WHERE " & strArr(5) & " order by ACCOUNTNO "
 
 elseif strArr(1)="ACCWISE" then
 sqlstr= "SELECT FILENAME, RECORDORIGINATOR, IFSCCODE, ACCOUNTNO, BENENAMEORG, CUSTOMERID, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN BENENAMEMATCHFLAG = '00' THEN 'Pass' WHEN BENENAMEMATCHFLAG = '01' THEN 'Single' ELSE 'Fail'  END BENENAMEMATCHFLAG, BENENAMERESP, AADHARNO, MOBILENO, MAILID,applicationdate FROM NACHLICIINPTRANDTLS WHERE  substr(ACCOUNTNO,1,3) = '"& strArr(2) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(3) &"' and  ACCOUNTNO = '"& strArr(4) &"' order by ACCOUNTNO "
 
 end if
 
 rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value   & "~" & rs(6).value   & "~" & rs(7).value   & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
	
elseif strArr(0)="NACHGSTD" then
 
 if strArr(1)="ALL" then
 sqlstr= "SELECT FILENAME, RECORDREFERENCENO, IFSCCODE, ACCOUNTNO, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN JOINTACCOUNTFLAG = '00' THEN 'Pass' WHEN JOINTACCOUNTFLAG = '01' THEN 'Single' ELSE 'Fail'  END JOINTACCOUNTFLAG, PRIACSHOLDPANNO, SECACSHOLDPANNO, PRIACCHOLDNAME, SECACCHOLDNAME, ACCTYPE,applicationdate FROM NACHgstdINPTRANDTLS WHERE " & strArr(5) & " order by ACCOUNTNO "
 
 elseif strArr(1)="ACCWISE" then
 sqlstr= "SELECT FILENAME, RECORDREFERENCENO, IFSCCODE, ACCOUNTNO, CASE WHEN ACCOUNTVALIDFLAG = '00' THEN 'Pass' WHEN ACCOUNTVALIDFLAG = '02' THEN 'Fail' ELSE 'Fail' END ACCOUNTVALIDFLAG, CASE WHEN JOINTACCOUNTFLAG = '00' THEN 'Pass' WHEN JOINTACCOUNTFLAG = '01' THEN 'Single' ELSE 'Fail'  END JOINTACCOUNTFLAG, PRIACSHOLDPANNO, SECACSHOLDPANNO, PRIACCHOLDNAME, SECACCHOLDNAME, ACCTYPE,applicationdate FROM NACHgstdINPTRANDTLS WHERE   substr(ACCOUNTNO,1,3) = '"& strArr(2) &"' and substr(ACCOUNTNO,4,6) = '"& strArr(3) &"' and  ACCOUNTNO = '"& strArr(4) &"' order by ACCOUNTNO "

 end if
 
 rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value   & "~" & rs(6).value   & "~" & rs(7).value   & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value  & "~" & rs(11).value & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
	
elseif strArr(0)="IntraFndsTrns" then

	if strArr(3) <> "Between" then

'	strcond = " and applicationDATE " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE  " & strArr(3) & " '" &  strArr(4) &"'"
	strcond_mob = " and m.applicationDATE " & strArr(3) & " '" &  strArr(4) &"'"
else

'	strcond = " and applicationDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE  between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond_mob = " and m.applicationDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if

if strArr(6) = "N" then
strcondbrcode =  " and m.branchcode = '"& strArr(1) &"'" 
else
strcondbrcode =  " and 1 = 1 "
end if


  sqlstr= "  SELECT m.applicationdate, m.refnum, m.branchcode||m.glcode||LPAD(m.accno,7,'0') draccno ,d.drname,m.amount , d.drremarks, (case when m.status = 'Y' then 'Success' else 'Fail' end )|| m.remarks  FROM (  SELECT applicationdate,RATEREFCODE, branchcode,glcode,accno,name drname,remarks drremarks ,SUBSTR(RESPONDINGBANKCODE,1,6) RESPONDINGBANKCODE FROM gentranslog WHERE   SUBSTR(RESPONDINGBANKCODE,1,6) = 'OWITRA' AND modeoftran = 3   "& strcond &" UNION ALL SELECT applicationdate,RATEREFCODE, branchcode,glcode,accno,name drname,remarks drremarks ,SUBSTR(RESPONDINGBANKCODE,1,6) RESPONDINGBANKCODE FROM gentranslogbkp WHERE  SUBSTR(RESPONDINGBANKCODE,1,6) = 'OWITRA' AND modeoftran = 3   "& strcond &" ) d , impslogdtls m WHERE m.serviceid=  'OWITRA'  "& strcondbrcode &" "& strcond_mob &" AND RESPONDINGBANKCODE (+) = m.serviceid AND RATEREFCODE (+)= m.refnum "
  
	rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				sqlstr= "SELECT  branchcode||glcode||lpad(accno,7,'0') craccno,name crname,remarks crremarks  FROM gentranslog WHERE EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and   SUBSTR(RESPONDINGBANKCODE,1,6) = 'OWITRA' AND modeoftran = 4  and RATEREFCODE = '"& rs(1).value &"' "& strcond &" UNION ALL SELECT  branchcode||glcode||lpad(accno,7,'0') craccno,name crname,remarks crremarks  FROM gentranslogbkp WHERE  EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and SUBSTR(RESPONDINGBANKCODE,1,6) = 'OWITRA' AND modeoftran = 4 and RATEREFCODE = '"& rs(1).value &"'   "& strcond &""
					rs1=obj.SingleSelectStat(sqlstr)
					craccno = "" : crname = "" : crremarks = ""
					if not rs1.eof and not rs1.bof then
						craccno = rs1(0).value 
						crname = rs1(1).value 
						crremarks = rs1(2).value 
					end if 
				if rs1.state =  1 then
					rs1.close
					rs1= nothing
				end if 
				strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & craccno   & "~" & crname & "~" & rs(4).value & "~" & rs(5).value & "~" & crremarks & "~" & rs(6).value  & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			end if
		strResult= strArr(0) & "*" & strResult	
	end if

elseif strArr(0)="NEFTByMobileFrnTrns" then
	
	
	if strArr(3) <> "Between" then

	'strcond = " and applicationDATE " & strArr(3) & " '" &  strArr(4) &"'"
	strcond = " and EFFECTIVEDATE " & strArr(3) & " '" &  strArr(4) &"'"
	strcond_mob = " and m.applicationDATE " & strArr(3) & " '" &  strArr(4) &"'"
else

	'strcond = " and applicationDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond = " and EFFECTIVEDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
	strcond_mob = " and m.applicationDATE between '" &  strArr(4) &"' and  '" &  strArr(5) &"'"
end if

if strArr(6) = "N" then
strcondbrcode =  " and m.branchcode = '"& strArr(1) &"'" 
else
strcondbrcode =  " and 1 = 1 "
end if


	dim strvalues
  
sqlstr= "SELECT m.applicationdate, m.refnum,m.amount , m.branchcode||m.glcode||LPAD(m.accno,7,'0') draccno , m.batchno,  (CASE WHEN m.status = 'Y' THEN 'Success' ELSE 'Fail' END )|| m.remarks  FROM mobbnklogdtls m WHERE m.serviceid=  'FNTRRP' "& strcondbrcode &" "& strcond_mob &""
	rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
				if isdbnull(rs(4).value) = false then
				
				
				sqlstr= "SELECT  branchcode||glcode||lpad(accno,7,'0') draccno,name drname,remarks drremarks,RATEREFCODE  FROM gentranslog WHERE batchno = "& rs(4).value &" and  EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and   SUBSTR(RESPONDINGBANKCODE,1,6) = 'NEFTOW' AND modeoftran = 3   "& strcond &" UNION ALL SELECT  branchcode||glcode||lpad(accno,7,'0') draccno,name drname,remarks drremarks,RATEREFCODE  FROM gentranslogbkp WHERE  batchno = "& rs(4).value &" and   EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and SUBSTR(RESPONDINGBANKCODE,1,6) = 'NEFTOW' AND modeoftran = 3 "& strcond &""
					rs1=obj.SingleSelectStat(sqlstr)
					craccno = "" : draccno = "" : drname = "" : drremarks = "" : drrefno = ""
					if not rs1.eof and not rs1.bof then
						draccno = rs1(0).value 
						drname = rs1(1).value 
						drremarks = rs1(2).value 
						drrefno = rs1(3).value 
					end if 
				if rs1.state =  1 then
					rs1.close
					rs1= nothing
				end if 
			if drremarks <> "" then
				strvalues = Split(drremarks," ")
				craccno = strvalues(3)
				sqlstr= "SELECT  name crname,remarks crremarks  FROM gentranslog WHERE  batchno = "& rs(4).value &" and   EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and   SUBSTR(RESPONDINGBANKCODE,1,6) = 'NEFTOW' AND modeoftran = 4  "& strcond &" UNION ALL SELECT  name crname,remarks crremarks  FROM gentranslogbkp WHERE  batchno = "& rs(4).value &" and   EFFECTIVEDATE = '"& format(cdate(rs(0).value),"dd-MMM-yyyy") &"' and SUBSTR(RESPONDINGBANKCODE,1,6) = 'NEFTOW' AND modeoftran = 4    "& strcond &""
					rs1=obj.SingleSelectStat(sqlstr)
					 crname = "" : crremarks = ""
					if not rs1.eof and not rs1.bof then
				
						crname = rs1(0).value 
						crremarks = rs1(1).value 
					end if 
				if rs1.state =  1 then
					rs1.close
					rs1= nothing
				end if 
		 end if 
			
					end if 
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & drname & "~" & craccno   & "~" & crname & "~" & drrefno & "~" & drremarks & "~" & crremarks & "~" & rs(5).value  & "|"
					rs.movenext()
			
				loop
					strResult=mid(strResult,1,strResult.length-1)
					
			end if
		strResult= strArr(0) & "*" & strResult	
	end if
	
 elseif strArr(0)="IMPSAccWiseRep" then
 
strtnxtype = ""
	strcond = ""
	if strArr(6) = "ALL" then
	strtnxtype = " "
	elseif  strArr(6) = "INWARD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'INWARD' "
	elseif  strArr(6) = "OUTWRD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'OUTWRD' "
	end if
	
if strArr(7) <> "Between" then

	strcond = " and EFFECTIVEDATE " & strArr(7) & " '" &  strArr(8) &"'"
else

	strcond = " and EFFECTIVEDATE between '" &  strArr(8) &"' and  '" &  strArr(9) &"'"
end if

if strNFTSCONVYN = "Y" then

sqlstr="SELECT  accno,NAME, AMOUNT,  RATEREFCODE, APPLICATIONDATE,SUBSTR(RESPONDINGBANKCODE,1,6),remarks FROM GENTRANSLOG WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"   & strtnxtype & " "  &  strcond  & _  
 " UNION ALL " & _
 " SELECT  accno,NAME,  AMOUNT, RATEREFCODE, APPLICATIONDATE,SUBSTR(RESPONDINGBANKCODE,1,6),remarks FROM GENTRANSLOGBKP WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"  & strtnxtype & " "  &  strcond 
 
else

sqlstr="SELECT BRANCHCODE|| GLCODE || LPAD(ACCNO,7,'0') accno,NAME, AMOUNT,  RATEREFCODE, APPLICATIONDATE,SUBSTR(RESPONDINGBANKCODE,1,6),remarks FROM GENTRANSLOG WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"   & strtnxtype & " "  &  strcond  & _  
 " UNION ALL " & _
 " SELECT BRANCHCODE|| GLCODE || LPAD(ACCNO,7,'0') accno,NAME, AMOUNT,  RATEREFCODE, APPLICATIONDATE,SUBSTR(RESPONDINGBANKCODE,1,6),remarks FROM GENTRANSLOGBKP WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"  & strtnxtype & " "  &  strcond 

end if
rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value  & "~" & rs(5).value  & "~" & rs(6).value  & "|"
					rs.movenext()
				loop
					strResult=mid(strResult,1,strResult.length-1)
			else
					strResult = "|"
			end if
		strResult= strArr(0) & "*" & strResult	
	end if			
elseif strArr(0)="GetIMPSAccWiseCustTrnsAccName" then
strtnxtype = ""
	strcond = ""
	if strArr(6) = "ALL" then
	strtnxtype = " "
	elseif  strArr(6) = "INWARD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'INWARD' "
	elseif  strArr(6) = "OUTWRD" then
	strtnxtype= " AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'OUTWRD' "
	end if
	
if strArr(6) <> "Between" then

	strcond = " and EFFECTIVEDATE " & strArr(7) & " '" &  strArr(8) &"'"
else

	strcond = " and EFFECTIVEDATE between '" &  strArr(8) &"' and  '" &  strArr(9) &"'"
end if

		sqlstr="SELECT NAME FROM GENTRANSLOG WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"   & strtnxtype & " "  &  strcond  & _  
 " UNION ALL " & _
 " SELECT NAME FROM GENTRANSLOGBKP WHERE CHQFVG = 'IMPS' AND branchcode = '"& strArr(1) &"' AND currencycode = '"& strArr(2) &"' and MODULEID = '"& strArr(3) &"' And glcode = '"& strArr(4) &"' And accno = '"& strArr(5) &"'"  & strtnxtype & " "  &  strcond 
		
		rs=obj.SingleSelectStat(sqlStr)
	if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
				strResult=rs(0).value
				else
				strResult=""
				end if
	end if	
			
end if

	if rs.state =  1 then
		rs.close
		rs= nothing
	end if
obj = nothing
end if
%>
<html>
	<head>
		<title>getDtls</title>
		<script language="vbscript" runat ="server">
		function GetModid(pstrGlcd)
		dim strmodid
		  If pstrGlcd = "102020" Then
                strmodid = "SB"
            ElseIf pstrGlcd = "102030" Then
                strmodid = "CA"
            ElseIf Mid(pstrGlcd, 1, 3) = "206" Then
                strmodid = "CC"
            End If
            GetModid = strmodid
		end function
		</script>
		<script language="javascript">
					
		function Details()
		{
			var type="<%=strArr(0)%>"
			var strResult="<%=strResult%>"
		//	alert("type " + type + "  strResult " + strResult)
			if (type=="GetAccountNo")
			{ 
				window.attachEvent(window.parent.DisplayAccNo(strResult))
			}
			else if ((type=="GetAccountNoIDS") || (type=="GetIMPSAccountNoIDS"))
			{
				window.attachEvent(window.parent.DisplayAccName(strResult))
			}
			else if ((type=="GetValidReferenceNo") || (type=="GetATMValidReferenceNo") || (type=="GetIMPSMOBValidReferenceNo") || (type=="GetIMPSValidReferenceNo"))
			{
				window.attachEvent(window.parent.GetReferenceno1(strResult))
			}
			else if ((type=="GetCustTrnsAccName") || (type=="GetH2HTransAccName"))
			{
				window.attachEvent(window.parent.DisplayCustTrnsAccName(strResult))
			}
			else if ((type=="GetNACHTransAccName"))
			{
				window.attachEvent(window.parent.DisplayNACHCustTrnsAccName(strResult))
			}
			else if ((type=="GetNACHCBDTLICTransAccName"))
			{
				window.attachEvent(window.parent.DisplayNACHCBDTLICCustTrnsAccName(strResult))
			}
			else if ((type=="NACHDRINREPQUERY") || (type=="NACHCRINREPQUERY"))
			{
			window.attachEvent(window.parent.DisplayNACHDRINREPQUERY(strResult))
			}
			else if (type=="NACHDROUTREPQUERY")
			{
			window.attachEvent(window.parent.DisplayNACHDROUTREPQUERY(strResult))
			}
			else if ((type=="NACHCBDT") || (type=="NACHGSTD"))
			{
			window.attachEvent(window.parent.DisplayNACHCBDT(strResult))
			}
			else if (type=="NACHLIC")
			{
			window.attachEvent(window.parent.DisplayNACHLIC(strResult))
			}
			else if((type=="ATMTRANSDETALL") || (type=="ATMTRANSDETATM") || (type=="ATMTRANSSUMALL") || (type=="ATMTRANSSUMATM") || (type=="IMPSTRANSDET") || (type=="IMPSTRANSSUM"))
			{
			 	window.attachEvent(window.parent.DisplayATMTrans(strResult))
			 }	
			else if((type=="GetIMPSByDateDtls") || (type=="GetIMPSByRefnoDtls") || (type=="GetBRCHANIMPSByDateDtls")  || (type=="GetBRCHANIMPSByRefnoDtls") ||  (type=="GetBRCHANIMPSByRefnoTrackDtls")  ||  (type=="GetBRCHANIMPSByDateTrackDtls")) 
			 {
			 	window.attachEvent(window.parent.DisplayIMPSDtls(strResult))
			 }
			 else if ((type=="GetATMByRefnoDtls")  || (type=="GetATMByDateDtls")) 
			 {
			 	window.attachEvent(window.parent.DisplayIMPSDtls(strResult))
			 }
			  else if ((type=="GetIMPSMOBByRefnoDtls") || (type=="GetIMPSMOBByDateDtls"))
			 {
			 	window.attachEvent(window.parent.DisplayIMPSDtls(strResult))
			 }
			 else if (type=="IMPSAccWiseRep")
			 {
			 window.attachEvent(window.parent.DisplayIMPSAccWiseRepDtls(strResult))
			 }			 
			  else if (type=="GetIMPSAccWiseCustTrnsAccName")
			 {
			 window.attachEvent(window.parent.DisplayIMPSAccWiseCustTrnsAccName(strResult))
			 }			 
			 else if (type=="getreferencedtls")
			 {
			 	window.attachEvent(window.parent.DisplayRefDtls(strResult))
			 }
			 else if((type=="ATMCUSTTRANSDETACCALL") || (type=="ATMCUSTTRANSDETACCSIN") || (type=="ATMCUSTTRANSDETMODALL") || (type=="ATMCUSTTRANSSUMACCALL") || (type=="ATMCUSTTRANSSUMACCSIN")  || (type=="ATMCUSTTRANSSUMMODALL"))
			 {
			 	window.attachEvent(window.parent.DisplayATMCustTrans(strResult))
			 }	
			 else if(type=="checkATMID")
			{
			 	window.attachEvent(window.parent.DisplaycheckATMID(strResult))
			 }	
			 	else if(type=="GETGLLNKGLCODE")
			 	{
				window.attachEvent(window.parent.getglcodedescription(strResult))	
				}
			else if(type=="GETGLLNKACCNO")
			{
				window.attachEvent(window.parent.GetAccountDesc(strResult))	
			 }
			else if(type=="ATMGLLNKDTLS")
			{
				window.attachEvent(window.parent.GetGLLNKDETAILS(strResult))	
			 }
			 else if((type=="REFSERCHNUM") || (type=="LOGREFSERCHNUM"))
			 {
				window.attachEvent(window.parent.GetPoprefNum(strResult))
			 }
			 else if(type=="RECONCILREP")
			 {
				window.attachEvent(window.parent.GetPopreconcil(strResult))
			 }
			 else if(type=="ATMPOSITION")
			 {
				window.attachEvent(window.parent.PopAtmposi(strResult))
			 }
			 else if(type=="BRCTNXDTLS")
			 {
				window.attachEvent(window.parent.PopBRCTNXDTLS(strResult))
			 }
			 else if(type=="BrChaChkTrnSta")
			 {
				window.attachEvent(window.parent.PopBRCChkTrnSta(strResult))
			 }
			 else if(type=="IntraFndsTrns")
			 {
				window.attachEvent(window.parent.PopIntraFndsTrns(strResult))
			 }
			  else if(type=="NEFTByMobileFrnTrns")
			 {
			
				window.attachEvent(window.parent.PopNEFTByMobileFrnTrns(strResult))
			 }
			 
		}
		
		</script>
	</head>
	<body onload="Details()">
		<form id="frmDetails">
			<input type="button" name="hdnResult" value="strResult">
		</form>
	</body>
</html>
