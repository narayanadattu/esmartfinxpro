<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmATMGLLinkinsert.aspx.vb" Inherits="eSmartDotNet.frmATMGLLinkinsert"%>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<%userid=session("userid")%>
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<SCRIPT LANGUAGE="javascript">
			</SCRIPT>


<%	

	Dim kstr
	kstr=Request.QueryString("st")
	
	if kstr="ATMGLLnknew" then
		Dim transarray(0,4)
		
				'------------------Assigning the  values------------------------
		GLLnkcode=Request.Form("txtGLLnkcode")
		Modcode=Request.Form("txtModcode")
		Glcode=Request.Form("txtGlcode")
		Accountno=Request.Form("txtAccountno")
		
	
		obj = server.CreateObject("ReportPurposeOnly.Reportonly")
		rs = Server.CreateObject("adodb.recordset")
		
		sqlstr="SELECT *  FROM atmgllnk where code = '"& GLLnkcode &"'"
		
		rs=obj.SingleSelectStat(sqlStr)

		
		if not rs.EOF and not rs.BOF then
			Response.Redirect ("frmATMGLLink.aspx?record=" & "ATM GL Link Code Already Exists")
		end if
		
		objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")
		
		strDataFlds="CODE, MODULEID, GLCODE, ACCNO"
		
		strDataVals= "'" & ucase(trim(GLLnkcode)) & "','" & ucase(trim(Modcode)) & "','" & trim(Glcode) & "','" & trim(Accountno) & "'"
		
				transarray(0,0)="I"	             'passing the TransactionType
				transarray(0,1)="atmgllnk"         'passing the tablename
				transarray(0,2)=strDataFlds		 'passing the FieldNames	
				transarray(0,3)=strDataVals      'passing the Fieldvalues
				transarray(0,4)=""				 'passing the Condition
				
				objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
				
				if objmsg="Transaction Sucessful." then
				
				'Response.Write (objmsg)
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			else
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			end if
			
			objmsg=nothing
			
else if kstr="ATMGLLnkmodify" then
		Dim transarray(0,4)
		
		GLLnkcode=Request.Form("txtGLLnkcode")	
		Modcode=Request.Form("txtModcode")
		Glcode=Request.Form("txtGlcode")
		Accountno=Request.Form("txtAccountno")
		
		objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")
		
		strDataFlds="MODULEID, GLCODE, ACCNO"
		
		strDataVals= "'" & ucase(trim(Modcode)) & "'~'" & trim(Glcode) & "'~'" & trim(Accountno) & "'"
		
		strcon = "code = '"& GLLnkcode &"'"

		transarray(0,0)="U"	             'passing the TransactionType
		transarray(0,1)="atmgllnk"         'passing the tablename
		transarray(0,2)=strDataFlds	 'passing the FieldNames	
		transarray(0,3)=strDataVals     'passing the Fieldvalues
		transarray(0,4)=strcon			 'passing the Condition
				
			objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			if objmsg="Transaction Sucessful." then
				
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			else
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			end if
			
			objmsg=nothing

else if kstr="ATMGLLnkdelete" then
		Dim transarray(0,4)
		
		GLLnkcode=Request.Form("txtGLLnkcode")	
		
		objTrans= SERVER.CreateObject("GeneralTransactions.DBTransactions")
		
		strcon = "code = '"& GLLnkcode &"'"

		transarray(0,0)="D"	             'passing the TransactionType
		transarray(0,1)="atmgllnk"       'passing the tablename
		transarray(0,2)=""				 'passing the FieldNames	
		transarray(0,3)=""				 'passing the Fieldvalues
		transarray(0,4)=strcon			 'passing the Condition
				
			objmsg= ObjTrans.DataTransactions(Transarray,,,,,"N")
			if objmsg="Transaction Sucessful." then
				
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			else
				Response.Redirect ("frmATMGLLink.aspx?record=" & objmsg)
			end if
			
			objmsg=nothing

		end if  ''kstr="ATMGLLnkmodify"
		
%>

<title></title>
	</head>
	<body>
		<form name="frmacc">
			<input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>
		</form>
	</body>
</html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
