<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="getAtmDtls.aspx.vb" Inherits="eSmartDotNet.getAtmDtls" %>
<HTML>
	<HEAD>
		<%
	dim strVal
	dim strArr
	dim strIndvVal
	dim strResult,batchNo,tranNo, sqlStr

	rs = Server.CreateObject("adodb.recordset")
	strVal=request.querystring("st")
	strArr=split(strVal,"|")

if strArr(0)="GETCUSTOMERID" then
	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT CUSTOMERID FROM " & strArr(3) & "MST WHERE ACCNO='" & strArr(5) & "' AND GLCODE='" & strArr(4) & "' AND BRANCHCODE='" & strArr(1) & "' "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					'do until rs.EOF
						strResult = rs(0).value 
					'rs.movenext()
					'loop
					'strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing

else if strArr(0)="DTAILSCRD" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT a.CARDCATEGORYTYPE, b.DESCRIPTION, a.CARDSCOPETYPE,c.DESCRIPTION, a.CARDLIMIT, a.CASHLIMIT, to_char(a.ISSUEDATE,'DD-Mon-YYYY') , to_char(a.VALIDFROMDATE,'DD-Mon-YYYY') , to_char(a.VALIDUPTODATE,'DD-Mon-YYYY'), a.NAME, a.MAINCARDNO, a.RELATIONID FROM ATMCARDLNKDTLS a,GENCARDCATEGORYSMST b, GENCARDSCOPEMST c WHERE a.cardno='" & strArr(1) & "' AND b.CARDCATEGORYTYPE=a.CARDCATEGORYTYPE AND c.CARDSCOPETYPE=a.CARDSCOPETYPE "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					'do until rs.EOF
						strResult = rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value 
					'rs.movenext()
					'loop
					'strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing
		
else if strArr(0)="GETCRDVALID" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT COUNT(*),CARDNO FROM ATMCARDLNKDTLS where cardtype='1' AND status='R' and accno='" & strArr(4) & "' and glcode='" & strArr(3) & "' and branchcode='" & strArr(1) & "' GROUP BY CARDNO "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					
						strResult = rs(0).value & "~" & rs(1).value
					
				end if
			end if
		rs=nothing

else if strArr(0)="SETCARDSCOPE" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	

	sqlStr= "SELECT g.CARDSCOPETYPE,g.DESCRIPTION FROM GENCARDSCOPEMST g , atmcrddtls a WHERE g.status = 'R'  AND g.CARDSCOPETYPE= a.CARDSCOPETYPE AND a.ACCOUNT1= (SELECT " & strArr(1) & strArr(3) & " ||lpad(" & strArr(4) & ",7,'0') FROM  dual)"

		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
						strResult = rs(0).value & "~" & rs(1).value
				end if
			end if
		rs=nothing

else if strArr(0)="CHECKCARDSCOPE" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")

	sqlStr = " SELECT account1 FROM ATMCRDDTLS WHERE actioncode = 'I' AND status = 'R' AND cardnumber IS NULL AND account1 = (select " & strArr(1) & strArr(3) & " ||lpad("& strArr(4) &",7,'0') from dual)"
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
						strResult = "YES"
						else
						strResult = "NO" 						
				end if
			end if
		rs=nothing
else if strArr(0)="VCRDNO" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT COUNT(*) FROM ATMCARDLNKDTLS where cardno='" & strArr(1) & "' "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					
						strResult = rs(0).value 
					
				end if
			end if
		rs=nothing
		
 else if strArr(0)="ACRDTAIL" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT a.SNO, a.CARDNO,  b.DESCRIPTION crdtyp , c.DESCRIPTION Categorytyp  , d.DESCRIPTION Scope, TO_CHAR(a.ISSUEDATE, 'DD-Mon-YYYY') issdate, TO_CHAR(a.VALIDUPTODATE, 'DD-Mon-YYYY')  VALIDUPTODATE, TO_CHAR(a.CLOSEDATE, 'DD-Mon-YYYY') CLOSEDATE, CASE WHEN a.STATUS = 'C' THEN 'Closed' WHEN a.STATUS = 'B' THEN 'Blocked'  WHEN a.STATUS = 'L' THEN 'Lost'  WHEN a.STATUS = 'E' THEN 'Expired' WHEN a.STATUS = 'R' THEN 'Running' END status, a.REMARKS FROM ATMCARDLNKDTLS a, GENCARDTYPEMST b, GENCARDCATEGORYSMST c, GENCARDSCOPEMST d WHERE b.CARDTYPE = a.CARDTYPE AND c.CARDCATEGORYTYPE = a.CARDCATEGORYTYPE AND d.CARDSCOPETYPE = a.CARDSCOPETYPE AND a.glcode='" & strArr(1) & "' AND a.accno='" & strArr(2) & "' AND a.branchcode='" & strArr(3) & "' ORDER BY TO_NUMBER(a.SNO) "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "|"
					rs.movenext() 
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing

else if strArr(0)="LISTDETAILS" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT " & strArr(2) & " FROM ATMCARDLNKDTLS a, GENCARDTYPEMST b WHERE b.CARDTYPE = a.CARDTYPE " & strArr(3) & " " & strArr(1) & "  "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(4) = "ISSUEDATE" then
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "|"
						else if strArr(4) = "VALIDUPTODATE" then
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "|"
						else
							strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "|"
						end if
						
						rs.movenext() 
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing	

elseif strArr(0)="ATMCARDWISEACCNO" then
strResult=""

obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
dim strfullaccno , strbrcode,strmodid,strglcode,straAccno
strfullaccno = strArr(1)
strbrcode = mid(strfullaccno,1,3) 

strglcode = mid(strfullaccno,4,6) 
straAccno =  clng(mid(strfullaccno,10,7))
if strglcode = "102020" then
strmodid = "SB"
else if  strglcode = "102030" then
strmodid = "CA"
else if  mid(strglcode,1,3) = "206" then
strmodid = "CC"
end if 
 cond = ""
if strArr(2) <> "" then
	cond = " and EFFECTIVEDATE = '"& format(cdate(strArr(2)),"dd-MMM-yyyy") &"'"
end if


sqlstr=" SELECT EFFECTIVEDATE,MODULEID, branchcode||GLCODE||lpad(accno,7,'0'), Batchno,tranno, AMOUNT,remarks,RATEREFCODE   FROM " & strmodid & "tranday WHERE chqfvg in ('ATM','POS','ECO','ECM') and glcode = '"& strglcode &"' and accno = '"& straAccno &"' AND BRANCHCODE ='"& strbrcode &"' AND CURRENCYCODE ='INR' " & cond & _ 
"  UNION ALL  " & _
" SELECT EFFECTIVEDATE,MODULEID, branchcode||GLCODE||lpad(accno,7,'0'),Batchno,tranno,AMOUNT,remarks,RATEREFCODE   FROM " & strmodid & "tran WHERE chqfvg  in ('ATM','POS','ECO','ECM') and glcode = '"& strglcode &"' and accno = '"& straAccno &"' AND  BRANCHCODE ='"& strbrcode &"' AND CURRENCYCODE ='INR' "  & cond & " order by EFFECTIVEDATE,Batchno,tranno"

rs=obj.SingleSelectStat(sqlstr)

	if obj.ConnError="Connected" then
		if not rs.BOF and not rs.EOF then
				do until rs.EOF
					strResult=strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value  & "~" & rs(7).value & "|"
					rs.movenext()
				loop
				
				strResult=mid(strResult,1,strResult.length-1)
				
			end if
			strResult= strArr(0) & "*" & strResult
	end if			

else if strArr(0)="CARDSTATUS" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	'sqlStr = " SELECT " & strArr(2) & " FROM ATMCARDLNKDTLS a, GENCARDTYPEMST b WHERE b.CARDTYPE = a.CARDTYPE " & strArr(3) & " " & strArr(1) & "   ORDER BY to_number(branchcode),to_number(glcode),TO_NUMBER(accno)"
				sqlStr = " SELECT " & strArr(2) & " FROM ATMCARDLNKDTLS a, GENCARDTYPEMST b WHERE b.CARDTYPE = a.CARDTYPE " & strArr(3) & " " & strArr(1) & "   ORDER BY ISSUEDATE"
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						if strArr(4) = "ISSUEDATE" then
							strResult = strResult & rs(0).value &"~" &  rs(1).value & rs(2).value & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value  & "~" & rs(8).value  & "~" & rs(9).value &  "~" & rs(10).value & "~" & rs(11).value & "|"
						else if strArr(4) = "VALIDUPTODATE" then
							strResult = strResult & rs(0).value & "~" &  rs(1).value & rs(2).value & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value  & "~" & rs(9).value &  "~" & rs(10).value &  "~" & rs(11).value & "|"
						else
							strResult = strResult & rs(0).value & "~" &  rs(1).value & rs(2).value & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "~" & rs(8).value & "~" & rs(9).value & "~" & rs(10).value & "~" & rs(11).value & "~" & rs(12).value & "|"
						end if
						
						rs.movenext() 
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing	
		
		
else if strArr(0)="CRDDETAILS" then

	strResult=""
	
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	sqlStr = " SELECT REFNUM, branchcode, DECODE(account1type,'10','SB','20','CA',account1type) moduleid, SUBSTR(account1,4,6) glcode , account1 accno, firstname, mobilephone, CARDNUMBER FROM atmcrddtls WHERE transtatus = 'A' AND branchcode='" & strArr(1) & "' " & strArr(2) & " " & strArr(3) & " ORDER BY refnum "
		
		rs=obj.SingleSelectStat(sqlStr)
			if obj.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					do until rs.EOF
						
						strResult = strResult & rs(0).value & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~" & rs(5).value & "~" & rs(6).value & "~" & rs(7).value & "|"
						
						rs.movenext() 
					loop
					strResult=mid(strResult,1,strResult.length-1)
				end if
			end if
		rs=nothing	



			
end if


%>
		<script>
		function Details()
		{
			var type="<%=strArr(0)%>"
			var strResult="<%=strResult%>"
			
			if(type=="GETCUSTOMERID")
				window.attachEvent(window.parent.getCustdtls(strResult))
			else if(type=="DTAILSCRD")
				window.attachEvent(window.parent.popDetails(strResult))
			else if(type=="GETCRDVALID")
				window.attachEvent(window.parent.popCrVald(strResult))
			else if(type=="SETCARDSCOPE")
				window.attachEvent(window.parent.GetCardScope(strResult))
			else if(type=="CHECKCARDSCOPE")
				window.attachEvent(window.parent.popCheckScope(strResult))
			else if(type=="VCRDNO")
				window.attachEvent(window.parent.popVcrdno(strResult))
			else if(type=="ACRDTAIL")
				window.attachEvent(window.parent.popAcdtail(strResult))	
			else if ((type=="LISTDETAILS") || (type=="CRDDETAILS") || (type=="CARDSTATUS"))
				window.attachEvent(window.parent.popLstdtail(strResult))
			else if(type=="ATMCARDWISEACCNO")
			 {
				window.attachEvent(window.parent.DisplayATMCardWise(strResult))			 
			 }
		
			window.close()
		}
		</script>
	</HEAD>
	<body onload="Details()">
		<form id="frmDetails" method="post" runat="server">
			<input type="button" name="hdnResult" value="strResult">
		</form>
	</body>
</HTML>
