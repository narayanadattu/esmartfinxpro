<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CardLnkInsert.aspx.vb" Inherits="eSmartDotNet.CardLnkInsert" %>
<%

dim obj,obj1,obj2,obj3,obj4,rs,rs1,rs2,rs3,Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno,stAc
obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj2 = server.CreateObject("ReportPurposeOnly.Reportonly")
obj3 = server.CreateObject("ReportPurposeOnly.Reportonly")
obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")

dim Arrtrans(50,4)

dim stBnknam
appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("empval")
strval=split(strmode,"~")

	sqlStr="SELECT depcertificate from genbankparm " ''for Bank name 
		
	rs3=obj1.SingleSelectStat(sqlStr)
	
	if obj1.ConnError="Connected" then
		if not rs3.BOF and not rs3.EOF then
			stBnknam = rs3(0).value 
		end if
	end if
	
	rs3 = nothing
	obj1 = nothing

if strval(0)="INSERT" then
	
		strInst=split(strval(1),"|")
		
		sqlStr="SELECT NVL(MAX(SNO),0)+1 num FROM ATMCARDLNKDTLS WHERE accno='" & strInst(3) & "' AND glcode='" & strInst(2) & "' AND branchcode='" & strInst(0) & "'" ''for table name 
		
		rs=obj2.SingleSelectStat(sqlStr)
		
		if obj2.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				accno = rs(0).value 
			end if
		end if
		
		rs = nothing
		
		
		
			strcolnames=" BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, SNO, CARDNO, CUSTOMERID, NAME, CARDTYPE, CARDCATEGORYTYPE, CARDSCOPETYPE, ISSUEDATE, VALIDFROMDATE, VALIDUPTODATE, CARDLIMIT, CASHLIMIT, MAINCARDNO, RELATIONID, APPLICATIONDATE, USERID, MACHINEID, STATUS, SYSTEMDATE "
				
			strdelvar="'" & strInst(0) & "','" & strInst(1) & "','" & strInst(2) & "','" & strInst(3) & "','" & accno & "','" & strInst(4) & "','" & strInst(5) & "','" & strInst(6) & "','" & strInst(7) & "','" & strInst(8) & "','" & strInst(9) & "','" & strInst(10) & "','" & strInst(11) & "','" & strInst(12) & "','" & strInst(13) & "','" & strInst(14) & "','" & strInst(15) & "','" & strInst(16) & "','" & appdate & "','" & userid & "','" & machineid & "','R',SYSDATE"
			
		
			sqlStr="SELECT  LPAD(" & strInst(3) & ",7,0) FROM DUAL " ''for table name 
			
			rs=obj3.SingleSelectStat(sqlStr)
			
			if obj3.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					stAc = rs(0).value 
				end if
			end if
			
			rs = nothing
			obj3 = nothing
			
			
				Arrtrans(0,0)="I"			
				Arrtrans(0,1)="ATMCARDLNKDTLS"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=""
				
					if  stBnknam = "MAHARAJA" or stBnknam = "ELURU" or stBnknam =  "PCUB" then
			
			
			
			
					strcolnames1 = "ACTIONCODE, cardnumber, TRANSTATUS, GENYN "
					strdelvar1 = "'U'~'" & strInst(4) & "'~'P'~'N'"
					'strdivcnd1 = " cardnumber IS NULL AND ACCOUNT1='" & strInst(0) & strInst(2) & "LPAD(" & strInst(3) & ",7,0)'"
					strdivcnd1 = " cardnumber IS NULL AND ACCOUNT1='" & strInst(0) & strInst(2) &  stAc & "'"
			
			sqlStr="SELECT cardnumber FROM ATMCRDDTLS where " & strdivcnd1
			rs=obj2.SingleSelectStat(sqlStr)
		
		if obj2.ConnError="Connected" then
			if not rs.BOF and not rs.EOF then
				if rs.recordcount > 0 then		
			
					Arrtrans(1,0) = "U"			
					Arrtrans(1,1) = "ATMCRDDTLS"
					Arrtrans(1,2) = strcolnames1
					Arrtrans(1,3) = strdelvar1
					Arrtrans(1,4) = strdivcnd1
					
					end if
					end if
				end if
		
		rs = nothing
		obj2 = nothing
				
				end if
				
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
			
			Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
			
			Strmsg = Strmsg 
			
			Response.Write (Strmsg)	
			obj=nothing
		 
	
else if strval(0)="MODIFY" then
	
			strcolnames=" BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CARDNO, CUSTOMERID, NAME, CARDTYPE, CARDCATEGORYTYPE, CARDSCOPETYPE, ISSUEDATE, VALIDFROMDATE, VALIDUPTODATE, CARDLIMIT, CASHLIMIT, MAINCARDNO, RELATIONID, APPLICATIONDATE, USERID, MACHINEID, REMARKS, STATUS, CLOSEDATE, SYSTEMDATE"
			
			
			strInst=split(strval(1),"|")
			
			sqlStr="SELECT  LPAD(" & strInst(3) & ",7,0) FROM DUAL " ''for table name 
			
			rs=obj3.SingleSelectStat(sqlStr)
			
			if obj3.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					stAc = rs(0).value 
				end if
			end if
			
			rs = nothing
			obj3 = nothing
			
			strCond = " GLCODE='" & strInst(2) & "' AND ACCNO='" & strInst(3) & "' AND CARDNO='" & strInst(4) & "' "
				
			strdelvar="'" & strInst(0) & "'~'" & strInst(1) & "'~'" & strInst(2) & "'~'" & strInst(3) & "'~'" & strInst(4) & "'~'" & strInst(5) & "'~'" & strInst(6) & "'~'" & strInst(7) & "'~'" & strInst(8) & "'~'" & strInst(9) & "'~'" & strInst(10) & "'~'" & strInst(11) & "'~'" & strInst(12) & "'~'" & strInst(13) & "'~'" & strInst(14) & "'~'" & strInst(15) & "'~'" & strInst(16) & "'~'" & appdate & "'~'" & userid & "'~'" & machineid & "'~'" & strInst(17) & "'~'" & strInst(18) & "'~'" & strInst(19) & "'~SYSDATE"
			
				
				Arrtrans(0,0)="U"			
				Arrtrans(0,1)="ATMCARDLNKDTLS"
				Arrtrans(0,2)=strcolnames
				Arrtrans(0,3)=strdelvar
				Arrtrans(0,4)=strCond
				
			if  stBnknam = "MAHARAJA" or stBnknam = "ELURU" or stBnknam =  "PCUB" then
				
				
					strcolnames1 = "STATUS,USERID, MACHINEID, SYSTEMDATE"
					strdelvar1 = "'" & strInst(18) & "'~'" & userid & "'~'" & machineid & "'~SYSDATE"
					strdivcnd1 = " ACCOUNT1='" & strInst(0) & strInst(2) &  stAc & "' AND STATUS = 'R'"
					
			
					Arrtrans(1,0) = "U"			
					Arrtrans(1,1) = "ATMCRDDTLS"
					Arrtrans(1,2) = strcolnames1
					Arrtrans(1,3) = strdelvar1
					Arrtrans(1,4) = strdivcnd1
				
				end if
		
				Response.Write (Arrtrans(acnt,0) & "<br>")
				Response.Write (Arrtrans(acnt,1) & "<br>")
				Response.Write (Arrtrans(acnt,2) & "<br>")
				Response.Write (Arrtrans(acnt,3) & "<br>")
				Response.Write (Arrtrans(acnt,4) & "<br>")
		
	Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		 obj=nothing


end if

	Response.Redirect ("frmATMCardlnk.aspx?record=" & Strmsg)


%>
