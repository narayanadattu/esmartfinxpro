	<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmcardcustomer.aspx.vb" Inherits="eSmartDotNet.frmcardcustomer" %>
<%
	dim strmessage

	strmessage=Request.QueryString("record")
	
	dim obj, rs, obj1, rs1, obj2, rs2
	
	dim impYn,brcod,Refnm,lef,multi,Sln

	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN","CODE='CARDISS'")
	
	if not rs.EOF and not rs.BOF then
		impYn = rs(0).value
	end if
	
	obj1 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs1 = obj1.SingleRecordSet("ATMCRDDTLS","NVL(MAX(REFNUM),0) refno","")
	
	if not rs1.EOF and not rs1.BOF then
		Refnm = rs1(0).value
	end if


%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Language" content="en-us">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
	<title>Customer Card Request</title>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"></SCRIPT>
	<SCRIPT LANGUAGE="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"></SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE="javascript">
	
	function Display()
	{
		var IMP="<%=impYn%>"
		
		if(IMP=="Y")
		{
			
		}
		else
		{
			alert("Please Contact SAS Enterprises")
			location.href="http://"+"<%=session("moduledir")& "/commonmodule.aspx"%>"
		}
		
		var stRef,Ref,stSnl
		
		stRef = "<%=Refnm%>"
		
		
		Ref = parseInt(stRef)+1
		
		window.document.frmCardRequst.hidRef.value = Ref
	}
	
	function DispTranMsg()
	{
		if('<%=strmessage%>'!="")
		{
			var mess="<%=strmessage%>"
			alert(mess)
			location.replace("../ATM/frmcardcustomer.aspx")
		}
	}
	
	
	function Branch()
	{
		var branch="Branch"	  
		var user="<%=session("userid")%>"  
		st=branch+"|"+user

		window.showModalDialog('<%="http://" & session("moduledir") & "/GENSBCA/" %>'+"sblist.aspx" + "?"+"st="+st,window,"status:no;"+"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:235px")	
	}

	function Branchid(kstr)
	{	
		assign(kstr,window.document.frmCardRequst.txtBrdesc,window.document.frmCardRequst.txtbranchcode)
	}
	
	function Tellmodule()
	{	clear()
		if(window.document.frmCardRequst.txtbranchcode.value=="")
		{
			alert("Please Select Branch Code.")
			return
		}
		stmod="ModuleTell"; 
		stbr=window.document.frmCardRequst.txtbranchcode.value.toUpperCase();
		kstr=stmod+"|"+stbr
		
		window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function modulecode(kstr)
	{
		var strMod=kstr.split("-----")
		window.document.frmCardRequst.txtModid.value=strMod[1]
		window.document.frmCardRequst.txtModiddesc.value=strMod[0]
		window.document.frmCardRequst.txtGlcodedesc.value=""
		window.document.frmCardRequst.txtGlcode.value=""
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtAccNo.value=""
	}
	
	function TellerGl()
	{clear()
		if(window.document.frmCardRequst.txtModid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmCardRequst.txtbranchcode.value.toUpperCase();
		modid=window.document.frmCardRequst.txtModid.value.toUpperCase();
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog('<%="http://" & session("moduledir")& "/customer/"%>'+"silist.aspx" + "?"+"st="+kstr,window,"status:no;"+"DialogWidth:390px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmCardRequst.txtGlcodedesc,window.document.frmCardRequst.txtGlcode)
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtAccNo.value=""
	}
	
	function Acccode()
	{clear()
		if(window.document.frmCardRequst.txtGlcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		stacc="Telleraccno"
		brchCd=window.document.frmCardRequst.txtbranchcode.value;
		ModId=window.document.frmCardRequst.txtModid.value.toUpperCase();
		GlCd=window.document.frmCardRequst.txtGlcode.value.toUpperCase();
		
		kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+window.document.frmCardRequst.txtcurrencycode.value.toUpperCase()+"|"+"='R'"
		
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
		
		window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	}

	function accountid(kstr)
	{
		assign(kstr,window.document.frmCardRequst.txtAccNm,window.document.frmCardRequst.txtAccNo)
		getData()
	}
	
	function getData()
	{
		var st="GETCARDDAT"+"|"+window.document.frmCardRequst.txtbranchcode.value+"|"+window.document.frmCardRequst.txtModid.value.toUpperCase()+"|"+window.document.frmCardRequst.txtGlcode.value.toUpperCase()+"|"+window.document.frmCardRequst.txtAccNo.value+"|"+"ATMCRDDTLS"
		
		window.document.all['iGetDtls'].src="../GEN/getDtls.aspx?st="+st
	}
	
	function getCard(str)
	{
		//alert(" str =  "+str)
		if(str == "No Data")
		{
			alert("For These Account Card Request Is Already Generated")
			return;
		}
		window.document.frmCardRequst.hidAdd.value = ""
		
		var kStr=str.split("~")
		
		window.document.frmCardRequst.txtCardTitle.value = kStr[7]
		window.document.frmCardRequst.txtFamilynam.value = kStr[6]
		window.document.frmCardRequst.txtFirstnam.value = ""
		window.document.frmCardRequst.txtBirthdat.value = kStr[0]
		window.document.frmCardRequst.txtBirthcity.value = ""
		window.document.frmCardRequst.txtMobphon.value = kStr[1]
		window.document.frmCardRequst.txtCardmailid.value = kStr[2]
		window.document.frmCardRequst.txtAcNom.value = kStr[9]
		window.document.frmCardRequst.txtAcctyp.value = kStr[8]
		
		window.document.frmCardRequst.hidAdd.value = kStr[3]
		
		window.document.frmCardRequst.txtMailmobil.value = ""
		window.document.frmCardRequst.txtAdd1.value = kStr[3].substring(0, 30);
		window.document.frmCardRequst.txtAdd2.value = kStr[3].substring(30, 60);
		window.document.frmCardRequst.txtAdd3.value = kStr[3].substring(60, 90);
		window.document.frmCardRequst.txtAdd4.value = kStr[3].substring(90, 120);
		window.document.frmCardRequst.txtCitycode.value = kStr[5].substring(0, 3);
		window.document.frmCardRequst.txtZipcod.value = kStr[5]
		
		window.document.frmCardRequst.hidcit.value = window.document.frmCardRequst.txtCitycode.value
		window.document.frmCardRequst.hidZip.value = window.document.frmCardRequst.txtZipcod.value

		window.document.frmCardRequst.txtMailAd1.value = ""
		window.document.frmCardRequst.txtMailAd2.value = ""
		window.document.frmCardRequst.txtMailAd3.value = ""
		window.document.frmCardRequst.txtMailAd4.value = ""
		window.document.frmCardRequst.txtMailcitycod.value = ""
		window.document.frmCardRequst.txtMailcode.value = ""
		alert("Please Enter Proper Surname , Fname, Middle Name")
	}


function Scop()
	{
//	clear()
		if (window.document.frmCardRequst.txtbranchcode.value == "")
		{
			alert("Branch Code should not be null")
			return
		}
		if(window.document.frmCardRequst.txtModid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		
	if(window.document.frmCardRequst.txtGlcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		
	if (window.document.frmCardRequst.txtAccNo.value =="")
		{
			alert("Acc No should not be null")
			return
		}
	
	
		stmod="ATMSCOPTYPE"; 
		
		kstr=stmod
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function sctype(kstr)
	{	
		assign(kstr,window.document.frmCardRequst.txtdbtScopdesc,window.document.frmCardRequst.txtdbtScopval)
	}
		
	function DescrptionDisp(strTxt)
	{
		sBr = window.document.frmCardRequst.txtbranchcode.value.toUpperCase()
		sMod = window.document.frmCardRequst.txtModid.value.toUpperCase()
		sGL = window.document.frmCardRequst.txtGlcode.value.toUpperCase()
		sAccno = window.document.frmCardRequst.txtAccNo.value.toUpperCase()
		sCur = window.document.frmCardRequst.txtcurrencycode.value.toUpperCase()
		 clear()
		if(strTxt=="txtModid")
		{ 
			if(window.document.frmCardRequst.txtModid.value=="")
			{
				return;
			}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"'~~"+strTxt
				
			window.document.frmCardRequst.txtModiddesc.value = ""
			window.document.frmCardRequst.txtGlcode.value = ""
			window.document.frmCardRequst.txtGlcodedesc.value = ""
			window.document.frmCardRequst.txtAccNo.value = ""
			window.document.frmCardRequst.txtAccNm.value = ""
		}
		
		if(strTxt=="txtGlcode")
		{ 
			if(window.document.frmCardRequst.txtGlcode.value=="")
			{
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
				
			window.document.frmCardRequst.txtGlcodedesc.value = ""
			window.document.frmCardRequst.txtAccNo.value = ""
			window.document.frmCardRequst.txtAccNm.value = ""	
		}
		
		if(strTxt=="txtAccNo")
		{
			if(window.document.frmCardRequst.txtAccNo.value=="")
			{
				return;
			}
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
			window.document.frmCardRequst.txtAccNm.value = ""
		}
		
		
		if(strTxt=="txtdbtScopval")
		{ 
			if(window.document.frmCardRequst.txtdbtScopval.value=="")
			{
				return;
			}
			
			st="DescDisplay~GENCARDSCOPEMST~DESCRIPTION~CARDSCOPETYPE='"+window.document.frmCardRequst.txtdbtScopval.value+"' AND status='R' ~~"+strTxt
		}
		
		//alert("st2 = "+st)
		window.document.all["iBatch"].src="../GENSBCA/querydisplay.aspx?st="+st
	}
	
	function DescDisplay(stri)
	{
		//alert("stri = "+stri)
		var strtype=new String()
		strtype=stri.split("~")
		
		var StrArrFld=new String()
		StrArrFld=strtype[0].split("|")
			
		if(strtype[1]=="txtModid")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid ModuleId")
				window.document.frmCardRequst.txtModid.value=""
				window.document.frmCardRequst.txtModiddesc.value=""
				window.document.frmCardRequst.txtModid.focus()
				return;
			}
			window.document.frmCardRequst.txtModiddesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtGlcode")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Glcode")
				window.document.frmCardRequst.txtGlcode.value=""
				window.document.frmCardRequst.txtGlcodedesc.value=""
				window.document.frmCardRequst.txtGlcode.focus()
				return;
			}
			window.document.frmCardRequst.txtGlcodedesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtAccNo")
		{
			if(StrArrFld[0]=="No")
			{
				alert("Invalid Account No.")
				window.document.frmCardRequst.txtAccNo.value=""
				window.document.frmCardRequst.txtAccNm.value=""
				window.document.frmCardRequst.txtAccNo.focus()
				return;
			}
			window.document.frmCardRequst.txtAccNm.value=StrArrFld[0]
			getData()
		}
		
		
		if(strtype[1]=="txtdbtScopval")
		{
						
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Scope Type")
					window.document.frmCardRequst.txtdbtScopval.value=""
					window.document.frmCardRequst.txtdbtScopdesc.value=""
					window.document.frmCardRequst.txtdbtScopval.focus()
					return;
				}
				window.document.frmCardRequst.txtdbtScopdesc.value=StrArrFld[0]
		}
	}
	
	function Addresschange()
	{
		if (window.document.frmCardRequst.opt1(0).checked==true)
		{
			if(window.document.frmCardRequst.chkMail.checked==true)
			{
				window.document.frmCardRequst.txtMailAd1.value = window.document.frmCardRequst.hidAdd.value.substring(0, 45);
				window.document.frmCardRequst.txtMailAd2.value = window.document.frmCardRequst.hidAdd.value.substring(45, 90);
				window.document.frmCardRequst.txtMailAd3.value = window.document.frmCardRequst.hidAdd.value.substring(90, 135);
				window.document.frmCardRequst.txtMailAd4.value = window.document.frmCardRequst.hidAdd.value.substring(135, 180);
				window.document.frmCardRequst.txtMailcitycod.value = window.document.frmCardRequst.hidcit.value;
				window.document.frmCardRequst.txtMailcode.value = window.document.frmCardRequst.hidZip.value;
			}
			else
			{
				window.document.frmCardRequst.txtMailAd1.value = ""
				window.document.frmCardRequst.txtMailAd2.value = ""
				window.document.frmCardRequst.txtMailAd3.value = ""
				window.document.frmCardRequst.txtMailAd4.value = ""
				window.document.frmCardRequst.txtMailcitycod.value = ""
				window.document.frmCardRequst.txtMailcode.value = ""
			}
		}
		if (window.document.frmCardRequst.opt1(1).checked==true)
		{
			if(window.document.frmCardRequst.chkMail.checked==true)
			{
				window.document.frmCardRequst.txtMailAd1.value = window.document.frmCardRequst.txtAdd1.value;
				window.document.frmCardRequst.txtMailAd2.value = window.document.frmCardRequst.txtAdd2.value;
				window.document.frmCardRequst.txtMailAd3.value = window.document.frmCardRequst.txtAdd3.value;
				window.document.frmCardRequst.txtMailAd4.value = window.document.frmCardRequst.txtAdd4.value;
				window.document.frmCardRequst.txtMailcitycod.value = window.document.frmCardRequst.txtCitycode.value;
				window.document.frmCardRequst.txtMailcode.value = window.document.frmCardRequst.txtZipcod.value;
			}
			else
			{
				window.document.frmCardRequst.txtMailAd1.value = ""
				window.document.frmCardRequst.txtMailAd2.value = ""
				window.document.frmCardRequst.txtMailAd3.value = ""
				window.document.frmCardRequst.txtMailAd4.value = ""
				window.document.frmCardRequst.txtMailcitycod.value = ""
				window.document.frmCardRequst.txtMailcode.value = ""
			}
		}
	}
	
	function Ok()
	{
		if (window.document.frmCardRequst.opt1(0).checked==true)
		{
			if(window.document.frmCardRequst.txtModid.value=="")
			{
				alert("Please Select Module ID.")
				return;
			}
			if(window.document.frmCardRequst.txtGlcode.value=="")
			{
				alert("Please Select Gloce Code.")
				return;
			}
			if(window.document.frmCardRequst.txtAccNo.value=="")
			{
				alert("Please Select Account No.")
				return;
			}
			
			if (window.document.frmCardRequst.txtdbtScopval.value =="")
			{
			alert("Card Type Should Not Be Null")
			return
			}
	
			if(window.document.frmCardRequst.SelResidence.value=="")
			{
				alert("Please Select Residence Status")
				return;
			}
			if(window.document.frmCardRequst.SelEmpstat.value=="")
			{
				alert("Please Select Employment Status")
				return;
			}
			if(window.document.frmCardRequst.SelMarstat.value=="")
			{
				alert("Please Select Marital Status")
				return;
			}
			if(window.document.frmCardRequst.SelDeliver.value=="")
			{
				alert("Please Select Delivery Mode")
				return;
			}
			
			if(window.document.frmCardRequst.txtSurName.value=="")
			{
				alert("Please Enter Sur Name")
				return;
			}
			
			if(window.document.frmCardRequst.txtFirstnam.value=="")
			{
				alert("Please Enter Print on card Name")
				return;
			}
			if(window.document.frmCardRequst.txtMiddleName.value=="")
			{
				alert("Please Enter Middle Name")
				return;
			}
			if(window.document.frmCardRequst.txtFatherName.value=="")
			{
				alert("Please Enter Father Name")
				return;
			}
			if(window.document.frmCardRequst.txtMailAd1.value=="")
			{
				alert("Please Enter Mailing Address")
				return;
			}
			if(window.document.frmCardRequst.txtAdd1.value=="")
			{
				alert("Please Enter Address1")
				return;
			}
			
			if (window.document.frmCardRequst.txtAdd1.value != "")
			{
				if(window.document.frmCardRequst.txtCity.value=="")
				{
					alert("Please Enter City")
					return;
				}
				
				if(window.document.frmCardRequst.SelState.value =="")
				{
					alert("Please Enter State")
					return;
				}
			}
			
			if(window.document.frmCardRequst.txtBirthdat.value=="")
			{
				alert("Please Enter Birthdate")
				return;
			}
			if(window.document.frmCardRequst.txtMobphon.value=="")
			{
				alert("Please Enter Mobile")
				return;
			}
			if(window.document.frmCardRequst.txtMailmobil.value=="")
			{
				alert("Please Enter Mailing Mobile")
				return;
			}

			if(window.document.frmCardRequst.txtAcctyp.value=="SB")
			{
				window.document.frmCardRequst.txtAcctyp.value="10"
			}
			else if(window.document.frmCardRequst.txtAcctyp.value=="CA")
			{
				window.document.frmCardRequst.txtAcctyp.value="20"
			}
			
			var kst, refnoQer
		
		
		var el = document.getElementById('SelState')
		var selectedStateText = el.options[el.selectedIndex].text

			refnoQer = "(select NVL(MAX(REFNUM),0)+1 from ATMCRDDTLS)"
			
			kst = "I"+"|"+window.document.frmCardRequst.SelOwner.value.toUpperCase()+"|"+//1
					window.document.frmCardRequst.SelBasicard.value.toUpperCase()+"|"+//2
					window.document.frmCardRequst.SelPhtoindicate.value.toUpperCase()+"|"+//3
					window.document.frmCardRequst.SelResidence.value.toUpperCase()+"|"+//4
					window.document.frmCardRequst.SelEmpstat.value.toUpperCase()+"|"+//5
					window.document.frmCardRequst.SelMarstat.value.toUpperCase()+"|"+//6
					window.document.frmCardRequst.SelDeliver.value.toUpperCase()+"|"+//7
					window.document.frmCardRequst.SelGender.value.toUpperCase()+"|"+//8
					window.document.frmCardRequst.SelVipFlag.value.toUpperCase()+"|"+//9
					window.document.frmCardRequst.SelIssueclient.value.toUpperCase()+"|"+//10
					window.document.frmCardRequst.txtCardTitle.value.toUpperCase()+"|"+//11
					window.document.frmCardRequst.txtFamilynam.value.toUpperCase()+"|"+//12
					window.document.frmCardRequst.txtFirstnam.value.toUpperCase()+"|"+//13
					window.document.frmCardRequst.txtBirthdat.value.toUpperCase()+"|"+//14
					window.document.frmCardRequst.txtBirthcity.value.toUpperCase()+"|"+//15
					window.document.frmCardRequst.txtMobphon.value.toUpperCase()+"|"+//16
					window.document.frmCardRequst.txtCardmailid.value.toUpperCase()+"|"+//17
					window.document.frmCardRequst.txtAcNom.value.toUpperCase()+"|"+//18
					window.document.frmCardRequst.txtAcctyp.value.toUpperCase()+"|"+//19
					window.document.frmCardRequst.txtMailmobil.value.toUpperCase()+"|"+//20
					window.document.frmCardRequst.txtAdd1.value.toUpperCase()+"|"+//21
					window.document.frmCardRequst.txtAdd2.value.toUpperCase()+"|"+//22
					window.document.frmCardRequst.txtAdd3.value.toUpperCase()+"|"+//23
					window.document.frmCardRequst.txtAdd4.value.toUpperCase()+"|"+//24
					window.document.frmCardRequst.txtCitycode.value.toUpperCase()+"|"+//25
					window.document.frmCardRequst.txtZipcod.value.toUpperCase()+"|"+//26
					window.document.frmCardRequst.txtMailAd1.value.toUpperCase()+"|"+//27
					window.document.frmCardRequst.txtMailAd2.value.toUpperCase()+"|"+//28
					window.document.frmCardRequst.txtMailAd3.value.toUpperCase()+"|"+//29
					window.document.frmCardRequst.txtMailAd4.value.toUpperCase()+"|"+//30
					window.document.frmCardRequst.txtMailcitycod.value.toUpperCase()+"|"+//31
					window.document.frmCardRequst.txtMailcode.value.toUpperCase()+"|"+//32
					window.document.frmCardRequst.txtbranchcode.value.toUpperCase()+"|"+//33
					refnoQer+"|"+//window.document.frmCardRequst.hidRef.value.toUpperCase()+"|"+ //34
					window.document.frmCardRequst.txtModid.value.toUpperCase()+"|"+ //35
					window.document.frmCardRequst.txtGlcode.value.toUpperCase()+"|"+ //36
					window.document.frmCardRequst.txtAccNo.value.toUpperCase() +"|"+ //37
					window.document.frmCardRequst.txtdbtScopval.value.toUpperCase()  +"|"+ //38	
					window.document.frmCardRequst.txtMiddleName.value.toUpperCase()  +"|"+ //39	
					window.document.frmCardRequst.txtFatherName.value.toUpperCase()  +"|"+ //40	
					window.document.frmCardRequst.txtCity.value.toUpperCase()  +"|"+ //41
					selectedStateText.toUpperCase() +"|"+ //42		
					window.document.frmCardRequst.txtSurName.value.toUpperCase()  //43  surname or family name
								
							
		}
		
		if (window.document.frmCardRequst.opt1(1).checked==true)
		{
			if(window.document.frmCardRequst.txtCrdnumber.value == "")
			{
				alert("Please Enter The Card Number")
				window.document.frmCardRequst.txtCrdnumber.focus();
				return;
			}
			if(window.document.frmCardRequst.txtModFnam.value == "")
			{
				alert("Please Enter The Family Name")
				window.document.frmCardRequst.txtModFnam.focus();
				return;
			}
			if(window.document.frmCardRequst.txtModFrstnm.value == "")
			{
				alert("Please Enter The First Name")
				window.document.frmCardRequst.txtModFrstnm.focus();
				return;
			}
			
			if(window.document.frmCardRequst.txtAdd1.value == "")
			{
				alert("Please Enter The Address1 ")
				window.document.frmCardRequst.txtAdd1.focus();
				return;
			}
			
			if (window.document.frmCardRequst.txtAdd1.value != "")
			{
				if(window.document.frmCardRequst.txtCity.value=="")
				{
					alert("Please Enter City")
					return;
				}
				if(window.document.frmCardRequst.SelState.value =="")
				{
					alert("Please Enter State")
					return;
				}
			}

			if(window.document.frmCardRequst.txtMailAd1.value == "")
			{
				alert("Please Enter The Mailing Address1")
				window.document.frmCardRequst.txtMailAd1.focus();
				return;
			}
			
			var kst
		var el = document.getElementById('SelState')
		var selectedStateText = el.options[el.selectedIndex].text
		
			kst = "U"+"|"+window.document.frmCardRequst.txtCrdnumber.value.toUpperCase() +"|"+//1
					window.document.frmCardRequst.txtModFnam.value.toUpperCase()+"|"+//2  surname or family name
					window.document.frmCardRequst.txtModFrstnm.value.toUpperCase()+"|"+//3
					window.document.frmCardRequst.txtModmail.value.toUpperCase()+"|"+//4
					window.document.frmCardRequst.txtAdd1.value.toUpperCase()+"|"+//5
					window.document.frmCardRequst.txtAdd2.value.toUpperCase()+"|"+//6
					window.document.frmCardRequst.txtAdd3.value.toUpperCase()+"|"+//7
					window.document.frmCardRequst.txtAdd4.value.toUpperCase()+"|"+//8
					window.document.frmCardRequst.txtCitycode.value.toUpperCase()+"|"+//9
					window.document.frmCardRequst.txtZipcod.value.toUpperCase()+"|"+//10
					window.document.frmCardRequst.txtMailAd1.value.toUpperCase()+"|"+//11
					window.document.frmCardRequst.txtMailAd2.value.toUpperCase()+"|"+//12
					window.document.frmCardRequst.txtMailAd3.value.toUpperCase()+"|"+//13
					window.document.frmCardRequst.txtMailAd4.value.toUpperCase()+"|"+//14
					window.document.frmCardRequst.txtMailcitycod.value.toUpperCase()+"|"+//15
					window.document.frmCardRequst.txtMailcode.value.toUpperCase()+"|"+//16
					window.document.frmCardRequst.txtMailmobil.value.toUpperCase()+"|"+//17
					window.document.frmCardRequst.txtModMidleName.value.toUpperCase()  +"|"+ //18
					window.document.frmCardRequst.txtModFatherName.value.toUpperCase()  +"|"+ //19				
					window.document.frmCardRequst.txtCity.value.toUpperCase()  +"|"+ //20
					selectedStateText.toUpperCase() //21		
			
		}
		
		///alert(" kst = "+kst)
		window.document.frmCardRequst.mercust.value=kst
		window.document.frmCardRequst.action="customercardinsert.aspx"
		window.document.frmCardRequst.method="post"   
		window.document.frmCardRequst.submit()
		
	}
	
	function clear()
	{
		window.document.frmCardRequst.txtCardTitle.value=""
		window.document.frmCardRequst.txtFamilynam.value=""
		window.document.frmCardRequst.txtFirstnam.value=""
		window.document.frmCardRequst.txtMiddleName.value=""
		window.document.frmCardRequst.txtFatherName.value=""
		window.document.frmCardRequst.txtBirthdat.value=""
		window.document.frmCardRequst.txtBirthcity.value=""
		window.document.frmCardRequst.txtMobphon.value=""
		window.document.frmCardRequst.txtCardmailid.value=""
		window.document.frmCardRequst.txtMailmobil.value=""
		window.document.frmCardRequst.txtAdd1.value=""
		window.document.frmCardRequst.txtAdd2.value=""
		window.document.frmCardRequst.txtAdd3.value=""
		window.document.frmCardRequst.txtAdd4.value=""
		window.document.frmCardRequst.txtCitycode.value=""
		window.document.frmCardRequst.txtZipcod.value=""
		window.document.frmCardRequst.txtCity.value=""
		window.document.frmCardRequst.txtMailAd1.value=""
		window.document.frmCardRequst.txtMailAd2.value=""
		window.document.frmCardRequst.txtMailAd3.value=""
		window.document.frmCardRequst.txtMailAd4.value=""
		window.document.frmCardRequst.txtMailcitycod.value=""
		window.document.frmCardRequst.txtMailcode.value=""
	}
	
	function New()
	{
		clear()
		window.document.frmCardRequst.txtModid.value=""
		window.document.frmCardRequst.txtModiddesc.value=""
		window.document.frmCardRequst.txtGlcode.value=""
		window.document.frmCardRequst.txtGlcodedesc.value=""
		window.document.frmCardRequst.txtAccNo.value=""
		window.document.frmCardRequst.txtAccNm.value=""
		window.document.frmCardRequst.txtCrdnumber.value=""
		window.document.frmCardRequst.txtCrdname.value=""
		window.document.frmCardRequst.txtClntcode.value=""
		window.document.frmCardRequst.txtModFnam.value=""
		window.document.frmCardRequst.txtModFrstnm.value=""
		window.document.frmCardRequst.txtModmail.value=""
		
		if (window.document.frmCardRequst.opt1(0).checked==true)
		{	
			window.document.all.divMain.style.display = "block"
			window.document.all.divAplc.style.display = "block"
			window.document.all.divPadd.style.display = "block"
			window.document.all.divMadd.style.display = "block"
			window.document.all.divMod.style.display = "block"
			window.document.all.divCrdMod.style.display = "none"
		}
		if (window.document.frmCardRequst.opt1(1).checked==true)
		{
			window.document.all.divMain.style.display = "none"
			window.document.all.divAplc.style.display = "none"
			window.document.all.divPadd.style.display = "block"
			window.document.all.divMadd.style.display = "block"
			window.document.all.divMod.style.display = "none"
			window.document.all.divCrdMod.style.display = "block"
		}
	}
	
	function crdNumber()
	{
		st="CRDNUM"+"|"+"<%=session("branchcode")%>"
		
			window.showModalDialog('<%="http://" & session("moduledir")& "/CUSTOMER/"%>'+ "silist.aspx" + "?"+"st="+st,window,
  "status:no;dialogWidth:440px;dialogHeight:170px");
	}
	
	function crdCode(strCrd)
	{
		var crid
		crid = (strCrd).split("-----")
		
		window.document.frmCardRequst.txtCrdnumber.value = crid[1]
		window.document.frmCardRequst.txtCrdname.value = crid[0]
		getcrdtls()
		
	}
	function getcrdtls()
	{
		var st
		clMod()
		
		if (window.document.frmCardRequst.txtCrdnumber.value == "")
		{
			alert(" Please Enter the Card Number")
			//window.document.frmCardRequst.txtCrdnumber.focus();
			return;
		}
		
		st = "DTLSCRD"+"|"+window.document.frmCardRequst.txtCrdnumber.value
		
		window.document.all['iGetDtls'].src="../GEN/getDtls.aspx?st="+st
	}
	
	function clMod()
	{
		//window.document.frmCardRequst.txtCrdname.value = ""
		window.document.frmCardRequst.txtClntcode.value = ""
		window.document.frmCardRequst.txtModFnam.value = ""
		window.document.frmCardRequst.txtModFrstnm.value = ""
		window.document.frmCardRequst.txtModmail.value = ""
		window.document.frmCardRequst.txtModMidleName.value = ""
		window.document.frmCardRequst.txtModFatherName.value = ""
		window.document.frmCardRequst.txtAdd1.value = ""
		window.document.frmCardRequst.txtAdd2.value = ""
		window.document.frmCardRequst.txtAdd3.value = ""
		window.document.frmCardRequst.txtAdd4.value = ""
		window.document.frmCardRequst.txtCitycode.value = ""
		window.document.frmCardRequst.txtZipcod.value = ""
		window.document.frmCardRequst.txtCity.value = ""
		window.document.frmCardRequst.txtMailAd1.value = ""
		window.document.frmCardRequst.txtMailAd2.value = ""
		window.document.frmCardRequst.txtMailAd3.value = ""
		window.document.frmCardRequst.txtMailAd4.value = ""
		window.document.frmCardRequst.txtMailcitycod.value = ""
		window.document.frmCardRequst.txtMailcode.value = ""
		window.document.frmCardRequst.txtMailmobil.value = ""
	}
	
	function popDtlscrd(str)
	{
		if(str=="No Records")
		{
			alert("No Records Found")
			return;
		}
		
		var kDtr=str.split("~")
		
		window.document.frmCardRequst.txtClntcode.value = kDtr[0]
		//window.document.frmCardRequst.txtCrdname.value = kDtr[1]
		window.document.frmCardRequst.txtModFnam.value = kDtr[1]
		window.document.frmCardRequst.txtModFrstnm.value = kDtr[2]
		window.document.frmCardRequst.txtModmail.value = kDtr[3]
		window.document.frmCardRequst.txtAdd1.value = kDtr[4]
		window.document.frmCardRequst.txtAdd2.value = kDtr[5]
		window.document.frmCardRequst.txtAdd3.value = kDtr[6]
		window.document.frmCardRequst.txtAdd4.value = kDtr[7]
		window.document.frmCardRequst.txtCitycode.value = kDtr[8]
		window.document.frmCardRequst.txtZipcod.value = kDtr[9]
		window.document.frmCardRequst.txtMailAd1.value = kDtr[10]
		window.document.frmCardRequst.txtMailAd2.value = kDtr[11]
		window.document.frmCardRequst.txtMailAd3.value = kDtr[12]
		window.document.frmCardRequst.txtMailAd4.value = kDtr[13]
		window.document.frmCardRequst.txtMailcitycod.value = kDtr[14] // mail city code
		window.document.frmCardRequst.txtMailcode.value = kDtr[15]  // zip code
		window.document.frmCardRequst.txtMailmobil.value = kDtr[16]
		
		window.document.frmCardRequst.txtModMidleName.value = kDtr[17]
		window.document.frmCardRequst.txtModFatherName.value = kDtr[18]
		window.document.frmCardRequst.txtCity.value = kDtr[19]
		if (kDtr[20] == "")
		{
		window.document.frmCardRequst.SelState.value = kDtr[20]
		}
		else
		{
		//var el = document.getElementById('SelState')
		//el.options[el.selectedIndex].text = kDtr[20]
}
		
		
	}
	</script>
	
	<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
	function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					/*else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}*/
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	</script>
	
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display();DispTranMsg();">

    <form name="frmCardRequst">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="10%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>Customer Card Request</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
	<%appdate=formatdatetime(session("applicationdate"),1)%>
	
	<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%">
			<div align="center">
				<table width="100%" cellspacing="0" border="0" cellpadding="0" class="tablebordermain">
					<tr>
						<td width="100%">
							<div align="center">
							<center>
							<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor1">
												<td width="10%">
												<p align="center"><font class="textblack"><input type="radio" value="INSERT" name="opt1" onclick="New()" checked>New&nbsp;</font></p></td>
												<td width="12%">
												<p align="center"><font class="textblack"><input type="radio" value="MODIFY" name="opt1" onclick="New()">Modify&nbsp;</font></p></td>
												<!---<td width="12%">
												<p align="center"><font class="textblack"><input name="opt1" onclick="New()" type="radio" value="VIEW">View</font></td>--->
											</tr>
										</table>
									</td>
								</tr>
							</table>
							</center>
							</div>
							<div align="center" id="divMod">
							<center>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=txtautofill onkeypress=addresschar() id=txtbranchcode onblur='Dataarrange(txtbranchcode);DescrptionDisp("txtbranchcode")' onkeyup='window.document.frmCardRequst.txtBrdesc.value=""' style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: right" tabIndex=1 maxLength=6 size=16 value="<%=session("branchcode")%>" name=txtbranchcode ><INPUT class=button id=btnBr onclick=Branch() type=button value=" L " name=butBranch><INPUT class=bgcolor1 onkeypress=addresschar() readOnly size=20 value="<%=session("branchnarration")%>" name=txtBrdesc></FONT></td>
										<td align=left width="15%"><P align=left>Currency Code&nbsp;&nbsp;</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=addresschar() id=txtcurrencycode onblur='Dataarrange(txtcurrencycode);DescCheck("txtcurrencycode")' onkeyup='window.document.frmCardRequst.txtCrdesc.value=""' style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" tabIndex=2 type=text size=10 value="<%=session("currencycode")%>" name=txtcurrencycode ><INPUT class=button disabled onclick=Currency() type=button value=" L " name=butCur><INPUT class=bgcolor1 onkeypress=addresschar() readOnly size=23 value="<%=session("currencynarration")%>" name=txtCrdesc></FONT></td>
									</tr>
									<tr>
										<td align=left width="15%"><P align=left >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module Id</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtModid')" style="TEXT-TRANSFORM: uppercase" maxLength=16 onchange="return txtModid_onchange()" size=16 name=txtModid ><INPUT class=button onclick=Tellmodule() type=button value=" L " name=butdbtmodid><INPUT class=bgcolor1 readOnly type=text size=20 name=txtModiddesc ></FONT></td>
										<td align=left width="15%"><P align=left>GL Code&nbsp;&nbsp;</P></td>
										<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtGlcode')" style="TEXT-TRANSFORM: uppercase" type=text maxLength=6 onchange="return txtGlcode_onchange()" size=10 name=txtGlcode ><INPUT class=button onclick=TellerGl() type=button value=" L " name=butdbtglcode><INPUT class=bgcolor1 readOnly type=text size=23 name=txtGlcodedesc ></FONT></td>
									</tr>
									<tr>
										<td width="13%" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Acc.No</td>
										<td width="35%"><INPUT class=txtautofill onkeypress=Alphanum() onblur="DescrptionDisp('txtAccNo')" type=text maxLength=16 size=16 name=txtAccNo><INPUT class=button onclick=Acccode() type=button value=" L " name=butdbtaccno><INPUT class=bgcolor1 readOnly type=text size=20 name=txtAccNm ></td>
										
										<td width="15%">Card Type</td>
										<td width="35%"><input type="text" name="txtdbtScopval" class="txtautofill" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtScopval&quot;)" size="10" onchange="return txtdbtglcode_onchange()" maxlength=6><input type="button" class="button" value=" L " name="butdbtglcode" onclick="Scop()"><input type="text" name="txtdbtScopdesc" class="bgcolor1" readonly size="23"></td>
										<!--<td align=left width="15%"><P align=left>Cur Balance&nbsp;&nbsp;</P> ---></td>
									<!--	<td width="35%"><FONT color=#000000 size=2 ><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: right" readOnly type=text maxLength=6 size=19 name=txtCurBal ></FONT> </td>--->
									</tr>
								</table>
							</center>
							</div>
							<div align="center" id="divCrdMod" style="display:none" >
								<center>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Card Number</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=txtautofill onblur='getcrdtls()'  style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: right" tabIndex=1 maxLength=22 size=16 name=txtCrdnumber ><INPUT class=button id=btncrd onclick=crdNumber() type=button value=" L " name=butcrdnum></FONT></td>
										<td align=left width="15%"><P align=left>&nbsp;Card Name </P></td>
										<td width="35%"><FONT color=#000000 size=2 >&nbsp;<INPUT class=bgcolor1 id=txtCrdname style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 name=txtCrdname readonly ></FONT></td>
									</tr>
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Client Code</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=bgcolor1 style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 name=txtClntcode readonly ></FONT></td>
										<td align=left width="15%"><P align=left>&nbsp;Sur Name </P></td>
										<td width="35%"><FONT color=#000000 size=2 >&nbsp;<INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 maxlength=20 name=txtModFnam ></FONT></td>
									</tr>
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;First Name</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 name=txtModFrstnm ></FONT></td>
										<td align=left width="15%"><P align=left>&nbsp;Middle Name</P></td>
										<td width="35%"><FONT color=#000000 size=2 >&nbsp;<INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 maxlength=25 name=txtModMidleName ></FONT></td>
									</tr>
									
									<tr class="bgcolor">
										<td align=left width="15%"><P align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Father Name</P></td>
										<td width="35%"><FONT color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 name=txtModFatherName ></FONT></td>
										<td align=left width="15%"><P align=left>&nbsp;Email Id </P></td>
										<td width="35%"><FONT color=#000000 size=2 >&nbsp;<INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase; TEXT-ALIGN: left" size=25 maxlength=20 name=txtModmail ></FONT></td>
									</tr>
								</table>
							</center>
							</div>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<div align="center" id="divMain">
							<center>
								<fieldset style="width:950px;">
								<legend><font color="blue">Card Details</font></legend>
								<table width="100%" border='0'>
									<tr>
										<td width="34%"><font color=#000000 size=2>&nbsp;&nbsp;OWNER CODE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<select name="SelOwner">
												<option value="1">Individual</option>
												<option value="2">Spouse</option>
												<option value="3">Child</option>
												<option value="4">Business</option>
												<option value="5">Card Issuer's employee</option>
											</select></font>
										</td>
										<td width="33%"><font color=#000000 size=2>&nbsp;&nbsp;BASIC CARD FLAG &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<select name="SelBasicard">
												<option value="0">Basic card</option>
												<option value="1">Supplementary card</option>
												<option value="2">Both</option>
											</select></font>
										</td>
										<td width="34%"><font color=#000000 size=2>&nbsp;&nbsp;PHOTO INDICATOR &nbsp;&nbsp;
											<select name="SelPhtoindicate">
												<option value="0">No Photo</option>
												<option value="1">PhotoCard</option>
											</select></font>
										</td>
										
									</tr>
									<tr>
										<td width="34%"><font color=#000000 size=2>&nbsp;&nbsp;RESIDENCE STATUS&nbsp;&nbsp;
											<select name="SelResidence">
												<option value="" selected >Select</option>
												<option value="0">Not Reported</option>
												<option value="1">Rented</option>
												<option value="2">Owned</option>
												<option value="3">Dependent</option>
											</select></font>
										</td>
										<td width="33%"><font color=#000000 size=2>&nbsp;&nbsp;EMPLOYMENT STATUS &nbsp;&nbsp;
											<select name="SelEmpstat">
												<option value="" selected >Select</option>
												<option value="0">Employee</option>
												<option value="1">Liberal Job</option>
												<option value="2">Retired</option>
												<option value="3">Student</option>
												<option value="4">Unemployed</option>
												<option value="5">Self Employed</option>
											</select></font>
										</td>
										<td width="33%"><font color=#000000 size=2>&nbsp;&nbsp;MARITAL STATUS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<select name="SelMarstat">
												<option value="" selected >Select</option>
												<option value="1">Single</option>
												<option value="2">Married</option>
												<option value="3">Divorced</option>
												<option value="4">Widower</option>
											</select></font>
										</td>
									</tr>
									<tr>
										<td width="34%"><font color=#000000 size=2>&nbsp;&nbsp;DELIVERY MODE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<select name="SelDeliver">
												<option value="" selected >Select</option>
												<option value="0">Branch</option>
												<option value="1">Payment System Dept</option>
												<option value="2">Mail</option>
											</select></font>
										</td>
										<td width="33%"><font color=#000000 size=2>&nbsp;&nbsp;Gender &nbsp;&nbsp;
											<select name="SelGender">
												<option value="M">Male</option>
												<option value="F">Female</option>
											</select></font>
											<font color=#000000 size=2>&nbsp;&nbsp;VIP FLAG &nbsp;&nbsp;
											<select name="SelVipFlag">
												<option value="0">Normal</option>
												<option value="1">Important</option>
											</select></font>
										</td>
										<td width="33%"><font color=#000000 size=2>&nbsp;&nbsp;ISSUER'S CLIENT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<select name="SelIssueclient">
												<option value="0">Yes</option>
												<option value="1">No</option>
											</select></font>
										</td>
									</tr>
									<tr>
										
									</tr>
								</table>
								</fieldset>
								</center>
								</div>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<div align="center" id="divAplc">
							<center>
								<fieldset style="width:950px;">
								<legend><font color="blue">Applicant Details</font></legend>
									<table width="100%" border='0'>
										<tr>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;TITLE &nbsp;&nbsp;</font></td>
											<td width="25%" colspan=2><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=4 size=5 name="txtCardTitle" ></font> <font color=#000000 size=2>Surname </font> <INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=20 size=10 name="txtSurName" >
											<font color=#000000 size=2>&nbsp;FNAME &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=20 size=20 name="txtFamilynam" ></font></td>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;MIDDLE NAME&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=25 name="txtMiddleName" ></font></td>
										</tr>
										
										<tr>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;FATHERNAME</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtFatherName" ></font></td>
										  <td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;NAMEONCARD</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=26 size=20 name="txtFirstnam" ></font></td>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;BIRTH DATE&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2></font><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxlength='12' onblur="datecheck(this)"  size=10 name="txtBirthdat" >&nbsp;(DDMMYYYY)</td>
										</tr>
										
										<tr>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;BIRTH CITY&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=5 size=10 name="txtBirthcity" ></font></td>
											<!---<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;BIRTH COUNTRY&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=3 size=10 name="txtBirthcuntry" ></font></td> --->
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;MOBILEPHONE</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=15 size=20 name="txtMobphon" ></font></td>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;EMAIL ID&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=50 size=20 name="txtCardmailid" ></font></td>
										</tr>
										<tr>
											<!---<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;COUNTRY CODE &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=3 size=20 name="txtCuntrycod" ></font></td>--->
											
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ACCOUNT &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=24 size=20 name="txtAcNom" readonly></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ACCOUNTTYPE</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=2 size=10 name="txtAcctyp" readonly></font></td>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp; &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2></font></td>
										</tr>
										<!--<tr>
											
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ACCOUNT1 CURRENCY &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=3 size=10 name="txtAccurncy" ></font></td>
											
										</tr>  --->
										
										
									</table>
								</fieldset>
							</center>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%">
							<div align="center" id="divPadd">
							<center>
								<fieldset style="width:950;">
								<legend><font color="blue">Permanent Address</font></legend>
									<table width="100%" border='0'>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS1 &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=30 size=20 name="txtAdd1" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS2&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=30 size=20 name="txtAdd2" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS3&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=30 size=20 name="txtAdd3" ></font></td>
										</tr>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;ADDRESS4 &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=30 size=20 name="txtAdd4" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;CITY&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=25 size=20 name="txtCity" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;STATE&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2>
											<%
										dim objCnt,rsCt
										objCnt = server.CreateObject("ReportPurposeOnly.Reportonly")
										rsCt = Server.CreateObject("adodb.recordset")
										sqlCnt=" SELECT substr(STATENAME,1,25) STATENAME FROM GENSTATEMST ORDER BY DECODE(STATENAME, 'Andhra Pradesh','0',STATENAME)"
		 
									rsCt=objCnt.SingleSelectStat(sqlCnt)
		
									if objCnt.ConnError="Connected" then
									if not rsCt.BOF and not rsCt.EOF then
									%>
											<select name="SelState">
												<%
												while not rsCt.EOF %>
																				
												<option value=<%= rsCt(0).value%>><%= rsCt(0).value %></option>
												
												<%
			rsCt.movenext
			end while
			end if
			end if
			%>
											</select></font>
											</font></td>
										</tr>
										<tr>
											<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;CITY CODE&nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=5 size=20 name="txtCitycode" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;ZIP CODE&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=10 size=20 name="txtZipcod" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2></font></td>
										</tr>
										
									</table>
								</fieldset>
							</center>
							</div>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<div align="center" id="divMadd">
							<center>
								<fieldset style="width:950px;">
								<legend><font color="blue">Mailing Address <input type="checkbox" onclick="Addresschange()" name="chkMail">Same as Permanent Address</font></legend>
									<table width="100%" border='0'>
										<tr>
											<td width="15%"><font color=#000000 size=2>MAILING_ADDRESS1 </font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=45 size=20 name="txtMailAd1" ></font></td>
											<td width="10%"><font color=#000000 size=2>MAILING_ADDRESS2 </font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=45 size=20 name="txtMailAd2" ></font></td>
											<td width="10%"><font color=#000000 size=2>MAILING_ADDRESS3 </font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=45 size=20 name="txtMailAd3" ></font></td>
										</tr>
										<tr>
											<td width="15%"><font color=#000000 size=2>MAILING_ADDRESS4 </font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=45 size=20 name="txtMailAd4" ></font></td>
											<td width="10%"><font color=#000000 size=2>MAILING_CITY_CODE </font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=5 size=20 name="txtMailcitycod" ></font></td>
											<td width="10%"><font color=#000000 size=2>MAILING_ZIP_CODE </font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=10 size=20 name="txtMailcode" ></font></td>
										</tr>
										<tr>
											<!---<td width="15%"><font color=#000000 size=2>&nbsp;&nbsp;MAILING_COUNTRY_CODE &nbsp;&nbsp;</font></td>
											<td width="15%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=3 size=20 name="txtMailcntrycod" ></font></td> --->
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp;PHONE_MOBILE &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2><INPUT class=txtautofill style="TEXT-TRANSFORM: uppercase" maxLength=15 size=20 name="txtMailmobil" ></font></td>
											<td width="10%"><font color=#000000 size=2>&nbsp;&nbsp; &nbsp;&nbsp;</font></td>
											<td width="25%"><font color=#000000 size=2></font></td>
										</tr>
									</table>
							</center>
							</div>
						</td>
					</tr>	
					
					<tr>
						<td width="100%">
							<div>
							<center>
							<table width="100%" border='01'>
								
							</table>
							</center>
							</div>
						</td>
					</tr>
					
					<tr>
						<td width="100%" valign="top" align="center"><input name="cmdOk" onclick="Ok()" type="button" value="   Ok   " class="button"><input name="cmdCancel" type="button" value="Cancel" class="button" onclick="location.href=&quot;frmcardcustomer.aspx&quot;"><input type="button" value="  Exit  " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"></td>
					</tr>
				</table>
			</div>
			</td>
		</tr>
	</table>
					
	<input type="hidden" name="mercust">
	<input type="hidden" name="hidBrcd">
	<input type="hidden" name="hidChbr">
	<input type="hidden" name="hidAdd">
	<input type="hidden" name="hidcit">
	<input type="hidden" name="hidZip">
	<input type="hidden" name="hidRef">
	<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
	<IFRAME id=iGetDtls style="DISPLAY: block" align=center frameSpacing=0 src="../gen/getDtls.aspx" frameBorder=0 width=0 height=0></IFRAME>
	<iframe id="iBatch" frameBorder=0 frameSpacing=0  height=0 width=0 src="../GENSBCA/querydisplay.aspx"></iframe>
	<div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>
    </form>

  </body>
</html>