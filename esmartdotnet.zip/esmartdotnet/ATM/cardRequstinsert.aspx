<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="cardRequstinsert.aspx.vb" Inherits="eSmartDotNet.cardRequstinsert"%>
<%

dim obj,obj1,obj2,obj3,obj4,obj5,obj6,obj7,rs,rs1,rs2,rs3,rs4,rs5,rs6,rs7, Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno

obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
obj2=server.CreateObject("queryrecordsets.fetchrecordsets")
obj3=server.CreateObject("queryrecordsets.fetchrecordsets")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
obj6=server.CreateObject("queryrecordsets.fetchrecordsets")
obj7=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")
rs5=server.CreateObject("adodb.recordset")
rs6=server.CreateObject("adodb.recordset")
rs7=server.CreateObject("adodb.recordset")

dim Arrtrans(50,4)
dim cntCode
dim msg
		
cntCode="356"

appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("mercust")
strval=split(strmode,"~")


if strval(0) = "I"

	strcolnames = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, NAME, PREFERENCE, CARDNAME, MOTHERNAME, CARDLIMIT, ADDRESS1, ADDRESS2, ADDRESS3, CITYCODE, ZIPCODE, MOBILE, STATE, REFNUM, TRANSTATUS, APPLICATIONDATE, USERID, MACHINEID"
	
	strdelvar=" '" & strval(2) & "','" & strval(3) & "','" & strval(4) & "','" & strval(5) & "','" & strval(6) & "','" & strval(7) & "','PIN','" & strval(8) & "','" & strval(9) & "','" & strval(10) & "','" & strval(12) & "','" & strval(13) & "','" & strval(14) & "','" & strval(15) & "','" & strval(16) & "','" & strval(11) & "','" & strval(17) & "','" & strval(1) & "','A','" & appdate & "','" & userid & "','" & machineid & "'"
	
	
		Arrtrans(i,0)="I"			
		Arrtrans(i,1)="ATMCRDREQUESTDTLS"
		Arrtrans(i,2)=strcolnames
		Arrtrans(i,3)=strdelvar
		Arrtrans(i,4)=""
		
		msg = "CRD" & strval(1)

end if



		
		Response.Write (Arrtrans(acnt,0) & "<br>")
		Response.Write (Arrtrans(acnt,1) & "<br>")
		Response.Write (Arrtrans(acnt,2) & "<br>")
		Response.Write (Arrtrans(acnt,3) & "<br>")
		Response.Write (Arrtrans(acnt,4) & "<br>")

		Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		obj=nothing
		
		
		
		Response.Redirect ("frmcardrequest.aspx?record=" & Strmsg & " " & msg  )

%>
