<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmATMCardlnk.aspx.vb" Inherits="eSmartDotNet.frmATMCardlnk"%>
<%
	dim rsBnk,objBnk,frmname,staccond
	rsBnk=server.CreateObject("adodb.recordset")
	objBnk=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsBnk=objBnk.singlerecordset("genbankparm","depcertificate","")
	
	if objBnk.ConnError="Connected" then	
		if not rsBnk.EOF and not rsBnk.BOF then
			frmname=rsBnk(0).value
		end if
	end if
	
	
%><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>frmATMCardlnk</title>

	<LINK href="../styletag.css" type=text/css rel=stylesheet >
	<meta content=False name=vs_showGrid>
	<meta content="Microsoft Visual Studio .NET 7.1" name=GENERATOR>
	<meta content="Visual Basic .NET 7.1" name=CODE_LANGUAGE>
	<meta content=JavaScript name=vs_defaultClientScript>
	<meta content=http://schemas.microsoft.com/intellisense/ie5 name=vs_targetSchema>
	<SCRIPT language=javascript src="../proc.js" ?> </SCRIPT>
	<SCRIPT language=javascript src="../val.js"> </SCRIPT>
	<SCRIPT language=JavaScript src="../dhtmllib.js"></SCRIPT>
	<SCRIPT language=JavaScript src="../MenuLib.js"></SCRIPT>
	<SCRIPT language=JavaScript src="../navbar.js"></SCRIPT>
	<SCRIPT language=javascript>
	
	var stBnk
	stBnk = "<%=frmname%>"
	
		function Branch()
		{  	
        telbr="Tellerbranch";
	   window.showModalDialog("../GEN/Listquery.aspx"+"?"+"st="+telbr,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:190px;DialogTop:200px");
		}
 //Assign Selected Branch code and Branch desc to the Textboxes.
	 
function Branchcode(kstr)
 { 
	  assign(kstr,window.document.frmAtmlnk.txtbranchdesc, window.document.frmAtmlnk.txtbranchcode)
	
 }
 
	function Tellermodule()
	{
		stmod="ATMTELLERMOD"; 
		stbr=window.document.frmAtmlnk.txtbranchcode.value
		kstr=stmod+"|"+stbr
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}

	function Modulecode(kstr)
	{
		assign(kstr,window.document.frmAtmlnk.txtdbtmodiddesc,window.document.frmAtmlnk.txtdbtmodid)
		clear("ALL")
	}
	
	function DescrptionDisp(strTxt)
	{
		sBr = window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()
		sMod = window.document.frmAtmlnk.txtdbtmodid.value.toUpperCase()
		sGL = window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()
		sAccno = window.document.frmAtmlnk.txtdbtaccno.value.toUpperCase()
		sCur = window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()
		
		if(strTxt=="txtdbtmodid")
		{ 
			if(window.document.frmAtmlnk.txtdbtmodid.value=="")
			{
				return;
			}
				st="DescDisplay~GENMODULETYPESMST M~"+
				"M.NARRATION~m.IMPLEMENTEDYN='Y' and " +
				"m.moduleid='"+sMod+"'~~"+strTxt
				
		}
		
		if(strTxt=="txtdbtglcode")
		{ 
			if(window.document.frmAtmlnk.txtdbtglcode.value=="")
			{
				return;
			}
				st="DescDisplay~GENGLSHEETMST~"+
				"NARRATION~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND MODULEID='"+sMod+"'~~"+strTxt
		}
		
		if(strTxt=="txtdbtaccno")
		{ 
			if(window.document.frmAtmlnk.txtdbtaccno.value=="")
			{
				return;
			}
				st="DescDisplay~"+sMod+"MST~"+
				"NAME,status~branchcode='" +sBr+ "' AND " +
				"GLCODE='"+sGL+"' AND currencycode='"+sCur+"' and "+
				"accno='"+sAccno+"' and status='R' ~~"+strTxt
		}
		
		if(strTxt=="txtdbtcrdval")
		{ 
			if(window.document.frmAtmlnk.txtdbtcrdval.value=="")
			{
				return;
			}
			
			st="DescDisplay~GENCARDTYPEMST~DESCRIPTION~CARDTYPE='"+window.document.frmAtmlnk.txtdbtcrdval.value+"' AND status='R' ~~"+strTxt
		}
		
		if(strTxt=="txtdbtCatval")
		{ 
			if(window.document.frmAtmlnk.txtdbtCatval.value=="")
			{
				return;
			}
			
			st="DescDisplay~GENCARDCATEGORYSMST~DESCRIPTION~CARDCATEGORYTYPE='"+window.document.frmAtmlnk.txtdbtCatval.value+"' AND status='R' ~~"+strTxt
		}
		
		if(strTxt=="txtdbtScopval")
		{ 
			if(window.document.frmAtmlnk.txtdbtScopval.value=="")
			{
				return;
			}
			
			st="DescDisplay~GENCARDSCOPEMST~DESCRIPTION~CARDSCOPETYPE='"+window.document.frmAtmlnk.txtdbtScopval.value+"' AND status='R' ~~"+strTxt
		}
		
		if(strTxt=="txtdbtRelid")
		{ 
			if(window.document.frmAtmlnk.txtdbtRelid.value=="")
			{
				return;
			}
			
			st="DescDisplay~GENRELATIONSMST~NARRATION~CODE='"+window.document.frmAtmlnk.txtdbtRelid.value+"' AND status='R' ~~"+strTxt
		}
		
		//alert("st2 = "+st)
		window.document.all["iBatch"].src="../GENSBCA/querydisplay.aspx?st="+st
		
	}
	
	function DescDisplay(stri)
	{
		//alert("stri = "+stri)
		var strtype=new String()
		strtype=stri.split("~")
		
		var StrArrFld=new String()
		StrArrFld=strtype[0].split("|")
			
		if(strtype[1]=="txtdbtmodid")
		{
			clear("ALL")
		
				if(StrArrFld[0]=="No")
				{
					alert("Invalid ModuleId")
					window.document.frmAtmlnk.txtdbtmodid.value=""
					window.document.frmAtmlnk.txtdbtmodiddesc.value=""
					window.document.frmAtmlnk.txtdbtmodid.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtmodiddesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtdbtglcode")
		{
			clear("1")
		
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Glcode")
					window.document.frmAtmlnk.txtdbtglcode.value=""
					window.document.frmAtmlnk.txtdbtglcodedesc.value=""
					window.document.frmAtmlnk.txtdbtglcode.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtglcodedesc.value=StrArrFld[0]
		}
		
		if(strtype[1]=="txtdbtaccno")
		{
			clear("2")
				window.document.frmAtmlnk.txtdbtcustid.value=""
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Account No.")
					window.document.frmAtmlnk.txtdbtaccno.value=""
					window.document.frmAtmlnk.txtdbtaccnodesc.value=""
					window.document.frmAtmlnk.txtdbtaccno.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtaccnodesc.value=StrArrFld[0]
				getCust()
		}
		
		if(strtype[1]=="txtdbtcrdval")
		{
			clear("3")
				
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Card Type")
					window.document.frmAtmlnk.txtdbtcrdval.value=""
					window.document.frmAtmlnk.txtdbtcrdtyp.value=""
					window.document.frmAtmlnk.txtdbtcrdval.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtcrdtyp.value=StrArrFld[0]
				
				if(window.document.frmAtmlnk.txtdbtcrdval.value=="2")
				{
					window.document.all.divAdon.style.display="block" 
				}
				else
				{
					window.document.all.divAdon.style.display="none" 
				}
				
				CrdValid()
		}
		
		if(strtype[1]=="txtdbtCatval")
		{
			clear("4")
				
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Category")
					window.document.frmAtmlnk.txtdbtCatval.value=""
					window.document.frmAtmlnk.txtdbtCatdes.value=""
					window.document.frmAtmlnk.txtdbtCatval.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtCatdes.value=StrArrFld[0]
				
		}
		
		if(strtype[1]=="txtdbtScopval")
		{
			clear("5")
				
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Scope Type")
					window.document.frmAtmlnk.txtdbtScopval.value=""
					window.document.frmAtmlnk.txtdbtScopdesc.value=""
					window.document.frmAtmlnk.txtdbtScopval.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtScopdesc.value=StrArrFld[0]
				window.document.frmAtmlnk.txtdbtIsdat.value = "<%=session("applicationdate")%>"
				window.document.frmAtmlnk.txtdbtCrdlmt.value = "0.00"
				window.document.frmAtmlnk.txtdbtCshlmt.value = "0.00"
				if ((window.document.frmAtmlnk.txtdbtcrdval.value == "1") && (window.document.frmAtmlnk.txtdbtScopval.value == "2"))
				{
				//CheckForScope()
				}
		}
		if(strtype[1]=="txtdbtRelid")
		{
				if(StrArrFld[0]=="No")
				{
					alert("Invalid Relation")
					window.document.frmAtmlnk.txtdbtRelid.value=""
					window.document.frmAtmlnk.txtdbtReltiondesc.value=""
					window.document.frmAtmlnk.txtdbtRelid.focus()
					return;
				}
				window.document.frmAtmlnk.txtdbtReltiondesc.value=StrArrFld[0]
				
		}
		
	}
	
	
	function clear(st)
	{
		if(st=="ALL")
		{
			window.document.frmAtmlnk.txtdbtglcode.value=""
			window.document.frmAtmlnk.txtdbtglcodedesc.value=""
			window.document.frmAtmlnk.txtdbtaccno.value=""
			window.document.frmAtmlnk.txtdbtaccnodesc.value=""
			window.document.frmAtmlnk.txtdbtcustid.value=""
			window.document.frmAtmlnk.txtdbtcrdval.value=""
			window.document.frmAtmlnk.txtdbtcrdtyp.value=""
			window.document.frmAtmlnk.txtdbtcrdNo.value=""
			window.document.frmAtmlnk.txtdbtCatval.value="1"
			window.document.frmAtmlnk.txtdbtCatdes.value="RUPAY"
			window.document.frmAtmlnk.txtdbtScopval.value=""
			window.document.frmAtmlnk.txtdbtScopdesc.value=""
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtMincard.value=""
			window.document.frmAtmlnk.txtAcardnam.value=""
			window.document.frmAtmlnk.txtdbtRelid.value=""
			window.document.frmAtmlnk.txtdbtReltiondesc.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
		if(st=="1")
		{
			window.document.frmAtmlnk.txtdbtaccno.value=""
			window.document.frmAtmlnk.txtdbtaccnodesc.value=""
			window.document.frmAtmlnk.txtdbtcustid.value=""
			window.document.frmAtmlnk.txtdbtcrdval.value=""
			window.document.frmAtmlnk.txtdbtcrdtyp.value=""
			window.document.frmAtmlnk.txtdbtcrdNo.value=""
			window.document.frmAtmlnk.txtdbtCatval.value="1"
			window.document.frmAtmlnk.txtdbtCatdes.value="RUPAY"
			window.document.frmAtmlnk.txtdbtScopval.value=""
			window.document.frmAtmlnk.txtdbtScopdesc.value=""
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtMincard.value=""
			window.document.frmAtmlnk.txtAcardnam.value=""
			window.document.frmAtmlnk.txtdbtRelid.value=""
			window.document.frmAtmlnk.txtdbtReltiondesc.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
		if(st=="2")
		{
			window.document.frmAtmlnk.txtdbtcrdval.value=""
			window.document.frmAtmlnk.txtdbtcrdtyp.value=""
			window.document.frmAtmlnk.txtdbtcrdNo.value=""
			window.document.frmAtmlnk.txtdbtCatval.value="1"
			window.document.frmAtmlnk.txtdbtCatdes.value="RUPAY"
			window.document.frmAtmlnk.txtdbtScopval.value=""
			window.document.frmAtmlnk.txtdbtScopdesc.value=""
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtMincard.value=""
			window.document.frmAtmlnk.txtAcardnam.value=""
			window.document.frmAtmlnk.txtdbtRelid.value=""
			window.document.frmAtmlnk.txtdbtReltiondesc.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
		if(st=="3")
		{
			window.document.frmAtmlnk.txtMincard.value=""
			window.document.frmAtmlnk.txtAcardnam.value=""
			window.document.frmAtmlnk.txtdbtRelid.value=""
			window.document.frmAtmlnk.txtdbtReltiondesc.value=""
			window.document.frmAtmlnk.txtdbtcrdNo.value=""
			window.document.frmAtmlnk.txtdbtCatval.value="1"
			window.document.frmAtmlnk.txtdbtCatdes.value="RUPAY"
			window.document.frmAtmlnk.txtdbtScopval.value=""
			window.document.frmAtmlnk.txtdbtScopdesc.value=""
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
		if(st=="4")
		{
			//window.document.frmAtmlnk.txtdbtScopval.value=""
			//window.document.frmAtmlnk.txtdbtScopdesc.value=""
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
		if(st=="5")
		{
			window.document.frmAtmlnk.txtdbtCrdlmt.value=""
			window.document.frmAtmlnk.txtdbtCshlmt.value=""
			window.document.frmAtmlnk.txtdbtIsdat.value=""
			window.document.frmAtmlnk.txtdbtValfrmdat.value=""
			window.document.frmAtmlnk.txtdbtValtodat.value=""
			window.document.frmAtmlnk.txtCrdRemark.value=""
			window.document.frmAtmlnk.selAcType.value=""
		}
	}
	
	function TellerGl()
	{
		if(window.document.frmAtmlnk.txtdbtmodid.value=="")
		{
			alert("Module Id should not be null")
			return
		}
		telgl="Tellerglcode";
		brcode=window.document.frmAtmlnk.txtbranchcode.value
		modid=window.document.frmAtmlnk.txtdbtmodid.value.toUpperCase() 
		kstr=telgl+"|"+brcode+"|"+modid
		if(modid!="")
		{
			window.showModalDialog("../CUSTOMER/silist.aspx" + "?"+"st="+kstr,window,"status:no;"+
			"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		} 
	}

	function Glcodeid(kstr)
	{
		assign(kstr,window.document.frmAtmlnk.txtdbtglcodedesc,window.document.frmAtmlnk.txtdbtglcode)
		clear("1")
		
	}
	
	function Acccode()
	{
		if(window.document.frmAtmlnk.txtdbtglcode.value=="")
		{
			alert("GL Code should not be null")
			return
		}
		var actioncode 
	//stacc="Telleraccno"
	
	if(window.document.frmAtmlnk.radCardlnk(0).checked==true)
		{
		actioncode = 'I'
		}
		else
		{
		actioncode = 'U'
		}
		
		stacc="CardRequestAccs"
			
		 
		brchCd=window.document.frmAtmlnk.txtbranchcode.value.toUpperCase();
		ModId=window.document.frmAtmlnk.txtdbtmodid.value.toUpperCase();
		GlCd=window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase();
		Crcd=window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase();
		
			kstr=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd+"|"+Crcd+"|"+"='R'|"+ actioncode
		
		if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0) && (Crcd.length>0))
		{
   			window.showModalDialog("../gensbca/Listquery.aspx?st="+kstr,window,"status:no;"+
				"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")

   		}    
   		
	}
	
	function accountid(kstr)
	{ 
		assign(kstr,window.document.frmAtmlnk.txtdbtaccnodesc,window.document.frmAtmlnk.txtdbtaccno)
		
		window.document.frmAtmlnk.txtdbtcustid.value=""
		getCust()
		
	}
	
	function getCust()
	{
		var st="GETCUSTOMERID"+"|"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtmodid.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtaccno.value
   
		window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+st
	}
	
	function getCustdtls(str)
	{
		var st 
		
		st = str
		
		if(st == "")
		{
			alert("Not A Valid Customer Id")
			return;
		}
		
		window.document.frmAtmlnk.txtdbtcustid.value = st
		clear("2")
		
	}
	
	function CrdTyp()
	{
		if(window.document.frmAtmlnk.txtdbtaccno.value=="")
		{
			alert("Please Select Accno")
			return;
		}
		
		stmod="ATMCRDTYP"; 
		
		kstr=stmod
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function Crdtyp(kstr)
	{
		assign(kstr,window.document.frmAtmlnk.txtdbtcrdtyp,window.document.frmAtmlnk.txtdbtcrdval)
		
		clear("3")
		
		if(window.document.frmAtmlnk.txtdbtcrdval.value=="2")
		{
			window.document.all.divAdon.style.display="block" 
		}
		else
		{
			window.document.all.divAdon.style.display="none" 
		}
		
		CrdValid()
	}
	
	function CrdValid()
	{
		if(window.document.frmAtmlnk.radCardlnk(0).checked==true)
		{
			var st="GETCRDVALID"+"|"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtaccno.value+"|"+window.document.frmAtmlnk.txtdbtcrdval.value.toUpperCase()
   
		window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+st
		}
		
	}
	
	function popCrVald(str)
	{
		if(str != "")
		{
			var vStr
		
			vStr = str.split("~")
			
			if(window.document.frmAtmlnk.txtdbtcrdval.value=="1")
			{
				if(vStr[0]!="0")
				{
					alert("Already Primary Card Is Alloted")
					window.document.frmAtmlnk.txtdbtcrdval.value = ""
					window.document.frmAtmlnk.txtdbtcrdtyp.value = ""
					return;
				}
			}
			if(window.document.frmAtmlnk.txtdbtcrdval.value=="2")
			{
				if(vStr[0]=="0")
				{
					alert("Primary Card Is Not Alloted \n First Issue Primary Card")
					window.document.frmAtmlnk.txtdbtcrdval.value = ""
					window.document.frmAtmlnk.txtdbtcrdtyp.value = ""
					return;
				}
				else
				{
					window.document.frmAtmlnk.txtMincard.value = vStr[1]
				}
			}
		}
		else
		{
			if(window.document.frmAtmlnk.txtdbtcrdval.value=="2")
			{
				alert("Primary Card Is Not Alloted \n First Issue Primary Card")
				window.document.frmAtmlnk.txtdbtcrdval.value = ""
				window.document.frmAtmlnk.txtdbtcrdtyp.value = ""
				window.document.all.divAdon.style.display="none" 
				return;
			}
		}

	SetCardScope()		
	}
	
	function SetCardScope()		
	{
	var st="SETCARDSCOPE"+"|"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtaccno.value
		window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+st
	}

function GetCardScope(str)
	{
		if(str != "")
		{
			var vStr
		
			vStr = str.split("~")
			window.document.frmAtmlnk.txtdbtScopval.value = vStr[0]
			window.document.frmAtmlnk.txtdbtScopdesc.value = vStr[1]			
		}
}	
	
	
	function Categry()
	{
		stmod="ATMCATYPE"; 
		
		kstr=stmod
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function Catype(kstr)
	{	
		assign(kstr,window.document.frmAtmlnk.txtdbtCatdes,window.document.frmAtmlnk.txtdbtCatval)
		clear("4")
	}
	
	function Scop()
	{
		stmod="ATMSCOPTYPE"; 
		
		kstr=stmod
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function sctype(kstr)
	{	
		assign(kstr,window.document.frmAtmlnk.txtdbtScopdesc,window.document.frmAtmlnk.txtdbtScopval)
		clear("5")
		window.document.frmAtmlnk.txtdbtIsdat.value = "<%=session("applicationdate")%>"
		window.document.frmAtmlnk.txtdbtCrdlmt.value = "0.00"
		window.document.frmAtmlnk.txtdbtCshlmt.value = "0.00"
	// instant card
		if ((window.document.frmAtmlnk.txtdbtcrdval.value == "1") && (window.document.frmAtmlnk.txtdbtScopval.value == "2"))
		{
		//CheckForScope()
		}
		
		
		
		
	}
	
	function CheckForScope()
	{
	
		var st="CHECKCARDSCOPE"+"|"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtaccno.value
			window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+st
	}
	
	function popCheckScope(kstr)
	{
		if (kstr == "YES")
		{
			alert("This A/c already placed Customize Card Request")
			window.document.frmAtmlnk.txtdbtScopval.value=""
			window.document.frmAtmlnk.txtdbtScopdesc.value=""
		}
	}
	
	
	function Relat()
	{
		stmod="ATMRELION"; 
		
		kstr=stmod
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
	}
	
	function stRlat(kstr)
	{
		assign(kstr,window.document.frmAtmlnk.txtdbtReltiondesc,window.document.frmAtmlnk.txtdbtRelid)
		window.document.frmAtmlnk.txtCrdRemark.value=""
		window.document.frmAtmlnk.selAcType.value=""
	}
	
	function numbercheck(strTxt)
	{

		var theNum=parseFloat(strTxt.value);
		if(isNaN(theNum)||theNum<0)
		{
			if(theNum<0)
			{
				alert("Enter Only Numbers and Shoud Not Be Less Than Zero")
			}
			strTxt.value=""
			return;
		}
		else
		{
			strTxt.value=theNum;
		}

	}
	
	function showAcc()
	{
		if(window.document.frmAtmlnk.radCardlnk(0).checked==true)
		{
			window.document.frmAtmlnk.butCrdno.style.visibility="hidden"
			window.document.all['divClose'].style.display="none" 
			window.document.frmAtmlnk.txtdbtcrdNo.readOnly = false
		}
		if(window.document.frmAtmlnk.radCardlnk(1).checked==true)
		{
			window.document.frmAtmlnk.butCrdno.style.visibility="visible"
			window.document.all['divClose'].style.display="block" 
			window.document.frmAtmlnk.txtdbtcrdNo.readOnly = true
		}
		
		window.document.frmAtmlnk.txtdbtmodid.value=""
		window.document.frmAtmlnk.txtdbtmodiddesc.value=""
		window.document.frmAtmlnk.txtdbtglcode.value=""
		window.document.frmAtmlnk.txtdbtglcodedesc.value=""
		window.document.frmAtmlnk.txtdbtaccno.value=""
		window.document.frmAtmlnk.txtdbtaccnodesc.value=""
		window.document.frmAtmlnk.txtdbtcustid.value=""
		window.document.frmAtmlnk.txtdbtcrdval.value=""
		window.document.frmAtmlnk.txtdbtcrdtyp.value=""
		window.document.frmAtmlnk.txtdbtcrdNo.value=""
		window.document.frmAtmlnk.txtdbtCatval.value=""
		window.document.frmAtmlnk.txtdbtCatdes.value=""
		window.document.frmAtmlnk.txtdbtScopval.value=""
		window.document.frmAtmlnk.txtdbtScopdesc.value=""
		window.document.frmAtmlnk.txtdbtCrdlmt.value=""
		window.document.frmAtmlnk.txtdbtCshlmt.value=""
		window.document.frmAtmlnk.txtdbtIsdat.value=""
		window.document.frmAtmlnk.txtdbtValfrmdat.value=""
		window.document.frmAtmlnk.txtdbtValtodat.value=""
		window.document.frmAtmlnk.txtMincard.value=""
		window.document.frmAtmlnk.txtAcardnam.value=""
		window.document.frmAtmlnk.txtdbtRelid.value=""
		window.document.frmAtmlnk.txtdbtReltiondesc.value=""
		window.document.frmAtmlnk.txtCrdRemark.value=""
		window.document.frmAtmlnk.selAcType.value=""
		
	}
	
	function CrdNo()
	{
		stmod = "CARDNO"+"|"+window.document.frmAtmlnk.txtdbtmodid.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtaccno.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+window.document.frmAtmlnk.txtdbtcrdval.value.toUpperCase()
		
		kstr=stmod
		
		window.showModalDialog("atmList.aspx" + "?"+"st="+kstr,window,"status:no;"+
		"DialogWidth:270px;DialogHeight:170px;DialogLeft:300px;DialogTop:200px")
		
	}
	
	function stCrd(kstr)
	{
		window.document.frmAtmlnk.txtdbtcrdNo.value=kstr
		crDtls()
		
	}
	
	function crDtls()
	{
		var dtst
		
		dtst = "DTAILSCRD"+"|"+window.document.frmAtmlnk.txtdbtcrdNo.value
		
		window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+dtst
	}
	
	function popDetails(str)
	{
		if(str=="")
		{
			alert("No Records Found")
			return;
		}
		
		kstr=str.split("~")
		
		window.document.frmAtmlnk.txtdbtCatval.value = kstr[0]
		window.document.frmAtmlnk.txtdbtCatdes.value = kstr[1]
		window.document.frmAtmlnk.txtdbtScopval.value = kstr[2]
		window.document.frmAtmlnk.txtdbtScopdesc.value = kstr[3]
		window.document.frmAtmlnk.txtdbtCrdlmt.value = kstr[4]
		window.document.frmAtmlnk.txtdbtCshlmt.value = kstr[5]
		window.document.frmAtmlnk.txtdbtIsdat.value = kstr[6]
		window.document.frmAtmlnk.txtdbtValfrmdat.value = kstr[7]
		window.document.frmAtmlnk.txtdbtValtodat.value = kstr[8]
		window.document.frmAtmlnk.txtAcardnam.value = kstr[9]
		window.document.frmAtmlnk.txtMincard.value = kstr[10]
		window.document.frmAtmlnk.txtdbtReltiondesc.value = kstr[11]
		
		return;
	}
	
	function ValidCrd()
	{
	
	var strCardNo = window.document.frmAtmlnk.txtdbtcrdNo.value.toUpperCase()

if (strCardNo.length < 16)
{
	window.document.frmAtmlnk.txtdbtcrdNo.value=""
	alert("Debit Card Length Should Be 16 Digits")
	return
}

	
		if(window.document.frmAtmlnk.radCardlnk(0).checked==true)
		{
			dtst = "VCRDNO"+"|"+window.document.frmAtmlnk.txtdbtcrdNo.value
			
			window.document.all['iGetDtls'].src="getAtmDtls.aspx?st="+dtst
		}
	}
	
	function popVcrdno(str)
	{
		if(str!="0")
		{
			alert("Card Is Allready Issued")
			window.document.frmAtmlnk.txtdbtcrdNo.value = ""
			return;
		}
	}
	
	function Clschange()
	{
		window.document.frmAtmlnk.txtCrdRemark.value=""
	}
	
	function Submit()
	{
		if(window.document.frmAtmlnk.txtbranchcode.value=="")
		{
			alert("Please Select Branchcode")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtmodid.value=="")
		{
			alert("Please Select Module Id")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtglcode.value=="")
		{
			alert("Please Select Glcode")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtaccno.value=="")
		{
			alert("Please Select Accno")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtcustid.value=="")
		{
			alert("Please Select Customerid")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtcrdval.value=="")
		{
			alert("Please Select Card Type")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtcrdNo.value=="")
		{
			alert("Please Enter Card No.")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtCatval.value=="")
		{
			alert("Please Select Category")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtScopval.value=="")
		{
			alert("Please Select Scope")
			return;
		}
		/*if((window.document.frmAtmlnk.txtdbtCrdlmt.value=="")||(window.document.frmAtmlnk.txtdbtCrdlmt.value=="0.00"))
		{
			alert("Please Enter Card Limit")
			return;
		}
		if((window.document.frmAtmlnk.txtdbtCshlmt.value=="")||(window.document.frmAtmlnk.txtdbtCshlmt.value=="0.00"))
		{
			alert("Please Enter Cash Limit")
			return;
		}*/
		if(window.document.frmAtmlnk.txtdbtIsdat.value=="")
		{
			alert("Please Enter Issue Date")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtValfrmdat.value=="")
		{
			alert("Please Enter Valid From Date")
			return;
		}
		if(window.document.frmAtmlnk.txtdbtValtodat.value=="")
		{
			alert("Please Enter Valid To Date")
			return;
		}
		
		if(window.document.frmAtmlnk.txtdbtcrdNo.value=="2")
		{
			if(window.document.frmAtmlnk.txtMincard.value=="")
			{
				alert("Please Enter Main Card No.")
				return;
			}
			if(window.document.frmAtmlnk.txtAcardnam.value=="")
			{
				alert("Please Enter Card Holder Name")
				return;
			}
			if(window.document.frmAtmlnk.txtdbtRelid.value=="")
			{
				alert("Please Select Relation")
				return;
			}
		}
		
		var kSt,stMn,stNm
		
		if(window.document.frmAtmlnk.txtdbtcrdval.value=="2")
		{
			stNm = window.document.frmAtmlnk.txtAcardnam.value.toUpperCase()
		}
		else
		{
			stNm = window.document.frmAtmlnk.txtdbtaccnodesc.value.toUpperCase();
		}
		
		if(window.document.frmAtmlnk.radCardlnk(0).checked==true)
		{
			kSt = "INSERT"
		}
		if(window.document.frmAtmlnk.radCardlnk(1).checked==true)
		{
			kSt = "MODIFY"
		}
		
		stMn = kSt+"~"+window.document.frmAtmlnk.txtbranchcode.value.toUpperCase()+"|"+//brvod
					   window.document.frmAtmlnk.txtcurrencycode.value.toUpperCase()+"|"+//currency code
					   window.document.frmAtmlnk.txtdbtglcode.value.toUpperCase()+"|"+//glcode
					   window.document.frmAtmlnk.txtdbtaccno.value.toUpperCase()+"|"+//accno
					   window.document.frmAtmlnk.txtdbtcrdNo.value.toUpperCase()+"|"+//crd no
					   window.document.frmAtmlnk.txtdbtcustid.value.toUpperCase()+"|"+ // cust id
					   stNm+"|"+//name
					   window.document.frmAtmlnk.txtdbtcrdval.value.toUpperCase()+"|"+//crd type
					   window.document.frmAtmlnk.txtdbtCatval.value.toUpperCase()+"|"+//category type 
					   window.document.frmAtmlnk.txtdbtScopval.value.toUpperCase()+"|"+//scop type
					   window.document.frmAtmlnk.txtdbtIsdat.value.toUpperCase()+"|"+//isue date
					   window.document.frmAtmlnk.txtdbtValfrmdat.value.toUpperCase()+"|"+// val frm dat
					   window.document.frmAtmlnk.txtdbtValtodat.value.toUpperCase()+"|"+//val to dat
					   window.document.frmAtmlnk.txtdbtCrdlmt.value.toUpperCase()+"|"+//crd limt
					   window.document.frmAtmlnk.txtdbtCshlmt.value.toUpperCase()+"|"+// cash limt
					   window.document.frmAtmlnk.txtMincard.value.toUpperCase()+"|"+//main card
					   window.document.frmAtmlnk.txtdbtReltiondesc.value.toUpperCase()//relation
		
		if(window.document.frmAtmlnk.radCardlnk(1).checked==true)
		{
			var stat,stCdat
			
			if(window.document.frmAtmlnk.selAcType.value=="")
			{
				stat = "R"
				stCdat = ""
			}
			else
			{
				stat = window.document.frmAtmlnk.selAcType.value.toUpperCase()
				stCdat = "<%=session("applicationdate")%>"
			}
			
			stMn = stMn +"|"+window.document.frmAtmlnk.txtCrdRemark.value.toUpperCase()+"|"+stat+"|"+stCdat
			
		}
		//alert(" stMn = "+stMn )
		window.document.frmAtmlnk.empval.value=stMn
		window.document.frmAtmlnk.action="CardLnkInsert.aspx"
		window.document.frmAtmlnk.method="post"   
		window.document.frmAtmlnk.submit()
		
	}
	
	
	function dispMsg()
	{
		var strtran
			strtran='<%=Request.QueryString("record")%>'
		
		if(strtran!="")
		{
			alert(strtran)
			window.location.href="http://"+"<%=session("moduledir")& "/ATM/frmATMCardlnk.aspx"%>"
		}
	}
	
	</script>
	
	<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
	function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
			
			var intRefnd=getDateDiff(window.document.frmAtmlnk.txtdbtValfrmdat.value, window.document.frmAtmlnk.txtdbtIsdat.value)
			
			/*if(intRefnd<0)
			{
				alert("Valid From Date Should Not be Less Than Issue Date")
				window.document.frmAtmlnk.txtdbtValfrmdat.value=""
				window.document.frmAtmlnk.txtdbtValfrmdat.focus()
			}*/
			
			var intTofnd=getDateDiff(window.document.frmAtmlnk.txtdbtValtodat.value, window.document.frmAtmlnk.txtdbtValfrmdat.value)
			
			if(intTofnd<=0)
			{
				alert("Valid To Date Should Not be Less Than Or Equal To Valid From Date")
				window.document.frmAtmlnk.txtdbtValtodat.value=""
				window.document.frmAtmlnk.txtdbtValtodat.focus()
			}
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
		
	</script>
</head>
	<body onload="GetMenu(&quot;<%=session("menustring")%>&quot;);dispMsg()">
	<FORM id="frmAtmlnk" name="frmAtmlnk" >
	<DIV class=header><%appdate=formatdatetime(session("applicationdate"),1)%>
		<TABLE cellSpacing=0 cellPadding=0 width="99%">
			<TR>
				<TD class=bankHeaderLogo align=left></TD>
				<TD class=esmartBankerLogo align=right></TD>
			</TR>
		</TABLE>
	</DIV>
	<DIV class=menuBar>
		<TABLE cellSpacing=0 cellPadding=0 width="100%">
			<TR>
				<TD class=subHeader width="40%" height=22><FONT face=arial>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<I>Welcome, </I>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%> <%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<TD class=subHeader align=left width="40%" height=22><H2>Card Linking</H2></TD>
				<TD class=subHeader align=right width="20%" height=22> <%=APPDATE%></TD>
			</TR>
		</TABLE>
	</DIV>
	<DIV id=menucontrol></DIV>
		<TABLE class=tablebordermain cellSpacing=0 cellPadding=0 width="100%">
			<TR>
				<TD width="100%">
					<TABLE cellSpacing=0 class=tableborder2 cellPadding=0 width="100%" border=0>
						<tr class="bgcolor">
							<td width="15%" height="27"><font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</font></td>
							<td width="34%" height="27"><input class="txtautofill" name="txtbranchcode" size="16" maxlength=10 onblur=GetId('1') value="<%=session("branchcode")%>" ><input type="button" class="button" value=" L " name="buttbr" onclick="Branch()"><input name="txtbranchdesc" class="bgcolor1" size="28" value="<%=session("branchnarration")%>" readonly></td>
							<td width="20%" height="27"><font>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency Code</font></td>
							<td height="27" width="32%"><input name="txtcurrencycode"  class="txtautofill" maxlength=10 onblur=GetId('2') value="<%=session("currencycode")%>" size="9" ><input type="button" class="button" value=" L " name="buttcur" onclick="currency()"><input name="txtcurrencydesc" class="bgcolor1" size="16" value="<%=session("currencynarration")%>" readonly></td>
						</tr>
						<tr class="bgcolor">
							<td width="15%" height="27" colspan='4' align="center"><input type="radio" name="radCardlnk" id="crdLnk" onclick="showAcc()" checked>New&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radCardlnk" id="crdLnk1" onclick="showAcc()" >Modify</td>
						</tr>
						<tr>
							<td colspan='4' width="100%"> 
								<table class=tableborder2 width="90%">
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module ID&nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtdbtmodid" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtmodid&quot;)" size="16" onchange="return txtdbtmodid_onchange()"><input type="button" class="button" value=" L " name="butdbtmodid" onclick="Tellermodule()"><input type="text" name="txtdbtmodiddesc" class="bgcolor1" readonly size="28"></td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GL Code</td>
										<td width="17%"><input type="text" name="txtdbtglcode" class="txtautofill" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtglcode&quot;)" size="9" onchange="return txtdbtglcode_onchange()" maxlength=6><input type="button" class="button" value=" L " name="butdbtglcode" onclick="TellerGl()"><input type="text" name="txtdbtglcodedesc" class="bgcolor1" readonly size="16"></td>
									</tr>
									<tr>
										<td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Acc.No</td>
										<td width="35%"><input type="text" name="txtdbtaccno" class="txtautofill" onkeypress="Alphanum()" onblur="DescrptionDisp(&quot;txtdbtaccno&quot;)" size="16" maxlength="16" readonly><input type="button" class="button" value=" L " name="butdbtaccno" onclick="Acccode()"><input type="text" name="txtdbtaccnodesc" class="bgcolor1" readonly size="28"></td>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Customer ID</td>
										<td width="37%"><input type="text" name="txtdbtcustid" class="bgcolor1" readonly size="35" style="width: 246; height: 23"></td>
									</tr> 
								</table>
							</td>
						</tr>
						<tr>
							<td colspan='4'> 
							<fieldset style="width:900px;">
							<legend><font color="blue">Card Details</font></legend>
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="13%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Card Type</td>
										<td width="35%"><input type="text" name="txtdbtcrdval" class="txtautofill" onkeypress="Alphanum()" onblur="DescrptionDisp(&quot;txtdbtcrdval&quot;)" size="16" maxlength="16"><input type="button" class="button" value=" L " name="butdbtaccno" onclick="CrdTyp()"><input type="text" name="txtdbtcrdtyp" class="bgcolor1" readonly size="28"></td>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Card No</td>
										<td width="37%"><input type="text" name="txtdbtcrdNo" class="bgcolor1" size="35" onkeypress="numdec(window.document.frmAtmlnk.txtdbtcrdNo.value)"  maxlength="16" style="width: 246; height: 23" onblur="ValidCrd()"><input type="button" class="button" value=" L " name="butCrdno" onclick="CrdNo()" style="VISIBILITY: hidden" ></td>
									</tr> 
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Category&nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtdbtCatval" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtCatval&quot;)" size="16" onchange="return txtdbtmodid_onchange()" value="1"><input type="button" class="button" value=" L " name="butdbtmodid" onclick="Categry()"><input type="text" name="txtdbtCatdes" class="bgcolor1" readonly size="28" value = "RUPAY"></td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Scope</td>
										<td width="17%"><input type="text" name="txtdbtScopval" class="txtautofill" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtScopval&quot;)" size="9" onchange="return txtdbtglcode_onchange()" maxlength=6 readonly ><input type="button" class="button" value=" L " name="butdbtglcode" onclick="Scop()"><input type="text" name="txtdbtScopdesc" class="bgcolor1" readonly size="16"></td>
									</tr>
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Card Limit&nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtdbtCrdlmt" class="txtautofill" maxlength=16 onkeypress="Alphanum()" size="16" onkeypress="numdec(window.document.frmAtmlnk.txtdbtCrdlmt.value,window.document.frmAtmlnk.hpr.value)" value="0.00" style="TEXT-ALIGN: right" onblur="numbercheck(window.document.frmAtmlnk.txtdbtCrdlmt);precision(window.document.frmAtmlnk.txtdbtCrdlmt,window.document.frmAtmlnk.hpr.value);"></td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Limit</td>
										<td width="17%"><input type="text" name="txtdbtCshlmt" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-ALIGN: right" size="16" onkeypress="numdec(window.document.frmAtmlnk.txtdbtCshlmt.value,window.document.frmAtmlnk.hpr.value)" value="0.00" onblur="numbercheck(window.document.frmAtmlnk.txtdbtCshlmt);precision(window.document.frmAtmlnk.txtdbtCshlmt,window.document.frmAtmlnk.hpr.value);"></td>
									</tr>
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Issue Date&nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtdbtIsdat" class="txtautofill" maxlength='12' onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="16" onblur="datecheck(this)"  value="<%=session("applicationdate")%>">(DDMMYYYY)</td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="17%"></td>
									</tr>
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Valid From </td>
										<td width="17%"><input type="text" name="txtdbtValfrmdat" class="txtautofill" onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="16" onblur="datecheck(this)"  maxlength='12'>(DDMMYYYY)</td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Valid To</td>
										<td width="17%"><input type="text" name="txtdbtValtodat" class="txtautofill" maxlength='12' onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="16" onblur="datecheck(this)" >(DDMMYYYY)</td>
									</tr>
							
								</table>
							</fieldset>
							</td>
						</tr>
						<tr>
							<td colspan='4'>
							<div id="divAdon"  style="display:none" >
								<table border='0' class=tableborder2 width="90%">
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Main Card No. &nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtMincard" onkeypress="numdec(window.document.frmAtmlnk.txtMincard.value)" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="22" onchange="return txtdbtmodid_onchange()" readonly></td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="17%">&nbsp;&nbsp;</td>
									</tr>
									<tr>
										<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Card Holder Name&nbsp;&nbsp;</td>
										<td width="17%"><input type="text" name="txtAcardnam" class="txtautofill" maxlength=40 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="25" onchange="return txtdbtmodid_onchange()"></td>
										<td width="19%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Relation </td>
										<td width="17%">&nbsp;&nbsp;<input type="text" name="txtdbtRelid" class="txtautofill" maxlength=16 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" onblur="DescrptionDisp(&quot;txtdbtRelid&quot;)" size="9" onchange="return txtdbtmodid_onchange()"><input type="button" class="button" value=" L " name="butdbtmodid" onclick="Relat()"><input type="text" name="txtdbtReltiondesc" class="bgcolor1" readonly size="20"></td>
									</tr>
								</table>
							</div>
							</td>
						</tr>
						<tr>
							<td colspan='4'>
							<div id="divClose"  style="display:none" >
								<table border='0'  class=tableborder2 width="90%">
									<tr>
										<td width="8%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Close Type</font></td>
										<td width="24%" align="left">&nbsp;<select name="selAcType" onchange="Clschange()">
													<option value="" selected ></option>
													<option value="C">Closed</option>
													<option value="L">Lost</option>
													<option value="E">Expired</option>
													<option value="B">Block</option>
													</select></td>
										<td width="14%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remarks</td>
										<td width="22%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="txtCrdRemark" class="txtautofill" maxlength=40 onkeypress="Alphanum()" style="TEXT-TRANSFORM: uppercase" size="25"></td>
										
									</tr>
								</table>
							</div>
							</td>
						</tr>
					</td>
				</tr>
			</table>
	
	<iframe id="iGetDtls"  style="display: block" frameborder="0" framespacing="0" height="0" width="0" src="getAtmDtls.aspx"></iframe>
	<iframe id="iBatch" frameBorder=0 frameSpacing=0  height=0 width=0 src="../GENSBCA/querydisplay.aspx"></iframe>
	<input type="hidden" name="hmod" value="<%=session("module")%>">
	<input type="hidden" name="hpr" value="<%=session("precision")%>">
	<input type="hidden" name="empval">
	
	<table border="0" align="center" cellspacing="0" cellpadding="0" class="tableborder1" >
		<tr>
			<td align="right" width="5px"><input id="btnOk"  type="button" value=" OK "  class="button" onclick="Submit()"> </td>
			<td align="right" width="5px"><input id="btnCancel"  type="button" value=" Cancel "  class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/ATM/frmATMCardlnk.aspx"%>&quot;"> </td>
			<td align="right" width="5px"><input id="btnExit" type="button"  value="  Exit  "  class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/commonmodule.aspx"%>&quot;"> </td>
		</tr>
	</table>
	
	 <div class="footer">
		<div class="logo"></div>
		<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
	</div>					
    </form>

  </body>
</html>
