Public Class frmBRIMPSRefTrackingInsert
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strmode As Object
    Dim mystr As String
    Dim strvalues As Object
    Dim rows As Integer
    Dim strcols As Object
    Dim strRefno As String
    Dim appdate1 As String
    Dim i As Integer

    Dim dbCon As New DatabaseConnection.cDBConnection
    Dim o_errmsg As String
    Dim objCmd As New OracleClient.OracleCommand
    Dim drint As OracleClient.OracleDataReader
    Dim strResult, strResult1 As String
    Dim strTranStatus As String
    Dim strRequestFormat As String
    Dim strResponseFormat As String
    Dim strDelChanConID As String
    Dim strProcedureName As String
    Dim strBrId As String
    Dim strAccNo As String
    Dim strGlcd As String
    Dim strACTP As String
    Dim strDrRemarks As String


    Dim strRequest As String
    Dim strRequestDisp As String


    Dim strMobileNo As String


    Dim sQuery As String
    ' The response1 from the remote device.
    Dim response1 As String

    Dim strMTI As String
    Dim strMTIRes As String
    Dim strBitMap_1 As String
    Dim strBitMap_1Disp As String
    Dim strBrBen_2_1 As String
    Dim strBrBen_2_2 As String
    Dim strBenAccNo_103_1 As String
    Dim strBenAccNo_103_2 As String
    Dim strBenIFSCCode_127_1 As String
    Dim strBenIFSCCode_127_2 As String
    Dim strProCd_3 As String '' processing code
    Dim strTrnAmt_4 As String ''transaction amount

    Dim strSysTraAudNum_11 As String ''System Trace Audit Number
    Dim strLocTranDtTime_12 As String ''Local Transaction Date and Time
    Dim strCapDt_17 As String '' Capture Date
    Dim strFuncCd_24 As String ''Function Code
    Dim strAcqInsIdenCd_32_1 As String ''Acquiring Institution Identification Code
    Dim strAcqInsIdenCd_32_2 As String ''Acquiring Institution Identification Code
    Dim strExtPriAccNum_34_1 As String ''Extended Primary Account Number
    Dim strExtPriAccNum_34_2 As String ''Extended Primary Account Number
    Dim strTrack2Data_35_1 As String '' Track 2 Data
    Dim strTrack2Data_35_2 As String '' Track 2 Data
    Dim strRefNum_37 As String ''Reference Number
    Dim strResponseCode_39 As String '' Response Code
    Dim strRespCode1 As String
    Dim strCardAccTerID_41 As String ''Card Acceptor Terminal Id
    Dim strCardAccIden_42 As String  ''Card Acceptor Identification
    Dim strCardAccTermName_43_1 As String  ''Card Acceptor Identification
    Dim strCardAccTermName_43_2 As String  ''Card Acceptor Identification

    Dim strchrgsAmt_46_1 As String  '' charges / transaction amount
    Dim strchrgsAmt_46_2 As String  '' charges / transaction amount


    Dim strTranCurrCd_49 As String  ''Transaction Currency Code
    Dim strField56ForRev_56_1 As String  ''Field 56 For Reversal
    Dim strField56ForRev_56_2 As String  ''Field 56 For Reversal
    Dim strTrnsData_59_1 As String   '' Transport Data
    Dim strTrnsData_59_2 As String  '' Transport Data

    Dim strNetwrkMngtInfCode_70 As String   ''Network Management Information Code

    Dim strTransDest_93_1 As String   '' Transaction Destination  Institution Identification Code 
    Dim strTransDest_93_2 As String   '' Transaction Destination  Institution Identification Code 

    Dim strTransOrigin_94_1 As String   '' Transaction Originator  Institution Identification Code 
    Dim strTransOrigin_94_2 As String   '' Transaction Originator  Institution Identification Code 

    Dim strRepAmtParRev_95 As String  ''Replacement Amount(Partial Reversal)
    Dim strAccIden_102 As String
    Dim strAccIden_102_1 As String ''Account Identification 1
    Dim strAccIden_102_2 As String ''Account Identification 2
    Dim strAccIden_103 As String ''Account Identification 1
    Dim strDelChanConID_123_1 As String ''Delivery Channel Controller ID
    Dim strDelChanConID_123_2 As String ''Delivery Channel Controller ID
    Dim strTempDelChanConID_123_2 As String ''Temp Delivery Channel Controller ID
    Dim strTempTermType_124_2 As String '' Temp Terminal Type

    Dim strTermType_124_1 As String ''Terminal Type
    Dim strTermType_124_2 As String ''Terminal Type

    Dim strResrvPrvUse_125_1 As String ''Reserved For Private Use
    Dim strResrvPrvUse_125_2 As String ''Reserved For Private Use

    Dim strPrivFld_126_1 As String '' Private Field
    Dim strPrivFld_126_2 As String ''Private Field

    Dim strBenName As String
    Dim strMTIReq As String
    Dim dblbalAmt As Double
    Dim strRespStaCd As String
    Dim lngbatchno As Long

    Dim pRefNum As String
    Dim strServiceid As String
    Dim strRemarksOutWrd1 As String
    Dim ObjDbConn As New DatabaseConnection.cDBConnection

    Dim objtran As OracleClient.OracleTransaction
    Dim objCon As New OracleClient.OracleConnection
    Dim errmsg As String
    Dim o_errmsg1 As String
    Dim strCurCode As String
    Dim strRemAccName As String
    Dim strchqtype As String
    Dim strchqno As String
    Dim strchqdate As String
    Dim strPayeeAccno As String
    Dim strPayeeName As String
    Dim strIFSCCode As String
    Dim strCrRemarks As String
    Dim appDate, userId, machineID As String
    Dim strModid As String

    Dim sessBrCode As String
    Dim strOrgChanRefno, strTransRefno As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strsql As String
        Try


            mystr = Request.Form("hidpend")
            '' database connection
            objCon = dbCon.GetDbConnection(o_errmsg)
            If o_errmsg <> "" Then
                o_errmsg = "Failed To Connect To DataBase"
                Throw New Exception(o_errmsg)
            End If
            strResult = "" : strResult1 = ""
            If Len(mystr) > 0 Then
                strmode = Split(mystr, "~*~")
                strvalues = Split(strmode(0), "|")
                rows = strmode(1)

                For i = 0 To UBound(strvalues) - 1
                    SetClear()
                    strcols = Split(strvalues(i), "~")
                    strRefno = strcols(0)
                    appdate1 = strcols(1)



                    strsql = "select REFNO37, BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BNKREMMOBNO43, REMACCNO1021, REMACCNO1022,REMNAME1251, REMNAME1252,  TRANSREFNO from impsbrchanfundstrnsdtls where sentyn = 'Y' and  APPLICATIONDATE = '" & Format(CDate(appdate1), "dd-MMM-yyyy") & "' and REFNO37 = '" & strRefno & "' and SERVICEID = 'OUTWRD' and  TRANSTATUS='A'"
                    objCmd = New OracleClient.OracleCommand(strsql, objCon)
                    drint = objCmd.ExecuteReader
                    objCmd.Dispose()
                    objCmd = Nothing
                    If drint.HasRows = True Then
                        drint.Read()
                        strOrgChanRefno = IIf(IsDBNull(drint!REFNO37), "", drint!REFNO37)
                        strTransRefno = IIf(IsDBNull(drint!TRANSREFNO), "", drint!TRANSREFNO)
                        strBrId = IIf(IsDBNull(drint!BRANCHCODE), "", drint!BRANCHCODE)
                        strCurCode = IIf(IsDBNull(drint!CURRENCYCODE), "", drint!CURRENCYCODE)
                        strACTP = IIf(IsDBNull(drint!MODULEID), "", drint!MODULEID)
                        strGlcd = IIf(IsDBNull(drint!GLCODE), "", drint!GLCODE)
                        strAccNo = IIf(IsDBNull(drint!ACCNO), "", drint!ACCNO)
                        strMobileNo = IIf(IsDBNull(drint!BNKREMMOBNO43), "", drint!BNKREMMOBNO43)
                        strModid = IIf(IsDBNull(drint!MODULEID), "", drint!MODULEID)
                        strAccIden_102_2 = IIf(IsDBNull(drint!REMACCNO1022), "", drint!REMACCNO1022)
                        strAccIden_102_2 = strAccIden_102_2.TrimStart("0")
                        strAccIden_102_1 = strAccIden_102_2.Length.ToString.PadLeft(2, "0")
                        strResrvPrvUse_125_2 = IIf(IsDBNull(drint!REMNAME1252), "", drint!REMNAME1252)
                        strResrvPrvUse_125_1 = IIf(IsDBNull(drint!REMNAME1251), "", drint!REMNAME1251)

                        strServiceid = "CTRNST" ''  check transaction status
                        strProCd_3 = "111003"
                        strTranStatus = "A"
                        strTrnAmt_4 = ""
                        strTrnAmt_4 = strTrnAmt_4.PadLeft("12", "0")

                        strMTI = "1200"
                        strBitMap_1Disp = ""
                        '            strBitMap_1 = HexaToAscii("F030810128A08000000000000600003E")



                        strBrBen_2_2 = strBrId.Length.ToString.PadLeft(2, "0") & strBrId & getNBinNo.Length.ToString.PadLeft(2, "0") & getNBinNo()
                        strBrBen_2_1 = strBrBen_2_2.Length.ToString.PadLeft(2, "0")
                        ' strProCd_3 = "170001"

                        '' strSysTraAudNum_11 = "000446"
                        strSysTraAudNum_11 = ""
                        ' strLocTranDtTime_12 = Format(Now, "yyMMddHHmmss")
                        strLocTranDtTime_12 = Format(Now, "yyyyMMddHHmmss")
                        strCapDt_17 = Format(Now, "yyMM")
                        strFuncCd_24 = "200"
                        ' strAcqInsIdenCd_32_2 = "108481"  '' testing
                        strAcqInsIdenCd_32_2 = "100522" '' live
                        ''  strAcqInsIdenCd_32_2 = "108325" '' live
                        strAcqInsIdenCd_32_1 = strAcqInsIdenCd_32_2.Length.ToString.PadLeft(2, "0")
                        strTrack2Data_35_2 = "P2AO BRC"
                        strTrack2Data_35_1 = strTrack2Data_35_2.Length.ToString.PadLeft(2, "0")
                        strResponseCode_39 = ""
                        If strMobileNo = "" Then
                            Throw New Exception("Mobile No Not Present For The Accno : " & strAccNo)
                        End If

                        strCardAccTerID_41 = "MAH" & strMobileNo.Substring(5, 5)
                        '     strCardAccTermName_43_2 = "MCUBV" & strMobileNo
                        'strCardAccTermName_43_2 = ("MAH" & strMobileNo).PadRight(15, " ")
                        strCardAccTermName_43_2 = ("MAH91" & strMobileNo).PadRight(15, " ")
                        strTranCurrCd_49 = "356"

                        '  strAccIden_102_2 = (strBrId & strGlcd & strAccNo.PadLeft(7, "0")).PadLeft(17, "0")



                        strBenAccNo_103_2 = ""
                        strBenAccNo_103_1 = ""

                        strDelChanConID_123_2 = "CED"
                        strDelChanConID_123_1 = strDelChanConID_123_2.Length.ToString.PadLeft(3, "0")

                        strTermType_124_2 = "IMP"
                        strTermType_124_1 = strTermType_124_2.Length.ToString.PadLeft(3, "0")




                        strPrivFld_126_2 = ""
                        strPrivFld_126_1 = ""

                        strBenIFSCCode_127_2 = ""
                        strBenIFSCCode_127_1 = ""

                        strBenName = ""
                        appDate = GetAppDate(strBrId)
                        userId = Session("userid")
                        machineID = Session("machineid")

                        strResult = InsertIntoIMPSBrnchChannelFundsTrnsDtls(strRefNum_37, strSysTraAudNum_11, strBrId, strCurCode, strGlcd, strAccNo, strMTI, strBitMap_1Disp, strBrBen_2_1, strBrBen_2_2, strProCd_3, strTrnAmt_4, strLocTranDtTime_12, strCapDt_17, strFuncCd_24, strAcqInsIdenCd_32_1, strAcqInsIdenCd_32_2, strTrack2Data_35_1, strTrack2Data_35_2, strResponseCode_39, strCardAccTerID_41, strCardAccTermName_43_2, strTranCurrCd_49, strAccIden_102_1, strAccIden_102_2, strBenAccNo_103_1, strBenAccNo_103_2, strDelChanConID_123_1, strDelChanConID_123_2, strTermType_124_1, strTermType_124_2, strResrvPrvUse_125_1, strResrvPrvUse_125_2, strPrivFld_126_1, strPrivFld_126_2, strBenIFSCCode_127_1, strBenIFSCCode_127_2, strServiceid, strBenName, strTranStatus, appDate, userId, machineID, strRequestDisp, strModid, strOrgChanRefno, strTransRefno)
                        If strResult = "Success" Then
                        Else
                            Throw New Exception("Error Inserting in impsbrchanfundstrnsdtls : " & strRefNum_37)
                        End If




                    End If
                    drint.Close()
                    drint = Nothing
                    strResult1 = strResult1 & strRefno & ", "
                Next
                strResult = "Transaction Approved Successfull For Reference No " & strResult1
            End If
            Response.Redirect("frmIMPSRefNoOutwrdApprovals.aspx?st=" & strResult, False)
            Exit Sub
        Catch ex As Exception
            Response.Redirect("frmIMPSRefNoOutwrdApprovals.aspx?st=" & ex.Message, False)
        End Try
    End Sub


    Private Function GetAppDate(ByVal strbrid As String) As Date
        Try
            Dim appdate As Date
            Dim dtsysdate As Date
            Dim recnfts As OracleClient.OracleDataReader
            ' If objDBCon.State <> ConnectionState.Open Then
            '  objDBCon = objCon.GetDbConnection(errMsg)
            '  End If
            sQuery = "select sysdate from dual"
            objCmd = New OracleClient.OracleCommand(sQuery, objCon)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                If recnfts.Read() Then
                    dtsysdate = recnfts!sysdate
                End If
            End If
            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing

            sQuery = "select applicationdate from genapplicationdatemst where branchcode = '" & strbrid & "'"
            objCmd = New OracleClient.OracleCommand(sQuery, objCon)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                recnfts.Read()
                If IsDBNull(recnfts!applicationdate) Then
                    appdate = dtsysdate
                Else
                    appdate = recnfts!applicationdate
                End If
            Else
                appdate = dtsysdate
            End If
            GetAppDate = appdate
            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing
            Exit Function
        Catch ex As Exception
            If ex.Message = "Invalid operation. The connection is closed." Then
                GetAppDate = Format(Now, "dd-MMM-yyyy")
            End If
            ' WriteToErrorLogFile("GetAppDate", ex.Message)
        End Try
    End Function

    Private Function getNBinNo() As String
        Dim strError As String
        Dim recnfts As OracleClient.OracleDataReader
        Dim strgrpmst As String
        Dim strbnbin As String
        Try
            strgrpmst = ""


            strgrpmst = "select bnbin  from genbankparm"

            objCmd = New OracleClient.OracleCommand(strgrpmst, objCon)

            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                recnfts.Read()
                strbnbin = IIf(IsDBNull(recnfts!bnbin), "", recnfts!bnbin)

            Else
                strbnbin = ""
            End If
            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing

            getNBinNo = strbnbin
            Exit Function
        Catch ex As Exception
            strError = ex.Message
        End Try

    End Function

    Private Function HexaToAscii(ByVal strmsg As String) As String
        Dim text As New System.Text.StringBuilder(strmsg.Length \ 2)
        For i As Integer = 0 To strmsg.Length - 2 Step 2
            text.Append(Chr(Convert.ToByte(strmsg.Substring(i, 2), 16)))
        Next

        HexaToAscii = text.ToString
    End Function

    Public Sub SetClear()
        Try


            strServiceid = ""
            strBrId = ""
            strGlcd = ""
            strAccNo = ""
            strACTP = ""
            response1 = String.Empty

            strMTI = ""
            strMTIRes = ""
            strBitMap_1 = ""
            strBrBen_2_1 = ""
            strBrBen_2_2 = ""
            strBenAccNo_103_1 = ""
            strBenAccNo_103_2 = ""
            strBenIFSCCode_127_1 = ""
            strBenIFSCCode_127_2 = ""
            strRequestFormat = ""
            strResponseFormat = ""
            strDelChanConID = ""
            strProcedureName = ""
            strResult = ""
            strRequest = ""
            strMobileNo = ""
            strMTIReq = ""
            strRespStaCd = ""
            pRefNum = ""
            strProCd_3 = "" '' processing code
            strTrnAmt_4 = "" ''transaction amount
            strSysTraAudNum_11 = "" ''System Trace Audit Number
            strLocTranDtTime_12 = "" ''Local Transaction Date and Time
            strCapDt_17 = "" '' Capture Date
            strFuncCd_24 = "" ''Function Code
            strAcqInsIdenCd_32_1 = "" ''Acquiring Institution Identification Code
            strAcqInsIdenCd_32_2 = "" ''Acquiring Institution Identification Code
            strExtPriAccNum_34_1 = "" ''Extended Primary Account Number
            strExtPriAccNum_34_2 = "" ''Extended Primary Account Number
            strTrack2Data_35_1 = "" '' Track 2 Data
            strTrack2Data_35_2 = "" '' Track 2 Data
            strRefNum_37 = "" ''Reference Number
            strResponseCode_39 = "" ' Response Code
            strCardAccTerID_41 = "" ''Card Acceptor Terminal Id
            strCardAccIden_42 = "" ''Card Acceptor Identification
            strCardAccTermName_43_1 = ""  ''Card Acceptor Identification
            strCardAccTermName_43_2 = ""  ''Card Acceptor Identification
            strchrgsAmt_46_1 = "" '' Charges / Transaction Fee
            strchrgsAmt_46_2 = "" '' Charges / Transaction Fee
            strTranCurrCd_49 = ""  ''Transaction Currency Code
            strField56ForRev_56_1 = ""  ''Field 56 For Reversal
            strField56ForRev_56_2 = ""  ''Field 56 For Reversal

            strNetwrkMngtInfCode_70 = "" ''Network Management Information Code
            strRepAmtParRev_95 = "" ''Replacement Amount(Partial Reversal)

            strAccIden_102_1 = "" ''Account Identification 1
            strAccIden_102_2 = "" ''Account Identification 1
            strAccIden_103 = "" ''Account Identification 1
            strDelChanConID_123_1 = "" ''Delivery Channel Controller ID
            strDelChanConID_123_2 = "" ''Delivery Channel Controller ID
            strTempDelChanConID_123_2 = ""
            strTempTermType_124_2 = ""
            strTermType_124_1 = ""
            strTermType_124_2 = ""
            strDelChanConID = "" '' deliver channel id
            strPrivFld_126_1 = ""
            strPrivFld_126_2 = ""

            strResrvPrvUse_125_1 = "" ''Reserved For Private Use
            strResrvPrvUse_125_2 = "" ''Reserved For Private Use


            strBenName = ""
            strMTIReq = ""
            strMTIRes = ""

            strProcedureName = ""

            'Dim strarrstmtbal(6) As String  'array for ministatement details
            'Dim strarrstmtdet(5) As String  ' array for ministatement each column details

            strTrnsData_59_1 = ""
            strTrnsData_59_2 = ""
            strTransDest_93_1 = ""
            strTransDest_93_2 = ""
            strTransOrigin_94_1 = ""
            strTransOrigin_94_2 = ""
        Catch ex As Exception

        End Try
    End Sub
    Private Function InsertIntoIMPSBrnchChannelFundsTrnsDtls(ByRef refstrrefno As String, ByRef strstan11 As String, ByVal strbrcode As String, ByVal strcurcode As String, ByVal strGlcode As String, ByVal strAccno As String, ByVal mti As String, ByVal bitmap1 As String, ByVal brben1 As String, ByVal strbrben22 As String, ByVal strproccd3 As String, ByVal stramount4 As String, ByVal strdatetime12 As String, ByVal strdate17 As String, ByVal strfuncd24 As String, ByVal stracquirer321 As String, ByVal stracquirer322 As String, ByVal strtranchan351 As String, ByVal strtranchan352 As String, ByVal strrespcd39 As String, ByVal strstationid41 As String, ByVal strbnkremmobno43 As String, ByVal strcurcd49 As String, ByVal strremaccno1021 As String, ByVal strremaccno1022 As String, ByVal strbenaccno1031 As String, ByVal strbenaccno1032 As String, ByVal strnetwrk1231 As String, ByVal strnetwrk1232 As String, ByVal strimp1241 As String, ByVal strimp1242 As String, ByVal strremname1251 As String, ByVal strremname1252 As String, ByVal strremarks1261 As String, ByVal strremarks1262 As String, ByVal strbenifsccode1271 As String, ByVal strbenifsccode1272 As String, ByVal strserviceid As String, ByVal pstrbenname As String, ByVal pstrTranStatus As String, ByVal pappDate As String, ByVal puserId As String, ByVal pmachineID As String, ByRef pReqData As String, ByVal pstrModid As String, ByVal pstrOrgRefno As String, ByVal pstrTransRefno As String) As String

        Dim strError As String
        Dim recnfts As OracleClient.OracleDataReader
        Dim strSql As String
        Dim result As String

        Dim strrefno As String
        Dim cnt As Integer

        Dim subrefno As String = "1"
        Dim startdate As String
        Dim strRequestDisp1 As String
        Try

            startdate = "01/" & "01/" & Format(Now, "yyyy")
            'Dim lngcurdt As String = Format(Now, "yyMMdd")
            Dim lngcurdt As String = Format(Now, "yyyy").Substring(3, 1)
            Dim intdayofyr As String = (DateDiff("D", CDate(startdate), Now) + 1).ToString.PadLeft(3, "0")
            Dim inthh As String = Format(Now, "HH")
            strstan11 = GetStanNo()
            strrefno = lngcurdt & intdayofyr & inthh & strstan11
            refstrrefno = strrefno


            '' building request string 
            strRequestDisp1 = ""


            pReqData = strRequestDisp1

            strSql = "insert into impsbrchanfundstrnsdtls(refno37,BRANCHCODE,CURRENCYCODE,moduleid,GLCODE,ACCNO,MTI, BITMAPID, BRBEN1,brben2,proccd3,trnsamount4,stan11, datetime12,date17, funcd24,acquirer321, acquirer322,tranchan351,tranchan352,respcd39, stationid41,bnkremmobno43,curcd49,remaccno1021,remaccno1022,benaccno1031, benaccno1032,netwrk1231,netwrk1232,imp1241, imp1242, remname1251, remname1252,remarks1261,remarks1262,benifsccode1271,benifsccode1272,serviceid,benname,TRANSTATUS,applicationdate,USERID,MACHINEID,SYSTEMDATE,REQDATA,TRANSREFNO, ORIGINALCHANREFNO) values('" & strrefno & "','" & strbrcode & "','" & strcurcode & "','" & pstrModid & "','" & strGlcode & "','" & strAccno & "','" & mti & "','" & bitmap1 & "','" & brben1 & "','" & strbrben22 & "','" & strproccd3 & "','" & stramount4 & "','" & strstan11 & "','" & strdatetime12 & "','" & strdate17 & "','" & strfuncd24 & "','" & stracquirer321 & "','" & stracquirer322 & "','" & strtranchan351 & "','" & strtranchan352 & "','" & strrespcd39 & "','" & strstationid41 & "','" & strbnkremmobno43 & "','" & strcurcd49 & "','" & strremaccno1021 & "','" & strremaccno1022 & "','" & strbenaccno1031 & "','" & strbenaccno1032 & "','" & strnetwrk1231 & "','" & strnetwrk1232 & "','" & strimp1241 & "','" & strimp1242 & "','" & strremname1251 & "','" & strremname1252 & "','" & strremarks1261 & "','" & strremarks1262 & "','" & strbenifsccode1271 & "','" & strbenifsccode1272 & "','" & strserviceid & "','" & pstrbenname & "','" & pstrTranStatus & "','" & Format(CDate(pappDate), "dd-MMM-yyyy") & "','" & puserId & "','" & pmachineID & "',sysdate,'" & pReqData & "','" & pstrTransRefno & "','" & pstrOrgRefno & "')"

            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            cnt = objCmd.ExecuteNonQuery()
            result = "Success"
            objCmd.Dispose()
            objCmd = Nothing


        Catch ex As Exception
            result = "Fail"
            strError = ex.Message
        End Try
        InsertIntoIMPSBrnchChannelFundsTrnsDtls = result
    End Function

    Private Function GetStanNo() As String
        Dim recnfts As OracleClient.OracleDataReader
        Dim strSql As String
        Dim result As String
        Dim subrefno As String = "1"
        Dim strrefno As String

        Try

            Dim lngcurdt As String = Format(Now, "yyyy").Substring(3, 1)

            strSql = "select max(to_number(stan11))+1 sno from impsbrchanfundstrnsdtls where substr(refno37,0,1) ='" & lngcurdt & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts = objCmd.ExecuteReader
            objCmd.Dispose()
            objCmd = Nothing
            If recnfts.HasRows = True Then
                recnfts.Read()
                If IsDBNull(recnfts!sno) = True Then
                    strrefno = subrefno.PadLeft(6, "0")
                Else
                    strrefno = (recnfts!sno).ToString.PadLeft(6, "0")
                End If
            Else
                strrefno = subrefno.PadLeft(6, "0")
            End If
            recnfts.Close()
            recnfts = Nothing
            GetStanNo = strrefno
        Catch ex As Exception

        End Try
    End Function
End Class
