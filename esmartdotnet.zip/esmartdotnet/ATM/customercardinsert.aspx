<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="customercardinsert.aspx.vb" Inherits="eSmartDotNet.customercardinsert" %>
<%

dim obj,obj1,obj2,obj3,obj4,obj5,obj6,obj7,rs,rs1,rs2,rs3,rs4,rs5,rs6,rs7, Strmsg,status,StrTabName,strDataFlds,strDataFldVals,count,sno

obj=server.CreateObject("GeneralTransactions.DBTransactions")

obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
obj2=server.CreateObject("queryrecordsets.fetchrecordsets")
obj3=server.CreateObject("queryrecordsets.fetchrecordsets")
obj4=server.CreateObject("queryrecordsets.fetchrecordsets")
obj5=server.CreateObject("queryrecordsets.fetchrecordsets")
obj6=server.CreateObject("queryrecordsets.fetchrecordsets")
obj7=server.CreateObject("queryrecordsets.fetchrecordsets")
rs=server.CreateObject("adodb.recordset")
rs1=server.CreateObject("adodb.recordset")
rs2=server.CreateObject("adodb.recordset")
rs3=server.CreateObject("adodb.recordset")
rs4=server.CreateObject("adodb.recordset")
rs5=server.CreateObject("adodb.recordset")
rs6=server.CreateObject("adodb.recordset")
rs7=server.CreateObject("adodb.recordset")

dim Arrtrans(50,4)
dim cntCode
dim msg
cntCode="356"

appdate=session("applicationdate")
userid=session("userid")
machineid=session("machineid")
strmode=Request.Form("mercust")
strval=split(strmode,"|")


if strval(0) = "I" then

	rs1 = obj1.SingleRecordSet("genbankbranchmst","SUBSTR(MICRCODE,0,3) citycode,ATMBIN bnkcode,LPAD(NVL(branchcode,'0'),3,'0') brcode","branchcode='" & strval(33) & "'")
		
		if not rs1.EOF and not rs1.BOF then
			stCit = rs1(0).value
			stBnk = rs1(1).value
			stBrcd = rs1(2).value
		end if
		
		strcolnames = "ACTIONCODE,BANKCODE, BRCODE, VIPFLAG, OWNERCODE, BASICCARDFLAG, TITLE, FAMILYNAME, FIRSTNAME, EMBOSSEDNAME, ENCODEDNAME, MARITALSTATUS, GENDER, BIRTHDATE, BIRTHCITY,  ADDRESS1, ADDRESS2, ADDRESS3, ADDRESS4, CITYCODE, ZIPCODE, MOBILEPHONE, EMAIL1ID, EMPLOYMENTSTATUS, DELIVERYMODE, ACCOUNT1, ACCOUNT1TYPE, MAILINGADDRESS1, MAILINGADDRESS2, MAILINGADDRESS3, MAILINGADDRESS4,  MAILINGCITYCODE, MAILINGZIPCODE,  BRANCHCODE, REFNUM, APPLICATIONDATE, USERID, MACHINEID, NATIONALITYCODE, BIRTHCOUNTRY, COUNTRYCODE,  ACCOUNT1CURRENCY, MAILINGCOUNTRYCODE, PHOTOINDICATOR,LANGUAGEIND,PHONEMOBILE, CLIENTCODE, OPENINGDATE, PRODUCTCODE, TARIFFCODE,CONTRACTSTARTDATE,cardscopetype,MIDDLENAME, FATHERNAME, CITY, STATE"
		
		strdelvar=" 'I','" & stBnk & "','" & stBrcd & "','" & strval(9) & "','" & strval(1) & "','" & strval(2) & "','" & mid(ucase(strval(11)),1,4) & "','" & ucase(strval(43)) & "','" & ucase(strval(12)) & "','" & ucase(strval(13)) & "','" & ucase(strval(13)) & "','" & strval(6) & "','" & strval(8) & "','" & strval(14) & "','" & strval(15) & "','" & strval(21) & "','" & strval(22) & "','" & strval(23) & "','" & strval(24) & "','" & strval(25) & "','" & strval(26) & "','" & strval(16) & "','" & strval(17) & "','" & strval(5) & "','" & strval(7) & "','" & strval(18) & "','" & strval(19) & "','" & strval(27) & "','" & strval(28) & "','" & strval(29) & "','" & strval(30) & "','" & strval(31) & "','" & strval(32) & "','" & strval(33) & "'," & strval(34) & ",'" & appdate & "','" & userid & "','" & machineid & "','" & cntCode & "','" & cntCode & "','" & cntCode & "','" & cntCode & "','" & cntCode & "','" & strval(3) & "','1','" & strval(20) & "',(SELECT CUSTOMERID FROM " & strval(35) & "MST WHERE ACCNO='" & strval(37) & "' AND GLCODE='" & strval(36) & "' AND BRANCHCODE='" & strval(33) & "'),'" & appdate & "','001','001','" & appdate & "','"& strval(38) &"','"& strval(39) &"','"& strval(40) &"','"& strval(41) &"','"& strval(42) &"'"
		
		
			Arrtrans(i,0)="I"			
			Arrtrans(i,1)="ATMCRDDTLS"
			Arrtrans(i,2)=strcolnames
			Arrtrans(i,3)=strdelvar
			Arrtrans(i,4)=""
			
			Response.Write (Arrtrans(acnt,0) & "<br>")
			Response.Write (Arrtrans(acnt,1) & "<br>")
			Response.Write (Arrtrans(acnt,2) & "<br>")
			Response.Write (Arrtrans(acnt,3) & "<br>")
			Response.Write (Arrtrans(acnt,4) & "<br>")

			Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
			Response.Write (Strmsg)	
			obj=nothing
			
			msg = ""
			
			if ucase(mid(Strmsg,1,21))= "TRANSACTION SUCESSFUL" then
				rs2 = obj2.SingleRecordSet("ATMCRDDTLS","REFNUM","branchcode='" & strval(33) & "' and ACCOUNT1 = '" & strval(18) & "' and ACTIONCODE='I' ")
		
				if not rs2.EOF and not rs2.BOF then
					stRefno = rs2(0).value
				end if
				
				msg = "CRD" & stRefno
			end if
			
			
			
elseif strval(0) = "U" then


		strcolnames = "ACTIONCODE,FAMILYNAME, FIRSTNAME, EMAIL1ID, ADDRESS1, ADDRESS2, ADDRESS3, ADDRESS4, CITYCODE, ZIPCODE, MAILINGADDRESS1, MAILINGADDRESS2, MAILINGADDRESS3, MAILINGADDRESS4, MAILINGCITYCODE, MAILINGZIPCODE,  MOBILEPHONE, TRANSTATUS, GENYN, DELIVERYMODE,MIDDLENAME, FATHERNAME, CITY, STATE"
		strdelvar = "'" & strval(0) & "'~'" & strval(2) & "'~'" & strval(3) & "'~'" & strval(4) & "'~'" & strval(5) & "'~'" & strval(6) & "'~'" & strval(7) & "'~'" & strval(8) & "'~'" & strval(9) & "'~'" & strval(10) & "'~'" & strval(11) & "'~'" & strval(12) & "'~'" & strval(13) & "'~'" & strval(14) & "'~'" & strval(15) & "'~'" & strval(16) & "'~'" & strval(17) & "'~'P'~'N'~'1'~'" & strval(18) & "'~'" & strval(19) & "'~'" & strval(20) & "'~'" & strval(21) &"'"
		strdivcnd = " cardnumber='" & strval(1) & "' "
		
		Arrtrans(i,0)="U"			
		Arrtrans(i,1)="ATMCRDDTLS"
		Arrtrans(i,2)=strcolnames
		Arrtrans(i,3)=strdelvar
		Arrtrans(i,4)=strdivcnd
		
		Response.Write (Arrtrans(acnt,0) & "<br>")
		Response.Write (Arrtrans(acnt,1) & "<br>")
		Response.Write (Arrtrans(acnt,2) & "<br>")
		Response.Write (Arrtrans(acnt,3) & "<br>")
		Response.Write (Arrtrans(acnt,4) & "<br>")

		Strmsg= obj.DataTransactions(Arrtrans,cstr(session("branchcode")),cstr(userid),cstr(machineid),cstr(appdate))
		Response.Write (Strmsg)	
		obj=nothing

		msg = "" 
end if
		
		Response.Redirect ("frmcardcustomer.aspx?record=" & Strmsg & " " & msg  )

%>
