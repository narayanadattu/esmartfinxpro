<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="back3.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.back3" %>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<SCRIPT LANGUAGE=javascript>
<!--
function callme(){
window.history.back() 
window.history.back()
}
//-->
</SCRIPT>

</HEAD>
<BODY onload=callme()>

<P>&nbsp;</P>

</BODY>
</HTML>
