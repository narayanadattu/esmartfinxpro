<%@ Page CodeBehind="SBInstrumentapproval.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBInstrumentapproval" %>
<%
dim instr,str,trans,insdesc,inscd
str=Request.QueryString("result")
if len(str)> 0 then
instr=split(str,"~!~")
trans=instr(0)
inscd=instr(1)
insdesc=instr(2)
end if
%>

<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Instrument Approval</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
//To Get Branchcode
function branch()
{   
	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,st,"width=210%,height=150%,left=124%,top=210%")
	
}	

function Branchcode(str)
{

	assign(str,window.document.frmapproval.txtbranchdesc,window.document.frmapproval.txtbranchcode)
	//instrclear()
	//window.document.frmapproval.txtmodulecode.value=""
	//window.document.frmapproval.txtmoduledesc.value=""
	//window.document.frmapproval.txtuserdesc.value=""
	//window.document.frmapproval.txtuserid.value=""
		
}
	
function Display(){

		window.document.all.divleaf.style.display="none"
		window.document.all.divbook.style.display="block"
}

function Instrument(){
	
	str="Instrapproval"
	strbr=window.document.frmapproval.txtbranchcode.value
	Instrdet=str+"~"+strbr
	window.open("Listquery.asp?st="+Instrdet,"Ins","width=210,height=150%,right=124%,top=210%")
		
}

function instrcode(str){
	
	assign(str,window.document.frmapproval.txtinstrdesc,window.document.frmapproval.txtinstrcode)
	Insrment()
}
//To Get Instruments details.
function Insrment()
{
	brcode=window.document.frmapproval.txtbranchcode.value
	inscode=window.document.frmapproval.txtinstrcode.value
	if(brcode!="" && inscode!="")
	{
	window.document.frames(0).frminsapp.hidinstr.value=brcode+"~"+inscode
	window.document.frames(0).frminsapp.method="post"
	window.document.frames(0).frminsapp.action="SBinstrumentdtls.asp"
	window.document.frames(0).frminsapp.submit();
	}

}
// TO Approve all Instruments.
function Approveall()
{
var irows,irow,strrow
var jcols,jcol,strflex
strrow=""
strflex=""
irows=window.document.frames(0).frminsapp.mfgins.rows
for(irow=0;irow<irows-1;irow++)
{
	for(jcol=0;jcol<10;jcol++)
	{
		strflex=strflex+"~!~"+window.document.frames(0).frminsapp.mfgins.TextMatrix(irow+1,jcol)
	}
	strrow=strrow+"*|*"+strflex
	strflex=""
}	
if(eval(irows)>1){
	window.document.frmapproval.hidstatus.value="APPROVEALL"
	window.document.frmapproval.hidflex.value=strrow
	window.document.frmapproval.action="SBinstrumentapprovalinsert.asp"
	window.document.frmapproval.method="post"
	window.document.frmapproval.submit();
}
}

//To store textbox values into variables
function store()
{


	brcode=window.document.frmapproval.txtbranchcode.value
	inscd=window.document.frmapproval.txtinscode.value
	esno=window.document.frmapproval.txtendsno.value
	nlpb=window.document.frmapproval.txtnoleavesperbook.value
	serno=window.document.frmapproval.txtserno.value
	ssno=window.document.frmapproval.txtssno.value
	modid=window.document.frmapproval.txtmodid.value
	uid=window.document.frmapproval.txtuserid.value
	leno=window.document.frmapproval.txtleno.value
	lserno=window.document.frmapproval.txtlserno.value
	lsno=window.document.frmapproval.txtlsno.value
}


// To Approve  Instrument.

function Approveorrej(){
var brcode,inscd,esno,nlpb,serno,ssno
store()
if(window.document.frmapproval.Radtype(0).checked==true)
{	
 if(brcode!="" && modid!="" && uid!="" && inscd!="" && serno!="" && esno!="" && nlpb!="" && ssno!="")
 {
	
	window.document.frmapproval.action="SBinstrumentapprovalinsert.asp"
	window.document.frmapproval.method="post"
	window.document.frmapproval.submit();
  }
  else
  {
	alert('Fields Should not be Null.')
  }
 }
 else if(window.document.frmapproval.Radtype(1).checked==true)
 {

	if(brcode!="" && inscd!="" && modid!="" && uid!="" && leno!=""&& lserno!=""&& lsno!="")
	{
		window.document.frmapproval.action="SBinstrumentapprovalinsert.asp"
		window.document.frmapproval.method="post"
		window.document.frmapproval.submit();
	}
	else
	{
	alert('Fields Should not be Null.')
	}
}
}

//To Get Instruments Details when form loads.
function Instrdet(){

Insrment()

}
//To Approve the Instrument
function Approve(){

window.document.frmapproval.hidstatus.value="APPROVE"
Approveorrej()
}
//To Reject the Instrument
function Reject(){
window.document.frmapproval.hidstatus.value="REJECT"
Approveorrej()

}
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload='GetMenu("<%=session("menustring")%>");Display();Instrdet()'>
<form name="frmapproval">
<%appdate=formatdatetime(session("applicationdate"),1)%>
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr class="bgcolor">
      <td width="11%"><IMG border=0 height=19 src="blanktextbox.gif" width=90><IMG border=0 height=19 src="blanktextbox.gif" width=70></td>
      <td width="89%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="27%" align="middle">
          </td>
          <td width="40%" align="middle">
          <font class="text">Instrument(Department)
          Approval</font>
          </td>
          <td width="33%" nowrap align="middle"><font color="white"><%=APPDATE%></font></td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td width="100%" valign="top" height="15" align=middle><font face="MS Sans Serif" color="blue" size="3"><%=trans%></font></td>
    </tr>
    <tr>
      <td width="100%" valign="top">
      <div align="center">

        <table border="0" width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td>
            <div align="center">
              <center>

              <table border="0" width="99%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="20%" height="10"></td>
                  <td height="10"></td>
                  <td width="29%" align="right" height="10"></td>
                  <td width="75%" align="right" height="10"></td>
                </tr>
                <tr class="bgcolor">
                  <td width="20%">
                  <p align="right"><font class="textbold">Branch
                  Code&nbsp;&nbsp;</font></p>
                  </td>
                  <center>
                  <td><input name="txtbranchcode" size="9" Value="<%=session("Branchcode")%>" readonly style="TEXT-ALIGN: right" ><input type="button" value=" L " name="B3" onclick="branch()"><input name="txtbranchdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" Value="<%=session("Branchnarration")%>" readonly></td>
                  <td width="29%" align="right"><font class="textbold">Instrument
                  Code&nbsp;&nbsp;&nbsp;</font></td>
                  </center>
                  <td width="75%" align="right">
                  <p align="left"><input name="txtinstrcode" size="7"  value="<%=inscd%>"><input type="button" value=" L " name="butins" onclick="Instrument()"><input name="txtinstrdesc" size="16" value="<%=insdesc%>" style="background-color: #B3A597; color: #FFFFFF"></p>
                  </td>
                </tr>
                <center>
                <tr>
                  <td width="20%" height="10"></td>
                  <td height="10"></td>
                  <td width="29%" align="right" height="10"></td>
                  <td width="75%" align="right" height="10"></td>
                </tr>
                </table>

              </center>
              </div>
              <div align="center">
                <center>

                <table border="0" width="99%" cellspacing="0" cellpadding="0" class="tableborder2">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%" height="5"></td>
                      </tr>
                      <tr>
                        <td width="100%">
                        <div align="center">
                          <center>

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="100%">
                              <td><iframe id=den align=center            
                                      frameborder=0 framespacing=0 noresize height=140 width=700 
                              valign="top" src="SBinstrumentdtls.asp" 
                              style="BACKGROUND-COLOR: darkred"></iframe></td>
                            </tr>
                          </table>

                          </center>
                        </div>
                        </td>
                      </tr>
                    </table>

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%" height="10"></td>
                      </tr>
                    </table>

                    <div align="center">
                      <center>

                      <table border="0" width="20%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 98px" class="tablebordermain">
                        <tr>
                          <td width="100%"><input type="button" value="Approve all" name="butapp" onclick="Approveall()" class="bgcolor"></td>
                        </tr>
                      </table>

                      </center>
                    </div>

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%" height="10"></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

                </center>
              </div>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
              </table>

              <div align="center">
                <center>

                <table border="0" width="98%" class="tableborder2" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr>
                      <td width="100%">

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="100%"></td>
                        </tr>
                        <tr>
                          <td width="100%">

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr class="bgcolor">
                              <td width="14%" height="15">&nbsp;&nbsp;&nbsp;&nbsp; <font class="textbold">Branch
                              Code</font></td>
                              <td width="29%" height="15"><input name="txtbrcode" size="9" readonly style="TEXT-ALIGN: right" ><input type="button" value=" L " name="B3" onclick="branch()" disabled><input name="txtbrdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" readonly></td>
                              <td width="21%" height="15" align="right"><font class="textbold">Instrument
                              Code&nbsp;&nbsp;&nbsp;</font></td>
                              <td width="36%" height="15"><input name="txtinscode" size="9" readonly><input type="button" value=" L " name="B3" onclick="account()" disabled><input name="txtinsdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" readonly></td>
                            </tr>
                            <tr>
                              <td width="14%" height="15"><font face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              To User ID&nbsp;&nbsp;&nbsp;</font></td>
                              <td width="29%" height="15"><input name="txtuserid" size="9" readonly><input type="button" value=" L " name="cmdmod" onclick="module()" disabled><input name="txtuserdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" readonly></td>
                              <td width="21%" height="15" align="right"><font face="MS Sans Serif" size="2">Module ID &nbsp;&nbsp;</font></td>
                              <td width="36%" height="15"><input name="txtmodid" size="9" readonly><input type="button" value=" L " name="B3" disabled><input name="txtmoddesc" size="16" style="background-color: #B3A597; color: #FFFFFF" readonly></td>
                            </tr>
                          </table>

                          </td>
                        </tr>
                      </table>

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tbody>
                          <tr>
                            <td width="100%" height="10"></td>
                          </tr>
                          <tr>
                            <td width="100%" height="10">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor1">
                                <td width="18%" height="26"><font size="2" face="MS Sans Serif">&nbsp;</font><input type="radio" value="Book" checked name="Radtype"><font size="2" face="MS Sans Serif">Book</font></td>
                                <td width="5%" height="26"><input type="radio" value="Leaf" name="Radtype"><font size="2" face="MS Sans Serif">Leaf</font></td>
                                <td width="15%" height="26"></td>
                                <td width="5%" height="26"></td>
                                <td width="71%" height="26"></td>
                              </tr>
                              <tr>
                                <td width="100%" height="10" colspan="5">
                                <p align="center"></p>
                                </td>
                              </tr>
                            </table>

                            <div align="center">
                              <center>
                              <div id="divbook">

                                <table border="0" width="100%" class="tablebordermain" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="100%">

                                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                      <tr class="bgcolor">
                                        <td width="748" colspan="9" height="20"><font class="subheading">Available
                                        Book Stock Details</font></td>
                                      </tr>
                                      <tr>
                                        <td width="748" height="19" colspan="9"></td>
                                      </tr>
                                      <tr>
                                        <td width="60" height="20" nowrap><font class="textsmall">&nbsp;Series
                                        No</font></td>
                                        <td height="20" width="103" nowrap><font size="1"><input name="txtserno" size="9" readOnly></font></td>
                                        <td width="118" height="20" align="right" nowrap><font class="textsmall">No
                                        of Leaves per book</font></td>
                                        <td width="61" height="20" nowrap><font size="1"><input name="txtnoleavesperbook" size="6" 
                                readOnly></font></td>
                                        <td height="20" align="right" nowrap></td>
                                        <td width="60" height="20" align="right" nowrap><font class="textsmall">Start
                                        S.No&nbsp;</font></td>
                                        <td width="71" height="20" nowrap><font size="1"><input name="txtssno" size="9" readOnly></font></td>
                                        <td width="60" height="20" align="right" nowrap><font class="textsmall">End
                                        S.No.&nbsp;</font></td>
                                        <td width="71" height="20" nowrap><font size="1"><input name="txtendsno" size="9" 
                                readOnly></font></td>
                                      </tr>
                                      <tr>
                                        <td width="730" height="5" colspan="9"></td>
                                      </tr>
                                    </table>

                                    </td>
                                  </tr>
                                </table>

                              </center>
                              </div>
                              <div align="center">
                                <center>
                                <div id="divleaf">

                                  <table border="0" width="100%" class="tablebordermain" cellspacing="0" cellpadding="0">
                                    <tbody>
                                      <tr>
                                        <td width="100%">

                                        <table border="0" width="100%" cellspacing="0" cellpadding="0" height="67">
                                          <tr class="bgcolor">
                                            <td width="731" height="20" colspan="8"><font class="subheading">Available
                                            Leaf&nbsp; Details</font></td>
                                          </tr>
                                          <tr>
                                            <td width="731" height="20" nowrap colspan="8"></td>
                                          </tr>
                                          <tr>
                                            <td width="75" height="27" nowrap>
                                            <p align="right"><font face="MS Sans Serif" size="1">Series
                                            No.</font><font size="2" face="MS Sans Serif">&nbsp;&nbsp;&nbsp;&nbsp;</font></p>
                                            </td>
                                            <center></center><center></center><center></center>
                                            <td width="75" height="27" nowrap><input name="txtlserno" size="9" readOnly></td>
                                            <td width="83" height="27" nowrap>
                                            <p align="right"><font face="MS Sans Serif" size="1">No.of&nbsp;Leaves&nbsp;&nbsp;
                                            </font></p>
                                            </td>
                                            <center><center><center>
                                            <td width="98" height="27" nowrap><input name="txtnol" size="9" readOnly 
                               ></td>
                                            <td width="77" height="27" align="right" nowrap><font face="MS Sans Serif" size="1">Leaf
                                            Start No.</font> </td>
                                            <td width="110" height="27" nowrap><input name="txtlsno" size="9"></td>
                                            <td width="109" height="27" nowrap><font face="MS Sans Serif" size="1">Leaf
                                            End No.</font></td>
                                            <td width="109" height="27" nowrap><input name="txtleno" size="9" 
                                readOnly></td>
                                            </tr>
                                            </table>

                                            </center></center></center></td>
                                      </tr>
                                  </table>

                                </div></DIV></CENTER></DIV>

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="100%" height="10"></td>
                              </tr>
                            </table>

                            <div align="center">
                              <center>

                              <table border="0" width="25%" cellspacing="0" cellpadding="0" class="tablebordermain">
                                <tr>
                                  <td width="100%"><input type="button" value="Approve" name="butapp" onclick='Approve()' class="bgcolor"><input type="button" value="Reject" name="butrej" onclick='Reject()' class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick='window.location.href="http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.asp"%>"' class="bgcolor"><input type="button" value="   Exit   " name="butexit" class="bgcolor" onclick='location.replace("sbmodule.asp")'></td>
                                </tr>
                              </table>

                              </center>
                            </div>
                            </td>
                          </tr>
                          <tr>
                            <td width="100%" height="10"></td>
                          </tr>
                      </table></TD></TR></TBODY></TABLE></CENTER></DIV>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
              </table></CENTER></TD></TR></TABLE></DIV></TD></TR>
    <tr>
      <td width="100%" valign="top"></td>
    </tr></TABLE>

  <input type="hidden" name="hidflex"><input type="hidden" name="hidstatus">
</form>

</body>

</html>
