<%@ Page Language="vb" CodeBehind="Listcustomer.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Listcustomer" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmart Banker</title>
<%
 strType=Request.QueryString("st")
 userid=session("userid")
 brchCd=Request.QueryString("brchCd")
 atype=Request.QueryString("atype")
 Modid=Request.QueryString("Modid")
 status="Y"
%>
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
function List()
{
var str,ints,intk,intp


 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else
 {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	
if (type=="Branch")
{
	window.attachEvent(window.opener.Branchid(str))
	window.close()
}
if (type=="Bruser")
{   window.attachEvent(window.opener.Bruser(str))
	window.close()
}

else if (type=="Currency")
{
	window.attachEvent(window.opener.Currencyid(str))
	window.close()
}	

else if (type.substr(0,5)=="DocNo")
{
	
	window.attachEvent(window.opener.dispDocNo(str))
	window.close()
}	

	else if (type=="BLevel")
{
	window.attachEvent(window.opener.Levelid(str))
	window.close()
}
else if (type=="Curr")
{
	window.attachEvent(window.opener.Currid(str))
	window.close()
}
else if (type=="Module")
{
	window.attachEvent(window.opener.Moduleid(str))
	window.close()
}
else if (type=="DocModule")
{
	window.attachEvent(window.opener.Moduleid(str))
	window.close()
}
else if (type.substring(0,6)=="Glcode")
{
	window.attachEvent(window.opener.Glcodeid(str))
	window.close()
}
else if (type.substring(0,5)=="Accno")
{
	window.attachEvent(window.opener.Accnoid(str))
	window.close()
}

else if (type.substring(0,7)=="TransNo")
{
	window.attachEvent(window.opener.TransNoid(str))
	window.close()
}
else if (type.substring(0,6)=="CustID")
{
	window.attachEvent(window.opener.Custid(str))
	window.close()
}

else if (type.substring(0,11)=="Cashiertype")
{
	window.attachEvent(window.opener.Cashiertype(str))
	window.close()
}
else if (type.substring(0,9)=="Cashierid")
{
	window.attachEvent(window.opener.Cashierid(str))
	window.close()
}
else if (type.substring(0,10)=="Cashiermgt")
{
	window.attachEvent(window.opener.CashierMgtid(str))
	window.close()
}
else if (type.substring(0,11)=="CutsoiledNo")
{
	window.attachEvent(window.opener.CutSoiledid(str))
	window.close()
}
else if (type.substring(0,9)=="Allotment")
{
	window.attachEvent(window.opener.Allotmentid(str))
	window.close()
}
else if (type.substring(0,7)=="Cashier")
{
	window.attachEvent(window.opener.Cashiercd(str))
	window.close()
}
else if (type.substring(0,8)=="Bankcode")
{
	window.attachEvent(window.opener.Bankid(str))
	window.close()
}
else if (type.substring(0,6)=="CashID")
{
	window.attachEvent(window.opener.Cashierid(str))
	window.close()
}
else if (type.substring(0,7)=="Cashacc")
{
	window.attachEvent(window.opener.Cashieracc(str))
	window.close()
}
else if ((type.substring(0,9)=="AppUserid") ||(type.substring(0,10)=="AppGroupid") )
{
	window.attachEvent(window.opener.UserCode(str))
	window.close()
}
else if (type=="User")
{
	window.attachEvent(window.opener.DisplayGroup(str))
	
	window.close()
}

else if (type=="Groups")
{
	window.attachEvent(window.opener.DisplayGroups(str))
	
	window.close()
}

else if (type=="Group")
{
		
	window.attachEvent(window.opener.DisplayGroup(str))
	
	window.close()
}
else if (type.substring(0,5)=="Query")
{
	window.attachEvent(window.opener.DisplayQuery(str))
	
	window.close()
}

else if (type.substring(0,14)=="AllotedCashier")
{
	window.attachEvent(window.opener.AllotedCashierid(str))
	window.close()
}
else if (type=="regions")
{
	window.attachEvent(window.opener.Regionid(str))
	window.close()
}

else if (type=="usergroups")
{
	window.attachEvent(window.opener.Groupid(str))
	window.close()
}
else if (type.substring(0,8)=="cashtype")
{
	window.attachEvent(window.opener.cashtype(str))
	window.close()
}
else if (type.substring(0,12)=="cashiertypes")
{  
	window.attachEvent(window.opener.cashiertypes(str))
	window.close()
}

else if (type.substring(0,16)=="Cashrefundaccept")
{
	window.attachEvent(window.opener.Cashiercodeid(str))
	window.close()
}
else if (type.substring(0,12)=="Cashrefundno")
{
	window.attachEvent(window.opener.Cashrefundid(str))
	window.close()
}
else if (type.substring(0,13)=="Cashcounterno")
{
	window.attachEvent(window.opener.Cashcounterid(str))
	window.close()
}
else if (type.substring(0,6)=="Userid")
{
	window.attachEvent(window.opener.UserCode(str))
	
	window.close()
	
}
else if(type.substring(0,11)=="ALLCASHIERS")
{
	
	window.attachEvent(window.opener.Cashiercd(str))
	window.close()
}
else if(type.substring(0,10)=="Occupation")
//else if (type=="Occupation")
{
	
	window.attachEvent(window.opener.dispOccCode(str))
	window.close()
}
else if(type.substring(0,6)=="Income")
{
	
	window.attachEvent(window.opener.dispOccCode(str))
	window.close()
}
else if(type.substring(0,13)=="Qualification")
{
	
	window.attachEvent(window.opener.dispOccCode(str))
	window.close()
}
else if(type.substring(0,8)=="CustType")
{
	
	window.attachEvent(window.opener.dispOccCode(str))
	window.close()
}
}
}
</SCRIPT>
<%
dim obj,rs
  set rs=server.CreateObject("adodb.recordset")
  set rssyn=server.CreateObject("adodb.recordset")
  set rs1=server.CreateObject("adodb.recordset")
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  set objbr=server.CreateObject("GeneralTranQueries.TransactionQueries")
  
if strType ="Branch" then
	set rs=obj.singlerecordset("GENBANKBRANCHMST","Branchcode,narration")
	
elseif strType="BLevel" then
	set rs=obj.singlerecordset("GENBANKLEVELMST","code,narration")	
	
elseif strType="Bruser" then	
	set rs=objbr.BranchCodes(cstr(userid))
	
elseif left(strType,6)="Userid" then
   atype=mid(strType,7,len(strType))
   set rs=obj.singlerecordset("genusermst","userid,name","branchcode='"&atype&"'")

elseif strType="Currency" then
	set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration","STATUS!='D'")
elseif strType="Curr" then
	set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,precision","STATUS!='D'")
	
elseif strType="Module" then
   set  rs=obj.singlerecordset("genmoduletypesmst","distinct moduleid,Narration","implementedyn='Y'")

elseif mid(strType,1,10)="Occupation" then
	strtype1=split(strtype,"|")
if strtype1(1)="View" then
	set  rs=obj.singlerecordset("genoccupationmst","code,Narration,status")
else
   set  rs=obj.singlerecordset("genoccupationmst","code,Narration,status","status='R'")
end if 
elseif mid(strType,1,6)="Income" then
	strtype1=split(strtype,"|")
if strtype1(1)="View" then
	set  rs=obj.singlerecordset("genincomemst","code,Narration,status")
else
   set  rs=obj.singlerecordset("genincomemst","code,Narration,status","status='R'")
end if

elseif mid(strType,1,13)="Qualification" then
	strtype1=split(strtype,"|")
if strtype1(1)="View" then
	set  rs=obj.singlerecordset("genQualificationmst","code,Narration,status")
else
   set  rs=obj.singlerecordset("genQualificationmst","code,Narration,status","status='R'")
end if  
elseif mid(strType,1,8)="CustType" then
	strtype1=split(strtype,"|")
if strtype1(1)="View" then
	set  rs=obj.singlerecordset("custtypemst","code,Narration,status")
else
   set  rs=obj.singlerecordset("custtypemst","code,Narration,status","status='R'")
end if  

elseif strType="DocModule" then
   set  rs=obj.singlerecordset("GENBANKDOCUMENTMST a, Genmoduletypesmst b","distinct a.moduleid,b.Narration","a.moduleid=b.moduleid")
   
elseif mid(strType,1,5)="DocNo" then
   
   set  rs=obj.singlerecordset("GENBANKDOCUMENTMST","documentcode,Narration,status","moduleid='" & mid(strtype,6) &"'")
   
   
elseif left(strType,6)="Glcode" then
   'stname=left(strType,2)
   'atype=mid(strType,7,len(strType))
   set rs=obj.singlerecordset("genglsheetmst","glcode,NARRATION","moduleid='"&atype&"'")
    
elseif left(strType,5)="Accno" then
    'stname=left(strType,5)
    'atype=mid(strType,6,len(strType))
    dim objTrn
    set objTrn=Server.CreateObject("GeneralTranQueries.TransactionQueries")
    set rs=objTrn.AccountNumbers(cstr(brchCd),cstr(Modid),cstr(atype))
	set objTrn=nothing 
    
elseif left(strType,6)="CustID" then
    stname=left(strType,4)
    atype=mid(strType,7)
    set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","")
	
elseif left(strType,7)="TransNo" then
    stname=left(strType,5)
    atype=mid(strType,8)
    set rs=obj.singlerecordset("translog","tranno,amount","glcode='"& atype &"'","tranno")
    
elseif left(strtype,8)="cashtype" then
    ctype=split(strtype,"|")
    set rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration","STATUS is null and (currencycode='" & ctype(2) & "' and branchcode='" & ctype(1) & "')")
    
elseif left(strtype,12)="cashiertypes" then
    ctype=split(strtype,"|")
    set rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration"," STATUS IS NULL and (currencycode='" & ctype(2) & "' and branchcode='" & ctype(1) & "')")
    
elseif strtype="regions" then
    set rs=obj.singlerecordset("GENREGIONMST","CODE,NARRATION","STATUS='R'")
elseif strtype="usergroups" then
    set rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS IS NULL")

elseif left(strType,11)="Cashiertype" then
	stname=left(strType,11)
	k=split(strType,"*")
	set rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration","BRANCHCODE='" & k(1) & "'","cashiertypeid")
elseif strType="Cashier" then
	stname=strType
	strcond="W.USERID = U.USERID AND W.USERID<>'" & userid & "' AND W.USERID NOT IN (SELECT CASHIERID FROM CASHCOUNTERMST)"
	strfld="DISTINCT W.USERID,U.NAME"
	strtab="GENWORKALLOTMENTMST W,GENUSERMST U"
	SET rs=obj.singlerecordset(cstr(strtab),cstr(strfld),cstr(strcond))
    
elseif left(strType,9)="Cashierid" then
	stname=strType
	k=split(strType,"*")
	set rs=obj.singlerecordset("cashcashierposmst cash,genusermst gen","cash.cashierid,gen.name","cash.cashierid=gen.userid and cash.cashierid <> '"& cstr(userid)&"' " )
	
elseif left(strType,6)="CashID" then
	k=split(strType,"|")
	set rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid),gen.name","cash.cashierid=gen.userid and upper(trim(cash.cashierid)) <> '"& ucase(trim(cstr(userid))) &"' and gen.branchcode='" & k(1) &"'")
	
elseif left(strType,14)="AllotedCashier" then
	stname=strType
	cash=split(stname,"*")
    set rs=obj.singlerecordset("CASHALLOTMENTSTRN CASH,GENUSERMST GEN","DISTINCT(CASH.CASHIERID),GEN.NAME","CASH.CASHIERID=GEN.USERID AND CASH.BRANCHCODE='"& CASH(1) &"' AND CASH.CURRENCYCODE='" & CASH(2)&"'","CASH.CASHIERID")
	
elseif left(strType,9)="Allotment" then

	k=split(strType,"*")
	Response.Write strtype&"prasad"
	Response.Write cstr(userid)
	set rs=obj.singlerecordset("cashallotmentstrn","Allotmentno","cashierid='" & k(1) &"' and counterno = '" & k(2) & "' and status='P'","allotmentno")
	
elseif strtype="Bankcode" then

	set rs=obj.singlerecordset("Genbankmst","Bankname,BANKCODE")
	
elseif left(strtype,10)="Cashiermgt" then

	k=split(strtype,"*")
	set rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.cashierid=gen.userid and cash.cashierid not in ('" & ucase(userid) &"')")
	
	
elseif left(strtype,16)="Cashrefundaccept" then		

	k=split(strtype,"*")	
	set rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen","distinct(cash.REFUNDEDUSERID),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.REFUNDEDUSERID=gen.userid  and cash.status='P' and cash.USERID <> '"& userid&"'" )	
	
elseif left(strtype,7)="Cashacc" then

	k=split(strtype,"*")
	set rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN cash,genusermst gen","distinct(cash.fromcashierid),gen.name","cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.FROMcashierid=gen.userid and cash.status='P' and cash.tocashierid='" & cstr(userid) & "'","cash.fromcashierid")
	
elseif left(strtype,11)="CutsoiledNo" then
	k=split(strtype,"|")
	set rs=obj.singlerecordset("CASHCUTNSPOILNOTESMST","CUTSOILTRANNO,custid,RECEIVEDFROM","UPPER(TRIM(branchcode))='" & UCASE(TRIM(k(1))) & "' and UPPER(TRIM(currencycode))='" & UCASE(TRIM(k(2))) &"'")

elseif left(strtype,5)="Group" then
	k=split(strtype,"|")
	set rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='A'")
elseif left(strtype,6)="Groups" then
	k=split(strtype,"|")
	set rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='A'")
elseif left(strtype,4)="User" then
	k=split(strtype,"|")
	set rs=obj.singlerecordset("GENusermst","userid,name","STATUS='A'")
elseif left(strtype,5)="Query" then
	if right(strtype,1)="N" then
		set rs=obj.singlerecordset("GENUSERMST","Userid,Name")
	else
		set rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='P'")
	end if
elseif strType="Groupid" then
	set rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","status='A'")		
elseif left(strType,6)="Userid" then
   atype=mid(strType,7,len(strType))
   set rs=obj.singlerecordset("genusermst","userid,name","branchcode='"&atype&"' and status='A'")
elseif strType="AppGroupid" then
	set rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","groupcode in(select distinct(Groupcode) from gengroupformsmst where status<>'A')")		
elseif left(strType,9)="AppUserid" then
   atype=mid(strType,7,len(strType))
   set rs=obj.singlerecordset("genworkallotmentmst","userid,username","status<>'A'")
elseif left(strtype,11)="ALLCASHIERS" then
	k=split(strType,"|")
	set rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid), gen.name, cash.counterno "," cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.cashierid=gen.userid"," gen.name")
end if
%>
</head>
<body>

<form name="frmList">
  <%

IF  NOT rs.EOF AND NOT rs.BOF THEN%>
  <div align="center">
    <center>

    <table border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
      <tr class="bgcolor">
        <% if  strType="Curr" then%>
      
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(stname)%>&nbsp;DESCRIPTION
          - CODE - PRECISION</font></th>
        <%elseif len(strType)>8 then%>
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(stname)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%else%>
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(strType)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%end if%>
      <tr>
        <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	      <% 
	do until rs.EOF
	if rs.Fields.Count = 2 then%>
          <option><%=rs(1)%>-----<%=rs(0)%></option>
	      <%elseif rs.Fields.Count=3 then%>
          <option><%=rs(1)%>-----<%=rs(0)%>-----<%=rs(2)%></option>
	      <%end if%>
	      <%
	rs.MoveNext
	loop
	 
	  Response.Write"<script language=vbscript>"
	  Response.Write "window.document.frmList.cmbList.item(0).selected=true" & chr(13)
      Response.Write"</script>" 
          %>

        </select></td>
      </tr>
    </table>

    </center>
  </div>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
	<%else%>

  <center><%Response.Write "<center><font color=white size=3><b>No Records Found</b></font></center>"%></center><br>
  <br>
  <center><input type="button" value="   OK   " name="butok" onclick="window.close()" class="bgcolor"></center>
	<%end if%>
  </center>
</form>

</body>

</html>
