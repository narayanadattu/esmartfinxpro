<%@ Page Language="vb" CodeBehind="customerinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.customerinsert" %>
<%
	dim Arrtrans(2,4)
	dim obj,obj1,Strmsg,status,title,rs
	set obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=server.CreateObject("adodb.recordset")
	set rs=obj1.singlerecordset("gencustinfomst","max(to_number(customerid))+1")
	Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")
	appdate=session("applicationdate")
	name=Request.Form("txtname")
	userid=session("userid")
	custid=Request.Form("txtcustid")
	machineid=session("machineid")
	status=Request.Form("hidmode")	
	narration=Request.Form("txtnarration")
	famdtls=Request.Form("hidfamvals")
	mode=Request.Form("hidmode")
	
	trans="X"
	if len(custid )="" then
		custid=rs(0)
	end if
	
	set rs=obj1.singlerecordset("gencustfamilydtls","customerid","customerid='" & custid &"'")
	if not rs.EOF and not rs.BOF then
		deltrans="D"
	else
		deltrans="X"
	end if	
	
	if len(famdtls)>1 then
		famdtls=split(famdtls,"#")
		for i=1 to ubound(famdtls)
			famvals=famvals & "|" & famdtls(i) & ",'" & userid & "','" & _
				machineid & "','" & appdate & "','" & custid & "'" 
			trans="I"
		next
		famvals=trim(mid(famvals,2))
	else
		trans="X"
	end if
	code=Request.Form("txtcode")
	
	tabname="genCUSTINFOMST"
	
	custfields="branchcode,custname,customertype,custmembershipno,custdob,custemail,custfax," & _
	"custmobile,custminoryn,custmaritalstatus,custsex,custoccupation,custqualification," & _
	"custmonthlyincome,phone1,phone2,phone3,mailaddress1,mailaddress2,mailaddress3," & _
	"mailaddress4,mailaddress5,pmtaddress1,pmtaddress2,pmtaddress3,pmtaddress4," & _
	"pmtaddress5,offaddress1,offaddress2,offaddress3,offaddress4,offaddress5," & _
	"userid,machineid,applicationdate,systemdate,customerid"
	if mode="New" then
		transtat="I"
		custvals=trim(ucase(Request.Form("hidcustvals"))) &  ",'" & userid & "','" & _
		machineid & "','" & appdate & "',sysdate,'" & custid & "'"
		arrtrans(0,4)=""
	elseif mode="Modify" then
		transtat="U"
		custvals=trim(ucase(Request.Form("hidcustvals"))) &  "~'" & userid & "'~'" & _
		machineid & "'~'" & appdate & "'~sysdate~'" & custid & "'"
		arrtrans(0,4)="customerid='" & custid &"'"
	elseif mode="Delete" then
		transtat="D"
		arrtrans(0,4)="customerid='" & custid &"'"
	end if
		
			arrtrans(0,0)=transtat
			arrtrans(0,1)=tabname
			arrtrans(0,2)=custfields
			arrtrans(0,3)=custvals
			
			
			arrtrans(1,0)=deltrans
			arrtrans(1,1)="Gencustfamilydtls"
			arrtrans(1,2)=""
			arrtrans(1,3)=""
			arrtrans(1,4)="customerid='" & custid &"'"
			
			
			
			arrtrans(2,0)=trans
			arrtrans(2,1)="Gencustfamilydtls"
			arrtrans(2,2)="branchcode,name,dob,relation,userid,machineid,applicationdate,Customerid"
			arrtrans(2,3)=famvals
			arrtrans(2,4)=""
			
Strmsg= obj.DataTransactions(Arrtrans)



Response.Write strmsg
Response.Write arrtrans(0,0) & "<br>"
Response.Write arrtrans(0,2) & "<br>"
Response.Write arrtrans(0,3) & "<br>"
Response.Write arrtrans(0,4) & "<br>"

Response.Write arrtrans(1,0) & "<br>"
Response.Write arrtrans(1,2) & "<br>"
Response.Write arrtrans(1,3) & "<br>"
Response.Write arrtrans(1,4) & "<br>"

Response.Write arrtrans(2,0) & "<br>"
Response.Write arrtrans(2,2) & "<br>"
Response.Write arrtrans(2,3) & "<br>"
Response.Write arrtrans(2,4) & "<br>"
response.Redirect "customer.asp?record=" & strmsg

		
%>
  
