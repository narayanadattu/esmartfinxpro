<%@ Page CodeBehind="customer.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Customer" %>
<%
dim rs,rs1,rs2,rs3,obj
dim occcode,occdesc,quacode,quadesc,inccode,incdesc,relcode,reldesc
		
set obj=server.CreateObject("QueryRecordsets.FetchRecordsets")
set rs=server.CreateObject("adodb.recordset")
set rs1=server.CreateObject("adodb.recordset")
set rs2=server.CreateObject("adodb.recordset")
set rs3=server.CreateObject("adodb.recordset")

set rs=obj.singlerecordset("genoccupationmst","code,narration","status='R' order by code")
set rs1=obj.singlerecordset("genqualificationmst","code,narration"," status='R' order by code")
set rs2=obj.singlerecordset("genincomemst","code,narration","status='R' order by code")
set rs3=obj.singlerecordset("genrelationsmst","code,narration","status='R' order by code")
record=session("result")
result=Request.QueryString("record")
%>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<link rel="stylesheet" type="text/css" href="../styletag.css">
<title>Customer Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function Getcustomerid()
{
if(window.document.frmCustomer.hidmode.value=="New")
	return

st=window.document.frmCustomer.txtCustid.value
Clear()
window.document.frmCustomer.txtCustid.value=st
st=st
window.open("Customerfly.asp?st="+st,"Customer11","width=1,height=1 left=0 top=0")
}

function SetMinor()
{
if(window.document.frmCustomer.chkMinor.checked==true)
	window.document.frmCustomer.optMarital(1).checked=true

}


function NewCustDisplay(str)
{
record=str
if(record.length>1)
	{
	record=record.split("|")
	if (record.length>2)
		window.document.frmCustomer.hidch.value=record[2]
	
	window.document.frmCustomer.txtCustid.value =record[0]
	window.document.frmCustomer.txtCustname.value =record[1]
	st=record[0]+ "|Main"
	window.open("Customerfly.asp?st="+st,"Customer11","width=1,height=1 left=0 top=0")
	}
	window.document.frmCustomer.hidmode.value="Modify"
}



function GetNewcust()
{
record="<%=record%>"
result="<%=result%>"
if(result.length>1)
record=result
record=record.split("|")
if(record.length>1)
	{
	window.document.frmCustomer.txtCustid.value =record[0]
	window.document.frmCustomer.txtCustname.value =record[1]
	if(record.length>2)
	{
		window.document.frmCustomer.txtBranchCode.value=record[2]
		window.document.frmCustomer.txtCurrencyCode.value=record[3]
		window.document.frmCustomer.txtBranchDesc.value=record[4]
		window.document.frmCustomer.txtCurrrencyDesc.value=record[5]
	}
	st=record[0]+ "|Main"
	window.open("Customerfly.asp?st="+st,"Customer11","width=1,height=1 left=0 top=0")
	window.document.frmCustomer.hidmode.value="Modify"
	}
else
	{
	window.close()
	}
}

function AddtoGrid()
{
var rows=window.document.frmCustomer.mfgPenal.Rows
var fname=window.document.frmCustomer.txtFamName.value 
var fdob=window.document.frmCustomer.txtFamDob.value
var selind=window.document.frmCustomer.cmbRelation.selectedIndex 
var frel=window.document.frmCustomer.cmbRelation.options[selind].text

if((fname.length<1)||(fdob.length<1)||(eval(selind)<1))
{
return
}
if(window.document.frmCustomer.mfgPenal.TextMatrix(1,1).length>1)
	window.document.frmCustomer.mfgPenal.Rows=rows+1
else
	rows=rows-1	
window.document.frmCustomer.mfgPenal.TextMatrix(rows,0)=rows
window.document.frmCustomer.mfgPenal.TextMatrix(rows,1)=fname
window.document.frmCustomer.mfgPenal.TextMatrix(rows,2)=fdob
window.document.frmCustomer.mfgPenal.TextMatrix(rows,3)=frel
window.document.frmCustomer.txtFamDob.value=""
window.document.frmCustomer.txtFamName.value=""
window.document.frmCustomer.cmbRelation.options[0].selected=true
}

function GetCustomer()
{

st="RealCust"
	window.open("ListCustomer.asp" + "?"+"st="+st,"Customer","width=350%,height=150% left=130 top=200")

}
function GetBranch()
{
	st="Branch"
	window.open("ListCustomer.asp" + "?"+"st="+st,"Customer","width=350%,height=150% left=130 top=200")

}


function Branchid(str)
{
str=str.split("-----")
window.document.frmCustomer.txtBranchCode.value=str[1]
window.document.frmCustomer.txtBranchDesc.value=str[0] 
}

function GetCurrency()
{
	st="Currency"
	window.open("ListCustomer.asp" + "?"+"st="+st,"Customer","width=350%,height=150% left=130 top=200")

}


function Currencyid(str)
{
str=str.split("-----")
window.document.frmCustomer.txtCurrencyCode.value=str[1]
window.document.frmCustomer.txtCurrrencyDesc.value=str[0] 
}


function DispCustomer(str)
{
	if (str!="No Data Found..")
	{
		Clear()
		str=str.split("-----")
		window.document.frmCustomer.txtCustid.value=str[1]
		window.document.frmCustomer.txtCustname.value=str[0]
		st=str[1] + "|Main"
		window.open("Customerfly.asp?st="+st,"Customer11","width=1,height=1 left=0 top=0")
		
	}
}

function Display(str)
{
if((str=="Invalid Customer Id..")&&(window.document.frmCustomer.hidmode.value!="New"))
{
	alert(str)
	window.document.frmCustomer.txtCustid.value=""
	return
}

str1=str.split("!!")
fstr=str1[0].split("~~")
str=str1[1].split("|")
if(fstr.length>1)
{
	window.document.frmCustomer.txtCustname.value =str[31]
	window.document.frmCustomer.chkFamily.checked=true
	window.document.frmCustomer.mfgPenal.Rows=fstr.length
	for(i=1;i<fstr.length;i++)
	{
		dstr=fstr[i].split("|")
		window.document.frmCustomer.mfgPenal.TextMatrix(i,0)=i
		window.document.frmCustomer.mfgPenal.TextMatrix(i,1)=dstr[0]
		window.document.frmCustomer.mfgPenal.TextMatrix(i,2)=dstr[1]
		window.document.frmCustomer.mfgPenal.TextMatrix(i,3)=dstr[2]
	}


}
window.document.frmCustomer.txtCustTypeDesc.value=str[0]
if(eval(str[1])>0)
window.document.frmCustomer.txtCustType.value=str[1]
if(str[2].length>1)
{
	window.document.all.spMember.style.visibility="visible"
	window.document.frmCustomer.chkMember.checked=true
}
window.document.frmCustomer.txtMemId.value=str[2]
window.document.frmCustomer.txtDob.value=str[3]
window.document.frmCustomer.txtEmail.value=str[4]
window.document.frmCustomer.txtFax.value=str[5]
window.document.frmCustomer.txtMobile.value=str[6]
if(str[7].length>0)
{
if(str[7].toUpperCase()=="Y")
	window.document.frmCustomer.chkMinor.checked=true
else
	 window.document.frmCustomer.chkMinor.checked=false
}
if(str[8].length>0)
{
if(str[8]=="Y")
	window.document.frmCustomer.optMarital(0).checked=true
else if(str[8]=="N")
	window.document.frmCustomer.optMarital(1).checked=true
}
if(str[9].length>0)
{
if(str[9]=="M")
	window.document.frmCustomer.optGender(0).checked=true
else if(str[9]=="F")
	window.document.frmCustomer.optGender(1).checked=true
}	
	
for(i=0;i<window.document.frmCustomer.cmbOccupation.length;i++)
	{
		if(eval(window.document.frmCustomer.cmbOccupation.options[i].value)==eval(str[10]))
		{	window.document.frmCustomer.cmbOccupation.options[i].selected=true
			
		}
	} 
for(i=0;i<window.document.frmCustomer.cmbEducation.length;i++)
	{
		if(eval(window.document.frmCustomer.cmbEducation.options[i].value)==eval(str[11]))
			window.document.frmCustomer.cmbEducation.options[i].selected=true
	} 
for(i=0;i<window.document.frmCustomer.cmbIncome.length;i++)
	{
		if(eval(window.document.frmCustomer.cmbIncome.options[i].value)==eval(str[12]))
			window.document.frmCustomer.cmbIncome.options[i].selected=true
	}
window.document.frmCustomer.txtPhone1.value=str[13]
window.document.frmCustomer.txtPhone2.value=str[15]
window.document.frmCustomer.txtPhone3.value=str[14]

window.document.frmCustomer.txtMFlat.value=str[16]
window.document.frmCustomer.txtMBldg.value=str[17]
window.document.frmCustomer.txtMArea.value =str[18]
window.document.frmCustomer.txtMCity.value=str[19]
window.document.frmCustomer.txtMPin.value =str[20]

window.document.frmCustomer.txtPFlat.value=str[21]
window.document.frmCustomer.txtPBldg.value=str[22]
window.document.frmCustomer.txtPArea.value =str[23]
window.document.frmCustomer.txtPCity.value=str[24]
window.document.frmCustomer.txtPPin.value =str[25]

window.document.frmCustomer.txtOFlat.value=str[26]
window.document.frmCustomer.txtOBldg.value=str[27]
window.document.frmCustomer.txtOArea.value =str[28]
window.document.frmCustomer.txtOCity.value=str[29]
window.document.frmCustomer.txtOPin.value =str[30]

window.document.frmCustomer.chkPersonal.checked=true
window.document.frmCustomer.chkMailing.checked=true

if((eval(str[10])>0)||(eval(str[11])>0)||(eval(str[12])>0))
	window.document.frmCustomer.chkOccup.checked=true
else
	window.document.frmCustomer.chkOccup.checked=false

if((str[21].length>1)||(str[22].length>1)||(str[23].length>1)||(str[24].length>1)||(str[25].length>1)||(str[14].length>1))
	window.document.frmCustomer.chkPerm.checked=true
else
	window.document.frmCustomer.chkPerm.checked=false

if((str[26].length>1)||(str[27].length>1)||(str[28].length>1)||(str[29].length>1)||(str[30].length>1)||(str[15].length>1))
	window.document.frmCustomer.chkOffice.checked=true
else
	window.document.frmCustomer.chkOffice.checked=false
}
function dtpDob_CloseUp() {
	Datepick(window.document.frmCustomer.dtpDob,window.document.frmCustomer.txtDob)
	st=window.document.frmCustomer.txtDob.value + "|" + "9999"
	window.open("datecheck.asp"+"?"+"st="+st,"Mod","width=1%,height=1%,left=0,top=0") 
}

function dtpFamDob_CloseUp() {
	Datepick(window.document.frmCustomer.dtpFamDob,window.document.frmCustomer.txtFamDob)
	st=window.document.frmCustomer.txtFamDob.value + "|" + "999"
	window.open("datecheck.asp"+"?"+"st="+st,"Mod","width=1%,height=1%,left=0,top=0") 
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpDob EVENT=CloseUp>
<!--
 dtpDob_CloseUp()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpFamDob EVENT=CloseUp>
<!--
 dtpFamDob_CloseUp()
//-->
</SCRIPT>
</head>

<SCRIPT LANGUAGE=javascript>
<!--
// to check for "@" and "." symbols in email id
function DisplayMember()
{
if(window.document.frmCustomer.chkMember.checked==true)
	window.document.all.spMember.style.visibility="visible"
else
	window.document.all.spMember.style.visibility="hidden"

}
function Checksymbols() 
{
var indx
var indy
	window.document.frmCustomer.txtEmail 
	if (window.document.frmCustomer.txtEmail.value!="")
	{
	indx=window.document.frmCustomer.txtEmail.value.split("@")
	if (indx.length>2)
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	indy=window.document.frmCustomer.txtEmail.value.split(".")
	if (indy.length>3)
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	indy=window.document.frmCustomer.txtEmail.value.lastIndexOf(".")
	indx=window.document.frmCustomer.txtEmail.value.length
	if(indy==indx-1) 
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	indx=window.document.frmCustomer.txtEmail.value.indexOf("@") // Take the index of "@"
	if ((indx==-1)||(indx==0))  // if "@" is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	indy=window.document.frmCustomer.txtEmail.value.indexOf(".") // Take the index of "."

	if ((indx==-1)||(indx==0))  // if "." is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	if ((indy==indx+1)||(indy<indx))
		{
			alert ("Enter valid mailid...!")
			window.document.frmCustomer.txtEmail.focus() 
			return
		}
	}
}


function DispDivision(str)
{
	if (str==1) 
	{
		if(window.document.frmCustomer.chkPersonal.checked==true)
		{
			window.document.all.divPersonal.style.display="block"
			window.document.all.divFamily.style.display="none"
			window.document.all.divOccupation.style.display="none"
			window.document.all.divMail.style.display="none"
			window.document.all.divPerm.style.display="none"
			window.document.all.divOffice.style.display="none"
		
		}
		else
			window.document.all.divPersonal.style.display="none"
	}
	if (str==2) 
	{
		if(window.document.frmCustomer.chkFamily.checked==true)
		{
			window.document.all.divFamily.style.display="block"
			window.document.all.divPersonal.style.display="none"
			window.document.all.divOccupation.style.display="none"
			window.document.all.divMail.style.display="none"
			window.document.all.divPerm.style.display="none"
			window.document.all.divOffice.style.display="none"
		}
		else
			window.document.all.divFamily.style.display="none"
	}
	if (str==3) 
	{
		if(window.document.frmCustomer.chkOccup.checked==true)
		{
			window.document.all.divOccupation.style.display="block"
			window.document.all.divFamily.style.display="none"
			window.document.all.divPersonal.style.display="none"
			window.document.all.divMail.style.display="none"
			window.document.all.divPerm.style.display="none"
			window.document.all.divOffice.style.display="none"
		}	
		else
			window.document.all.divOccupation.style.display="none"
	}
	if (str==4) 
	{
		if(window.document.frmCustomer.chkMailing.checked==true)
		{
			window.document.all.divMail.style.display="block"
			window.document.all.divOccupation.style.display="none"
			window.document.all.divFamily.style.display="none"
			window.document.all.divPersonal.style.display="none"
			window.document.all.divPerm.style.display="none"
			window.document.all.divOffice.style.display="none"
		}
		else
			window.document.all.divMail.style.display="none"
	}
	if (str==6) 
	{
		if(window.document.frmCustomer.chkPerm.checked==true)
		{
			window.document.all.divPerm.style.display="block"
			window.document.all.divOccupation.style.display="none"
			window.document.all.divFamily.style.display="none"
			window.document.all.divPersonal.style.display="none"
			window.document.all.divOffice.style.display="none"
			window.document.all.divMail.style.display="none"
		}
		else
			window.document.all.divPerm.style.display="none"
	}
	if (str==5) 
	{
		if(window.document.frmCustomer.chkOffice.checked==true)
		{
			window.document.all.divOffice.style.display="block"
			window.document.all.divPerm.style.display="none"
			window.document.all.divOccupation.style.display="none"
			window.document.all.divFamily.style.display="none"
			window.document.all.divPersonal.style.display="none"
			window.document.all.divMail.style.display="none"
		}
		else
			window.document.all.divOffice.style.display="none"
	}
}

function EnableCtls()
{ 
with(window.document.frmCustomer)
{
	SetQueryReadonly(window.document.frmCustomer,txtEmail,txtCustname,txtFamName,txtFax,txtMArea,txtMBldg,txtMCity,txtMemId,
					txtMFlat,txtMobile,txtMPin,txtOArea,txtOBldg,txtOCity,txtOFlat,
					txtOPin,txtPArea,txtPBldg,txtPCity,txtPFlat,txtPhone1,txtPhone2,txtPhone3,
					txtPPin,chkMinor,chkFamily,chkMailing,chkMember,chkOccup,chkOffice,
					chkPerm,chkPersonal,cmbEducation,cmbIncome,cmbOccupation,cmbRelation)
}	
	window.document.frmCustomer.cmdCancel.disabled=false
	window.document.frmCustomer.cmdCustomer.disabled=false
	window.document.frmCustomer.cmdCustType.disabled=false
	window.document.frmCustomer.cmdFamOk.disabled=false
	window.document.frmCustomer.cmdlstBranch.disabled=false
	window.document.frmCustomer.cmdlstCurrency.disabled=false
	window.document.frmCustomer.cmdOk.disabled=false
	window.document.frmCustomer.optGender(0).disabled=false
	window.document.frmCustomer.optGender(1).disabled=false
	window.document.frmCustomer.optMarital(0).disabled=false
	window.document.frmCustomer.optMarital(1).disabled=false
}
function DisableCtls()
{
with(window.document.frmCustomer)
{
	SetQueryReadonly(window.document.frmCustomer,chkFamily,chkMailing,txtCustname,
					chkOccup,chkOffice,chkPerm,chkPersonal)
}
	window.document.frmCustomer.cmdCancel.disabled=false
	window.document.frmCustomer.cmdCustomer.disabled=false
	window.document.frmCustomer.cmdCustType.disabled=true
	window.document.frmCustomer.cmdFamOk.disabled=true
	window.document.frmCustomer.cmdlstBranch.disabled=false
	window.document.frmCustomer.cmdlstCurrency.disabled=false
	window.document.frmCustomer.cmdOk.disabled=false
	window.document.frmCustomer.optGender(0).disabled=true
	window.document.frmCustomer.optGender(1).disabled=true
	window.document.frmCustomer.optMarital(0).disabled=true
	window.document.frmCustomer.optMarital(1).disabled=true

}

function GetTypeCode()
{
	st="CustType|Cust"
	window.open("ListCustomer.asp" + "?"+"st="+st,"CustType","width=250%,height=150% left=200 top=260")
}

function dispOccCode(str)
{
	if (str!="No Data Found..")
	{
		str=str.split("-----")
		window.document.frmCustomer.txtCustType.value=str[1]
		window.document.frmCustomer.txtCustTypeDesc.value=str[0]
	}
}

function GetMode()
{
	Clear()
	if(window.document.frmCustomer.opttransmod(0).checked==true)
	{
		window.document.frmCustomer.cmdCustomer.style.visibility="hidden"
		EnableCtls()
		window.document.frmCustomer.txtCustname.disabled=true
		window.open("newcustomer.asp","Customer","width=340%,height=380% left=350 top=150")
	}
	else if(window.document.frmCustomer.opttransmod(1).checked==true)
	{
		window.document.frmCustomer.hidmode.value="Modify"
		window.document.frmCustomer.cmdCustomer.style.visibility="visible"
		EnableCtls()
		window.document.frmCustomer.txtCustname.disabled=false
		window.document.frmCustomer.txtCustid.readOnly=false
	}
	else if(window.document.frmCustomer.opttransmod(2).checked==true)
	{
		window.document.frmCustomer.hidmode.value="Delete"
		window.document.frmCustomer.cmdCustomer.style.visibility="visible"
		EnableCtls()
		DisableCtls()
		window.document.frmCustomer.txtCustname.disabled=true
	}
	else if(window.document.frmCustomer.opttransmod(3).checked==true)
	{
		window.document.frmCustomer.hidmode.value="View"
		window.document.frmCustomer.cmdCustomer.style.visibility="visible"
		EnableCtls()
		DisableCtls()
		window.document.frmCustomer.txtCustname.disabled=true
	}
	
}

function CheckVals()
{
if(window.document.frmCustomer.chkFamily.checked==true)
{
	if(window.document.frmCustomer.mfgPenal.TextMatrix(1,1).length<1)
		return "family"
	else
		return true
}
if(window.document.frmCustomer.chkOccup.checked ==true)
{
	val1=window.document.frmCustomer.cmbEducation.options[window.document.frmCustomer.cmbEducation.selectedIndex].value
	val2=window.document.frmCustomer.cmbIncome.options[window.document.frmCustomer.cmbIncome.selectedIndex].value
	val3=window.document.frmCustomer.cmbOccupation.options[window.document.frmCustomer.cmbOccupation.selectedIndex].value
	
	if((val1<1)&&(val2<1) &&(val3<1))
		return "Occupation"
	else
		return true
}
if(window.document.frmCustomer.chkPerm.checked==true)
{
	val1=window.document.frmCustomer.txtPArea.value.length
	val2=window.document.frmCustomer.txtPBldg.value.length
	val3=window.document.frmCustomer.txtPCity.value.length
	val4=window.document.frmCustomer.txtPFlat.value.length
	val5=window.document.frmCustomer.txtPPin.value.length
	val6=window.document.frmCustomer.txtPhone3.value.length
	if((val1<1)&&(val2<1) &&(val3<1)&&(val4<1) &&(val5<1)&&(val6<1))
		return "Perm"
	else
		return true
}
if(window.document.frmCustomer.chkOffice.checked==true)
{
	val1=window.document.frmCustomer.txtOArea.value.length
	val2=window.document.frmCustomer.txtOBldg.value.length
	val3=window.document.frmCustomer.txtOCity.value.length
	val4=window.document.frmCustomer.txtOFlat.value.length
	val5=window.document.frmCustomer.txtOPin.value.length
	val6=window.document.frmCustomer.txtPhone2.value.length
	if((val1<1)&&(val2<1) &&(val3<1)&&(val4<1) &&(val5<1)&&(val6<1))
		return "office"
	else
		return true
}
}
function Ok()
{
if((window.document.frmCustomer.chkPersonal.checked==false)||
(window.document.frmCustomer.chkMailing.checked==false))
{
	alert("Manditory Fields should not be null..")
	return
}
if((window.document.frmCustomer.txtBranchCode.value=="")||
	(window.document.frmCustomer.txtCurrencyCode.value=="")||
	(window.document.frmCustomer.txtCustname.value=="")||
	(window.document.frmCustomer.txtCustType.value=="")||
	(window.document.frmCustomer.txtMFlat.value==""))
{
	alert("Manditory Fields should not be null..")
	return
}


var result=CheckVals()
if(window.document.frmCustomer.hidmode.value!="Modify")
result=""
if(result=="Perm")
	{alert("Please Fill Permanent Address...")
	return}
else if(result=="office")
	{alert("Please Fill Office Address...")
	return}
else if(result=="Occupation")
	{alert("Please Fill Occupation Details...")
	return}
else if(result=="family")
	{alert("Please Fill Family Details...")
	return}
brcode="'" + window.document.frmCustomer.txtBranchCode.value +"'"
custname="'" +window.document.frmCustomer.txtCustname.value+ "'"
typeid=window.document.frmCustomer.txtCustType.value
if (isNaN(typeid)==true)
	typeid=0
if (window.document.frmCustomer.chkMember.checked==false)
	window.document.frmCustomer.txtMemId.value=""
	memid="'" +window.document.frmCustomer.txtMemId.value+"'"

dob="'" +window.document.frmCustomer.txtDob.value+"'"
mail="'" +window.document.frmCustomer.txtEmail.value+"'"
mobile="'" +window.document.frmCustomer.txtMobile.value+"'"
fax="'" +window.document.frmCustomer.txtFax.value +"'"
if(window.document.frmCustomer.chkMinor.checked==true)
	minor="'" +"Y"+"'"
else
	minor="'" +"N"+"'"
if(window.document.frmCustomer.optMarital(0).checked==true)
	marital="'" +"Y"+"'"
else
	marital="'" +"N"+"'"
if(window.document.frmCustomer.optGender(0).checked==true)
	gender="'" +"M"+"'"
else
	gender="'" +"F"+"'"
occup=window.document.frmCustomer.cmbOccupation.options[
		window.document.frmCustomer.cmbOccupation.selectedIndex].value	
qual=window.document.frmCustomer.cmbEducation.options[
		window.document.frmCustomer.cmbEducation.selectedIndex].value
income=window.document.frmCustomer.cmbIncome.options[
		window.document.frmCustomer.cmbIncome.selectedIndex].value
phone1="'" +window.document.frmCustomer.txtPhone1.value+"'"
phone2="'" +window.document.frmCustomer.txtPhone2.value+"'"
phone3="'" +window.document.frmCustomer.txtPhone3.value+"'"

mail1="'" +window.document.frmCustomer.txtMFlat.value+"'"
mail2="'" +window.document.frmCustomer.txtMBldg.value+"'"
mail3="'" +window.document.frmCustomer.txtMArea.value +"'"
mail4="'" +window.document.frmCustomer.txtMCity.value+"'"
mail5="'" +window.document.frmCustomer.txtMPin.value +"'"

perm1="'" +window.document.frmCustomer.txtPFlat.value+"'"
perm2="'" +window.document.frmCustomer.txtPBldg.value+"'"
perm3="'" +window.document.frmCustomer.txtPArea.value +"'"
perm4="'" +window.document.frmCustomer.txtPCity.value+"'"
perm5="'" +window.document.frmCustomer.txtPPin.value +"'"

off1="'" +window.document.frmCustomer.txtOFlat.value+"'"
off2="'" +window.document.frmCustomer.txtOBldg.value+"'"
off3="'" +window.document.frmCustomer.txtOArea.value +"'"
off4="'" +window.document.frmCustomer.txtOCity.value+"'"
off5="'" +window.document.frmCustomer.txtOPin.value +"'"
if(window.document.frmCustomer.hidmode=="New")
	sep=","
else
	sep="~"
var dbvalues=brcode+ sep +custname+sep+typeid+sep+memid+sep+dob+sep+mail+sep+fax+sep+
			mobile+sep+minor+sep+marital+sep+gender+sep+occup+sep+qual+sep+
			income+sep+phone1+sep+phone2+sep+phone3+sep+mail1+sep+mail2+sep+
			mail3+sep+mail4+sep+mail5+sep+perm1+sep+perm2+sep+perm3+sep+
			perm4+sep+perm5+sep+off1+sep+off2+sep+off3+sep+off4+sep+off5
var famdtls=""
if(window.document.frmCustomer.chkFamily.checked==true)
{
for(i=1;i<window.document.frmCustomer.mfgPenal.Rows;i++)
{
	fname="'" +window.document.frmCustomer.mfgPenal.TextMatrix(i,1) +"'"
	fdob="'" +window.document.frmCustomer.mfgPenal.TextMatrix(i,2)+"'"
	frel="'" +window.document.frmCustomer.mfgPenal.TextMatrix(i,3)+"'"
	famdtls=famdtls + "#" +brcode+","+fname+","+fdob+","+frel
}
}
if(window.document.frmCustomer.hidmode.value=="Delete")
{
dbvalues=""
famdtls=""
}
if (window.document.frmCustomer.hidmode.value!="View")
{
window.document.frmCustomer.hidcustvals.value=dbvalues
window.document.frmCustomer.hidfamvals.value =famdtls

window.document.frmCustomer.txtCustid.disabled=false 
window.document.frmCustomer.action="customerinsert.asp"
window.document.frmCustomer.method="post"
window.document.frmCustomer.submit()
}
}

function Clear()
{
splitString("window.document.frmCustomer","txtCustType,txtCustTypeDesc,txtCustid,txtCustname,txtDob,txtEmail,txtFamName,txtFamDob,txtFax,txtMArea,txtMBldg,txtMCity,txtMemId," +
					"txtMFlat,txtMobile,txtMPin,txtOArea,txtOBldg,txtOCity,txtOFlat," +
					"txtOPin,txtPArea,txtPBldg,txtPCity,txtPFlat,txtPhone1,txtPhone2,txtPhone3," +
					"txtPPin")
				

window.document.frmCustomer.mfgPenal.Rows=2
window.document.frmCustomer.mfgPenal.TextMatrix(1,0)=""
window.document.frmCustomer.mfgPenal.TextMatrix(1,1)=""
window.document.frmCustomer.mfgPenal.TextMatrix(1,2)=""
window.document.frmCustomer.mfgPenal.TextMatrix(1,3)=""
window.document.frmCustomer.chkMinor.checked=false
window.document.all.spMember.style.visibility="hidden"
window.document.frmCustomer.chkFamily.checked=false
window.document.frmCustomer.chkMailing.checked=false
window.document.frmCustomer.chkMinor.checked=false
window.document.frmCustomer.chkOccup.checked=false
window.document.frmCustomer.chkOffice.checked=false
window.document.frmCustomer.chkPerm.checked=false
window.document.frmCustomer.cmbEducation.options[0].selected=true
window.document.frmCustomer.cmbIncome.options[0].selected=true
window.document.frmCustomer.cmbOccupation.options[0].selected=true
window.document.frmCustomer.cmbRelation.options[0].selected=true
window.document.frmCustomer.optGender(0).checked=false
window.document.frmCustomer.optGender(1).checked=false
window.document.frmCustomer.optMarital(0).checked=false
window.document.frmCustomer.optMarital(1).checked=false
}

function Cancel()
{
location.reload() 
}

function GetDateDif(str,str1)
{
if (eval(str)>0)
{
	alert("DOB should not be greater than application date..")
	if(str1.length==4)
		window.document.frmCustomer.txtDob.value=""
	if(str1.length==3)
		window.document.frmCustomer.txtFamDob.value=""
	
}
}





//-->
</SCRIPT>


<body topmargin="0" leftmargin="0" onload="GetNewcust();GetMenu(&quot;<%=session("menustring")%>&quot;)">

<form name="frmCustomer">
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <td width="100%" height="28"></td>
    </tr>
  </table>

  <table border="0" width="100%" height="25" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <td width="34%"></td>
      <td width="33%">
      <p align="center"><font class="text">Customer</font></p>
      </td>
      <td width="33%" align="right"><font class="textwhite"><%=appdate%></font></td>
    </tr>
  </table>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="150%" height="15">
      <p align="center"><font class="textblue"><%=Request.QueryString("record")%></p>
      </font></td>
    </tr>
    <tr>
      <td width="100%" align="middle">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="15"></td>
        </tr>
      </table>

      <table width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td>
          <div align="center">
            <center>

            <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tbody>
                <tr>
                  <td width="100%">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr class="bgcolor">
                      <td width="106">
                      <p align="right"><font class="textbold">Branch Code&nbsp;</p>
                      </font></td>
                      <td width="249" class="bottombg"><input name="txtBranchCode" size="9" readonly maxlength="10" value="9999" style="TEXT-TRANSFORM: uppercase"><input type="button" value=" L " name="cmdlstBranch" onclick="GetBranch()"><input name="txtBranchDesc" size="16" readonly disabled maxlength="30" value="MAIN BRANCH" style="TEXT-TRANSFORM: uppercase"></td>
                      <td align="right" width="131"><font class="textbold">Currency
                      Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                      <td width="242"><input name="txtCurrencyCode" size="9" readonly maxlength="4" value="INR" style="TEXT-TRANSFORM: uppercase"><input type="button" value=" L " name="cmdlstCurrency" onclick="GetCurrency()"><input name="txtCurrrencyDesc" size="16" readonly disabled maxlength="30" value="INDIAN RUPEE" style="TEXT-TRANSFORM: uppercase"></td>
                    </tr>
                  </table>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
                    <tr class="bgcolor1">
                      <td width="23%" align="middle"><font class="textwhite"><input type="radio" name="opttransmod" onclick="GetMode()">
                      New</font>
                      <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="opttransmod" onclick="GetMode()">
                      Modify</font></td>
                      <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="opttransmod" onclick="GetMode()">
                      Delete</font></td>
                      <td width="25%" align="middle"><font class="textwhite"><input type="radio" name="opttransmod" onclick="GetMode()">
                      View</font></td>
                    </tr>
                  </table>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%" height="10"></td>
                    </tr>
                  </table>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%" height="10">
                      <div align="center">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="14%" height="10">&nbsp;Cust. ID</td>
                            <td width="42%" height="10"><input type="text" name="txtCustid" size="17" maxlength="17" readonly onblur="Getcustomerid()"><input type="button" value=" L " name="cmdCustomer" style="visibility:hidden" onclick="GetCustomer()"></td>
                            <td width="13%" height="10">Name</td>
                            <td width="31%" height="10" colspan="3"><input type="text" name="txtCustname" size="25" maxlength="50" style="text-transform:Capitalize" onkeypress="Alphanum()"></td>
                          </tr>
                          <tr>
                            <td width="14%" height="10">&nbsp;Cust. Type</td>
                            <td width="42%" height="10"><input type="text" name="txtCustType" size="4" maxlength="2" readonly><input type="button" value=" L " name="cmdCustType" onclick="GetTypeCode()"><input type="text" name="txtCustTypeDesc" size="26" maxlength="20" readonly style="text-transform:Capitalize"></td>
                            <td width="13%" height="10">Member</td>
                            <td width="3%" height="10"><input type="checkbox" name="chkMember" value="ON" onclick="DisplayMember()"></td>
                          </center></center>
                        <td width="26%" height="10"><center><span id="spMember" style="visibility:hidden">
                        <p align="right">Member ID&nbsp; <input type="text" name="txtMemId" size="10" maxlength="10" style="text-transform:Capitalize" onkeypress="Alphanum()"></span></center></td>
                        </tr>
                        <tr>
                          <td width="14%" height="10">&nbsp;</td>
                          <td width="42%" height="10"></td>
                          <td width="13%" height="5"></td>
                          <td width="3%" height="10"></td>
                          <td width="12%" height="10"></td>
                          <td width="16%" height="10"></td>
                        </tr>
                      </table>

                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
                      <tr class="bgcolor">
                        <td width="16%" align="center" height="20"><input type="checkbox" name="chkPersonal" value="ON" onclick="DispDivision(&quot;1&quot;)"><font class="textbold">
                        Personal Details</font></td>
                        <td width="15%" align="center" height="20"><input type="checkbox" name="chkFamily" value="ON" onclick="DispDivision(&quot;2&quot;)"><font class="textbold">
                        Family Details</font></td>
                        <td width="18%" align="center" height="20"><input type="checkbox" name="chkOccup" value="ON" onclick="DispDivision(&quot;3&quot;)"><font class="textbold">
                        Occupation Dtls</font></td>
                        <td width="16%" align="center" height="20"><input type="checkbox" name="chkMailing" value="ON" onclick="DispDivision(&quot;4&quot;)"><font class="textbold">
                        Mailing Address</font></td>
                        <td width="17%" align="center" height="20"><input type="checkbox" name="chkOffice" value="ON" onclick="DispDivision(&quot;5&quot;)"><font class="textbold">
                        Office Address</font></td>
                        <td width="18%" align="center" height="20"><input type="checkbox" name="chkPerm" value="ON" onclick="DispDivision(&quot;6&quot;)"><font class="textbold">Permanent
                        Address</font></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divPersonal" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="8" height="15"><font class="subheading">&nbsp;Personal
                                Details</font></td>
                              </tr>
                              <tr>
                                <td width="12%">&nbsp;DOB</td>
                                <td width="8%"><input type="text" name="txtDob" size="11" readonly></td>
                                <td width="10%">
                                <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="28" id="dtpDob" name="dtpDob" style="LEFT: 0px; TOP: 0px" width="41">
                                  <param name="_ExtentX" value="1085">
                                  <param name="_ExtentY" value="741">
                                  <param name="_Version" value="393216">
                                  <param name="MousePointer" value="0">
                                  <param name="Enabled" value="1">
                                  <param name="OLEDropMode" value="0">
                                  <param name="CalendarBackColor" value="-2147483643">
                                  <param name="CalendarForeColor" value="-2147483630">
                                  <param name="CalendarTitleBackColor" value="-2147483633">
                                  <param name="CalendarTitleForeColor" value="-2147483630">
                                  <param name="CalendarTrailingForeColor" value="-2147483631">
                                  <param name="CheckBox" value="1">
                                  <param name="CustomFormat" value="dd-MMM-yyyy">
                                  <param name="DateIsNull" value="0">
                                  <param name="Format" value="662831107">
                                  <param name="UpDown" value="0">
                                  <param name="CurrentDate" value="36895">
                                  <param name="MaxDate" value="2958465">
                                  <param name="MinDate" value="-109205">
                                </object>
                                </td>
                                <td width="10%">Minor (Y/N)</td>
                                <td width="10%">&nbsp;<input type="checkbox" name="chkMinor" value="ON" onclick="SetMinor()"></td>
                                <td width="11%">Marital Status</td>
                              </center>
                              <td width="13%">
                              <p align="right"><input type="radio" name="optMarital" value="V1">
                              Married&nbsp;&nbsp;&nbsp;</p>
                              </td>
                              <center>
                              <td width="27%"><input type="radio" name="optMarital" value="V2">
                              Single</td>
                              </tr>
                              <tr>
                                <td width="12%" height="13">&nbsp;EMail ID</td>
                                <td width="38%" colspan="4" height="13"><input type="text" name="txtEmail" onblur="TrimSpace(window.document.frmCustomer.txtEmail)" size="33" maxlength="30" onblur="Checksymbols()" onkeypress="chkmailchar()"></td>
                                <td width="11%" height="13">Gender</td>
                              </center>
                              <td width="13%" height="13">
                              <p align="right"><input type="radio" name="optGender" value="V3">
                              MaIe&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                              </td>
                              <center>
                              <td width="27%" height="13"><input type="radio" name="optGender" value="V4">
                              Female</td>
                              </tr>
                              <tr>
                                <td width="12%" height="25">&nbsp;Mobile No</td>
                                <td width="13%" height="25"><input type="text" name="txtMobile" size="11" maxlength="15" onkeypress="phonenumeric()"></td>
                                <td width="25%" height="25" colspan="3"></td>
                                <td width="11%" height="25">Fax No</td>
                                <td width="40%" height="25" colspan="2"><input type="text" name="txtFax" size="11" maxlength="10" onkeypress="phonenumeric()"></td>
                              </tr>
                              <tr>
                                <td width="12%" height="10"></td>
                                <td width="13%" height="10"></td>
                                <td width="25%" height="10" colspan="3"></td>
                                <td width="11%" height="10"></td>
                                <td width="40%" height="10" colspan="2"></td>
                              </tr>
                            </table>

                            </center></td>
                        </tr>
                        </table>

                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divFamily" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="210">
                              <tr class="bgcolor">
                                <td width="100%" colspan="7" height="18"><font class="subheading">&nbsp;Family
                                Details</font></td>
                              </tr>
                              <tr>
                                <td width="12%" height="24">&nbsp;Name</td>
                                <td width="22%" height="24"><input type="text" name="txtFamName" onkeypress="Alphanum()" style="text-transform:Capitalize" size="20" maxlength="50"></td>
                              </center>
                              <td width="14%" height="24">
                              <p align="center">Relation</p>
                              </td>
                              <center>
                              <td width="11%" height="24"><select size="1" name="cmbRelation">
                                <option value="0">&nbsp;&nbsp;</option>
                                <% if not rs3.EOF and not rs3.BOF then 
								do while not rs3.EOF %>
                                  
                                <option value="<%=rs3(0)%>"><%=rs3(1)%></option>
								<%rs3.MoveNext 
								loop
								end if%>
                              
                              </select></td>
                              <td width="18%" height="24">
                              <p align="right">DOB&nbsp;&nbsp;</td>
                              </center><center>
                              <td width="13%" height="24"><input type="text" name="txtFamDob" size="11" readonly></td>
                              <td width="14%" height="24">
                              <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="28" id="dtpFamDob" name="dtpFamDob" style="LEFT: 0px; TOP: 0px" width="41">
                                <param name="_ExtentX" value="1085">
                                <param name="_ExtentY" value="741">
                                <param name="_Version" value="393216">
                                <param name="MousePointer" value="0">
                                <param name="Enabled" value="1">
                                <param name="OLEDropMode" value="0">
                                <param name="CalendarBackColor" value="-2147483643">
                                <param name="CalendarForeColor" value="-2147483630">
                                <param name="CalendarTitleBackColor" value="-2147483633">
                                <param name="CalendarTitleForeColor" value="-2147483630">
                                <param name="CalendarTrailingForeColor" value="-2147483631">
                                <param name="CheckBox" value="1">
                                <param name="CustomFormat" value="dd-MMM-yyyy">
                                <param name="DateIsNull" value="0">
                                <param name="Format" value="662831107">
                                <param name="UpDown" value="0">
                                <param name="CurrentDate" value="36895">
                                <param name="MaxDate" value="2958465">
                                <param name="MinDate" value="-109205">
                              </object>
                              </td>
                              </tr>
                              <tr>
                                <td width="100%" colspan="7" height="18"></td>
                              </tr>
                              <tr>
                                <td width="100%" colspan="7" height="33">
                                <div align="center">
                                  <center>

                                  <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                                    <tr>
                                      <td width="100%"><input type="button" value="   Ok   " name="cmdFamOk" class="bgcolor" onclick="AddtoGrid()"></td>
                                    </tr>
                                  </table>

                                  </center>
                                </div>
                                </td>
                              </tr>
                              <tr>
                                <td width="100%" colspan="7" height="99">
                                <p align="center">
                                <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="87" id="mfgPenal" name="mfgFamilyDtls" style="LEFT: 80px; TOP: 0px" width="487">
                                  <param name="_ExtentX" value="12885">
                                  <param name="_ExtentY" value="2302">
                                  <param name="_Version" value="393216">
                                  <param name="Rows" value="2">
                                  <param name="Cols" value="4">
                                  <param name="FixedRows" value="1">
                                  <param name="FixedCols" value="0">
                                  <param name="RowHeightMin" value="0">
                                  <param name="BackColor" value="-2147483643">
                                  <param name="ForeColor" value="-2147483640">
                                  <param name="BackColorFixed" value="-2147483633">
                                  <param name="ForeColorFixed" value="-2147483630">
                                  <param name="BackColorSel" value="-2147483635">
                                  <param name="ForeColorSel" value="-2147483634">
                                  <param name="BackColorBkg" value="8421504">
                                  <param name="GridColor" value="12632256">
                                  <param name="GridColorFixed" value="0">
                                  <param name="WordWrap" value="0">
                                  <param name="Redraw" value="-1">
                                  <param name="AllowBigSelection" value="-1">
                                  <param name="ScrollTrack" value="0">
                                  <param name="Enabled" value="-1">
                                  <param name="RightToLeft" value="0">
                                  <param name="TextStyle" value="0">
                                  <param name="TextStyleFixed" value="0">
                                  <param name="FocusRect" value="1">
                                  <param name="HighLight" value="1">
                                  <param name="FillStyle" value="0">
                                  <param name="GridLines" value="1">
                                  <param name="GridLinesFixed" value="2">
                                  <param name="ScrollBars" value="3">
                                  <param name="SelectionMode" value="0">
                                  <param name="MergeCells" value="0">
                                  <param name="AllowUserResizing" value="0">
                                  <param name="PictureType" value="0">
                                  <param name="BorderStyle" value="1">
                                  <param name="Appearance" value="1">
                                  <param name="MousePointer" value="0">
                                  <param name="GridLineWidth" value="1">
                                  <param name="FormatString" value="S no |                        Name                   |        DOB           |&gt;         Relation   ">
                                  <param name="OLEDropMode" value="0">
                                </object>
                                </td>
                              </tr>
                              <tr>
                                <td width="100%" colspan="7" height="18"></td>
                              </tr>
                            </table>

                            </center></td>
                        </tr>
                        </table>

                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divOccupation" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="4"><font class="subheading">&nbsp;Occupation
                                Details</font></td>
                              </tr>
                              <tr>
                                <td width="28%">&nbsp;Occupation</td>
                                <td width="24%"><select size="1" name="cmbOccupation">
                                  <option value="0">&nbsp;&nbsp;</option>
                                  <% if not rs.EOF and not rs.BOF then 
								do while not rs.EOF %>
                                  
                                  <option value="<%=rs(0)%>"><%=rs(1)%></option>
								  <%rs.MoveNext 
								loop
								end if%>
                                </select></td>
                                <td width="14%">Education</td>
                                <td width="34%"><select size="1" name="cmbEducation">
                                  <option value="0">&nbsp;&nbsp;</option>
                                  <% if not rs1.EOF and not rs1.BOF then 
								do while not rs1.EOF %>
                                  
                                  <option value="<%=rs1(0)%>"><%=rs1(1)%></option>
								  <%rs1.MoveNext 
								loop
								
								end if%>
                                </select></td>
                              </tr>
                              <tr>
                                <td width="28%">&nbsp;Monthly Household Income(Rs.)</td>
                                <td width="24%"><select size="1" name="cmbIncome">
                                  <option value="0">&nbsp;&nbsp;</option>
                                  <% if not rs2.EOF and not rs2.BOF then 
								do while not rs2.EOF %>
                                  
                                  <option value="<%=rs2(0)%>"><%=rs2(1)%></option>
								  <%rs2.MoveNext 
								loop
								
								end if%>
                                
                                </select></td>
                                <td width="14%"></td>
                                <td width="34%"></td>
                              </tr>
                              <tr>
                                <td width="28%" height="10"></td>
                                <td width="24%" height="10"></td>
                                <td width="14%" height="10"></td>
                                <td width="34%" height="10"></td>
                              </tr>
                            </table>

                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divMail" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="4"><font class="subheading">&nbsp;Mailing
                                Address</font></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Flat/Plot No.</td>
                                <td width="38%"><input type="text" name="txtMFlat" onkeypress="Alphanum()" style="text-transform:Capitalize" size="20" maxlength="30"></td>
                                <td width="14%">Bldg./Society</td>
                                <td width="34%"><input type="text" name="txtMBldg" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Area/Locality</td>
                                <td width="38%"><input type="text" name="txtMArea" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                                <td width="14%">City/Village</td>
                                <td width="34%"><input type="text" name="txtMCity" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Pin Code</td>
                                <td width="38%"><input type="text" name="txtMPin" size="10" maxlength="6" onkeypress="numeric()"></td>
                                <td width="14%">Phone No.</td>
                                <td width="34%"><input type="text" name="txtPhone1" size="10" maxlength="10" onkeypress="phonenumeric()"></td>
                              </tr>
                            </table>

                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divPerm" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="4"><font class="subheading">&nbsp;Permanent
                                Address</font></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Flat/Plot No.</td>
                                <td width="38%"><input type="text" name="txtPFlat" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                                <td width="14%">Bldg./Society</td>
                                <td width="34%"><input type="text" name="txtPBldg" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Area/Locality</td>
                                <td width="38%"><input type="text" name="txtPArea" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                                <td width="14%">City/Village</td>
                                <td width="34%"><input type="text" name="txtPCity" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Pin Code</td>
                                <td width="38%"><input type="text" name="txtPPin" size="10" maxlength="6" onkeypress="numeric()"></td>
                                <td width="14%">Phone No.</td>
                                <td width="34%"><input type="text" name="txtPhone2" size="10" maxlength="10" onkeypress="phonenumeric()"></td>
                              </tr>
                            </table>

                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div>
                      <div align="center" id="divOffice" style="display:none">
                        <center>

                        <table border="0" width="96%" cellspacing="0" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr class="bgcolor">
                                <td width="100%" colspan="4"><font class="subheading">&nbsp;Office
                                Address</font></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Company</td>
                                <td width="38%"><input type="text" name="txtOFlat" onkeypress="Alphanum()" style="text-transform:Capitalize" size="20" maxlength="30"></td>
                                <td width="14%">Bldg./Society</td>
                                <td width="34%"><input type="text" name="txtOBldg" onkeypress="Alphanum()" style="text-transform:Capitalize" size="20" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Area/Locality</td>
                                <td width="38%"><input type="text" name="txtOArea" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                                <td width="14%">City/Village</td>
                                <td width="34%"><input type="text" name="txtOCity" size="20" onkeypress="Alphanum()" style="text-transform:Capitalize" maxlength="30"></td>
                              </tr>
                              <tr>
                                <td width="14%">&nbsp;Pin Code</td>
                                <td width="38%"><input type="text" name="txtOPin" size="10" maxlength="6" onkeypress="numeric()"></td>
                                <td width="14%">Phone No.</td>
                                <td width="34%"><input type="text" name="txtPhone3" size="10" maxlength="10" onkeypress="phonenumeric()"></td>
                              </tr>
                            </table>

                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                  </table>

                </td>
              </tr>
            </table>

          </div>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="52">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="5"></td>
            </tr>
          </table>

          <div align="center">
            <center>

            <table width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="   Ok   " name="cmdOk" class="bgcolor" onclick="Ok()"><input type="button" value="Cancel" name="cmdCancel" onclick="location.href=&quot;customer.asp&quot;" class="bgcolor"><input type="button" value="  Exit  " name="cmdExit" class="bgcolor" onclick="window.close()"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" height="5"></td>
        </tr>
      </table>

      </td>
  </table>

  <input type="hidden" name="hidmode" value="New"><input type="hidden" name="hidcustvals" value><input type="hidden" name="hidfamvals" value><input type="hidden" name="hidch" value>
</form>

</body>

</html>
