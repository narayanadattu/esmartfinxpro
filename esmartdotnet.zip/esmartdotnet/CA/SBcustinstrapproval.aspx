<%@ Page CodeBehind="SBcustinstrapproval.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBcustinstrapproval" %>
<%
dim instr,str,trans,insdesc,inscd
	str=Request.QueryString("result")
if len(str)> 0 then
	instr=split(str,"~!~")
	trans=instr(0)
	inscd=instr(1)
	insdesc=instr(2)
	insmodid=instr(3)
	insmoddesc=instr(4)
end if
%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript		src="<%="http://" & session("moduledir")& "/proc.js"%>"> 
</SCRIPT>
<SCRIPT LANGUAGE=javascript		src="<%="http://" & session("moduledir")& "/val.js"%>"> 
</SCRIPT>
<script language="JavaScript"	src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" >
</script>
<script language="JavaScript"	src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" >
</script>
<script language="JavaScript"	src="<%="http://" & session("moduledir")& "/navbar.js"%>" >
</script>
<SCRIPT LANGUAGE=javascript>
<!--
//To Get Branchcode
function branch(){

	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,st,
		"width=200%,height=150%,left=140%,top=210%")
}	
function Branchcode(str){

	assign(str,window.document.frmcuststockapp.txtbranchdesc,
		window.document.frmcuststockapp.txtbranchcode)
	//clear()
}

//To get Instrumentcode

function instrument(){

	st="Instrument"
	window.open("Listquery.asp" + "?" +"st="+st,st,
		"width=200%,height=150%,left=140%,top=210%")
}
//To get Currency
function Currency()
{
	st="Currency"	
	window.open("Listquery.asp" + "?"+"st="+st,"currency",
		"width=200%,height=150% left=550 top=215")
}

function Currencyid(str)
{
	assign(str,window.document.frmcuststockapp.txtcurrencydesc,
		window.document.frmcuststockapp.txtcurrencycode)      
	
	window.document.frmcuststockapp.txtmodulecode.value=""
	window.document.frmcuststockapp.txtmoduledesc.value=""
	window.document.frmcuststockapp.txtinstrcode.value=""
	window.document.frmcuststockapp.txtinstrdesc.value=""
	window.document.frames(0).frminsapp.mfgins.rows=1
	window.document.frmcuststockapp.txtaccdesc.value=""
	window.document.frmcuststockapp.txtaccno.value=""
	window.document.frmcuststockapp.txtendchqno.value=""
	window.document.frmcuststockapp.txtlserno.value=""
	window.document.frmcuststockapp.txtlstchqno.value=""
	window.document.frmcuststockapp.txtnol.value=""
	window.document.frmcuststockapp.txtnoleavesperbook.value=""
	window.document.frmcuststockapp.txtstchqno.value=""
	window.document.frmcuststockapp.txtserno.value=""
	
	

}
//To get Moduleid.
function module()
{
		st1="custinsmodule"
		st2=window.document.frmcuststockapp.txtbranchcode.value
		sy="|"
		st=st1+sy+st2
		window.open("Listquery.asp" + "?" +"st="+st,"Module",
			"width=200%,height=150%,left=140%,top=210%")
}
function custmodcode(str)
{
       assign(str,window.document.frmcuststockapp.txtmoduledesc,
			window.document.frmcuststockapp.txtmodulecode)
	window.document.frmcuststockapp.txtinstrcode.value=""
	window.document.frmcuststockapp.txtinstrdesc.value=""
	window.document.frames(0).frminsapp.mfgins.rows=1
	window.document.frmcuststockapp.txtaccdesc.value=""
	window.document.frmcuststockapp.txtaccno.value=""
	window.document.frmcuststockapp.txtendchqno.value=""
	window.document.frmcuststockapp.txtlserno.value=""
	window.document.frmcuststockapp.txtlstchqno.value=""
	window.document.frmcuststockapp.txtnol.value=""
	window.document.frmcuststockapp.txtnoleavesperbook.value=""
	window.document.frmcuststockapp.txtstchqno.value=""
	window.document.frmcuststockapp.txtserno.value=""
}
function Display(){

	window.document.all.divleaf.style.display="none"
	window.document.all.divbook.style.display="block"
}
function instrcode(str){
	
	assign(str,window.document.frmcuststockapp.txtinstrdesc,
			window.document.frmcuststockapp.txtinstrcode)
	
	window.document.frmcuststockapp.txtaccdesc.value=""
	window.document.frmcuststockapp.txtaccno.value=""
	window.document.frmcuststockapp.txtendchqno.value=""
	window.document.frmcuststockapp.txtlserno.value=""
	window.document.frmcuststockapp.txtlstchqno.value=""
	window.document.frmcuststockapp.txtnol.value=""
	window.document.frmcuststockapp.txtnoleavesperbook.value=""
	window.document.frmcuststockapp.txtstchqno.value=""
	window.document.frmcuststockapp.txtserno.value=""
	Insrment()
}
	
// TO Approve all Instruments.
function Approveall()
{
var irows,irow,strrow
var jcols,jcol,strflex
strrow=""
strflex=""
irows=window.document.frames(0).frminsapp.mfgins.rows
for(irow=0;irow<irows-1;irow++)
{
	for(jcol=0;jcol<10;jcol++)
	{
		strflex=strflex+"~!~"+
			window.document.frames(0).frminsapp.mfgins.TextMatrix(irow+1,jcol)
	}
	strrow=strrow+"*|*"+strflex
	strflex=""
}	
if(eval(irows)>1)
{
	window.document.frmcuststockapp.hidstatus.value="APPROVEALL"
	window.document.frmcuststockapp.hidflex.value=strrow
	window.document.frmcuststockapp.action="SBcustinstrapprovalinsert.asp"
	window.document.frmcuststockapp.method="post"
	window.document.frmcuststockapp.submit();
}
}

//To store textbox values into variables
function store()
{
	brcode=window.document.frmcuststockapp.txtbranchcode.value	
	inscd=window.document.frmcuststockapp.txtinstrcode.value
	esno=window.document.frmcuststockapp.txtendchqno.value
	nlpb=window.document.frmcuststockapp.txtnoleavesperbook.value
	serno=window.document.frmcuststockapp.txtserno.value
	ssno=window.document.frmcuststockapp.txtstchqno.value
	modid=window.document.frmcuststockapp.txtmodulecode.value
	//uid=window.document.frmcuststockapptxtuserid.value
	leno=window.document.frmcuststockapp.txtlendchqno.value
	lserno=window.document.frmcuststockapp.txtlserno.value
	lsno=window.document.frmcuststockapp.txtlstchqno.value
}
//To Get Instruments details.
function Insrment()
{
	brcode=window.document.frmcuststockapp.txtbranchcode.value
	inscode=window.document.frmcuststockapp.txtinstrcode.value
	modid=window.document.frmcuststockapp.txtmodulecode.value
	
	if(brcode && inscode && modid)
	{
	window.document.frames(0).frminsapp.hidinstr.value=brcode+"~"+inscode+"~"+modid
	window.document.frames(0).frminsapp.method="post"
	window.document.frames(0).frminsapp.action="SBcustinstrumentdtls.asp"
	window.document.frames(0).frminsapp.submit();
	}

}

// To Approve  Instrument.

function Approveorrej(){
var brcode,inscd,esno,nlpb,serno,ssno
store()
if(window.document.frmcuststockapp.Radtype(0).checked==true)
{	
 if(brcode!="" && modid!="" && inscd!="" && serno!=""
	&& esno!="" && nlpb!="" && ssno!="")
 {
	
	window.document.frmcuststockapp.action="SBcustinstrapprovalinsert.asp"
	window.document.frmcuststockapp.method="post"
	window.document.frmcuststockapp.submit();
  }
  else
  {
	alert('Fields Should not be Null.')
  }
 }
 else if(window.document.frmcuststockapp.Radtype(1).checked==true)
 {

	if(brcode!="" && inscd!="" && modid!="" && leno!=""&& lserno!=""&& lsno!="")
	{
		window.document.frmcuststockapp.action="SBcustinstrapprovalinsert.asp"
		window.document.frmcuststockapp.method="post"
		window.document.frmcuststockapp.submit();
	}
	else
	{
		alert('Fields Should not be Null.')
	}
}
}

//To Get Instruments Details when form loads.
function Instrdet(){

	Insrment()
}

//To Approve the Instrument
function Approve(){

	window.document.frmcuststockapp.hidstatus.value="APPROVE"
	Approveorrej()
}
//To Reject the Instrument
function Reject(){

	window.document.frmcuststockapp.hidstatus.value="REJECT"
	Approveorrej()

}	
//-->
</SCRIPT>

<title>Cash Transfer</title>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display();Insrment()">

<form name="frmcuststockapp">

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr class="bgcolor">
      <td width="100%" nowrap height="28" colspan="3" align="left">
      <p>&nbsp;<img border="0" height="22" name="placeholder" src="transparent.gif" width="1"></p>
      </td>
    </tr>
    <tr class="bgcolor">
      <td width="34%" nowrap height="25">
      <p align="center">
      </td>
      <td width="33%" nowrap align="center" height="25">
      <font class="text">Customer
      Instrument Approval</font>
      </td>
      <td width="33%" nowrap height="25">
      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" height="15" align=center><%=trans%></td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
        <TBODY>
          <tr class="bgcolor">
            <td width="15%">
            <p align="right"><font class="textbold">&nbsp;Branch
            Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</font></p>
            </td>
            <td width="32%"><font size="2" face="MS Sans Serif"><input name="txtbranchcode" size="9" value="<%=session("branchcode")%>"></font><input type="button" value=" L " name="butbr" onclick="branch()"><font size="2" face="MS Sans Serif"><input name="txtbranchdesc" size="16"  value="<%=session("branchnarration")%>"></font></td>
            <td width="15%">
            <p align="right"><font class="textbold">&nbsp;&nbsp;Currency
            Code&nbsp;&nbsp;&nbsp;</font></p>
            </td>
            <td width="38%"><input name="txtcurrencycode" size="9" value="<%=session("currencycode")%>"><input type="button" value=" L " name="butcurrency" onclick="Currency()"><input name="txtcurrencydesc" size="16" value="<%=session("currencynarration")%>"></td>
          </tr>
          <tr>
            <td width="15%">Module
              ID&nbsp;&nbsp;&nbsp;</td>
            <td width="32%"><input name="txtmodulecode" value="<%=insmodid%>" size="9"><input type="button" value=" L " name="butmod" onclick="module()"><input name="txtmoduledesc" size="16" value="<%=insmoddesc%>"></td>
            <td width="15%">&nbsp;&nbsp; Instrument
            Code</font></td>
            <td width="32%"><font size="2" face="MS Sans Serif"><input name="txtinstrcode" size="9" value="<%=inscd%>"></font><input type="button" value=" L " name="butinstr" onclick="instrument()"><font size="2" face="MS Sans Serif"><input name="txtinstrdesc" size="16" value="<%=insdesc%>"></font></td>
          </tr>
          <center>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">

              <table border="0" width="80%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%"><iframe id=den align=center             
                        frameborder=0 framespacing=0 noresize 
                        height=143 width=650 scrolling=yes
		                valign="top" src="SBcustinstrumentdtls.asp" 
                        style="BACKGROUND-COLOR: darkred; HEIGHT: 143px; WIDTH: 650px"></iframe></td>
                </tr>
              </table>

            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
          </CENTER>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
              <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="100%"><input type="button" value="Approve All" name="butappall" onclick='Approveall()' class="bgcolor"></td>
                </tr>
              </table>
              </center>
            </div>
            </td>
          </tr>
          <center>
          <tr>
            <td width="100%" colspan="4">
            <p align="center"></p>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="16%"></td>
                <CENTER></CENTER>
              <td width="26%">
              <p align="right">Account
              Number&nbsp;&nbsp; </p></td>
              <center>
              <td width="58%"><input name="txtaccno" size="9" ><input type="button" value=" L " name="butaccount" class="bgcolor"><input name="txtaccdesc" size="16" ></td></tr>
              <tr class="bgcolor1">
                <td width="16%"><font class="textwhite">&nbsp;<input type="radio" value="BOOK" name="Radtype" onclick="">
                Book</font></td>
                <td width="84%" colspan="2"><font class="textwhite"><input type="radio" value="LEAF" checked name="Radtype">
                Leaf</font></td>
              </tr></table>
              </center></td>
              </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
              <div id="divbook">

                <table border="0" width="98%" class="tableborder2" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr class="bgcolor">
                        <td width="100%" colspan="6"><font class="subheading">&nbsp;Available
                        Book Details</font></td>
                      </tr>
                      <tr>
                        <td width="15%"><font class="textsmall">&nbsp;Series
                        No.</font></td>
                        <td width="13%"><font class="textsmall"><input name="txtserno" size="9"></font></td>
                        <td width="22%"><font class="textsmall">&nbsp;No. of
                        Leaves per Book</font></td>
                        <td width="18%"><font class="textsmall"><input name="txtnoleavesperbook" size="9"></font></td>
                        <td width="13%"></td>
                        <td width="19%"></td>
                      </tr>
                      <tr>
                        <td width="15%"><font class="textsmall">&nbsp;Start
                        Cheque No..</font></td>
                        <td width="13%"><font class="textsmall"><input name="txtstchqno" size="9"></font></td>
                        <td width="22%"><font class="textsmall">&nbsp;Ending
                        Cheque.No</font></td>
                        <td width="18%"><font class="textsmall"><input name="txtendchqno" size="9"></font></td>
                        <td width="13%"></td>
                        <td width="19%"></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

              </div>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
              <div id="divleaf">

                <table border="0" width="98%" class="tableborder2" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr class="bgcolor">
                        <td width="100%" colspan="8"><font class="subheading">&nbsp;Available
                        Leaf Details</font></td>
                      </tr>
                      <tr>
                        <td width="10%"><font class="textsmall">&nbsp;Series
                        No.</font></td>
                        <td width="9%"><font class="textsmall"><input name="txtlserno" size="9"></font></td>
                        <td width="21%"><font class="textsmall">&nbsp;No. of
                        Leaves</font></td>
                        <td width="10%"><font class="textsmall"><input name="txtnol" size="9"></font></td>
                        <td width="11%"><font class="textsmall">&nbsp;Start
                        chq no.</font></td>
                        <td width="13%"><FONT 
                        face="MS Sans Serif" size=2><INPUT name=txtlstchqno 
                        size=9></FONT></td>
                        <td width="14%"><font class="textsmall">Ending Chq.
                        no.</font></td>
                        <td width="12%"><font class="textsmall"><input name="txtlendchqno" size="9"></font></td>
                      </tr>
                    </table><FONT 
                  face="MS Sans Serif" size=2></FONT>

                    </td>
                  </tr>
                </table>

              </div>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>

              <table border="0" width="25%" class="tablebordermain" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                  <p align="center"><input type="button" value="Approve" name="butapp" onclick="Approve()" class="bgcolor"><input type="button" value=" Reject " name="butrej" onclick="Reject()" class="bgcolor"><input type="button" value=" Cancel " name="butcancel" onclick='location.replace("SBcustinstrapproval.asp")' class="bgcolor"><input type="button" value="   Exit   " name="butexit" id="butexit" onclick="location.replace(&quot;sbmodule.asp&quot;)" class="bgcolor"></p>
                  </td>
                </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
            </table></CENTER></DIV></TD></TR></TABLE>

  <input type="hidden" name="hidstatus"><input type="hidden" name="hidflex">
</form>

</body>

</html>
