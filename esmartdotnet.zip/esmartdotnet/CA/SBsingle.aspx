<%@ Page Language="vb" CodeBehind="SBsingle.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.SBsingle1" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>e-Smart Banker</title>
<%
strType=Request.QueryString("st")
%>
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
function List()
{

var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
	{
		alert("Select Any Code") 
	}
else
   {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	if (type.substring(0,9)=="Allotment")
		{
		window.attachEvent(window.opener.Allotmentid(str))
		window.close()
		}
			
	else if(type.substring(0,6)=="Modify")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}	
	else if(type.substring(0,6)=="Delete")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}	
	else if(type.substring(0,4)=="View")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}	
		
	}
}
</SCRIPT>
<%
dim obj,rs
  
  set rs=server.CreateObject("adodb.recordset")    
  set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")  
if left(strtype,6)="Modify" then
	k=split(strtype,"|")    
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(3)),cstr(k(4)),cstr(k(2)),"R")
	set obj=nothing
elseif left(strtype,6)="Delete" then	
	k=split(strtype,"|")
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(3)),cstr(k(4)),cstr(k(2)),"R")	
set obj=nothing	
elseif left(strtype,4)="View" then	
	k=split(strtype,"|")
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(3)),cstr(k(4)),cstr(k(2)),"A")	
set obj=nothing

end if
%>
</head>
<body>

<form name="frmList">
  <%if not rs.BOF and not rs.EOF then %>
  <div align="center">
    <center>

    <table border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
      <tr class="bgcolor">
        <th style="FONT-SIZE:xx-small"><font class="textbold">&nbsp; No</font></th>
      <tr>
        <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	      <%do until rs.EOF%>	
          <option><%=rs(0)%></option>
	      <%
	rs.MoveNext
	loop  
	set rs=nothing
	set obj=nothing
	      %>     
        </select></td>
      </tr>
    </table>

    </center>
  </div>
  <%
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()"& chr(13)  
	Response.Write "window.document.frmList.cmbList.item(0).selected=true"& chr(13)      
	Response.Write "end sub" & chr(13)  
	Response.Write "call show()" & chr(13)  
	Response.Write "</script>" & chr(13) 
  %>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <%else	
	msg="No Records Found"
	Response.Write "<FONT size=4  color=white>" & chr(13) 
	Response.Write msg & chr(13)
	Response.Write"</font>" & chr(13)
	
  %>
  <center><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <% end if%>
  <br>
</form>

</body>

</html>
