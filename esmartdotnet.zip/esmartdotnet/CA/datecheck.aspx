<%@ Page Language="vb" CodeBehind="datecheck.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Datecheck" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
	var str,str1
	str= window.document.frmacc.hbno.value
	str1= window.document.frmacc.hbno1.value				
	window.attachEvent(window.opener.GetDateDif(str,str1))  
	window.close()
 
}
//-->
</SCRIPT>

<%
	dim str
	dim cnt
	str=split(Request.QueryString("st")  	,"|")
	appdate=session("applicationdate")
	dif=datediff("d",appdate,str(0))
	set rs=nothing
	set obj=nothing	


%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" name="hbno" id="hbno" value="<%=dif%>"><input type="hidden" name="hbno1" id="hbno1" value="<%=str(1)%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
