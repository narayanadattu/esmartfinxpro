<%@ Page CodeBehind="custlist.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Custlist" %>
<HTML>
	<HEAD>
		<title>New</title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<%
strval=Request.QueryString("strbut")
%>
			<script language="javascript">

function getlistdtls(str)
	{
	strvalue=str.split("~")
	strvalues=strvalue[0].split("-----")
		if(strvalue[1]=="cmdmodlist")
		{
		window.document.frmcustlist.txtmodcode.value=strvalues[1]
		window.document.frmcustlist.txtmoddesc.value=strvalues[0]
		window.document.frmcustlist.hidtablename.value=strvalues[2]
		}
		else if(strvalue[1]=="cmdgllst")
		{
		window.document.frmcustlist.txtglcode.value=strvalues[1]
		window.document.frmcustlist.txtgldesc.value=strvalues[0]
		}
		else if(strvalue[1]=="cmdacclst")
		{
		window.document.frmcustlist.txtaccno.value=strvalues[1]
		window.document.frmcustlist.txtname.value=strvalues[0]
		window.document.frmcustlist.txtcustid.value=strvalues[2]
		}
		else if(strvalue[1]=="cmdseclst")
		{
		window.document.frmloanopening.txtsecurityid.value=strvalues[0]
		}
		else if(strvalue[1]=="cmdcustlst")
		{
		window.document.frmcustlist.txtcustomer.value=strvalues[1]
		window.document.frmcustlist.txtcustname.value=strvalues[0]
		}
		
	}
function lstdtls(strbut)
{
var strtablename
	if((strbut).substr(0,9)=="cmdcislst")
	{
	if((window.document.frmloanopening.hidcis[eval((strbut).substr(9,11))-1].value).length>0)
	{
	strtablename=window.document.frmloanopening.hidcis[eval((strbut).substr(9,11))-1].value 
	st=strtablename+"~code,narration~~~"+strbut
	window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	}
	}
	else if(strbut=="cmdmodlist") 
	{
	st="GENMODULEMST~MODULEID,NARRATION,MASTERTABLE~~~"+strbut
	window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	}
	else if(strbut=="cmdgllst") 
	{
	 if((window.document.frmcustlist.txtmodcode.value).length>0)
	 {
	  st="GENGLSHEETMST~Glcode,NARRATION~moduleid='"+window.document.frmcustlist.txtmodcode.value+"'~~"+strbut
	  window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	 }
	 else
	 {
	 alert("Module ID Cannot be null")
	 }	
	}
	else if(strbut=="cmdacclst")	
	{
	 if((window.document.frmcustlist.txtmodcode.value.length>0) && (window.document.frmcustlist.txtglcode.value.length>0))
	 {
		st=window.document.frmcustlist.hidtablename.value+"~accno,name,customerid~~~"+strbut
		window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	 }	
	}
	else if(strbut=="cmdlstcust1") 
	{
	st="GENCUSTINFOMST~customerid,custname~~~"+strbut
	window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	}
	else if(strbut=="cmdseclst") 
	{
	st="LOANSECURITYMST~SECURITYID,SECURITYDESC~CUSTOMERID='"+window.document.frmloanopening.txtcustno.value+"'~~"+strbut
	window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	}
	else if(strbut=="cmdlstcust1") 
	{
	st="GENCUSTINFOMST~customerid,custname~~~"+strbut
	window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
	}
	else if(strbut=="cmdcustlst") 
	{
		if(window.document.frmcustlist.txtnametype.value.length>0)
		{
		var stra
		stra="CUSTNAME like '"+ window.document.frmcustlist.txtnametype.value+"%'"
		
		st="GENCUSTINFOMST~customerid,custname~"+stra+"~~"+strbut
		window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sth","width=220%,height=150%")
		}
		else
		{
		st="GENCUSTINFOMST~customerid,custname~~~"+strbut
		window.open("../BILLS/List1.aspx" + "?"+"st="+st,"sthh","width=220%,height=150%")
		}
	}
	
}   
function sendcustid()
{
if(window.document.frmcustlist.opttype(0).checked==true)
{
	if((window.document.frmcustlist.txtcustid.value).length>1)
		{
		window.attachEvent(window.opener.getcustid(window.document.frmcustlist.hidbutname.value+"~"+window.document.frmcustlist.txtcustid.value+"~"+window.document.frmcustlist.txtname.value)) 
		window.close()
		}
	else
		{
		alert("CustomerID cannot be null")
		}
}		
else if(window.document.frmcustlist.opttype(1).checked==true)		
{
    if((window.document.frmcustlist.txtcustomer.value).length>1)
		{
		window.attachEvent(window.opener.getcustid(window.document.frmcustlist.hidbutname.value+"~"+window.document.frmcustlist.txtcustomer.value+"~"+window.document.frmcustlist.txtcustname.value)) 
		window.close()
		}
	else
		{
		alert("CustomerID cannot be null")
		}
}
}
//}
function getdtls(strvals){
	var strsplit
	strsplit=(strvals).split("|")
	if(strsplit[0]="newaccno")
	{
	window.document.frmloanopening.txtaccno.disabled=true
	window.document.frmloanopening.txtaccno.value=strsplit[1]
	}
}

function senddtls(strtype){
   if(strtype="newaccno")
   {
     strqry="frmloanopening"+"|"+"newaccno"
     window.open("loanmstgetdtls.asp" +"?" +"strqry="+strqry,"strsendval","width=220%,height=150%")
   }
   
}

function cisgetdtls()
{
var strcistype
strcistype="frmloanopening"+"~"+"N"
window.open("cisloanmstgetdtls.asp" +"?"+"strcistype="+strcistype,"CIS","width=50%,height=75%,LEFTMARGIN=10")
}
function frmclose(){
window.close()
}

function showdiv(){
	if(window.document.frmcustlist.opttype(0).checked==true)
	{
	window.document.all.divaccount.style.display="block"
	window.document.all.divname.style.display="none"
	}
	else if(window.document.frmcustlist.opttype(1).checked==true)
	{
	window.document.all.divname.style.display="block"
	window.document.all.divaccount.style.display="none"
	}
}
			</script>
			<form name="frmcustlist">
	</HEAD>
	<body topmargin="0" leftmargin="0">
		<table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
			<tr>
				<td width="100%">
					<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
						<tr class="bgcolor1">
							<td width="50%"><font class="textwhite"><input type="radio" value="V1" checked name="opttype" onclick="showdiv()">Account 
									Wise</font></td>
							<td width="50%"><font class="textwhite"><input type="radio" value="V1" name="opttype" onclick="showdiv()">Name 
									Wise</font></td>
						</tr>
					</table>
					<div id="divaccount">
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="33%" height="23">&nbsp; Module ID</td>
								<td width="139%" height="23"><input name="txtmodcode" size="11" disabled><input type="button" value=" L " name="cmdmodlist" onclick="lstdtls('cmdmodlist')"><input disabled name="txtmoddesc" size="24"></td>
							</tr>
							<tr>
								<td width="33%" height="1">&nbsp; GL Code</td>
								<td width="72%" height="1"><input name="txtglcode" size="11" disabled><input type="button" value=" L " name="cmdgllst" onclick="lstdtls('cmdgllst')"><input name="txtgldesc" size="24" disabled></td>
							</tr>
							<tr>
								<td width="33%" height="1">&nbsp; Acc. No</td>
								<td width="72%" height="1"><input name="txtaccno" size="11" disabled><input type="button" value=" L " name="cmdacclst" onclick="lstdtls('cmdacclst')"><input name="txtname" size="24" disabled></td>
							</tr>
							<tr>
								<td width="33%" height="23">&nbsp; Cust. ID</td>
								<td width="72%" height="23"><input name="txtcustid" size="29" disabled></td>
							</tr>
						</table>
					</div>
					<div id="divname" style="DISPLAY: none; WIDTH: 480px; HEIGHT: 75px">
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="18%">&nbsp; Name &nbsp;</td>
								<td width="82%"><input name="txtnametype" size="29"> %</td>
							</tr>
							<tr>
								<td width="18%">&nbsp; Cust. ID</td>
								<td width="82%"><input name="txtcustomer" size="17"><input type="button" value=" L " name="cmdcustlst" onclick="lstdtls('cmdcustlst')"><input name="txtcustname" size="32" disabled></td>
							</tr>
						</table>
					</div>
					<div align="center">
						<center>
							<table width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%"><input type="button" value="     OK      " name="cmdok" onclick="sendcustid()" class="bgcolor"><input type="button" value="Cancel " name="cmdcancel" onclick="frmclose()" class="bgcolor"
											color="BLACK"></td>
								</tr>
							</table>
						</center>
					</div>
				</td>
			</tr>
		</table>
		<p>&nbsp;</p>
		<input type="hidden" name="hidtablename"><input type="hidden" name="hidbutname" value="<%=strval%>">
		</FORM>
	</body>
</HTML>
