<%@ Page CodeBehind="chequeissuedetls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.chequeissuedetls" %>
<html>
<%
dim str
str=Request.QueryString("strMsg")
'Response.Write str
'strg=split(str,"*")
'Response.Write strg(0)
%>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>New Page 1</title>
</HEAD>
<body bgcolor="#c7ba95" topmargin="0" leftmargin="0">
<form name="frmChqDtls">
<%      
	dim ObjFetchRec,RecChq
        Set RecChq = CreateObject("adodb.recordset")
		Set ObjFetchRec = CreateObject("QueryRecordsets.FetchRecordsets")
		'Set RecChq = ObjFetchRec.singlerecordset("Genchequedtls", "BOOKSERIESNO,CHQBOOKLEAFNO", "where branchcode='" & branchcode & "' AND currencycode='" & currencycode & "' AND glcode='" & glcode & "'AND accno='" & accno & "'", "CHQBOOKLEAFNO")
		Set RecChq = ObjFetchRec.singlerecordset("Genchequedtls", "BOOKSERIESNO,CHQBOOKLEAFNO,LEAFSERIESN0,CHQLEAFNO", "branchcode='0001' AND currencycode='INR' AND glcode='SB0001' AND accno='123'", "CHQBOOKLEAFNO")
If Not RecChq.EOF Then
I = 0
RecChq.MoveFirst
Do Until RecChq.EOF
    If I = 0 Then
        Num = RecChq(1)
        Bl="Book" &"*"
        Series = RecChq(0) & "*"
        Startno = RecChq(1) & "*"
     Else
        Num = Num + 1
            If RecChq(1) - Num = 1 Then
				BL=BL & "Book" & "*"
                Series = Series & RecChq(0) & "*"
                Endno = Endno & Num - 1 & "*"
                Startno = Startno & RecChq(1) & "*"
                Num = RecChq(1)
                
            End If
    End If
 Num = Num
 I = I + 1
 if RecChq(2)<>"" then
 LF=LF &"Leaf" &"*"
 lSeries=lseries & RecChq(2) &"*"
 lStartNo=lStartNo & RecChq(3)& "*"
 lendno=lendno & RecChq(3)& "*"
 end if
 RecChq.MoveNext
 If RecChq.EOF Then
    Endno = Endno & Num &"*"
 End If
Loop
end if

Series=Series & lSeries 
StartNo=StartNo & lStartno 
endno=endno & lEndno 
Bl=Bl & Lf
Series=left(series,len(series)-1)
StartNo=left(StartNo,len(StartNo)-1)
endno=left(endno,len(endno)-1)
Bl=left(Bl,len(Bl)-1)

'Bl=split(Bl,"*")
'Series=split(Series,"*")
'StartNo=split(Startno,"*")
'EndNo=split(Endno,"*")
strSeries=bl & "|" & Series & "|" &  Startno & "|" &  Endno  & "|"
Response.Write strseries

%>


<table border="0" width="100%" cellspacing="0" cellpadding="0">

  <tr>
    <td width="100%" colspan="4"><font face="MS Sans Serif" size="2" color="#000000">Cheque
    issue details of the customer / Account holder</font></td>
  </tr>
  <tr>
    <td width="100%" colspan="4">

    </td>
  </tr>
  <tr>
    <td width="100%" colspan="4">
      <OBJECT classid=clsid:6262D3A0-531B-11CF-91F6-C2863C385E30 height=138 
      id=stopPay name=stopPay 
      style="HEIGHT: 138px; LEFT: 0px; TOP: 0px; WIDTH: 457px" width=457><PARAM NAME="_ExtentX" VALUE="12091"><PARAM NAME="_ExtentY" VALUE="3651"><PARAM NAME="_Version" VALUE="393216"><PARAM NAME="Rows" VALUE="2"><PARAM NAME="Cols" VALUE="4"><PARAM NAME="FixedRows" VALUE="1"><PARAM NAME="FixedCols" VALUE="0"><PARAM NAME="RowHeightMin" VALUE="0"><PARAM NAME="BackColor" VALUE="-2147483643"><PARAM NAME="ForeColor" VALUE="-2147483640"><PARAM NAME="BackColorFixed" VALUE="-2147483633"><PARAM NAME="ForeColorFixed" VALUE="-2147483630"><PARAM NAME="BackColorSel" VALUE="-2147483635"><PARAM NAME="ForeColorSel" VALUE="-2147483634"><PARAM NAME="BackColorBkg" VALUE="8421504"><PARAM NAME="GridColor" VALUE="12632256"><PARAM NAME="GridColorFixed" VALUE="0"><PARAM NAME="WordWrap" VALUE="0"><PARAM NAME="Redraw" VALUE="-1"><PARAM NAME="AllowBigSelection" VALUE="-1"><PARAM NAME="ScrollTrack" VALUE="0"><PARAM NAME="Enabled" VALUE="-1"><PARAM NAME="RightToLeft" VALUE="0"><PARAM NAME="TextStyle" VALUE="3"><PARAM NAME="TextStyleFixed" VALUE="0"><PARAM NAME="FocusRect" VALUE="1"><PARAM NAME="HighLight" VALUE="1"><PARAM NAME="FillStyle" VALUE="0"><PARAM NAME="GridLines" VALUE="1"><PARAM NAME="GridLinesFixed" VALUE="2"><PARAM NAME="ScrollBars" VALUE="3"><PARAM NAME="SelectionMode" VALUE="0"><PARAM NAME="MergeCells" VALUE="0"><PARAM NAME="AllowUserResizing" VALUE="1"><PARAM NAME="PictureType" VALUE="0"><PARAM NAME="BorderStyle" VALUE="1"><PARAM NAME="Appearance" VALUE="1"><PARAM NAME="MousePointer" VALUE="0"><PARAM NAME="GridLineWidth" VALUE="1"><PARAM NAME="FormatString" VALUE="^       Book/Leaf|^              SeriesNo|^           Start No |^             End No"><PARAM NAME="OLEDropMode" VALUE="0"></OBJECT>
	<%
	'for icount=0 to ubound(Series)-1
'Response.Write "<script language=vbscript>" & chr(13)
'Response.Write "sub dd()" & chr(13)
'Response.Write "window.document.frmChqDtls.stopPay.textmatrix(" & icount+1 & ",0)="& chr(34)& BL(icount) & chr(34)& chr(13)
'Response.Write "window.document.frmChqDtls.stopPay.textmatrix(" & icount+1 & ",1)="& chr(34)& series(icount) & chr(34)& chr(13) 
'Response.Write "window.document.frmChqDtls.stopPay.textmatrix(" & icount+1 & ",2)="& chr(34)& Startno(icount) & chr(34)& chr(13) 
'Response.Write "window.document.frmChqDtls.stopPay.textmatrix(" & icount+1 & ",3)="& chr(34)& EndNo(icount) & chr(34)& chr(13)  
'Response.Write "window.document.frmChqDtls.stopPay.rows=window.document.frmChqDtls.stopPay.rows+1" & chr(13)	
'Response.Write "end sub" & chr(13)
'Response.Write "call dd()" & chr(13)
'Response.Write "</script>" & chr(13)
'next
	%>
	
	
	
	
	
	
	
	
</td>
  </tr>
  </table>
  <%
 'if strg(0)="STOP" then
 %>
 <div id="StopDiv" "style: display=Block">
 <center>
 <table>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Stop Payment Charges from</font></td>
    <td width="7%"><input name="txtStopFrom" size="6" 
     ></td>
    <td width="4%">
    <p align="right"><font size="2" face="MS Sans Serif">To&nbsp; </font></p></td>
    <td width="64%"><input name="txtStopTo" size="8" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Reason for stop Payment</font></td>
    <td width="75%" colspan="3"><input name="txtStopReason" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Customer letter Reference
    No</font></td>
    <td width="75%" colspan="3"><input name="txtStopRefno" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Letter Reference Date</font></td>
    <td width="75%" colspan="3"><input name="txtStopRefDt" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Stop Pay effective Date</font></td>
    <td width="75%" colspan="3"><input name="txtStopEfDt" 
     ></td>
  </tr>
</table>
</center>
</div>




<%
'elseif strg(0)="CANCEL" then
%>
<p>&nbsp;</p>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%" colspan="4"></td>
  </tr>
  <tr>
    <td width="100%" colspan="4">

    </td>
  </tr>
  <tr>
    <td width="100%" colspan="4">
</td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Cancel Stop Payment from</font></td>
    <td width="7%"><input name="txtCanFrom" size="6" 
     ></td>
    <td width="4%">
    <p align="right"><font size="2" face="MS Sans Serif">To&nbsp; </font></p></td>
    <td width="64%"><input name="txtCanTo" size="8" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Reason for Cancellation</font></td>
    <td width="75%" colspan="3"><input name="txtCanReason" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Customer letter Reference
    No</font></td>
    <td width="75%" colspan="3"><input name="txtCanRefno" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Letter Reference Date</font></td>
    <td width="75%" colspan="3"><input name="txtRefDt" 
     ></td>
  </tr>
  <tr>
    <td width="25%"><font size="2" face="MS Sans Serif">&nbsp; Cancellation effective Date</font></td>
    <td width="75%" colspan="3"><input name="txtCanEfDt" 
     ></td>
  </tr>
  <%
  'end if
  %>
</table>
</form>
</body>

</html>
