<%@ Page CodeBehind="SBcustinstrumentdtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBcustinstrumentdtls" %>
<%
	dim insdtl,insstr
	insdtl=Request.Form("hidinstr")
	insstr=split(insdtl,"~")	
%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Instruments</title>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
function mfgins_DblClick() 
{
	if(window.document.frminsapp.mfgins.Cols>1 && window.document.frminsapp.mfgins.Rows>1)
	{
		i=window.document.frminsapp.mfgins.Row
		
		//for (d=0;d<window.document.frminsapp.mfgins.Cols;d++) 
		//{   
		//		window.document.frminsapp.mfgins.Row=i
		//		window.document.frminsapp.mfgins.Col=d
		//		window.document.frminsapp.mfgins.CellBackColor="<%=vbyellow%>"
		//}
       window.parent.window.document.frmcuststockapp.txtaccno.value=window.document.frminsapp.mfgins.TextMatrix(i,2)
	if(window.document.frminsapp.mfgins.TextMatrix(i,4))
	{
		window.parent.window.document.frmcuststockapp.Radtype(0).disabled=false
		window.parent.window.document.frmcuststockapp.Radtype(0).checked=true
		window.parent.window.document.frmcuststockapp.Radtype(1).disabled=true
		window.parent.window.document.frmcuststockapp.all.divleaf.style.display="none"
		window.parent.window.document.frmcuststockapp.all.divbook.style.display="block"
		window.parent.window.document.frmcuststockapp.txtserno.value=window.document.frminsapp.mfgins.TextMatrix(i,4)
		window.parent.window.document.frmcuststockapp.txtnoleavesperbook.value=window.document.frminsapp.mfgins.TextMatrix(i,6)
		window.parent.window.document.frmcuststockapp.txtstchqno.value=window.document.frminsapp.mfgins.TextMatrix(i,7)
		window.parent.window.document.frmcuststockapp.txtendchqno.value=window.document.frminsapp.mfgins.TextMatrix(i,8)
	}
	else if(window.document.frminsapp.mfgins.TextMatrix(i,5))
	{
		var lsno,esno,nol
		lsno=window.document.frminsapp.mfgins.TextMatrix(i,9)
		esno=window.document.frminsapp.mfgins.TextMatrix(i,10)
		nol=eval(esno)-eval(lsno)+1
		window.parent.window.document.frmcuststockapp.Radtype(1).disabled=false
		window.parent.window.document.frmcuststockapp.Radtype(1).checked=true
		window.parent.window.document.frmcuststockapp.Radtype(0).disabled=true
		window.parent.window.document.frmcuststockapp.all.divleaf.style.display="block"
		window.parent.window.document.frmcuststockapp.all.divbook.style.display="none"
		window.parent.window.document.frmcuststockapp.txtlserno.value=window.document.frminsapp.mfgins.TextMatrix(i,5)
		window.parent.window.document.frmcuststockapp.txtnol.value=nol
		window.parent.window.document.frmcuststockapp.txtlstchqno.value=window.document.frminsapp.mfgins.TextMatrix(i,9)
		window.parent.window.document.frmcuststockapp.txtlendchqno.value=window.document.frminsapp.mfgins.TextMatrix(i,10)
	}
	}
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=mfgins EVENT=DblClick>
<!--
 mfgins_DblClick()
//-->
</SCRIPT>
</head>
<body bgcolor="#C7BA95" topmargin="0" leftmargin="0">
<form name="frminsapp">
<div align="center">
<input type="hidden" name="hidinstr">
<center>
<table border="0" width="60%" class="tablebordermain" cellspacing="0" cellpadding="0">
<tr>
<td width="100%">
      <OBJECT classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height=140 id=mfgins name=mfgins 
	style="HEIGHT: 140px; LEFT: 21px; TOP: 0px; WIDTH: 617px" width=617>
	<PARAM NAME="_ExtentX" VALUE="16325">
	<PARAM NAME="_ExtentY" VALUE="3704">
	<PARAM NAME="_Version" VALUE="393216">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="Cols" VALUE="12">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="HighLight" VALUE="1">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="AllowUserResizing" VALUE="1">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="FormatString" VALUE="Module id  |<  GL code |> Account No  |< Instrument Code  |<  Book Series No  |< Leaf Series No |> Leaves Per Book  |> Book  Start No |> Book End No  |> Leaf  Start No |> Leaf End No |^ Application Date">
	<PARAM NAME="OLEDropMode" VALUE="0"></OBJECT>
</td>
</tr>
</table>
</center>
</div>
<%

if len(insdtl)> 0 then	
if len(insstr(0))>0 and len(insstr(1))>0 then

	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rsins=server.CreateObject("adodb.recordset")
	
''' this is for books

set rsins=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","MODULEID,GLCODE,Accno," &_
		"INSTRCODE,BOOKSERIESNO,LEAFSERIESNO,LEAVESPERBOOK, " &_
		"BOOKSTARTNO,BOOKENDNO,LEAFNUMBER,APPLICATIONDATE","branchcode='" & insstr(0) & "' and UPPER(TRIM(INSTRCODE))='" & UCASE(TRIM(insstr(1))) & "' and " & _
		"MODULEID='"& insstr(2) &"' AND Status='P' and TRANSSTATUS='A' and bookseriesno IS NOT NULL ", _
		"accno,BOOKSERIESNO,to_number(BOOKSTARTNO)")
		
		
''' for Leafstno,leafendno calculating

set ObjFetchRec=server.CreateObject("queryrecordsets.fetchrecordsets")
set RecIns=server.CreateObject("adodb.recordset")
Set RecIns = obj.SingleRecordSet("GENDEPTCUSTINSTRSTOCKDTLS","MODULEID,GLCODE,Accno,INSTRCODE,LEAFSERIESNO," & _
			"LEAFNUMBER,APPLICATIONDATE","upper(trim(branchcode))='" & insstr(0) & "' and " & _
			"upper(trim(INSTRCODE))='" & insstr(1) & "' and " & _
			"upper(trim(MODULEID))='" & insstr(2) & "' and " & _
			"Status='P' and TRANSSTATUS='A' and leafseriesno is not null", _
			"accno,LEAFSERIESNO,TO_NUMBER(leafnumber)")
Dim Mode,Lno,lstno,count
 
if rsins.EOF<>true and rsins.BOF<>true then
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	rsins.MoveFirst()
	for count=0 to rsins.RecordCount - 1
		Response.Write "window.document.frminsapp.mfgins.rows=window.document.frminsapp.mfgins.rows +1" & chr(13)
	 for jins=0 to rsins.Fields.Count - 2
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &","& jins &")="&  chr(34) &  rsins(jins) & chr(34)& chr(13)
	 next
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &",11)="&  chr(34) &  rsins(10) & chr(34)& chr(13)
		rsins.MoveNext()
	next
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if

if RecIns.EOF<>true and RecIns.BOF<>true then
	lstno = 0
	BkStno=""
	BkendNo=""
	lfPerBk=""
	BookSno=""
	Accountno=0
 Do Until RecIns.EOF
    
    If eval(Mode) <> 1 Then
    
      LeafStNo =  RecIns(0) & "*" & RecIns(1) & "*"	& RecIns(2) & "*" _
				  &	RecIns(3) & "*" & LfPerBk & "*" &  RecIns(4) & "*" _	
				  & LfPerBk & "*" &  BkStNo & "*" & BkEndNo & "*" & RecIns(5) _
				  & "*" & RecIns(6)
				
				
	'Response.Write	LeafStNo&"LeafStNo"
	'Response.Write	RecIns(3)&"RecIns(5)"
    End If
    
    If cdbl(RecIns(5)) <> cdbl(lstno) And eVal(lstno) <> 0 	or cdbl(RecIns(2)) <> cdbl(Accountno)and eVal(Accountno) <> 0 Then
             
    LeafStNo = LeafStNo & "|" & RecIns(0) & "*" _
			   & RecIns(1) & "*" & RecIns(2) & "*" _
			   & RecIns(3) & "*" & LfPerBk & "*"   _
			   & RecIns(4) & "*" 	& LfPerBk & "*" _
			   & BkStNo & "*" & BkEndNo & "*" _
			   & RecIns(5) & "*" & RecIns(6)
				
		LeafEndNo = LeafEndNo & Lno & "|"
	End If
      
    Lno = RecIns(5)
    lstno =cdbl(Lno) + 1
    Accountno=cdbl(RecIns(2))
    'Response.Write Accountno&"<br>"
    RecIns.MoveNext
        
   If RecIns.EOF = True Then
       LeafEndNo = LeafEndNo & Lno & "|"
   End If
    Mode = 1
   Loop
	StrLeafSt=split(leafstno,"|")
	strleafEd=split(leafEndno,"|")
	'Response.Write leafstno&"<br>"
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	for jCnt=0 to ubound(StrLeafSt)
		leafst=split(StrLeafSt(jCnt),"*")
	if len(leafst(0))>0 and len(leafst(1))>0 then
		
			Response.Write "window.document.frminsapp.mfgins.rows=window.document.frminsapp.mfgins.rows +1" & chr(13)
			
		  for cleaf=0 to 4
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & "," & cleaf & ")="&  chr(34)  &  leafst(cleaf) & chr(34)& chr(13)
		  next
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",5)="&  chr(34)  &  leafst(5) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",6)="&  chr(34)  &  leafst(6) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",7)="&  chr(34)  &  leafst(7) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",8)="&  chr(34)  &  leafst(8) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",9)="&  chr(34)  &  leafst(9) & chr(34)& chr(13)
			
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",10)="&  chr(34)  &  strleafEd(jCnt) & chr(34)& chr(13)
		  	Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",11)="&  chr(34) &  leafst(10) & chr(34)& chr(13)
		  
	end if
		count=count+1
		next
		Response.Write "end sub" & chr(13)
		Response.Write "call show()" & chr(13)
		Response.Write "</script>" & chr(13)
	End If	
 
if RecIns.EOF=true and RecIns.BOF=true  and rsins.EOF=true and rsins.BOF=true then
 
	st="^                                                           Description                          "
	str="        No Records Found.    "
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.formatstring="& chr(34)& st & chr(34)& chr(13)
	Response.Write "window.document.frminsapp.mfgins.cols=1" & chr(13)	
	Response.Write "window.document.frminsapp.mfgins.rows=2" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.textmatrix(1,0)="& chr(34)& str & chr(34)& chr(13)
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if
end if
end if
%>
</form>
</body>
</html>
