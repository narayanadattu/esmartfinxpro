<%@ Page Language="vb" CodeBehind="changemasterdetails.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.changemasterdetails3" %>
<%
	dim rs,obj,obj1,rs1
	str=Request.form("hcondition")  
	'Response.Write str &"<br>"	
	k=split(str,"|")  		
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")  
	set rs=server.CreateObject("adodb.recordset")	
if len(str)>0 then		
	 dim custid,accno
	 if k(0)="Joint" then
		set rs=obj.singlerecordset(cstr(k(1)),"jointholderid,jointholdername,minoryn," _
		& "to_char(minordob,'dd-Mon-yyyy'),relation,userid,machineid","branchcode='"&k(2)&"'" _
		& " and currencycode='"& k(3)&"' and moduleid='"&k(4)&"' and " _
		& " glcode='"& k(5)&"' and accno='"&k(6)&"'")
		
	jcount=rs.RecordCount     
	if not rs.BOF and  not rs.EOF then  
		for inti=1 to rs.RecordCount			
			strrec= strrec & rs(0)& ","& rs(1)& "," & rs(2)& ","  & rs(3)& "," & rs(4)& "," & rs(5)& "," & rs(6) & "$" 
			rs.MoveNext() 
		next 
	intk=instrrev(strrec,"$")
	strrec=mid(strrec,1,intk-1)
	strResult="Joint"&"|"& jcount & "|"& strrec
	else
		strResult="Joint" & "|" & jcount		
	end if
	
elseif	k(0)="Nominee" then
	set rs=obj.singlerecordset(cstr(k(1)),"nomineeid,nomineename,minoryn," _
		& "to_char(minordob,'dd-Mon-yyyy'),relation,userid,machineid","branchcode='"&k(2)&"'" _
		& " and currencycode='"& k(3)&"' and moduleid='"&k(4)&"' and " _
		& " glcode='"& k(5)&"' and accno='"&k(6)&"'")
		
	ncount=rs.RecordCount     
	if not rs.BOF and  not rs.EOF then  
		for inti=1 to rs.RecordCount			
			strrec= strrec & rs(0)& ","& rs(1)& "," & rs(2)& ","  & rs(3)& "," & rs(4)& "," & rs(5)& "," & rs(6) & "$" 
			rs.MoveNext() 
		next 
	intk=instrrev(strrec,"$")
	strrec=mid(strrec,1,intk-1)
	strResult="Nominee"&"|"& ncount & "|"& strrec
	else
		strResult="Nominee" & "|" & ncount		
	end if
elseif	k(0)="Guard" then
	set rs=obj.singlerecordset(cstr(k(1)),"guardianid,guardianname," _
		& "relation,userid,machineid","branchcode='"&k(2)&"'" _
		& " and currencycode='"& k(3)&"' and moduleid='"&k(4)&"' and " _
		& " glcode='"& k(5)&"' and accno='"&k(6)&"'")
		
	gcount=rs.RecordCount     
	if not rs.BOF and  not rs.EOF then  
	
		for inti=1 to rs.RecordCount			
			strrec= strrec & rs(0)& ","& rs(1)& "," & rs(2)& ","  & rs(3)& "," & rs(4) & "$" 
			rs.MoveNext() 
		next 
	intk=instrrev(strrec,"$")
	strrec=mid(strrec,1,intk-1)
	strResult="Guard"&"|"& gcount & "|"& strrec
	else
		strResult="Guard" & "|" & gcount		
	end if		
 end if	 
 
'Response.Write strresult & "<br>"			
end if
%>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<SCRIPT ID="clientEventHandlersJS" LANGUAGE="javascript">
<!--

function mfgMaster_Click()
 {	
	var row=window.document.frmFlex.mfgMaster.RowSel		
	if(window.parent.window.document.forms("frmChangerequest").radAdd(1).checked==true ||
	window.parent.window.document.forms("frmChangerequest").radAdd(2).checked==true)
	
	{
	window.parent.window.document.forms("frmChangerequest").txtJointid.value=window.document.frmFlex.mfgMaster.TextMatrix(row,1)
	window.parent.window.document.forms("frmChangerequest").txtJointdesc.value=window.document.frmFlex.mfgMaster.TextMatrix(row,2)
	window.parent.window.document.forms("frmChangerequest").butok.disabled=false
	if(window.parent.window.document.forms("frmChangerequest").txtTitle.value!="Guardian Details")
	{
		window.parent.window.document.forms("frmChangerequest").txtJminordob.value=window.document.frmFlex.mfgMaster.TextMatrix(row,4)        	        	
	}
	else
	{
		window.parent.window.document.forms("frmChangerequest").txtJminordob.value=window.document.frmFlex.mfgMaster.TextMatrix(row,3)        	        	
	}
	
	if(window.document.frmFlex.mfgMaster.TextMatrix(row,3)=="Y")
	{
		window.parent.window.document.forms("frmChangerequest").chkJminor.checked=true
	}        	
	else
	{
		window.parent.window.document.forms("frmChangerequest").chkJminor.checked=false
	}
	
	if(window.parent.window.document.forms("frmChangerequest").txtTitle.value!="Guardian Details")
	{
	var relation=window.document.frmFlex.mfgMaster.TextMatrix(row,5)        	        	
	}
	else
	{
	var relation=window.document.frmFlex.mfgMaster.TextMatrix(row,3)        	        	
	}
	
	
		
	for(inti=0;inti<window.parent.window.document.forms("frmChangerequest").cmbJrelation.length;inti++)
	{		
		
		if(relation.toUpperCase()==window.parent.window.document.forms("frmChangerequest").cmbJrelation.options[inti].text.toUpperCase())
		{
			window.parent.window.document.forms("frmChangerequest").cmbJrelation.options[inti].selected=true
		}
		
	}
	
	}	
	
}
//-->
			</SCRIPT>
			<SCRIPT LANGUAGE="javascript" FOR="mfgMaster" EVENT="Click">
<!--
 mfgMaster_Click()
//-->
			</SCRIPT>
			<title></title>
	</head>
	<body>
		<form name="frmFlex">
			<p align="center">
				<object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="164" id="mfgMaster"
					name="mfgMaster" style="HEIGHT: 164px; LEFT: 0px; TOP: 0px; WIDTH: 610px" width="610">
					<param name="_ExtentX" value="16140">
					<param name="_ExtentY" value="4339">
					<param name="_Version" value="393216">
					<param name="Rows" value="1">
					<param name="Cols" value="9">
					<param name="FixedRows" value="1">
					<param name="FixedCols" value="0">
					<param name="RowHeightMin" value="0">
					<param name="BackColor" value="-2147483643">
					<param name="ForeColor" value="-2147483640">
					<param name="BackColorFixed" value="-2147483633">
					<param name="ForeColorFixed" value="-2147483630">
					<param name="BackColorSel" value="-2147483635">
					<param name="ForeColorSel" value="-2147483634">
					<param name="BackColorBkg" value="8421504">
					<param name="GridColor" value="12632256">
					<param name="GridColorFixed" value="0">
					<param name="WordWrap" value="0">
					<param name="Redraw" value="-1">
					<param name="AllowBigSelection" value="-1">
					<param name="ScrollTrack" value="0">
					<param name="Enabled" value="-1">
					<param name="RightToLeft" value="0">
					<param name="TextStyle" value="0">
					<param name="TextStyleFixed" value="0">
					<param name="FocusRect" value="1">
					<param name="HighLight" value="1">
					<param name="FillStyle" value="0">
					<param name="GridLines" value="1">
					<param name="GridLinesFixed" value="2">
					<param name="ScrollBars" value="3">
					<param name="SelectionMode" value="0">
					<param name="MergeCells" value="0">
					<param name="AllowUserResizing" value="3">
					<param name="PictureType" value="0">
					<param name="BorderStyle" value="1">
					<param name="Appearance" value="1">
					<param name="MousePointer" value="0">
					<param name="GridLineWidth" value="1">
					<param name="FormatString" value="  Sno  |^     Customer ID                 |^                      Name          |^   Minor           |^Minor Date of Birth  |^        Relation              |^         Entered By           |^  Entered Machine       |&lt;Remarks                          ">
					<param name="OLEDropMode" value="0">
				</object>
			</p>
			<%			

if len(str)>0 then	
		k=split(strresult,"|")						
	if ubound(k)>0 then	
		
		if k(1)>0 then
			strrec=split(k(2),"$")				  	  
			Response.Write "<script language=vbscript>" & chr(13)
			Response.Write "sub assignflex()" & chr(13)				
		
	if k(0)="Guard" then		
		Response.Write "window.document.frmFlex.mfgMaster.cols=0"& chr(13)
		str="Sno  |^     Customer ID      |^         Name           |^  Relation |^ Entered By |^  Entered Machine" 
		response.Write "window.document.frmFlex.mfgMaster.formatstring=" & chr(34)& str & chr(34)& chr(13)                         		
	end if
	 for inti=1 to k(1)			
		Response.Write "window.document.frmFlex.mfgMaster.rows=window.document.frmFlex.mfgMaster.rows+1" & chr(13)
		Response.Write "window.document.frmFlex.mfgMaster.textmatrix("& inti &",0)="& chr(34)& inti & chr(34)& chr(13)
	
		fldcount=split(strrec(inti-1),",")			
	   for intj=0 to ubound(fldcount)				
		Response.Write "window.document.frmFlex.mfgMaster.textmatrix("& inti &","& intj+1 &")="& chr(34)& fldcount(intj) & chr(34)& chr(13)
	   next	  
	 
	next		
	
		Response.Write "end sub" & chr(13)	 
		Response.Write "call assignflex()" & chr(13)
		Response.Write "</script >" & chr(13)
	
	
	else
		Response.Write "<script language=vbscript>" & chr(13)		
		dim strmsg
		if k(0)="Guard" then		
		Response.Write "window.document.frmFlex.mfgMaster.cols=0"& chr(13)
		str="Sno  |^     Customer ID      |^         Name           |^  Relation |^ Entered By |^  Entered Machine" 
		response.Write "window.document.frmFlex.mfgMaster.formatstring=" & chr(34)& str & chr(34)& chr(13)                         		
	end if
		strmsg="No Records Found"
		Response.Write "msgbox" & chr(34)&strmsg&chr(34) & chr(13)
		Response.Write "window.parent.window.document.frmChangerequest.butok.disabled=true" & chr(13)				
		Response.Write "</script >" & chr(13)
	
end if
end if
end if		
  %>
			<input type="hidden" name="hcondition" id="hcondition">
		</form>
	</body>
</html>
