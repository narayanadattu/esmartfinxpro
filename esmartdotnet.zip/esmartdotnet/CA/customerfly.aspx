<%@ Page Language="vb" CodeBehind="customerfly.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.customerfly1" %>
<HTML>
<HEAD>
<META NAME="GENERATOR"  Content="Microsoft Visual Studio 6.0">
<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
	var str,str1
	str= window.document.frmcust.hbno.value
	window.attachEvent(window.opener.Display(str))  
	window.close()
 
}
//-->
</SCRIPT>

<%
	dim rs,rs1,obj,custid
	dim mainstr
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")  
    set rs=server.CreateObject("adodb.recordset")
    set rs1=server.CreateObject("adodb.recordset") 	 	
	custid=Request.QueryString("st")
	Response.Write custid
	k=split(custid,"|")	
	if ubound(k)>0 then
			
			Response.Write k(0) &"<br>"
			listfields="custname,customertype,custmembershipno,to_char(custdob,'dd-Mon-yyyy'),custemail,custfax," & _
			"custmobile,custminoryn,custmaritalstatus,custsex,custoccupation,custqualification," & _
			"custmonthlyincome,phone1,phone2,phone3,mailaddress1,mailaddress2,mailaddress3," & _
			"mailaddress4,mailaddress5,pmtaddress1,pmtaddress2,pmtaddress3,pmtaddress4," & _
			"pmtaddress5,offaddress1,offaddress2,offaddress3,offaddress4,offaddress5"
		
			set rs=obj.singlerecordset("Gencustinfomst",cstr(listfields),"customerid='" &  cstr(k(0)) & "'")
		
			set rs1=obj.singlerecordset("gencustfamilydtls","name,to_char(dob,'dd-Mon-yyyy'),relation","customerid='" & cstr(k(0)) & "'")
		
			if not rs1.eof and not rs1.BOF then
				do while not rs1.EOF 
					 mainstr=mainstr & "~~" & rs1(0) & "|" & rs1(1) & "|" & rs1(2)
					rs1.MoveNext 
				loop
			end if
			mainstr=mainstr & "!!"
			'Response.Write rs(0)
		
			if not rs.EOF and not rs.BOF then
				if len(rs(1))>0 then
					set rs1=obj.singlerecordset("custtypemst","narration","code=" & cstr(rs(1)) )
					if not rs1.EOF and not rs1.BOF then
						mainstr=mainstr & rs1(0)
					end if
				end if
			end if
	else
			set rs=obj.singlerecordset("gencustinfomst","custname,mailaddress1,mailaddress2," & _
									"mailaddress3,mailaddress4,mailaddress5,custemail," & _
									"phone1,phone2,phone3,custmobile,custfax," & _
									"to_char(custdob,'dd-Mon-yyyy')," & _
									"custminoryn", "customerid='" & custid & "'")
	end if
	Response.Write "gencustinfomst" & "  custname,mailaddress1,mailaddress2," & _
									"mailaddress3,mailaddress4,mailaddress5,custemail," & _
									"phone1,phone2,phone3,custmobile,custfax," & _
									"to_char(custdob,'dd-Mon-yyyy')," & _
									"custminoryn" &  "  customerid='" & custid & "'"
	
	
	
	
	if not rs.eof and not rs.BOF then
		for i=1 to rs.Fields.Count-1
			mainstr=mainstr & "|" & rs(i)
		next
		mainstr=mainstr&"|"&rs(0)
	else
		mainstr="Invalid Customer Id.."
end if
	Response.Write mainstr
	set rs=nothing
	set obj=nothing	
	 '''
%>
</HEAD>                  
<BODY bgcolor=#643428 onLoad='List()'>
<form name=frmcust>
<INPUT type=hidden name="hbno" id="hbno" value="<%=mainstr%>">
<center>
<font color=red size=4>Processing..........</font>
</center>
</form>
</BODY>
</HTML>


