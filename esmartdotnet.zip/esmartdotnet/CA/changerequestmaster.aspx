<%@ Page language="vb" CodeBehind="changerequestmaster.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Changerequestmaster" %>
<%
'************************************************************************************************
'*	Name Of the File :  Masterapproval.asp							  							*
'*	Purpose	  	     :  Master Forms(SB,Current) Modification						* 
'*	Other Forms used :  changelist.asp,changecounter.asp,changemasterdetails.asp,
'							changerequestconfirmation.asp						     *
' 		                (changemasterdetails.asp is to show the details of JointHolder,
'							Nominee,Guardian)'
' 		                (changerequestconfirmation.asp is to update the database)                      *
'|----------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	                  
'|----------------------|------------------|------------|---------------------------|
'| Sobhan Babu.K        |    06-AUG-2001   |   3.0      |		                    |     
'|				        |                  |	        |                           |
'|----------------------------------------------------------------------------------|
'************************************************************************************
%>

<%		
	strreturn=Request.QueryString("record")
	
	if len(strreturn)>0 then
		strmsg=split(strreturn,"|")		
		strmessage=strmsg(0)		
		if ubound(strmsg)>0 then
			strval=strmsg(1)
		end if		
	end if
	
		
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<title>Change Request</title>
<meta content="text/html; charset=windows-1252" http-equiv="Content-Type">
<meta content="Microsoft FrontPage 4.0" name="GENERATOR">
<meta content="FrontPage.Editor.Document" name="ProgId">
<script language=javascript src="DatePicker.js"></script>
<script language=javascript src="val.js"></script>

<SCRIPT LANGUAGE="javascript">
<!--
var divstatus=""
function focus()
{
strvals="<%=strval%>"
	if(strvals)	
	{					
		strvalues=strvals.split("~")
	
	window.document.frmChangerequest.txtBrcode.value =strvalues[0]     
	window.document.frmChangerequest.txtBrdesc.value =strvalues[1]
	window.document.frmChangerequest.txtCrcode.value =strvalues[2]
	window.document.frmChangerequest.txtCrdesc.value =strvalues[3]
	window.document.frmChangerequest.txtModcode.value =strvalues[4]     
	window.document.frmChangerequest.txtModdesc.value =strvalues[5]
	window.document.frmChangerequest.txtGlcode.value =strvalues[6]
	window.document.frmChangerequest.txtGldesc.value =strvalues[7]
	window.document.frmChangerequest.txtAccountno.value =strvalues[8]
	window.document.frmChangerequest.txtAccountname.value =strvalues[9]
	
  }

		
}
function focus12()
{
	window.document.frmChangerequest.txtBrcode.value="0001"  
	window.document.frmChangerequest.txtBrdesc.value="MAIN BRANCH"
	window.document.frmChangerequest.txtCrcode.value="INR"
	window.document.frmChangerequest.txtCrdesc.value="INDIAN RUPEE"
	window.document.frmChangerequest.txtModcode.value="SB"
	window.document.frmChangerequest.txtModdesc.value="SAVINGS BANK"
	window.document.frmChangerequest.txtGlcode.value="SB0001"
	window.document.frmChangerequest.txtGldesc.value="ABHYASA SAVINGS"
	window.document.frmChangerequest.txtAccountno.value="1"
	window.document.frmChangerequest.txtAccountname.value="AJAY RAJU"
	
}

//-----------To Get Branch List ------------------------------------------------------------
function Branch()
{
	
	var branch="Branch"	
	var user="SOBHAN"  // log in userid
	st=branch+"|"+user			
	window.open("changelist.asp" + "?"+"st="+st,"Branch","width=200%,height=150% left=255 top=190")	
	
}
//------------------------------To Assign Branch details to text boxes----------------------

 function Branchid(str)
{	
	assign(str,window.document.frmChangerequest.txtBrdesc,window.document.frmChangerequest.txtBrcode)      	    
	branchclear()
}

//------------------------------To Get Currency List ------------------------------------------------------------
function Currency()
{
	
	st="Currency"	
	if(window.document.frmChangerequest.txtBrcode.value=="")
	{    
		alert("Branch  Code Should Not Be Null")
		return;
	}
	else
	{
		window.open("changelist.asp" + "?"+"st="+st,"Branch","width=200%,height=150% left=560 top=190")
		
	}	
}

//------------------------------To Assign Currrency details to text boxes----------------------
 function Currencyid(str)
{
	assign(str,window.document.frmChangerequest.txtCrdesc,window.document.frmChangerequest.txtCrcode)      
	currencyclear()
}

//------------------------------To Get Module List in the corresponding Branch ------------------------------------------------------------
function Module()
{
	
	var mod="Module"
	var brcode=window.document.frmChangerequest.txtBrcode.value 
	var crcode=window.document.frmChangerequest.txtCrcode.value  
	if(brcode=="")
	{
		alert("Branch Code Should Not Be Null")
		return;
	}
	else if(crcode=="")
	{
		alert("Currency Code Should Not Be Null")
		return;
	}	
	else
	{
	st=mod+"|"+brcode   
	window.open("changelist.asp" + "?"+"st="+st,"Branch","width=200%,height=150% left=255 top=220")
	}
}


//------------------------------To Assign Module details to text boxes----------------------
 function Moduleid(str)
{
	assign(str,window.document.frmChangerequest.txtModdesc,window.document.frmChangerequest.txtModcode)      
	moduleclear()
}
//------------------------------To Get GLcodes List in the corresponding Branch ------------------------------------------------------------

function Glcode()
{	
	
	var glcode="Glcode"
	var brcode=window.document.frmChangerequest.txtBrcode.value
	var crcode=window.document.frmChangerequest.txtCrcode.value  
	var mod=window.document.frmChangerequest.txtModcode.value    
	if(brcode=="")
	{
		alert("Branch Code Should Not Be Null") 
		return;
	
	}
	else if(crcode=="")
	{
		alert("Currency Code Should Not Be Null")
		return;
	}
	else if(mod=="")
	{
		alert("ModuleId Should Not Be Null") 
		return;
	
	}
	
	else
	{
	st=glcode+"|"+brcode +"|"+  mod
	window.open("changelist.asp" + "?"+"st="+st,"Branch","width=200%,height=150% left=575 top=210")
	}
}

//------------------------------To Assign GLcode details to text boxes----------------------
 function Glcodeid(str)
{
	assign(str,window.document.frmChangerequest.txtGldesc ,window.document.frmChangerequest.txtGlcode) 	
	glclear()	
}

//---------------- This function is to get Account No and Name  ----------------------------
var accountmode=""
function Accoutno()
{	
	
	
	var del="|"			
	var brcode=window.document.frmChangerequest.txtBrcode.value 
	var crcode=window.document.frmChangerequest.txtCrcode.value 
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var glcode=window.document.frmChangerequest.txtGlcode.value
	var accno=window.document.frmChangerequest.txtAccountno.value  
	
	if(brcode=="")
	{
		alert("Branch Code Should Not Be Null")
		return;
	
	}	
	else if(crcode=="")
	{
		alert("Currency Code Should Not Be Null")
		return;
	
	}
	else if(modcode=="")
	{
		alert("ModuleId Should Not Be Null")
		return;
	
	}
	else if(glcode=="")
	{
		alert("GLCode Should Not Be Null")
		return;
	
	}
	
	if(accountmode=="Getaccountno")
	{
		gen=accountmode
		var tab=modcode+"MST"
		st=gen+"|"+tab+"|"+brcode+"|"+crcode+"|"+modcode+"|"+glcode+"|"+accno
  		window.open("changecounter.asp" + "?"+"st="+st,"Modify13","width=1%,height=1% left=1 top=1")
	
	}	
	 else
	 {   	       			
		gen="Accno"  	
		st=gen+"|"+brcode+"|"+crcode+"|"+modcode+"|"+glcode
  		window.open("changelist.asp" + "?"+"st="+st,"Modify12","width=200%,height=150% left=255 top=235")
	}
}

//-------------------- This function is to assign,  Account no and Name ---------------------

function Accnoid(str)
{
	assign(str,window.document.frmChangerequest.txtAccountname,window.document.frmChangerequest.txtAccountno)      
	
}

//---------- This function is to enable Save button and show controls for changing the status----------------
function changestatus()
{
var accno=window.document.frmChangerequest.txtAccountno.value 
 
if(accno!="")
{   	
		
	if(window.document.frmChangerequest.cmbNewstatus.options[window.document.frmChangerequest.cmbNewstatus.selectedIndex].text!="Select")        
	{	
		window.document.all.sreason.style.visibility="visible"   
		window.document.frmChangerequest.txtReason.style.visibility="visible"   		
		window.document.frmChangerequest.butok.disabled=false    
	}
	else
	{
		window.document.frmChangerequest.cmbNewstatus.options[0].selected=true		
		window.document.all.sreason.style.visibility="hidden"   		
		window.document.frmChangerequest.txtReason.style.visibility="hidden"      			
		window.document.frmChangerequest.butok.disabled=true    
	}
}

else
{
	alert("Account No Should Not be Null")
	window.document.frmChangerequest.cmbStatus[0].selected=true   
}
}

//---------------- This function is to Assign Corresponding Values to controls------------------
function Allot(str)
{	
		k=str.split("|")
		
		if(k[0]=="Cheque")
		{
			if(k[1]=="Y")
			{
				window.document.frmChangerequest.radCheque(0).checked=true    
				window.document.frmChangerequest.radCheque(0).disabled=true 
			}
			else
			{
				window.document.frmChangerequest.radCheque(1).checked=true
				window.document.frmChangerequest.radCheque(1).disabled=true   
			}
		}
		else if(k[0]=="TDS")
		{
			if(k[1]=="Y")
			{
				window.document.frmChangerequest.radTds(0).checked=true    
				window.document.frmChangerequest.radTds(0).disabled=true 
			}
			else
			{
				window.document.frmChangerequest.radTds(1).checked=true
				window.document.frmChangerequest.radTds(1).disabled=true   
			}		
		}
		
		else if(k[0]=="Bank")
		{
			if(k[1]=="Y")
			{
				window.document.frmChangerequest.radBank(0).checked=true    
				window.document.frmChangerequest.radBank(0).disabled=true 
			}
			else
			{
				window.document.frmChangerequest.radBank(1).checked=true  
				window.document.frmChangerequest.radBank(1).disabled=true
			}		
		}
		
		else if(k[0]=="Status")
		{			
				window.document.frmChangerequest.txtOldstatus.value=k[1]
				window.document.frmChangerequest.cmbNewstatus 
				balstr=str.split("~")								
				s=balstr[1].split("|")
				for(inti=0;inti<s.length-1;inti++)
				{
					var option0 = new Option(s[eval(inti)])
													
					eval("window.document.frmChangerequest.cmbNewstatus.options[inti+1]=option0")  
				}
				
				
		}
		else if(k[0]=="Opinstr")
		{			
				window.document.frmChangerequest.txtOldinstr.value=k[1]  
		}
//----------- This is for Assigning  Operated by name-------------------------------
		else if(k[0]=="Optby")
		{			
				window.document.frmChangerequest.txtOperateold.value=k[1]  
		}
//----------- This is for Assigning Account holder name-------------------------------
		else if(k[0]=="Accoutno")
		{
			if(k[1].substring(0,4)!="This")
			{
				window.document.frmChangerequest.txtAccountname.value=k[1]  
			}
			else
			{
				alert(k[1])
				window.document.frmChangerequest.txtAccountno.value=""  
				window.document.frmChangerequest.txtAccountname.value=""
			}
		}		
	}
	


	var checkstatus
	checkstatus=false
	
//---------------- This function is to Show Cheque Book   Details------------------	
function showchequebook()
{	
	var empty
	empty=checknull()
 if(empty==true)
	{
	if(checkstatus==false)
	{		
		window.document.all.dcheque.style.display="block"  
		window.document.all.dtds.style.display="none"
		window.document.all.dstatus.style.display="none"    
		window.document.all.doptby.style.display="none"  
		window.document.all.dopinstr.style.display="none"  		
		window.document.all.djoint.style.display="none"  		
		window.document.all.dbank.style.display="none" 
		divstatus="Cheque"
		checkstatus=true 
		getotherdetails()
	}
	else
	{		
		checkdiv()
	}
}		
}

//-------------------- This function is to Show TDS  Details--------------------------

function showtds()
{	
	var empty
	empty=checknull()
	
 if(empty==true)
	{
	if(checkstatus==false)
	{
		window.document.all.dtds.style.display="block"
		window.document.all.dcheque.style.display="none"  	
		window.document.all.dstatus.style.display="none"    
		window.document.all.doptby.style.display="none"  
		window.document.all.dopinstr.style.display="none"  		
		window.document.all.djoint.style.display="none"  		
		window.document.all.dbank.style.display="none" 
		divstatus="TDS"
		checkstatus=true 
		getotherdetails()
	}
	else
	{
		
		checkdiv()
		
	}
  }	
}

//---------------- This function is to Check Which details are changing------------------
function checkdiv()
{	
	if(window.document.all.dcheque.style.display=="block" )
		{
			alert("First Complete The Cheque Changes")
		}
		else if(window.document.all.dtds.style.display=="block" )
		{
			alert("First Complete The TDS Changes")
		}
		else if(window.document.all.dstatus.style.display=="block" )
		{
			alert("First Complete The Status Changes")
		}
		else if(window.document.all.doptby.style.display=="block" )
		{
			alert("First Complete The Operated By Changes")
		}
		else if(window.document.all.dopinstr.style.display=="block" )
		{
			alert("First Complete The Operating Instruction Changes")
		}
		else if(window.document.all.dbank.style.display=="block" )
		{
			alert("First Complete The Bankstaff Changes")
		}
		else if(divstatus=="Joint" )
		{
			alert("First Complete The Joint Holder Changes")
		}
		else if(divstatus=="Nominee" )
		{
			alert("First Complete The Nominee Changes")
		}
		else if(divstatus=="Guard")
		{
			alert("First Complete The Guardian Changes")
		}
		
}

//---------------- This function is to Show Bank staff  Details----------------------
function showbank()
{		
	var empty
	empty=checknull()
 if(empty==true)
	{
	if(checkstatus==false)
	{
	window.document.all.dbank.style.display="block"  
	window.document.all.dcheque.style.display="none"  
	window.document.all.dtds.style.display="none"
	window.document.all.dstatus.style.display="none"    
	window.document.all.doptby.style.display="none"  
	window.document.all.dopinstr.style.display="none"  	
	window.document.all.djoint.style.display="none"  	
	divstatus="Bank"
	checkstatus=true
	getotherdetails()
	}
	else
	{
		checkdiv()
	}
  }
}

//---------------- This function is to Show Status  Details------------------
function showstatus()
{	
	
 var empty
	empty=checknull()
 if(empty==true)
	{	
	if(checkstatus==false)
	{
	window.document.all.dstatus.style.display="block" 
	window.document.all.dcheque.style.display="none"  
	window.document.all.dtds.style.display="none"	   
	window.document.all.doptby.style.display="none"  
	window.document.all.dopinstr.style.display="none"  	
	window.document.all.djoint.style.display="none"  	
	window.document.all.dbank.style.display="none"  
	checkstatus=true
	divstatus="Status"
	getotherdetails()
	}
	else
	{
		checkdiv()
	}
}

}

//---------------- This function is to Show Operating Instructions  Details------------------
function showoperateinstr()
{	
	
	var empty
	empty=checknull()
 if(empty==true)
	{	
	if(checkstatus==false)
	{
		window.document.all.dopinstr.style.display="block"
		window.document.all.dcheque.style.display="none"  
		window.document.all.dtds.style.display="none"
		window.document.all.dstatus.style.display="none"    
		window.document.all.doptby.style.display="none"  	  		
		window.document.all.djoint.style.display="none"  		
		window.document.all.dbank.style.display="none" 
		divstatus="Opinstr" 
		checkstatus=true
		getotherdetails()
	}
	
	else
	{
		checkdiv()
	}
	
  }	
}

//--------------------- This function is to Show Operated By  Details------------------------
function showoperateby()
{	
	
var empty
	empty=checknull()
 if(empty==true)
	{	
	if(checkstatus==false)
	{
	window.document.all.doptby.style.display="block"  	
	window.document.all.dcheque.style.display="none"  
	window.document.all.dtds.style.display="none"
	window.document.all.dstatus.style.display="none"    	
	window.document.all.dopinstr.style.display="none"  	  
	window.document.all.djoint.style.display="none"  	
	window.document.all.dbank.style.display="none"  
	divstatus="Operateby"
	checkstatus=true
	getotherdetails()
	}
	else
	{
		checkdiv()
	}
}
}

//--------------------- This function is to Show JointHolder   Details------------------------
function showjoint()
{	
	
	var empty
	empty=checknull()
 if(empty==true)
	{	
	if(checkstatus==false)
	{
	window.document.all.djoint.style.display="block"  
	window.document.all.dcheque.style.display="none"  
	window.document.all.dtds.style.display="none"
	window.document.all.dstatus.style.display="none"    
	window.document.all.doptby.style.display="none"  
	window.document.all.dopinstr.style.display="none" 	
	window.document.all.dbank.style.display="none"  
	checkstatus=true
	divstatus="Joint"
	window.document.frmChangerequest.txtTitle.value="JointHolder Details"    
	getdivdata()
	}
	else
	{
		checkdiv()
	}
 }
}
//--------------------- This function is to Show Nominee  Details------------------------
function shownominee()
{	
	
var empty
	empty=checknull()
 if(empty==true)
	{	
	if(checkstatus==false)
	{	
	window.document.all.djoint.style.display="block"    
	window.document.all.dcheque.style.display="none"  
	window.document.all.dtds.style.display="none"
	window.document.all.dstatus.style.display="none"    
	window.document.all.doptby.style.display="none"  
	window.document.all.dopinstr.style.display="none"  			
	window.document.all.dbank.style.display="none"  
	checkstatus=true
	divstatus="Nominee"
	window.document.frmChangerequest.txtTitle.value="NomineeHolder Details"    
	getdivdata()
	}
	else
	{
		checkdiv()
	}
}
}

//--------------------- This function is to Show Guardian  Details------------------------
function showguardian()
{		
	
var empty
	empty=checknull()
 if(empty==true)
	{
	if(checkstatus==false)
	{	
	
		window.document.all.djoint.style.display="block"    
		window.document.all.dcheque.style.display="none"  
		window.document.all.dtds.style.display="none"
		window.document.all.dstatus.style.display="none"    
		window.document.all.doptby.style.display="none"  
		window.document.all.dopinstr.style.display="none"  			
		window.document.all.dbank.style.display="none"  
		checkstatus=true
		divstatus="Guard"
		window.document.frmChangerequest.txtTitle.value="Guardian Details"    
		window.document.all.lblminor.style.visibility="hidden"
		window.document.all.lbldob.style.visibility="hidden"
		window.document.frmChangerequest.chkJminor.style.visibility="hidden"          
		window.document.frmChangerequest.txtJminordob.style.visibility="hidden"
		window.document.frmChangerequest.dtpJointdob.style.visibility="hidden"          		
		getdivdata()
		
	}
	else
	{
		checkdiv()
	}
}
}
//------- This function is to get the Corrsponding data of Jointholder or Nominee or Guardian---------
function AddOrDelete()
{
if(window.document.frmChangerequest.radAdd(0).checked==true)
{		
	window.document.frmChangerequest.radAdd(1).disabled=true
	window.document.frmChangerequest.radAdd(2).disabled=true 	 	
	window.document.frmChangerequest.butJointok.disabled=false  

}    
else if(window.document.frmChangerequest.radAdd(1).checked==true)
{
	
	window.document.frmChangerequest.radAdd(0).disabled=true
	window.document.frmChangerequest.radAdd(2).disabled=true
	window.document.frmChangerequest.butJointid.disabled=true	
	window.document.frmChangerequest.butJointok.disabled=true         	 	
	
}    
else if(window.document.frmChangerequest.radAdd(2).checked==true)
{
	  
	window.document.frmChangerequest.radAdd(0).disabled=true
	window.document.frmChangerequest.radAdd(1).disabled=true
	window.document.frmChangerequest.chkJminor.disabled=true
	window.document.frmChangerequest.txtJointid.readOnly=true       
	window.document.frmChangerequest.txtJointdesc.readOnly=true
	window.document.frmChangerequest.butJointid.disabled=true
	window.document.frmChangerequest.cmbJrelation.disabled=true
	window.document.frmChangerequest.txtJminordob.readOnly=true
	window.document.frmChangerequest.dtpJointdob.Enabled=false
	window.document.frmChangerequest.butJointok.disabled=true              
	
}    
}
//-------- This function is to get the data of Cheque,TDS,Bank,Opinstr,Opt By ,status---------
function getotherdetails()
{
	var brcode=window.document.frmChangerequest.txtBrcode.value    
	var crcode=window.document.frmChangerequest.txtCrcode.value 
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var glcode=window.document.frmChangerequest.txtGlcode.value 
	var accno=window.document.frmChangerequest.txtAccountno.value 
	var tab=modcode+"MST"
	if(window.document.all.dcheque.style.display=="block")
	{
		var gen="Cheque"
	}   
	else if(window.document.all.dtds.style.display=="block")
	{
		var gen="TDS"
	}   
	else if(window.document.all.dbank.style.display=="block")
	{
		var gen="Bank"
	} 
	else if(window.document.all.dstatus.style.display=="block")
	{
		var gen="Status"
	} 
	else if(window.document.all.dopinstr.style.display=="block")
	{
		var gen="Opinstr"
	} 
	else if(window.document.all.doptby.style.display=="block")
	{
		var gen="Optby"
	} 
	
	var del="|"
	st=gen+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno
	window.open("changecounter.asp" + "?"+"st="+st,"Branch","width=1%,height=1% left=1 top=1")
	
}


//----- This function is to get the related jointHolder or Nominee or Guardian Details---------------
function getdivdata()
{
	var brcode=window.document.frmChangerequest.txtBrcode.value    
	var crcode=window.document.frmChangerequest.txtCrcode.value 
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var glcode=window.document.frmChangerequest.txtGlcode.value 
	var accno=window.document.frmChangerequest.txtAccountno.value 
	
	
	
	if(divstatus=="Joint")
	{
		var gen="Joint"
		var tab="GENCUSTJOINTHOLDERMST"
	}
	else if(divstatus=="Nominee")
	{
		var gen="Nominee"
		var tab="GENCUSTNOMINEEMST"
	}
	else if(divstatus=="Guard")
	{
		var gen="Guard"
		var tab="GENCUSTGUARDIANMST"
	}
	var del="|"
		st=gen+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno
	
		window.document.frames(0).frmFlex.hcondition.value=st   	
		window.document.frames(0).frmFlex.action="changemasterdetails.asp"
		window.document.frames(0).frmFlex.method="post"
		window.document.frames(0).frmFlex.submit()
	
}

//----------------- This function is to get the Account No and Name----------------------------
function customer()
{
	var gen ="Custid"
	var brcode =window.document.frmChangerequest.txtBrcode.value
	var crcode=window.document.frmChangerequest.txtCrcode.value    	
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var glcode=window.document.frmChangerequest.txtGlcode.value   
	var accno=window.document.frmChangerequest.txtAccountno.value    
	if(brcode=="")
	{
		alert("Branch Code Should Not Be Null")
	}	
	else if(modcode=="")
	{
		alert("ModuleID Should Not Be Null")
	}
	else if(glcode=="")
	{
		alert("GL Code Should Not Be Null")
	}
	else if(accno=="")
	{
		alert("Account No Should Not Be Null")
	}
	else
	
	{
	del="|"
	var tab=modcode+"MST"
	st=gen+del+tab+del+brcode+del+crcode+del+glcode+del+accno	
	window.open("changelist.asp" + "?"+"st="+st,"Branch","width=200%,height=150% left=135 top=240")
	}

}
//----------------- This function is to Assign the Account No and name to the controls----------------------------

function Customerid(str)
{
	assign(str,window.document.frmChangerequest.txtJointdesc,window.document.frmChangerequest.txtJointid) 
}
//----------------- This function is to enable the Save Button----------------------------
function radioCheque()
{
	window.document.frmChangerequest.butok.disabled=false     
}
//----------------- This function is to enable the Save Button----------------------------
function radioTds()
{
	window.document.frmChangerequest.butok.disabled=false     
}
//----------------- This function is to enable the Save Button----------------------------
function radioBank()
{
	window.document.frmChangerequest.butok.disabled=false     
}

//--------------------- This function is to Save the Modifications--------------------------

function Save()
{
	var div=divstatus
	
	var brcode=window.document.frmChangerequest.txtBrcode.value 
	var brdesc=window.document.frmChangerequest.txtBrdesc.value     
	var crcode=window.document.frmChangerequest.txtCrcode.value 
	var crdesc=window.document.frmChangerequest.txtCrdesc.value  
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var moddesc=window.document.frmChangerequest.txtModdesc.value  
	var glcode=window.document.frmChangerequest.txtGlcode.value 
	var gldesc=window.document.frmChangerequest.txtGldesc.value  
	var accno=window.document.frmChangerequest.txtAccountno.value 
	var accname=window.document.frmChangerequest.txtAccountname.value 
	var del="|"
	var del1="~"

if(div=="Cheque")
{
	if(window.document.frmChangerequest.radCheque(0).checked==true)
	{
		var value="Y"
	}    
	else if(window.document.frmChangerequest.radCheque(1).checked==true)
	{
		var value="N"
	}
	
	var tab=modcode+"MST"		
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value	
}
else if(div=="TDS")
{
	if(window.document.frmChangerequest.radTds(0).checked==true)
	{
		var value="Y"
	}    
	else if(window.document.frmChangerequest.radTds(1).checked==true)
	{
		var value="N"
	}
	
	var tab=modcode+"MST"	
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value	
	
}
else if(div=="Bank")
{
	if(window.document.frmChangerequest.radBank(0).checked==true)
	{
		var value="Y"
	}    
	else if(window.document.frmChangerequest.radBank(1).checked==true)
	{
		var value="N"
	}
	
	var tab=modcode+"MST"	
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value	
	
}
else if(div=="Status")
{
	var tab=modcode+"MST"	
	value=window.document.frmChangerequest.cmbNewstatus.options[window.document.frmChangerequest.cmbNewstatus.selectedIndex].text        		
	var reason=window.document.frmChangerequest.txtReason.value  
	if(reason=="")  
	{
		alert("Reason for Changing the Status Should Not Be Null")
		return;
	}
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value+del+reason	
}
else if(div=="Opinstr")
{
	var tab=modcode+"MST"	
	value=window.document.frmChangerequest.cmbNewinstr.options[window.document.frmChangerequest.cmbNewinstr.selectedIndex].text        			
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value	
	
}	
else if(div=="Operateby")
{
	var tab=modcode+"MST"	
	value=window.document.frmChangerequest.txtOperatenew.value  
	var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+value	
	
}	

//------------------------------Joint Holder Part Starts---------------------------------
else if(div=="Joint")
{
	var tab="GENCUSTJOINTHOLDERMST"			
	if(window.document.frmChangerequest.radAdd(0).checked==true)
	{
		var mode="Add"
	 if(window.document.frames(0).frmFlex.mfgMaster.rows>1)
	  {
		var quote="'",strjoint="",del=",",strjointall="",del1="|"
		var jcount=0
		for(inti=1;inti<window.document.frames(0).frmFlex.mfgMaster.rows;inti++)
		{
			for(intj=1;intj<=5;intj++)
			{
				if(window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti,6)=="")
				{
				strjoint= strjoint+window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti,intj)+del
				
				}
			
		    }
			var intk=strjoint.lastIndexOf(",")
			strjoint=strjoint.substring(0,intk)						
			strjoint=strjoint+"|"		
			jcount=inti-1
		}
			intk=strjoint.lastIndexOf("|")
			strjoint=strjoint.substring(0,intk)									
			strjointall=jcount+strjoint			
			window.document.frmChangerequest.hinsert.value=strjointall 
			var st=div+del1+tab+del1+brcode+del1+crcode+del1+modcode+del1+glcode+del1+accno+del1+mode   		
	  }	 
	  
	}  
	else if(window.document.frmChangerequest.radAdd(1).checked==true)
	{
		var mode="Modify"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Joint Holder To Modify")
			return;		
		} 		
		else
		{
			var minor=""
			var minordob=window.document.frmChangerequest.txtJminordob.value 
			var jointid=window.document.frmChangerequest.txtJointid.value
			//var jointdesc=window.document.frmChangerequest.txtJointdesc.value 
			var relation=window.document.frmChangerequest.cmbJrelation.options[window.document.frmChangerequest.cmbJrelation.selectedIndex].text     
			var jdel="~",quote="'"
			
			if(window.document.frmChangerequest.chkJminor.checked==true)
			{
				minor="Y"
			}    
			else
			{
				minor="N"
			}	
			
			if(minor=="Y")
			{
				if(minordob=="")
				{
					alert("Minor Date Of Birth Should Not Be Null")
					return;
				}
			}	
			
			var strModify=minor+del+minordob+del+relation
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+jointid
			window.document.frmChangerequest.hmodify.value=strModify   	    	    	    	
		}   
	}  
	
	else if(window.document.frmChangerequest.radAdd(2).checked==true)
	{
		var mode="Delete"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Joint Holder To Delete")
			return;		
		}
		else
		{
			var jointid=window.document.frmChangerequest.txtJointid.value
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+jointid
		}    
	}  
	
	var strreturn=""	
	strreturn=brcode+del1+brdesc+del1+crcode+del1+crdesc+del1+modcode+del1+moddesc+del1+glcode+del1+gldesc+del1+accno+del1+accname
	
	window.document.frmChangerequest.hchange.value=st
	window.document.frmChangerequest.hreturn.value=strreturn	
	
	window.document.frmChangerequest.action="changerequestconfirmation.asp"
	window.document.frmChangerequest.method="post" 
	window.document.frmChangerequest.submit()     
}	
	
//-----------------------------Joint Holder Part Ends---------------------------------
//------------------------------Nominee Detail Starts---------------------------------
else if(div=="Nominee")
{
	var tab="GENCUSTNOMINEEMST"			
	if(window.document.frmChangerequest.radAdd(0).checked==true)
	{
		var mode="Add"
	 if(window.document.frames(0).frmFlex.mfgMaster.rows>1)
	  {
		var strnominee="",del=",",strnomineeall="",del1="|"
		var jcount=0
		for(inti=1;inti<window.document.frames(0).frmFlex.mfgMaster.rows;inti++)
		{
			for(intj=1;intj<=5;intj++)
			{
				if(window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti,6)=="")
				{
				strnominee= strnominee+window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti,intj)+del
				
				}
			
		    }
			var intk=strnominee.lastIndexOf(",")
			strnominee=strnominee.substring(0,intk)						
			strnominee=strnominee+"|"		
			jcount=inti-1
		}
			intk=strnominee.lastIndexOf("|")
			strnominee=strnominee.substring(0,intk)									
			strnomineeall=jcount+strnominee			
			window.document.frmChangerequest.hinsert.value=strnomineeall 
			var st=div+del1+tab+del1+brcode+del1+crcode+del1+modcode+del1+glcode+del1+accno+del1+mode   		
	  }	 
	  
	}  
	else if(window.document.frmChangerequest.radAdd(1).checked==true)
	{
		var mode="Modify"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Nominee Holder To Modify")
			return;		
		} 		
		else
		{
			var minor=""
			var minordob=window.document.frmChangerequest.txtJminordob.value 
			var nomineeid=window.document.frmChangerequest.txtJointid.value
			//var jointdesc=window.document.frmChangerequest.txtJointdesc.value 
			var relation=window.document.frmChangerequest.cmbJrelation.options[window.document.frmChangerequest.cmbJrelation.selectedIndex].text     
			var jdel="~",quote="'"
			
			if(window.document.frmChangerequest.chkJminor.checked==true)
			{
				minor="Y"
			}    
			else
			{
				minor="N"
			}
			if(minor=="Y")
			{
				if(minordob=="")
				{
					alert("Minor Date Of Birth Should Not Be Null")
					return;
				}
			}	
			var strModify=minor+del+minordob+del+relation
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+nomineeid
			window.document.frmChangerequest.hmodify.value=strModify   	    	    	    	
		}   
	}  
	
	else if(window.document.frmChangerequest.radAdd(2).checked==true)
	{
		var mode="Delete"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Nominee Holder To Delete")
			return;		
		}
		else
		{
			var nomineeid=window.document.frmChangerequest.txtJointid.value
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+nomineeid
		}    
	}  
	
	var strreturn=""	
	strreturn=brcode+del1+brdesc+del1+crcode+del1+crdesc+del1+modcode+del1+moddesc+del1+glcode+del1+gldesc+del1+accno+del1+accname
	
	window.document.frmChangerequest.hchange.value=st
	window.document.frmChangerequest.hreturn.value=strreturn	
	
	window.document.frmChangerequest.action="changerequestconfirmation.asp"
	window.document.frmChangerequest.method="post" 
	window.document.frmChangerequest.submit()     
}
//------------------------------Nominee Detail Ends-----------------------------------
//-----------------------------Guardian Detail Starts---------------------------------
else if(div=="Guard")
{
	var tab="GENCUSTGUARDIANMST"			
	if(window.document.frmChangerequest.radAdd(0).checked==true)
	{
		var mode="Add"
	 if(window.document.frames(0).frmFlex.mfgMaster.rows>1)
	  {
		var strguard="",del=",",del1="|"
		var jcount=0
		
			for(intj=1;intj<=3;intj++)
			{		
				strguard= strguard+window.document.frames(0).frmFlex.mfgMaster.textmatrix(1,intj)+del							
		    }
		    
			var intk=strguard.lastIndexOf(",")
			strguard=strguard.substring(0,intk)		
				
			window.document.frmChangerequest.hinsert.value=strguard
			var st=div+del1+tab+del1+brcode+del1+crcode+del1+modcode+del1+glcode+del1+accno+del1+mode   		
	  }	 
	  
	}  
	else if(window.document.frmChangerequest.radAdd(1).checked==true)
	{
		var mode="Modify"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Guardian To Modify")
			return;		
		} 		
		else
		{
			var minor=""
			var guarddob=window.document.frmChangerequest.txtJminordob.value 
			var guardid=window.document.frmChangerequest.txtJointid.value
			//var guarddesc=window.document.frmChangerequest.txtJointdesc.value 
			var relation=window.document.frmChangerequest.cmbJrelation.options[window.document.frmChangerequest.cmbJrelation.selectedIndex].text     
			var jdel="~",quote="'"
			
			
			var strModify=relation+del+guarddob
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+guardid
			window.document.frmChangerequest.hmodify.value=strModify   	    	    	    	
		}   
	}  
	
	else if(window.document.frmChangerequest.radAdd(2).checked==true)
	{
		var mode="Delete"
		if(window.document.frmChangerequest.txtJointid.value=="")
		{
			alert("Select Any Guardian To Delete")
			return;		
		}
		else
		{
			var guardid=window.document.frmChangerequest.txtJointid.value
			var st=div+del+tab+del+brcode+del+crcode+del+modcode+del+glcode+del+accno+del+mode+del+guardid
		}    
	}  
	
	var strreturn=""	
	strreturn=brcode+del1+brdesc+del1+crcode+del1+crdesc+del1+modcode+del1+moddesc+del1+glcode+del1+gldesc+del1+accno+del1+accname
	
	window.document.frmChangerequest.hchange.value=st
	window.document.frmChangerequest.hreturn.value=strreturn	
	
	window.document.frmChangerequest.action="changerequestconfirmation.asp"
	window.document.frmChangerequest.method="post" 
	window.document.frmChangerequest.submit()     
}
var strreturn=""	
	strreturn=brcode+del1+brdesc+del1+crcode+del1+crdesc+del1+modcode+del1+moddesc+del1+glcode+del1+gldesc+del1+accno+del1+accname
	
	window.document.frmChangerequest.hchange.value=st
	window.document.frmChangerequest.hreturn.value=strreturn	
	
	window.document.frmChangerequest.action="changerequestconfirmation.asp"
	window.document.frmChangerequest.method="post" 
	window.document.frmChangerequest.submit()     
}
//-----------------------------Guardian Detail Ends--------------------------------------

//--------------------- This function is to Enable save button----------------------------
function changeinstruction()
{
	var instr=window.document.frmChangerequest.cmbNewinstr.options[window.document.frmChangerequest.cmbNewinstr.selectedIndex].text
	if(instr!="Select")        
	{			
		if(instr!=window.document.frmChangerequest.txtOldinstr.value)    
		{
			window.document.frmChangerequest.butok.disabled=false    
		}
		else
		{
			window.document.frmChangerequest.butok.disabled=true    
		}	
	}
	else
	{
		window.document.frmChangerequest.cmbNewinstr.options[0].selected=true				
		window.document.frmChangerequest.butok.disabled=true    
	}		
}

//----------------- This function is to Check Null values in the controls------------------
function checknull()
{	
	var brcode=window.document.frmChangerequest.txtBrcode.value
	var crcode=window.document.frmChangerequest.txtCrcode.value  
	var modcode=window.document.frmChangerequest.txtModcode.value 
	var glcode=window.document.frmChangerequest.txtGlcode.value 
	var accno=window.document.frmChangerequest.txtAccountno.value 
	if(brcode=="")
	{
		alert("Branch Code Should Not be Null")
		return false;
	}
	else if(crcode=="")
	{
		alert("Currency Code Should Not be Null")
		return false;
	}
	else if(modcode=="")
	{
		alert("Module ID Should Not be Null")
		return false;
	}
	else if(glcode=="")
	{
		alert("GL Code Should Not be Null")
		return false;
	}
	else if(accno=="")
	{
		alert("Account Number Should Not be Null")
		return false;
	}
	else
	{
		return true;
	}
	   
}
//---------------------- This function is to Enable the Save Button ------------------------
function Opearatedby()
{
	if(window.document.frmChangerequest.txtOperatenew.value!="")    
	{		
		window.document.frmChangerequest.butok.disabled=false    
	}	
}
//------------ This function is to add Joint Holders or Nominee or Guardian details---------
function Jointadd()
{	
	var jointid=window.document.frmChangerequest.txtJointid.value
	var jointdesc=window.document.frmChangerequest.txtJointdesc.value  
	var minordob=window.document.frmChangerequest.txtJminordob.value 	
	var relation=window.document.frmChangerequest.cmbJrelation.options[window.document.frmChangerequest.cmbJrelation.selectedIndex].text        
	
if(divstatus=="Joint")
	{
		if(window.document.frmChangerequest.chkJminor.checked==true)
	{    
		var minor="Y"
	}
	else
	{
		var minor="N"
	}
	
		if(jointid=="")
		{
			alert("JointHolder ID Should Not Be Null")
			return;
		}		
		else if(minor=="Y")
		{
			if(minordob=="")
			{
				alert("Minor Date Of Birth Should Not Be Null")
				return;
			}	
		}
	
	var jcount=window.document.frames(0).frmFlex.mfgMaster.rows-1			
	for(inti=0;inti<jcount;inti++)
	{
		if(jointid==window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti+1,1))
		{
			alert("This JointHolder ID Already Exists")
			return
		}
	}
	
	
	window.document.frmChangerequest.butok.disabled=false    
	window.document.frames(0).frmFlex.mfgMaster.rows=window.document.frames(0).frmFlex.mfgMaster.rows+1
	var rowpos=window.document.frames(0).frmFlex.mfgMaster.rows-1
	
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,0)=jcount+1
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,1)=jointid
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,2)=jointdesc      
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,3)=minor
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,4)=minordob
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,5)=relation
	
	
}	
	else if(divstatus=="Nominee")
	{
		if(window.document.frmChangerequest.chkJminor.checked==true)
		{    
			var minor="Y"
		}
		else
		{
			var minor="N"
		}
	
		if(jointid=="")
		{
			alert("Nominee ID Should Not Be Null")
			return;
		}		
		else if(minor=="Y")
		{
			if(minordob=="")
			{
				alert("Minor Date Of Birth Should Not Be Null")
				return;
			}	
		}
	
	var jcount=window.document.frames(0).frmFlex.mfgMaster.rows-1			
	for(inti=0;inti<jcount;inti++)
	{
		if(jointid==window.document.frames(0).frmFlex.mfgMaster.textmatrix(inti+1,1))
		{
			alert("This Nominee ID Already Exists")
			return
		}
	}
	
	window.document.frmChangerequest.butok.disabled=false    
	window.document.frames(0).frmFlex.mfgMaster.rows=window.document.frames(0).frmFlex.mfgMaster.rows+1
	var rowpos=window.document.frames(0).frmFlex.mfgMaster.rows-1
	
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,0)=jcount+1
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,1)=jointid
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,2)=jointdesc      
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,3)=minor
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,4)=minordob
	window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,5)=relation
	
	
}
	else if(divstatus=="Guard")
	{
		var jcount=window.document.frames(0).frmFlex.mfgMaster.rows-1			
		if(jointid=="")
		{
			alert("Guardian ID Should Not Be Null")
			return;
		}		
		else if(jcount>0) 
		{
			alert("There Is Already One Guardian Exists")
			return;
		}
		else
		{		
		window.document.frmChangerequest.butok.disabled=false    
		window.document.frames(0).frmFlex.mfgMaster.rows=window.document.frames(0).frmFlex.mfgMaster.rows+1
		var rowpos=window.document.frames(0).frmFlex.mfgMaster.rows-1
	
		window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,0)=jcount+1
		window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,1)=jointid
		window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,2)=jointdesc      		
		window.document.frames(0).frmFlex.mfgMaster.textmatrix(rowpos,3)=relation	
		}
	}	
	
	
	window.document.frmChangerequest.txtJointid.value=""   
	window.document.frmChangerequest.txtJointdesc.value=""
	window.document.frmChangerequest.txtJminordob.value=""
	window.document.frmChangerequest.chkJminor.checked=false  
	window.document.frmChangerequest.cmbJrelation.options[0].selected=true  
	
}
// --------This function is to get account number details(like name)-----------
function getaccountno()
{	
	accountmode="Getaccountno"
	var accno=window.document.frmChangerequest.txtAccountno.value 
	if(accno=="")
	{	window.document.frmChangerequest.txtAccountname.value=""    
		alert("Account No Should Not Be Null")
		
	}
	else
	{   
		Accoutno()
	}
}

//----------------To Clear The Screen When The Branch Code Changes----------------------------
function branchclear()
{
	with(window.document.frmChangerequest)
	{
		txtCrcode.value =""    
		txtCrdesc.value =""	
		txtModcode.value=""
		txtModdesc.value=""      
		txtGlcode.value=""
		txtGldesc.value =""
		txtAccountno.value =""
		txtAccountname.value =""

	}
	
	
}

//----------------To Clear The Screen When The Curreny Code Changes----------------------------
function currencyclear()
{
	with(window.document.frmChangerequest)
	{
		txtModcode.value =""	
		txtModdesc.value =""
		txtGlcode.value =""
		txtGldesc.value =""
		txtAccountno.value =""
		txtAccountname.value =""
	}	
	
}

//----------------To Clear The Screen When The MOdule Code Changes----------------------------
function moduleclear()
{
	with(window.document.frmChangerequest)
	{
		txtGlcode.value =""
		txtGldesc.value =""		
		txtAccountno.value =""
		txtAccountname.value =""
	}
	
}

//--------------------To Clear The Screen When The GL Code Changes----------------------------
function glclear()
{	
		window.document.frmChangerequest.txtAccountno.value =""
		window.document.frmChangerequest.txtAccountname.value =""
	
}

function textclear()
{
	
	if(window.document.frmChangerequest.txtAccountno.value=="")
	{
		window.document.frmChangerequest.txtAccountname.value="" 
	}    

}


//-->
</SCRIPT>


<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function dtpAppdate_Change()
 {
	Datepick(window.document.frmChangerequest.dtpAppdate,window.document.frmChangerequest.txtAppdate) 
}


function dtpJointdob_Change() 
{
	Datepick(window.document.frmChangerequest.dtpJointdob,window.document.frmChangerequest.txtJminordob)
}


function dtpNomineedob_Change()
 {

Datepick(window.document.frmChangerequest.dtpNomineedob,window.document.frmChangerequest.txtNminordob)
}



function dtpGuarddob_Change()
 {
Datepick(window.document.frmChangerequest.dtpGuarddob,window.document.frmChangerequest.txtGminordob) 
}


//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpAppdate EVENT=Change>
<!--
 dtpAppdate_Change()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpJointdob EVENT=Change>
<!--
 dtpJointdob_Change()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpNomineedob EVENT=Change>
<!--
 dtpNomineedob_Change()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpGuarddob EVENT=Change>
<!--
 dtpGuarddob_Change()
//-->

</SCRIPT>
</head>
<body onload="focus()" topmargin="0" leftmargin="0">

<form name="frmChangerequest">
  <input type="hidden" name="hmodify"><input type="hidden" name="hinsert"><input type="hidden" name="hreturn"><input type="hidden" name="hchange">
  <div align="center">
    <center>
    <%appdate=formatdatetime(Date(),1)%>

    <table border="0" cellpadding="0" cellspacing="0" width="780">
      <tbody>
        <tr>
          <td valign="top" width="100%">

          <table cellpadding="0" cellspacing="0" width="100%" class="tablebordermain">
            <tbody>
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="34%" height="25"></td>
                    <td width="33%" height="25">
                    <p align="center"><font class="text">Change Request Master</font></td>
                    <td width="33%" height="25" align="right"><font class="textwhite"><%=appdate%></font></td>
                  </tr>
                </table>

                <table border="0" cellpadding="0" cellspacing="0" width="780">
                  <tbody>
                    <tr>
                      <td width="100%" height="15" align="center"><font class="textblue"><%=strmessage%></font></td>
                    </tr>
                  </tbody>
                </table>

                <div align="center">

                  <table cellpadding="0" cellspacing="0" width="100%" class="tableborder1">
                    <tbody>
                      <tr>
                        <td valign="top" width="18%">
                        <div align="left">

                          <table border="0" width="96%" cellspacing="1" cellpadding="0">
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showchequebook()"><font class="textbold">Cheque
                              Book</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showtds()"><font class="textbold">TDS</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showbank()"><font class="textbold">Bank
                              Staff</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showstatus()"><font class="textbold">Status</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showoperateinstr()"><font class="textbold">Operating<br>
                              &nbsp;Instructions</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showoperateby()"><font class="textbold">Operated
                              By</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showjoint()"><font class="textbold">Joint
                              Holder</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="shownominee()"><font class="textbold">Nominee</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"><font class="textbold">&nbsp;</font><a href="#" onclick="showguardian()"><font class="textbold">Guardian</font></a></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"></td>
                            </tr>
                            <tr class="bgcolor">
                              <td width="100%" height="18"></td>
                            </tr>
                          </table>

                        </div>
                        </td>
                        <td valign="top" width="87%">

                        <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                          <tr>
                            <td valign="top" width="100%">

                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                              <tbody>
                                <tr>
                                  <td width="100%">

                                  <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                      <tr>
                                        <td valign="top" width="86%">

                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                          <tbody>
                                            <tr>
                                              <td valign="top" width="100%">

                                              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                <tr>
                                                  <td align="left" width="24%">&nbsp;Branch</td>
                                                  <td align="left" width="32%"><input maxlength="5" name="txtBrcode" size="8" readonly><input name="butBrid" onclick="Branch()" type="button" value=" L "><input name="txtBrdesc" size="15" readonly></td>
                                                  <td width="11%">&nbsp;Currency</td>
                                                  <td align="left" width="33%" colspan="2"><input name="txtCrcode" size="6" readonly><input name="butCrid" onclick="Currency()" type="button" value=" L "><input name="txtCrdesc" size="15" readonly></td>
                                                </tr>
                                                <tr>
                                                  <td align="left" width="24%">&nbsp;Module
                                                  ID</td>
                                                  <td align="left" width="32%"><input name="txtModcode" size="8" readonly><input name="butModid" onclick="Module()" type="button" value=" L "><input name="txtModdesc" size="15" readonly></td>
                                                  <td width="11%">&nbsp;GL Code</td>
                                                  <td align="left" width="33%" colspan="2"><input name="txtGlcode" size="6" readonly><input name="butGlid" onclick="Glcode()" type="button" value=" L "><input name="txtGldesc" size="15"></td>
                                                </tr>
                                                <tr>
                                                  <td align="left" width="24%">&nbsp;Acc.
                                                  No.</td>
                                                  <td align="left" width="22%"><input name="txtAccountno" size="8" style="TEXT-ALIGN: right" onblur="getaccountno()" onkeypress="numeric();textclear()"><input name="butAccno" onclick="Accoutno()" type="button" value=" L "><input name="txtAccountname" size="15" readonly></td>
                                                  <td width="24%">&nbsp;Date of Request</td>
                                                  <td align="left" width="15%"><input name="txtAppdate" size="13" readonly></td>
                                                  <td align="left" width="15%">
                                                  <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="23" id="dtpAppdate" style="HEIGHT: 23px; LEFT: 0px; TOP: 0px; WIDTH: 37px" width="41">
                                                    <param name="_ExtentX" value="979">
                                                    <param name="_ExtentY" value="609">
                                                    <param name="_Version" value="393216">
                                                    <param name="MousePointer" value="0">
                                                    <param name="Enabled" value="1">
                                                    <param name="OLEDropMode" value="0">
                                                    <param name="CalendarBackColor" value="-2147483643">
                                                    <param name="CalendarForeColor" value="-2147483630">
                                                    <param name="CalendarTitleBackColor" value="-2147483633">
                                                    <param name="CalendarTitleForeColor" value="-2147483630">
                                                    <param name="CalendarTrailingForeColor" value="-2147483631">
                                                    <param name="CheckBox" value="1">
                                                    <param name="CustomFormat" value>
                                                    <param name="DateIsNull" value="0">
                                                    <param name="Format" value="662831105">
                                                    <param name="UpDown" value="0">
                                                    <param name="CurrentDate" value="37041">
                                                    <param name="MaxDate" value="2958465">
                                                    <param name="MinDate" value="-109205">
                                                  </object>
                                                  </td>
                                                </tr>
                                              </table>

                                              <div id="dstatus" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0" bordercolor="#d9d2b3">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15">&nbsp;<font class="subheading">Status</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="17%">&nbsp;Current Status</td>
                                                    <td width="35%"><input name="txtOldstatus" size="14" disabled></td>
                                                    <td width="16%">&nbsp; Changed Status</td>
                                                    <td width="33%"><select size="1" name="cmbNewstatus" onchange="changestatus()">
                                                      <option selected>Select</option>
                                                    </select></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="17%">&nbsp;<span id="sreason" style="VISIBILITY: hidden">Narration</span></td>
                                                    <td width="84%" colspan="3"><input name="txtReason" style="TEXT-TRANSFORM: capitalize; VISIBILITY: hidden" size="68">&nbsp;</td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="dcheque" style="DISPLAY: none">

                                                <table border="0" width="100%" bordercolor="#d9d2b3" cellspacing="0" cellpadding="0">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15"><font class="subheading">&nbsp;Cheque
                                                    Book</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="16%" height="21">&nbsp;</td>
                                                    <td width="34%" height="21">&nbsp;Yes <input type="radio" name="radCheque" onclick="radioCheque()"></td>
                                                    <td width="18%" height="21">&nbsp;No <input type="radio" name="radCheque" onclick="radioCheque()"></td>
                                                    <td width="32%" height="21"></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="dtds" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15">&nbsp;<font class="subheading">TDS</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="16%">&nbsp;</td>
                                                    <td width="34%">Yes <input type="radio" name="radTds" onclick="radioTds()"></td>
                                                    <td width="18%">&nbsp;No <input type="radio" name="radTds" onclick="radioTds()"></td>
                                                    <td width="32%"></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="dbank" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15">&nbsp;<font class="subheading">Bank
                                                    Staff</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="16%">&nbsp;</td>
                                                    <td width="34%">Yes <input type="radio" name="radBank" onclick="radioBank()"></td>
                                                    <td width="18%">&nbsp; No <input type="radio" name="radBank" onclick="radioBank()"></td>
                                                    <td width="32%"></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="dopinstr" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15">&nbsp;<font class="subheading">Operating
                                                    Instructions</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="17%">&nbsp;Current Status</td>
                                                    <td width="34%"><input name="txtOldinstr" size="14" disabled></td>
                                                    <td width="17%">&nbsp;Changed Status</td>
                                                    <td width="32%"><select size="1" name="cmbNewinstr" onchange="changeinstruction()">
                                                      <option selected>Select</option>
                                                      <option>IN</option>
                                                      <option>ES</option>
                                                      <option>FS</option>
                                                    </select></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="doptby" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                  <tr class="bgcolor">
                                                    <td width="100%" colspan="4" height="15">&nbsp;<font class="subheading">Operated
                                                    By</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="17%">&nbsp;Current Oper.</td>
                                                    <td width="33%"><input name="txtOperateold" readonly disabled size="20"></td>
                                                    <td width="18%">&nbsp;Changed Oper.</td>
                                                    <td width="32%"><input name="txtOperatenew" onblur="Opearatedby()" style="TEXT-TRANSFORM: capitalize" size="20"></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              <div id="djoint" style="DISPLAY: none">

                                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td width="612" colspan="6"><input name="txtTitle" class="bgcolor" style="BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #000080; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; FONT-WEIGHT: bold" size="20"></td>
                                                  </tr>
                                                  <tr class="bgcolor1">
                                                    <td width="85"></td>
                                                    <td width="143"><font class="textwhite"><input type="radio" name="radAdd" checked onclick="AddOrDelete()">
                                                    Add</font></td>
                                                    <td width="80"><font class="textwhite"><input type="radio" name="radAdd" onclick="AddOrDelete()">
                                                    Modify</font></td>
                                                    <td width="100"></td>
                                                    <td width="196" colspan="2"><font class="textwhite" <input type="radio" name="radAdd" onclick="AddOrDelete()">Delete</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="85">&nbsp;<span id="lblminor">Minor</span></td>
                                                    <td width="225" colspan="2"><input type="checkbox" name="chkJminor" value="ON"></td>
                                                    <td width="100">&nbsp;<span id="lbldob">Date
                                                    of Birth</span></td>
                                                    <td width="106"><input name="txtJminordob" size="14" readonly></td>
                                                    <td width="88">
                                                    <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="23" id="dtpJointdob" style="HEIGHT: 23px; LEFT: 0px; TOP: 0px; WIDTH: 37px" width="41">
                                                      <param name="_ExtentX" value="979">
                                                      <param name="_ExtentY" value="609">
                                                      <param name="_Version" value="393216">
                                                      <param name="MousePointer" value="0">
                                                      <param name="Enabled" value="1">
                                                      <param name="OLEDropMode" value="0">
                                                      <param name="CalendarBackColor" value="-2147483643">
                                                      <param name="CalendarForeColor" value="-2147483630">
                                                      <param name="CalendarTitleBackColor" value="-2147483633">
                                                      <param name="CalendarTitleForeColor" value="-2147483630">
                                                      <param name="CalendarTrailingForeColor" value="-2147483631">
                                                      <param name="CheckBox" value="1">
                                                      <param name="CustomFormat" value>
                                                      <param name="DateIsNull" value="0">
                                                      <param name="Format" value="662831105">
                                                      <param name="UpDown" value="0">
                                                      <param name="CurrentDate" value="37041">
                                                      <param name="MaxDate" value="2958465">
                                                      <param name="MinDate" value="-109205">
                                                    </object>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td width="85" height="29">&nbsp;Cust.
                                                    ID</td>
                                                    <td colspan="5" width="525" height="29"><input name="txtJointid" size="17" readonly><input name="butJointid" type="button" value=" L " onclick="customer()"><input name="txtJointdesc" size="39" readonly style="TEXT-TRANSFORM: uppercase">&nbsp;</td>
                                                  </tr>
                                                  <tr>
                                                    <td width="85" height="29">&nbsp;Relation</td>
                                                    <td width="225" colspan="2" height="29"><select size="1" name="cmbJrelation">
                                                      <option selected>Others</option>
                                                      <option>Father</option>
                                                      <option>Mother</option>
                                                      <option>Grand Father</option>
                                                      <option>Grand Mother</option>
                                                      <option>Uncle</option>
                                                      <option>Aunty</option>
                                                      <option>Brother</option>
                                                      <option>Brother-In-Law</option>
                                                      <option>Sister</option>
                                                      <option>Sister-In-Law</option>
                                                    </select></td>
                                                    <td width="100" height="29"></td>
                                                    <td width="196" colspan="2" height="29">

                                                    <table width="10%" cellspacing="0" cellpadding="0" class="tablebordermain">
                                                      <tr>
                                                        <td width="100%"><input name="butJointok" type="button" value="   Add   " onclick="Jointadd()" disabled class="bgcolor"></td>
                                                      </tr>
                                                    </table>

                                                    </td>
                                                  </tr>
                                                </table>

                                                <table border="0" cellspacing="0" cellpadding="0" width="60%">
                                                  <tr>
                                                    <td><iframe id=den align=center             
                        frameborder=0 framespacing=0 noresize 
                        height=100 width=690 scrolling=no
                                                      
                        valign="top" src     
                         ="changemasterdetails.asp" 
                                style="BACKGROUND-COLOR: darkred; HEIGHT: 190px; WIDTH: 600px" 
                               ></iframe></td>
                                                  </tr>
                                                </table>

                                              </div>
                                              </td>
                                            </tr>
                                          </tbody>
                                        </table>

                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>

                                  </td>
                                </tr>
                              </tbody>
                            </table>

                            </td>
                          </tr>
                        </table>

                        </td>
                      </tr>
                    </tbody>
                  </table>

                </div>
                </td>
              </tr>
            </tbody>
            <center>
            <tr>
              <td>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
                <tr>
                  <td width="100%">
                  <div align="center">
                    <center>

                    <table border="0" width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
                      <tr>
                        <td width="100%"><input name="butok" onclick="Save()" type="button" disabled value="    Ok    " class="bgcolor"><input name="butcancel" type="button" value=" Cancel " onclick="location.replace(&quot;changerequestmaster.asp&quot;)" class="bgcolor"><input id="Butexit" name="Butexit" onclick="window.close()" type="button" value="    Exit    " class="bgcolor"></td>
                      </tr>
                    </table>

                    </center>
                  </div>
                  </td>
                </tr>
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
              </table>

            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" height="15"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

          </center></td>
        </tr>
      </tbody>
    </table>

    </div>
  </center>
</form>

</body>

</html>
