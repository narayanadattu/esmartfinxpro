<%@ Page Language="vb" CodeBehind="Changerequestconfirmation.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Changerequestconfirmation2" %>
<HEAD>
</HEAD>
<%
'----------This form is used for Master Modifications  -----------------------	
	'declaration of array	
		dim Arrtrans()
					
	'declaration of recordset,object,returned message	
		dim rs,obj,Strmsg 				
		
	'-----------------declaration of recordset,object,returned message--------------			
		dim strcondition,condition,strwhere
		dim strinsert
	'-----------------getting the value  sent by client page	---------------------
		strcondition=Request.Form("hchange")
		strreturn=Request.Form("hreturn")																				

	'----------------------------spliting the value----------------------------	-----
		condition=split(strcondition,"|")	
		'Response.Write strreturn & "<br>"
		'Response.Write strcondition & "<br>"
		
		dim userid,machineid,applicationdate
		userid=session("userid")
		machineid=session("machineid")
		applicationdate=session("applicationdate")
		
	'-----------------------creating the recordset object------------------------------
	set rs=server.CreateObject("adodb.recordset")		
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets") 		
		
	''***************** Updating the values into database ********************
	
	'----------Building the condition for update the Master table--------------------------
	
		mastercondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"'"		
		
	'----------Building the condition for update  correspnding table--------------------------
	
		wherecondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and moduleid='"& condition(4)&"' and glcode='"&condition(5)&"' and accno='"& condition(6)&"'"		
				
	if condition(0)="Cheque" then	
		
		masterfields="chequebook,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition	
					
	elseif condition(0)="TDS" then	
		
		masterfields="tdsyn,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition
										
	elseif condition(0)="Bank" then	
		
		masterfields="bankstaffyn,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition									
	
	elseif condition(0)="Status" then	
		
		masterfields="status,narration,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'"&condition(8)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition		
	
	elseif condition(0)="Opinstr" then	
		
		masterfields="OPERATINGINSTR,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition	
		
	elseif condition(0)="Operateby" then	
		
		masterfields="OPERATEDBY,transtatus,userid,machineid,applicationdate"	
		mastervalues="'"&condition(7)&"'~'P'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
		Arrtrans(0,0)="U"
		Arrtrans(0,1)=condition(1)
		Arrtrans(0,2)=masterfields
		Arrtrans(0,3)=mastervalues
		Arrtrans(0,4)=mastercondition		
	
	elseif condition(0)="Joint" then			
		
		if condition(7)="Add" then 						
		
		strinsert=Request.Form("hinsert") 		
		insert=split(strinsert,"|")
		
		jointfields="branchcode,currencycode,moduleid,glcode,accno,jointholderid," _
		& "jointholdername,minoryn,minordob,relation,userid,machineid,applicationdate"			
		
		for inti= 1 to insert(0)
			jvalue=split(insert(inti),",")
		jointvalues=jointvalues & "|"& "'"&condition(2)&"','"&condition(3)&"','"&condition(4)&"'," _
		& " '"&condition(5)&"','"& condition(6)&"','"&jvalue(0)&"','"&jvalue(1)&"'," _
		& " '"&jvalue(2)&"','"& jvalue(3)&"','"&jvalue(4)&"'," _
		& "'"&userid&"','"&machineid&"','"&applicationdate&"'"
		
		next
		jointvalues=mid(jointvalues,2)		
		
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="I"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=jointfields
			Arrtrans(0,3)=jointvalues
			Arrtrans(0,4)=""
		
		'------------------- checking the mode  for Updation or Deletion-------------------
	elseif condition(7)="Modify" then 		
		
		'----------Building the condition for update the GencustJointHoldermst table--------------------------
	
		jointcondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and jointholderid='"& condition(8)&"'"		
		
		modify=split(Request.Form("hmodify"),"|")	 				
		jointfields="minoryn,minordob,relation,userid,machineid,applicationdate"			
		
		jointvalues="'"&modify(0)&"'~'"&modify(1)&"'~'"&modify(2)&"'" _
		& " ~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="U"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=jointfields
			Arrtrans(0,3)=jointvalues
			Arrtrans(0,4)=jointcondition					
			
	elseif condition(7)="Delete" then
		
		'----------Building the condition for update the GencustJointHoldermst table--------------------------
	
		jointcondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and jointholderid='"& condition(8)&"'"		
		
			redim Arrtrans(0,4)			
		
			Arrtrans(0,0)="D"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=""
			Arrtrans(0,3)=""
			Arrtrans(0,4)=jointcondition			
			
	  end if		
	  
'----------------------------Joint Holder Part Ends here-------------------------------

'---------------------------- Nominee Part starts here-------------------------------		
		
elseif condition(0)="Nominee" then			
		
	if condition(7)="Add" then 					
		
		strinsert=Request.Form("hinsert") 		
		insert=split(strinsert,"|")
		
		nomineefields="branchcode,currencycode,moduleid,glcode,accno,nomineeid," _
		& "nomineename,minoryn,minordob,relation,userid,machineid,applicationdate"					
			
		for inti= 1 to insert(0)		
			nvalue=split(insert(inti),",")
			nomineevalues=nomineevalues & "|"& "'"&condition(2)&"','"&condition(3)&"'," _
			& "'"&condition(4)&"','"&condition(5)&"','"& condition(6)&"','"&nvalue(0)&"'," _
			& "'"&nvalue(1)&"','"&nvalue(2)&"','"& nvalue(3)&"','"&nvalue(4)&"'," _
			& "'"&userid&"','"&machineid&"','"&applicationdate&"'"				
		
		next				
		nomineevalues=mid(nomineevalues,2)		
		
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="I"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=nomineefields
			Arrtrans(0,3)=nomineevalues
			Arrtrans(0,4)=""
		
		'------------------- checking the mode  for Updation or Deletion-------------------
	elseif condition(7)="Modify" then 		
		
		'----------Building the condition for update the GencustJointHoldermst table--------------------------
	
		nomineecondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and nomineeid='"& condition(8)&"'"		
		
		modify=split(Request.Form("hmodify"),"|")	 				
		nomineefields="minoryn,minordob,relation,userid,machineid,applicationdate"			
		
		nomineevalues="'"&modify(0)&"'~'"&modify(1)&"'~'"&modify(2)&"'" _
		& " ~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
			
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="U"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=nomineefields
			Arrtrans(0,3)=nomineevalues
			Arrtrans(0,4)=nomineecondition					
			
	elseif condition(7)="Delete" then
		
		'----------Building the condition for update the GenCustNomineeMst table--------------------------
	
		nomineecondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and nomineeid='"& condition(8)&"'"		
		
			redim Arrtrans(0,4)			
		
			Arrtrans(0,0)="D"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=""
			Arrtrans(0,3)=""
			Arrtrans(0,4)=nomineecondition			
			
	end if
'----------------------------Nominee Part Ends here-------------------------------
'----------------------------Guardian Part Starts here-------------------------------		
			
elseif condition(0)="Guard" then			
		
	if condition(7)="Add" then 					
		
		strinsert=Request.Form("hinsert") 		
		insert=split(strinsert,"|")		

		guardianfields="branchcode,currencycode,moduleid,glcode,accno,guardianid," _
		& "guardianname,relation,userid,machineid,applicationdate"								
		
			nvalue=split(insert(inti),",")
			
		guardianvalues="'"& condition(2)&"','"&condition(3)&"'," _
		& "'"&condition(4)&"','"&condition(5)&"','"& condition(6)&"'," _
		& "'"&nvalue(0)&"','"&nvalue(1)&"','"&nvalue(2)&"'," _
		& "'"&userid&"','"&machineid&"','"&applicationdate&"'"						
		
		guardianvalues=mid(guardianvalues,1)			
				
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="I"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=guardianfields
			Arrtrans(0,3)=guardianvalues
			Arrtrans(0,4)=""
		
		'------------------- checking the mode  for Updation or Deletion-------------------
	elseif condition(7)="Modify" then 		
		
		'----------Building the condition for update the GencustJointHoldermst table--------------------------
	
		guardiancondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and guardianid='"& condition(8)&"'"		
		
		modify=split(Request.Form("hmodify"),"|")
		guardianfields="relation,userid,machineid,applicationdate"			
		
		guardianvalues="'"&modify(0)&"'~'"&userid&"'~'"&machineid&"'~'"&applicationdate&"'"
		
			
		redim Arrtrans(0,4)			
								
			Arrtrans(0,0)="U"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=guardianfields
			Arrtrans(0,3)=guardianvalues
			Arrtrans(0,4)=guardiancondition			
			
			Response.Write guardianfields &"<br>"
			Response.Write guardianvalues&"<br>"
			Response.Write guardiancondition&"<br>"				
			
	elseif condition(7)="Delete" then
		
		'----------Building the condition for update the GenCustNomineeMst table--------------------------
	
		guardiancondition="branchcode='"&condition(2)&"' and currencycode='"& condition(3)&"'" _
		& " and glcode='"&condition(5)&"' and accno='"& condition(6)&"' " _
		& " and guardianid='"& condition(8)&"'"		
		
			redim Arrtrans(0,4)			
		
			Arrtrans(0,0)="D"
			Arrtrans(0,1)=condition(1)
			Arrtrans(0,2)=""
			Arrtrans(0,3)=""
			Arrtrans(0,4)=guardiancondition			
			
	end if
'----------------------------Nominee Part Ends here-------------------------------		
		
		
	end if
	
		Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")	
		Strmsg= obj.DataTransactions(Arrtrans)				
		strmsg=strmsg & "|"& strreturn
	'Response.Write strmsg	
	Response.Redirect "changerequestmaster.asp?record=" & strmsg	
	
	
  
%>
<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
