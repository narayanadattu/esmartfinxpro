<%@ Page CodeBehind="instrumentmst.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.instrumentmst" %>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>General Instrument</title>

<SCRIPT LANGUAGE=javascript>
<!--
//To Get bankcodes for Modification.
var Mode="Insert"
function Instrcode(){

	st="Instrcode"
	
	window.open("singlequery.asp" +"?"+"st="+st,st,"width=200%,height=150%,left=400%")
	
}

function Instrid(str){
	
	window.document.frminstr.txtinstrcode.value =str
	Getrecord()
	
}	
	
//To clear the Textboxes	


function Clearfields(){

	if(Mode=="Query")
	{
		window.document.frminstr.butok.disabled=true
		window.document.frminstr.txtinstrcode.readOnly=true
		window.document.frminstr.txtdesc.readOnly=true
	}
	else if(Mode=="Delete")
	{
		window.document.frminstr.txtinstrcode.readOnly=true
		window.document.frminstr.txtdesc.readOnly=true
		window.document.frminstr.butok.disabled=false
	}
	else if(Mode=="Modify")
	{
		window.document.frminstr.butok.disabled=false
		window.document.frminstr.txtinstrcode.readOnly=true
		
	}
	else
	{
		window.document.frminstr.butok.disabled=false
	}
	window.document.frminstr.txtinstrcode.value=""
	window.document.frminstr.txtdesc.value=""

}
	
	
//To Get record for modification based on bankcode.
	
function Getrecord(){
	
if(window.document.frminstr.txtinstrcode.value!="")
{
	st1="Instrrecord"
	st2=window.document.frminstr.txtinstrcode.value 
	st=st1+"|"+st2
	window.open("querydisplay.asp"+"?"+"st="+st,"record","width=100%,height=80%")
	
	
	}
}
function Getrecorddts(str){

	var strrec = new String()
	
	strrec=str.split("|")
	
	window.document.frminstr.txtdesc.value=strrec[0]
	
	if(strrec[1]!="")
	{
		if(strrec[1]=="N")
		{
			window.document.frminstr.radrem(1).checked=true
		}
		else
		{
			window.document.frminstr.radrem(0).checked=true
		}
	}
	
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
function Cmdcan(){
	
	location.replace("instrumentmst.asp")
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
function Insert(){

if(Mode=="Insert")
{
	if(window.document.frminstr.txtdesc.value !="" && window.document.frminstr.txtinstrcode.value!="")
	{
		window.document.frminstr.hidstatus.value=""	
		window.document.frminstr.hidstatus.value="INSERT"	
		window.document.frminstr.action="instrumentmstinsert.asp"
		window.document.frminstr.method ="post"
		window.document.frminstr.submit()
	}
	else
	{
		alert("Fields Should not be Null.")
	}
}
else if(Mode=="Modify")
{
  if(window.document.frminstr.txtinstrcode.value)
	{
	window.document.frminstr.hidstatus.value=""
	window.document.frminstr.hidstatus.value="MODIFY"
	window.document.frminstr.action="instrumentmstinsert.asp"
	window.document.frminstr.method ="post"
	window.document.frminstr.submit();
	}
	else
	{
		alert('Please Select Instrument Code')	
	}
	
}
else if(Mode=="Delete")
{
	if(window.document.frminstr.txtinstrcode.value)
	{
		window.document.frminstr.hidstatus.value=""
		window.document.frminstr.hidstatus.value="DELETE"
		window.document.frminstr.action="instrumentmstinsert.asp"
		window.document.frminstr.method ="post"
		window.document.frminstr.submit();
	}
	else
	{
		alert('Please Select Instrument Code')	
	}
	
}

}
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" bgcolor="#C7BA95">
<form name="frminstr">
  <input type="hidden" name="hidstatus">

  <table border="1" width="100%" bordercolor="#7D5445" cellspacing="0" cellpadding="0" height="480">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="11%" bgcolor="#7d5445"><img border="0" src="file://Comsvr/c/ASPTest/blanktextbox.gif" width="90" height="19"><img border="0" src="file://Comsvr/c/ASPTest/blanktextbox.gif" width="70" height="19"></td>
          <td width="89%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" bgcolor="#7d5445"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="257">
        <tr>
          <td width="100%" bgcolor="#7D5445" height="22">
          <p align="center"><font color="#FFFFFF" size="3" face="MS Sans Serif"><b>General
          Instrument Master</b></font></td>
        </tr>
        <tr>
          <td height="15" align="center"><font face="MS Sans Serif" color="blue" size="3"><%=Request.QueryString("record")%></font></td>
        </tr>
        <tr align="center">
          <td>
          <div align="center">
            <center>

            <table border="1" width="100%" bordercolor="#D9D2B3" cellspacing="0" cellpadding="0">
              <tr>
                <td width="23%" align="middle" bgcolor="#9c8769"><font color="#ffffff" size="2" face="MS Sans Serif"><input type="radio" name="rdtran" onclick='Mode="Insert";Clearfields()' checked>
                New</font></td>
                <td width="26%" align="middle" bgcolor="#9c8769"><font color="#ffffff" size="2" face="MS Sans Serif"><input type="radio" name="rdtran" onclick='Mode="Modify";Clearfields();Instrcode()'>
                Modify</font></td>
                <td width="26%" align="middle" bgcolor="#9c8769"><font color="#ffffff" size="2" face="MS Sans Serif"><input type="radio" name="rdtran" onclick='Mode="Delete";Clearfields();Instrcode()'>
                Delete</font></td>
                <td width="25%" align="middle" bgcolor="#9c8769"><font color="#ffffff" size="2" face="MS Sans Serif"><input type="radio" name="rdtran" onclick='Mode="Query";Clearfields();Instrcode()'>
                Query</font></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr align="center">
          <td></td>
        </tr>
        <tr>
          <td width="100%" height="136">
          <div align="center">
            <center>

            <table border="1" width="70%" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="28%" height="20"></td>
                    <td width="16%" height="20" colspan="2"></td>
                    <td width="23%" height="20" align="right" colspan="2"></td>
                    <td width="33%" height="20"></td>
                  </tr>
                  <tr>
                    <td width="28%" height="20"></td>
                    <td width="16%" height="20" colspan="2"></td>
                    <td width="23%" height="20" align="right" colspan="2"></td>
                    <td width="33%" height="20"></td>
                  </tr>
                  <tr>
                    <td width="28%" height="20"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    Instrument&nbsp; Code</font></td>
                    <td width="16%" height="20" colspan="2"><input type="text" name="txtinstrcode" size="10" maxlength="4"></td>
                    <td width="23%" height="20" align="right" colspan="2"><font size="2" face="MS Sans Serif">Description&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                    <td width="33%" height="20"><input type="text" name="txtdesc" size="20" maxlength="20"></td>
                  </tr>
                </center>
                <tr>
                  <td width="28%" height="20"></td>
                  <td width="20%" height="20" colspan="2"></td>
                  <td width="16%" height="20"></td>
                  <td width="36%" height="20" colspan="2"></td>
                </tr>
                <tr>
                  <td width="28%" height="20">
                  <p align="right"><font size="2" face="MS Sans Serif">Remittance&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                  <center>
                  <td width="10%" height="20"><font size="2" face="MS Sans Serif"><input type="radio" value="Y" name="radrem">
                  Yes</font></td>
                  <td width="10%" height="20"><font size="2" face="MS Sans Serif"><input type="radio" value="N" checked name="radrem">
                  No</font></td>
                  <td width="16%" height="20"></td>
                  <td width="36%" height="20" colspan="2"></td>
                  </tr>
                  <tr>
                    <td width="100%" height="20" colspan="6"></td>
                  </tr>
                  <tr>
                    <td width="100%" height="20" colspan="6"></td>
                  </tr>
                </table>

                </center></td>
            </tr>
            </table>

          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" height="21"></td>
        </tr>
        <tr>
          <td width="100%" height="31">
          <div align="center">
            <center>

            <table border="1" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%"><input type="button" value="    Ok    " name="butok" onclick="Insert()"><input type="button" value="Cancel" name="Cmdcancel" onclick="Cmdcan()"><input type="button" value="   Exit   " name="B2"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

</form>

</body>

</html>
