<%@ Page CodeBehind="chequedtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.chequedtls1" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Starting Cheque No</title>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmcheque">

  <table width="31%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="19%" align="center"><font class="textwhite">S.No</font></td>
          <td width="36%" align="center"><font class="textwhite">Starting Cheque No</font></td>
          <td width="35%" align="center">
          <p align="center"><font class="textwhite">Ending Cheque No</font></p>
          </td>
        </tr>
      </table>

      <div id="divcheque" align="center">
        <center>

        <table width="307" cellspacing="0" cellpadding="0" border="0">
        
          <%
  if len(TRIM(Request.Form("hidcheque")))>0 then

	modchestock=Request.Form("hidmodchestock")
	modchestart=Request.Form("hidmodchestart")

	'Response.Write	 modchestock &"<br>"
	
	chestock=split(modchestock,"*")
	
	totbklf=0
	
	for ichestock=1 to ubound(chestock)
	
		totbklf=totbklf+chestock(ichestock)
		
		'Response.Write totbklf&"total"
	next
	
	
	
	chestart=split(modchestart,"*")
	
	cheque=Request.Form("hidcheque")
	
	'Response.Write modchestart &"<br>"
	'Response.Write cheque &"<br>"

	booksleaves=split(cheque,"*")
	if ucase(booksleaves(0))="BOOK" then
			
			noofbkleas=booksleaves(1)
			leaperbook=booksleaves(2)-1
			brcode=booksleaves(3)
			modid=booksleaves(4)
			Instrcode=booksleaves(5)
			Bklfserno=booksleaves(6)
			Mode=booksleaves(7)
			'serno=booksleaves(8)
			'rembook=booksleaves(9)
			'Mode=booksleaves(10)
			bklfstart=chestart(1)

	elseif	ucase(booksleaves(0))="LEAF" then
	
			noofbkleas=booksleaves(1)
			leaperbook=0
			brcode=booksleaves(3)
			modid=booksleaves(4)
			Instrcode=booksleaves(5)
			Bklfserno=booksleaves(6)
			Mode=booksleaves(7)
			bklfstart=chestart(1)
										
	end if
	
if len(noofbkleas)>0 and len(leaperbook)>0  then

   	if  eval(noofbkleas)>1 then
   	
		if ucase(trim(Mode))="INSERT" or ucase(trim(Mode))="DELETE" or ucase(trim(Mode))="QUERY" then
			j=1
			for i=0 to eval(noofbkleas) - 1
				if i=cint(chestock(j)) and ubound(chestock)<>j then
					bklfstart=cint(chestart(j+1))
					j=j+1
				end if %>
          <tr>
            <td width="61" align="right"><%=i+1%>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqsno" size="15" style="height:18 px" onkeypress="numeric()" disabled value="<%=bklfstart%>"></p>
            </td>
            <td width="61">
					<%Endno=eval(leaperbook)+eval(bklfstart) %>
            <p align="center"><input type="text" name="txtchqeno" size="15" style="height:18 px" onkeypress="numeric()" value="<%=endno%>" disabled></p>
            </td>
          </tr>
					<%bklfstart=endno+1
			next
		elseif 	ucase(trim(Mode))="MODIFY" then
		 if eval(noofbkleas)<=eval(totbklf) then
		 j=1
		
			for i=0 to eval(noofbkleas) - 1 
				if i=cint(chestock(j)) and ubound(chestock)<>j then
					bklfstart=cint(chestart(j+1))
					j=j+1
				end if
					Endno=eval(leaperbook)+eval(bklfstart) %>
          <tr>
            <td width="61" align="right"><%=i+1%>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqsno" size="15" style="height:18 px" disabled value="<%=bklfstart%>"></p>
            </td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqeno" size="15" style="height:18 px" disabled value="<%=Endno%>"></p>
            </td>
          </tr>
			<%	bklfstart=endno+1
			next
			
		  elseif eval(noofbkleas)>eval(totbklf) then
		  j=1 
		  'Response.Write "chandu"
		  ' Response.Write noofbkleas
			for i=0 to eval(noofbkleas) - 1
			if i=cint(chestock(j)) and ubound(chestock)<>j then
					bklfstart=cint(chestart(j+1))
					j=j+1
				 Response.Write "chandu"
				end if
					Endno=eval(leaperbook)+eval(bklfstart) %> 
          <tr>
            <td width="61" align="right"><%=i+1%>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqsno" size="15" style="height:18 px" disabled value="<%=bklfstart%>"></p>
            </td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqeno" size="15" style="height:18 px" disabled value="<%=Endno%>"></p>
            </td>
          </tr>
			<%
			bklfstart=endno+1
			next
			
			if ucase(booksleaves(0))="BOOK" then
			
				set obj=Server.CreateObject("queryrecordsets.fetchrecordsets")	
				set rs=Server.CreateObject("adodb.recordset")
				set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","Bookstartno","upper(trim(branchcode))='" & ucase(trim(brcode)) & "' and " & _
					"upper(trim(bookseriesno))='" & ucase(trim(Bklfserno)) & "' and " & _
					"upper(trim(Instrcode))='" & ucase(trim(Instrcode)) & "' and " & _
					"upper(trim(moduleid))='" & ucase(trim(modid)) & "' and status='A' and " & _
					"leavesperbook='" & leaperbook+1 &"' and Accno IS NULL","Bookseriesno,to_number(Bookstartno)")
			
			
			
				set obj=nothing
			elseif ucase(booksleaves(0))="LEAF" then
				set obj=Server.CreateObject("queryrecordsets.fetchrecordsets")
				set rsleaf=Server.CreateObject("adodb.recordset")
				set rsleaf=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS", _
					 "LEAFNUMBER","upper(trim(branchcode))='"& ucase(trim(brcode)) &"' and " & _
					"upper(trim(LEAFSERIESNO))='" & ucase(trim(Bklfserno))& "' " & _
					"and upper(trim(INSTRCODE))='" & ucase(trim(Instrcode)) & "' " & _
					"and upper(trim(moduleid))='" & ucase(trim(modid)) & "'" & _
					"and Accno IS NULL","leafseriesno,to_number(leafnumber)")
				if not rsleaf.EOF then
					rsleaf.MoveFirst()
					stano=rsleaf(0)
				end if
				set obj=nothing
			end if
			'rembooks=cdbl(noofbkleas)-cdbl(totbklf)
			for bookleafi=i to eval(noofbkleas) - 1	
			if not rs.EOF then
			
			stano=rs(0)%>
          <tr>
            <td width="61" align="right"><%=bookleafi+1%>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqsno" size="15" style="height:18 px" disabled value="<%=stano%>"></p>
            </td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqeno" size="15" style="height:18 px" disabled value="<%=stano+leaperbook%>"></p>
            </td>
          </tr>
			<%
			rs.MoveNext()
			end if
			next
			set rs=nothing
			end if
		end if
	elseif eval(noofbkleas)=1 then%>
          <tr>
            <td width="61" align="right">1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqsno" size="15" style="height:18 px" onkeypress="numeric()" disabled value="<%=bklfstart%>"></p>
            </td>
            <td width="61">
            <p align="center"><input type="text" name="txtchqeno" size="15" style="height:18 px" onkeypress="numeric()" value="<%=bklfstart+leaperbook%>" disabled></p>
            </td>
          </tr>
		  <%end if
	end if
	end if%>
        </table>

        </center>
      </div>
      </td>
    </tr>
    <input type="HIDDEN" name="hidcheque"><input type="HIDDEN" name="hidleaves"><input type="hidden" name="hidmodchestock"><input type="hidden" name="hidmodchestart">
  </table>

</form>

</body>

</html>
