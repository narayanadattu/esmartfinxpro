<%@ Page Language="vb" CodeBehind="deptinstrstockdtlsinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_deptinstrstockdtlsinsert" %>
<%

'Variable Declaration
dim brcode,userid,modcode,inscode
dim rtype,serno,nol,lserno,endsno
dim nlpb,nobook,ssno
dim ddsno,deptrecdate,lendno
dim lstartno,nobooks,hidddsno
DIM Transarray(0,4)
dim rs
dim bookyesno
status=Request.Form("hidstatus")



	set rs=server.CreateObject("adodb.recordset")
	set rs1=server.CreateObject("adodb.recordset")
	brcode=Request.Form("txtbranchcode")
	userid=Request.Form("txtuserid")
	modcode=Request.Form("txtmodulecode")
	inscode=Request.Form("txtinstrcode")
	rtype=Request.Form("Radtype")
	nlpb=Request.Form("txtnoleavesperbook")
	nobook=Request.Form("txtnobook")
	ssno=Request.Form("txtssno")
	endsno=Request.Form("txtendsno")
	lserno=Request.Form("txtlserno")
	nol=Request.Form("txtnol")
	lstartno=Request.Form("txtlstartno")
	lendno=Request.Form("txtlendno")
	hsno=Request.Form("hsno")
	Response.Write hsno & "hsno"& "<br>"
	
	heno=Request.Form("heno")
	Response.Write heno & "heno" & "<br>"
	deptrecdate=session("Applicationdate")
	machid=session("machineid")
	nsno=split(Request.Form("nsno"),",")
	neno=split(Request.Form("neno"),",")
	
	
	if ucase(trim(rtype))="LEAF" then
	
		bookyesno="N"
		serno=Request.Form("txtlserno")
	else
		bookyesno="Y"
		serno=Request.Form("txtserno")
	
	end if
	
	if ucase(trim(inscode))="DD" and ucase(trim(rtype))="BOOK"	then
	
		if ucase(trim(rtype))="BOOK" then
			nobooks=Request.Form("txtnobook")
			bookyesno="Y"
		elseif ucase(trim(rtype))="LEAF" then
			nobooks=Request.Form("txtnol")
			bookyesno="N"
		end if
			hidddsno=Request.Form("hidddsno")
			ddsno=split(hidddsno,"|")
		dim Stno()
		redim Stno(nobooks-1)
		if trim(nobooks)>1 then
			for j= 0 to nobooks-1
				Stno(j)=ddsno(j+1)
			next
		else
		for j= 0 to nobooks-1
		  Stno(j)=hidddsno
		next
		end if
	end if
	
dim Obj,strmsg
if ucase(trim(status))="INSERT" then
	set Obj=server.CreateObject("DeptInstrInsert.BookLeafDeptInsert")
	IF len(trim(brcode))>0 and len(trim(userid))>0 and  len(trim(modcode))>0 and  len(trim(inscode))>0 and len(trim(rtype))>0 then
	
		if ucase(trim(rtype))="BOOK" and ucase(trim(inscode))="DD" then
			
			strmsg= OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"Y",cstr(nlpb),cstr(serno),cstr(ssno),cstr(endsno),"","","","",cstr(nobook),"",cstr(machid),cstr(machid),Stno)
			
		elseif ucase(trim(rtype))="BOOK" and ucase(trim(inscode))<>"DD" then
		
			strmsg= OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"Y",cstr(nlpb),cstr(serno),cstr(ssno),cstr(endsno),"","","","",cstr(nobook),"",cstr(machid),cstr(machid))
			
		elseif ucase(trim(rtype))="LEAF" then
		
			strmsg=OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"","","","","","Y",CSTR(lserno),CSTR(lstartno),CSTR(lendno),"",cstr(nol),cstr(machid),cstr(machid))
			
		end if
		set Obj=nothing
	'Response.Redirect "deptinstrstockdtls.asp?record=" & strmsg
	else	
	'Response.Redirect "deptinstrstockdtls.asp?record=Fields Should Not be Null"
			
	end if
elseif ucase(trim(status))="MODIFY" then
	Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
	set obj=server.CreateObject("instrcancel.deptcancel")
	
	
	
	for j=1 to ubound(nsno)
		if nobook=j then j=ubound(nsno)
		Response.Write cstr(BrCode) & " ,  " & cstr(Modcode) & " ,  " & cstr(InsCode) & "  , " & cstr(SerNo) & "  , " & cstr(NLPb) & "  , " & cstr(NoBook) & "  , " & cstr(nsno(j)) & " ,  " & cstr(neno(j)) & " ,  " & cstr(bookyesno) & " ,  " & cstr(userid)
		strmsg=obj.deptinstrcancel(cstr(BrCode), cstr(Modcode), cstr(InsCode),cstr(SerNo), cstr(NLPb), cstr(NoBook),cstr(nsno(j)),cstr(neno(j)),cstr(bookyesno),cstr(userid))
		
		
		Response.Write  "<br>" & nsno(j) & "<br>"
		Response.Write  "<br>" & neno(j) & "<br>"
	next
	Response.Write strmsg
	
	'if strmsg="Transaction Completed..." and ucase(inscode)="DD" then
		remvals=split(Request.Form("hidvals"),",")
		remenos=split(Request.Form("hidenos"),",")
		'Response.Write Request.Form ("hidvals")
		for i=1 to ubound(remvals)
			Transarray(0,0)="D"
			Transarray(0,1)="REMITDDDTLS"
			Transarray(0,2)=""
			Transarray(0,3)=""
			Transarray(0,4)="branchcode='" & cstr(brcode) & "' and moduleid='" & modcode & "' and  ddseriesno='" & cstr(serno) &"' and to_number(ddno)>=" & cint(remvals(i)) & " and to_number(ddno)<=" & cint(remenos(i))
			Response.Write transarray(0,4) &"<br>"
			strmsg=Objfrm.DataTransactions(Transarray)
			Response.Write strmsg
		next
	set Obj=nothing 
	'if 1=2 then
	set Obj=server.CreateObject("DeptInstrInsert.BookLeafDeptInsert")
	if len(trim(brcode))>0 and len(trim(userid))>0 and  len(trim(modcode))>0 and  len(trim(inscode))>0 and len(trim(rtype))>0 then
		if ucase(trim(rtype))="BOOK" and ucase(trim(inscode))="DD" then
			strmsg= OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"Y",cstr(nlpb),cstr(serno),cstr(ssno),cstr(endsno),"","","","",cstr(nobook),"",cstr(machid),cstr(machid),Stno)
		elseif ucase(trim(rtype))="BOOK" and ucase(trim(inscode))<>"DD" then
			strmsg= OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"Y",cstr(nlpb),cstr(serno),cstr(ssno),cstr(endsno),"","","","",cstr(nobook),"",cstr(machid),cstr(machid))
		elseif ucase(trim(rtype))="LEAF" then
			strmsg=OBJ.CustInstruments("GENDEPTCUSTINSTRSTOCKDTLS",CSTR(brcode),cstr(modcode),cstr(userid),cstr(session("Applicationdate")),cstr(deptrecdate),cstr(inscode),"","","","","","Y",CSTR(lserno),CSTR(lstartno),CSTR(lendno),"",cstr(nol),cstr(machid),cstr(machid))
		end if
		set Obj=nothing
	end if
	'end if
elseif ucase(trim(status))="DELETE" then
	
	Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
	Set obj=server.CreateObject("instrcancel.deptcancel")
	remvals=split(Request.Form("hidvals"),",")
	remenos=split(Request.Form("hidenos"),",")
	for j=1 to ubound(nsno)
		strmsg=obj.deptinstrcancel(cstr(BrCode), cstr(Modcode), cstr(InsCode),cstr(SerNo), cstr(NLPb), cstr(NoBook),cstr(nsno(j)),cstr(neno(j)),cstr(bookyesno),cstr(userid))
		if nobook=j then j=ubound(nsno)
		Response.Write  "<br>" & nsno(j) & "<br>"
		Response.Write  "<br>" & neno(j) & "<br>"
		Response.Write strmsg
	next
		for i=1 to ubound(remvals)
			Transarray(0,0)="D"
			Transarray(0,1)="REMITDDDTLS"
			Transarray(0,2)=""
			Transarray(0,3)=""
			Transarray(0,4)="branchcode='" & cstr(brcode) & "' and moduleid='" & modcode & "' and  ddseriesno='" & cstr(serno) &"' and to_number(ddno)>=" & cint(remvals(i)) & " and to_number(ddno)<=" & cint(remenos(i)) 
			strmsg=Objfrm.DataTransactions(Transarray)
		next
	set Obj=nothing 	
end if
Response.Write status
Response.Write strmsg 
Response.Redirect "deptinstrstockdtls.asp?record=" & strmsg


%>
