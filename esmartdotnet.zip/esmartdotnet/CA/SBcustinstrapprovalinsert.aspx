<%@ Page Language="vb" CodeBehind="SBcustinstrapprovalinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBcustinstrapprovalinsert" %>
<%
Dim Obj 'object variable.
Dim strmsg 
Dim brcode,inscode 'To store textbox values.
Dim Arrtrans(0,4) 
Dim flexval,flex,flexstr,transtr,str,strvalues
Dim modid,uid,leno,lserno,lsno,status
Dim ssno

'Storing Branch,Instrument details.

brcode=trim(Request.Form("txtbranchcode"))
inscode=trim(Request.Form("txtinstrcode"))
insdesc=trim(Request.Form("txtinstrdesc"))
status=trim(Request.Form("hidstatus"))
rtype=trim(Request.Form("Radtype"))
esno=trim(Request.Form("txtendchqno"))

nlpb=trim(Request.Form("txtnoleavesperbook"))
serno=trim(Request.Form("txtserno"))
ssno=trim(Request.Form("txtstchqno"))
modid=trim(Request.Form("txtmodulecode"))
moddesc=trim(Request.Form("txtmoduledesc"))
leno=trim(Request.Form("txtlendchqno"))
lserno=trim(Request.Form("txtlserno"))
lsno=trim(Request.Form("txtlstchqno"))
accno=trim(Request.Form("txtaccno"))
	
Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")				
if len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVEALL" then

	flexval=Request.Form("hidflex")
	flex=split(flexval,"*|*")
	
	for irow=1 to ubound(flex)
		flexstr=split(flex(irow),"~!~")
	if	len(flexstr(5))>0	then
		strwhere=strwhere & "trim(BRANCHCODE)='" & trim(brcode) & "' " & _
				"AND trim(MODULEID)='" & trim(flexstr(1)) & "' " & _
				"AND ACCNO='" & trim(flexstr(3)) & "' " & _
				"AND INSTRCODE='" & trim(flexstr(4)) & "' " & _
				"AND LEAVESPERBOOK='" & trim(flexstr(7)) & "' "& _
				"AND BOOKSERIESNO='" & trim(flexstr(5)) & "' "& _
				"AND BOOKSTARTNO='" & trim(flexstr(8)) & "' "& _
				"AND BOOKENDNO='" & trim(flexstr(9)) & "' " & _
				"AND STATUS='P'" &"|"
		
	elseif	len(flexstr(6))>0   then
	
		strwhere=strwhere & "trim(BRANCHCODE)='" & trim(brcode) & "' " & _
				 " AND trim(MODULEID)='" & trim(flexstr(1)) & "' " & _
				 "AND ACCNO='" & trim(flexstr(3)) & "' " & _
				 "AND INSTRCODE='" & trim(flexstr(4)) & "' " & _
				 "AND LEAFSERIESNO='" & trim(flexstr(6)) & "' " & _
				 "AND TO_NUMBER(LEAFNUMBER) BETWEEN '" & trim(flexstr(10)) & "'" & _
				 "AND '" & trim(flexstr(10)) & "' AND STATUS='P' " & "|"
		
	end if
		strvalues=strvalues &"'A'"&"|"
		
	next
		str="STATUS"
		
		strwhere=left(strwhere,len(strwhere)-1)
		strvalues=left(strvalues,len(strvalues)-1)
		
		Arrtrans(0,0)="U"
		'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
		'passing columns
		Arrtrans(0,2)=str
		'passing values
		Arrtrans(0,3)=strvalues
		'passing where condition
		Arrtrans(0,4)=strwhere
		
	Strmsg= OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc&"~!~"&modid&"~!~"&moddesc
	'Response.Write STRMSG
	Response.Redirect "SBcustinstrapproval.asp?result=" & result

elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVE" then
	
	if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND trim(MODULEID)='" & trim(modid) & "' AND ACCNO='" & trim(accno) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "' AND STATUS='P'"
		transtr="A"
		strvalues="'" & transtr & "'"
		str="STATUS"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "' AND MODULEID='" & trim(modid) & "' AND accno='" & trim(accno) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND to_number(LEAFNUMBER) BETWEEN '" & trim(lsno) & "' AND '" & trim(leno) & "' AND STATUS='P'"
		
		Response.Write strwhere
		
		transtr="A"
		strvalues="'" & transtr & "'"
		
		str="STATUS"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	end if
	Strmsg= OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc&"~!~"&modid&"~!~"&moddesc
	'Response.Write strmsg
	Response.Redirect "SBcustinstrapproval.asp?result=" & result
elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="REJECT" then
	
	if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND trim(MODULEID)='" & trim(modid) & "' AND accno='" & trim(accno) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "' AND STATUS='P'"
		transtr="R"
		strvalues="'" & transtr & "'"
		str="STATUS"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "' AND MODULEID='" & trim(modid) & "' AND ACCNO='" & trim(accno) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND to_number(LEAFNUMBER) BETWEEN '" & trim(lsno) & "' AND '" & trim(leno) & "' AND STATUS='P'"
		
		transtr="R"
		strvalues="'" & transtr & "'"
		
		str="STATUS"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
		
	end if
	Strmsg=OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc&"~!~"&modid&"~!~"&moddesc
	Response.Redirect "SBcustinstrapproval.asp?result=" & result 
else
	strmsg="Fields Should not be Null"
	result=strmsg&"~!~"&inscode&"~!~"&insdesc&"~!~"&modid&"~!~"&moddesc
	Response.Redirect "SBcustinstrapproval.asp?result=" & result
end if	
%>
