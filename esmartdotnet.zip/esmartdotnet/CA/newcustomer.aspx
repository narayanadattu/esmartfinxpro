<%@ Page CodeBehind="newcustomer.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.newcustomer1" %>
<html>
<%
strresult=Request.QueryString("result")
custid=Request.QueryString("custid")
record=Request.QueryString("record")
code=Request.QueryString("code")
'custid="99990100000000001"
%>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<link rel="stylesheet" type="text/css" href="../styletag.css">
<title>Customer Creation</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/NavBar.js"%>" ></script>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--


function dtpCustomer_CloseUp() {
Datepick(window.document.frmNewCustomer.dtpCustomer ,window.document.frmNewCustomer.txtDob)
st=window.document.frmNewCustomer.txtDob.value + "|" + "txtDob"
window.open("datecheck.asp"+"?"+"st="+st,"Mod","width=1%,height=1%,left=0,top=0") 
}

//-->
</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=dtpCustomer EVENT=CloseUp>
<!--
 dtpCustomer_CloseUp()
//-->
</SCRIPT>
</head>



<SCRIPT LANGUAGE=javascript>
<!--

function GetDateDif(str,str1)
{
if (eval(str)>0)
{
	alert("DOB should not be greater than application date..")
	if(str1=="txtDob")
		window.document.frmNewCustomer.txtDob.value=""
	

}
}


function GetType()
{
	st="CustType|Cust"
	window.open("ListCustomer.asp" + "?"+"st="+st,"CustType","width=250%,height=150% left=200 top=260")
}

function dispOccCode(str)
{
	if (str!="No Data Found..")
	{
		str=str.split("-----")
		window.document.frmNewCustomer.txtCustType.value=str[1]
		window.document.frmNewCustomer.txtCustTypedesc.value=str[0]
	}
}

function CheckResult()
{

var strresult=""
var strcon="nothing"
var record=""
record="<%=record%>"
strresult="<%=strresult%>"
custid="<%=custid%>"
if(custid.length>0)
{
st=custid
window.document.frmNewCustomer.txtName.disabled=true
window.document.frmNewCustomer.cmdCustType.disabled=true
window.document.frmNewCustomer.txtAddress1.disabled=true
window.document.frmNewCustomer.txtAddress2.disabled=true
window.document.frmNewCustomer.txtAddress3.disabled=true
window.document.frmNewCustomer.txtAddress4.disabled=true
window.document.frmNewCustomer.txtAddress5.disabled=true
window.document.frmNewCustomer.txtDob.disabled=true
window.document.frmNewCustomer.txtMail.disabled=true
window.document.frmNewCustomer.txtphone1.disabled=true
window.document.frmNewCustomer.txtphone2.disabled=true
window.document.frmNewCustomer.txtphone3.disabled=true
window.document.frmNewCustomer.txtMobile.disabled=true
window.document.frmNewCustomer.txtFax.disabled=true
window.document.frmNewCustomer.chkMinor.disabled=true
window.document.frmNewCustomer.txtCustType.disabled=true
window.document.frmNewCustomer.txtCustTypedesc.disabled=true
window.document.frmNewCustomer.dtpCustomer.Enabled=false
window.open("customerfly.asp"+"?"+"st="+st,"CustFly","width=10%,height=1%,left=0,top=0")  		
return
}
if(record.length>0)
{
var str,str1
	
	window.attachEvent(window.opener.NewCustDisplay(record.toUpperCase())) 
	
	strcon=window.confirm("Do you want to enter more Customer details....")
	if(strcon==true)
	{
		window.open("customer.asp"+"?"+"record="+record,"CustomerDetails","width=800,height=600,left=0,top=0")  		
	}
	window.close()
}
	
}

function Display(str)
{
if(str.length>0)
{	
	if (str=="")
	{
		alert(str)
		window.close()
		return
	}
	str=str.split("|")
	window.document.frmNewCustomer.txtName.value=str[15]
	window.document.frmNewCustomer.txtCustType.value=str[14]
	
	if (str[14].length>0)
		window.document.frmNewCustomer.txtCustTypedesc.value=str[16]
	window.document.frmNewCustomer.txtAddress1.value=str[1]
	window.document.frmNewCustomer.txtAddress2.value=str[2]
	window.document.frmNewCustomer.txtAddress3.value=str[3]
	window.document.frmNewCustomer.txtAddress4.value=str[4]
	window.document.frmNewCustomer.txtAddress5.value=str[5]
	window.document.frmNewCustomer.txtMail.value=str[6]
	window.document.frmNewCustomer.txtphone1.value=str[7]
	window.document.frmNewCustomer.txtphone2.value=str[8]
	window.document.frmNewCustomer.txtphone3.value=str[9]
	window.document.frmNewCustomer.txtMobile.value=str[10]
	window.document.frmNewCustomer.txtFax.value=str[11]
	window.document.frmNewCustomer.txtDob.value=str[12]
	if(str[13]=="Y")
		window.document.frmNewCustomer.chkMinor.checked==true
	else
		window.document.frmNewCustomer.chkMinor.checked==false
	
}

}
function Checksymbols() 
{
var indx
var indy
	
	if (window.document.frmNewCustomer.txtMail.value!="")
	{
	indx=window.document.frmNewCustomer.txtMail.value.split("@")
	if (indx.length>2)
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	indy=window.document.frmNewCustomer.txtMail.value.split(".")
	if (indy.length>3)
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	indy=window.document.frmNewCustomer.txtMail.value.lastIndexOf(".")
	indx=window.document.frmNewCustomer.txtMail.value.length
	if(indy==indx-1) 
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	indx=window.document.frmNewCustomer.txtMail.value.indexOf("@") // Take the index of "@"
	if ((indx==-1)||(indx==0))  // if "@" is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	indy=window.document.frmNewCustomer.txtMail.value.indexOf(".") // Take the index of "."

	if ((indx==-1)||(indx==0))  // if "." is not found
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	if ((indy==indx+1)||(indy<indx))
		{
			alert ("Enter valid mailid...!")
			window.document.frmNewCustomer.txtMail.focus() 
			return
		}
	}
}

function Ok()
{
if(window.document.frmNewCustomer.txtName.disabled==true)
{
	window.close()
	return
}
var code="<%=code%>"
code=code.split("@@")
var brcode="'"+code[0]+"'"
var crcode="'"+code[1]+"'"
window.document.frmNewCustomer.hidbrcrcode.value=code[0]+"~~"+code[1]+"~~"+code[2]+"~~"+code[3]
var stname=window.document.frmNewCustomer.txtName.value
var address=window.document.frmNewCustomer.txtAddress1.value
var dob=window.document.frmNewCustomer.txtDob.value 
var address2="'" + window.document.frmNewCustomer.txtAddress2.value + "'"
var address3="'" +window.document.frmNewCustomer.txtAddress3.value + "'"
var address4="'" +window.document.frmNewCustomer.txtAddress4.value + "'"
var address5="'" +window.document.frmNewCustomer.txtAddress5.value + "'"
var emailid="'" +window.document.frmNewCustomer.txtMail.value +"'"
var phone1="'" + window.document.frmNewCustomer.txtphone1.value +"'"
var phone2="'" + window.document.frmNewCustomer.txtphone2.value +"'"
var phone3="'" + window.document.frmNewCustomer.txtphone3.value +"'"
var mobile="'" + window.document.frmNewCustomer.txtMobile.value +"'"
var fax="'" + window.document.frmNewCustomer.txtFax.value +"'"
var typeid= window.document.frmNewCustomer.txtCustType.value 

if(window.document.frmNewCustomer.chkMinor.checked==false)
	var minoryn="'N'"
else
	var minoryn="'Y'"

if(window.document.frmNewCustomer.chkGlobal.checked==true)
	window.document.frmNewCustomer.hidGlobal.value="Y"
else
	window.document.frmNewCustomer.hidGlobal.value="N"

if((stname.length==0) || (address.length==0) || (dob.length==0)||(typeid.length=0))
{
	alert("Manditory fields should not be null...")
	return
}
					
var mainstr="'" + stname + "','" + address + "'," + address2 + "," + address3 + "," + 
			address4 + "," + address5 + ","+ emailid + "," + phone1 + ", " +
			phone2 + "," + phone3 + "," + mobile + "," + fax + ",'" + dob + "'," + minoryn +
			","+typeid +"," +brcode +","+crcode
			
window.document.frmNewCustomer.hidcustvals.value=mainstr
window.document.frmNewCustomer.action ="newcustomerinsert.asp"
window.document.frmNewCustomer.method="POST"
window.document.frmNewCustomer.submit()

}


//-->
</SCRIPT>

<body topmargin="0" leftmargin="0" onload="CheckResult()">

<form name="frmNewCustomer">
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <input type="hidden" name="hpr"><input type="hidden" name="hVoucherno">

  <table border="0" width="52%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr class="bgcolor">
      <td width="100%" colspan="4" align="center" height="20"><font class="subheading">Customer
        Master</font></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;Name</td>
      <td width="90%" colspan="3"><input type="text" name="txtName" size="37" maxlength=50 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtName)></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;Type</td>
      <td width="90%" colspan="3"><input type="text" name="txtCustType" size="5" maxlength=10 onkeypress="phonenumeric()"><input type="button" value=" L " name="cmdCustType" onclick='GetType()'><input type="text" name="txtCustTypedesc" size="27"  maxlength=15 onkeypress="phonenumeric()" style="text-transform:capitalize"></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;Address</td>
      <td width="90%" colspan="3"><input type="text" name="txtAddress1" size="37" maxlength=30 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtAddress1)></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;</td>
      <td width="90%" colspan="3"><input type="text" name="txtAddress2" size="37" maxlength=30 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtAddress2)></td>
    </tr>
    <tr>
      <td width="44%"></td>
      <td width="90%" colspan="3"><input type="text" name="txtAddress3" size="37" maxlength=30 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtAddress3)></td>
    </tr>
    <tr>
      <td width="44%"></td>
      <td width="90%" colspan="3"><input type="text" name="txtAddress4" size="37" maxlength=30 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtAddress4)></td>
    </tr>
    <tr>
      <td width="44%"></td>
      <td width="90%" colspan="3"><input type="text" name="txtAddress5" size="37" maxlength=30 style="text-transform:capitalize" onblur=TrimSpace(window.document.frmNewCustomer.txtAddress5)></td>
    </tr>
    <tr>
      <td width="44%">E-mail Id</td>
      <td width="90%" colspan="3"><input type="text" name="txtMail" size="37" maxlength=30 onblur="Checksymbols()" onkeypress="chkmailchar()" onblur=TrimSpace(window.document.frmNewCustomer.txtMail)></td>
    </tr>
    <tr>
      <td width="44%">Phone No. Off</td>
      <td width="90%" colspan="3"><input type="text" name="txtphone1" size="10" maxlength=10 onkeypress="phonenumeric()"><input type="text" name="txtphone2" size="10"  maxlength=10 onkeypress="phonenumeric()" style="text-transform:capitalize">&nbsp;&nbsp;&nbsp;
        R<input type="text" name="txtphone3" size="10"  maxlength=10 onkeypress="phonenumeric()"></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;Mobile</td>
      <td width="34%" colspan="2"><input type="text" name="txtMobile" size="15"  maxlength=15 onkeypress="phonenumeric()" style="text-transform:capitalize"></td>
      <td width="56%"></td>
    </tr>
    <tr>
      <td width="44%">&nbsp;Fax</td>
      <td width="34%" colspan="2"><input type="text" name="txtFax" size="15"  maxlength=15 onkeypress="phonenumeric()" style="text-transform:capitalize"></td>
      <td width="56%">&nbsp; Global Customer&nbsp; <input type="checkbox" name="chkGlobal" value="ON" >
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td width="44%">&nbsp;DOB&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td width="21%"><input type="text" name="txtDob" size="9" readonly onblur=TrimSpace(window.document.frmNewCustomer.txtDob)></td>
      <td width="13%">
      <OBJECT classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height=23 id=dtpCustomer 
	name=dtpbillDate style="LEFT: -1px; TOP: 0px" width=21>
	<PARAM NAME="_ExtentX" VALUE="556">
	<PARAM NAME="_ExtentY" VALUE="609">
	<PARAM NAME="_Version" VALUE="393216">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="Enabled" VALUE="1">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CheckBox" VALUE="0">
	<PARAM NAME="CustomFormat" VALUE="">
	<PARAM NAME="DateIsNull" VALUE="0">
	<PARAM NAME="Format" VALUE="662831107">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="CurrentDate" VALUE="36086.5351157407">
	<PARAM NAME="MaxDate" VALUE="2958465">
	<PARAM NAME="MinDate" VALUE="-109205"></OBJECT>
      </td>
      <td width="56%">
      &nbsp; Minor&nbsp;&nbsp;<input type="checkbox" name="chkMinor" value="ON" >
      </td>
    </tr>
    <tr>
      <td width="131%" colspan="4">&nbsp;&nbsp;&nbsp;&nbsp; 
        <div align="center">
          <center>
          <table border="1" cellpadding="0" cellspacing="0" class="tablebordermain" width="125">
            <tr>
              <td width="120">
                <p align="center"><input type="button" value="   Ok   " name="cmdOk" class="bgcolor" onclick="Ok()"><input type="button" value="Cancel" name="cmdCancel" class="bgcolor" onclick="window.close()"></td>
            </tr>
          </table>
          </center>
        </div>
      </td>
    </tr>
  </table>
<input type="hidden" name="hidcustvals">
<input type="hidden" name="hidGlobal">
<input type="hidden" name="hidbrcrcode">
</form>

</body>

</html>
