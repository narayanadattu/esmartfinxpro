<%@ Page Language="vb" CodeBehind="instrstockdtlsinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Instrstockdtlsinsert" %>
<%
	dim Obj,Objmod,strmsg,strmod
	dim ArrTrans(0,4)
	
	set rsinsert=server.CreateObject("adodb.recordset")
	set Obj=server.CreateObject("GeneralTransactions.DBTransactions")

	stno=Request.Form("hidstno")
	edno=Request.Form("hidedno")
	
	branchcode=trim(Request.Form("txtbranchcode"))
	instrcode=trim(Request.Form("txtinstrcode"))
	instrdesc=trim(Request.Form("txtinstrdesc"))
	radtype=trim(Request.Form("Radtype"))
	sno=ucase(trim(Request.Form("txtsno")))
	nlpbook=trim(Request.Form("txtnlpbook"))
	noofbook=trim(Request.Form("txtnoofbook"))
	startno=trim(Request.Form("txtstartno"))
	endno=trim(Request.Form("txtendno"))
	lsno=ucase(trim(Request.Form("txtlsno")))
	lstartno=trim(Request.Form("txtlstartno"))
	noofleaves=trim(Request.Form("txtnoofleaves"))
	lendno=trim(Request.Form("txtlendno"))
	status=trim(Request.Form("hidstatus"))
	userid=session("userid")
	macid=session("machineid")
	appdate=session("applicationdate")
	
	
if len(trim(instrcode))>0 and len(trim(branchcode))>0 and len(trim(radtype))>0 then
	
	if ucase(trim(status))="INSERT" then
	
	if radtype="Book" then
	'for book
		str="BRANCHCODE,INSTRCODE,INSTRNAME,BOOKYESNO,BOOKSERIESNO,LEAVESPERBOOK,NOOFBOOKS,BOOKSTARTNO,BOOKENDNO,STATUS,TRANSTATUS,USERID,MACHINEID,STOCKRECEIVEDDATE,APPLICATIONDATE"
	
		strvalues="'" & branchcode & "','" & instrcode & "','" & instrdesc & "','Y','" & sno & "','" & nlpbook &"','" & noofbook & "','" & startno & "','" & endno & "','STOCK','P','" & userid & "','" & macid & "','" & appdate & "','" & session("applicationdate") &"'"
		
	elseif radtype="Leaf" then
	'for leaf
		str="BRANCHCODE,INSTRCODE,INSTRNAME,LEAFYESNO,LEAFSERIESNO,NOOFLEAVES,LEAFSTARTNO,LEAFENDNO,STATUS,TRANSTATUS,USERID,MACHINEID,STOCKRECEIVEDDATE,APPLICATIONDATE"
		
		strvalues="'" & branchcode & "','" & instrcode & "','" & instrdesc & "','Y','" & lsno & "','" & noofleaves &"','" & lstartno & "','" & lendno & "','STOCK','P','" & session("userid") & "','" & session("machineid") & "','" & session("applicationdate") & "','" & session("applicationdate") &"'"
	end if

		ArrTrans(0,0)="I"
'passing the table name
		ArrTrans(0,1)="GENINSTRUMENTSTOCKDTLS"
'passing columns
		ArrTrans(0,2)=str
'passing values
		ArrTrans(0,3)=strvalues
'passing where condition
		ArrTrans(0,4)=""
	
		Strmsg= OBJ.DataTransactions(ArrTrans)

elseif ucase(trim(status))="MODIFY" then

if radtype="Book" then
	strvalues=""
	strvalues="'" &  noofbook & "'~'" & startno & "'~'" & endno &"'"
	str="NOOFBOOKS,BOOKSTARTNO,BOOKENDNO"
	strwhere="upper(trim(branchcode))='" & branchcode &"' and  trim(INSTRCODE)='"& trim(instrcode) &"' and  LEAVESPERBOOK='" & nlpbook &"' and BOOKYESNO='Y' AND UPPER(TRIM(BOOKSERIESNO))='" & sno &"' AND BOOKSTARTNO='" & stno &"' AND  BOOKENDNO='" & edno &"'" 
	
elseif  radtype="Leaf" then

	strvalues=""
	strvalues="'" &  noofleaves & "'~'" & lstartno & "'~'" & lendno &"'"
	str="noofleaves,LEAFSTARTNO,LEAFENDNO"
	strwhere="upper(trim(branchcode))='" & branchcode &"' and  trim(INSTRCODE)='"& trim(instrcode) &"' and LEAFYESNO='Y' AND UPPER(TRIM(LEAFSERIESNO))='" & lsno &"' AND LEAFSTARTNO='" & stno &"' AND  LEAFENDNO='" & edno &"'" 
end if
	
	
	ArrTrans(0,0)="U"
'passing the table name
	ArrTrans(0,1)="GENINSTRUMENTSTOCKDTLS"
'passing columns
	ArrTrans(0,2)=str
'passing values
	ArrTrans(0,3)=strvalues
'passing where condition
	ArrTrans(0,4)=strwhere
	
	Strmsg= OBJ.DataTransactions(ArrTrans)

elseif ucase(trim(status))="DELETE" then

if radtype="Book" then
	
	strwhere="upper(trim(branchcode))='" & branchcode &"' and  trim(INSTRCODE)='"& trim(instrcode) &"' and BOOKYESNO='Y' AND LEAVESPERBOOK='" & nlpbook &"' and UPPER(TRIM(BOOKSERIESNO))='" & sno &"' AND BOOKSTARTNO='" & startno &"' AND TRANSTATUS<>'A' AND BOOKENDNO='" & endno &"'" 

elseif  radtype="Leaf" then

	strwhere="upper(trim(branchcode))='" & branchcode &"' and  trim(INSTRCODE)='"& trim(instrcode) &"' and LEAFYESNO='Y' AND UPPER(TRIM(LEAFSERIESNO))='" & lsno &"' AND LEAFSTARTNO='" & lstartno &"' AND  TRANSTATUS<>'A' AND LEAFENDNO='" & lendno &"'" 
end if
	
	STR=""
	ArrTrans(0,0)="D"
'passing the table name
	ArrTrans(0,1)="GENINSTRUMENTSTOCKDTLS"
'passing columns
	ArrTrans(0,2)=""
'passing values
	ArrTrans(0,3)=""
'passing where condition
	ArrTrans(0,4)=strwhere
	
	Strmsg= OBJ.DataTransactions(ArrTrans)

end if
set obj=nothing
	Response.Redirect "instrstockdtls.asp?record=" & strmsg
else
	Response.Redirect "instrstockdtls.asp?record=Fields Should Not be Empty." & strmsg
end if

%>