<%@ Page Language="vb" CodeBehind="Singlequery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Singlequery" %>
<%  strType=Request.QueryString("st")  %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>e-SMART</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE="javascript">

function load(){

	window.document.frmList.cmbList.focus()
	
}
function List()
{

var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
	{
		alert("Select Any Code") 
	}
else
   {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	if (type.substring(0,9)=="Instrcode")
		{
		window.attachEvent(window.opener.Instrid(str))
		window.close()
		}
	else if (type.substring(0,12)=="Leafseriesno")
		{
			window.attachEvent(window.opener.leafseries(str))
			window.close()
		}
	else if (type.substring(0,12)=="Bookseriesno")
		{
			window.attachEvent(window.opener.bookseries(str))
			window.close()
		}
		else if (type.substring(0,14)=="DeptLeafseries")
		{
			window.attachEvent(window.opener.Leafseriesmod(str))
			window.close()
		}
	else if (type.substring(0,10)=="Deptmodify")
		{
			window.attachEvent(window.opener.Leafseriesmod(str))
			window.close()
		}
	else if (type.substring(0,10)=="Leafmodify")
		{
			window.attachEvent(window.opener.Leafseriesmod(str))
			window.close()
		}
	else if (type.substring(0,10)=="Seriesleaf")
		{
			window.attachEvent(window.opener.leafser(str))
			window.close()
		}
	}
}
</SCRIPT>
<%
dim obj,rs,sname
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  set rs=server.CreateObject("adodb.recordset")

if left(strType,9)="Instrcode" then
	
	sname="Instrcode"
	
	set rs=obj.singlerecordset("GENINSTRUMENTMST","INSTRCODE","","INSTRCODE")
	
elseif left(strType,12)="Bookseriesno" then
	
	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","DISTINCT BOOKSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and bookyesno='Y'","BOOKSERIESNO")

elseif left(strType,12)="Leafseriesno" then
	
	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","DISTINCT LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and leafyesno='Y'","LEAFSERIESNO")
elseif left(strType,10)="Deptmodify" then
	
	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","DISTINCT BOoKSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and bookyesno='Y' and ISSUEDTO='" & K(3) &"' and MODULEID='" & k(4) &"' and TRANSSTATUS ='P'","bookSERIESNO")
elseif left(strType,10)="Leafmodify" then
	
	k=split(strType,"|")
	
	'set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","DISTINCT LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and leafyesno='Y' and ISSUEDTO='" & K(3) &"' and MODULEID='" & k(4) &"' and TRANSSTATUS ='P'","LEAFSERIESNO")
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","DISTINCT LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and leafyesno='Y' and ISSUEDTO='" & K(3) &"' and MODULEID='" & k(4) &"'","LEAFSERIESNO")

elseif left(strType,14)="DeptLeafseries" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","distinct LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and LEAFYESNO='Y' and status<>'ISSUED'","LEAFSERIESNO")
	

elseif left(strType,10)="Seriesleaf" then
	
	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","distinct LEAFSERIESNO","branchcode='" & k(1) & "' and  moduleid='" & k(2)& "' and instrcode='" &  K(3) & "' and leafyesno='Y'","LEAFSERIESNO")
	
end if

%>
</head>
<body bgcolor="#643428" onload="load()">

<form name="frmList">
  <div align="center">
    <center>

    <table border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
      <tr class="bgcolor">
        <th style="FONT-SIZE:xx-small"><font class="textbold">&nbsp;<%=ucase(sname)%>&nbsp;NO</font></th>
      <tr>
        <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	      <%  
	 if rs.EOF<>true and rs.BOF<>true then
	do until rs.EOF
	if rs.Fields.Count < 2 then%>
          <option><%=rs(0)%></option>
	      <%else%>
          <option><%=rs(0) & "----" & rs(1) &"----" & rs(2)%></option>
	      <%end if%>
	      <%rs.MoveNext
  loop
  Response.Write "<script language=vbscript>"& chr(13)
  Response.Write "window.document.frmList.cmblist.item(0).selected=true" & chr(13)
  Response.Write "</script>" & chr(13)
  end if
  set rs=nothing
  set obj=nothing
          %>     
        </select></td>
      </tr>
    </table>

    </center>
  </div>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor"></center>
</form>

</body>

</html>
