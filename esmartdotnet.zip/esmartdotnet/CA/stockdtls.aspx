<%@ Page Language="vb" CodeBehind="stockdtls.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_stockdtls" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function stockdtls()
//if ucase(trim(window.document.frmstock.hidstatus.value))
{
if(window.document.frmstock.hidtype.value=="BOOK")
{	
	i=1
	
	window.parent.window.document.frmdepins.txtnobook.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
	window.parent.window.document.frmdepins.txtssno.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
	window.parent.window.document.frmdepins.hsno.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
	window.parent.window.document.frmdepins.heno.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
	window.parent.window.document.frmdepins.txtendsno.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
	if (window.document.frmstock.hidstatus.value=="MODIFY" )
		{
			window.parent.window.document.frmdepins.hidnoofbl.value=window.document.frmstock.stockdtls.TextMatrix(i,3)
			window.parent.window.document.frmdepins.hidnobooks.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
			window.parent.window.document.frmdepins.hidblstart.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
			window.parent.window.document.frmdepins.hidblend.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
			stbra=window.parent.window.document.frmdepins.txtbranchcode.value
			stins=window.parent.window.document.frmdepins.txtinstrcode.value
			stser=window.parent.window.document.frmdepins.txtserno.value
			stuser=window.parent.window.document.frmdepins.txtuserid.value
			stmod=window.parent.window.document.frmdepins.txtmodulecode.value
			stlpb=window.parent.window.document.frmdepins.txtnoleavesperbook.value
			//stnoofb=window.parent.window.document.frmdepins.txtnobook.value
			stnoofb=window.document.frmstock.stockdtls.TextMatrix(i,0)
			//'stsno=window.parent.window.document.frmdepins.txtssno.value
			stsno=window.document.frmstock.stockdtls.TextMatrix(i,1)
			//'steno=window.parent.window.document.frmdepins.txtendsno.value
			steno=window.document.frmstock.stockdtls.TextMatrix(i,2)
			window.parent.window.document.frames(1).frmdd.hiddd.value="book"+"*"+"MODIFY"+"*"+stbra+"*"+stuser+"*"+stmod+"*"+stins+"*"+stser+"*"+stlpb+"*"+stnoofb+"*"+stsno+"*"+steno
			window.parent.window.document.frames(1).frmdd.action="../GENSBCA/dddtls.aspx"
			window.parent.window.document.frames(1).frmdd.method="post"
			window.parent.window.document.frames(1).frmdd.submit()
		}
	else(window.document.frmstock.hidstatus.value=="INSERT" )
		{
			window.parent.window.document.frmdepins.hidnoofbl.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
			for(i=1;i<=window.document.frmstock.stockdtls.Rows;i++)
			{
			stx=st+"|"+window.document.frmstock.stockdtls.TextMatrix(i,0)
			sty=st1+"|"+window.document.frmstock.stockdtls.TextMatrix(i,1)
			window.parent.window.document.frmdepins.hiddata.value=stx+"@"+sty
			}
			
			st=window.document.frmstock.stockdtls.TextMatrix(i,0)
		
		
		}
		
		
		
		window.parent.window.document.frmdepins.txtnobook.focus()
		window.parent.window.document.frmdepins.txtnobook.select()
}
else(window.document.frmstock.hidtype.value=="LEAF")
{
	i=window.document.frmstock.stockdtls.row
	window.parent.window.document.frmdepins.txtnol.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
	window.parent.window.document.frmdepins.txtlstartno.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
	window.parent.window.document.frmdepins.txtlendno.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
	window.parent.window.document.frmdepins.hidnoofbl.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
	window.parent.window.document.frmdepins.hsno.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
	window.parent.window.document.frmdepins.heno.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
	
	if (window.document.frmstock.hidstatus.value=="MODIFY" )
		{
			window.parent.window.document.frmdepins.hidnoofbl.value=window.document.frmstock.stockdtls.TextMatrix(i,3)
			window.parent.window.document.frmdepins.hidblstart.value=window.document.frmstock.stockdtls.TextMatrix(i,1)
			window.parent.window.document.frmdepins.hidblend.value=window.document.frmstock.stockdtls.TextMatrix(i,2)
			stbra=window.parent.window.document.frmdepins.txtbranchcode.value
			stins=window.parent.window.document.frmdepins.txtinstrcode.value
			stser=window.parent.window.document.frmdepins.txtserno.value
			stuser=window.parent.window.document.frmdepins.txtuserid.value
			stmod=window.parent.window.document.frmdepins.txtmodulecode.value
			stlpb=window.parent.window.document.frmdepins.txtnoleavesperbook.value
			//stnoofb=window.parent.window.document.frmdepins.txtnobook.value
			stnoofb=window.document.frmstock.stockdtls.TextMatrix(i,0)
			//'stsno=window.parent.window.document.frmdepins.txtssno.value
			stsno=window.document.frmstock.stockdtls.TextMatrix(i,1)
			//'steno=window.parent.window.document.frmdepins.txtendsno.value
			steno=window.document.frmstock.stockdtls.TextMatrix(i,2)
			window.parent.window.document.frames(1).frmdd.hiddd.value="book"+"*"+"MODIFY"+"*"+stbra+"*"+stuser+"*"+stmod+"*"+stins+"*"+stser+"*"+stlpb+"*"+stnoofb+"*"+stsno+"*"+steno
			window.parent.window.document.frames(1).frmdd.action="../GENSBCA/dddtls.aspx"
			window.parent.window.document.frames(1).frmdd.method="post"
			window.parent.window.document.frames(1).frmdd.submit()
		}
	else(window.document.frmstock.hidstatus.value=="INSERT" )
		{
			window.parent.window.document.frmdepins.hidnoofbl.value=window.document.frmstock.stockdtls.TextMatrix(i,0)
		}
		
		window.parent.window.document.frmdepins.txtnobook.focus()
		window.parent.window.document.frmdepins.txtnobook.select()
	
}
}

//-->
</SCRIPT>
<title></title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmstock">
  <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="131" id="stockdtls" style="HEIGHT: 131px; LEFT: 53px; TOP: 15px; WIDTH: 280px" width="280">
    <param name="_ExtentX" value="7408">
    <param name="_ExtentY" value="3466">
    <param name="_Version" value="393216">
    <param name="Rows" value="2">
    <param name="Cols" value="3">
    <param name="FixedRows" value="1">
    <param name="FixedCols" value="0">
    <param name="RowHeightMin" value="0">
    <param name="BackColor" value="-2147483643">
    <param name="ForeColor" value="-2147483640">
    <param name="BackColorFixed" value="-2147483633">
    <param name="ForeColorFixed" value="-2147483630">
    <param name="BackColorSel" value="-2147483635">
    <param name="ForeColorSel" value="-2147483634">
    <param name="BackColorBkg" value="8421504">
    <param name="GridColor" value="12632256">
    <param name="GridColorFixed" value="0">
    <param name="WordWrap" value="0">
    <param name="Redraw" value="-1">
    <param name="AllowBigSelection" value="-1">
    <param name="ScrollTrack" value="0">
    <param name="Enabled" value="-1">
    <param name="RightToLeft" value="0">
    <param name="TextStyle" value="3">
    <param name="TextStyleFixed" value="0">
    <param name="FocusRect" value="1">
    <param name="HighLight" value="1">
    <param name="FillStyle" value="0">
    <param name="GridLines" value="1">
    <param name="GridLinesFixed" value="2">
    <param name="ScrollBars" value="3">
    <param name="SelectionMode" value="0">
    <param name="MergeCells" value="0">
    <param name="AllowUserResizing" value="1">
    <param name="PictureType" value="0">
    <param name="BorderStyle" value="1">
    <param name="Appearance" value="1">
    <param name="MousePointer" value="0">
    <param name="GridLineWidth" value="1">
    <param name="FormatString" value="^       No.of Books|^       Start No |^    End No">
    <param name="OLEDropMode" value="0">
  </object>
  <input type="HIDDEN" name="hidstartno"> <input type="hidden" name="hidstock"> <input type="hidden" name="hidtype">
  <input type="hidden" name="hidstatus" value="Insert">

  <%

strval=Request.Form("hidstock")

dim obj,rs,RsDept

if len(strval)> 0 then
stq=split(strval,"|")
	
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=server.CreateObject("adodb.recordset")
	set Rsdept=server.CreateObject("adodb.recordset")  
	Dim brCode
	Dim BookSerNo
	Dim LeafSerNo
	Dim LeafPerBk
	Dim InstrCode
	Dim arrStartNo()
	Dim arrNoBk()
	dim arrendno()
	dim des
	dim checkyn
	checkyn="N"
	brCode    =	stq(0)
	InstrCode = stq(1)
	BookSerNo = stq(2)
	LeafPerBk = stq(3)
	
if ucase(trim(stq(5)))="INSERT" then
	
	if ucase(trim(stq(4)))="BOOK" then
	
	des="^No.of Books"
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","nvl(to_number(NOOFBOOKS),0),nvl(NOBOOKISSUED,0),nvl(to_number(bookstartno),0),nvl(to_number(BOOKENDNO),0)","branchcode='" & trim(brCode) & "' and upper(BOOKSERIESNO)='" & ucase(trim(BookSerNo)) & "' and  upper(INSTRCODE)='" & ucase(trim(InstrCode)) & "' and  LEAVESPERBOOK='" & trim(LeafPerBk) & "' and Status<>'ISSUED' and transtatus='A' and nvl(to_number(NOBOOKISSUED),0)<>nvl(to_number(NOOFBOOKS),0)","to_number(bookstartno)")
	set RsDept=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","max(nvl(to_number(BOOKENDNO),0))","BOOKSERIESNO='" & BookSerNo & "' and LEAVESPERBOOK='" & LeafPerBk & "' and instrcode='" & InstrCode & "' and  branchcode='" & brCode & "'","TO_NUMBER(bookstartno)")
	if  rs.EOF<>true then
	i=0
	do while not rs.EOF 
		cnt=cnt+1
		rs.MoveNext 
	loop
	checkyn="Y"
	redim arrnobk(cnt)
	redim arrstartno(cnt)
	redim arrendno(cnt)
	rs.Movefirst
	do until rs.EOF 
		arrnobk(i)=cdbl(rs(0))-cdbl(rs(1))
	if rs.AbsolutePosition=1 then
		If RsDept(0) ="0" or isnull(RsDept(0)) Then
		arrstartno(i)=cdbl(rs(2))
		else
		arrstartno(i)=cdbl(rs(2))+(LeafPerBk*cdbl(rs(1)))
		end if
	else
		arrstartno(i)=cdbl(rs(2))
	end if
		arrendno(i)=cdbl(rs(3))
		rs.MoveNext()
		i=i+1
	loop
	end if
	ElseIf ucase(trim(stq(4)))="LEAF" Then
	
	des="^No.of Leaves"
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","noofleaves,nvl(NOLEAFISSUED,0),nvl(to_number(Leafstartno),0),nvl(to_number(LEAFENDNO),0)","branchcode='" & brCode & "' and LEAFSERIESNO='" & BookSerNo & "' and instrcode='" & InstrCode & "' AND transtatus='A'  and  status<>'ISSUED'","leafseriesno,to_number(leafSTARTNO)")
	set RsDept=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","nvl(max(nvl(to_number(Leafnumber),0)),0)","leafSERIESNO='" & BookSerNo & "' and branchcode='" & brCode & "' and instrcode='" & InstrCode & "'","leafSERIESNO,TO_NUMBER(LEAFnumber)")
	
	if  rs.EOF<>true then
	i=0
	do while not rs.EOF 
		cnt=cnt+1
		rs.MoveNext 
	loop
	checkyn="Y"
	redim arrnobk(cnt)
	redim arrstartno(cnt)
	redim arrendno(cnt)
	rs.Movefirst
	do until rs.EOF 
		arrnobk(i)=cdbl(rs(0))-cdbl(rs(1))
	if rs.AbsolutePosition=1 then
		If RsDept(0) ="0" or isnull(RsDept(0)) Then
		arrstartno(i)=cdbl(rs(2))
		else
		arrstartno(i)=cdbl(rs(2))+cdbl(rs(1))
		end if
	else
		arrstartno(i)=cdbl(rs(2))
	end if
		arrendno(i)=cdbl(rs(3))
		rs.MoveNext()
		i=i+1
	loop
	
	end if
end if

elseif ucase(trim(stq(7)))="MODIFY" or ucase(trim(stq(7)))="DELETE" or ucase(trim(stq(7)))="QUERY" then
	
	issueto=stq(5)
	modid=stq(6)
		
	if ucase(trim(stq(4)))="BOOK" then

	des="^No.of Books"
	brCode    =	stq(0)
	InstrCode = stq(1)
	BookSerNo = stq(2)
	LeafPerBk = stq(3)
	
	'set Rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","count(bookendno),min(to_number(bookstartno)),max(to_number(bookendno))","branchcode='" & brCode & "' and BOOKSERIESNO='" & BookSerNo & "' and  BOOKYESNO='Y' AND ISSUEDTO='" & issueto &"' AND  MODULEID='" & modid &"' AND INSTRCODE='" & InstrCode & "' and  LEAVESPERBOOK='" & LeafPerBk & "' and Status='ISSUABLE' and TRANSSTATUS='P' group by systemdate,bookstartno order by bookstartno")
	'set RsDept=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","nvl(sum(nvl(TO_NUMBER(NOOFBOOKS),0)),0),nvl(sum(NVL(NOBOOKISSUED,0)),0)","branchcode='" & brCode & "' and BOOKSERIESNO='" & BookSerNo & "' and  BOOKYESNO='Y' AND INSTRCODE='" & InstrCode & "' and transtatus='A' and LEAVESPERBOOK='" & LeafPerBk & "'","BOOKSERIESNO")


	set Rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","bookstartno,bookendno","branchcode='" & brCode & "' and BOOKSERIESNO='" & BookSerNo & "' and  BOOKYESNO='Y' AND ISSUEDTO='" & issueto &"' AND  MODULEID='" & modid &"' AND INSTRCODE='" & InstrCode & "' and  LEAVESPERBOOK='" & LeafPerBk & "' and Status='ISSUABLE' and TRANSSTATUS='P' order by to_number(bookstartno)")
	set RsDept=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","nvl(sum(nvl(TO_NUMBER(NOOFBOOKS),0)),0),nvl(sum(NVL(NOBOOKISSUED,0)),0)","branchcode='" & brCode & "' and BOOKSERIESNO='" & BookSerNo & "' and  BOOKYESNO='Y' AND INSTRCODE='" & InstrCode & "' and transtatus='A' and LEAVESPERBOOK='" & LeafPerBk & "'","BOOKSERIESNO")
	cnt=0
	if not rs.EOF and not rs.BOF then
	do while not rs.EOF 
		cnt=cnt+1
		avastock=clng(rsdept(0))-clng(rsdept(1))
		rs.MoveNext
	loop
	rs.MoveFirst 
	end if
	redim arrnobk(cnt)
	redim arrstartno(cnt)
	redim arrendno(cnt)
	checkyn="Y"
	
if not RsDept.EOF and not RsDept.BOF and not rs.BOF  and not rs.EOF then
j=0
for i=0 to rs.RecordCount - 1
if rs.AbsolutePosition=1 then
	arrstartno(j)=cdbl(rs(0))
	endno=cdbl(rs(1))+1
	arrNoBk(j)=1
else
	if cdbl(rs(0)) = endno then
		endno=cdbl(rs(1))+1
		n=n+1
		arrNoBk(j)=arrNoBk(j)+1
	else
		arrendno(j)=cdbl(endno)-1
		j=j+1
		arrstartno(j)=cdbl(rs(0))
		endno=cdbl(rs(1))+1
		arrNoBk(j)=1
	end if
end if
rs.MoveNext()
next
arrendno(j)=cdbl(endno)-1
end if
    
SET RsDept=NOTHING
stat="Stock"
SET Rs=NOTHING
elseif ucase(trim(stq(4)))="LEAF" then

	des="^ No.of Leaves"
	
	'set Rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","count(LEAFNUMBER),min(to_number(LEAFNUMBER)),max(to_number(LEAFNUMBER))","branchcode='" & brCode & "' and LEAFYESNO='Y' and  LEAFSERIESNO='" & BookSerNo & "' and iSSUEDTO='" & issueto &"' AND  MODULEID='" & modid &"' AND INSTRCODE='" & InstrCode & "' and Status='ISSUABLE' and TRANSSTATUS='P'")
	'set RsDept=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","sum(nvl(NOOFLEAVES,0)),sum(NVL(NOLEAFISSUED,0))","branchcode='" & brCode & "' and LEAFSERIESNO='" & BookSerNo & "' and transtatus='A' and LEAFYESNO='Y' AND INSTRCODE='" & InstrCode & "'" ,"LEAFSERIESNO")
	
	
	set Rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","LEAFNUMBER","branchcode='" & brCode & "' and LEAFSERIESNO='" & BookSerNo & "' and  LEAFYESNO='Y' AND ISSUEDTO='" & issueto &"' AND  MODULEID='" & modid &"' AND INSTRCODE='" & InstrCode & "' and Status='ISSUABLE' and TRANSSTATUS='P'","to_number(LEAFNUMBER)")
	set RsDept=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","nvl(sum(nvl(TO_NUMBER(NOOFLEAVES),0)),0),nvl(sum(NVL(NOLEAFISSUED,0)),0)","branchcode='" & brCode & "' and LEAFSERIESNO='" & BookSerNo & "' and  LEAFYESNO='Y' AND INSTRCODE='" & InstrCode & "' and transtatus='A'","LEAFSERIESNO")
	
	if not rs.EOF and not rs.BOF then
	do while not rs.EOF 
		cnt=cnt+1
		avastock=clng(rsdept(0))-clng(rsdept(1))
		rs.MoveNext
	loop
	rs.MoveFirst 
	end if
	redim arrnobk(cnt)
	redim arrstartno(cnt)
	redim arrendno(cnt)
	checkyn="Y"
	
if not RsDept.EOF and not RsDept.BOF and not rs.BOF  and not rs.EOF then
j=0
for i=0 to rs.RecordCount - 1
if rs.AbsolutePosition=1 then
	arrstartno(j)=cdbl(rs(0))
	endno=cdbl(rs(0))+1
	arrNoBk(j)=1
else
	if cdbl(rs(0)) = endno then
		endno=cdbl(rs(0))+1
		n=n+1
		arrNoBk(j)=arrNoBk(j)+1
	else
		arrendno(j)=cdbl(endno)-1
		j=j+1
		arrstartno(j)=cdbl(rs(0))
		endno=cdbl(rs(0))+1
		arrNoBk(j)=1
	end if
end if
rs.MoveNext()
next
arrendno(j)=cdbl(endno)-1
end if
    
SET RsDept=NOTHING
stat="Stock"
SET Rs=NOTHING
end if

end if

if checkyn="Y"  then
checkyn="N"

if ubound(arrnobk)>0 then
'if len(trim(NoBk))>0 and len(trim(StartNo))>0 and len(trim(Endno)) > 0  then
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frmstock.stockdtls.formatstring="& chr(34)& des & chr(34)& chr(13)
	Response.Write "window.document.frmstock.hidtype.value="& chr(34) & stq(4)   & chr(34) & chr(13)
	Response.Write "window.document.frmstock.stockdtls.rows=window.document.frmstock.stockdtls.rows-1"& chr(13)
	totbooks=0
	''''' checking
	for i=1 to ubound(arrnobk)
	if len(arrnobk(i-1))>0 then
	Response.Write "window.document.frmstock.stockdtls.rows=window.document.frmstock.stockdtls.rows+1"& chr(13)
	Response.Write "window.document.frmstock.stockdtls.textmatrix(" & i & ",0)="& chr(34)& arrNoBk(i-1) & chr(34)& chr(13)
	Response.Write "window.document.frmstock.stockdtls.textmatrix(" & i & ",1)="& chr(34)& arrStartNo(i-1) & chr(34)& chr(13)
	Response.Write "window.document.frmstock.stockdtls.textmatrix(" & i & ",2)="& chr(34)& arrEndno(i-1) & chr(34)& chr(13)
	
	totbooks=cdbl(totbooks) + cdbl(arrNoBk(i-1))
	strrow=strrow+1
	stx=stx & "|" & arrNoBk(i-1) 
	sty =sty & "|" & arrStartNo(i-1)
	
	
	'Response.Write "msgbox"&chr(34)& totbooks+avastock & chr(34) & chr(13)	
	'Response.Write "window.document.frmstock.stockdtls.cols=window.document.frmstock.stockdtls.cols+1"& chr(13)
	
	Response.Write "window.parent.window.document.frmdepins.hidnoofbl.value=" & chr(34 ) & totbooks & chr(34) & chr(13)
	Response.Write "window.parent.window.document.frmdepins.txtnobook.value=" & chr(34 ) & totbooks & chr(34) & chr(13)
	
	'Response.Write "window.parent.window.document.frmdepins.hidnb.value=" & chr(34 ) & totbooks & chr(34) & chr(13)
	
	Response.Write "window.parent.window.document.frmdepins.txtssno.value=window.document.frmstock.stockdtls.TextMatrix(1,1)" & chr(13)
	Response.Write "window.parent.window.document.frmdepins.txtendsno.value=window.document.frmstock.stockdtls.TextMatrix(" & strrow &",2)" & chr(13)
	Response.Write "window.parent.window.document.frmdepins.txtnol.value=window.document.frmstock.stockdtls.TextMatrix(1,0)" & chr(13)
	Response.Write "window.parent.window.document.frmdepins.txtlstartno.value=window.document.frmstock.stockdtls.TextMatrix(1,1)" & chr(13)
	Response.Write "window.parent.window.document.frmdepins.txtlendno.value=window.document.frmstock.stockdtls.TextMatrix(" & strrow &",2)" & chr(13)
	
	Response.Write "window.parent.window.document.frmdepins.hsno.value=window.document.frmstock.stockdtls.TextMatrix(1,1)" & chr(13)
	Response.Write "window.parent.window.document.frmdepins.heno.value=window.document.frmstock.stockdtls.TextMatrix(" & i-1 &",2)" & chr(13)
	
	end if 
	next

	'Response.Write "strrows=window.document.frmstock.stockdtls.rows" & chr(13)
	'Response.Write "msgbox" & chr(34) & prasad & chr(34) & chr(13)
	'Response.Write "msgbox"& chr(34)& stq(5)& chr(34) & chr(13)
	
	if ucase(trim(stq(5)))<>"INSERT" then
		if ucase(trim(stq(7)))="MODIFY" then
		
			'Response.Write "msgbox"&chr(34)& avastock & chr(34) & chr(13)
			
			Response.Write "window.parent.window.document.frmdepins.hidnoofbl.value=" & chr(34 ) & totbooks+avastock & chr(34) & chr(13)
			Response.Write "window.parent.window.document.frmdepins.txtnobook.value=" & chr(34 ) & totbooks & chr(34) & chr(13)
			Response.Write "window.document.frmstock.hidstatus.value="& chr(34) & stq(7)& chr(34) & chr(13)
			Response.Write "window.document.frmstock.stockdtls.cols=window.document.frmstock.stockdtls.cols+1"& chr(13)
			Response.Write "window.document.frmstock.stockdtls.textmatrix(0,3)="& chr(34)& stat & chr(34)& chr(13)
			for i=1 to strrow
				Response.Write "window.document.frmstock.stockdtls.textmatrix(" & i & ",3)="& chr(34) & totbooks+avastock & chr(34)& chr(13)
			
				'Response.Write "msgbox"&chr(34)& Avastock+totbooks & chr(34) & chr(13)
				
			next
		end if
	else
		Response.Write "window.parent.window.document.frmdepins.hiddata.value=" & chr(34)  & stx &  "~"  & sty & chr(34) & chr(13)
	end if
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
else
	st="^                                                Description            "
	str="                          No Books/Leaves.                         "
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frmstock.stockdtls.formatstring="& chr(34)& st & chr(34)& chr(13)
	Response.Write "window.document.frmstock.stockdtls.cols=1" & chr(13)	
	Response.Write "window.document.frmstock.stockdtls.rows=2" & chr(13)
	Response.Write "window.document.frmstock.stockdtls.textmatrix(1,0)="& chr(34)& str & chr(34)& chr(13)
	Response.Write chr(13)
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if

else
	st="^                                    Description                             "
	str=" No Books/Leaves."
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frmstock.stockdtls.formatstring="& chr(34)& st & chr(34)& chr(13)
	Response.Write "window.document.frmstock.stockdtls.cols=1" & chr(13)	
	Response.Write "window.document.frmstock.stockdtls.rows=2" & chr(13)
	Response.Write "window.document.frmstock.stockdtls.textmatrix(1,0)="& chr(34)& str & chr(34)& chr(13)
	Response.Write chr(13)
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)

end if

end if
  %>
</form>

</body>

</html>
