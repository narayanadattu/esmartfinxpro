<%@ Page CodeBehind="stockaaproval.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.stockaaproval" %>
<%
dim instr,str,trans,insdesc,inscd
	str=Request.QueryString("result")
if len(str)> 0 then
	instr=split(str,"~!~")
	trans=instr(0)
	inscd=instr(1)
	insdesc=instr(2)
end if
%>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE="javascript"   src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE="javascript"   src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="javaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="javaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="javaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
//To Get Branchcode
function branch(){

	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
}	
function Branchcode(str){

	assign(str,window.document.frmstockapp.txtbranchdesc,window.document.frmstockapp.txtbranchcode)
	//clear()
}

//To get Instrumentcode

function instrument(){

	st="Instrument"
	window.open("Listquery.asp" + "?" +"st="+st,st,"width=200%,height=150%,left=140%,top=210%")

}
function Display(){

	window.document.all.divleaf.style.display="none"
	window.document.all.divbook.style.display="block"
}
function instrcode(str){
	
	assign(str,window.document.frmstockapp.txtinstrdesc,window.document.frmstockapp.txtinstrcode)
	Insrment()
}
	
	
// TO Approve all Instruments.
function Approveall()
{
var irows,irow,strrow
var jcols,jcol,strflex
strrow=""
strflex=""
irows=window.document.frames(0).frminsapp.mfgins.rows
icols=window.document.frames(0).frminsapp.mfgins.cols
if(eval(icols)>1)
{
for(irow=0;irow<irows-1;irow++)
{
	for(jcol=0;jcol<10;jcol++)
	{
		strflex=strflex+"~!~"+window.document.frames(0).frminsapp.mfgins.TextMatrix(irow+1,jcol)
	}
	strrow=strrow+"*|*"+strflex
	strflex=""
}	

if(eval(irows)>1)
{
	window.document.frmstockapp.hidstatus.value="APPROVEALL"
	window.document.frmstockapp.hidflex.value=strrow
	window.document.frmstockapp.action="stockapprovalinsert.asp"
	window.document.frmstockapp.method="post"
	window.document.frmstockapp.submit();
}
}
}

//To Get Instruments details.
function Insrment()
{
	brcode=window.document.frmstockapp.txtbranchcode.value
	inscode=window.document.frmstockapp.txtinstrcode.value
	if(brcode!="" && inscode!="")
	{
	window.document.frames(0).frminsapp.hidinstr.value=brcode+"~"+inscode
	window.document.frames(0).frminsapp.method="post"
	window.document.frames(0).frminsapp.action="SBstockinstrdetails.asp"
	window.document.frames(0).frminsapp.submit();
	}

}

// To Approve  Instrument.

function Approveorrej(){
var brcode,inscd,esno,nlpb,serno,ssno
	brcode=window.document.frmstockapp.txtbranchcode.value
	inscd=window.document.frmstockapp.txtinstrcode.value
	esno=window.document.frmstockapp.txtendsno.value
	nlpb=window.document.frmstockapp.txtnoleavesperbook.value
	serno=window.document.frmstockapp.txtserno.value
	ssno=window.document.frmstockapp.txtssno.value
	leno=window.document.frmstockapp.txtleno.value
	lserno=window.document.frmstockapp.txtlserno.value
	lsno=window.document.frmstockapp.txtlsno.value
	nol=window.document.frmstockapp.txtnol.value
if(window.document.frmstockapp.Radtype(0).checked==true)
{	
 if(brcode && inscd && serno && esno && nlpb && ssno)
 {
	window.document.frmstockapp.action="stockapprovalinsert.asp"
	window.document.frmstockapp.method="post"
	window.document.frmstockapp.submit();
 }
 else
 {
 	alert('Fields Should not be Null.')
 }
}
else if(window.document.frmstockapp.Radtype(1).checked==true)
{
	if(brcode && inscd && nol && leno && lserno && lsno)
	{
		window.document.frmstockapp.action="stockapprovalinsert.asp"
		window.document.frmstockapp.method="post"
		window.document.frmstockapp.submit();
	}
	else
	{
		alert('Fields Should not be Null.')
	}
}
}

//To Get Instruments Details when form loads.
function Instrdet(){
	Insrment()
}

//To Approve the Instruments
function Approve(){

window.document.frmstockapp.hidstatus.value="APPROVE"
Approveorrej()
}
//To Reject the Instruments
function Reject(){
window.document.frmstockapp.hidstatus.value="REJECT"
Approveorrej()

}	
//-->
</SCRIPT>

<title>Cash Transfer</title>
</head>
<body topmargin="0" leftmargin="0" onload='GetMenu("<%=session("menustring")%>");Display();Instrdet()'>
<form name="frmstockapp">
<%appdate=formatdatetime(session("applicationdate"),1)%>
<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
  <tr class="bgcolor">
    <td width="100%" nowrap colspan="3" height="28">
    <img border="0" height="22" name="placeholder" src="transparent.gif" width="1"></td>
  </tr>
  <tr class="bgcolor">
    <td width="34%" nowrap height="25">
    <p align="center">&nbsp;</p></td>
    <td width="33%" nowrap height="25" align="center">
    <font class="text">Stock Approval</font></td>
    <td width="33%" nowrap height="25">
    <font face="MS Sans Serif" size="2" color="#FFFFFF"><%=APPDATE%></font>
    </td>
  </tr>
</table>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
      <td width="100%" valign="top" height="15" align=middle><font face="MS Sans Serif" color="blue" size="3"><%=trans%></font></td>
    </tr>
</table>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">

      <table border="0" width="98%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="15%">
          <p align="right"><font class="textbold">&nbsp;Branch
          Code&nbsp;&nbsp;</font></p>
          </td>
          <center>
          <td width="32%"><font size="2" face="MS Sans Serif"><input name="txtbranchcode" size="9" value="<%=session("branchcode")%>"
           ></font><input type="button" value=" L " name="butbr" onclick='branch()'><font size="2" face="MS Sans Serif"><input name="txtbranchdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" value="<%=session("branchnarration")%>"></font></td>
          </center>
          <td width="15%">
          <p align="right"><font class="textbold">Instrument Code &nbsp;</font></p></td>
          <center>
          <td width="38%"><font size="2" face="MS Sans Serif"><input name="txtinstrcode" size="9" value="<%=inscd%>"
           ></font><input type="button" value=" L " name="butinstr" onclick='instrument()'><font size="2" face="MS Sans Serif"><input name="txtinstrdesc" size="16" style="background-color: #B3A597; color: #FFFFFF" value="<%=insdesc%>"></font></td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">

              <table border="0" width="80%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%"><iframe id=den align=center             
                        frameborder=0 framespacing=0 noresize 
                        height=100 width=690 scrolling=yes
		                valign="top" src="SBstockinstrdetails.asp" 
                          style="BACKGROUND-COLOR: darkred; HEIGHT: 140px; WIDTH: 600px"></iframe></td>
                </tr>
              </table>

            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
              <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="100%"><input type="button" value="Approve All" name="butappall"  class="bgcolor" onclick='Approveall()'></td>
                </tr>
              </table>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <p align="center"></p></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor1">
                <td width="16%"><font class="textwhite">&nbsp;<input type="radio" value="BOOK" checked name ="Radtype" onclick="">
                Book</font></td>
                <td width="84%"><font class="textwhite"><input type="radio" value="LEAF"  name="Radtype">
                Leaf</font></td>
              </tr>
            </table>

            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
             <div id="divbook">

                <table border="0" width="98%" class="tableborder2" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr class="bgcolor">
                        <td width="100%" colspan="6"><font class="subheading">&nbsp;Available
                        Book Details</font></td>
                      </tr>
                      <tr>
                        <td width="10%"><font class="textsmall">&nbsp;Series
                        No.</font></td>
                        <td width="9%"><font class="textsmall"><input name="txtserno" readonly size="9"></font></td>
                        <td width="21%"><font class="textsmall">&nbsp;No. of
                        Leaves per Book</font></td>
                        <td width="21%"><font class="textsmall"><input name="txtnoleavesperbook" readonly  size="9" 
                       ></font></td>
                        <td width="15%"><font class="textsmall">&nbsp;No. of
                        Books</font></td>
                        <td width="24%"><font class="textsmall"><input name="txtnobooks" readonly  size="9"></font></td>
                      </tr>
                      <tr>
                        <td width="10%"><font class="textsmall">&nbsp;Start
                        S.No.</font></td>
                        <td width="9%"><font class="textsmall"><input name="txtssno" readonly size="9"></font></td>
                        <td width="21%"><font class="textsmall">&nbsp;End S.No.</font></td>
                        <td width="21%"><font class="textsmall"><input name="txtendsno" readonly size="9"></font></td>
                        <td width="15%"></td>
                        <td width="24%"></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

              </div>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center" >
              <center>
              <div id="divleaf">
                <table border="0" width="98%" class="tableborder2" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr class="bgcolor">
                        <td width="100%" colspan="8"><font class="subheading">&nbsp;Available
                        Leaf Details</font></td>
                      </tr>
                      <tr>
                        <td width="10%"><font class="textsmall">&nbsp;Series
                        No.</font></td>
                        <td width="9%"><font class="textsmall"><input name="txtlserno" readonly size="9"></font></td>
                        <td width="21%"><font class="textsmall">&nbsp;No. of
                        Leaves</font></td>
                        <td width="10%"><font class="textsmall"><input name="txtnol" readonly  size="9"></font></td>
                        <td width="11%"><font class="textsmall">&nbsp;Start
                        No.</font></td>
                        <td width="15%"><font class="textsmall"><input name="txtlsno" readonly size="9"></font></td>
                        <td width="12%"><font class="textsmall">End S.No.</font></td>
                        <td width="12%"><font class="textsmall"><input name="txtleno" readonly size="9"></font></td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

              </div>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <div align="center">
              <center>
              <table border="0" width="25%" class="tablebordermain" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                  <p align="center"><input type="button" value="Approve" name="butapproval" class="bgcolor" ONCLICK='Approve()'><input type="button" value=" Reject "  name="butreject" class="bgcolor" onclick='Reject()'><input type="button" class="bgcolor"  value=" Cancel " name="butcancel" onclick='location.replace("stockaaproval.asp")'><input type="button" value="   Exit   " class="bgcolor" name="butexit" ONCLICK='window.location.href="http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.asp"%>"'></p></td>
                </tr>
              </table>
              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="5"></td>
          </tr>
        </table>
    </center>
    </div>
    </td>
  </tr>
  <input type="hidden" name="hidstatus">
  <input type="hidden" name="hidflex">
</table></form>

</body>

</html>
