<%@ Page Language="vb" CodeBehind="newcustomerinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.newcustomerinsert1" %>
<%
	dim Arrtrans(0,4)
	dim obj,obj1,Strmsg,status,title,rs,rs1
	set obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=server.CreateObject("adodb.recordset")
	set rs1=server.CreateObject("adodb.recordset")
	codestr=Request.Form("hidbrcrcode")
	codestr=split(codestr,"~~")
	
	brcode=codestr(0)
	crcode=codestr(1)
	'if 1=2 then
	appdate=session("applicationdate")
	name=Request.Form("txtname")
	userid=session("userid")
	machineid=session("machineid")
	status=Request.Form("hidmode")	
	narration=Request.Form("txtnarration")
	code=Request.Form("txtcode")
	globalcode=Request.Form("hidglobal")
	custtype=Request.Form("txtCustType")
	set rs=obj1.singlerecordset("gencustinfomst","nvl(max(to_number(customerid)),0)+1","branchcode='" & brcode & "'" )
	Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")
	if globalcode="Y" then
		set rs1=obj1.singlerecordset("GENBANKLEVELMST a,GENBANKBRANCHMST b","branchcode","a.branchtype=b.branchtype and a.hierarchy=(select min(hierarchy) from genbanklevelmst) " )
		brcode=rs1(0)
	end if
	customerid="00000000001"
	if cdbl(rs(0))>1 then
		customerid=mid(rs(0),6)
	end if

	customerid=brcode & custtype & customerid
	tabname="GENCUSTINFOMST"
	custfields="custname,mailaddress1,mailaddress2,mailaddress3,mailaddress4," & _ 
					"mailaddress5,custemail,phone1,phone2,phone3," & _
					"custmobile,custfax,custdob,custminoryn,customertype,branchcode,currencycode," & _ 
					"userid,machineid,applicationdate,systemdate,customerid"
			
	custvals=ucase(Request.Form("hidcustvals")) &  ",'" & userid & "','" & _
	machineid & "','" & appdate & "',sysdate,'" &  customerid & "'"
			arrtrans(0,0)="I"
			arrtrans(0,1)=tabname
			arrtrans(0,2)=custfields
			arrtrans(0,3)=custvals
			arrtrans(0,4)=""
			
Strmsg= obj.DataTransactions(Arrtrans)



Response.Write strmsg
Response.Write arrtrans(0,2) & "<br>"
Response.Write arrtrans(0,3) & "<br>"
Response.Write arrtrans(0,4) & "<br>"

Response.Redirect "newcustomer.asp?record=" & customerid & "|" & name & "|" & brcode & "|" & crcode & "|" & codestr(2)& "|" & codestr(3)
'end if
		
%>
  
