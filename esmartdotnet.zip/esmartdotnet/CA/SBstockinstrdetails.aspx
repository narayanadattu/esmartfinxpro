<%@ Page CodeBehind="SBstockinstrdetails.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBstockinstrdetails" %>
<%
	dim insdtl,insstr
	insdtl=Request.Form("hidinstr")
	insstr=split(insdtl,"~")	
	
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Instruments</title>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
//
function mfgins_DblClick() 
{
if(eval(window.document.frminsapp.mfgins.Cols)>1)
{
	i=window.document.frminsapp.mfgins.Row
if(window.document.frminsapp.mfgins.TextMatrix(i,1))
	{
		window.parent.window.document.frmstockapp.Radtype(0).disabled=false
		window.parent.window.document.frmstockapp.Radtype(0).checked=true
		window.parent.window.document.frmstockapp.Radtype(1).disabled=true
		window.parent.window.document.frmstockapp.all.divleaf.style.display="none"
		window.parent.window.document.frmstockapp.all.divbook.style.display="block"
		window.parent.window.document.frmstockapp.txtserno.value=window.document.frminsapp.mfgins.TextMatrix(i,1)
		window.parent.window.document.frmstockapp.txtnoleavesperbook.value=window.document.frminsapp.mfgins.TextMatrix(i,3)
		window.parent.window.document.frmstockapp.txtnobooks.value=window.document.frminsapp.mfgins.TextMatrix(i,4)
		window.parent.window.document.frmstockapp.txtssno.value=window.document.frminsapp.mfgins.TextMatrix(i,6)
		window.parent.window.document.frmstockapp.txtendsno.value=window.document.frminsapp.mfgins.TextMatrix(i,7)
	}
else if(window.document.frminsapp.mfgins.TextMatrix(i,2))
	{
		var lsno,esno,nol
		window.parent.window.document.frmstockapp.Radtype(1).disabled=false
		window.parent.window.document.frmstockapp.Radtype(1).checked=true
		window.parent.window.document.frmstockapp.Radtype(0).disabled=true
		window.parent.window.document.frmstockapp.all.divleaf.style.display="block"
		window.parent.window.document.frmstockapp.all.divbook.style.display="none"
		window.parent.window.document.frmstockapp.txtlserno.value=window.document.frminsapp.mfgins.TextMatrix(i,2)
		window.parent.window.document.frmstockapp.txtnol.value=window.document.frminsapp.mfgins.TextMatrix(i,5)
		window.parent.window.document.frmstockapp.txtlsno.value=window.document.frminsapp.mfgins.TextMatrix(i,8)
		window.parent.window.document.frmstockapp.txtleno.value=window.document.frminsapp.mfgins.TextMatrix(i,9)
	}
	
}
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=mfgins EVENT=DblClick>
<!--
 mfgins_DblClick()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0">

<form name="frminsapp">
  <div align="center">
    <input type="hidden" name="hidinstr"><center>

    <table border="0" width="60%" class="tablebordermain" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%">
        <OBJECT classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height=133 id=mfgins name=mfgins 
	style="HEIGHT: 133px; LEFT: 21px; TOP: 0px; WIDTH: 572px" width=572>
	<PARAM NAME="_ExtentX" VALUE="15134">
	<PARAM NAME="_ExtentY" VALUE="3519">
	<PARAM NAME="_Version" VALUE="393216">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="Cols" VALUE="11">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="HighLight" VALUE="1">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="AllowUserResizing" VALUE="1">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="FormatString" VALUE="Instrument Code  |<  Book Series No  |< Leaf Series No |> Leaves Per Book  |>No.of Books |> No.of Leaves|> Book  Start No |> Book End No  |> Leaf  Start No |> Leaf End No |^ Application Date">
	<PARAM NAME="OLEDropMode" VALUE="0"></OBJECT>
        </td>
      </tr>
    </table>

    </center>
  </div>
  <%

if len(insdtl)> 0 then
if len(insstr(0))>0 and len(insstr(1))>0 then

	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rsins=server.CreateObject("adodb.recordset")
	
		
'''' assigning values to flrxgrid

set ObjFetchRec=server.CreateObject("queryrecordsets.fetchrecordsets")
set rsins=server.CreateObject("adodb.recordset")
Set rsins =obj.SingleRecordSet("GENINSTRUMENTSTOCKDTLS", _
			"INSTRCODE,BOOKSERIESNO,LEAFSERIESNO,LEAVESPERBOOK," & _
			"NOOFBOOKS,NOOFLEAVES,BOOKSTARTNO,BOOKENDNO, " & _
			"LEAFSTARTNO,LEAFENDNO,APPLICATIONDATE", _
			"upper(trim(branchcode))='" & insstr(0) & "' and " & _
			"upper(trim(INSTRCODE))='" & insstr(1) & "' and " & _
			"Status='STOCK' and TRANSTATUS='P'", _
			"bookseriesno,LEAFSERIESNO,TO_NUMBER(BOOKSTARTNO)," & _
			"TO_NUMBER(LEAFSTARTNO)")
			
		
			
 Dim Mode,Lno,lstno,count
 
if rsins.EOF<>true and rsins.BOF<>true then
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	rsins.MoveFirst()
	for count=0 to rsins.RecordCount - 1
	Response.Write "window.document.frminsapp.mfgins.rows=window.document.frminsapp.mfgins.rows+1" & chr(13)
	for jfield=0 to rsins.Fields.Count - 1
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &","& jfield &")="&  chr(34) &  rsins(jfield) & chr(34)& chr(13)
	next
	rsins.MoveNext()
		
	next
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if

if  rsins.EOF=true and rsins.BOF=true then

	st="^                                                                                                   Description                          "
	str="                    No Records Found.    "
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.formatstring="& chr(34)& st & chr(34)& chr(13)
	Response.Write "window.document.frminsapp.mfgins.cols=1" & chr(13)	
	Response.Write "window.document.frminsapp.mfgins.rows=2" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.textmatrix(1,0)="& chr(34)& str & chr(34)& chr(13)
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if
 
 
 
end if
end if
		
	

  %>
</form>

</body>

</html>
