<%@ Page CodeBehind="instrstockdtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Instrstockdtls" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Instrument Stock Details</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var Mode
function frmload()
{
	Mode="Insert"
	window.document.frmdepins.rdtran[0].checked=true
}

//To Get Branchcode
function branch(){

	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
}	
function Branchcode(str){

	assign(str,window.document.frmdepins.txtbranchdesc,window.document.frmdepins.txtbranchcode)
	clear()
}

//To get Instrumentcode

function instrument(){

	st="Instrument"
	window.open("Listquery.asp" + "?" +"st="+st,st,"width=200%,height=150%,left=140%,top=210%")

}

function instrcode(str){

	assign(str,window.document.frmdepins.txtinstrdesc,window.document.frmdepins.txtinstrcode)
	window.document.frmdepins.txtendno.value=""
	window.document.frmdepins.txtlendno.value=""
	window.document.frmdepins.txtlsno.value=""
	window.document.frmdepins.txtlstartno.value=""
	window.document.frmdepins.txtnlpbook.value=""
	window.document.frmdepins.txtnoofbook.value=""
	window.document.frmdepins.txtsno.value=""
	window.document.frmdepins.txtstartno.value=""
	window.document.frmdepins.txtnoofleaves.value=""
		
}

//To get End Serial.no for Book


/*
if(Mode=="Insert")
{
if(window.document.frmdepins.txtbranchcode.value!="" 
	&& window.document.frmdepins.txtinstrcode.value!="" 
	&& window.document.frmdepins.txtsno.value!="" 
	&& window.document.frmdepins.txtnlpbook.value!="" 
	&& window.document.frmdepins.txtnoofbook.value!="")
	{
	st1="Book"
	st2=window.document.frmdepins.txtbranchcode.value
	st3=window.document.frmdepins.txtinstrcode.value
	st4=window.document.frmdepins.txtsno.value
	st5=window.document.frmdepins.txtnlpbook.value
	if(eval(window.document.frmdepins.txtnoofbook.value)<1)
	{
		alert("Please Enter Correct Value.")
		window.document.frmdepins.txtnoofbook.value=""
		window.document.frmdepins.txtnoofbook.focus()
		return;
	}
	else
	{
		sy="|"
		st=st1+sy+st2+sy+st3+sy+st4+sy+st5
		window.open("querydisplay.asp"+"?"+"st="+st,"book","width=10%,height=15%,left=140%,top=210%")
	}
	}
}

*/

function getnoofbook()
{
if(Mode=="Insert" || Mode=="Modify")
{
	brcode=window.document.frmdepins.txtbranchcode.value
	instr=window.document.frmdepins.txtinstrcode.value
	serno=window.document.frmdepins.txtsno.value
	nlpbook=window.document.frmdepins.txtnlpbook.value
	noofbook=window.document.frmdepins.txtnoofbook.value
	startno=window.document.frmdepins.txtstartno.value
	
	if(brcode!="" && instr!="" 	&& serno!="" && nlpbook!="" && startno!="")
	{
		if(eval(startno)>=0)
		{
			sy="|"
			if(Mode=="Insert")
			{
				str="Book"
				st=str+sy+brcode+sy+instr+sy+serno+sy+startno+sy+noofbook+sy+nlpbook
			}
			else if(Mode=="Modify")
			{
				str="ModifyBook"
				stno=window.document.frmdepins.hidstno.value
				edno=window.document.frmdepins.hidedno.value
				st=str+sy+brcode+sy+instr+sy+serno+sy+startno+sy+noofbook+sy+nlpbook+sy+stno+sy+edno
			}
			window.open("querydisplay.asp"+"?"+"st="+st,"book","width=10%,height=15%,left=1%,top=2%")
		}
		else
		{
			alert('Enter Correct value.')
		}
	}
}	
}

function Bookendsno(str){

	if(str=="TRUE")
	{
		alert('Invalid Start No.')
		window.document.frmdepins.txtstartno.value=""
		window.document.frmdepins.txtstartno.focus()
	
	}
	else
	{
		window.document.frmdepins.txtendno.value=eval(startno)+eval(nlpbook)*eval(noofbook)-1
		window.document.frmdepins.butok.focus()
	}
}


function Getstedno()
{
if(Mode=="Modify")
{
	nlpbook=window.document.frmdepins.txtnlpbook.value
	noofbook=window.document.frmdepins.txtnoofbook.value
	startno=window.document.frmdepins.txtstartno.value
	if(nlpbook!="" && noofbook!="" && startno!="")
	{
	   if(eval(nlpbook)>0)
	   {
			if(eval(noofbook)>0)
			{
	   			if(eval(noofbook) > 0)
				{	
				no=eval(nlpbook)*eval(noofbook)
				endno=eval(no)-eval(1)+eval(startno)
				window.document.frmdepins.txtendno.value=endno
				}
			}
			else
			{
			alert("Please Enter Correct Value")
			window.document.frmdepins.txtnoofbook.value=""
			}
		}
		else
		{
			alert("Please Enter Correct Value")
			window.document.frmdepins.txtnlpbook.value=""
		}
	}
}
}
//To get Endserial.no for Leaf
function getnoofleaves()
{
	brcode=window.document.frmdepins.txtbranchcode.value
	instr=window.document.frmdepins.txtinstrcode.value
	lserno=window.document.frmdepins.txtlsno.value
	noofleaves=window.document.frmdepins.txtnoofleaves.value
	lstartno=window.document.frmdepins.txtlstartno.value
if(Mode=="Insert" || Mode=="Modify")	
{
	if(brcode!="" && instr!="" 	&& lserno!="" && noofleaves !="" && lstartno!="")
	{
		if(eval(lstartno)>=0)
		{
			sy="|"
		 if(Mode=="Insert")	
		 {
			str="Leaf"
			stl=str+sy+brcode+sy+instr+sy+lserno+sy+lstartno+sy+noofleaves
		 } 
		 else if(Mode=="Modify")
		 {
			str="ModifyLeaf"
			stno=window.document.frmdepins.hidstno.value
			stl=str+sy+brcode+sy+instr+sy+lserno+sy+lstartno+sy+noofleaves+sy+stno
		 }
			window.open("querydisplay.asp"+"?"+"st="+stl,"leaf","width=10%,height=15%,left=1%,top=2%")
		}
		else
		{
			alert('Enter Correct value.')
		}
	}
  }
}

function Leafendsno(str)
{
	noofleaves=window.document.frmdepins.txtnoofleaves.value
	lstartno=window.document.frmdepins.txtlstartno.value
   if(str=="TRUE")
	{
		alert('Invalid Start No.')
		window.document.frmdepins.txtlstartno.value=""
		window.document.frmdepins.txtlstartno.focus()
	
	}
	else
	{
		window.document.frmdepins.txtlendno.value=eval(lstartno)+eval(noofleaves)-1
		window.document.frmdepins.butok.focus()
	}
	
}
//To get endno for leaf

function getleafeno(){
if(Mode=="Modify")
{
	noofleaves=window.document.frmdepins.txtnoofleaves.value
	lstartno=window.document.frmdepins.txtlstartno.value	
		
	if(noofleaves!="" && lstartno!="")
	{
	   if(eval(noofleaves)>0)
	   {
			window.document.frmdepins.txtlendno.value=eval(lstartno)+eval(noofleaves)-eval(1)
			
	   }
	   else
	   {
			alert("Please Enter Correct Value")
			window.document.frmdepins.txtnoofbook.value=""
		}
	}
}
}

//To get Records for Modification

function Query()
{
if(Mode!="Insert")
{
	if(window.document.frmdepins.txtbranchcode.value !="" 
		&& 	window.document.frmdepins.txtinstrcode.value)
	{
		Radlen =window.document.frmdepins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmdepins.Radtype(i).checked==true)
		{
			instrtype=window.document.frmdepins.Radtype(i).value
		}
	}	
	if(instrtype=="Book")
	{
		st1="Instrbook"
	}
	else if(instrtype=="Leaf")
	{
		st1="Instrleaf"
	}
	st2=window.document.frmdepins.txtbranchcode.value
	st3=window.document.frmdepins.txtinstrcode.value
	sy="|"
	st=st1+sy+st2+sy+st3
	
	window.open("Listquery.asp"+"?"+"st="+st,"book","width=200%,height=150%,left=240%,top=190%")
	}
	else
	{
		alert('Please Select Branchcode and InstrCode')
	
	}
  }
}

function instrbook(str){
	
	var strval=str.split("-----")
	window.document.frmdepins.txtsno.value=strval[0]
	window.document.frmdepins.txtnlpbook.value=strval[1]
	window.document.frmdepins.txtstartno.value=strval[2]
	window.document.frmdepins.hidstno.value=strval[2]
	instrperbook()
}

function instrleaf(str){

	var strval=str.split("-----")
	window.document.frmdepins.txtlsno.value=strval[0]	
	window.document.frmdepins.txtlstartno.value=strval[1]
	window.document.frmdepins.hidstno.value=strval[1]
	instrperbook()
	
}

//To Get noofleavesperbook,noofbooks and ends.no

function instrperbook()
{
	Radlen =window.document.frmdepins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmdepins.Radtype(i).checked==true)
		{
			instrtype=window.document.frmdepins.Radtype(i).value
		}
	}	
	if(instrtype=="Book")
	{
		st1="Noofbooks"
		st2=window.document.frmdepins.txtbranchcode.value 
		st3=window.document.frmdepins.txtinstrcode.value 
		st4=window.document.frmdepins.txtsno.value
		st5=window.document.frmdepins.txtstartno.value
		st6=window.document.frmdepins.txtnlpbook.value
		sy="|"
		str=st1+sy+st2+sy+st3+sy+st4+sy+st5+sy+st6
		window.open("querydisplay.asp"+"?"+"st="+str,"Leaf","width=10%,height=15%,left=1%,top=2%")
	}
	else if(instrtype=="Leaf")
	{
		st1="Endno"
		st2=window.document.frmdepins.txtbranchcode.value 
		st3=window.document.frmdepins.txtinstrcode.value 
		st4=window.document.frmdepins.txtlsno.value 
		st5=window.document.frmdepins.txtlstartno.value 
		str=st1+sy+st2+sy+st3+sy+st4+sy+st5
		window.open("querydisplay.asp"+"?"+"st="+str,"Leaf","width=10%,height=15%,left=1%,top=2%")
	}	

}
function instrnoofbooks(str){
	if(str){
	
	var strval=str.split("*")
	window.document.frmdepins.txtnoofbook.value =strval[1]
	window.document.frmdepins.txtendno.value=strval[2]
	window.document.frmdepins.hidedno.value=strval[2]
	
	}
}

function instrendno(str){
	
	if(str)
	{
	var strval=str.split("*")
	window.document.frmdepins.txtnoofleaves .value=strval[1]
	window.document.frmdepins.txtlendno.value=strval[2]
	window.document.frmdepins.hidedno.value=strval[2]
	
	}
}

//To Get Seriesno

function instrsno(){
if(Mode=="Insert")
{
	st2=window.document.frmdepins.txtbranchcode.value
	st3=window.document.frmdepins.txtinstrcode.value
	Radlen=window.document.frmdepins.Radtype.length
	if(st2!="" && st3!="")
	{
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmdepins.Radtype(i).checked==true)
			{
			Type=window.document.frmdepins.Radtype(i).value
			}
		}
	if(Type=="Book"){
	
		st1="Bookseriesno"
		sy="|"
		st=st1+sy+st2+sy+st3
		window.open("singlequery.asp"+"?"+"st="+st,"Leaf","width=180%,height=150%,left=120%,top=140%")
		}
	else if(Type=="Leaf"){
		st1="Leafseriesno"
		sy="|"
		st=st1+sy+st2+sy+st3
		window.open("singlequery.asp"+"?"+"st="+st,"Leaf","width=180%,height=150%,left=120%,top=140%")
		}
		}
		else
		{
		alert('Please Select Branchcode,InstrCode.')
		}
	}
}

function leafseries(str)
{
		window.document.frmdepins.txtlsno.value=str
		window.document.frmdepins.txtnoofleaves.focus()
		window.document.frmdepins.txtlendno.value=""
		window.document.frmdepins.txtlstartno.value=""
		window.document.frmdepins.txtnoofleaves.value=""
}

function bookseries(str){

	window.document.frmdepins.txtsno.value=str
	window.document.frmdepins.txtnlpbook.focus()
	window.document.frmdepins.txtendno.value=""
	window.document.frmdepins.txtnlpbook.value=""
	window.document.frmdepins.txtnoofbook.value=""
	window.document.frmdepins.txtstartno.value=""
		
}

function Bookcheck()
{
	if(Mode=="Insert")
	{
		if(window.document.frmdepins.txtinstrcode.value=="")
		{
		  if(window.document.frmdepins.txtsno.value)
		  {
				window.document.frmdepins.txtsno.value=""
				alert('Select Instrument Code')
		  }
		}
	}
}
function Leafcheck()
{
	if(Mode=="Insert")
	{
		if(window.document.frmdepins.txtinstrcode.value=="")
		{
		  if(window.document.frmdepins.txtlsno.value)
		  {
				window.document.frmdepins.txtlsno.value=""
				alert('Select Instrument Code')
		  }
		}
	}
}

//----------------------------------------------------------------------------------------
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
function Cmdcan(){

	location.replace("instrstockdtls.asp")
	
}

function Insert(){
	Radlen =window.document.frmdepins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmdepins.Radtype(i).checked==true)
		{
			Type=window.document.frmdepins.Radtype(i).value
		}
	}
if(Mode=="Insert")
{
	
	if(window.document.frmdepins.txtbranchcode.value!="" && window.document.frmdepins.txtinstrcode.value!="")
	 {
		if(Type=="Book")
		{
				 if(window.document.frmdepins.txtsno.value!="" &&  window.document.frmdepins.txtnoofbook.value!=""  && window.document.frmdepins.txtnlpbook.value!="" && window.document.frmdepins.txtstartno.value && window.document.frmdepins.txtendno.value!="")
					{
						window.document.frmdepins.hidstatus.value=""	
						window.document.frmdepins.hidstatus.value="INSERT"
						window.document.frmdepins.action="instrstockdtlsinsert.asp"
						window.document.frmdepins.method ="post"
						window.document.frmdepins.submit()
					}
					else
					{
						alert("Fields Should not be Null")
					
					}
		}
		else if(Type=="Leaf")
		{
			if(window.document.frmdepins.txtlsno.value!="" && window.document.frmdepins.txtnoofleaves.value!="" && window.document.frmdepins.txtlstartno.value && window.document.frmdepins.txtlendno.value!="")
			{
				window.document.frmdepins.hidstatus.value=""	
				window.document.frmdepins.hidstatus.value="INSERT"
				window.document.frmdepins.action="instrstockdtlsinsert.asp"
				window.document.frmdepins.method ="post"
				window.document.frmdepins.submit()
			}
			else
			{
				alert("Fields Should not be Null")
			}
		}
	}
	else
	{
			alert("Fields Should not be Null")
					
	}
}
else if(Mode=="Delete")
{
if(window.document.frmdepins.txtbranchcode.value!="" && 
   window.document.frmdepins.txtinstrcode.value!="")
	{
		if(Type=="Book")
		{
				 if(window.document.frmdepins.txtsno.value!="" &&  window.document.frmdepins.txtnoofbook.value!=""  && window.document.frmdepins.txtnlpbook.value!="" && window.document.frmdepins.txtstartno.value && window.document.frmdepins.txtendno.value!="")
					{
						window.document.frmdepins.hidstatus.value=""	
						window.document.frmdepins.hidstatus.value="DELETE"	
						window.document.frmdepins.action="instrstockdtlsinsert.asp"
						window.document.frmdepins.method ="post"
						window.document.frmdepins.submit()
					}
					else
					{
						alert("Fields Should not be Null.")
					
					}
	
		}
		else if(Type=="Leaf")
		{
			if(window.document.frmdepins.txtlsno.value!="" && window.document.frmdepins.txtnoofleaves.value!="" && window.document.frmdepins.txtlstartno.value && window.document.frmdepins.txtlendno.value!="")
			{
				window.document.frmdepins.hidstatus.value=""	
				window.document.frmdepins.hidstatus.value="DELETE"	
				window.document.frmdepins.action="instrstockdtlsinsert.asp"
				window.document.frmdepins.method ="post"
				window.document.frmdepins.submit()
			}
			else
			{
				alert("Fields Should not be Null.")
			}
		}
	}
	else
	{
			alert("Select Branchcode and Instrumentcode")
					
	}
}
else if(Mode=="Modify"){

	if(window.document.frmdepins.txtbranchcode.value!="" && 
		window.document.frmdepins.txtinstrcode.value!="")
	{
		if(Type=="Book")
		{
				 if(window.document.frmdepins.txtsno.value!="" &&  window.document.frmdepins.txtnoofbook.value!=""  && window.document.frmdepins.txtnlpbook.value!="" && window.document.frmdepins.txtstartno.value && window.document.frmdepins.txtendno.value!="")
					{
						window.document.frmdepins.hidstatus.value=""	
						window.document.frmdepins.hidstatus.value="MODIFY"	
						window.document.frmdepins.action="instrstockdtlsinsert.asp"
						window.document.frmdepins.method ="post"
						window.document.frmdepins.submit()
					}
					else
					{
						alert("Fields Should not be Null.")
					
					}
	
		}
		else if(Type=="Leaf")
		{
			if(window.document.frmdepins.txtlsno.value!="" && window.document.frmdepins.txtnoofleaves.value!="" && window.document.frmdepins.txtlstartno.value && window.document.frmdepins.txtlendno.value!="")
			{
				window.document.frmdepins.hidstatus.value=""	
				window.document.frmdepins.hidstatus.value="MODIFY"	
				window.document.frmdepins.action="instrstockdtlsinsert.asp"
				window.document.frmdepins.method ="post"
				window.document.frmdepins.submit()
			}
			else
			{
				alert("Fields Should not be Null.")
			}
		}
	}
	else
	{
			alert("Select Branchcode and Instrumentcode")
					
	}
}
}

function Clearfields(){
if(Mode=="Query")
{
	window.document.frmdepins.butok.disabled=true
	clear()
	window.document.frmdepins.txtsno.readOnly=true
	window.document.frmdepins.txtlsno.readOnly=true
	window.document.frmdepins.txtnoofbook.readOnly=true
	window.document.frmdepins.txtnoofleaves.readOnly=true
	window.document.frmdepins.txtnlpbook.readOnly=true
	window.document.frmdepins.txtstartno.readOnly=true
	//window.document.frmdepins.txtendno.readOnly=true
	//window.document.frmdepins.txtlendno.readOnly=true
	window.document.frmdepins.txtlstartno.readOnly=true
}
else if(Mode=="Insert")
{
	window.document.frmdepins.butok.disabled=false
	clear()
	window.document.frmdepins.txtsno.readOnly=false
	window.document.frmdepins.txtlsno.readOnly=false
	window.document.frmdepins.txtnoofbook.readOnly=false
	window.document.frmdepins.txtnoofleaves.readOnly=false
	window.document.frmdepins.txtnlpbook.readOnly=false
	window.document.frmdepins.txtstartno.readOnly=false
	//window.document.frmdepins.txtendno.readOnly=false
	//window.document.frmdepins.txtlendno.readOnly=false
	window.document.frmdepins.txtlstartno.readOnly=false
}
else if(Mode=="Delete")
{
	window.document.frmdepins.butok.disabled=false
	clear()
	window.document.frmdepins.txtsno.readOnly=true
	window.document.frmdepins.txtlsno.readOnly=true
	window.document.frmdepins.txtnoofbook.readOnly=true
	window.document.frmdepins.txtnoofleaves.readOnly=true
	window.document.frmdepins.txtnlpbook.readOnly=true
	window.document.frmdepins.txtstartno.readOnly=true
	//window.document.frmdepins.txtendno.readOnly=true
	//window.document.frmdepins.txtlendno.readOnly=true
	window.document.frmdepins.txtlstartno.readOnly=true
}
else if(Mode=="Modify")
{
	window.document.frmdepins.butok.disabled=false
	clear()
	window.document.frmdepins.txtsno.readOnly=true
	window.document.frmdepins.txtlsno.readOnly=true
	window.document.frmdepins.txtnoofbook.readOnly=false
	window.document.frmdepins.txtnoofleaves.readOnly=false
	window.document.frmdepins.txtnlpbook.readOnly=true
	window.document.frmdepins.txtstartno.readOnly=false
	//window.document.frmdepins.txtendno.readOnly=false
	//window.document.frmdepins.txtlendno.readOnly=false
	window.document.frmdepins.txtlstartno.readOnly=false
}

}
function clear(){
	window.document.frmdepins.txtendno.value=""
	window.document.frmdepins.txtinstrcode.value=""
	window.document.frmdepins.txtinstrdesc.value=""
	window.document.frmdepins.txtlendno.value=""
	window.document.frmdepins.txtlsno.value=""
	window.document.frmdepins.txtlstartno.value=""
	window.document.frmdepins.txtnlpbook.value=""
	window.document.frmdepins.txtnoofbook.value=""
	window.document.frmdepins.txtsno.value=""
	window.document.frmdepins.txtstartno.value=""
	window.document.frmdepins.txtnoofleaves.value=""

}

</SCRIPT>
<SCRIPT LANGUAGE=javascript>
function Display(){

	Radlen =window.document.frmdepins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmdepins.Radtype(i).checked==true)
	{
		if(window.document.frmdepins.Radtype(i).value=="Book")
			{
			if(window.document.all.divbook.style.display=="none")
				{
					window.document.all.divleaf.style.display="none"
					window.document.all.divbook.style.display="block"
					window.document.frmdepins.txtendno.value=""
					window.document.frmdepins.txtnoofbook.value=""
					window.document.frmdepins.txtnlpbook.value=""
					window.document.frmdepins.txtstartno.value=""
					window.document.frmdepins.txtsno.value=""
				}		
			}
			else if(window.document.frmdepins.Radtype(i).value=="Leaf")
			{
				if(window.document.all.divbook.style.display=="block")
				{
					window.document.all.divleaf.style.display="block"
					window.document.all.divbook.style.display="none"
					window.document.frmdepins.txtlsno.value=""
					window.document.frmdepins.txtlstartno.value =""
					window.document.frmdepins.txtlendno.value=""
					window.document.frmdepins.txtnoofleaves.value=""
					
				}
			}
	}
		
	}
	}

</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" bgcolor="#c7ba95" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);frmload()">

<form name="frmdepins">
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <table border="0" width="100%" class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="11%" height="28"><img border="0" src="file://Comsvr/C/CashFinal/cutimages/blanktextbox.gif" width="90" height="19"><img border="0" height="19" src="file://Comsvr/C/CashFinal/cutimages/blanktextbox.gif" width="70"></td>
              <td width="89%" height="28">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="100%"><img border="0" height="22" name="placeholder" src="file://Comsvr/C/CashFinal/dscript42/transparent.gif" width="1"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25">
          </td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Instruments (Stock) Details</font></p>
          </td>
          <td width="33%" nowrap align="right" height="25"><font class="textwhte"><%=session("applicationdate")%></font></td>
        </tr>
      </table>

    <tr>
      <td width="100%" height="15" align="center"><font face="MS Sans Serif" color="blue" size="3"><%=Request.QueryString("record")%></font></td>
    </tr>
    <tr align="middle">
      <td width="100%" height="15">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor1">
          <td width="23%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Insert&quot;;Clearfields()" checked>
          New</font></td>
          <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Modify&quot;;Clearfields()">
          Modify</font></td>
          <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Delete&quot;;Clearfields()">
          Delete</font></td>
          <td width="25%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Query&quot;;Clearfields()">
          View</font></td>
        </tr>
      </table>

      </td>
    </tr>
    <tr align="middle">
      <td width="100%" height="15">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="96"><font class="textbold">&nbsp;Branch Code&nbsp;</font></b></td>
          <td width="268"><input name="txtbranchcode" size="9" value="<%=SESSION("BRANCHCODE")%>" readonly maxlength="4" color="white"><input type="button" value=" L " name="cmdbranch" onclick="branch()" readonly class="bgcolor"><input name="txtbranchdesc" value="<%=session("Branchnarration")%>" readonly size="16"></td>
          <td align="right" width="163"><font class="textbold">Instrument
          Code&nbsp;&nbsp;</font></td>
          <td align="right" width="227"><input name="txtinstrcode" size="9" color="white" readonly maxlength="4"><input type="button" value=" L " name="cmdinstr" onclick="instrument()" class="bgcolor"><input name="txtinstrdesc" readonly  size="16" maxlength="20"></td>
        </tr>
      </table>

      </td>
    </tr>
    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="756" height="15" colspan="2"></td>
        </tr>
        <tr class="bgcolor">
          <td width="122" height="26"><font size="2" face="MS Sans Serif">&nbsp;</font><input type="radio" value="Book" checked name="Radtype" onclick="Display()"><font class="textwhite">Book</font></td>
          <td width="632" height="26"><input type="radio" value="Leaf" name="Radtype" onclick="Display()"><font class="textwhite">Leaf</font></td>
        </tr>
      </table>

      <div align="center" id="divbook" style="DISPLAY: block">
        <center>
        <div align="center">
          <center>

          <table border="0" width="99%" cellspacing="1" cellpadding="0" class="tableborder2">
            <tbody>
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="748" colspan="10" height="20"><font class="subheading">Available
                    Book Stock Details</font></td>
                  </tr>
                  <tr>
                    <td width="748" height="20" colspan="10"></td>
                  </tr>
                  <tr>
                    <td width="60" height="20"><font class="textsmall">&nbsp;Series
                    No.</font></td>
                    <td height="20" width="103"><font class="textsmall"><input name="txtsno" size="9" style="TEXT-TRANSFORM: uppercase" onblur="Bookcheck()" maxlength="10"><input type="button" value=" L " name="Cmdsno" onclick="instrsno();Query()" class="bgcolor"></font></td>
                    <td width="118" height="20" align="right"><font face="MS Sans Serif" size="1">No
                    of Leaves per book</font></td>
                    <td width="61" height="20"><font class="textsmall"><input name="txtnlpbook" size="6" onkeypress="numeric()" onkeyup="Getstedno()" maxlength="10"></font></td>
                    <td width="76" height="20" align="right"><font face="MS Sans Serif" size="1">No.
                    Of Books</font></td>
                    <td width="50" height="20"><font class="textsmall"><input name="txtnoofbook" size="6" onkeypress="numeric()" onkeyup="Getstedno()" maxlength="10"></font></td>
                    <td width="60" height="20" align="right"><font face="MS Sans Serif" size="1">Start
                    S.No&nbsp;</font></td>
                    <td width="71" height="20"><font class="textsmall"><input name="txtstartno" size="9" onkeypress="numeric()" onblur="getnoofbook()" maxlength="15"></font></td>
                    <td width="56" height="20" align="right"><font face="MS Sans Serif" size="1">End
                    S.No.&nbsp;</font></td>
                    <td width="75" height="20"><font class="textsmall"><input name="txtendno" size="9" onkeypress="numeric()" readonly maxlength="15"></font></td>
                  </tr>
                  <center></center><center>
                  </table>

                  <p>&nbsp;

                </center></td>
              </tr>
          </table>

          </center>
        </div>
        </div>
        <div align="center" id="divleaf" style="DISPLAY: none">
          <center>
          <div align="center">
            <center>

            <table border="0" width="99%" cellspacing="0" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="748" height="20" colspan="8"><font class="subheading">Available
                    Leaf&nbsp; Details</font></td>
                  </tr>
                  <tr>
                    <td width="748" height="20" colspan="8"></td>
                  </tr>
                  <tr>
                    <td height="20" width="62"><font class="textsmall">&nbsp;Series
                    No.</font></td>
                    <td width="135" height="20"><font class="textsmall"><input name="txtlsno" size="9" style="TEXT-TRANSFORM: uppercase" onblur="Leafcheck()" maxlength="20"><input type="button" value=" L " name="B3" onclick="instrsno();Query()" class="bgcolor"></font></td>
                    <td width="94" height="20" align="right"><font class="textsmall">No.
                    of Leaves &nbsp;</font></td>
                    <td width="73" height="20"><font class="textsmall"><input name="txtnoofleaves" size="9" onkeypress="numeric()" onkeyup="getleafeno()" maxlength="10"></font></td>
                    <td width="92" height="20" align="right"><font class="textsmall">Starting
                    Sl.No &nbsp;</font></td>
                    <td width="72" height="20"><font class="textsmall"><input name="txtlstartno" size="9" onkeypress="numeric()" onblur="getnoofleaves()" maxlength="15"></font></td>
                    <td width="130" height="20" align="right"><font class="textsmall">End
                    S.No.&nbsp;</font></td>
                    <td width="76" height="20" align="right"><font class="textsmall"><input name="txtlendno" size="9" onkeypress="numeric()" readonly maxlength="15"></font></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
          </center>
        </div>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%" height="20"></td>
          </tr>
          <tr>
            <td width="100%" height="20"></td>
          </tr>
          <tr>
            <td width="100%" height="20"></td>
          </tr>
          <tr>
            <td width="100%">
            <div align="center">
              <center><input type="hidden" name="hidstno"><input type="hidden" name="hidedno">

              <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="100%"><input type="button" value="    Ok    " name="butok" onclick="Insert()" class="bgcolor"><input type="button" value="Cancel" name="cmdCan" onclick="Cmdcan()" class="bgcolor"><input type="button" value="   Exit   " name="B5"  class="bgcolor" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.asp"%>&quot;">
                </tr>
              </table>

              <input type="hidden" name="hidstatus"></center>
            </div>
            </td>
          </tr>
        </table>

      </center>
  </table>

</form>

</body>

</html>

