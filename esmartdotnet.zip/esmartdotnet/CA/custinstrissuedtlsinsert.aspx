<%@ Page Language="vb" CodeBehind="custinstrissuedtlsinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Custinstrissuedtlsinsert" %>
<%
	dim ObjCust 'object variables
	dim strmsg
	dim brcode,crcode 'to store textbox values
		
		brcode=Request.Form("txtbranchcode")
		curcode=Request.Form("txtcurrencycode")
		modcode=Request.Form("txtmodulecode")
		glcode=Request.Form("txtglcode")
		accno=Request.Form("txtaccno")
		inscode=Request.Form("txtinstrcode")
		customercode=Request.Form("txtcustomercode")
		custname=Request.Form("txtcustomername")
		rtype=Request.Form("Radtype")
		serno=Request.Form("txtserno")
		nlpb=Request.Form("txtlpboook")
		st=Request.Form("status")
		if ucase(trim(rtype))="BOOK" then
		nobooks=Request.Form("txtnobooks")
		ELSEif ucase(trim(rtype))="LEAF" then
		nobooks=Request.Form("txtnoofleaves")
		END IF
		
		'startno=Request.Form("txtstartno")
		'endno=Request.Form("txtendno")
		
		lserno=Request.Form("txtlserno")
		nol=Request.Form("txtnoofleaves")
		lstartno=Request.Form("txtlstartno")
		lendno=Request.Form("txtlendno")
		session("Applicationdate")="02-jun-2001"
		deptrecdate="2-jun-2001"
		status=Request.Form("hidstatus")
		USERID="UID"
		MACHINEID="MID"
		PreStNo=Request.Form("hidprestartno")
		preEdNo=Request.Form("hidpreendno")
		
		'Response.Write PreStNo
		'Response.Write preEdNo
	
		'''''-----------Componenet for insert
		
	IF LEN(TRIM(brcode))>0 AND LEN(TRIM(curcode))>0 AND LEN(TRIM(modcode))>0 AND LEN(TRIM(glcode))>0 AND LEN(TRIM(accno))>0  then
	
		hidchequesno=Request.Form("hidchequesno")
		hidchequeeno=Request.Form("hidchequeeno")
				
		'Response.Write hidchequesno&"<br>"
		'Response.Write hidchequeeno&"<br>"
		chequesno=split(hidchequesno,"|")
		chequeeno=split(hidchequeeno,"|")
		
		dim Stno()
		redim Stno(nobooks-1)
		dim Edno()
		REdim Edno(nobooks-1)
		if trim(nobooks)>1 then
		for j= 0 to nobooks-1
				Stno(j)=chequesno(j+1)
				Edno(j)=chequeeno(j+1)
				Response.Write Stno(j)&"prasad"&"<br>"
				Response.Write Edno(j)&"prasad"&"<br>"
			next
		else
			for j= 0 to nobooks-1
				Stno(j)=hidchequesno
				Edno(j)=hidchequeeno
			next
		
		end if
		if st="Insert" then
		set ObjCust=server.CreateObject("GenCustChqInsert.CustChqInsert")
		if ucase(trim(rtype))="BOOK" then
			startno= stno(lbound(stno))
			endno= edno(ubound(edno))
			strmsg=ObjCust.CustInstrInsert(cstr(curcode),cstr(brcode),cstr(modcode),cstr(glcode), cstr(accno),cstr(customercode),cstr(inscode), cstr(session("Applicationdate")),"B",cstr(serno),cstr(startno),cstr(EndNo),cstr(nlpb),cstr(nobooks), Stno, Edno) 
		elseif  ucase(trim(rtype))="LEAF" then
        
		Response.Write cstr(curcode)&"<br>"
		Response.Write cstr(brcode)&"<br>"
		Response.Write cstr(modcode)&"<br>"
		Response.Write cstr(glcode)&"<br>"
		Response.Write cstr(accno)&"<br>"
		Response.Write cstr(customercode)&"<br>"
		Response.Write cstr(inscode)&"<br>"
		Response.Write cstr(session("Applicationdate"))&"<br>"
		Response.Write cstr(lserno)&"<br>"
		Response.Write cstr(lstartno)&"<br>"
		Response.Write cstr(nol)&"prasad"
		
		
		lstartno= stno(lbound(stno)) 
		lendno= edno(ubound(edno)) 
			
		'strmsg=ObjCust.CustInstrInsert(cstr(curcode),cstr(brcode),cstr(modcode),cstr(glcode), cstr(accno),cstr(customercode),cstr(inscode),cstr(session("Applicationdate")),"L", cstr(lserno), cstr(lstartno),"","", cstr(nol), Stno, Edno)
	    
	  
	    end if
	    
	
    	Response.Redirect "custinstrissuedtls.asp?record=" & strmsg
    		
   ''' This is code is used to modify the customer cheqdtls 		
	elseif st="Modify" then

	
			 dim ArrTrans(1,4)
		set ObjTran=server.CreateObject("GeneralTransactions.DBTransactions")
		'''' updating in dept table
		if ucase(trim(rtype))="BOOK" then
			ArrTrans(0,0)="U"
			ArrTrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
			ArrTrans(0,2)="BOOKCHQSTNO,BOOKCHQENDNO,status,accno,glcode,CUSTOMERID," &  _
						"CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE"
			ArrTrans(0,3)="''~''~'ISSUABLE'~''~''~''~''~''~''"
			ArrTrans(0,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"upper(trim(instrcode))='" & inscode &"' and " & _
						"upper(trim(bookseriesno))='" & serno &"' and " & _
						"trim(leavesperbook)=" & nlpb &" and " & _
						"upper(trim(status))='P' and " & _
						"to_number(bookstartno)>=" & PreStNo &" and " & _
						"to_number(bookendno)<=" & PreEdNo &" and " & _
						"accno is not null"
			
			elseif  ucase(trim(rtype))="LEAF" then	
		
			ArrTrans(0,0)="U"
			ArrTrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
			ArrTrans(0,2)="LEAFNUMBER,status,accno,glcode,CUSTOMERID," &  _
						"CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE"
			ArrTrans(0,3)="''~'ISSUABLE'~''~''~''~''~''~''"
			ArrTrans(0,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"upper(trim(instrcode))='" & inscode &"' and " & _
						"upper(trim(leafseriesno))='" & lserno &"' and " & _
						"upper(trim(status))='P' and " & _
						"to_number(leafnumber)>=" & PreStNo &" and " & _
						"to_number(leafnumber)<=" & PreEdNo &" and " & _
						"accno is not null"
			
			end if		
			'''deleting rows from genchequedtls.	
			ArrTrans(1,0)="D"
			ArrTrans(1,1)="GENchequedtls"
			ArrTrans(1,2)=""
			ArrTrans(1,3)=""
			if  ucase(trim(rtype))="BOOK" then	
			ArrTrans(1,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						  "upper(trim(moduleid))='" & modcode &"' and " & _
						  "upper(trim(glcode))='" & glcode &"' and " & _
						  "upper(trim(accno))='" & accno &"' and " & _
						  "to_number(chequeno)>=" & PreStno &" and " & _
						  "to_number(chequeno)<=" & PreEdNo &" and " & _
						  "upper(trim(CHQSERIESNO))='" & serno &"'"
						  
			Response.Write ArrTrans(1,4)						  
						
			elseif  ucase(trim(rtype))="LEAF" then
			ArrTrans(1,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"to_number(chequeno)>=" & PreStno &" and " & _
						"to_number(chequeno)<=" & PreEdNo &" and " & _
						"to_number(leafnumber)>=" & PreStNo &" and " & _
						"to_number(leafnumber)<=" & PreEdNo &" and " & _
						"upper(trim(CHQSERIESNO))='" & lserno &"'"
			end if
			Strmsg= OBJtran.DataTransactions(ArrTrans)
				
			
				
		if strmsg="Transaction Sucessful." then
		'''' insert new rows into genchequedtls
			set ObjCust=server.CreateObject("GenCustChqInsert.CustChqInsert")	
		if ucase(trim(rtype))="BOOK" then
			startno= stno(lbound(stno)) 
			endno= edno(ubound(edno)) 
			strmsg1=ObjCust.CustInstrInsert(cstr(curcode),cstr(brcode),cstr(modcode),cstr(glcode), cstr(accno),cstr(customercode),cstr(inscode), cstr(session("Applicationdate")),"B",cstr(serno),cstr(startno),cstr(EndNo),cstr(nlpb),cstr(nobooks), Stno, Edno) 
    
        elseif  ucase(trim(rtype))="LEAF" then
			startno= stno(lbound(stno)) 
			endno= edno(ubound(edno)) 
			strmsg1=ObjCust.CustInstrInsert(cstr(curcode),cstr(brcode),cstr(modcode),cstr(glcode), cstr(accno),cstr(customercode),cstr(inscode),cstr(session("Applicationdate")),"L", cstr(lserno), cstr(lstartno),"","", cstr(nol), Stno, Edno)
	
	    end if
		   Response.Redirect "custinstrissuedtls.asp?record=" & strmsg1
		end if										
				
	elseif st="Delete" then
	
		redim ArrTrans(1,4)
		set ObjTran=server.CreateObject("GeneralTransactions.DBTransactions")
		'''' updating in dept table
		if ucase(trim(rtype))="BOOK" then
		startno= stno(lbound(stno)) 
		endno= edno(ubound(edno))
		
			ArrTrans(0,0)="U"
			ArrTrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
			ArrTrans(0,2)="BOOKCHQSTNO,BOOKCHQENDNO,status,accno,glcode,CUSTOMERID," &  _
						"CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE"
			ArrTrans(0,3)="''~''~'ISSUABLE'~''~''~''~''~''~''"
			ArrTrans(0,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"upper(trim(instrcode))='" & inscode &"' and " & _
						"upper(trim(bookseriesno))='" & serno &"' and " & _
						"trim(leavesperbook)=" & nlpb &" and " & _
						"upper(trim(status))='P' and " & _
						"to_number(bookstartno)>=" & startno &" and " & _
						"to_number(bookendno)<=" & endno &" and " & _
						"accno is not null"
			
			ArrTrans(1,0)="D"
			ArrTrans(1,1)="GENchequedtls"
			ArrTrans(1,2)=""
			ArrTrans(1,3)=""
			ArrTrans(1,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"to_number(chequeno)>=" & startno &" and " & _
						"to_number(chequeno)<=" & endno &" and " & _
						"upper(trim(CHQSERIESNO))='" & serno &"'"	
			
			elseif  ucase(trim(rtype))="LEAF" then	
			lstartno= stno(lbound(stno)) 
			lendno= edno(ubound(edno)) 
			ArrTrans(0,0)="U"
			ArrTrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
			ArrTrans(0,2)="LEAFNUMBER,status,accno,glcode,CUSTOMERID," &  _
						"CHRGAPPSTATUS,CHRGAMOUNT,CHRGAPPDATE"
			ArrTrans(0,3)="''~'ISSUABLE'~''~''~''~''~''~''"
			ArrTrans(0,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"upper(trim(instrcode))='" & inscode &"' and " & _
						"upper(trim(leafseriesno))='" & serno &"' and " & _
						"upper(trim(status))='P' and " & _
						"to_number(leafnumber)>=" & lstartno &" and " & _
						"to_number(leafnumber)<=" & lendno &" and " & _
						"accno is not null"
								
			ArrTrans(1,0)="D"
			ArrTrans(1,1)="GENchequedtls"
			ArrTrans(1,2)=""
			ArrTrans(1,3)=""
			ArrTrans(1,4)="upper(trim(branchcode))='" & brcode &"' and " & _
						"upper(trim(moduleid))='" & modcode &"' and " & _
						"upper(trim(glcode))='" & glcode &"' and " & _
						"upper(trim(accno))='" & accno &"' and " & _
						"to_number(chequeno)<=" & lstartno &" and " & _
						"to_number(chequeno)>=" & lendno &" and " & _
						"upper(trim(CHQSERIESNO))='" & serno &"'"			
			end if
			
			'''deleting rows from genchequedtls			
			
			Strmsg= OBJtran.DataTransactions(ArrTrans)
			Response.Redirect "custinstrissuedtls.asp?record=" & strmsg				
								
	end if
	else	
	 Response.Redirect "custinstrissuedtls.asp?record=Fields Should Not be Null"
			
	end if
%>
