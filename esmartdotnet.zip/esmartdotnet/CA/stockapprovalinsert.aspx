<%@ Page Language="vb" CodeBehind="stockapprovalinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_stockapprovalinsert" %>
<%
Dim Obj 'object variable.
Dim strmsg 
Dim brcode,inscode 'To store textbox values.
Dim Arrtrans(0,4) 
Dim flexval,flex,flexstr,transtr,str,strvalues
Dim modid,uid,leno,lserno,lsno,status,nol
Dim ssno

'Storing Branch,Instrument details.
appdate=session("applicationdate")
uid=session("userid")
macid=session("machineid")


brcode=trim(Request.Form("txtbranchcode"))
inscode=trim(Request.Form("txtinstrcode"))
insdesc=trim(Request.Form("txtinstrdesc"))
status=trim(Request.Form("hidstatus"))
rtype=trim(Request.Form("Radtype"))
esno=trim(Request.Form("txtendsno"))
nlpb=trim(Request.Form("txtnoleavesperbook"))
serno=trim(Request.Form("txtserno"))
ssno=trim(Request.Form("txtssno"))
nol=trim(Request.Form("txtnol"))

leno=trim(Request.Form("txtleno"))
lserno=trim(Request.Form("txtlserno"))
lsno=trim(Request.Form("txtlsno"))
	
Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")				
if len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVEALL" then
	flexval=Request.Form("hidflex")
	'Response.Write flexval&"<br>"
	flex=split(flexval,"*|*")
	for irow=1 to ubound(flex)
		flexstr=split(flex(irow),"~!~")
		if len(trim(flexstr(2)))> 0 then
		strwhere= strwhere & "trim(BRANCHCODE)='" & trim(brcode) & "' " & _
			 "AND INSTRCODE='" & trim(flexstr(1)) & "' " & _
			 "AND LEAVESPERBOOK='" & trim(flexstr(4)) & "' " & _
			 "AND BOOKSERIESNO='" & trim(flexstr(2)) & "' " & _
			 "AND NOOFBOOKS=" & trim(flexstr(5)) & " " & _
			 "AND BOOKSTARTNO=" & trim(flexstr(7)) & " " & _
			 "AND BOOKENDNO=" & trim(flexstr(8)) & " " & _
			 "AND TRANSTATUS<>'A'" & "|"
		elseif len(trim(flexstr(3)))> 0 then
		strwhere= strwhere & "trim(BRANCHCODE)='" & trim(brcode) & "' " & _
			 "AND INSTRCODE='" & trim(flexstr(1)) & "' " & _
			 "AND LEAFSERIESNO='" & trim(flexstr(3)) & "' " & _
			 "AND LEAFSTARTNO=" & trim(flexstr(9)) & " " & _
			 "AND LEAFENDNO=" & trim(flexstr(10)) & " " & _
			 "AND NOOFLEAVES=" & trim(flexstr(6)) & " " & _
			 "AND TRANSTATUS<>'A'" & "|"
		end if
		str="TRANSTATUS,applicationdate,APPROVEDBY,APPROVEDMACHINE"
		strvalues=strvalues &"'A'~'" & appdate & "'~'" & uid & "'~'" & macid & "'~'|"
	next
		strwhere=left(strwhere,len(strwhere)-1)
		strvalues=left(strvalues,len(strvalues)-1)
		        
        
		
		Arrtrans(0,0)="U"
		'passing the table name
		Arrtrans(0,1)="GENINSTRUMENTSTOCKDTLS"
		'passing columns
		Arrtrans(0,2)=str
		'passing values
		Arrtrans(0,3)=strvalues
		'passing where condition
		Arrtrans(0,4)=strwhere
		
		Strmsg= OBJ.DataTransactions(ArrTrans)
		
		result=strmsg&"~!~"&inscode&"~!~"&insdesc
		
		Response.Redirect "stockaaproval.asp?result=" & result

elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVE" then
	
	if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "'"
		transtr="A"
		strvalues="'" & transtr & "'"
		str="TRANSTATUS,applicationdate,APPROVEDBY,APPROVEDMACHINE"
		strvalues="'A'~'" & appdate & "'~'" & uid & "'~'" & macid & "'~'"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENINSTRUMENTSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND LEAFSTARTNO='" & trim(lsno) & "' AND  LEAFENDNO='" & trim(leno) & "'"
		
		Response.Write strwhere
		
		transtr="A"
		str="TRANSTATUS,applicationdate,APPROVEDBY,APPROVEDMACHINE"
		strvalues="'A'~'" & appdate & "'~'" & uid & "'~'" & macid & "'~'"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENINSTRUMENTSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	end if
	Strmsg= OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "stockaaproval.asp?result=" & result 
elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="REJECT" then
   if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "'"
		transtr="R"
		str="TRANSTATUS,applicationdate,APPROVEDBY,APPROVEDMACHINE"
		strvalues="'R'~'" & appdate & "'~'" & uid & "'~'" & macid & "'~'"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENINSTRUMENTSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "'  AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND LEAFSTARTNO='" & trim(lsno) & "' AND  LEAFENDNO='" & trim(leno) & "'"
		
		Response.Write STRWHERE
		
		transtr="R"
		
		str="TRANSTATUS,applicationdate,APPROVEDBY,APPROVEDMACHINE"
		strvalues="'R'~'" & appdate & "'~'" & uid & "'~'" & macid & "'~'"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENINSTRUMENTSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues
	'passing where condition
		Arrtrans(0,4)=strwhere
	end if
	Strmsg=OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "stockaaproval.asp?result=" & result 
else
	strmsg="Fields Should not be Null"
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "stockaaproval.asp?result=" & result
end if	
%>
