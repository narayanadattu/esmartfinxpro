<%@ Page CodeBehind="deptinstrstockdtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Deptinstrstockdtls" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Dept Instrument Details</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var Mode="Insert"
//To Get Branchcode
function clea()
{
	window.document.frmdepins.txtbranchcode.value=""
	window.document.frmdepins.txtbranchdesc.value=""
	window.document.frmdepins.txtuserid.value=""
	window.document.frmdepins.txtuserdesc.value=""
	window.document.frmdepins.txtmodulecode.value=""
	window.document.frmdepins.txtmoduledesc.value=""
	window.document.frmdepins.txtinstrcode.value=""
	window.document.frmdepins.txtinstrdesc.value=""
	window.document.frmdepins.txtserno.value=""
	window.document.frmdepins.txtnoleavesperbook.value=""
	window.document.frmdepins.txtnobook.value=""
	window.document.frmdepins.txtssno.value=""
	window.document.frmdepins.txtendsno.value=""
	window.document.frmdepins.txtlserno.value=""
	window.document.frmdepins.txtnol.value=""
	window.document.frmdepins.txtlstartno.value=""
	window.document.frmdepins.txtlendno.value=""
	window.document.frmdepins.hidstatus.value=""
	window.document.frmdepins.hidnoofbl.value=""
	window.document.all.divdd1.src="../GENSBCA/dddtls.aspx"
	window.document.all.ifrastockdtls.src="stockdtls.asp"

	//window.document.frames(0).frmstock.action="stockdtls.asp"
	//window.document.frames(0).frmstock.method="post"
	//window.document.frames(0).frmstock.submit()
}


function branch()
{   
	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
}	
function Branchcode(str)
{
	assign(str,window.document.frmdepins.txtbranchdesc,window.document.frmdepins.txtbranchcode)
	instrclear()
	window.document.frmdepins.txtmodulecode.value=""
	window.document.frmdepins.txtmoduledesc.value=""
	window.document.frmdepins.txtuserdesc.value=""
	window.document.frmdepins.txtuserid.value=""
		
}
//To get Userid
function Touser(){
	st="User"
	window.open("Listquery.asp" + "?" +"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
}

function usercode(str)
{
	assign(str,window.document.frmdepins.txtuserdesc,window.document.frmdepins.txtuserid)
	instrclear()
	window.document.frmdepins.txtmodulecode.value=""
	window.document.frmdepins.txtmoduledesc.value=""

}

//To get Moduleid
function module(){

	stmod="Commodule"; 
	stbr=window.document.frmdepins.txtbranchcode.value
	str=stmod+"|"+stbr
	window.open("Listquery.asp?st="+str,"mod","width=250%,height=150% left=60 top=50");
 }

function modulecode(str)
{	
	assign(str,window.document.frmdepins.txtmoduledesc,window.document.frmdepins.txtmodulecode)
	instrclear()
}

function instrclear()
{
		bookclear()
		leafclear()
		window.document.frmdepins.Radtype(1).disabled=false
		window.document.frmdepins.txtinstrcode.value=""
		window.document.frmdepins.txtinstrdesc.value=""
		window.document.frmdepins.txtserno.value=""
		window.document.frmdepins.txtnoleavesperbook.value=""
		window.document.frmdepins.txtlserno.value=""
}

//To get Instrumentcode
function instrument(){
		var modid	
		modid=window.document.frmdepins.txtmodulecode.value
		if(modid=="REM")
		{
			st="Reminstrument"
			window.open("Listquery.asp" + "?" +"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
		}
		else
		{
			st="DDinstrument"
			window.open("Listquery.asp" + "?" +"st="+st,st,"width=200%,height=150%,left=140%,top=210%")
					
		}
}

function ddbook()
{
//if(window.document.frmdepins.txtnobook.value=="")
//{
//alert("No of Books Cannot be Null..")
//window.document.frmdepins.txtnobook.focus()
//return
//}

if(window.document.frmdepins.hmsg.value=="true")
{
alert('Cannot give More than Avalible Stock')
window.document.frmdepins.txtnobook.focus()
return
}
if(window.document.frmdepins.txtinstrcode.value=="DD")
{
	if(Mode=="Insert")
	{
		var nobooks=window.document.frmdepins.txtnobook.value
		var leaves=window.document.frmdepins.txtnoleavesperbook.value
		
		
		stnoofb=window.document.frmdepins.txtnobook.value
		stsno=window.document.frmdepins.txtssno.value
		steno=window.document.frmdepins.txtendsno.value
		stdata=window.document.frmdepins.hiddata.value 		
		window.document.frames(1).frmdd.hiddd.value="book"+"*"+nobooks+"*"+leaves+"*"+stnoofb+"*"+stsno+"*"+steno+"*"+stdata
		window.document.frames(1).frmdd.action="../GENSBCA/dddtls.aspx"
		window.document.frames(1).frmdd.method="post"
		window.document.frames(1).frmdd.submit()
	}
	else if(Mode=="Modify" || Mode=="Delete")
	{	
		stbra=window.document.frmdepins.txtbranchcode.value
		stins=window.document.frmdepins.txtinstrcode.value
		stser=window.document.frmdepins.txtserno.value
		stuser=window.document.frmdepins.txtuserid.value
		stmod=window.document.frmdepins.txtmodulecode.value
		stlpb=window.document.frmdepins.txtnoleavesperbook.value
		stnoofb=window.document.frmdepins.txtnobook.value
		stsno=window.document.frmdepins.txtssno.value
		steno=window.document.frmdepins.txtendsno.value
		oldeno=window.document.frames(0).frmstock.stockdtls.textmatrix(window.document.frames(0).frmstock.stockdtls.rows-1,2)
		window.document.frames(1).frmdd.hiddd.value="book"+"*"+"MODIFY"+"*"+stbra+"*"+stuser+"*"+stmod+"*"+stins+"*"+stser+"*"+stlpb+"*"+stnoofb+"*"+stsno+"*"+steno+"*"+oldeno
		window.document.frames(1).frmdd.action="../GENSBCA/dddtls.aspx"
		window.document.frames(1).frmdd.method="post"
		window.document.frames(1).frmdd.submit()
	}
	
}
}

function instrcode(str)
{
	assign(str,window.document.frmdepins.txtinstrdesc,window.document.frmdepins.txtinstrcode)
	if(window.document.frmdepins.txtinstrcode.value=="DD")
	{
		window.document.frmdepins.Radtype(1).disabled=true
	}
	else
	{
		window.document.frmdepins.Radtype(1).disabled=false
	}
		bookclear()
		leafclear()
		window.document.frmdepins.txtserno.value=""
		window.document.frmdepins.txtnoleavesperbook.value=""
		window.document.frmdepins.txtlserno.value=""
}

function chknoofbookleaves()
{
	
	if(window.document.frmdepins.hidnoofbl.value)
	{
		
		if(window.document.frames(0).frmstock.hidtype.value=="Book")
		{
			if(eval(window.document.frmdepins.txtnobook.value)==0)
			{
			alert("Cannot be ZERO..")
			window.document.frmdepins.txtnobook.value=""
			window.document.frmdepins.txtnobook.focus()
			return
			}
			if(eval(window.document.frmdepins.txtnobook.value)>eval(window.document.frmdepins.hidnoofbl.value) || eval(window.document.frmdepins.txtnobook.value)<1)
			{
				
				alert('Cannot give More than Avalible Stock')
				//window.document.frmdepins.txtnobook.value=""
				//window.document.frmdepins.txtssno.value=""
				//window.document.frmdepins.txtendsno.value=""
				window.document.all.divdd1.src="../GENSBCA/dddtls.aspx"
				window.document.frmdepins.txtnobook.focus()
				window.document.frmdepins.hmsg.value="true"
			}
			else
			{
				window.document.frmdepins.hmsg.value="false"
				if(window.document.frmdepins.txtnobook.value)
				{
				startno=eval(window.document.frmdepins.txtssno.value)
				nlpbook=eval(window.document.frmdepins.txtnoleavesperbook.value)
				noofbooks=eval(window.document.frmdepins.txtnobook.value)
				no=eval(nlpbook)*eval(noofbooks)
				endno=eval(no)-eval(1)+eval(startno)
				if(isNaN(endno)==false)
					{
						window.document.frmdepins.txtendsno.value=endno
					}
										
				}
				
			}
		}
		else if(window.document.frames(0).frmstock.hidtype.value=="Leaf")
		{
			if(eval(window.document.frmdepins.txtnol.value)==0)
			{
			alert("Cannot be ZERO..")
			window.document.frmdepins.txtnol.value=""
			window.document.frmdepins.txtnol.focus()
			return
			}
			
			if(eval(window.document.frmdepins.txtnol.value)>eval(window.document.frmdepins.hidnoofbl.value) || eval(window.document.frmdepins.txtnol.value)<1)
			{
				alert('Cannot give More than Avalible Stock')
				window.document.frmdepins.txtnol.value=""
				window.document.frmdepins.txtnol.focus()
				window.document.frmdepins.hmsg.value="true"
			}
			else
			{
			window.document.frmdepins.hmsg.value="false"
			if(window.document.frmdepins.txtnol.value!="")
				{
				startno=eval(window.document.frmdepins.txtlstartno.value)
				nl=eval(window.document.frmdepins.txtnol.value)
				endno=eval(nl)+eval(startno)-1
				if(isNaN(endno)==false)
				 {
					window.document.frmdepins.txtlendno.value=endno
				 }
				}
				
			}
		
		}
	}
}
	
//-->
</SCRIPT>
<script language=javascript>
function Cmdcan(){
	location.replace("deptinstrstockdtls.asp")
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
//To Get Stock Details,if Instrtype is BOOK.
function BookSeriesdtls(){
	
		stbra=window.document.frmdepins.txtbranchcode.value
		stins=window.document.frmdepins.txtinstrcode.value
		stser=window.document.frmdepins.txtserno.value
		stlpb=window.document.frmdepins.txtnoleavesperbook.value
		Radlen =window.document.frmdepins.Radtype.length
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmdepins.Radtype(i).checked==true)
		  {
			sttype=window.document.frmdepins.Radtype(i).value
		  }
		}
		sy="|"
		if(Mode=="Insert")
		{
			st=stbra+sy+stins+sy+stser+sy+stlpb+sy+sttype+sy+Mode
		}
		else
		{
			stissue=window.document.frmdepins.txtuserid.value
			stmod=window.document.frmdepins.txtmodulecode.value
			//Mode="Modify"
			st=stbra+sy+stins+sy+stser+sy+stlpb+sy+sttype+sy+stissue+sy+stmod+sy+Mode
		}
		bookclear()
		window.document.frames(0).frmstock.hidstock.value=st
		window.document.frames(0).frmstock.action="stockdtls.asp"
		window.document.frames(0).frmstock.method="post"
		window.document.frames(0).frmstock.submit()
		
}
function bookclear()
	{
		window.document.frmdepins.txtendsno.value=""
		window.document.frmdepins.txtnobook.value=""
		window.document.frmdepins.txtssno.value=""
		window.document.all.ifrastockdtls.src="stockdtls.asp"
		window.document.all.divdd1.src="../GENSBCA/dddtls.aspx"
	}
//To Stock Details,if Instrtype is LEAF.
function LeafSeriesdtls(){

		st1=window.document.frmdepins.txtbranchcode.value 
		st2=window.document.frmdepins.txtinstrcode.value
		st3=window.document.frmdepins.txtlserno.value 
		st4=window.document.frmdepins.txtnol.value
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmdepins.Radtype(i).checked==true)
		{
		st5=window.document.frmdepins.Radtype(i).value
		}
		}
		sy="|"
		if(Mode=="Insert")
		{
			st=st1+sy+st2+sy+st3+sy+st4+sy+st5+sy+Mode
		}
		else
		{
			stissue=window.document.frmdepins.txtuserid.value
			stmod=window.document.frmdepins.txtmodulecode.value
			//Mode="Modify"
			st=st=st1+sy+st2+sy+st3+sy+st4+sy+st5+sy+stissue+sy+stmod+sy+Mode
		}
		leafclear()
		window.document.frames(0).frmstock.hidstock.value=st
		window.document.frames(0).frmstock.action="stockdtls.asp"
		window.document.frames(0).frmstock.method="post"
		window.document.frames(0).frmstock.submit()
		
}

function leafclear(){

		window.document.frmdepins.txtlendno.value=""
		window.document.frmdepins.txtlstartno.value=""
		window.document.frmdepins.txtnol.value=""
		window.document.all.ifrastockdtls.src="stockdtls.asp"
	}

//To get seriesno and noofleavesperbook for Book.
function serandpages(){

	brcode=window.document.frmdepins.txtbranchcode.value
	instr=window.document.frmdepins.txtinstrcode.value
	user=window.document.frmdepins.txtuserid.value
	mod=window.document.frmdepins.txtmodulecode.value
	sy="|"
	if(brcode!="" && instr!="" && user!="" && mod!="")
	{
	if(Mode=="Insert")
	{
		str="Series"
		st=str+sy+brcode+sy+instr
		window.open("Listquery.asp"+"?"+"st="+st,"series","width=200%,height=150%,left=140%,top=210%")
	}
	else if(Mode=="Modify"||Mode=="Delete"||Mode=="Query")
	{
		str="Deptmodify"
		st=str+sy+brcode+sy+instr+sy+user+sy+mod
		window.open("Listquery.asp"+"?"+"st="+st,"series","width=200%,height=150%,left=140%,top=210%")
	}
	}
	else
	{
			alert('Please Select ToUserid,Module Id and Instrument Code')
  	}
}
function serpagedet(str){

		assign(str,window.document.frmdepins.txtserno,window.document.frmdepins.txtnoleavesperbook)
		BookSeriesdtls()
}
function okdis(){
if(Mode=="Query")
{
	window.document.frmdepins.butok.disabled=true
	window.document.frmdepins.txtnobook.disabled=true
}
else
{
	window.document.frmdepins.butok.disabled=false
}
}
//To get seriesno and noofleaves  for leaf.
function leafandpages()
{
	brcode=window.document.frmdepins.txtbranchcode.value
	instr=window.document.frmdepins.txtinstrcode.value
	user=window.document.frmdepins.txtuserid.value
	mod=window.document.frmdepins.txtmodulecode.value
	sy="|"
	
 if(brcode!="" && instr!="" && user!="" && mod!="")
  {	
	if(Mode=="Insert")
	{
		str="DeptLeafseries"
		st=str+sy+brcode+sy+instr
		window.open("singlequery.asp" + "?" +"st="+st,"series","width=200%,height=150%,left=140%,top=210%")
		
	}
	else if(Mode=="Modify" || Mode=="Query" || Mode=="Delete")
	{
		str="Leafmodify"
		st=str+sy+brcode+sy+instr+sy+user+sy+mod
		window.open("singlequery.asp" + "?" +"st="+st,"series","width=200%,height=150%,left=140%,top=210%")
	}
  }
  else
  {
		alert(' Please Select ToUserid,Module Id and Instrument Code')
  }
}

//Leafseries for Modify

function Leafseriesmod(str)
{
	window.document.frmdepins.txtlserno.value=str
	LeafSeriesdtls()
}

function focusadd()
{
	if(Mode!="Query")
	{
		if(window.document.frmdepins.txtinstrcode.value!="DD")
		{
			window.document.frmdepins.butok.focus();
		}
	}
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
function Display(){
	Radlen =window.document.frmdepins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmdepins.Radtype(i).checked==true)
	{
		if(window.document.frmdepins.Radtype(i).value=="Book")
		{
			if(window.document.all.divbook.style.display=="none")
				{
					window.document.all.divleaf.style.display="none"
					window.document.all.divbook.style.display="block"
					window.document.all.ifrastockdtls.src="stockdtls.asp"
					window.document.all.divdd1.src="../GENSBCA/dddtls.aspx"
					window.document.frmdepins.txtendsno.value=""
					window.document.frmdepins.txtnobook.value=""
					window.document.frmdepins.txtnoleavesperbook.value=""
					window.document.frmdepins.txtssno.value=""
					window.document.frmdepins.txtserno.value=""
				}		
			}
			else if(window.document.frmdepins.Radtype(i).value=="Leaf")
			{
			 if(window.document.all.divbook.style.display=="block")
				{
					window.document.all.divleaf.style.display="block"
					window.document.all.divbook.style.display="none"
					window.document.all.ifrastockdtls.src="stockdtls.asp"
					window.document.frmdepins.txtlserno.value=""
					window.document.frmdepins.txtlstartno.value =""
					window.document.frmdepins.txtlendno.value=""
					window.document.frmdepins.txtnol.value=""
					
				}
			}
	}
		
	}
	}



function Insert()
{
	var ddno
	var deno
	var nsno
	var neno
	if(Mode=="Insert" || Mode=="Modify" || Mode=="Delete")
	{
		for(i=1;i<=window.document.frames(0).frmstock.stockdtls.rows-1;i++)
				{
					nsno=nsno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,1)
					neno=neno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,2)
				}
				window.document.frmdepins.nsno.value=nsno
				window.document.frmdepins.neno.value=neno
		
		Radlen =window.document.frmdepins.Radtype.length
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmdepins.Radtype(i).checked==true)
			{
				Type=window.document.frmdepins.Radtype(i).value
			}
		}
		if(window.document.frmdepins.txtbranchcode.value!="" && 
			window.document.frmdepins.txtinstrcode.value!="")
		{
			if(Type=="Book")
				{
				if(window.document.frmdepins.txtserno.value!="" &&  
					window.document.frmdepins.txtnobook.value!=""  && 
					window.document.frmdepins.txtnoleavesperbook.value!="" && 
					window.document.frmdepins.txtssno.value && 
					window.document.frmdepins.txtendsno.value!="")
					{
						if(window.document.frmdepins.txtinstrcode.value=="DD")
							{
								len=window.document.frames(1).frmdd.txtddsno.length
								if(eval(len)>1)
									{
										sy="|"
   										for(i=0;i<eval(len);i++)
   										{
    										if(window.document.frames(1).frmdd.txtddsno(i).value!="")
												{
													window.document.frmdepins.hidddsno.value=window.document.frmdepins.hidddsno.value+sy+window.document.frames(1).frmdd.txtddsno(i).value
													window.document.frmdepins.hidddeno.value=window.document.frmdepins.hidddeno.value+sy+window.document.frames(1).frmdd.txtddeno(i).value
													if(Mode=="Modify"|| Mode=="Delete")
														{
															window.document.frmdepins.hdmodstno.value=window.document.frmdepins.hdmodstno.value+sy+window.document.frames(1).frmdd.hidmodstno(i).value
															window.document.frmdepins.hdmodedno.value=window.document.frmdepins.hdmodedno.value+sy+window.document.frames(1).frmdd.hidmodedno(i).value
														}
												}
												else
												{
													alert('Enter D.D Start number.')
													return;
												}
	      								}
									      		//for(i=0;i<=window.document.frames(1).frmdd.txtddsno.length-1;i++)
													//	{
													//		ddno=ddno+","+window.document.frames(1).frmdd.txtddsno(i).value
													//		deno=deno+","+window.document.frames(1).frmdd.txtddeno(i).value
													//	}
										for(i=1;i<=window.document.frames(0).frmstock.stockdtls.rows-1;i++)
											{
												ddno=ddno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,1)
												deno=deno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,2)
											}
										alert(ddno)
										alert(deno)
										window.document.frmdepins.hidvals.value=ddno
										window.document.frmdepins.hidenos.value=deno	
	      								window.document.frmdepins.hidstatus.value=""	
										window.document.frmdepins.hidstatus.value=Mode
										window.document.frmdepins.action="deptinstrstockdtlsinsert.asp"
										window.document.frmdepins.method="post"
										window.document.frmdepins.submit()
									}
							else
									{
										if(window.document.frames(1).frmdd.txtddsno.value!="")
											{
											for(i=1;i<=window.document.frames(0).frmstock.stockdtls.rows-1;i++)
												{
													ddno=ddno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,1)
													deno=deno+","+window.document.frames(0).frmstock.stockdtls.textmatrix(i,2)
												}
											window.document.frmdepins.hidddsno.value=window.document.frames(1).frmdd.txtddsno.value
											window.document.frmdepins.hidddeno.value=window.document.frames(1).frmdd.txtddeno.value
											if(Mode=="Modify"||Mode=="Delete")
												{
													window.document.frmdepins.hdmodstno.value=window.document.frames(1).frmdd.hidmodstno.value
													window.document.frmdepins.hdmodedno.value=window.document.frames(1).frmdd.hidmodedno.value
												}
											window.document.frmdepins.hidstatus.value=""	
											window.document.frmdepins.hidstatus.value=Mode
											window.document.frmdepins.hidvals.value=ddno
											window.document.frmdepins.hidenos.value=deno
											alert(ddno+deno)
											window.document.frmdepins.action="deptinstrstockdtlsinsert.asp"
											window.document.frmdepins.method="post"
											window.document.frmdepins.submit()
											}
										else
											{
												alert('Enter D.D Start number.')
												return;
											}
									}
								}
							else{
									window.document.frmdepins.hidstatus.value=""	
									window.document.frmdepins.hidstatus.value=Mode
									//alert(window.document.frmdepins.hidstatus.value)
									// MODIFY MODE
									//alert(window.document.frmdepins.hsno.value)
									window.document.frmdepins.action="deptinstrstockdtlsinsert.asp"
									window.document.frmdepins.method ="post"
									window.document.frmdepins.submit()
								}
							}
							else
							{
									alert("Fields Should not be Null")
							}
						}
						else if(Type=="Leaf")
						{
							if(window.document.frmdepins.txtlserno.value!="" && 
								window.document.frmdepins.txtnol.value!="" && 
								window.document.frmdepins.txtlstartno.value && 
								window.document.frmdepins.txtlendno.value!="")
								{
									window.document.frmdepins.hidstatus.value=""	
									window.document.frmdepins.hidstatus.value=Mode
									//alert(window.document.frmdepins.hidstatus.value)
									window.document.frmdepins.action="deptinstrstockdtlsinsert.asp"
									window.document.frmdepins.method ="post"
									window.document.frmdepins.submit()
								}
							else
								{
									alert("Fields Should not be Null")
								}
					}
				}
				else
				{
					alert("Fields Should not be Null")
				}
		}
		
			
}

</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display()">

<form name="frmdepins">
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" height="28">
          <p align="center">&nbsp;</p>
          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="114%" nowrap height="22">
          <p align="center"><font class="text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          Instruments (Department Stock) Details</p>
          </font></td>
          <td width="86%" nowrap align="right" height="22"><font face="MS Sans Serif" color="#ffffff" size="2"><%=APPDATE%></font></td>
        </tr>
      </table>

      <%if len(Request.QueryString("record"))>0 then%>

      <table align="center">
        <tr>
          <td height="15"><font class="blue"><%=Request.QueryString("record")%></font></td>
        </tr>
      </table>

      <%end if%>
      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tableborder1">
          <tr class="bgcolor1">
            <td width="23%" align="middle"><input type="radio" name="rdtran" onclick="Mode=&quot;Insert&quot;;okdis();clea()" checked><font class="textwhite">
            New</font></td>
            <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Modify&quot;;okdis();clea()">
            Modify</font></td>
            <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Delete&quot;;okdis();clea()">
            Delete</font></td>
            <td width="25%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Query&quot;;okdis();clea()">
            View</font></td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td width="51%" height="20" valign="top">
            <div align="center">
              <center>

              <table width="96%" cellpadding="0">
                <tr>
                  <td>

                  <table border="0" width="355" cellspacing="0" cellpadding="0" class="tableborder2">
                    <tr>
                      <td width="124" height="10"></td>
                      <td width="227" height="10"></td>
                    </tr>
                    <tr>
                      <td width="124" height="28"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;Branch
                      Code</font></td>
                      <td width="227" height="28"><input name="txtbranchcode" size="9" readonly maxlength="4" color="white" value="<%=session("branchcode")%>"><input type="button" value=" L " name="cmdbranch" onclick="branch()" class="bgcolor"><input name="txtbranchdesc" size="16" readonly class="bgcolor1" value="<%=session("branchnarration")%>"></td>
                    </tr>
                    <tr>
                      <td width="124" height="28"><font size="2" face="MS Sans Serif">&nbsp;
                      To User ID</font></td>
                      <td width="227" height="28"><input name="txtuserid" size="9" maxlength="20" readonly><input type="button" value=" L " name="cmduser" onclick="Touser()" class="bgcolor"><input name="txtuserdesc" size="16" readonly class="bgcolor1"></td>
                    </tr>
                    <tr>
                      <td width="124" height="28"><font size="2" face="MS Sans Serif">&nbsp;
                      Module ID&nbsp;</font></td>
                      <td width="227" height="28"><input name="txtmodulecode" size="9" maxlength="6" readonly><input type="button" value=" L " name="cmdmodule" onclick="module()" class="bgcolor"><input name="txtmoduledesc" size="16" readonly class="bgcolor1"></td>
                    </tr>
                    <tr>
                      <td width="124" height="28"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;Instrument
                      Code</font></td>
                      <td width="227" height="28"><input name="txtinstrcode" size="9" readonly maxlength="4"><input type="button" value=" L " name="cmdinstr" onclick="instrument()" class="bgcolor"><input name="txtinstrdesc" size="16" readonly class="bgcolor1"></td>
                    </tr>
                    <tr>
                      <td width="124" height="10"></td>
                      <td width="227" height="10"></td>
                    </tr>
                  </table>

                  </td>
                </tr>
              </table>

              </center>
            </div>
            </td>
            <td width="49%" height="20" valign="top">
            <div align="center">
              <center>

              <table border="0" width="60%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%"><!-- -----------------------DENOMINATIONS---------------------------------->
                  <div id="denom" align="center" style="DISPLAY: block; HEIGHT: 21px; WIDTH: 219px">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
                      <tr>
                        <td><iframe       
                      id ="ifrastockdtls" align =center frameborder=0 
                        framespacing=0 noresize height=190 width=300 
                        valign="top" src="stockdtls.asp" 
                        style="BACKGROUND-COLOR: darkred; HEIGHT: 134px; WIDTH: 348px" 
                       ></iframe></td>
                      </tr>
                    </table>

                  </div>
                  </td>
                </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="19%" height="5">&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="Book" checked name="Radtype" onclick="Display()"><font size="2" face="MS Sans Serif">Book</font></td>
            <td width="81%" height="5"><input type="radio" value="Leaf" name="Radtype" onclick="Display()"><font size="2" face="MS Sans Serif">Leaf</font></td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center" id="divbook" style="DISPLAY: block">
        <center>
        <div align="center">
          <center>

          <table width="98%" cellpadding="0" class="tableborder2">
            <tbody>
              <tr>
                <td width="100%">
                <div align="center">
                  <center>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="20">
                    <tr class="bgcolor">
                      <td width="748" colspan="10" height="15"><font class="subheading">Available
                      Book Stock Details</font></td>
                    </tr>
                    <tr>
                      <td width="748" height="19" colspan="10"></td>
                    </tr>
                    <tr>
                      <td width="60" height="20"><font class="textsmall">&nbsp;Series No</font></td>
                      <td height="20" width="103"><font size="1"><input name="txtserno" size="9" readonly maxlength="10"><input type="button" value=" L " name="cmdserno" onclick="serandpages()" class="bgcolor"></font></td>
                      <td width="118" height="20" align="right"><font class="textsmall">No
                      of Leaves per book</font></td>
                      <td width="61" height="20"><font size="1"><input name="txtnoleavesperbook" size="6" readonly maxlength="10"></font></td>
                      <td width="76" height="20" align="right"><font class="textsmall">No.
                      of Books</font></td>
                      <td width="50" height="20"><font size="1"><input name="txtnobook" size="6" onblur="ddbook()" onkeyup="chknoofbookleaves()" onkeypress="numeric()" maxlength="3"></font></td>
                      <td width="60" height="20" align="right"><font class="textsmall">Start
                      S.No&nbsp;</font></td>
                      <td width="71" height="20"><font size="1"><input name="txtssno" size="9" readonly maxlength="15"></font></td>
                      <td width="60" height="20" align="right"><font class="textsmall">End
                      S.No.&nbsp;</font></td>
                      <td width="71" height="20"><font size="1"><input name="txtendsno" size="9" readonly onblur="focusadd()" maxlength="15"></font></td>
                    </tr>
                    <center></center><center>
                    <tr>
                      <td width="730" height="20" colspan="10"></td>
                    </tr>
                    <tr>
                      <td width="730" height="20" colspan="10">
                      <div align="center">
                        <center>

                        <table border="0" width="45%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="100%">
                            <td><iframe  align=center frameborder=0 id="divdd1"
					     	      
                        framespacing=0 noresize height=90 width=330 
                        valign="top" src="../GENSBCA/dddtls.aspx"></iframe>
                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                      </td>
                    </tr>
                    </table>

                  </center>
                  </div>
                </center></td>
              </tr>
          </table>

          </center>
        </div>
        </div>
        <div align="center" id="divleaf" style="DISPLAY: none">
          <center>

          <table width="98%" cellpadding="0" class="tableborder2">
            <tr>
              <td width="100%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0" id="TABLE1">
                <tr class="bgcolor">
                  <td width="100%" height="15" colspan="8"><font class="subheading">Available
                  Leaf&nbsp; Details</font></td>
                </tr>
                <tr>
                  <td width="14%" height="19"></td>
                  <td width="13%" height="19"></td>
                  <td width="13%" height="19"></td>
                  <td width="8%" height="19"></td>
                  <td width="13%" height="19" align="right"></td>
                  <td width="10%" height="19"></td>
                  <td width="13%" height="19" align="right"></td>
                  <td width="16%" height="19"></td>
                </tr>
                <tr>
                  <td width="14%" height="20"><font class="textsmall">&nbsp;Series No.</font></td>
                  <td width="13%" height="20"><font size="1"><input name="txtlserno" size="9" readonly maxlength="20"><input type="button" value=" L " name="cmdlsno" onclick="leafandpages()" class="bgcolor"></font></td>
                  <td width="12%" height="20" align="right"><font class="textsmall">No.of
                  Leaves&nbsp;</font></td>
                  <td width="8%" height="20"><font size="1"><input name="txtnol" size="9" onkeypress="numeric()" onkeyup="chknoofbookleaves()" maxlength="3"></font></td>
                  <td width="12%" height="20" align="right"><font class="textsmall">Starting
                  Sl.No</font></td>
                  <td width="10%" height="20"><font size="1"><input name="txtlstartno" size="9" readonly maxlength="16"></font></td>
                  <td width="13%" height="20" align="right"><font class="textsmall">Ending
                  Sl.No.&nbsp;</font></td>
                  <td width="16%" height="20"><input name="txtlendno" size="9" readonly maxlength="15"></td>
                </tr>
                <tr>
                  <td width="14%" height="20"></td>
                  <td width="13%" height="20"></td>
                  <td width="12%" height="20" align="right"></td>
                  <td width="8%" height="20"></td>
                  <td width="12%" height="20" align="right"></td>
                  <td width="10%" height="20"></td>
                  <td width="13%" height="20" align="right"></td>
                  <td width="16%" height="20"></td>
                </tr>
                <tr>
                  <td width="98%" height="20" colspan="8">
                  <div align="center">
                    <center><!--  <table border="0" width="46%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%">
                        <td><iframe  align=center frameborder=0 id="divdd2"
					     	      
                        framespacing=0 noresize height=90 width=330 
                        valign="top" src="../GENSBCA/dddtls.aspx" 
                        style="BACKGROUND-COLOR: darkred"></iframe>
                        </td>
                      </tr>
                    </table> -->
                    </center>
                  </div>
                  </td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </center>
        </div>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%" height="23"></td>
          </tr>
          <tr>
            <td width="100%" height="31">
            <div align="center">
              <center>

              <table width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="100%"><input type="button" value="    Ok    " name="butok" onclick="Insert()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="Cmdcan()" class="bgcolor"><input type="button" value="   Exit   " name="butexit" class="bgcolor" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.asp"%>&quot;"></td>
                </tr>
              </table>

              <input type="hidden" name="hidstatus"></center><input type="hidden" name="hidnoofbl"><center></center>
            </div>
            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%" height="10"></td>
          </tr>
        </table>

      </center></td>
    </tr>
  </table>

  <input type="hidden" name="hsno"><input type="hidden" name="heno"><input type="hidden" name="hidddsno"><input type="hidden" name="hidddeno"><input type="hidden" name="hidnobooks"><input type="hidden" name="hidblstart"><input type="hidden" name="hidblend"><input type="hidden" name="hdmodstno"><input type="hidden" name="hdmodedno"><input type="hidden" name="hiddata"><input type="hidden" name="hidvals"><input type="hidden" name="hidenos"><input type="hidden" name="hidnb"><input type="hidden" name="hmsg" value="xx"><input type="hidden" name="hnewnoofbooks"><input type="hidden" name="hnewsno"><input type="hidden" name="nsno"><input type="hidden" name="neno">
</form>

</body>

</html>
