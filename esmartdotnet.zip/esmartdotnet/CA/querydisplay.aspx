<%@ Page Language="vb" CodeBehind="querydisplay.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Querydisplay" %>
<%str=Request.QueryString("st")%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
var stri

	stri=window.document.frmacc.hbno.value
	type="<%=str%>"
if (type.substring(0,11)=="Instrrecord")
	{
		window.attachEvent(window.opener.Getrecorddts(stri))
		window.close()
	}
else if(type.substring(0,4)=="Book" || type.substring(0,10)=="ModifyBook")
	{
		window.attachEvent(window.opener.Bookendsno(stri))
		window.close()
	}
else if(type.substring(0,4)=="Leaf" || type.substring(0,10)=="ModifyLeaf")
	{
		window.attachEvent(window.opener.Leafendsno(stri))
		window.close()
	}
else if(type.substring(0,9)=="Noofbooks")
	{
		window.attachEvent(window.opener.instrnoofbooks(stri))
		window.close()
	}
else if(type.substring(0,10)=="Customerid")
	{
		window.attachEvent(window.opener.Customername(stri))
		window.close()
	}
else if(type.substring(0,5)=="Endno")
	{
		window.attachEvent(window.opener.instrendno(stri))
		window.close()
	}

}
//-->
</SCRIPT>

<%
  dim rs,obj
  set rs=server.CreateObject("adodb.recordset")
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  if left(str,11)="Instrrecord" then
	  st=split(str,"|")
		set rs=obj.singleRecordSet("GENINSTRUMENTMST","INSTRNAME,REMYN","INSTRCODE='" & st(1) & "'","INSTRNAME")
			 if not rs.EOF and not rs.bof then
					 counterno=rs(0)&"|"&rs(1)
			 end if
  ELSEIF LEFT(STR,4)="Book" then
	 st=split(STR,"|")
	 startno=st(4)
	 nobooks=st(5)
	 ipbook=st(6)
	 endno=cint(startno)+cint(nobooks)*cint(ipbook)-1
	set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","Bookstartno,bookendno"," UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and BOOKYESNO='Y' and UPPER(TRIM(BOOKSERIESNO))='" & UCASE(TRIM(st(3))) & "'","bookseriesno,to_number(bookstartno)")
	if not rs.EOF and not rs.bof then
		do while not rs.EOF 
		
		if cint(startno)>=cint(rs(0)) and cint(startno)<=cint(rs(1)) or cint(endno)>=cint(rs(0)) and cint(endno)<=cint(rs(1)) then
			counterno="TRUE"
		end if
		rs.Movenext
		loop 	
			 	
	end if
	ELSEIF LEFT(STR,10)="ModifyBook" then
	 st=split(STR,"|")
	 startno=st(4)
	 nobooks=st(5)
	 ipbook=st(6)
	 stno=st(7)
	 endno=cint(startno)+cint(nobooks)*cint(ipbook)-1
	set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","Bookstartno,bookendno","UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and BOOKYESNO='Y' and UPPER(TRIM(BOOKSERIESNO))='" & UCASE(TRIM(st(3))) & "' and Bookstartno<>'" & stno &"'","bookseriesno,to_number(bookstartno)")
	if not rs.EOF and not rs.bof then
		do while not rs.EOF 
		
		if cint(startno)>=cint(rs(0)) and cint(startno)<=cint(rs(1)) or cint(endno)>=cint(rs(0)) and cint(endno)<=cint(rs(1)) then
			counterno="TRUE"
		end if
		rs.Movenext
		loop 	
			 	
	end if
	ELSEIF LEFT(STR,4)="Leaf" then
	Response.Write str
	 st=SPLIT(STR,"|")
	 start=st(4)
	 noofleaves=st(5)
	 endno=cint(start)+cint(noofleaves)
	set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","LEAFstartno,LEAFendno","UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and LEAFYESNO='Y' and UPPER(TRIM(LEAFSERIESNO))='" & UCASE(TRIM(st(3))) & "'","to_number(leafstartno)")	
	'set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","MAX(to_number(leafendno))","UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and LEAFYESNO='Y' and UPPER(TRIM(LEAFSERIESNO))='" & UCASE(TRIM(st(3))) & "'","to_number(leafendno)")
	if not rs.EOF and not rs.bof then
		do while not rs.EOF 
		
		if cint(start)>=cint(rs(0)) and cint(start)<=cint(rs(1)) or cint(endno)>=cint(rs(0)) and cint(endno)<=cint(rs(1)) then
			counterno="TRUE"
		end if
		rs.Movenext
		loop 	
			 	
	end if
	ELSEIF LEFT(STR,10)="ModifyLeaf" then
	Response.Write str
	 st=SPLIT(STR,"|")
	 start=st(4)
	 noofleaves=st(5)
	 stno=st(6)
	 endno=cint(start)+cint(noofleaves)
	set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","LEAFstartno,LEAFendno","UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and LEAFYESNO='Y' and UPPER(TRIM(LEAFSERIESNO))='" & UCASE(TRIM(st(3))) & "' and Leafstartno<>'"& stno &"'","to_number(leafstartno)")	
	'set rs=obj.singleRecordSet("GENINSTRUMENTSTOCKDTLS","MAX(to_number(leafendno))","UPPER(TRIM(branchcode))='" & UCASE(TRIM(st(1))) & "' and UPPER(TRIM(instrcode))='" & UCASE(TRIM(st(2))) & "' and LEAFYESNO='Y' and UPPER(TRIM(LEAFSERIESNO))='" & UCASE(TRIM(st(3))) & "'","to_number(leafendno)")
	if not rs.EOF and not rs.bof then
		do while not rs.EOF 
		
		if cint(start)>=cint(rs(0)) and cint(start)<=cint(rs(1)) or cint(endno)>=cint(rs(0)) and cint(endno)<=cint(rs(1)) then
			counterno="TRUE"
		end if
		rs.Movenext
		loop 	
			 	
	end if
	elseif left(str,9)="Noofbooks" then
	
	k=split(str,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","NOOFBOOKS,BOOKENDNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and bookyesno='Y' and UPPER(TRIM(BOOKSTARTNO))='" & UCASE(TRIM(k(4))) &  "' and BOOKSERIESNO = '" & k(3) & "' and LEAVESPERBOOK='" &  k(5) & "'")
	
		if not rs.EOF and not rs.bof then
				for i=0 to rs.Fields.Count - 1
					 counterno= counterno & "*" & rs(i)
				next
		end if
	ELSEIF LEFT(STR,10)="Customerid" THEN
	 st=SPLIT(STR,"~")
		set rs=obj.singleRecordSet("GENMODULEMST","MASTERTABLE","MODULEID='" & st(2) & "'")
				if not rs.EOF and not rs.bof then
					 mtable=rs(0)
				end if
			if len(trim(mtable))> 0 then
			set rs=obj.singleRecordSet(cstr(mtable),"CUSTomerID,NAME","BRANCHCODE='" & st(1) & "' and GLCODE='" & st(3) & "' and  ACCNO='" & st(4) & "'")			
				 if not rs.EOF and not rs.bof then
					for i=0 to rs.Fields.Count - 1
						 counterno= counterno & "*" & rs(i)
					next
				end if
			end if
		
	elseif left(str,5)="Endno" then

	k=split(str,"|")
		set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","NOOFLEAVES,LEAFENDNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and leafyesno='Y' and LEAFSTARTNO='" & k(4) &  "' and LEAFSERIESNO = '" & K(3) & "'" )
			
			if not rs.EOF and not rs.bof then
				for i=0 to rs.Fields.Count - 1
					 counterno= counterno & "*" & rs(i)
				next
			end if
			
   end if
  set obj=nothing
 '%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=counterno%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
