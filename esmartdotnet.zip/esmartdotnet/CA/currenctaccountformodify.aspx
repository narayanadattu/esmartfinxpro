<%@ Page Language="vb" CodeBehind="currenctaccountformodify.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.currenctaccountformodify" %>
<%
		dim Arrtrans()
		dim rs1
		set rs1=server.CreateObject("adodb.recordset")
		dim sbfields,jointfields,nomfields,guardfields,strcondition,statusfields
		dim sbvalues,jointvalues,nomvalues,guardvalues,statusvalues,jointvalue
		dim obj,Strmsg,condition,strjoint	
		dim cnt,jcnt,gcnt,ncnt
		
		sbvalues=Request.Form("hsb")
		jointvalues=Request.Form("hjoint")    	
		nomvalues=Request.Form("hnom")
		sigvalues=Request.Form("hsig") 		  		
		guardvalues=Request.Form("hguard")
		strcondition=Request.Form("hdel")	
		statusvalues=Request.Form("hstatus")
		intvalues=Request.Form("hint")
		userid=session("userid")
		appdate=session("applicationdate")
		machineid=session("machineid")
			
		dim joint,sig
		joint=split(jointvalues,"|")
		sig=split(sigvalues,"|")
		'' fro signature
		if sig(0)="D" then
			scnt=0	
			sigid=joint(1)	
		elseif len(sigvalues)=1 then
			scnt=0
		else
			scnt=1	
		end if	
		if joint(0)="D" then
			jcnt=0	
			jointid=joint(1)	
		elseif len(jointvalues)=1 then
			jcnt=0
		else
			jcnt=1	
		end if	
		
		if len(guardvalues)=1 then
			gcnt=0
		else
			gcnt=1
		end if
		if len(intvalues)=1 then
			icnt=0
		else
			icnt=1
		end if
		
		dim nom
		if len(nomvalues)>0 then
		nom=split(nomvalues,"|")
		
		if nom(0)="D" then		
			ncnt=0
			nomid=nom(1)
		elseif len(nom(0))=1 then
			ncnt=0
		else
			ncnt=1	
		end if			
		else
		ncnt=0
		end if		
		
		condition=split(strcondition,"|")				
		
		cnt=instrrev(jointvalues,"|")
		if cnt<>0 then		
			jointvalues=left(jointvalues,cnt-1)		
		end if		
		
		 
''***************** Inserting the values into database ********************			
   
  
      
		sbfields="branchcode,currencycode,glcode,accno," _
		&"customerid,name,chequebook,tdsyn,opdate,transtatus,transferfrombranchcode,fromaccno," _
		&"operatedby,operatinginstr,categorycode,bankstaffyn,NOMINEEYN,JOINTHOLDERYN," & _
		"INTRODUCERYN,GUARDIANYN,signatureyn,userid,machineid,applicationdate,status"					
				
		jointfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,sno,jhcustomerid,jointholdername,customerid,userid," & _
		"machineid,applicationdate"
		
		sigfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,customerid,name,userid," & _
		"machineid,applicationdate"
		
		nomfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,sno,nomineeid,nomineename,relation,customerid,userid," & _
		"machineid,applicationdate"						
		
		guardfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,GRDCUSTOMERID,guardianname,relation,customerid,userid," & _
		"machineid,applicationdate"
		
		
		intfields="branchcode,currencycode,glcode,accno," _
		& "moduleid,INTRCUSTOMERID,customerid,userid,machineid,applicationdate"
		
		nomfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,nomcustomerid,nomineename,relation,customerid," & _
		"userid,machineid,applicationdate"						
		
		statusfields="branchcode,currencycode,glcode,accno," _
		& " moduleid,presentstatus,previousstatus,narration,userid,machineid,applicationdate"		
		
'--------**********************************************---------------------------------------
		
			
		'------------------------------------**********************--------------------------
		
		dim sbcondition,strwhere 
		
		'--------------------------Condition for Deleting Records----------------------------
		sbcondition="branchcode='"& condition(0) &"' and currencycode='"& condition(1)&"' " _
		& "  and glcode='"& condition(3) &"' and accno='"& condition(4) &"' and " _
		& " customerid='"& condition(5) &"' "
		
		strwhere="branchcode='"& condition(0) &"' and currencycode='"& condition(1)&"' " _
		& "  and moduleid='"& condition(2) &"' and glcode='"& condition(3) &"' " _
		& " and accno='"& condition(4) &"' and customerid='"& condition(5) &"' "
		'-----------------------------------End----------------------------------------------
		'-----------------Deleting The Records started---------------------------------------
							
		dim strdel
		cnt=instrrev(strwhere,"and")
		strdel=left(strwhere,cnt-1)
		
		set rs=server.CreateObject("adodb.recordset")
		set obj=server.CreateObject("queryrecordsets.fetchrecordsets") 
		
		set rs=obj.singlerecordset("GENACCOUNTSTATUSDTLS","accno","branchcode='"& condition(0) &"' " _
		& " and currencycode='"& condition(1)&"' and moduleid='"& condition(2) &"' " _
		 & " and glcode='"& condition(3) &"' and accno='"& condition(4) &"'") 
		 		 
		 statuscount=rs.RecordCount 		
		
		sbvalues=sbvalues & ",'" & userid & "' ,'" & machineid &"','"& appdate&"','R'"
		jointvalues1=split(jointvalues,"|")
		jointvalues=""
		for i=0 to ubound(jointvalues1)
			jointvalues=jointvalues & "|" & jointvalues1(i) & ",'" & userid & _
			"' ,'" & machineid &"','"&appdate&"'"
		next
		jointvalues=mid(jointvalues,2)
		'' for signature details
		sigvalues1=split(sigvalues,"|")
		sigvalues=""
		for i=0 to ubound(sigvalues1)-1
			sigvalues=sigvalues & "|" & sigvalues1(i) & ",'" & userid & _
			"' ,'" & machineid &"','"&appdate&"'"
		next
		sigvalues=mid(sigvalues,2)
		nomvalues=nomvalues & ",'" & userid & "' ,'" & machineid &"','"&appdate&"'"
		guardvalues=guardvalues & ",'" & userid & "' ,'" & machineid &"','"&appdate&"'"
		statusvalues=statusvalues & ",'" & userid & "' ,'" & machineid &"','"&appdate&"'"
		intvalues=intvalues & ",'" & userid & "' ,'" & machineid &"','"&appdate&"'"
		 
	if gcnt>0 then
		set rs1=obj.singlerecordset("GENCUSTGUARDIANMST","accno",cstr(strwhere) )
		if not rs1.EOF and not rs1.BOF then
			gstat="Y"
		else
			gstat="N"
		end if
	end if
	'' for signature details
	if scnt>0 then
		set rs1=obj.singlerecordset("GENSIGNOTRIESMST","accno",cstr(strwhere) )
		if not rs1.EOF and not rs1.BOF then
			sstat="Y"
		else
			sstat="N"
		end if
	end if	 
	if jcnt>0 then
		set rs1=obj.singlerecordset("GENCUSTJOINTHOLDERMST","status",cstr(strwhere ))
		if not rs1.EOF and not rs1.BOF then
			jstat="Y"
		else
			jstat="N"
		end if
	end if
	
	if ncnt>0 then
		set rs1=obj.singlerecordset("GENCUSTNOMINEEMST","status",cstr(strwhere ))
		if not rs1.EOF and not rs1.BOF then
			nstat="Y"
		else
			nstat="N"
		end if
	end if

	if icnt>0 then
		set rs1=obj.singlerecordset("gencustintroducermst","userid",cstr(strwhere) )
		if not rs1.EOF and not rs1.BOF then
			istat="Y"
		else
			istat="N"
		end if
	end if

	strdeltables="SBMST|"
	if gstat="Y" then
	strdeltables=strdeltables & "GENCUSTGUARDIANMST|" 
	end if
	if sstat="Y" then
	strdeltables=strdeltables & "GENSIGNOTRIESMST|" 
	end if
	if jstat="Y" then
	strdeltables=strdeltables & "GENCUSTJOINTHOLDERMST|" 
	end if
	if nstat="Y" then
	strdeltables=strdeltables & "GENCUSTNOMINEEMST|" 
	end if
	if istat="Y" then
	strdeltables=strdeltables & "gencustintroducermst|" 
	end if
	if statuscount>0 then
		strdeltables=strdeltables & "GENACCOUNTSTATUSDTLS" & "|"
	end if
	strtables="SBMST|"
	strcols=sbfields & "|"
	strvals=sbvalues & "$"
	if gcnt>0 then
	strtables=strtables & "GENCUSTGUARDIANMST|" 
	strcols=strcols & guardfields & "|"
	strvals=strvals & guardvalues & "$"
	end if
	if jcnt>0 then
	strtables=strtables & "GENCUSTJOINTHOLDERMST|" 
	strcols=strcols & jointfields & "|"
	strvals=strvals & jointvalues & "$"
	end if
	if scnt>0 then
	strtables=strtables & "GENSIGNOTRIESMST|" 
	strcols=strcols & sigfields & "|"
	strvals=strvals & sigvalues & "$"
	end if
	if ncnt>0 then
	strtables=strtables & "GENCUSTNOMINEEMST|" 
	strcols=strcols & nomfields & "|"
	strvals=strvals & nomvalues & "$"
	end if
	if icnt>0 then
	strtables=strtables & "gencustintroducermst|" 
	strcols=strcols & intfields & "|"
	strvals=strvals & intvalues & "$"
	end if
	strtables=strtables & "GENACCOUNTSTATUSDTLS"
	strcols=strcols & statusfields & "|"
	strvals=strvals & statusvalues & "$"
	strdeltables=mid(strdeltables,1,len(strdeltables)-1)
	strdeltables=split(strdeltables,"|")
	strtables=split(strtables,"|")
	redim arrtrans(ubound(strdeltables)+ubound(strtables)+2,4)
	
	for i=0 to ubound(strdeltables)
		Arrtrans(i,0)="D"
		Arrtrans(i,1)=strdeltables(i)
		Arrtrans(i,2)=""
		Arrtrans(i,3)=""
		if ucase(strdeltables(i))="SBMST" then
			Arrtrans(i,4)=sbcondition				
		elseif ucase(strdeltables(i))="GENACCOUNTSTATUSDTLS" then
			Arrtrans(i,4)=strdel
		else
				Arrtrans(i,4)=strwhere
		end if
			
	next
	
	j=i
	strcols=split(strcols,"|")
	strvals=split(strvals,"$")
	for i=0 to ubound(strtables)
		Arrtrans(j+i,0)="I"
		Arrtrans(j+i,1)=strtables(i)
		Arrtrans(j+i,2)=strcols(i)
		Arrtrans(j+i,3)=strvals(i)
		Arrtrans(j+i,4)=""
		
	next

		Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")	
		Strmsg= obj.DataTransactions(Arrtrans)
		set obj=nothing
		Response.Write strmsg
		Response.Redirect "SBAccountopening.asp?record=" & strmsg	
%>
