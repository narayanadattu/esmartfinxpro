<%@ Page CodeBehind="custinstrissuedtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_Custinstrissuedtls" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Customer Instrissuedtls</title>
<SCRIPT LANGUAGE=javascript		src="<%="http://" & session("moduledir")& "/proc.js"%>"> 
</SCRIPT>
<SCRIPT LANGUAGE=javascript		src="<%="http://" & session("moduledir")& "/val.js"%>"> 
</SCRIPT>
<script language="JavaScript"	src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" >
</script>
<script language="JavaScript"	src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" >
</script>
<script language="JavaScript"	src="<%="http://" & session("moduledir")& "/navbar.js"%>" >
</script>
<SCRIPT LANGUAGE=javascript>
<!--
//To Get Branchcode
var Mode="Insert"
var j=0
function branch()
{   
	st="Combranch"
	window.open("Listquery.asp" + "?"+"st="+st,"branch",
	"width=200%,height=150%,left=140%,top=210%")
}	

function Branchcode(str)
{
	assign(str,window.document.frmcustins.txtbranchdesc,
	window.document.frmcustins.txtbranchcode)
	modclear()
	window.document.frmcustins.txtmodulecode.value=""
	window.document.frmcustins.txtmoduledesc.value=""
	window.document.frmcustins.txtcurrencycode.value=""
	window.document.frmcustins.txtcurrencydesc.value=""
	
}
//To get Currency
function Currency()
{
	st="Currency"	
	window.open("Listquery.asp" + "?"+"st="+st,
	"currency","width=200%,height=150% left=550 top=215")
}

function Currencyid(str)
{
	assign(str,window.document.frmcustins.txtcurrencydesc,
	window.document.frmcustins.txtcurrencycode)      
	modclear()
	window.document.frmcustins.txtmodulecode.value=""
	window.document.frmcustins.txtmoduledesc.value=""

}
//To get Moduleid.
function module(){

		st1="custinsmodule"
		st2=window.document.frmcustins.txtbranchcode.value
		sy="|"
		st=st1+sy+st2
		window.open("Listquery.asp" + "?" +"st="+st,
		"Module","width=200%,height=150%,left=140%,top=210%")

}
function custmodcode(str)
{
       assign(str,window.document.frmcustins.txtmoduledesc,
       window.document.frmcustins.txtmodulecode)
	   modclear()
}
function modclear(){

		instrclear()
		window.document.frmcustins.txtinstrcode.value =""
		window.document.frmcustins.txtinstrdesc.value =""
		window.document.frmcustins.txtaccdesc.value=""
		window.document.frmcustins.txtaccno.value =""
		window.document.frmcustins.txtglcode.value=""
		window.document.frmcustins.txtgldesc.value=""
		window.document.frmcustins.txtcustomercode.value=""
		window.document.frmcustins.txtcustomername.value=""
	
}
//Toget GLcode
function GL(){
		st1="Comglcode"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		sy="|"
		st=st1+sy+st2+sy+st3
		window.open("Listquery.asp" + "?" +"st="+st,"GL",
		"width=200%,height=150%,left=140%,top=210%")
}

function Glcode(str){

		assign(str,window.document.frmcustins.txtgldesc,
		window.document.frmcustins.txtglcode)
		instrclear()
		window.document.frmcustins.txtinstrcode.value =""
		window.document.frmcustins.txtinstrdesc.value =""
		window.document.frmcustins.txtaccdesc.value=""
		window.document.frmcustins.txtaccno.value =""
		window.document.frmcustins.txtcustomercode.value=""
		window.document.frmcustins.txtcustomername.value=""
}
//To Get Accountno 
function account(){

		st1="Comaccount"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		st4=window.document.frmcustins.txtglcode.value
		sy="|"
		st=st1+sy+st2+sy+st3+sy+st4
		window.open("Listquery.asp" + "?" +"st="+st,"GL",
		"width=200%,height=150%,left=140%,top=210%")
}

function accountid(str){
	
		assign(str,window.document.frmcustins.txtaccdesc,
		window.document.frmcustins.txtaccno)
		getcustid()
}

//To get Instrumentcode
function instrument(){
		st1="Custinsinstrument"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		sy="|"
		st=st1+sy+st2+sy+st3
		window.open("Listquery.asp" + "?" +"st="+st,"cust",
		"width=200%,height=150%,left=140%,top=210%")
}		
		
function Custinstrcode(str)
{		
		assign(str,window.document.frmcustins.txtinstrdesc,
		window.document.frmcustins.txtinstrcode)
		instrclear()
}

function getcustid()
{
		st1="Customerid"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		st4=window.document.frmcustins.txtglcode.value
		st5=window.document.frmcustins.txtaccno.value
		sy="~"
		st=st1+sy+st2+sy+st3+sy+st4+sy+st5
		window.open("querydisplay.asp" + "?" +"st="+st,"CUST",
		"width=200%,height=150%,left=140%,top=210%")
}

function Customername(str){
		var k
		k=str.split("*")
		window.document.frmcustins.txtcustomercode.value = k[1]
		window.document.frmcustins.txtcustomername.value = k[2]
		instrclear()
		window.document.frmcustins.txtinstrcode.value =""
		window.document.frmcustins.txtinstrdesc.value =""
}

function instrclear(){

		clear()
		window.document.all.ifrastockdtls.src="../GENSBCA/custstockdtls.aspx"
		window.document.frmcustins.txtserno.value=""
		window.document.frmcustins.txtlpboook.value=""
		window.document.frmcustins.txtlserno.value=""
		
		
}		
function Display(){
		
	Radlen =window.document.frmcustins.Radtype.length
	for(i=0;i<Radlen;i++)
	{
	if(window.document.frmcustins.Radtype(i).checked==true)
	{
		if(window.document.frmcustins.Radtype(i).value=="Book")
			{
			if(window.document.all.divbook.style.display=="none")
				{
					window.document.all.divleaf.style.display="none"
					window.document.all.divbook.style.display="block"
					window.document.all.ifrastockdtls.src="../GENSBCA/custstockdtls.aspx"
					window.document.frmcustins.txtendno.value=""
					window.document.frmcustins.txtnobooks.value=""
					window.document.frmcustins.txtlpboook.value=""
					window.document.frmcustins.txtstartno.value=""
					window.document.frmcustins.txtserno.value=""
					window.document.all.divcheque1.src="chequedtls.asp"
				}		
			}
			else if(window.document.frmcustins.Radtype(i).value=="Leaf")
			{
			
				if(window.document.all.divbook.style.display=="block")
				{
					window.document.all.divleaf.style.display="block"
					window.document.all.divbook.style.display="none"
					window.document.all.ifrastockdtls.src="../GENSBCA/custstockdtls.aspx"
					window.document.frmcustins.txtlserno.value=""
					window.document.frmcustins.txtlstartno.value =""
					window.document.frmcustins.txtlendno.value=""
					window.document.frmcustins.txtnoofleaves.value=""
					window.document.all.divcheque2.src="chequedtls.asp"
					
				}
			}
		}
	}
	}

function chequeleaf()
{
		var brcode=window.document.frmcustins.txtbranchcode.value
		var modcode=window.document.frmcustins.txtmodulecode.value
		var instr=window.document.frmcustins.txtinstrcode.value
		var leaves=window.document.frmcustins.txtnoofleaves.value
		var lserno=window.document.frmcustins.txtlserno.value
		var stoc=""
		if(leaves!="" && lserno!="")
		{
			strows=eval(window.document.frames(0).frmstock.stockdtls.rows)
			for(istock=1;istock<=eval(strows)-1;istock++)
			{
				window.document.frames(2).frmcheque.hidmodchestock.value=
				window.document.frames(2).frmcheque.hidmodchestock.value+
				"*"+window.document.frames(0).frmstock.stockdtls.textmatrix(istock,0)
				window.document.frames(2).frmcheque.hidmodchestart.value=
				window.document.frames(2).frmcheque.hidmodchestart.value+
				"*"+window.document.frames(0).frmstock.stockdtls.textmatrix(istock,1)
			}
			window.document.frames(2).frmcheque.hidcheque.value="Leaf"+"*"+
			leaves+"*"+stoc+"*"+brcode+"*"+modcode+"*"+instr+"*"+lserno+"*"+Mode
			window.document.frames(2).frmcheque.action="chequedtls.asp"
			window.document.frames(2).frmcheque.method="post"
			window.document.frames(2).frmcheque.submit()
		}
}
			
function chequebook()
{
		var brcode=window.document.frmcustins.txtbranchcode.value
		var modcode=window.document.frmcustins.txtmodulecode.value
		var instr=window.document.frmcustins.txtinstrcode.value
		var nobooks=window.document.frmcustins.txtnobooks.value
		var serno=window.document.frmcustins.txtserno.value
		var leaves=window.document.frmcustins.txtlpboook.value
		var stoc
		if(nobooks!="" && leaves!="")
		{
		//	if(window.parent.frames(0).frmstock.stockdtls.cols>1)
		//	{
		//	stoc=window.parent.frames(0).frmstock.stockdtls.textmatrix(1,1)
		//	books=window.parent.frames(0).frmstock.stockdtls.textmatrix(1,0)
		//	}
			
		//if(stoc)
		//{
			//if(Mode=="Insert")
			//{
			//window.document.frames(1).frmcheque.hidcheque.value="book"+"*"+nobooks+"*"+leaves+"*"+brcode+"*"+modcode+"*"+instr+"*"+serno+"*"+Mode
			//window.document.frames(1).frmcheque.action="chequedtls.asp"
			//window.document.frames(1).frmcheque.method="post"
			//window.document.frames(1).frmcheque.submit()
			//}
			//else if(Mode=="Modify" || Mode=="Delete")
			//{
			strows=eval(window.document.frames(0).frmstock.stockdtls.rows)
			
			for(istock=1;istock<=eval(strows)-1;istock++)
			{
				window.document.frames(1).frmcheque.hidmodchestock.value=
				window.document.frames(1).frmcheque.hidmodchestock.value+"*"+
				window.document.frames(0).frmstock.stockdtls.textmatrix(istock,0)
				window.document.frames(1).frmcheque.hidmodchestart.value=
				window.document.frames(1).frmcheque.hidmodchestart.value+"*"+
				window.document.frames(0).frmstock.stockdtls.textmatrix(istock,1)
			}
			window.document.frames(1).frmcheque.hidcheque.value=
			"book"+"*"+nobooks+"*"+leaves+"*"+brcode+"*"+modcode+"*"+instr+"*"+
			serno+"*"+Mode
			window.document.frames(1).frmcheque.action="chequedtls.asp"
			window.document.frames(1).frmcheque.method="post"
			window.document.frames(1).frmcheque.submit()
			//}
		//}
		}
}

//To Stock Details,if Instrtype is BOOK
function BookSeriesdtls(){
	
		branid=window.document.frmcustins.txtbranchcode.value
		modid=window.document.frmcustins.txtmodulecode.value
		instr=window.document.frmcustins.txtinstrcode.value
		serno=window.document.frmcustins.txtserno.value
		lpb=window.document.frmcustins.txtlpboook.value
		accno=window.document.frmcustins.txtaccno.value
		Radlen =window.document.frmcustins.Radtype.length
		
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmcustins.Radtype(i).checked==true)
		{
		rtype=window.document.frmcustins.Radtype(i).value
		}
		}
		sy="|"
		st=branid+sy+modid+sy+instr+sy+serno+sy+lpb+sy+rtype+sy+Mode+sy+accno
		clear()
		
		window.document.frames(0).frmstock.hidstock.value=st
		window.document.frames(0).frmstock.action="../GENSBCA/custstockdtls.aspx"
		window.document.frames(0).frmstock.method="post"
		window.document.frames(0).frmstock.submit()

}

function clear(){
		
		window.document.frmcustins.txtendno.value=""
		window.document.frmcustins.txtlendno.value =""
		window.document.frmcustins.txtlstartno.value=""
		window.document.frmcustins.txtnobooks.value=""
		window.document.frmcustins.txtnoofleaves.value=""
		window.document.frmcustins.txtstartno.value=""
		window.document.all.divcheque1.src="chequedtls.asp"
		window.document.all.divcheque2.src="chequedtls.asp"
		
}
//To Stock Details,if Instrtype is LEAF.

function LeafSeriesdtls(){

		branch=window.document.frmcustins.txtbranchcode.value
		mod=window.document.frmcustins.txtmodulecode.value
		instr=window.document.frmcustins.txtinstrcode.value
		lserno=window.document.frmcustins.txtlserno.value 
		nlp=window.document.frmcustins.txtnoofleaves.value
		accno=window.document.frmcustins.txtaccno.value
		for(i=0;i<Radlen;i++)
		{
		if(window.document.frmcustins.Radtype(i).checked==true)
		{
		type=window.document.frmcustins.Radtype(i).value
		}
		}
		sy="|"
		st=branch+sy+mod+sy+instr+sy+lserno+sy+nlp+sy+type+sy+Mode+sy+accno
		clear()
		window.document.frames(0).frmstock.hidstock.value=st
		window.document.frames(0).frmstock.action="../GENSBCA/custstockdtls.aspx"
		window.document.frames(0).frmstock.method="post"
		window.document.frames(0).frmstock.submit()
		
}

function getserno(){
		st1="Custserno"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		st4=window.document.frmcustins.txtinstrcode.value
		sy="~"
		st=st1+sy+st2+sy+st3+sy+st4
		window.open("Listquery.asp" + "?" +"st="+st,"sb",
		"width=200%,height=150%,left=140%,top=210%")
}

function Custsernonoofl(str){

		assign(str,window.document.frmcustins.txtlpboook,window.document.frmcustins.txtserno)
		BookSeriesdtls()
		
}

function leafandpages(){
		
		st1="Seriesleaf"
		st2=window.document.frmcustins.txtbranchcode.value
		st3=window.document.frmcustins.txtmodulecode.value
		st4=window.document.frmcustins.txtinstrcode.value
		sy="|"
		st=st1+sy+st2+sy+st3+sy+st4
		window.open("singlequery.asp" + "?" +"st="+st,"series",
		"width=200%,height=150%,left=140%,top=210%")
			
}		
function leafser(str){

		window.document.frmcustins.txtlserno.value=str
		LeafSeriesdtls()
} 


function chknoofbookleaves()
{
	
	flex=window.document.frames(0).frmstock.stockdtls.cols
	if(window.document.frmcustins.hidnoofbl.value!="" && eval(flex)>1)
	{
		
		if(window.document.frames(0).frmstock.hidtype.value=="Book")
		{
		
			if(eval(window.document.frmcustins.txtnobooks.value)>
			eval(window.document.frmcustins.hidnoofbl.value) ||
			 eval(window.document.frmcustins.txtnobooks.value)<1)
			{
				alert('Cannot give More than Avalible Stock')
				window.document.frmcustins.txtnobooks.value=
				window.document.frmcustins.hidnoofbl.value
				//window.document.frmcustins.txtstartno.value=""
				//window.document.frmcustins.txtendno.value=""
				window.document.all.divcheque1.src="chequedtls.asp"
				window.document.frmcustins.txtnobooks.focus()
				window.document.frmcustins.txtnobooks.select()
			}
			else
			{
				if(window.document.frmcustins.txtstartno.value!="")
				{
				startno=eval(window.document.frmcustins.txtstartno.value)
				nlpbook=eval(window.document.frmcustins.txtlpboook.value)
				noofbooks=eval(window.document.frmcustins.txtnobooks.value)
				no=eval(nlpbook)*eval(noofbooks)
				endno=eval(no)-eval(1)+eval(startno)
				if(isNaN(endno)==false)
				{
				window.document.frmcustins.txtendno.value=endno
				}
				}
			}
		}
		else if(window.document.frames(0).frmstock.hidtype.value=="Leaf")
		{
			if(eval(window.document.frmcustins.txtnoofleaves.value)>
			eval(window.document.frmcustins.hidnoofbl.value) ||
			eval(window.document.frmcustins.txtnoofleaves.value)<1)
			{
				alert('Cannot give More than Avalible Stock')
				window.document.frmcustins.txtnoofleaves.value=
				window.document.frmcustins.hidnoofbl.value
				window.document.all.divcheque2.src="chequedtls.asp"
				window.document.frmcustins.txtnoofleaves.focus()
				window.document.frmcustins.txtnoofleaves.select()
			}
			else
			{
			if(window.document.frmcustins.txtlstartno.value!="")
				{
				startno=eval(window.document.frmcustins.txtlstartno.value)
				nl=eval(window.document.frmcustins.txtnoofleaves.value)
				endno=eval(nl)+eval(startno)-1
				if(isNaN(endno)==false)
				{
					window.document.frmcustins.txtlendno.value=endno
				}
				}
			}
		
		}
	}
	else
	{
			alert('No Stock in the Dept.')
			window.document.frmcustins.txtnobooks.value=""
			window.document.frmcustins.txtnoofleaves.value=""
	}
}


	
function okdis()
{

instrclear()
window.document.frmcustins.txtaccdesc.value=""
window.document.frmcustins.txtaccno.value=""
window.document.frmcustins.txtcustomercode.value=""
window.document.frmcustins.txtcustomername.value=""
window.document.frmcustins.txtendno.value=""
window.document.frmcustins.txtglcode.value=""
window.document.frmcustins.txtgldesc.value=""
window.document.frmcustins.txtinstrcode.value=""
window.document.frmcustins.txtinstrdesc.value=""
window.document.frmcustins.txtlendno.value=""
window.document.frmcustins.txtlpboook.value=""
window.document.frmcustins.txtlserno.value=""
window.document.frmcustins.txtlstartno.value=""
window.document.frmcustins.txtmodulecode.value=""
window.document.frmcustins.txtmoduledesc.value=""
window.document.frmcustins.txtnobooks.value=""
window.document.frmcustins.txtnoofleaves.value=""
window.document.frmcustins.txtserno.value=""
window.document.frmcustins.txtstartno.value=""
if(Mode=="Query")
{
	window.document.frmcustins.butok.disabled=true
	window.document.frmcustins.txtnobooks.readOnly=true
	
}
else
{
	window.document.frmcustins.butok.disabled=false
	window.document.frmcustins.txtnobooks.readOnly=false
}
}	





function Insert(){
	window.document.frmcustins.status.value=Mode
 if(window.document.frmcustins.txtbranchcode.value!="" && 
	window.document.frmcustins.txtcurrencycode.value!="" && 
	window.document.frmcustins.txtmodulecode.value!="" && 
	window.document.frmcustins.txtaccno.value!="" && 
	window.document.frmcustins.txtglcode.value!="" && 
	window.document.frmcustins.txtcustomercode.value!="" && 
	window.document.frmcustins.txtinstrcode.value!="" &&
	window.document.frames(0).frmstock.stockdtls.cols>1) 
{
Radlen =window.document.frmcustins.Radtype.length
for(i=0;i<Radlen;i++)
{
	if(window.document.frmcustins.Radtype(i).checked==true)
	{
		if(window.document.frmcustins.Radtype(i).value=="Book")
		{
			if(window.document.frmcustins.txtserno.value!="" && 
				window.document.frmcustins.txtlpboook.value!="")// && 
				///window.document.frmcustins.txtnobooks.value!="" && 
				//window.document.frmcustins.txtstartno.value!="" && 
				//window.document.frmcustins.txtendno.value!="")
			{
				len=window.document.frames(1).frmcheque.txtchqsno.length
				
				if(eval(len)>1)
				{
    				sy="|"
	    				for(i=0;i<eval(len);i++)
		    				{
								if (window.document.frames(1).frmcheque.txtchqsno(i).value!="")
								{
									window.document.frmcustins.hidchequesno.value=window.document.frmcustins.hidchequesno.value+sy+window.document.frames(1).frmcheque.txtchqsno(i).value
									window.document.frmcustins.hidchequeeno.value=window.document.frmcustins.hidchequeeno.value+sy+window.document.frames(1).frmcheque.txtchqeno(i).value
									
								}
								else
								{
									alert('Enter Cheque Start number.')
									return;
								}
													
							}
									
									window.document.frmcustins.hidprestartno.value=
									window.document.frames(0).frmstock.stockdtls.textmatrix(1,1)
									window.document.frmcustins.hidpreendno.value=
									window.document.frames(0).frmstock.stockdtls.textmatrix(1,2)
									window.document.frmcustins.action="custinstrissuedtlsinsert.asp"
									window.document.frmcustins.method="post"
									window.document.frmcustins.submit()
						}
					else
						{
							if(window.document.frames(1).frmcheque.txtchqsno.value!="")
							{
								window.document.frmcustins.hidchequesno.value=
								window.document.frames(1).frmcheque.txtchqsno.value
								window.document.frmcustins.hidchequeeno.value=
								window.document.frames(1).frmcheque.txtchqeno.value
								window.document.frmcustins.hidprestartno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,1)
								window.document.frmcustins.hidpreendno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,2)
								window.document.frmcustins.action="custinstrissuedtlsinsert.asp"
								window.document.frmcustins.method="post"
								window.document.frmcustins.submit()
							
							}
							else
							{
								alert('Enter Cheque Start number.')
								return;
							}
						}
									
			}
			else
			{
					alert('Fields Should not  be Empty.')
			}
		}
		else if(window.document.frmcustins.Radtype(i).value=="Leaf")
		{
			
			if(window.document.frmcustins.txtlserno.value!="" && 
				window.document.frmcustins.txtnoofleaves.value!="")
				//&&
				//window.document.frmcustins.txtlstartno.value!="" && 
				//window.document.frmcustins.txtlstartno.value!="" && 
				//window.document.frmcustins.txtlendno.value!="")
			{
				len=window.document.frames(2).frmcheque.txtchqsno.length
				
					if(eval(len)>1)
					{
							sy="|"
							for(i=0;i<eval(len);i++)
							{
								
								if(window.document.frames(2).frmcheque.txtchqsno(i).value!="")
								{
									window.document.frmcustins.hidchequesno.value=
									window.document.frmcustins.hidchequesno.value+sy+
									window.document.frames(2).frmcheque.txtchqsno(i).value
									window.document.frmcustins.hidchequeeno.value=
									window.document.frmcustins.hidchequeeno.value+sy+
									window.document.frames(2).frmcheque.txtchqeno(i).value
								}
								else
								{
									alert('Enter Cheque Start number.')
									return;
								}
							}
								window.document.frmcustins.hidprestartno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,1)
								window.document.frmcustins.hidpreendno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,2)
								window.document.frmcustins.action="custinstrissuedtlsinsert.asp"
								window.document.frmcustins.method="post"
								window.document.frmcustins.submit()
						}
						else
							{
								if(window.document.frames(1).frmcheque.txtchqsno.value!="")
								{
								window.document.frmcustins.hidchequesno.value=
								window.document.frames(2).frmcheque.txtchqsno.value
								window.document.frmcustins.hidchequeeno.value=
								window.document.frames(2).frmcheque.txtchqeno.value
								window.document.frmcustins.hidprestartno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,1)
								window.document.frmcustins.hidpreendno.value=
								window.document.frames(0).frmstock.stockdtls.textmatrix(1,2)
								window.document.frmcustins.action="custinstrissuedtlsinsert.asp"
								window.document.frmcustins.method="post"
								window.document.frmcustins.submit()
								}
								else
								{
									alert('Enter Cheque Start number.')
									return;
								}
							}
								
			}
			else
			{
					alert('Fields Should not  be Empty.')
			}
		}
	}
}

		
}
else
{
		alert('Fields Should not be Empty.')
}
}


function Cancel(){

	location.replace("custinstrissuedtls.asp")

}
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Display()">

<form name="frmcustins">
  <input type="hidden" name="txtendno" size="9" onkeypress="numeric()" readonly maxlength="15"><input type="hidden" name="txtstartno" size="6" onkeypress="numeric()" readonly maxlength="15">
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" nowrap height="28" colspan="3"></td>
        </tr>
        <tr class="bgcolor">
          <td width="34%" nowrap height="25"></td>
          <td width="33%" nowrap height="25"><font class="text">Customer Instrument Issue
          Details</font></td>
          <td width="33%" nowrap height="25" align="right"><font color="white">
                <%=APPDATE%></font></td>
        </tr>
      </table>

      <%if len(Request.QueryString("record"))>0 then%>

      <div align="center">
        <center>

        <table width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td height="15"><font face="MS Sans Serif" color="blue" size="3"><center><%=Request.QueryString("record")%></center></font></td>
          </tr>
        </table>

        </center>
      </div>

      <%end if%>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td width="100%" height="20" colspan="2">

            <table width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
              <tr class="bgcolor1">
                <td width="23%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Insert&quot;;okdis()" checked>
                New</font></td>
                <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Modify&quot;;okdis()">
                Modify</font></td>
                <td width="26%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Delete&quot;;okdis()">
                Delete</font></td>
                <td width="25%" align="middle"><font class="textwhite"><input type="radio" name="rdtran" onclick="Mode=&quot;Query&quot;;okdis()">
                Query</font></td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="113"><font class="textbold">&nbsp; Branch Code</font></td>
                <td width="237"><input name="txtbranchcode" size="9" readonly value="<%=session("branchcode")%>" maxlength="4"><input type="button" value=" L " name="cmdbranch" onclick="branch()" class="bgcolor"><input name="txtbranchdesc" size="16" readonly value="<%=session("branchnarration")%>"></td>
                <td width="130" align="right"><font class="textbold">Currency
                Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                <td width="254"><input name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" readonly maxlength="10"><input type="button" value=" L " name="B3" onclick="Currency()" class="bgcolor"><input name="txtcurrencydesc" size="16" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
              <tr>
                <td width="113" height="10"></td>
                <td width="237" height="10"></td>
                <td width="130" align="right" height="10"></td>
                <td width="254" height="10"></td>
              </tr>
            </table>

            </td>
          </tr>
          <tr>
            <td width="50%" valign="top">

            <table width="96%" cellpadding="0" class="tableborder2">
              <tr>
                <td>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="32%">&nbsp; Module ID</td>
                    <td width="68%"><input name="txtmodulecode" size="9" readonly maxlength="6"><input type="button" value=" L " name="cmdmodule" onclick="module()" class="bgcolor"><input name="txtmoduledesc" size="16" readonly></td>
                  </tr>
                  <tr>
                    <td width="32%">&nbsp; GLCode</td>
                    <td width="68%"><input name="txtglcode" size="9" readonly maxlength="8"><input type="button" value=" L " name="cmdglcode" onclick="GL()" class="bgcolor"><input name="txtgldesc" size="16" readonly></td>
                  </tr>
                  <tr>
                    <td width="32%">&nbsp; Account No</td>
                    <td width="68%"><input name="txtaccno" size="9" maxlength="10"><input type="button" value=" L " name="cmdaccno" readonly onclick="account()" class="bgcolor"><input name="txtaccdesc" size="16" readonly></td>
                  </tr>
                  <tr>
                    <td width="32%">&nbsp; Instrument Code</td>
                    <td width="68%"><input name="txtinstrcode" size="9" readonly maxlength="4"><input type="button" value=" L " name="cmdinstr" onclick="instrument()" class="bgcolor"><input name="txtinstrdesc" size="16" readonly></td>
                  </tr>
                  <tr>
                    <td width="32%">&nbsp; Customer Id</td>
                    <td width="68%"><input name="txtcustomercode" readonly size="30" maxlength="20"></td>
                  </tr>
                  <tr>
                    <td width="32%">&nbsp; Customer Name</td>
                    <td width="68%"><input name="txtcustomername" readonly size="30" maxlength="50"></td>
                  </tr>
                  <tr>
                    <td width="32%"></td>
                    <td width="68%"></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </td>
            <td width="50%" valign="top">
            <div align="center">
              <center>

              <table width="80%" cellpadding="0" class="tableborder2">
                <tbody>
                  <tr>
                    <td>
                    <div align="center">
                      <center>

                      <table width="50%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr class="bgcolor">
                          <td width="100%"><font class="textwhite">Available Range from
                          Department</font></td>
                        </tr>
                        <tr>
                          <td width="100%">
                          <div id="denom" align="center" style="display: block; height: 21; width: 283">

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr>
                                <td><iframe              
                  id="ifrastockdtls" align=center frameborder 
                              =0 framespacing 
                              =0 noresize 
                              height=96 width=284
                          
                        valign="top" src="../GENSBCA/custstockdtls.aspx" 
                        style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                          </div>
                          </td>
                        </tr>
                      </table>

                      </div>
                    </center></td>
                  </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="2" valign="top">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="16%">&nbsp;<input type="radio" value="Book" checked name="Radtype" onclick="Display()">Book</td>
                <td width="84%"><input type="radio" value="Leaf" name="Radtype" onclick="Display()">Leaf</td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>
        <div id="divbook" style="DISPLAY: block">

          <table width="98%" cellpadding="0" class="tableborder2">
            <tr>
              <td width="100%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" valign="top">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%">

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr class="bgcolor">
                          <td width="100%" colspan="10" height="15"><font class="subheading">Available
                          Book Stock Details</font></td>
                        </tr>
                        <tr>
                          <td width="100%" height="21" colspan="10"></td>
                        </tr>
                        <tr>
                          <td width="8%" height="28"><font class="textsmall">&nbsp;Series
                          No</font></td>
                          <td width="14%" height="28"><input name="txtserno" size="9" readonly maxlength="10"><input type="button" value=" L " name="cmdserno" onclick="getserno()" class="bgcolor"></td>
                          <td width="20%" height="28" align="right"><font class="textsmall">&nbsp;No.
                          of Leaves per book&nbsp;</font></td>
                          <td width="8%" height="28"><input name="txtlpboook" size="6" readonly onkeypress="numeric()" maxlength="10"></td>
                          <td width="11%" height="28" align="right"><font class="textsmall">No.
                          of Books&nbsp;</font></td>
                          <td width="10%" height="28"><input name="txtnobooks" size="9" onkeypress="numeric()" onkeyup="chknoofbookleaves()" onblur="chequebook()" maxlength="3"></td>
                          <!-- <td width="11%" height="28" align="right">Starting
                        S.No&nbsp;</font></td>-->
                          <td width="8%" height="28"></td>
                          <!--<td width="12%" height="28" align="right">Ending
                        S.no.&nbsp;</font></td>-->
                          <td width="10%" height="28"></td>
                        </tr>
                        <tr>
                          <td width="8%" height="10"></td>
                          <td width="14%" height="10"></td>
                          <td width="20%" height="10" align="right"></td>
                          <td width="8%" height="10"></td>
                          <td width="11%" height="10" align="right"></td>
                          <td width="10%" height="10"></td>
                          <td width="11%" height="10" align="right"></td>
                          <td width="8%" height="10"></td>
                          <td width="12%" height="10" align="right"></td>
                          <td width="10%" height="10"></td>
                        </tr>
                        <tr>
                          <td width="100%" colspan="10" valign="top">
                          <div align="center">

                            <table border="0" width="30%" bordercolor="#7d5445" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="100%">
                                <div align="center">

                                  <table border="0" width="100%" cellspacing="0" cellpadding="0" bordercolor="#7d5445">
                                    <tr>
                                      <td width="100%">
                                      <td><iframe  align=center frameborder=0 id="divcheque1"
										 framespacing =0 noresize 
										 height=120 width=330 valign="top" src="chequedtls.asp" 
                                style="BACKGROUND-COLOR: darkred"></iframe>
                                      </td>
                                    </tr>
                                  </table>

                                </div>
                                </td>
                              </tr>
                            </table>

                          </div>
                          </td>
                        </tr>
                        <tr>
                          <td width="100%" colspan="10" valign="top" height="20"></td>
                        </tr>
                      </table>

                      </td>
                    </tr>
                  </table>

                  </td>
                </tr>
                <tr>
                  <td width="100%"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

        </center>
        </div>
        <div id="divleaf" style="DISPLAY: none">
          <div align="center">
            <center>

            <table width="98%" cellpadding="0" class="tableborder2">
              <tr>
                <td width="100%">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%">

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr class="bgcolor">
                            <td width="100%" height="15" colspan="8"><font class="subheading">Available
                            Leaf&nbsp; Details</font></td>
                          </tr>
                          <tr>
                            <td width="7%" height="21"></td>
                            <td width="19%" height="21"></td>
                            <td width="12%" height="21"></td>
                            <td width="10%" height="21"></td>
                            <td align="right"></td>
                            <td width="14%" height="21"></td>
                            <td width="13%" height="21" align="right"></td>
                            <td width="14%" height="21"></td>
                          </tr>
                          <tr>
                            <td width="7%" height="25"><font class="textsmall">&nbsp;Series
                            No</font></td>
                            <td width="19%" height="25"><input name="txtlserno" size="9" readonly><input type="button" value=" L " name="cmdserno1" onclick="leafandpages()" class="bgcolor"></td>
                            <td width="12%" height="25" align="right"><font class="textsmall">&nbsp;No.
                            of Leaves&nbsp;</font></td>
                            <td width="10%" height="25"><input name="txtnoofleaves" size="9" onkeypress="numeric()" onkeyup="chknoofbookleaves()" onblur="chequeleaf()" maxlength="3"></td>
                            <!--<td width="13%" height="25" align="right">Starting
                        Sl.No&nbsp;</font></td>-->
                            <td><input type="text" type="hidden" name="txtlstartno" size="9" onkeypress="numeric()" readonly maxlength="15"></td>
                            <!--<td width="13%" height="25" align="right">Ending
                        Sl.No.&nbsp;</font></td>-->
                            <td width="17%" height="25"><input type="text" type="hidden" name="txtlendno" size="9" onkeypress="numeric()" readonly maxlength="15"></td>
                          </tr>
                          <tr>
                            <td width="100%" height="10" colspan="8"></td>
                          </tr>
                          <tr>
                            <td width="100%" height="25" colspan="8" valign="top">
                            <div align="center">
                              <center>

                              <table border="0" width="30%" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td width="100%">
                                  <td><font size="1" face="MS Sans Serif"><iframe  align=center frameborder=0 id="divcheque2"
										 framespacing =0 noresize 	 height=120 width=330 valign="top" src="chequedtls.asp" style="BACKGROUND-COLOR: darkred"></font></iframe>
                                  </td>
                                </tr>
                              </table>

                              </center>
                            </div>
                            </td>
                          </tr>
                          <tr>
                            <td width="100%" height="20" colspan="8" valign="top"></td>
                          </tr>
                        </table>

                        </td>
                      </tr>
                    </table>

                    </td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>

            </center>
          </div>
        </div>
      </div>
      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" height="10"></td>
    </tr>
  </table>

  <table border="0" align="center" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%"><input type="button" value="    Ok    " name="butok" onclick="Insert()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="Cancel()" class="bgcolor"><input type="button" value="   Exit   " name="butexit" class="bgcolor" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.asp"%>&quot;"></td>
    </tr>
  </table>

  <input type="hidden" name="hidchequesno"><input type="hidden" name="hidchequeeno"><input type="hidden" name="hidnoofbl"><input type="hidden" name="hidstatus"><input type="hidden" name="status"><input type="hidden" name="hidstock"><input type="hidden" name="hidprestartno"><input type="hidden" name="hidpreendno">
</form>

</body>

</html>
