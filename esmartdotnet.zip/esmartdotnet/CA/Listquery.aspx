<%@ Page Language="vb" CodeBehind="Listquery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Listquery1" %>
<HTML>
	<HEAD>
		<title>e-SMART</title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<%strType=Request.QueryString("st")%>
			<SCRIPT LANGUAGE="javascript">

function List()
{
var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0)
 {
	alert("Select Any Code") 
 }
else
 {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
		if (type=="Branch")
		{
			window.attachEvent(window.opener.Branchcode(str))
			window.close()
		}
		else if(type=="User")
		{
			window.attachEvent(window.opener.usercode(str))
			window.close()
		}
		else if(type=="Module")
		{
			window.attachEvent(window.opener.modulecode(str))
			window.close()
		}
		else if(type=="Instrument" || type=="DDinstrument" || type=="Reminstrument")
		{
			window.attachEvent(window.opener.instrcode(str))
			window.close()
		}
		else if(type.substring(0,17)=="Custinsinstrument")
		{
			window.attachEvent(window.opener.Custinstrcode(str))
			window.close()
		}
	else if (type.substring(0,9)=="Instrbook")
		{
			window.attachEvent(window.opener.instrbook(str))
			window.close()
		}
	else if (type.substring(0,13)=="Instrapproval")
		{
			window.attachEvent(window.opener.instrcode(str))
			window.close()
		}
	else if (type.substring(0,9)=="Instrleaf")
		{
			window.attachEvent(window.opener.instrleaf(str))
			window.close()
		}
	else if (type.substring(0,9)=="Combranch")
		{
			window.attachEvent(window.opener.Branchcode(str))
			window.close()
		}
	else if (type.substring(0,9)=="Commodule")
		{
			window.attachEvent(window.opener.modulecode(str))
			window.close()
		}
	else if (type.substring(0,13)=="custinsmodule")
		{
			window.attachEvent(window.opener.custmodcode(str))
			window.close()
		}
	else if (type.substring(0,9)=="Comglcode")
		{
			window.attachEvent(window.opener.Glcode(str))
			window.close()
		}
	else if (type.substring(0,10)=="Comaccount")
		{
			window.attachEvent(window.opener.accountid(str))
			window.close()
		}
	else if (type.substring(0,6)=="Series")
		{
			window.attachEvent(window.opener.serpagedet(str))
			window.close()
		}
	else if (type.substring(0,10)=="Deptmodify")
		{
			window.attachEvent(window.opener.serpagedet(str))
			window.close()
		}
		
	else if (type.substring(0,9)=="Custserno")
		{
			window.attachEvent(window.opener.Custsernonoofl(str))
			window.close()
		}
	else if (type.substring(0,10)=="Leafseries")
		{
			window.attachEvent(window.opener.leafpagedet(str))
			window.close()
		}
	else if (type.substring(0,11)=="Appromodule")
		{
			window.attachEvent(window.opener.modulecode(str))
			window.close()
		}
	else if (type=="Currency")
		{
			window.attachEvent(window.opener.Currencyid(str))
			window.close()
		}	
	else if (type.substring(0,12)=="Approaccount")
		{
			window.attachEvent(window.opener.accountid(str)(str))
			window.close()
		}
 }
}
			</SCRIPT>
			<%
dim obj,rs,uid
  set rs=server.CreateObject("adodb.recordset")
  set rs1=server.CreateObject("adodb.recordset")
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  uid=Session("userid")
if strType="Branch" then

	set rs=obj.singlerecordset("GENBANKBRANCHMST","distinct(Branchcode),narration")
	
elseif strType="User" then

	set rs=obj.singlerecordset("GenuSERMST","distinct(NAME),USERID")
	
elseif strType="Module" then

	set rs=obj.singlerecordset("GENMODULETYPESMST"," distinct(Moduleid),narration","IMPLEMENTEDYN='Y'")
	
elseif strType="Instrument" then

	set rs=obj.singlerecordset("GENINSTRUMENTMST","distinct(INSTRCODE),INSTRNAME")
	
elseif strType="Reminstrument" then

	set rs=obj.singlerecordset("GENINSTRUMENTMST","distinct(INSTRCODE),INSTRNAME","REMYN='Y'")
	
elseif strType="DDinstrument" then

	set rs=obj.singlerecordset("GENINSTRUMENTMST","distinct(INSTRCODE),INSTRNAME","REMYN='N'")

elseif left(strType,17)="Custinsinstrument" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTMST I,GENDEPTCUSTINSTRSTOCKDTLS D","distinct D.INSTRCODE,I.INSTRNAME","D.branchcode='" & k(1) & "' AND D.MODULEID='" & k(2) & "' AND D.INSTRCODE=I.INSTRCODE ","D.INSTRCODE")
	
elseif left(strType,9)="Instrbook" then
	
	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","BOOKSERIESNO,LEAVESPERBOOK,BOOKSTARTNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and bookyesno='Y' and status='STOCK' and transtatus='P'","BOOKSERIESNO,BOOKSTARTNO")

elseif left(strType,13)="custinsmodule" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS D, GENMODULETYPESMST M","distinct D.MODULEID,M.NARRATION","D.branchcode='" & k(1) & "' AND D.MODULEID=M.MODULEID","D.MODULEID")
	
elseif left(strType,9)="Instrleaf" then

	k=split(strType,"|")
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","LEAFSTARTNO,LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and leafyesno='Y' and STATUS='STOCK' and transtatus='P'","LEAFSERIESNO,LEAFSTARTNO")
	
elseif left(strType,9)="Combranch" then

	set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	set rs=obj.BranchCodes(cstr(uid))
	
elseif left(strType,9)="Comglcode" then

	set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	k=split(strType,"|")
	set rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))
	
elseif left(strType,10)="Comaccount" then
	k=split(strType,"|")
	set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	set rs=obj.AccountNumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)))
	if obj.connerror<>"" then
		str="Norecords"
		Errstr=obj.ConnError
	end if
	
elseif left(strType,9)="Commodule" then
	
	set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	k=split(strType,"|")
	set rs=obj.ModuleID(cstr(k(1)),"N","N")
	
elseif left(strType,6)="Series" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","distinct LEAVESPERBOOK,BOOKSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and bookyesno='Y' and status<>'ISSUED' and transtatus='A'","BOOKSERIESNO")
	
elseif left(strType,10)="Deptmodify" then

	k=split(strType,"|")
	
	'set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","distinct LEAVESPERBOOK,BOOKSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and ISSUEDTO='" & trim(ucase(K(3))) & "' and MODULEID = '" &trim(ucase(K(4))) &"' and bookyesno='Y' and status='ISSUABLE' and TRANSSTATUS='P'","BOOKSERIESNO")
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","distinct LEAVESPERBOOK,BOOKSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and ISSUEDTO='" & trim(ucase(K(3))) & "' and MODULEID = '" &trim(ucase(K(4))) &"' and bookyesno='Y'","BOOKSERIESNO")

elseif left(strType,9)="Custserno" then 

	k=split(strType,"~")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS","distinct bookseriesno,leavesperbook","branchcode='" & k(1) & "' and moduleid='" & k(2) & "'and  bookyesno='Y' and transstatus='A' and instrcode='" &  K(3) & "'","BOOKSERIESNO")

elseif left(strType,13)="Instrapproval" then

	k=split(strType,"~")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS C,GENINSTRUMENTMST M","distinct C.INSTRCODE, M.INSTRNAME","C.INSTRCODE=M.INSTRCODE AND C.branchcode='" & k(1) & "' and C.status='ISSUABLE' and C.transstatus='P'","C.INSTRCODE")
	
elseif left(strType,10)="Leafseries" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENINSTRUMENTSTOCKDTLS","distinct NOOFLEAVES,LEAFSERIESNO","branchcode='" & k(1) & "' and instrcode='" &  K(2) & "' and LEAFYESNO='Y' and status<>'ISSUED'","LEAFSERIESNO")
	
elseif left(strType,11)="Appromodule" then

	k=split(strType,"|")
	
	set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS C,GENMODULETYPESMST M","distinct C.moduleid, M.NARRATION","C.moduleid=M.moduleid AND C.branchcode='" & k(1) & "' and C.status<>'ISSUED'","C.moduleid")
	
elseif strType="Currency" then

	set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration")
	
elseif left(strType,12)="Approaccount" then

	k=split(strType,"|")
	
	set rs1=obj.singlerecordset("GENMODULEMST","distinct MASTERTABLE","moduleid='" & k(2) & "'","MASTERTABLE")
	
	IF rs1.EOF<>TRUE AND rs1.BOF<>TRUE THEN
		
		set rs=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS G,RS1(0) S","distinct G.ACCNO,S.NAME ","G.ACCNO=S.ACCNO AND G.branchcode='" & k(1) & "' and G.moduleid='" & k(2) & "'  and G.status<>'ISSUED'","G.ACCNO")
		
	END IF

end if

%>
	</HEAD>
	<body>
		<form name="frmList">
			<div align="center">
				<center>
					<table class="tablebordermain" cellspacing="0" cellpadding="0">
						<tr class="bgcolor">
							<%	if str="Norecords" then
	Response.Write"<font size=4 color=#FFFFFF face=MS Sans Serif>"& Errstr &"</font>" %>
							<center>
								<td><input type="button" value="   OK   " name="butmd" onclick="window.close()" class="bgcolor">
									<CENTER></CENTER>
									<%else
	IF  NOT rs.EOF   AND NOT rs.BOF THEN
		if len(strType)>8 then	%>
									<th align="left">
										<font class="textbold">
											<%'=UCASE(stname)%>
											&nbsp;DESCRIPTION - CODE</font></th>
									<%else%>
									<th align="left">
										<font class="textbold">
											<%'=UCASE(strType)%>
											&nbsp;DESCRIPTION - CODE</font></th>
									<%end if%>
									<tr>
								<td><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
										<%if rs.EOF<>true and rs.BOF<>true then
			do until rs.EOF
			if rs.Fields.Count < 2 then%>
										<option><%=rs(0)%></option>
										<%elseif rs.Fields.Count=3 and left(strType,9)="Instrbook" then%>
										<option><%=rs(0)%>
											-----<%=rs(1)%>
											-----<%=rs(2)%></option>
										<%else%>
										<option><%=rs(1)%>
											-----<%=rs(0)%></option>
										<%end if
			rs.MoveNext
			loop
			Response.Write "<script language=vbscript>" & chr(13)
			Response.Write "window.document.frmList.cmbList.item(0).selected=true" & chr(13)
			Response.Write "</script>" & chr(13)
			end if
			set rs=nothing
			set rs1=nothing
			set obj=nothing%>
									</select></td>
						</tr>
					</table>
				</center>
			</div>
			<center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
			</center>
			<%else
		Response.Write "<font color=white size=2><center><b>No Records Found<b></center></font>"%>
			<br>
			<br>
			<center><input type="button" value="   OK   " name="butok" onclick="window.close()" class="bgcolor"></center>
			<%end if%>
			<%end if%>
		</form>
		</CENTER>
	</body>
</HTML>
