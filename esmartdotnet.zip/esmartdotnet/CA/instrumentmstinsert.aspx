<%@ Page Language="vb" CodeBehind="instrumentmstinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.instrumentmstinsert" %>
<%

	dim Obj,strmsg	'object variables
	dim ArrTrans(0,4)	
	dim instrcode,desccode  'to store textbox values
	set rsinsert=server.CreateObject("adodb.recordset")
	set Obj=server.CreateObject("GeneralTransactions.DBTransactions")
	status=trim(Request.Form("hidstatus"))
	instrcode=trim(Request.Form("txtinstrcode"))
	desc=trim(Request.Form("txtdesc"))
	remitance=Request.Form("radrem")
	
					
if len(desc)>0 and len(instrcode)>0  then
			if status="INSERT" then
			str="INSTRCODE,INSTRNAME,REMYN,USERID,MACHINEID"
			
			strvalues="'" & instrcode & "','" & desc  & "','" & remitance &  "','" & session("userid") & "','" & session("MachineID") & "'"
	
			ArrTrans(0,0)="I"
				'passing the table name
			ArrTrans(0,1)="GENINSTRUMENTMST"
				'passing columns
			ArrTrans(0,2)=str
			'passing values
			ArrTrans(0,3)=strvalues
			'passing where condition
			ArrTrans(0,4)=""
			
			Strmsg= OBJ.DataTransactions(ArrTrans)

elseif status="MODIFY" then

	strvalues=""
	
	strvalues="'" &  instrcode & "'~'" & desc & "'~'" & remitance & "'"
	
	str="INSTRCODE,INSTRNAME,REMYN"
	
	ArrTrans(0,0)="U"
'passing the table name
	ArrTrans(0,1)="GENINSTRUMENTMST"
'passing columns
	ArrTrans(0,2)=str
'passing values
	ArrTrans(0,3)=strvalues
'passing where condition
	ArrTrans(0,4)="trim(INSTRCODE)='"& trim(instrcode) &"'" 
	
	Strmsg= OBJ.DataTransactions(ArrTrans)

elseif status=trim("DELETE") then

	STR=""
	str="trim(INSTRCODE)='"& trim(instrcode) &"'" 
	ArrTrans(0,0)="D"
'passing the table name
	ArrTrans(0,1)="GENINSTRUMENTMST"
'passing columns
	ArrTrans(0,2)=""
'passing values
	ArrTrans(0,3)=""
'passing where condition
	ArrTrans(0,4)=str
	Strmsg= OBJ.DataTransactions(ArrTrans)
end if
set obj=nothing
	Response.Redirect "instrumentmst.asp?record=" & strmsg
else
	Response.Redirect "instrumentmst.asp?record=Fields Should not be Null." 
end if

%>

