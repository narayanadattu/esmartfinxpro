<%@ Page Language="vb" CodeBehind="SBinstrumentapprovalinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBinstrumentapprovalinsert" %>
<%
Dim Obj 'object variable.
Dim strmsg 
Dim brcode,inscode 'To store textbox values.
Dim Arrtrans(0,4) 
Dim flexval,flex,flexstr,transtr,str,strvalues
Dim modid,uid,leno,lserno,lsno,status
Dim ssno

'Storing Branch,Instrument details.

brcode=trim(Request.Form("txtbranchcode"))
inscode=trim(Request.Form("txtinstrcode"))
insdesc=trim(Request.Form("txtinstrdesc"))
status=trim(Request.Form("hidstatus"))
rtype=trim(Request.Form("Radtype"))
esno=trim(Request.Form("txtendsno"))
nlpb=trim(Request.Form("txtnoleavesperbook"))
serno=trim(Request.Form("txtserno"))
ssno=trim(Request.Form("txtssno"))
modid=trim(Request.Form("txtmodid"))
uid=trim(Request.Form("txtuserid"))
leno=trim(Request.Form("txtleno"))
lserno=trim(Request.Form("txtlserno"))
lsno=trim(Request.Form("txtlsno"))
appby=session("userid")
appdate=session("applicationdate")
appmac=session("machineid")

	
Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")				
if len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVEALL" then
	flexval=Request.Form("hidflex")
	flex=split(flexval,"*|*")
	for irow=1 to ubound(flex)
		flexstr=split(flex(irow),"~!~")
	if	len(flexstr(4))>0	then
		strwhere=strwhere &"trim(BRANCHCODE)='" & trim(brcode) & "' AND trim(MODULEID)='" & trim(flexstr(1)) & "' AND ISSUEDTO='" & trim(flexstr(2)) & "' AND INSTRCODE='" & trim(flexstr(3)) & "' AND LEAVESPERBOOK='" & trim(flexstr(6)) & "' AND BOOKSERIESNO='" & trim(flexstr(4)) & "' AND BOOKSTARTNO='" & trim(flexstr(7)) & "' AND BOOKENDNO='" & trim(flexstr(8)) & "' AND TRANSSTATUS='P'"&"|"
	elseif	len(flexstr(5))>0   then
		strwhere=strwhere&"BRANCHCODE='" & trim(brcode) & "' AND MODULEID='" & trim(flexstr(1)) & "' AND ISSUEDTO='" & trim(flexstr(2)) & "' AND INSTRCODE='" & trim(flexstr(3)) & "' AND LEAFSERIESNO='" & trim(flexstr(5)) & "' AND LEAFNUMBER BETWEEN '" & trim(flexstr(9)) & "' AND '" & trim(flexstr(10)) & "' AND TRANSSTATUS='P'"&"|"
	end if
	strvalues=strvalues & "'A'"&  "~'" & appby & "'~'" & appmac & "'~sysdate~'" & appdate & "'" & "|"
	next
		strwhere=left(strwhere,len(strwhere)-1)
		strvalues=left(strvalues,len(strvalues)-1)
		
		str="TRANSSTATUS,approvedby,approvedmachine,systemdate,applicationdate"
		Arrtrans(0,0)="U"
		'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
		'passing columns
		Arrtrans(0,2)=str
		'passing values
		Arrtrans(0,3)=strvalues 
		'passing where condition
		Arrtrans(0,4)=strwhere
		
	
		Strmsg= OBJ.DataTransactions(ArrTrans)
		Response.Write arrtrans(0,4) & "<br>"
		Response.Write arrtrans(0,3) & "<br>"
		Response.Write arrtrans(0,2) & "<br>"
	
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Write strmsg
	Response.Redirect "SBInstrumentapproval.asp?result=" & result

elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="APPROVE" then
	
	if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND trim(MODULEID)='" & trim(modid) & "' AND ISSUEDTO='" & trim(uid) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "' AND TRANSSTATUS='P'"
		transtr="A"
		strvalues="'" & transtr & "'"
		'str="TRANSSTATUS"
		str="TRANSSTATUS,approvedby,approvedmachine,systemdate,applicationdate"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues & "~'" & appby & "'~'" & appmac & "'~sysdate~'" & appdate & "'"
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "' AND MODULEID='" & trim(modid) & "' AND ISSUEDTO='" & trim(uid) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND LEAFNUMBER BETWEEN '" & trim(lsno) & "' AND '" & trim(leno) & "' AND TRANSSTATUS='P'"
		
			
		transtr="A"
		strvalues="'" & transtr & "'"
		
			str="TRANSSTATUS,approvedby,approvedmachine,systemdate,applicationdate"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues & "~'" & appby & "'~'" & appmac & "'~sysdate~'" & appdate & "'"
	'passing where condition
		Arrtrans(0,4)=strwhere
	end if
	Strmsg= OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "SBInstrumentapproval.asp?result=" & result 
elseif len(brcode)>0 and len(inscode)>0 and ucase(status)="REJECT" then
		if ucase(rtype)="BOOK" then
	
		strwhere="trim(BRANCHCODE)='" & trim(brcode) & "' AND trim(MODULEID)='" & trim(modid) & "' AND ISSUEDTO='" & trim(uid) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAVESPERBOOK='" & trim(nlpb) & "' AND BOOKSERIESNO='" & trim(serno) & "' AND BOOKSTARTNO='" & trim(ssno) & "' AND BOOKENDNO='" & trim(esno) & "' AND TRANSSTATUS='P'"
		transtr="R"
		strvalues="'" & transtr & "'"
			str="TRANSSTATUS,approvedby,approvedmachine,systemdate,applicationdate"
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
		Arrtrans(0,3)=strvalues & "~'" & appby & "'~'" & appmac & "'~sysdate~'" & appdate & "'"
	'passing where condition
		Arrtrans(0,4)=strwhere
	
	elseif ucase(rtype)="LEAF" then
	
		strwhere="BRANCHCODE='" & trim(brcode) & "' AND MODULEID='" & trim(modid) & "' AND ISSUEDTO='" & trim(uid) & "' AND INSTRCODE='" & trim(inscode) & "' AND LEAFSERIESNO='" & trim(lserno) & "' AND LEAFNUMBER BETWEEN '" & trim(lsno) & "' AND '" & trim(leno) & "' AND TRANSSTATUS='P'"
		
		transtr="R"
		strvalues="'" & transtr & "'"
		
	str="TRANSSTATUS,approvedby,approvedmachine,systemdate,applicationdate"	
		Arrtrans(0,0)="U"
	'passing the table name
		Arrtrans(0,1)="GENDEPTCUSTINSTRSTOCKDTLS"
	'passing columns
		Arrtrans(0,2)=str
	'passing values
	Arrtrans(0,3)=strvalues & "~'" & appby & "'~'" & appmac & "'~sysdate~'" & appdate & "'"
	'passing where condition
		Arrtrans(0,4)=strwhere
	end if
	Strmsg=OBJ.DataTransactions(ArrTrans)
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "SBInstrumentapproval.asp?result=" & result 
else
	strmsg="Fields Should not be Null"
	result=strmsg&"~!~"&inscode&"~!~"&insdesc
	Response.Redirect "SBInstrumentapproval.asp?result=" & result
end if	

%>
