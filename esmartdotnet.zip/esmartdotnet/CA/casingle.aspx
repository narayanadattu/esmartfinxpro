<%@ Page Language="vb" CodeBehind="casingle.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_CAsingle" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>i-SMART</title>
<%strType=Request.QueryString("st")
%>
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">

function load()
{
	if(window.document.frmList.cmbList.length>1)
	window.document.frmList.cmbList[0].selected=true 	
}


function List()
{

var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
	{
		alert("Select Any Code") 
	}
else
   {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	if (type.substring(0,9)=="Allotment")
		{
		window.attachEvent(window.opener.Allotmentid(str))
		window.close()
		}
	
	
//----------------------for Sb module

else if (type.substring(0,9)=="chgGlcode")
{
	window.attachEvent(window.opener.chgGlcodeid(str))
	window.close()
}
else if(type.substring(0,6)=="Modify")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}	
	else if(type.substring(0,6)=="Delete")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}	
	else if(type.substring(0,4)=="View")
	{
		window.attachEvent(window.opener.Modifyid(str))
		window.close()
	}		
		
	}
}
</SCRIPT>
<%
dim obj,rs
  set obj=server.CreateObject("GeneralTranQueries.TransactionQueries") 
  set rs=server.CreateObject("adodb.recordset")
  k=split(strtype,"|")
 if left(strtype,6)="Modify" then
	k=split(strtype,"|")    
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(k(4)),"R")
	set obj=nothing
elseif left(strtype,6)="Delete" then	
	k=split(strtype,"|")
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(k(4)),"R")	
set obj=nothing	
elseif left(strtype,4)="View" then	
	k=split(strtype,"|")
	set rs=obj.Accountnumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(k(4)),"A")
	'set rs=obj.Accountnumbers("0001","CA","CA100","INR","A")		
set obj=nothing

end if
'onload='load()'
%>
</head>
<body onload="load()">

<form name="frmList">
  <%if not rs.BOF and not rs.EOF then %>

  <table class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <th style="FONT-SIZE:xx-medium"><font class="textbold">&nbsp;Account No</font></th>
    <tr class="bgcolor">
      <td style="FONT-SIZE:xx-medium"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	    <%do until rs.EOF%>	
        <option><%=rs(0)%></option>
	    <%
	rs.MoveNext
	loop  
	set rs=nothing
	set obj=nothing
	    %>  	   
      </select></td>
    </tr>
  </table>

  <%
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()"& chr(13)  
	Response.Write "window.document.frmList.cmbList.item(0).selected=true"& chr(13)      
	Response.Write "end sub" & chr(13)  
	Response.Write "call show()" & chr(13)  
	Response.Write "</script>" & chr(13) 
  %>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor">
  <input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <%else%>
  <font class="textwhite">No Records Found </font><center><select name="cmbList" size="4" ondblclick="List()">
  </select><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <%end if%>       
</form>

</body>

</html>
