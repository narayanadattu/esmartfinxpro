<%@ Page Language="vb" CodeBehind="changelist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.changelist3" %>
<HTML>
	<HEAD>
		<title>i-SMART</title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<%
strType=Request.QueryString("st")
%>
			<SCRIPT LANGUAGE="javascript" src="proc.js">
			</SCRIPT>
			<SCRIPT LANGUAGE="javascript">

function List()
{
var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else
 {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	
if (type.substring(0,6)=="Branch")
{
	window.attachEvent(window.opener.Branchid(str))
	window.close()
}
else if (type=="Currency")
{
	window.attachEvent(window.opener.Currencyid(str))
	window.close()
}	
else if (type.substring(0,6)=="Module")
{
	window.attachEvent(window.opener.Moduleid(str))
	window.close()
}
else if (type.substring(0,6)=="Glcode")
{
	
	window.attachEvent(window.opener.Glcodeid(str))
	window.close()
}
else if (type.substring(0,5)=="Accno")
{
	window.attachEvent(window.opener.Accnoid(str))
	window.close()
}
else if (type.substring(0,6)=="Custid")
{
	window.attachEvent(window.opener.Customerid(str))
	window.close()
}


}
}
			</SCRIPT>
			<%
dim obj,rs
  set rs=server.CreateObject("adodb.recordset")    
  set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")

if left(strType,6) ="Branch" then
	k=split(strType,"|")
	set rs=obj.BranchCodes(cstr(k(1)))	
	set obj=nothing
elseif strType="Currency" then
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration")
	set obj=nothing
elseif left(strType,6)="Module" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENMODULEMST","moduleid,narration","mastertable is not null")
	'set rs=obj.ModuleID(cstr(k(1)))
	set obj=nothing		
	
elseif left(strType,6)="Glcode" then
	k=split(strType,"|")
	set rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))
	set obj=nothing
elseif left(strType,5)="Accno" then
	k=split(strType,"|")	
	set rs=server.CreateObject("adodb.recordset")    
	set rs=obj.accountnumbers(cstr(k(1)),cstr(k(3)),cstr(k(4)),cstr(k(2)))
	'set rs=obj.accountnumbers("0001","SB","SB0001","INR")		
	set obj=nothing		
 elseif left(strType,6)="Custid" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset(cstr(k(1)),"customerid","BRANCHCODE='"& k(2)&"' and " _
	& " currencycode='"&k(3)&"' and glcode='"&k(4)&"' and accno='"&k(5)&"'","name")	
	custid=rs(0)	
	set rs=server.CreateObject("adodb.recordset")    
	set rs=obj.singlerecordset("gencustinfomst","customerid,custname","BRANCHCODE='"& k(2)&"'and  customerid<>'"&custid&"'") 	
	set obj=nothing


end if
%>
	</HEAD>
	<body>
		<form name="frmList">
			<table class="tablebordermain" cellspacing="0" cellpadding="0">
				<% if not rs.EOF and not rs.bof  then%>
				<%	if len(strType)>8 then	%>
				<tr class="bgcolor">
					<th>
						<font class="textbold">
							<%'=UCASE(stname)%>
							&nbsp;DESCRIPTION | CODE</font></th>
					<%	else	%>
					<th>
						<font class="textbold">
							<%'=UCASE(strType)%>
							&nbsp;DESCRIPTION | CODE</font></th>
					<%end if

	  %>
				<tr class="bgcolor">
					<td><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
							<% do until rs.EOF%>
							<option><%=rs(1)%>
								-----<%=rs(0)%></option>
							<%
	rs.MoveNext	
	loop    
        %>
						</select></td>
				</tr>
			</table>
			<%
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()"& chr(13)  
	Response.Write "window.document.frmList.cmbList.item(0).selected=true"& chr(13)      
	Response.Write "end sub" & chr(13)  
	Response.Write "call show()" & chr(13)  
	Response.Write "</script>" & chr(13) 
  %>
			<center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor">
				<input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
			</center>
			<%else%>
			<font class="textwhite">No Records Found </font>
			<center><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
			</center>
			<%end if %>
		</form>
	</body>
</HTML>
