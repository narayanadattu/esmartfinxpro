<%@ Page Language="vb" CodeBehind="sblist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.sblist1" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>e-Smart Banker</title>
<%
strType=Request.QueryString("st")
%>
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">

function List()
{
var str,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else
 {
	str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
	
if (type.substring(0,6)=="Branch")
{
	window.attachEvent(window.opener.Branchid(str))
	window.close()
}
else if (type.substring(0,10)=="FromBranch")
{
	window.attachEvent(window.opener.FromBranchid(str))
	window.close()
}
else if (type.substring(0,8)=="ToBranch")
{
	window.attachEvent(window.opener.ToBranchid(str))
	window.close()
}
else if (type=="Currency")
{
	window.attachEvent(window.opener.Currencyid(str))
	window.close()
}	
else if (type.substring(0,6)=="Module")
{
	window.attachEvent(window.opener.Moduleid(str))
	window.close()
}
else if (type.substring(0,12)=="Mastermodule")
{
	window.attachEvent(window.opener.Moduleid(str))
	window.close()
}

else if (type.substring(0,6)=="Glcode")
{
	
	window.attachEvent(window.opener.Glcodeid(str))
	window.close()
}
else if (type.substring(0,8)=="MasterGl")
{	
	window.attachEvent(window.opener.Glcodeid(str))
	window.close()
}

else if (type.substring(0,5)=="Accno")
{
	window.attachEvent(window.opener.Accnoid(str))
	window.close()
}

else if (type.substring(0,7)=="TransNo")
{
	window.attachEvent(window.opener.TransNoid(str))
	window.close()
}
else if (type.substring(0,6)=="Custid")
{
	window.attachEvent(window.opener.Custid(str))
	window.close()
}
else if (type.substring(0,5)=="Intid")
{
	window.attachEvent(window.opener.Introducerid(str))
	window.close()
}
else if (type.substring(0,7)=="Jointid")
{
	window.attachEvent(window.opener.Jointid(str))
	window.close()
}
else if (type.substring(0,7)=="Guardid")
{
	window.attachEvent(window.opener.Guardid(str))
	window.close()
}
else if (type.substring(0,9)=="Nomineeid")
{
	window.attachEvent(window.opener.Nomineeid(str))
	window.close()
}
else if (type.substring(0,8)=="Category")
{
	window.attachEvent(window.opener.Categoryid(str))
	window.close()
}

}
}
</SCRIPT>
<%
dim obj,rs
  set rs=server.CreateObject("adodb.recordset")    
  set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")

if left(strType,6) ="Branch" then
	k=split(strType,"|")
	set rs=obj.BranchCodes(cstr(k(1)))	
	set obj=nothing
elseif left(strType,10) ="FromBranch" then
	k=split(strType,"|")	
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENBANKBRANCHMST","branchcode,branchname","branchcode<>'"& cstr(k(1))&"'")
	set obj=nothing
elseif left(strType,8) ="ToBranch" then
	k=split(strType,"|")
	set rs=obj.BranchCodes(cstr(k(1)))	
	set obj=nothing		
elseif strType="Currency" then
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,PRECISION")
	set obj=nothing
		
elseif left(strType,6)="Module" then
	k=split(strType,"|")
	set rs=obj.ModuleID(cstr(k(1)))
	set obj=nothing
elseif left(strType,12)="Mastermodule" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENMODULEMST","moduleid,narration","mastertable is not null ")
	set obj=nothing		
	
elseif left(strType,6)="Glcode" then
	k=split(strType,"|")
	set rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))
	set obj=nothing
elseif left(strType,8)="MasterGl" then
	k=split(strType,"|")	
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")	
	str=k(1)
	set rs=obj.singlerecordset(""& str &" a,genglsheetmst b","distinct b.glcode,b.narration","b.branchcode='"& k(2) &"' and  b.moduleid='"&k(3)&"' and a.glcode=b.glcode")
	 
	set obj=nothing
	
	
 elseif left(strType,6)="Custid" then

	k=split(strType,"|")

	set rs=server.CreateObject("adodb.recordset")    

	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")

	set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","BRANCHCODE='"& cstr(k(1))&"'")

	set obj=nothing

elseif left(strType,5)="Intid" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","BRANCHCODE='"& cstr(k(1))&"' and customerid<>'"& cstr(k(2))&"'")
	set obj=nothing
elseif left(strType,7)="Jointid" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","BRANCHCODE='"& cstr(k(1))&"' and customerid<>'"& cstr(k(2))&"'")
	set obj=nothing
elseif left(strType,8)="Category" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("genacctcategorymst","CATEGORYCODE,NARRATION","")
	set obj=nothing	
elseif left(strType,7)="Guardid" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","BRANCHCODE='"& cstr(k(1))&"' and customerid<>'"& cstr(k(2))&"'")
	set obj=nothing
	elseif left(strType,9)="Nomineeid" then
	k=split(strType,"|")
	set rs=server.CreateObject("adodb.recordset")    
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","BRANCHCODE='"& cstr(k(1))&"' and customerid<>'"& cstr(k(2))&"'")
	set obj=nothing		
end if
%>
</head>
<body>

<form name="frmList">
  <div align="center">
    <center>

    <table class="tablebordermain" cellspacing="0" cellpadding="0">
      <tr class="bgcolor">
        <% if not rs.EOF and not rs.bof  then%>
        <%	if len(strType)>8 then	%>
      
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(stname)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%	else	%>
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(strType)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%end if

	    %>
      <tr>
        <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	      <%  
	
	do until rs.EOF
	if rs.Fields.Count = 2 then%>
          <option><%=rs(1)%>-----<%=rs(0)%></option>
	      <%elseif rs.Fields.Count=3 then%>
          <option><%=rs(1)%>-----<%=rs(0)%>-----<%=rs(2)%></option>
	      <%end if%>
	      <%rs.MoveNext
	
  loop
    
          %> 
        </select></td>
      </tr>
    </table>

    </center>
  </div>

  <%
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()"& chr(13)  
	Response.Write "window.document.frmList.cmbList.item(0).selected=true"& chr(13)      
	Response.Write "end sub" & chr(13)  
	Response.Write "call show()" & chr(13)  
	Response.Write "</script>" & chr(13) 
  %>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <%else%>
  <font color="white">No Records Found </font><center><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor">
  </center>
  <%end if %>     


</form>

</body>

</html>
