<%@ Page Language="vb" CodeBehind="changecounter.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.changecounter2" %>
<HTML>
	<HEAD>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
	var str
	str= window.document.frmacc.hbno.value		
	window.attachEvent(window.opener.Allot(str))   		
	window.close()
 
}
//-->
			</SCRIPT>
			<%
	dim rs,obj,strResult
	str=Request.QueryString("st")  	
	k=split(str,"|")  
	'Response.Write str & "<br>"
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")  
  set rs=server.CreateObject("adodb.recordset")
  
	
if k(0)="Cheque" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"chequebook","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'") 
	strResult="Cheque"& "|" & rs(0) 
	 rs.Close() 
elseif k(0)="TDS" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"tdsyn","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
	strResult="TDS"& "|" &rs(0)	
	 rs.Close() 
elseif k(0)="Bank" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"bankstaffyn","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
	strResult="Bank"& "|" &rs(0)
	 rs.Close() 	
elseif k(0)="Status" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"status","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
  status=rs(0)
  rs.Close()  
    
  set rs=obj.singlerecordset("GenAccountStatusTypeMst","code","code<>'"& status&"' and code<>'P'")
		set obj=nothing							
		if not rs.BOF and not rs.EOF then
		cnt=rs.RecordCount 
		do until rs.EOF 		
			counterno=counterno & rs(0)& "|"
			rs.MoveNext() 
		loop
		end if   
	strResult="Status"& "|" & status & "|"& cnt & "~"& counterno
	 rs.Close() 
elseif k(0)="Opinstr" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"OPERATINGINSTR","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
	strResult="Opinstr"& "|" &rs(0)		
	rs.Close()	
	
elseif k(0)="Optby" then 	
  set rs=obj.singlerecordset(cstr(k(1)),"OPERATEDBY","branchcode='"&k(2)&"' and " _
  & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
  
	strResult="Optby"& "|" &rs(0)					
	
	rs.Close() 
elseif(k(0)="Getaccountno") then	
	
 set rs=obj.singlerecordset(cstr(k(1)),"name","branchcode='"&k(2)&"' and " _
 & " currencycode='"& k(3)&"' and glcode='"& k(5)&"' and accno='"&k(6)&"'")
	if not rs.bof and not rs.eof then
		strResult="Accoutno"& "|" & rs(0)
	else
		strResult="Accoutno"& "|" & "This Account No Does Not Exists"
	end if	

	rs.Close() 
end if

 
'onLoad='List()'
%>
	</HEAD>
	<body onload="List()">
		<form name="frmacc">
			<input type="hidden" name="hbno" id="hbno" value="<%=strResult%>"><center><font class="textblue">Processing..........</font></center>
		</form>
	</body>
</HTML>
