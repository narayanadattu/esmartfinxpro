<%@ Page CodeBehind="SBinstrumentdtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_SBinstrumentdtls" %>
<%
	dim insdtl,insstr
	insdtl=Request.Form("hidinstr")
	insstr=split(insdtl,"~")	
%>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<title>Instruments</title>
			<SCRIPT ID="clientEventHandlersJS" LANGUAGE="javascript">
<!--
function mfgins_DblClick() 
{
	if(window.document.frminsapp.mfgins.Cols>1 && window.document.frminsapp.mfgins.Rows>1)
	{
		i=window.document.frminsapp.mfgins.Row
		
		//for (d=0;d<window.document.frminsapp.mfgins.Cols;d++) 
		//{   
		//		window.document.frminsapp.mfgins.Row=i
		//		window.document.frminsapp.mfgins.Col=d
		//		window.document.frminsapp.mfgins.CellBackColor="<%=vbyellow%>"
		//}
		
		window.parent.window.document.frmapproval.txtbrcode.value=window.parent.window.document.frmapproval.txtbranchcode.value
		window.parent.window.document.frmapproval.txtbrdesc.value=window.parent.window.document.frmapproval.txtbranchdesc.value
		window.parent.window.document.frmapproval.txtinscode.value=window.parent.window.document.frmapproval.txtinstrcode.value
		window.parent.window.document.frmapproval.txtinsdesc.value=window.parent.window.document.frmapproval.txtinstrdesc.value
		window.parent.window.document.frmapproval.txtuserid.value=window.document.frminsapp.mfgins.TextMatrix(i,1)
		window.parent.window.document.frmapproval.txtuserdesc.value=window.document.frminsapp.mfgins.TextMatrix(i,12)
		window.parent.window.document.frmapproval.txtmodid.value=window.document.frminsapp.mfgins.TextMatrix(i,0)
		window.parent.window.document.frmapproval.txtmoddesc.value=window.document.frminsapp.mfgins.TextMatrix(i,11)
	
	if(window.document.frminsapp.mfgins.TextMatrix(i,3))
	{
		//for(d=0 ;d<window.document.frminsapp.mfgins.Cols;d++) 
		//		{   
		//		window.document.frminsapp.mfgins.Row=i
		//		window.document.frminsapp.mfgins.Col=d
		//		window.document.frminsapp.mfgins.CellBackColor="<%=vbYellow%>"
		//  }
		
		window.parent.window.document.frmapproval.Radtype(0).disabled=false
		window.parent.window.document.frmapproval.Radtype(0).checked=true
		window.parent.window.document.frmapproval.Radtype(1).disabled=true
		window.parent.window.document.frmapproval.all.divleaf.style.display="none"
		window.parent.window.document.frmapproval.all.divbook.style.display="block"
		window.parent.window.document.frmapproval.txtserno.value=window.document.frminsapp.mfgins.TextMatrix(i,3)
		window.parent.window.document.frmapproval.txtnoleavesperbook.value=window.document.frminsapp.mfgins.TextMatrix(i,5)
		window.parent.window.document.frmapproval.txtssno.value=window.document.frminsapp.mfgins.TextMatrix(i,6)
		window.parent.window.document.frmapproval.txtendsno.value=window.document.frminsapp.mfgins.TextMatrix(i,7)
	}
	else if(window.document.frminsapp.mfgins.TextMatrix(i,4))
	{
		var lsno,esno,nol
		lsno=window.document.frminsapp.mfgins.TextMatrix(i,8)
		esno=window.document.frminsapp.mfgins.TextMatrix(i,9)
		nol=eval(esno)-eval(lsno)+1
		window.parent.window.document.frmapproval.Radtype(1).disabled=false
		window.parent.window.document.frmapproval.Radtype(1).checked=true
		window.parent.window.document.frmapproval.Radtype(0).disabled=true
		window.parent.window.document.frmapproval.all.divleaf.style.display="block"
		window.parent.window.document.frmapproval.all.divbook.style.display="none"
		window.parent.window.document.frmapproval.txtlserno.value=window.document.frminsapp.mfgins.TextMatrix(i,4)
		window.parent.window.document.frmapproval.txtnol.value=nol
		window.parent.window.document.frmapproval.txtlsno.value=window.document.frminsapp.mfgins.TextMatrix(i,8)
		window.parent.window.document.frmapproval.txtleno.value=window.document.frminsapp.mfgins.TextMatrix(i,9)
	}
	}
}

//-->
			</SCRIPT>
			<SCRIPT LANGUAGE="javascript" FOR="mfgins" EVENT="DblClick">
<!--
 mfgins_DblClick()
//-->
			</SCRIPT>
	</head>
	<body topmargin="0" leftmargin="0">
		<form name="frminsapp">
			<div align="center">
				<input type="hidden" name="hidinstr">
				<center>
					<table border="0" width="60%" class="tablebordermain" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%">
								<OBJECT classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="135" id="mfgins" name="mfgins"
									style="LEFT: 21px; TOP: 0px" width="656">
									<PARAM NAME="_ExtentX" VALUE="17357">
									<PARAM NAME="_ExtentY" VALUE="3572">
									<PARAM NAME="_Version" VALUE="393216">
									<PARAM NAME="Rows" VALUE="1">
									<PARAM NAME="Cols" VALUE="14">
									<PARAM NAME="FixedRows" VALUE="1">
									<PARAM NAME="FixedCols" VALUE="0">
									<PARAM NAME="RowHeightMin" VALUE="0">
									<PARAM NAME="BackColor" VALUE="-2147483643">
									<PARAM NAME="ForeColor" VALUE="-2147483640">
									<PARAM NAME="BackColorFixed" VALUE="-2147483633">
									<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
									<PARAM NAME="BackColorSel" VALUE="-2147483635">
									<PARAM NAME="ForeColorSel" VALUE="-2147483634">
									<PARAM NAME="BackColorBkg" VALUE="8421504">
									<PARAM NAME="GridColor" VALUE="12632256">
									<PARAM NAME="GridColorFixed" VALUE="0">
									<PARAM NAME="WordWrap" VALUE="0">
									<PARAM NAME="Redraw" VALUE="-1">
									<PARAM NAME="AllowBigSelection" VALUE="-1">
									<PARAM NAME="ScrollTrack" VALUE="0">
									<PARAM NAME="Enabled" VALUE="-1">
									<PARAM NAME="RightToLeft" VALUE="0">
									<PARAM NAME="TextStyle" VALUE="0">
									<PARAM NAME="TextStyleFixed" VALUE="0">
									<PARAM NAME="FocusRect" VALUE="1">
									<PARAM NAME="HighLight" VALUE="1">
									<PARAM NAME="FillStyle" VALUE="0">
									<PARAM NAME="GridLines" VALUE="1">
									<PARAM NAME="GridLinesFixed" VALUE="2">
									<PARAM NAME="ScrollBars" VALUE="3">
									<PARAM NAME="SelectionMode" VALUE="0">
									<PARAM NAME="MergeCells" VALUE="0">
									<PARAM NAME="AllowUserResizing" VALUE="1">
									<PARAM NAME="PictureType" VALUE="0">
									<PARAM NAME="BorderStyle" VALUE="1">
									<PARAM NAME="Appearance" VALUE="1">
									<PARAM NAME="MousePointer" VALUE="0">
									<PARAM NAME="GridLineWidth" VALUE="1">
									<PARAM NAME="FormatString" VALUE="Module id  |<  Issued To  |< Instrument Code  |<  Book Series No  |< Leaf Series No |> Leaves Per Book  |> Book  Start No |> Book End No  |> Leaf  Start No |> Leaf End No |^ Application Date|||">
									<PARAM NAME="OLEDropMode" VALUE="0">
								</OBJECT>
							</td>
						</tr>
					</table>
				</center>
			</div>
			<%

if len(insdtl)> 0 then	
if len(insstr(0))>0 and len(insstr(1))>0 then

	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rsins=server.CreateObject("adodb.recordset")
	
''''' this is for books

set rsins=obj.singlerecordset("GENDEPTCUSTINSTRSTOCKDTLS D," & _
		"GENMODULEMST M,GENUSERMST U","D.MODULEID,D.ISSUEDTO," &_
		"D.INSTRCODE,D.BOOKSERIESNO,D.LEAFSERIESNO,D.LEAVESPERBOOK, " &_
		"D.BOOKSTARTNO,D.BOOKENDNO,D.LEAFNUMBER,D.APPLICATIONDATE," & _
		"M.NARRATION,U.NAME","UPPER(D.MODULEID)=UPPER(M.MODULEID) AND UPPER(D.ISSUEDTO)=UPPER(U.USERID) "& _
		"AND D.branchcode='" & insstr(0) & "' and UPPER(TRIM(INSTRCODE))='" & UCASE(TRIM(insstr(1))) & "' and " & _
		"D.Status='ISSUABLE' and D.TRANSSTATUS='P' and D.bookseriesno IS NOT NULL ", _
		"D.ISSUEDTO,D.BOOKSERIESNO")
		
		
'''' for Leafstno,leafendno calculating

set ObjFetchRec=server.CreateObject("queryrecordsets.fetchrecordsets")
set RecIns=server.CreateObject("adodb.recordset")
Set RecIns = obj.SingleRecordSet("GENDEPTCUSTINSTRSTOCKDTLS D," & _
			"GENMODULEMST M,GENUSERMST U", "D.MODULEID,D.ISSUEDTO," & _
			"D.INSTRCODE,D.LEAFSERIESNO," & _
			"D.LEAFNUMBER,D.APPLICATIONDATE," & _
			"M.NARRATION,U.NAME", "D.MODULEID=M.MODULEID AND D.ISSUEDTO=U.USERID " & _
			"AND upper(trim(D.branchcode))='" & insstr(0) & "' and " & _
			"upper(trim(INSTRCODE))='" & insstr(1) & "' and " & _
			"D.Status='ISSUABLE' and D.TRANSSTATUS='P' and leafseriesno is not null", _
			"D.ISSUEDTO,d.bookseriesno,D.LEAFSERIESNO,D.leafnumber")
 Dim Mode,Lno,lstno,count
 
if rsins.EOF<>true and rsins.BOF<>true then
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	rsins.MoveFirst()
	for count=0 to rsins.RecordCount - 1
		Response.Write "window.document.frminsapp.mfgins.rows=window.document.frminsapp.mfgins.rows +1" & chr(13)
	 for jins=0 to rsins.Fields.Count - 5
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &","& jins &")="&  chr(34) &  rsins(jins) & chr(34)& chr(13)
	 next
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &",10)="&  chr(34) &  rsins(9) & chr(34)& chr(13)
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &",11)="&  chr(34) &  rsins(10) & chr(34)& chr(13)
		Response.Write "window.document.frminsapp.mfgins.textmatrix("& count+1 &",12)="&  chr(34) &  rsins(11) & chr(34)& chr(13)
	rsins.MoveNext()
	next
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if

if RecIns.EOF<>true and RecIns.BOF<>true then
	lstno = 0
	BkStno=""
	BkendNo=""
	lfPerBk=""
	BookSno=""
 Do Until RecIns.EOF
    
    If eval(Mode) <> 1 Then
    
      LeafStNo =  RecIns(0) & "*" & RecIns(1) & "*" _
      
      & RecIns(2) & "*" & BookSno & "*" & RecIns(3) & "*" & LfPerBk & "*" & BkStNo & "*" & BkEndNo & "*" & RecIns(4) & "*" & RecIns(5) & "*" & RecIns(6) & "*" & RecIns(7)
    End If
            
    If cint(RecIns(4)) <> cint(lstno) And eVal(lstno) <> 0 Then
             
    LeafStNo = LeafStNo & "|" & RecIns(0) & "*" & RecIns(1) & "*" _
             
             & RecIns(2) & "*" & BookSno & "*" & RecIns(3) & "*" _
             
             & LfPerBk & "*" & BkStNo & "*" & BkEndNo & "*" & RecIns(4) & "*" _
             
             & RecIns(5) & "*" & RecIns(6) & "*" & RecIns(7)
             
	   LeafEndNo = LeafEndNo & Lno & "|"
                
    End If
      
    Lno = RecIns(4)
    lstno =cint(Lno) + 1
    RecIns.MoveNext
   If RecIns.EOF = True Then
   
        LeafEndNo = LeafEndNo & Lno & "|"
         
    End If
    Mode = 1
   Loop
	StrLeafSt=split(leafstno,"|")
	strleafEd=split(leafEndno,"|")
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	for jCnt=0 to ubound(StrLeafSt)
		leafst=split(StrLeafSt(jCnt),"*")
	if len(leafst(0))>0 and len(leafst(1))>0 then
		
			Response.Write "window.document.frminsapp.mfgins.rows=window.document.frminsapp.mfgins.rows +1" & chr(13)
			
		  for cleaf=0 to 4
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & "," & cleaf & ")="&  chr(34)  &  leafst(cleaf) & chr(34)& chr(13)
		  next
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",5)="&  chr(34)  &  leafst(6) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",6)="&  chr(34)  &  leafst(7) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",8)="&  chr(34)  &  leafst(8) & chr(34)& chr(13)
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & ",9)="&  chr(34)  &  strleafEd(jCnt) & chr(34)& chr(13)
		  for ileaf=10 to 12
			Response.Write "window.document.frminsapp.mfgins.textmatrix(" & count+1 & "," & ileaf & ")="&  chr(34) &  leafst(ileaf-1) & chr(34)& chr(13)
		  next
	end if
		count=count+1
		next
		Response.Write "end sub" & chr(13)
		Response.Write "call show()" & chr(13)
		Response.Write "</script>" & chr(13)

End If	
 
if RecIns.EOF=true and RecIns.BOF=true  and rsins.EOF=true and rsins.BOF=true then
 
	st="^                                                           Description                          "
	str="        No Records Found.    "
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub show()" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.formatstring="& chr(34)& st & chr(34)& chr(13)
	Response.Write "window.document.frminsapp.mfgins.cols=1" & chr(13)	
	Response.Write "window.document.frminsapp.mfgins.rows=2" & chr(13)
	Response.Write "window.document.frminsapp.mfgins.textmatrix(1,0)="& chr(34)& str & chr(34)& chr(13)
	Response.Write "end sub" & chr(13)
	Response.Write "call show()" & chr(13)
	Response.Write "</script>" & chr(13)
end if
end if
end if
		
	

%>
		</form>
	</body>
</html>
