<%@ Page Language="vb" CodeBehind="cacounter.ASPX.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CA_CACounter" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
	var str,str1
	str= window.document.frmacc.hbno.value
	str1= window.document.frmacc.hbno1.value
	str2= window.document.frmacc.hbno2.value
					
	window.attachEvent(window.opener.Allot(str,str1,str2))  
	window.close()
 
}
//-->
</SCRIPT>

<%
	dim rs,obj,obj1,rs1,counterno,counterno1,counterno2,counterno3,counterno4,counterno5,counterno6
	dim cnt
	str=Request.QueryString("st")  	
	k=split(str,"|")  
	'Response.Write str &"<br>"
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")  
  set rs=server.CreateObject("adodb.recordset") 	

	'---------------------- To Get The Status List From GenAccountStatusTypeMst -------------------------------------	  	
if k(0)="Viewstatus" then 				
		set rs=obj.singlerecordset("GenAccountStatusTypeMst","code","")
		set obj=nothing							
		if not rs.BOF and not rs.EOF then
		cnt=rs.RecordCount 
		do until rs.EOF 		
			counterno=counterno & rs(0)& "|"
			rs.MoveNext() 
		loop
		end if
		counterno="Viewstatus" & "|" & cnt & "|" & counterno
elseif k(0)="Modifystatus" then 				
		set rs=obj.singlerecordset("GenAccountStatusTypeMst","code","code<>'C'")
		set obj=nothing							
		if not rs.BOF and not rs.EOF then
		cnt=rs.RecordCount 
		do until rs.EOF 		
			counterno=counterno & rs(0)& "|"
			rs.MoveNext() 
		loop
		end if
		counterno="Modifystatus" & "|" & cnt & "|" & counterno 		 

'---------------------- To Check The Account No ,whether it was already Exists-------------------------------------	  			
elseif trim(k(0))="Getaccountno" then	
		
		set rs=obj.singlerecordset(cstr(k(1)),"accno","branchcode='"& k(2)&"' and" _
		& " upper(currencycode)='"&ucase(k(3))&"' and upper(glcode)='"&ucase(k(4))&"' and accno='"&k(5)&"'")
		set obj=nothing	
	if  rs.BOF and rs.EOF then
		counterno="This Account No Does Not Exists"	
	else
		counterno="ok" & "|" &  rs(0)		
	end if	
	
	rs.Close()
'---------------------- To Check The GL codeo ,whether it is Exists-------------------------------------	  			
elseif trim(k(0))="Getglcode" then	
set rs=server.CreateObject("adodb.recordset")    
  set obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
  	
	set rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))	
		set obj=nothing	
		
	if  rs.BOF and rs.EOF then
		counterno="GLCode Does Not Exists"	
	else
		for inti=1 to rs.recordcount
			if ucase(rs(0))=ucase(k(3)) then
				counterno="getglcode" & "|" &  rs(1)		
			exit for
			else
				rs.movenext()		
				counterno="GLCode Does Not Exists"	
			end if
			
		next
		
	end if		
	rs.Close()	
'---------------------- To Get The Details For Modification-------------------------------------	  
elseif k(0)="Modifyaccount" then
	  dim custid	
'---------------------- To Get The Current Account Master Details-------------------------------------	  
	if k(7)="Modify" then
	  set rs=obj.singlerecordset(cstr(k(1)),"customerid,name,to_char(opdate,'dd-Mon-yyyy'),chequebook,tdsyn,status,TRANSFERFROMBRANCHCODE,FROMACCNO,OPERATINGINSTR,OPERATEDBY,POWEROFATTOR,BANKSTAFFYN,nvl(TYPEOFORG,'99'),to_char(minordob,'DD-Mon-yyyy')"," branchcode='"& k(4)&"' and  currencycode='"&k(5)&"' and glcode='"&k(6)&"' and  accno='"& k(3)&"' and status='R'")	  	  
	elseif  k(7)="Delete" then	
	  set rs=obj.singlerecordset(cstr(k(1)),"customerid,name,to_char(opdate,'dd-Mon-yyyy'),chequebook,tdsyn,status,TRANSFERFROMBRANCHCODE,FROMACCNO,OPERATINGINSTR,OPERATEDBY,POWEROFATTOR,BANKSTAFFYN,TYPEOFORG,to_char(minordob,'DD-Mon-yyyy')"," branchcode='"& k(4)&"'and currencycode='"&k(5)&"' and glcode='"&k(6)&"' and  accno='"& k(3)&"' and status='R'")	    	  
	elseif k(7)="View" then
	  set rs=obj.singlerecordset(cstr(k(1)),"customerid,name,to_char(opdate,'dd-Mon-yyyy'),chequebook,tdsyn,status,TRANSFERFROMBRANCHCODE,FROMACCNO,OPERATINGINSTR,OPERATEDBY,POWEROFATTOR,BANKSTAFFYN,TYPEOFORG,to_char(minordob,'DD-Mon-yyyy')"," branchcode='"& k(4)&"'and currencycode='"&k(5)&"' and glcode='"&k(6)&"' and  accno='"& k(3)&"'")  	  	  
	end if
	 if not rs.eof and not rs.bof then
		set rs1=obj.singlerecordset("genacctcategorymst","narration","categorycode='" & rs(12) & "'")
	 else
		set rs1=obj.singlerecordset("genacctcategorymst","narration","categorycode='xx'")
	 end if
	 org=""
	 if not rs1.eof and not rs1.bof then org=rs1(0)
	if not rs.BOF and not rs.EOF then			
		if not isnull(rs(6)) then		
			set rs1=obj.singlerecordset("genbankbranchmst","narration","branchcode='"& rs(6)&"'")				
			counterno1= org & "**" & rs(0)& "**" & rs(13) &  "|" & rs(1) & "|"& rs(2) & "|" & rs(3) & "|" & rs(4) & "|" & rs(5)& "|" & rs(6) & "|" & rs1(0)& "|" & rs(7) & "|" & rs(8) & "|" & rs(9) & "|" & rs(10) & "|" & rs(11) & "|" & rs(12) & "|" 
			rs1.close()
			set rs1=nothing
		else
			counterno1= org & "**" & rs(0)& "**" & rs(13) & "|" & rs(1) & "|"& rs(2) & "|" & rs(3) & "|" & rs(4) & "|" & rs(5)& "|" & rs(6) & "|" & ""& "|" & "" & "|" & rs(8) & "|" & rs(9) & "|" & rs(10) & "|" & rs(11) & "|" & rs(12) & "|" 
		end if  				
	   custid=rs(0)		  
	end if		
	rs.Close()
	dim jointrec,nomineerec
	
'---------------------- To Get The Joint Holder Details-------------------------------------	
	set rs=obj.singlerecordset("gencustjointholdermst","sno,jhcustomerid,jointholdername," _
	& "to_char(minordob,'dd-Mon-yyyy')","moduleid='"& k(2)&"' and glcode='"&k(6)&"'" _
	& "and accno='"& k(3)&"'  and branchcode='"& k(4)&"' and customerid='"& custid &"'")

	if not rs.BOF and not rs.EOF then	
	jointrec=rs.RecordCount 
	dim i,j,jointno
		
		for j= 1 to rs.RecordCount 
			for i=0 to rs.Fields.Count-1
				jointno=jointno & rs(i) & ","
			next
		jointno=jointno & "|" 
		rs.MoveNext()   
		next	
		jointno=jointno & jointrec 		
	end if	
	rs.close()
'---------------------- To Get The Guardian Details-----------------------------------------	
		
	set rs=obj.singlerecordset("gencustguardianmst","grdcustomerid,guardianname,relation","moduleid='"& k(2)&"'" _
	&"and glcode='"&k(6)&"' and accno='"& k(3)&"' and branchcode='"& k(4)&"' and " _
	&"customerid='"& custid &"'")
	
	if not rs.BOF and not rs.EOF then
		counterno3="|" & rs(0)& "|" & rs(1)& "|" & rs(2)& "|" 
	else
		counterno3= "Null"& "|" & "" & "|" & "" & "|" & "" & "|"				
	end if		
	
	rs.close()	
'---------------------- To Get The NomineeHolder Details-------------------------------------
	set rs=obj.singlerecordset("gencustnomineemst","sno,nomcustomerid,nomineename,relation," _
	&" to_char(minnomineedob,'dd-Mon-yyyy')","moduleid='"& k(2)&"' and " _
	&" glcode='"&k(6)&"' and accno='"& k(3)&"' and branchcode='"& k(4)&"' and" _
	&" customerid='"& custid &"'")
		
	if not rs.BOF and not rs.EOF then
		nomineerec=rs.RecordCount 	
		counterno4=rs(0)& "|" & rs(1)& "|" & rs(2)& "|" & rs(3)& "||" & rs(4)& "|" 
	else		
		counterno4= "Null"& "|" & "" & "|" & "" & "|" & "" & "|" & "" & "|" & "" & "|"	
	end if		
	rs.close()	
'---------------------- To Get The Introducer Details-------------------------------------
	set rs=obj.singlerecordset("gencustintroducermst","intrcustomerid,relation","moduleid='"& k(2)&"'" _
	&"and glcode='"&k(6)&"' and accno='"& k(3)&"' and branchcode='"& k(4)&"'" _
	&" and customerid='"& custid &"'")
	
	if not rs.BOF and not rs.EOF then	
		
	set rs1=obj.singlerecordset("gencustinfomst","custname","branchcode='"& k(4)&"' and " _
	&"customerid='"& rs(0) &"'")
		if not rs1.BOF and not rs1.EOF then		
			counterno5= rs(0)& "|" & rs1(0)& "|" & rs(1) 
		else
			
			counterno5= "" & "|"& "" & "|" & ""
		end if	
	
	rs1.close()		
	else
	counterno5= "" & "|"& "" & "|" & ""	
	
	set rs1=nothing	
	end if	
	
'---------------------- To Get The Organisation Details-------------------------------------
	set rs=obj.singlerecordset("caorganisationdtls","sno,typeoforg,orgname,personname," _
	&"relation,designation","moduleid='"& k(2)&"' and accno='"& k(3)&"'" _
	& "and branchcode='"& k(4)&"'  and glcode='"& k(6)&"'")
	
	if not rs.BOF and not rs.EOF then	
		orgrec=rs.RecordCount 		
	dim orgno
		
		for j= 1 to rs.RecordCount 
			for i=0 to rs.Fields.Count-1
				orgno=orgno & rs(i) & ","
			next
		orgno=orgno & "|" 
		rs.MoveNext()   
		next	
		orgno=orgno & orgrec 	
	else
		orgrec=0		
	end if
	
'---------------------- To Check Whether Any Pending Transactions for This Account-------------------------------------	
	set rs=obj.singlerecordset("CATRANDAY","customerid,accno","branchcode='"& k(4)&"'" _
	&" and currencycode='"& k(5)&"' and glcode='"& k(6)&"' and accno='"& k(3)&"'"_
	&" and transtatus='P' ")
		
	if not rs.BOF and not rs.EOF then			
		counterno6="Delete" & "|" & "This Account Has Some Pending Transactions"	
	else
		counterno6="Delete" & "|" & ""	
	end if				
	rs.close()		
		
	dim curbal,amount,counterno7,strdetails
		
'---------------------- To Get The  Amount from CABALANCE Table -------------------------------------		
	
	set obj1=Server.CreateObject("accountdetails.accdetails")
	'parameters order(branch,currency,module,glcode,accno). It will return balance
	
		strdetails=obj1.accountdetail(cstr(k(4)),cstr(k(5)),cstr(k(2)),cstr(k(6)),cint(k(3)))
		
	set obj1=nothing	
	
		balance=split(strdetails,"|")
		
	if balance(0) <>0 then
		counterno7="This Acount Has Some  Balance:" & ","&  balance(0)		
	else
		counterno7=trim(balance(0))
	end if	
	
'---------------------- To Return All the Data to Client Side -------------------------------------		
	counterno="Modify" & "|" & counterno1 & counterno3  & counterno4 & counterno5 & "|" & jointrec & "|" & nomineerec &"|"& orgrec & "|"& counterno6 & "|"& counterno7  
	
	
	set rs=nothing
	set obj=nothing	
	
	
end if

 
'onLoad='List()'
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" name="hbno" id="hbno" value="<%=counterno%>"><input type="hidden" name="hbno1" id="hbno1" value="<%=jointno%>"><input type="hidden" name="hbno2" id="hbno2" value="<%=orgno%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
