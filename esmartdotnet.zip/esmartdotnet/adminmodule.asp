<%
		
	dim usrid
	dim objfetch
	dim recdtls
	dim vmod
	dim recmod
	vmod=Request.Form("hmod")
	vmodx=split(Request.QueryString("record"),"~")
	if ubound(vmodx)>0 then
		vmod=vmodx(0)
		session("moddir")=vmodx(1)
	end if
	usrid=session("userid")
	
	set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
	set recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir",  _
			"upper(trim(machinename))='" & ucase(session("serverid")) & "'")
		mainstr=trim(recdtls(0)) &"/" & trim(recdtls(1)) &"/" & "~" & mainstr
		session("moduledir")=trim(recdtls(0)) &"/" & trim(recdtls(1)) 
	
	Response.Redirect  "http://" & recdtls(0) & "/" & _
					trim(recdtls(1)) & "/commonmodule.asp"
	

%>

