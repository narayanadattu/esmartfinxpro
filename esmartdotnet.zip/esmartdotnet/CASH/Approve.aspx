<%@ Page Language="vb" CodeBehind="Approve.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Approve" %>
<%
dim strmsg
dim struserid
dim strgroupcode
dim strmodule
dim strval
dim strwhere
dim transarray(0,4)
dim strfldval
dim strtab
dim obj

strval=Request.Form("info")
strval=split(strval,"|")
set obj=server.CreateObject("GeneralTransactions.DBTransactions")

if Request.Form("stat")="approve" then
	strfldval="'A'"
	strmode="U"
else
	strfldval="'D'"
	strmode="D"
end if

if strval(0)="Group" then
	strgroupcode=ucase(strval(1))
	strmodule=ucase(strval(2))
	strtab="gengroupformsmst"
	strwhere="upper(moduleid)='" & strmodule &"' and upper(groupcode)='" & ucase(strgroupcode) &"'"
else
	strtab="Genworkallotmentmst"
	struserid=strval(1)
	strwhere="upper(userid)='" & ucase(struserid) &"'" 
end if

	transarray(0,0)=strmode
	transarray(0,1)=strtab
	transarray(0,2)="Status"
	transarray(0,3)=strfldval
	transarray(0,4)=strwhere
	strmsg=obj.DataTransactions(transarray)
if strval(0)="Group" then
	transarray(0,0)=strmode
	transarray(0,1)="genbankusergroupmst"
	transarray(0,2)="Status"
	transarray(0,3)=strfldval
	transarray(0,4)="groupcode='" & strgroupcode &"'"
	strmsg=obj.DataTransactions(transarray)
end if


	response.Redirect "workallotmentapproval.asp?record=" & strmsg
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
