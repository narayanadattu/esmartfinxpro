<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="List.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.List" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmartBanker</title>
<% Response.CacheControl = "no-cache" %>
<% Response.AddHeader("Pragma", "no-cache") %>
<% Response.Expires = -1 %>
<%
 strType=Request.QueryString("st")
 userid=session("userid")
 brchCd=Request.QueryString("brchCd")
 atype=Request.QueryString("atype")
 Modid=Request.QueryString("Modid")
 status="Y"
%>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
function List()
{
var callerWindowObj = dialogArguments;
var kstr,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
 {
	alert("Select Any Code") 
 }
else
 {
	kstr= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	type="<%=strType%>"
if (type=="Branch")
{
	//window.attachEvent(window.opener.Branchid(kstr))
	callerWindowObj.Branchid(kstr)
	window.close()
}
if (type=="Bruser")
{   
//window.attachEvent(window.opener.Bruser(kstr))
callerWindowObj.Bruser(kstr)
	window.close()
}

else if (type=="Currency")
{
	
	callerWindowObj.Currencyid(kstr)
	window.close()
}	
	else if (type=="BLevel")
{
	window.attachEvent(window.opener.Levelid(kstr))
	window.close()
}
// Suspence Start

else if (type.substring(0,12)=="Categorycode")
{
	window.attachEvent(window.opener.Categoryassign(kstr))
	window.close()
}

// Suspence end
else if (type=="Curr")
{
	//window.attachEvent(window.opener.Currid(kstr))
	callerWindowObj.Currid(kstr)
	window.close()
}
else if (type=="Module")
{
	window.attachEvent(window.opener.Moduleid(kstr))
	window.close()
}
else if (type.substring(0,6)=="Glcode")
{
	window.attachEvent(window.opener.Glcodeid(kstr))
	window.close()
}
else if (type.substring(0,5)=="Accno")
{
	window.attachEvent(window.opener.Accnoid(kstr))
	window.close()
}

else if (type.substring(0,7)=="TransNo")
{
	window.attachEvent(window.opener.TransNoid(kstr))
	window.close()
}
else if (type.substring(0,6)=="CustID")
{
	window.attachEvent(window.opener.Custid(kstr))
	window.close()
}

else if (type.substring(0,11)=="Cashiertype")
{
	window.attachEvent(window.opener.Cashiertype(kstr))
	window.close()
}
///for CashCountermgt for-------------------------------------------------------------
///counterno for inserting 
else if (type.substring(0,11)=="CounterCode")
{
	
	//window.attachEvent(window.opener.CounterId(kstr))
	callerWindowObj.CounterId(kstr)
	window.close()
}

///counterno for querying
else if (type.substring(0,12)=="QryCounterNo")
{
	//window.attachEvent(window.opener.CounterQueryId(kstr))
	callerWindowObj.CounterQueryId(kstr)
	window.close()
}
//for cashierid for querying
else if (type.substring(0,14)=="counterCashier")
{
	//window.attachEvent(window.opener.CashCounterId(kstr))
	callerWindowObj.CashCounterId(kstr)
	window.close()
}
///---------------------------------------------------------------------------------------
else if (type.substring(0,9)=="Cashierid")
{
	window.attachEvent(window.opener.Cashierid(kstr))
	window.close()
}
////------ for cashtransferallotment-----------------------------------------------------
///for cashier ids
else if (type.substring(0,10)=="Cashiermgt")
{
	//window.attachEvent(window.opener.CashierMgtid(kstr))
	callerWindowObj.CashierMgtid(kstr)
	window.close()
}
//for cashierid 
else if (type.substring(0,10)=="Cashiercou")
{
	//window.attachEvent(window.opener.Cashiercd(kstr))
	callerWindowObj.Cashiercd(kstr)
	window.close()
}
///for cashiertype if

else if (type.substring(0,13)=="CashierTypeId")
{
	//window.attachEvent(window.opener.CashierTypeCode(kstr))
	
	callerWindowObj.CashierTypeCode(kstr)
	window.close()
}
///---------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------		
// for CashierwiseReportform----------------------------------------------------------
else if (type.substring(0,13)=="ReportCashier")
{
	//window.attachEvent(window.opener.Cashiercd(kstr))
	callerWindowObj.ReportCashierid(kstr)
	window.close()
}
//----------------------------------------------------------------------------
else if (type.substring(0,11)=="CutsoiledNo")
{
	window.attachEvent(window.opener.CutSoiledid(kstr))
	window.close()
}
else if (type.substring(0,9)=="Allotment")
{
	window.attachEvent(window.opener.Allotmentid(kstr))
	window.close()
}

else if (type.substring(0,8)=="Bankcode")
{
	window.attachEvent(window.opener.Bankid(kstr))
	window.close()
}
////----for cash allotment form-----------------------------------------------------------------
//to get cashierid
else if (type.substring(0,6)=="CashID")
{
	//window.attachEvent(window.opener.Cashierid(kstr))
	 callerWindowObj.Cashierid(kstr)
	window.close()
}

else if (type.substring(0,8)=="DNOMCASH")
{
	//window.attachEvent(window.opener.Cashierid(kstr))
	 callerWindowObj.Cashierid(kstr)
	window.close()
}

////------------------------------------------------------------------------------
else if (type.substring(0,7)=="Cashacc")
{
	//window.attachEvent(window.opener.Cashieracc(kstr))
	 callerWindowObj.Cashieracc(kstr)
	 window.close(); 
	
}
else if ((type.substring(0,9)=="AppUserid") ||(type.substring(0,10)=="AppGroupid") )
{
	window.attachEvent(window.opener.UserCode(kstr))
	window.close()
}
else if (type=="User")
{
	window.attachEvent(window.opener.DisplayGroup(kstr))
	
	window.close()
}

else if (type=="Groups")
{
	window.attachEvent(window.opener.DisplayGroups(kstr))
	
	window.close()
}

else if (type=="Group")
{
		
	window.attachEvent(window.opener.DisplayGroup(kstr))
	
	window.close()
}
else if (type.substring(0,5)=="Query")
{
	window.attachEvent(window.opener.DisplayQuery(kstr))
	
	window.close()
}

else if (type.substring(0,14)=="AllotedCashier")
{
	window.attachEvent(window.opener.AllotedCashierid(kstr))
	window.close()
}
else if (type.substring(0,8)=="cashtype")
{
	window.attachEvent(window.opener.cashtype(kstr))
	window.close()
}
// for Cash refundaccept form ----------------------------------------------------
/// for fetching cashier Id 
else if (type.substring(0,16)=="Cashrefundaccept")
{
	//window.attachEvent(window.opener.Cashiercodeid(kstr))
	callerWindowObj.Cashiercodeid(kstr)
	window.close()
}

///-------------------------------------------------------------------------------
else if (type.substring(0,12)=="Cashrefundno")
{
	window.attachEvent(window.opener.Cashrefundid(kstr))
	window.close()
}
else if (type.substring(0,13)=="Cashcounterno")
{
	window.attachEvent(window.opener.Cashcounterid(kstr))
	window.close()
}
else if (type.substring(0,6)=="Userid")
{
	window.attachEvent(window.opener.UserCode(kstr))
	
	window.close()
}
else if(type.substring(0,11)=="ALLCASHIERS")
{
	
	window.attachEvent(window.opener.Cashiercd(kstr))
	window.close()
}
//---------------PRSREM
else if (type.substring(0,8)=="issonbnk")
{
	window.attachEvent(window.opener.issuedonbnk(kstr))
	window.close()
}
else if (type.substring(0,7)=="issonbr")
{
	window.attachEvent(window.opener.issuedonbr(kstr))
	window.close()
}
else if (type.substring(0,10)=="issonothbr")
{
	window.attachEvent(window.opener.issuedonothbr(kstr))
	window.close()
}
//---------------
   
else if(type.substring(0,12)=="Tellermodule")
		{
		   	window.attachEvent(window.opener.modulecode(kstr))
			window.close()
		}
else if(type.substring(0,12)=="Tellerglcode")
		{
		   	window.attachEvent(window.opener.Glcodeid(kstr))
			window.close()
        }
else if(type=="Tellerbranch")
		{
		    window.attachEvent(window.opener.Branchcode(kstr))
			window.close()
		}
else if(type.substring(0,11)=="Telleraccno")
		{
		    window.attachEvent(window.opener.accountid(kstr))
			window.close()
		}
//-----ServiedId
else if (type=="Service")
{
	window.attachEvent(window.opener.ServiceCode(kstr))
	window.close()
}
//----ServiceId End		
}
}
</SCRIPT>
<%
dim obj,rs
   rs=server.CreateObject("adodb.recordset")
   rs1=server.CreateObject("adodb.recordset")
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
   objbr=server.CreateObject("GeneralTranQueries.TransactionQueries")
  
if strType ="Branch" then
	 rs=obj.singlerecordset("GENBANKBRANCHMST","Branchcode,narration")
	
elseif strType="BLevel" then
	 rs=obj.singlerecordset("GENBANKLEVELMST","code,narration")	
	
elseif strType="Bruser" then	
	 rs=objbr.BranchCodes(cstr(userid))
	
elseif left(strType,6)="Userid" then
   atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genusermst","userid,name","branchcode='" & atype & "'")

elseif strType="Currency" then
	 rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration")
elseif strType="Curr" then
	 rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration,precision")
	
elseif strType="Module" then
     rs=obj.singlerecordset("genmoduletypesmst","moduleid,Narration","implementedyn='Y'")
   
elseif left(strType,6)="Glcode" then
   'stname=left(strType,2)
   'atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genglsheetmst","glcode,NARRATION","moduleid='" & atype & "'")
    
elseif left(strType,5)="Accno" then
    'stname=left(strType,5)
    'atype=mid(strType,6,len(strType))
    dim objTrn
     objTrn=Server.CreateObject("GeneralTranQueries.TransactionQueries")
     rs=objTrn.AccountNumbers(cstr(brchCd),cstr(Modid),cstr(atype))
	 objTrn=nothing 
    
elseif left(strType,6)="CustID" then
    stname=left(strType,4)
    atype=mid(strType,7)
     rs=obj.singlerecordset("GENCUSTINFOMST","customerid,custname","")
	
elseif left(strType,7)="TransNo" then
    stname=left(strType,5)
    atype=mid(strType,8)
     rs=obj.singlerecordset("translog","tranno,amount","glcode='" & atype & "'","tranno")
    
elseif left(strtype,8)="cashtype" then
    kctype=split(strtype,"|")
     rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration", _
    "STATUS='R' and (currencycode='" & kctype(2) & "' and branchcode='" & kctype(1) & "')")
    
elseif left(strType,11)="Cashiertype" then
	stname=left(strType,11)
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHCASHIERTYPEMST","cashiertypeid,narration", _
	"BRANCHCODE='" & k(1) & "'","cashiertypeid")

'''for CashCountermgtform---------------------------------------------------------------
''' fetching counterno from cashcountermst table for isertion or deletion 
elseif left(strType,11)="CounterCode" then
	
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHCOUNTERMST", _
	"COUNTERNO, NARRATION", _
	"BRANCHCODE='" & k(1) & "' and currencycode='" & k(3) &"' and " & _
	"cashierid is null","COUNTERNO")

''' fetching counterno from cashcountermst table for querying
elseif left(strType,12)="QryCounterNo" then
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHCOUNTERMST","COUNTERNO,NARRATION", _
	"BRANCHCODE='" & k(1) & "' and (counterstatus='C' or counterstatus='')  OR " & _
	"CASHIERID='" & K(2) & "' and " & _
	"currencycode='" & k(3) &"'","COUNTERNO")	
elseif left(strType,14)="counterCashier" then
	
	k=split(strType,"*")
	 rs=obj.singlerecordset("GENUSERMST g,CASHCOUNTERMST c","c.CASHIERID,g.Name", _
	"c.BRANCHCODE='" & k(1) & "' and " & _
	"c.currencycode='" & k(2) &"' and g.userid=c.cashierid","c.CASHIERID")
		

elseif left(strType,10)="Cashiercou" then
	k=split(strType,"*")
	stname=strType
	strcond= "u.accountstatus = 'R' AND u.branchcode='" & k(1) &"' and " & _
	"u.groupid=b.groupcode and b.grouptype='CASHIER' and " & _
	"U.USERID  not IN (SELECT nvl(trim(CASHIERID),'n') FROM CASHCOUNTERMST where " & _
			"branchcode='" & k(1) & "' and currencycode='" & k(2) & "')"
	strfld="U.USERID,U.NAME"
	strtab="GENUSERMST U,GENBANKUSERGROUPMST b"
 rs=obj.singlerecordset(cstr(strtab),cstr(strfld),cstr(strcond))
'''for cashiertype id
elseif left(strType,13)="CashierTypeId" then
	k=split(strType,"*")
 rs=obj.singlerecordset("CASHCASHIERTYPEMST b","NARRATION,CASHIERTYPEID", _
				"upper(trim(branchcode))='" & k(1) & "' and " & _
				"upper(trim(currencycode))='" & k(2) & "' AND (branchcode,CASHIERTYPEID)NOT IN (SELECT branchcode,CASHIERTYPEID FROM cashcountermst a WHERE  b.CASHIERTYPEID=a.CASHIERTYPEID)")
	
	

'''------------------------------------------------------------------------------------------		
''''' for CashierwiseReportform----------------------------------------------------------
elseif left(strType,13)="ReportCashier" then
	k=split(strType,"*")
	stname=strType
	
	if session("applicationdate")=k(3) then
	 rs=obj.singlerecordset("CASHALLOTMENTSTRN cash,GENUSERMST u", _
			"distinct cash.cashierid,u.name", _
			"cash.branchcode='" & k(1) & "' and " & _
			"cash.currencycode='" & k(2) & "' and  "& _
			"cash.applicationdate='" & k(3) & "' and " & _
			"cash.cashierid=u.userid and u.branchcode='" & k(1) & "'")
			
		if rs.RecordCount=0 then
			 rs=obj.singlerecordset("CASHALLOTMENTSTRNhist cash,GENUSERMST u", _
			"distinct cash.cashierid,u.name", _
			"cash.branchcode='" & k(1) & "' and " & _
			"cash.currencycode='" & k(2) & "' and  "& _
			"cash.applicationdate='" & k(3) & "' and " & _
			"cash.cashierid=u.userid and u.branchcode='" & k(1) & "'")	
		end if		
	else
	
	 rs=obj.singlerecordset("CASHALLOTMENTSTRNBKP cash,GENUSERMST u", _
			"distinct cash.cashierid,u.name", _
			"cash.branchcode='" & k(1) & "' and " & _
			"cash.currencycode='" & k(2) & "' and  "& _
			"cash.applicationdate='" & k(3) & "' and " & _
			"cash.cashierid=u.userid and u.branchcode='" & k(1) & "'")		
			
	end if		
			
'''-------------------------------------------------------------------------------------	
	

 ' Suspence Start
elseif left(strtype,12)="Categorycode" then 
	k=split(strtype,"|")
	 rs=obj.singlerecordset("SCRCATEGORYMST","DISTINCT CATEGORYCODE,CATEGORYNAME")
' Suspence End   
elseif left(strType,9)="Cashierid" then
	stname=strType
	k=split(strType,"*")
	 rs=obj.singlerecordset("cashcashierposmst cash,genusermst gen","cash.cashierid,gen.name","cash.cashierid=gen.userid and cash.cashierid <> '" & cstr(userid) & "' " )
'''' for cash allotment form--------------------------------------------------------------------
'''for fetching cashier id,name according to branchcode	
elseif left(strType,6)="CashID" then
	k=split(strType,"|")
	 rs=obj.singlerecordset("cashcountermst cash,genusermst gen", _
	" distinct(cash.cashierid),gen.name", _
	" cash.cashierid=gen.userid and " & _
	" upper(trim(cash.cashierid)) <> '" & session("userid") & "' and " & _
	" gen.branchcode='" & k(1) & "'")
'''--------------------------------------------
elseif left(strType,8)="DNOMCASH" then
	k=split(strType,"|")
	 rs=obj.singlerecordset("CASHALLOTMENTSTRN" & k(3) & " A, GENUSERMST U", _
	" DISTINCT A.cashierid,U.NAME", _
	" A.cashierid = U.USERID AND u.branchcode=A.branchcode  " & k(1) & " " & k(2) & "")

'''---------------------------------------------------------------------------------	
elseif left(strType,14)="AllotedCashier" then
	stname=strType
	cash=split(stname,"*")
     rs=obj.singlerecordset("CASHALLOTMENTSTRN CASH,GENUSERMST GEN","DISTINCT(CASH.CASHIERID),GEN.NAME","CASH.CASHIERID=GEN.USERID AND CASH.BRANCHCODE='" & CASH(1) & "' AND CASH.CURRENCYCODE='" & CASH(2) & "'","CASH.CASHIERID")
	
elseif left(strType,9)="Allotment" then

	k=split(strType,"*")
	Response.Write (strtype)
	Response.Write (cstr(userid))
	 rs=obj.singlerecordset("cashallotmentstrn","Allotmentno","cashierid='" & k(1) & "' and counterno = '" & k(2) & "' and status='P'","allotmentno")
	
elseif strtype="Bankcode" then

	 rs=obj.singlerecordset("Genbankmst","Bankname,BANKCODE")
'''-----------------------for cashtransaferallotment form---------------------------
'''for cashier id fetching according to sended branchcode 	
elseif left(strtype,10)="Cashiermgt" then
	k=split(strtype,"*")
	 rs=obj.singlerecordset("cashcountermst cash,genusermst gen", _
		"distinct(cash.cashierid),gen.name", _
		"cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and " & _
		"cash.cashierid=gen.userid and cash.cashierid not in ('" & ucase(userid) & "') and " & _
		"cash.COUNTERSTATUS='O'")
'''----------------------------------------------------------------------------------------------		
'''' for cashrefundaccep form---------------------------------------------
'' for cashier id
elseif left(strtype,16)="Cashrefundaccept" then		
	k=split(strtype,"*")	
	 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen", _
	"distinct(cash.REFUNDEDUSERID),gen.name", _
	"cash.branchcode='" & k(1) & "' and " & _
	"cash.currencycode='" & k(2) & "' and " & _
	"cash.REFUNDEDUSERID=gen.userid  and " & _
	"cash.status='P' and cash.USERID <> '"& session("userid") & "'" )	
	
	'''-----------------------------------------------------------------
'''-----------------------for cashtransaferacceptance form---------------------------
'''for cashier id fetching according to sended branchcode 		
elseif left(strtype,7)="Cashacc" then
	k=split(strtype,"*")
	 rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN cash,genusermst gen", _
			"distinct(cash.fromcashierid),gen.name", _
			"cash.branchcode='" & k(1) & "' and " & _
			"cash.currencycode='" & k(2) & "' and " & _
			"cash.FROMcashierid=gen.userid and " & _
			"cash.status='P' and " & _
			"cash.tocashierid='" & session("userid") & "'", _
			"cash.fromcashierid")
'''------------------------------------------------------------------------------------------	
elseif left(strtype,11)="CutsoiledNo" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("CASHCUTNSPOILNOTESMST","CUTSOILTRANNO,customerid,RECEIVEDFROM","UPPER(TRIM(branchcode))='" & UCASE(TRIM(k(1))) & "' and UPPER(TRIM(currencycode))='" & UCASE(TRIM(k(2))) &"'")

elseif left(strtype,5)="Group" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='A'")
elseif left(strtype,6)="Groups" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","GROUPCODE,NARRATION","STATUS='A'")
elseif left(strtype,4)="User" then
	k=split(strtype,"|")
	 rs=obj.singlerecordset("GENusermst","userid,name","STATUS='A'")
elseif left(strtype,5)="Query" then
	if right(strtype,1)="N" then
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name")
	else
		 rs=obj.singlerecordset("GENUSERMST","Userid,Name","status='P'")
	end if
elseif strType="Groupid" then
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","status='A'")		
elseif left(strType,6)="Userid" then
   atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genusermst","userid,name","branchcode='" & atype & "' and status='A'")
elseif strType="AppGroupid" then
	 rs=obj.singlerecordset("GENBANKUSERGROUPMST","Groupcode,narration","groupcode in(select distinct(Groupcode) from gengroupformsmst where status<>'A')")		
elseif left(strType,9)="AppUserid" then
   atype=mid(strType,7,len(strType))
    rs=obj.singlerecordset("genworkallotmentmst","userid,username","status<>'A'")
elseif left(strtype,11)="ALLCASHIERS" then
	k=split(strType,"|")
	 rs=obj.singlerecordset("cashcountermst cash,genusermst gen","distinct(cash.cashierid), gen.name, cash.counterno "," cash.branchcode='" & k(1) & "' and cash.currencycode='" & k(2) & "' and cash.cashierid=gen.userid"," gen.name")
	
'--------------	
elseif strType="Tellerbranch" then

	 obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	
	 rs=obj.BranchCodes(cstr(session("userid")))
	
elseif left(strType,12)="Tellermodule" then
    
	 obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	
	k=split(strType,"|")
	
	 rs=obj.ModuleID(cstr(k(1)),"N","N")
	
elseif left(strType,11)="Telleraccno" then

	k=split(strType,"|")
	 obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	 rs=obj.AccountNumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)))
	if obj.connerror<>"" then
		kstr="Norecords"
		Errstr=obj.ConnError
	end if	
elseif left(strType,12)="Tellerglcode" then

	 obj=server.CreateObject("GeneralTranQueries.TransactionQueries")
	k=split(strType,"|")
	 rs=obj.GLCodes(cstr(k(1)),cstr(k(2)))
	'------PRSREM
elseif strType="issonbnk" then	
	 rs=obj.singlerecordset("GENOTHERBANKMST","Bankcode,BANKNAME")
elseif strType="issonbr" then	
	 rs=obj.singlerecordset("GENBANKBRANCHMST","BRANCHCODE,BRANCHNAME")		
elseif left(strType,10)="issonothbr" then	
    '  k=atype
	 rs=obj.singlerecordset("GENOTHERBRANCHMST","BRANCHCODE,BRANCHNAME","UPPER(BANKCODE)='" & atype & "'")		
'-----Service Id
elseif strType="Service" then
     rs=obj.singlerecordset("GENSERVICETYPESPMT","CODE,NARRATION",,"CODE")		
end if

%>
</head>
<body>

<form name="frmList">
  <%'''if 1=2 then
  IF  NOT rs.EOF   AND NOT rs.BOF THEN%>
  <center>

  <table class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <%	if len(strType)>8 then%>
    
      <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(stname)%>&nbsp;DESCRIPTION
        - CODE</font></th>
      <%else%>
      <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(strType)%>&nbsp;DESCRIPTION
        - CODE</font></th>
      <%end if%>
    <tr>
      <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	    <% 
	do until rs.EOF
	if rs.Fields.Count = 2 then%>
        <option><%=rs(1).value%>-----<%=rs(0).value%></option>
	    <%elseif rs.Fields.Count=3 then%>
        <option><%=rs(1).value%>-----<%=rs(0).value%>-----<%=rs(2).value%></option>
        <%elseif rs.Fields.Count=4 then%>
        <option><%=rs(1).value%>-----<%=rs(0).value%>-----<%=rs(2).value%>-----<%=rs(3).value%></option>
	    <%end if%>
	    <%
	rs.MoveNext
	loop
	 
	  Response.Write ("<script language=vbscript>")
	  Response.Write ("window.document.frmList.cmbList.item(0).selected=true" & chr(13))
      Response.Write ("</script>") 
     
        %>

      </select></td>
    </tr>
  </table>

  </center><center><input type="button" value="   OK   " name="butmd" onclick="List()" class="button"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="button">
  </center>
  <%else
		Response.Write ("<font color=white size=3><b>No Records Found<b></font>")%>
  <br>
  <br>
  <center><input type="button" value="   OK   " name="butok" onclick="window.close()" class="button"></center>

  <%end if
 '' end if%>

</form>

</body>

</html>
