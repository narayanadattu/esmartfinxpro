<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashrefundacceptinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashrefundacceptinsert" %>
<%
    Dim  ArrTran(0,4)
    dim status
    kstr=Request.Form("hstr")
    status=trim(Request.Form("hStatus"))
    k=split(kstr,"|")	
    userid=session("userid")
    applicationdate=session("applicationdate")
    macid=session("machineid")
    
    if Status="REFUND" then	  
	  Obj = SERVER.CreateObject("cashtransaction.transactions")
	 strmsg=obj.cashrefundacceptance(cstr(k(0)),cstr(k(1)),cstr(session("applicationdate")),cstr(userid),cstr(k(2)),cstr(k(3)),cstr(macid))
	elseif Status="REJECT" then
	
		StrTabName="CASHREFUNDSTRN"
		StrFldNames="status"
		StrUpFldvalues="'R'"
		strCondition="branchcode='" & k(0) & "' and currencycode='" & k(1)& "' and REFUNDNO='" & k(3) & "' and REFUNDEDUSERID='" & k(2) & "'"
		 Obj=SERVER.CreateObject("GeneralTransactions.DBTransactions")
			
			ArrTran(0,0)="U"			'passing the TransactionType
			ArrTran(0,1)=StrTabName		'passing the tablename
			ArrTran(0,2)=StrFldNames	'passing the FieldNames
			ArrTran(0,3)=StrUpFldvalues	'passing the Fieldvalues
			ArrTran(0,4)=strCondition	'passing the Fieldvalues
			Strmsg= Obj.DataTransactions(ArrTran)
					
		
	end if		
	 obj=nothing		
	response.Redirect ("cashrefundaccp.aspx?record="& strmsg)
	'Response.Write (strmsg)
		
	
	
%>
	
	
	
	
	
	
	
	








			





  
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
