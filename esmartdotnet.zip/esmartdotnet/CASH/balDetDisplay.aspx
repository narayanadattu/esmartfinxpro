<%@ Page Language="vb" CodeBehind="balDetDisplay.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.balDetDisplay" %>
<%
Dim strMod,strMand
strMod=Request.QueryString("str")
'Response.Write strMod  
strMand=Split(strMod,"~")
set obj=Server.CreateObject("accountdetails.accdetails")
str=obj.accountdetail(cstr(strMand(0)),cstr(strMand(1)),cstr(strMand(2)),cstr(strMand(3)),cstr(strMand(4)))

%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<SCRIPT LANGUAGE=javascript>
<!--
function init(){
	var str=window.document.frm1.balStr.value;
	window.attachEvent(window.opener.display(str)) 
	window.close(); 

}
//--> 
</SCRIPT>
</head>
<body onload="init()">

<form name="frm1">
  <p><font class="textbold">&nbsp;Please Wait,</font></p>
  <input type="hidden" name="balStr" value="<%=str%>">
</form>

</body>

</html>
