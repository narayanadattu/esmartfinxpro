<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="paylist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.paylist" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CashPaymentInsert.asp				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| N.Hari babu          |    26-APR-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>

<% kstr=Request.QueryString("strPrm")%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var s,rec,fld
  s= window.document.frmpay.hval.value 
  rec=window.document.frmpay.hrec.value
  fld=window.document.frmpay.hflds.value
  kstr=s+"$"+rec+"$"+fld
  //window.attachEvent(window.opener.FlexPop(kstr))  
  window.attachEvent(window.parent.FlexPop(kstr))  
  window.close()
}
//-->
</SCRIPT>    
<%
  vUserid=session("userid")
  for i=1 to 1
   k=split(kstr,"|")
  next
  brcode=k(0)
  Curcode=k(1)
  payType=k(2)
  abbYN=k(3)
  
  fldnms="distinct(T.BATCHNO),T.TRANNO,T.MODULEID,initcap(G.NARRATION)," & _
		 "T.ACCNO,initcap(T.NAME),abs(T.amount),T.tokenno,initcap(S.NARRATION)," & _
		 "decode(T.transtatus,'A','Approved'),initcap(T.REMARKS),initcap(T.USERID)," & _
		 "initcap(T.MACHINEID),G.Glcode,T.serviceid,initcap(M.narration), t.branchcode" & _
		 ",b.branchname"


  if payType="CASH" then
     whrAdd="T.batchno not in(select batchno from CASHTELLERPAYMENTSTRANDAY where UPPER(branchcode)='"& ucase(brcode) & "')" 
              
  elseif payType="TELLER" then
     whrAdd="T.batchno in(select batchno from CASHTELLERPAYMENTSTRANDAY where UPPER(branchcode)='"& ucase(brcode) & "') and " & _
            "upper(T.userid)='" & ucase(vUserid) & "'" 
  end if
  
  if ucase(abbYN)<>"Y" then
	  whrBr="upper(T.branchcode)='"& ucase(brcode) & "' and T.abbbranchcode is null "
  else
	  whrBr="upper(T.abbbranchcode)='"& ucase(brcode) & "'"
  end if
      
  whrExt="T.batchno in (select batchno from gentranslog T where T.transtatus='A' AND UPPER(T.branchcode)='"& ucase(brcode) & "') and " & _
         "T.batchno not in(select T.batchno from gentranslog T where T.transtatus='P' AND UPPER(T.branchcode)='"& ucase(brcode) & "') and " & _
         "upper(T.CURRENCYCODE) ='"&ucase(Curcode)& "' and " & whrBr & _
         " AND T.MODEOFTRAN='1' AND T.MODULEID<>'CASH' AND T.CASHPAIDYN<>'Y'"
  
          
  whrCond= whrBr & " and upper(T.CURRENCYCODE)='"& _
		   ucase(trim(Curcode))& "' and upper(T.branchcode)=upper(P.branchcode(+)) and " & _
           "upper(T.currencycode)=upper(P.currencycode(+)) and " & whrAdd & _
		   " and upper(G.BRANCHCODE)=upper(T.BRANCHCODE) " & _
		   " and upper(G.GLCODE)=upper(T.GLCODE) and " & _
		   " upper(M.moduleid)=upper(T.Moduleid) and " & _
		   " upper(M.branchcode)=upper(T.branchcode) and " & _
		   " upper(S.CODE)=upper(T.SERVICEID) and " & whrExt
    		         
 'if 1=2 then  '1 
   rs=server.CreateObject("adodb.recordset")
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")

  'Original code commented and rewritten by Radhika on 22 may 2008
  'rs=obj.singleRecordSet("GENTRANSLOG T,GENGLSHEETMST G,GENSERVICETYPESPMT S,GENMODULETYPESMST M,CASHTELLERPAYMENTSTRANDAY P",cstr(fldnms),cstr(whrCond),"T.Batchno,T.Tranno")						
  
 whrCond = whrCond & " and t.branchcode = b.branchcode"
  
 rs=obj.singleRecordSet("GENTRANSLOG T,GENGLSHEETMST G,GENSERVICETYPESPMT S,GENMODULETYPESMST M,CASHTELLERPAYMENTSTRANDAY P,GENBANKBRANCHMST B",cstr(fldnms),cstr(whrCond),"T.Batchno,T.Tranno")  
		  if not rs.EOF and not rs.bof then
		     rs.MoveFirst

				do until rs.EOF 
					for i=0 to rs.Fields.Count -  1
						if  isdbnull(rs(i).value)=true then '=""
						  a= a & "Null"
						else
						  a= a & rs(i).value
						end if
						if i<>rs.Fields.Count then
						 a= a & "~"
						end if
					next
				 a=a & "|"
				
				 rs.MoveNext
				loop
				pay=mid(a,1,len(a)-1)
		end if
		rscnt=rs.RecordCount 
		fldcnt=rs.Fields.Count 
		 obj=nothing  
'end if '1
%>
<title></title>
</head>
<body onload="List()">

<form name="frmpay">
  <input type="hidden" name="hval" value="<%=pay%>"><input type="hidden" id="htno" name="hrec" value="<%=rscnt%>"><input type="hidden" id="htno" name="hflds" value="<%=fldcnt%>"><center><font class="textblue">Processing..........</font></center>
</form>
<br>
<br>
<br>
<br>
<%if err.number<>0 then%>
<center><font class="textred">Error No:</font> <font class="textblue"><%=err.number%> -- <%=err.description%>
<p>&nbsp;</font></center>
<%end if
Response.End()%>

</body>

</html>

