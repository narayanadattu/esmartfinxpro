<%@ Page CodeBehind="menu.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.menu" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>New Page 2</title>
<base target="contents">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") &"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;)">

<form name="cashmenu">

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%" colspan="3">

    <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="89%">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="100%" height="28"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
          </tr>
        </table>

        </td>
      </tr>
    </table>

    </td>
  </tr>
  <tr class="bgcolor">
    <%appdate=formatdatetime(session("applicationdate"),1)%>
    
    <p align="center"><font class="text">Cash Master</font></td>
    <td width="33%" height="22" align="right"><font class="textblack"><%=appdate%></font></td>
  </tr>
</table>

</form>

</body>

</html>
