<%@ Page language="vb" aspcompat="true" explicit="false" CodeBehind="cashpaymentdetails.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashpaymentdetails" %>
<%kstr=Request.QueryString("kstr")

'response.write("<br>kstr=" & kstr)

kstr=Split(kstr,"~")
brchCd=trim(kstr(0))
curCd=trim(kstr(2))
trnNo=trim(kstr(4))
currbal=trim(kstr(25)) 'trim(kstr(23))
applDt=session("applicationdate")
userId=session("userid")
counterId=session("Counterno")

str1=brchcd & "~" & curCd & "~" & applDt & "~" & userId & "~" & counterId & "~"

	'Get Scroll number of this cashier to issue 
	dim rsBrParam, objChq, WhrCond, ScrollNo
	
	ScrollNo = 1
	WhrCond="upper(trim(branchcode))='" & ucase(trim(brchCd)) & "'" & _
		" and upper(trim(currencycode))='" & ucase(trim(curCd)) & "'" & _
		" and upper(trim(cashierid))='" & ucase(trim(userId)) & "'"

	rsBrParam=server.CreateObject("adodb.recordset")
	objChq=server.CreateObject("queryrecordsets.fetchrecordsets")
	rsBrParam=objChq.SingleRecordSet("CASHPAYMENTSTRN","NVL(MAX(paymentscrollno),0)", _
	cstr(WhrCond))

	if rsBrParam.eof = false and rsBrParam.bof = false then 
		ScrollNo= iif(isdbnull(rsBrParam(0).value),0,rsBrParam(0).value) 
		ScrollNo = val(ScrollNo) + 1
	else
		ScrollNo=1 
	end if

	rsBrParam = nothing
	objChq = nothing					

'response.write(currbal)
'response.end
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<title>Payments Details</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%'="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript src="trnClear.js"></SCRIPT>
<script language=javascript>
<!--
//------------------------------------------------------------------------------------------
var strDenom,strValues
var strFromTellerPayments
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'
var cashdenomtally 
	cashdenomtally = '<%=session("cashdenomtallyyn")%>'
function Denom(){
	if (window.document.frmTrans.hdnMode.value=="TPAY")
	{
		window.document.frmTrans.all.tpayspan.style.visibility="visible"
		window.document.frmTrans.cmdexit.disabled=true
	}
	else
	{
		window.document.frmTrans.all.tpayspan.style.visibility="hidden"
		window.document.frmTrans.cmdexit.disabled=false
	}
	if (CashDenom=='Y')
	{
		window.document.all.divDenom.style.display="block"
		window.document.all.divDenomtally.style.display="none"
	}
	else if ((CashDenom=='N') && (cashdenomtally== 'Y'))
		{
			window.document.all.divDenomtally.style.display="block"
			window.document.all.divDenom.style.display="none"
		}
	else
	{
		window.document.all.divDenom.style.display="none"
		window.document.all.divDenomtally.style.display="none"
	}

	var kstr="PAY"+"~"+window.document.frmTrans.txtbranchcode.value+"~"+
        window.document.frmTrans.txtcurrencycode.value+"~"+
        "<%=userId%>"+"~"+window.document.frmTrans.hpr.value+"~"
        window.document.all['idenom'].src='<%="http://" & session("moduledir") & "/GEN/"%>'+"cashDenominations.aspx?kstr="+kstr; 
    
}
//------------------------------------------------------------------------------------------	 
//This function was written to form denomination values,no of pieces,available amount,
//exchange amount array values.
 function denomStrForm(){
	var DValStr=""
	var DVal=""
	var DExamtStr=""
	var DExamt=""
	var DTypStr=""
	var DTyp=""
	var DPayamtStr=""
	var DPayamt=""
	var DPayRecAmt=""
	var PayAmt=""
 
     PayAmt="-"+eval(window.document.frmTrans.txtAmt.value)
	
	if(CashDenom=='Y')
	{
     if(PayAmt!=eval(window.document.frames('idenom').frmDenom.txtTotAmt.value)){
        alert("Denominations not Tallied")  
        return 
     } 
 
	//to form denom value string	 
	for(i=1;i<window.document.frames("idenom").frmDenom.mfgDenom.Rows;i++){
	    
		DVal=window.document.frames("idenom").frmDenom.mfgDenom.TextMatrix(i,3)
		DValStr=DValStr+DVal+"~"
			  	
		DTyp=window.document.frames("idenom").frmDenom.mfgDenom.TextMatrix(i,1)
		DTypStr=DTypStr+DTyp+"~";
				
		DPayRecAmt=window.document.frames("idenom").frmDenom.mfgDenom.TextMatrix(i,5)
		DPayamt=window.document.frames("idenom").frmDenom.mfgDenom.TextMatrix(i,4)
				
		if(eval(DPayRecAmt)>=0){
			DPayamtStr=DPayamtStr+DPayamt+"~";
		}   
		else{    
			DPayamt=""
			DPayamtStr=DPayamtStr+DPayamt+"~";
		}
				
		DExamt=window.document.frames("idenom").frmDenom.mfgDenom.TextMatrix(i,4)
		if(eval(DPayRecAmt)<0){
			DExamtStr=DExamtStr+DExamt+"~"
		}   
		else{    
			DExamt=""
			DExamtStr=DExamtStr+DExamt+"~"
		}
				
	}
	}// Denomination if end here.		
	strDenom=DValStr+"|"+DPayamtStr+"|"+DExamtStr+"|"+DTypStr;
	strForm()
	strDenom=strDenom+"|"+strValues	 
	
	window.document.frames['iPay'].CashPayInsrt.hdnPayInsrt.value=strDenom
    window.document.frames['iPay'].CashPayInsrt.action='<%="http://" & session("moduledir")& "/" & session("moddir") & "/"%>'+"CashPaymentInsert.aspx"
    window.document.frames['iPay'].CashPayInsrt.method="post"
    window.document.frames['iPay'].CashPayInsrt.submit()

}
//------------------------------------------------------------------------------------------
function strForm(){
   
     with(window.document.frmTrans){
     strValues=txtbranchcode.value+"~"+txtcurrencycode.value+"~"+txtbatch.value+"~"+
             txtTokenNo.value+"~"+txtScrollNo.value+"~"+txtTrnNo.value+"~"+
             txtModuleId.value+"~"+txtGLCode.value+"~"+txtAccNo.value+"~"+
             txtAmt.value+"~"+txtNarration.value+"~"+hdnMode.value
     }
}
//------------------------------------------------------------------------------------------
/*function Cancel(){
    window.document.frmTrans.txtTokenNo.value=""
    window.document.frmTrans.txtModuleId.value=""
    window.document.frmTrans.txtmoddesc.value=""
    window.document.frmTrans.txtGLCode.value=""
    window.document.frmTrans.txtgldesc.value=""
    window.document.frmTrans.txtAccNo.value=""
    window.document.frmTrans.txtaccnm.value=""
    window.document.frmTrans.txtAmt.value=""
    window.document.frmTrans.txtNarration.value=""
    window.document.frmTrans.txtbatch.value=""
    window.document.frmTrans.txtTrnNo.value=""
    window.document.frmTrans.txtScrollNo.value=""
    window.document.frames("idenom").DenomClear("P")
    
} */
//------------------------------------------------------------------------------------------
function Exit(){
    if(window.document.frmTrans.hdnMode.value=="TPAY"){
         window.close()
    }
    else if(window.document.frmTrans.hdnMode.value=="PAY"){
         location.replace('cashpendingpayments.aspx')
    }

}
//------------------------------------------------------------------------------------------
function PayRslt(vRslt){
  if(vRslt==""){
     return
  } 
  
  if(window.document.frmTrans.hdnMode.value=="PAY"){
     alert(vRslt)
     window.location.replace("cashpendingpayments.aspx")
     return
  }
  if(vRslt.substr(0,17)=="Transaction No : "){
	alert(vRslt)
	window.close()
	window.attachEvent(window.opener.TranRslt(vRslt))

  }
}


function CancelTransaction()
{
strFromTellerPayments=false
 window.document.frmTrans.cmdCancel.disabled=true
 var vals
 vals= window.document.frmTrans.txtbranchcode.value + "|" +
	window.document.frmTrans.txtcurrencycode.value + "|" +
	window.document.frmTrans.txtbatch.value 
	
if(window.document.frmTrans.txtbranchcode.value !=window.document.frmTrans.txtAccBrCd.value)
{  vals = vals + "||Y"  }
else
{  vals = vals + "||N"  }	 
	
	window.document.all['iTrnDel'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"gentransdelete.aspx?vals="+vals
	//window.document.frames['iTrnDel'].frmTrans.hidTeller.value=vals
	  
    //window.document.frames['iTrnDel'].frmTrans.method="post"
    // window.document.frames['iTrnDel'].frmTrans.submit() 
     
     //alert(vals)
     

}



function Result(kstr)
{
	if (kstr.substr(0,11)=="Transaction")
	{
		alert("Transaction is Rolledback. Get the Transaction from TranDtls..")
		window.close()
	}
	else
	{
		alert("Cannot Rolledback the Transaction. Transaction is Deleted")
		window.close()
	}
}


function BackToTellerPayments()
{
	window.document.frmTrans.cmdback.disabled=true
	var vals
	vals= window.document.frmTrans.txtbranchcode.value + "|" +
	window.document.frmTrans.txtcurrencycode.value + "|" +
	window.document.frmTrans.txtbatch.value +"|" + "NOMSG"
	
	if(window.document.frmTrans.txtbranchcode.value !=
	window.document.frmTrans.txtAccBrCd.value)
	{  vals = vals + "|Y"  }
	else
	{  vals = vals + "|N"  }	
	
	strFromTellerPayments=true
	window.document.all['iTrnDel'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"gentransdelete.aspx?vals="+vals
}


function TrnDeleteCash(kstr)
{

 var vals
 vals= window.document.frmTrans.txtbranchcode.value + "|" +
	window.document.frmTrans.txtcurrencycode.value + "|" +
	window.document.frmTrans.txtbatch.value 
	
/// when  back to teller payments clicked
	if (strFromTellerPayments==true)
	{
		if(kstr=="YES")
		{
			window.document.all['iTemp'].src="resetTran.aspx?vals="+vals
		}
		else
			window.document.frmTrans.cmdback.disabled=false
	}
	///////////////// when cancel transction clicked
	else
	{	
		if(kstr=="YES")
			window.close() 
		else
			window.document.frmTrans.cmdCancel.disabled=false
	}
}

//------------------------------------------------------------------------------------------
//-->

</script>

</head>
<body topmargin="0" leftmargin="0" onload="Denom()">

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmTrans">
  <input name="txtavtotal" type="hidden" size="15" value="0.00" style="BACKGROUND-COLOR: #b3a597; COLOR: #ffffff; HEIGHT: 22px; TEXT-ALIGN: right; WIDTH: 101px" align="right" readonly><input type="hidden" name="HidTokenNo" size="9" value="<%=kstr(6)%>" readonly><input name="applDt" type="hidden" size="10" value="<%=kstr(12)%>" readonly>
  <input type="hidden" name="hdnDenomValues">
  <input type="hidden" name="DemonValue">
  <input type="hidden" name="DenomType">
  <input type="hidden" name="PaidAmt">
  <input type="hidden" name="ExchgAmt">
  
  
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tbody>
      <tr>
        <td width="100%" valign="top">
  
  <div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
		
        <div class="menuBar"><%appdate=formatdatetime(session("applicationdate"),1)%>
            <table cellpadding="0" cellspacing="0" width="100%" border="0">
				<tr>
					<td width="23%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="16%" height="22" class="subHeader"><%=vTotNarr%>&nbsp;&nbsp;&nbsp;<span id="spnCashBal" style="VISIBILITY: visible">Curr. Balance : <%=currbal%></span></td>
					<td width="43%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Payments</h2></td>
					<td width="50%" height="22" align="right" class="subHeader"><%=APPDATE%></td>
				</tr>
			</table>
    </div>
     <div id="menucontrol"></div>
  

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="28"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

     

     <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" nowrap height="15">
          <p align="center"></p>
          </td>
        </tr>
      </table>-->
      
     <!--------------------------------------------------------------------->
  

  

       <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="34%" height="25"><font class="textwhite">Curr. Balance : <%=currbal%></font></td>
                <td width="33%" height="25">
                <p align="center"><font class="text">Payments Details</font></td>
                <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>-->

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">
            <div align="center">
              <center>

              <table border="0" width="98%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" colspan="4" height="15">
                  <p align="center">&nbsp;</p>
                  </td>
                </tr>
                <tr class="bgcolor">
                  <td width="15%"><font>&nbsp;&nbsp;&nbsp;&nbsp; Branch
                  Code</font></td>
                  <td width="35%"><input name="txtbranchcode" class="txtautofill" size="9" value="<%=kstr(0)%>" readonly><input type="button" value=" L " name="buttbr" onclick="branch()" class="button" readonly disabled><input name="txtbranchdesc" size="21" value=" <%=kstr(1)%>" readonly class="bgcolor1"></td>
                  <td width="15%" align="right"><font>Currency Code
                  &nbsp;&nbsp;&nbsp;</font></td>
                  <td width="35%"><input name="txtcurrencycode" value="<%=kstr(2)%>" size="9" class="txtautofill" readonly><input type="button" value=" L " name="buttcur" onclick="currency()" class="button" disabled><input name="txtcurrencydesc" size="21" value=" <%=kstr(3)%>" readonly class="bgcolor1"></td>
                </tr>
                <tr>
                 <td width="100%" colspan="4" height="15">
                  <p align="center">&nbsp;</p>
                </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
        </table>

        <div align="center">
          <center>

          <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain" height="380px">
            <tbody>
              <tr>
                <td>
                <div align="center">
                  <center>

                  <table width="100%" cellspacing="0" cellpadding="0">
                    <tbody>
                      <tr>
                        <td width="49%" valign="top">

                      <!--  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="100%" height="8"></td>
                          </tr>
                        </table>-->

                        <div align="center">

                          <table width="96%" cellpadding="0" class="tableborder2" height="378px">
                            <tr>
                              <td>

                              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td width="26%">&nbsp; Token No</td>
                                  <td width="81%"><input name="txtTokenNo" size="12" readonly class="bgcolor4" style="BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-FAMILY: ; FONT-WEIGHT: bold; TEXT-ALIGN: left" value="<%=kstr(11)%>" ></td>
                                </tr>
                                <tr>
                                <td width="26%">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp;Acc Br Cd</td>
                                  <td width="81%"><input name="txtAccBrCd" size="10" value="<%=kstr(20)%>" class="txtautofill" readonly><input type="button" name="B3" value=" L " class="button" readonly disabled><input name="txtAccBrDesc" size="20" readonly value="<%=kstr(21)%>" class="bgcolor1"></td>
                                </tr>                                
                                <tr>
                                  <td width="26%">&nbsp; Module ID</td>
                                  <td width="81%"><input name="txtModuleId" size="10" value="<%=kstr(6)%>" class="txtautofill" readonly><input type="button" name="B3" value=" L " class="button" readonly disabled><input name="txtmoddesc" size="20" readonly value="<%=kstr(19)%>" class="bgcolor1"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Gl Code</td>
                                  <td width="81%"><input name="txtGLCode" size="10" value="<%=kstr(17)%>" class="txtautofill" readonly><input type="button" name="B2" value=" L " class="button" readonly disabled><input name="txtgldesc" size="20" value="<%=kstr(7)%>" readonly class="bgcolor1"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Acct No</td>
                                  <td width="81%"><input name="txtAccNo" size="10" value="<%=kstr(8)%>" class="txtautofill" readonly><input type="button" name="B1" value=" L " class="button" disabled><input name="txtaccnm" size="20" readonly value="<%=kstr(9)%>" class="bgcolor1"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Amount</td>
                                  <td width="81%"><input name="txtAmt" size="14" value="<%=kstr(10)%>" class="txtautofill" readonly style="TEXT-ALIGN: right"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Narration</td>
                                  <td width="81%"><input name="txtNarration" size="37" value="<%=kstr(14)%>" class="txtautofill" readonly></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Batch No</td>
                                  <td width="81%"><input name="txtbatch" size="10" value="<%=kstr(4)%>" class="txtautofill" readonly style="TEXT-ALIGN: right"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Tran No</td>
                                  <td width="81%"><input name="txtTrnNo" size="10" value="<%=kstr(5)%>" class="txtautofill" readonly style="TEXT-ALIGN: right"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp; Scroll No</td>
                                  <td width="81%"><input name="txtScrollNo" size="10" value="<%=ScrollNo%>" class="txtautofill" readonly style="TEXT-ALIGN:right"></td>
                                </tr>
                                <tr>
                                  <td width="26%">&nbsp;</td>
                                  <td width="81%">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width="26%" height="25"></td>
                                  <td width="81%" height="25"></td>
                                </tr>
                              </table>

                              </td>
                            </tr>
                          </table>

                        </div>
                        </td>
                        <td width="67%" valign="top"><!-- -----------------------DENOMINATIONS---------------------------------->
                        <div id="denom" align="center" style="display: block; height: 328; position: absolute; top: 230; width: 395; left: 520;">
                          <div align="center">

                            <table width="94%" cellpadding="0" class="tableborder2" >
                              <tr>
                                <td>
                                <div align="center" id="divDenom" style="background-color:Maroon">
                                  <center>

                                  <table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="Green">
                                    <tbody>
                                      <tr>
                                        <td><iframe id=idenom align=center frameborder=0 framespacing=0 noresize 
                   height=200 width=530 valign="top" src='<%="http://" & session("moduledir")& "/GEN/"&"cashdenominations.aspx"%>' style="BACKGROUND-COLOR: darkred; HEIGHT: 300px; WIDTH: 400px"></iframe> 
										            
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>

                                  </center>
                                </div>
                                    <div id="divDenomtally" style="display: block; height: 16; position: absolute; top: 55; width: 0; left: 30;">
                                  <center>

                                  <table border="0" cellspacing="0" cellpadding="0" bgcolor="Blue">
                                    <tbody>
                                      <tr>
                                        <td>
                                     <IFRAME id="idenomtally" align=center frameborder=0 framespacing=0 border=0 scroll=no marginheight=0 marginwidth=0  height=260 width = 430 noResize        
                                 src='<%="http://" & session("moduledir")& "/GEN/"&"cashdenomtally.aspx"%>'
                                 style="BACKGROUND-COLOR: darkred;LEFT:0px" width=450 valign="top"></IFRAME>
	
									</td>
                                      </tr>
                                    </tbody>
                                  </table>

                                  </center>
                                  </div>
                                
                                <center></center><center></center></td>
                              </tr>
                            </table>

                          </div>
                        </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  </div>
                  <center><center>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%" height="10"></td>
                    </tr>
                    <input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
                  </table>

                  </center></center></center></td>
              </tr>
            </tbody>
          </table>

          </div>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
       <tr>
              <td width="100%" height="10"></td>
            </tr>
            <tr>
              <td width="100%" height="10"></td>
            </tr>
            <tr>
              <td width="100%" height="10"></td>
            </tr>
            <tr>
              <td width="100%" height="10"></td>
            </tr>
            <tr>
              <td width="100%">
              <div align="center">
             <center>
                <table cellspacing="0" cellpadding="0" width="100%">              
                  <tr>
                  <td width="40%"></td>
                    <td width="60%" ><input type="button" name="cmdOk" value="   Ok   " onclick="denomStrForm()" class="button"><input type="button" value="   Exit   " name="cmdexit" onclick="Exit()" class="button"><span id="tpayspan" style="visibility:hidden"><input type="button" name="cmdCancel" value="Cancel Transaction" onclick="CancelTransaction()" class="button"><input type="button" value="Back to Teller Payments" name="cmdback" onclick="BackToTellerPayments()" class="button">
                      </span>
                    </td>                    
                  </tr>
                </table>
</center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" height="10"></td>
            </tr>
          </table>

        </center></td>
      </tr>
    </tbody>
  </table>
<input type="hidden" name="hpr" value="<%=kstr(22)%>">
<input type="hidden" name="hdnMode" value="<%=kstr(23)%>">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iPay" name="iPay" align=center style="display:block"
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="CashPaymentInsert.aspx">
                                              </iframe>
                                              
      </td>
    </tr>
</table>
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="Green">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
        <!--billsonblu.aspx-->
          <td width="100%"><iframe id="ibills" align=center 
          frameBorder=0 frameSpacing=0  height=0 width=0 src="">
          </iframe>
          
          <iframe id="iTrnDel" align=center frameBorder=0 frameSpacing=0  
          height=0 width=0>
          </iframe>
           <iframe id="iTemp" align=center frameBorder=0 frameSpacing=0  
          height=0 width=0>
          </iframe>
          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

