<%@ Page Language="vb" CodeBehind="custaddress.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.custaddress" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<body>

<%          midid=Request.Form("txtmid")
			des1=Request.Form("txtdesc1") 
			gcd=Request.Form("txtgcd")
			des2=Request.Form("txtdesc2")
			ano=Request.Form("txtano")
			des3=Request.Form("txtdesc3")
			cid=Request.Form("txtcid")
	  set rs=server.CreateObject("adodb.recordset")
	  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	  set rs=obj.singlerecordset("GENCUSTINFOMST","CUSTPMTHNO,CUSTPMTSTREET,CUSTPMTTOWN,CUSTPMTDIST","customerid='" & cid &"'")
	  
	  rs.MoveFirst
	  cl1=rs(0)
	  cl2=rs(1)
	  cl3=rs(2)
	  cl4=rs(3)
	  st=midid+"|"+des1+"|"+gcd+"|"+des2+"|"+ano+"|"+des3+"|"+cid+"|"+cl1+"|"+cl2+"|"+cl3+"|"+cl4
     Response.Redirect "accountinfo.asp?star=" & st%>

</body>

</html>
