 <%@ Page Language="vb" CodeBehind="formid.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.formid" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
	<SCRIPT LANGUAGE=javascript>
<!--

function hh()
{
alert("sd")
window.parent.window.document.frames(0).frmmodule.reset()

}
//-->
</SCRIPT>

	<%Dim obj,vark,str,varst,cnt
	     str=Request.Form("hform")
	%>
</head>
<body bgcolor="#c7ba95">

<form name="frmforms">
  <% 

 if len(str)>0 then
      vark=split(str,"|")
    if ubound(vark)>0 then  
    if vark(4)="user" then
					    if vark(0)="delete" then
						    sts=cstr(vark(0))
						    set obj=server.CreateObject("WorkAllotment.Allotment")
						    varst=obj.UserWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						elseif vark(0)="add" then	
							sts=cstr(vark(0))
							set obj=server.CreateObject("WorkAllotment.Allotment")
							varst=obj.UserWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
							
						elseif vark(0)="modify" then
						   sts=cstr(vark(0))
						   set obj=server.CreateObject("WorkAllotment.Allotment")
						   varst=obj.UserWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						elseif vark(0)="query" then
						   sts=cstr(vark(0))
						   set obj=server.CreateObject("WorkAllotment.Allotment")
						   varst=obj.UserWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						end if
	
	elseif vark(4)="group" then
						if vark(0)="add" then	
							sts=cstr(vark(0))
							set obj=server.CreateObject("WorkAllotment.Allotment")
							varst=obj.GroupWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						elseif vark(0)="delete" then
						    sts=cstr(vark(0))
						    set obj=server.CreateObject("WorkAllotment.Allotment")
						    varst=obj.GroupWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						elseif vark(0)="modify" then
						   sts=cstr(vark(0))
						   set obj=server.CreateObject("WorkAllotment.Allotment")
						   varst=obj.GroupWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						elseif vark(0)="query" then
						   sts=cstr(vark(0))
						   set obj=server.CreateObject("WorkAllotment.Allotment")
						   varst=obj.GroupWorkAllotment(cstr(vark(0)),cstr(vark(1)),cstr(vark(2)),cstr(vark(3)))
						   
					   end if	
	   end if
	   end if
  %>

  <table border="0" width="120" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Forms</font></td>
    </tr>
  </table>

  <table>
      <%if vark(0)="modify" then%>
		   <%if ubound(varst)<>0 then%>  
		   
	           <%for icount=0 to ubound(varst)-1%>
			                <%cnt=cnt+1%>
    <tr>
      <td nowrap>
			          <%if varst(icount,1)="Y" then%>
      <input type="checkbox" id="chkup" name="chkup" checked value="<%=varst(icount,0)%>"><font color="black"><%=varst(icount,0)%></font>
			             <%else%>
      <input type="checkbox" id="chkup" name="chkup" value="<%=varst(icount,0)%>"><font color="black"><%=varst(icount,0)%></font>
			          <%end if%>
      </td>
    </tr>
			          
			   <%next%>
			<%else%>
			<%=varst(0,0)%>
			
		<%end if%>
    <%else%>
		<%if ubound(varst)<>0 then%>  
		    <%for icount=0 to ubound(varst)-1 %>
			
		       <%cnt=cnt+1%>
    <tr>
      <td>
				    <%if vark(0)="query" then%>
      <input type="checkbox" id="chkform" name="chkform" disabled value="<%=varst(icount)%>"><font color="black"><%=varst(icount)%></font>
						
				      <%elseif vark(0)="add" then%>
      <input type="checkbox" id="chkadd" name="chkadd" value="<%=varst(icount)%>"><font color="black"><%=varst(icount)%></font>
				      <%elseif vark(0)="delete" then%>
      <input type="checkbox" id="chkdel" name="chkdel" checked value="<%=varst(icount)%>"><font color="black"><%=varst(icount)%></font>
				    <%end  if%>
      </td>
    </tr>
		    <%next%>
		  <%else%>
		   <%=varst(0)%>
	   <%end if%>
	<%end if
	set obj=nothing%>
    <%end if%>

    <input type="hidden" name="hcnt" value="<%=cnt%>"><input type="hidden" name="hform" id="hform"><input type="hidden" name="hstatus" id="hstatus" value="<%=sts%>">
    </form>
  </table>

</body>

