<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="branchdenomequery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.branchdenomequery" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<%Dim obj,st,kstr,rs,a,b,k
	kstr=Request.Form("hden")
	k=split(kstr,"|")
	
	if len(kstr)>0 then
		 obj=server.CreateObject("Cashquery.queries")
		st=obj.CashInEachBranch(cstr(k(1)),cstr(k(2)))
		
    end if%>
    <SCRIPT LANGUAGE=vbscript>
  sub total()
    window.parent.window.document.forms("frmresult").txtvtotal.value=window.document.frmbrquery.hvtot.value
	window.parent.window.document.forms("frmresult").txtctotal.value=window.document.frmbrquery.hctot.value
	window.parent.window.document.forms("frmresult").txtftotal.value=window.document.frmbrquery.hftot.value
	 call precision(window.parent.window.document.forms("frmresult").txtvtotal,window.parent.window.document.forms("frmresult").hpre.value)
	 call precision(window.parent.window.document.forms("frmresult").txtctotal,window.parent.window.document.forms("frmresult").hpre.value)
	 call precision(window.parent.window.document.forms("frmresult").txtftotal,window.parent.window.document.forms("frmresult").hpre.value)
  end sub
</SCRIPT>
<title></title>
</head>
<body>

<form name="frmbrquery">

<script language=vbscript runat=server>
function toPrecision(number)
 	'function for precision calling 
	pr=session("PRECISION")
	dim i,j,k,n,m,v
	if(len(pr)=0) then
		p=2
	else
		p=pr
	end if
	j=0
	k=0
	n=0
	
	dim textvalue
	textvalue=number
	if isdbnull(textvalue)   or mid(textvalue,1,2)="--" then
		toPrecision=number
		exit function
	else
		for i=1 to p-1
			j=j & "0"	 
		next	
		m= "."& j

	end if	
	
	if not isdbnull(textvalue) then
		 dotindex=instr(1,textvalue,".")
		 			
		if dotindex=0 then
			number=textvalue &  m
			toPrecision=number
			exit function
		elseif dotindex>-1 then
			dotafterchars=mid(textvalue,dotindex+1)			
			k=len(dotafterchars)
			
			if k<p then
				t=val(p)-val(k)
				for i=0 to t-2
					n=n & "0"					
				next		
				number =textvalue &  n	 				
				 toPrecision=number
				 exit function
			elseif k=p then
				number=number
			else
				number=number & m
			end if				
		else
			number= mid(textvalue,0,dotindex) & mid(textvalue,dotindex,p+1)			
			 toPrecision=number
			 
			 exit function			
		end if				
		
			
	end if	
		toPrecision=number

end function	
</script>

  <%if len(kstr)>0 then
 
  if len(k(4))>1 then 
   %>
  <%if ubound(st)>0 then
   %>
     
     <%for i=0 to ubound(st)%>
     
        <%if cdbl(st(i,2))>0  or  cdbl(st(i,5))>0 then
        'if st(i,1)<>0 then
        '''precision
        '''& k(3)
         %>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="17%" align="right" height="0">
      <%
      strpres=split(cstr(st(i,0)),".")
      if ubound(strpres)>0 then
      %>
      <%=toPrecision(st(i,0))%>
      <%
      else
      %>
      <%=st(i,0)%>
      <%
      end if
      %>
      </td>
      <td width="17%" align="right" height="0"><%=st(i,1)%></td>
			<%if instr(st(i,2),".")>0 then
					vtot=(vtot)+st(i,2)%>
      <td width="17%" align="right" height="0"><%=toPrecision(cstr(st(i,2)))%> </td>
			<%else%>
      <td width="17%" align="right" height="0"><%= toPrecision(cstr(st(i,2))) %> </td>
			     <%vtot=(vtot)+st(i,2)%>
			 <%end if%>
      <td width="17%" align="right" height="0"><%=st(i,3) %> </td>
			<% if instr(st(i,4),".")>0 then
						ctot=(ctot)+st(i,4)
						%>
      <td width="17%" align="right" height="0"><%=toPrecision(cstr(st(i,4))) %> </td>
			<%else %>
      <td width="17%" align="right" height="0"><%=toPrecision(cstr(st(i,4)))%> </td>
				<%ctot=(ctot)+st(i,4) %>
     	  <% end if%>
			<% if instr(st(i,5),".")>0 then
					ftot=(ftot)+st(i,5)
					%>
      <td width="17%" align="right" height="0"><%= toPrecision(cstr(st(i,5)))%>&nbsp;</td>
			<%else %>
      <td width="17%" align="right" height="0"><%= toPrecision(cstr(st(i,5)))%> </td>
			<% ftot=(ftot)+st(i,5) %>
     
			<%end if%>
    </tr>
    
    <%end if%>
    <% next %>
  </table>

  <input type="hidden" name="hvtot" id="hvtot" value="<%=vtot%>"><input type="hidden" name="hctot" id="hctot" value="<%=ctot%>"><input type="hidden" name="hftot" id="hftot" value="<%=ftot%>">
    <%
      Response.Write ("<script language=vbscript>")
      Response.Write ("call total()")
      Response.Write ("</script>")
    %>
  <%end if%>
   
     <%'=st(0,0)%>
     
     
     
    <%else%>
  <%'-----------------------------------------------------------------%>
   <%
   ''''dummy code
  
   st=obj.CashDenominationsAsarray("CASHVAULTMST",cstr(k(1)),cstr(k(2)),cstr(k(4)))
   %>
      <%if ubound(st)>0 then%>  
     <%for i=0 to ubound(st)%>
     <%crcode=st(i,0)%>
        <%if st(i,1)<>0 then %>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="17%" align="right" height="0"><%=st(i,1)%></td>
      <td width="17%" align="right" height="0"><%=st(i,2)%></td>
		 
		<% 			pr=len(st(i,3))-1
                
                         dec=""	
						if trim(st(i,0))="CP" then
							cal=st(i,3)
							Tot=(cdbl(st(i,1))*cdbl(st(i,2)) /cal)
							k=split(Tot,".",-1)
							
							if ubound(k)>0 then
								
								
								if len(k(1))<pr then
									z=pr- len(k(1))
									 dec1=""
										for j=1 to z
											dec1=dec1 & "0"
										next
										dec=k(1) & dec1
								else
										
										dec=k(1)
							   end if
						   else
								for j=1 to pr
									dec=dec & "0"
								next
								
					       end if
					       Total=k(0) & "." & dec 
					   	   
					  else
					       Tot=cdbl(st(i,1))*cdbl(st(i,2))
					       for j=1 to pr
							dec=dec & "0"
						   next
						   Total=Tot & "." & dec 
					 end if	
				%>	 
		
      <td width="100" align="right"><%=Total%></td>
      <td width="17%" align="right" height="0">&nbsp;</td>
      <td width="17%" align="right" height="0">&nbsp;</td>
      <td width="17%" align="right" height="0">&nbsp;</td>
    </tr>
     <% Amount=cdbl(Amount)+cdbl(Total)%>
    <%end if%>
    <% next %>
   
  </table>

  <input type="hidden" name="hvtot" id="hvtot" value="<%=Amount%>"><input type="hidden" name="hctot" id="hctot" value="<%=ctot%>"><input type="hidden" name="hftot" id="hftot" value="<%=ftot%>">
    <%
      Response.Write ("<script language=vbscript>")
      Response.Write ("call total()")
      Response.Write ("</script>")
    %>
    <%else%>
    <%=st(0,0)%>
  <%end if%>
    <%'------------------------------------------------------------------%>
    <%end if%>    
   
  <%end if%>

  <input type="hidden" name="hden" id="hden">
</form>

</body>

</html>
