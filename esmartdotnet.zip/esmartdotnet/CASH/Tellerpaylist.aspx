<%@ Page Language="vb" CodeBehind="Tellerpaylist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Tellerpaylist" %>
<%
'**********************************************************************************
'*	Name Of the File : CashPaymentInsert.asp				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| N.Hari babu          |    26-APR-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<% str=Request.QueryString("st")%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var s,rec,fld
  s= window.document.frmpay.hval.value 
  rec=window.document.frmpay.hrec.value
  fld=window.document.frmpay.hflds.value
  str=s+"$"+rec+"$"+fld
  window.attachEvent(window.opener.payid(str))  
  window.close()
}
//-->
</SCRIPT>    
<% for i=1 to 1
   k=split(str,"|")
  next
  brcode=k(0)
  Curcode=k(1)
  set rs=server.CreateObject("adodb.recordset")
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
 set rs=obj.singleRecordSet("GENTRANSLOG","Batchno,Tranno,GLcode,Accno,abs(Amount),Narration,MODULEID,applicationdate","CURRENCYCODE ='"&Curcode&"' and branchcode='"&brcode&_
						
						"'AND MODEOFTRAN='1' AND MODULEID<>'CASH' AND CASHPAIDYN<>'Y' AND STATUS='A' AND APPROVEDBY IS NULL")

if not rs.EOF and not rs.bof then
rs.MoveFirst
		do until rs.EOF
			for i=0 to rs.Fields.Count -  1
				if  rs(i)="" then
				  a= a & "Null"
				else
				  a= a & rs(i)
				end if
				if i<>rs.Fields.Count - 1 then
				 a= a & "~"
				end if
			next
		 a=a & "|"
		 rs.MoveNext
		loop
pay=mid(a,1,len(a)-1)
end if
  rscnt=rs.RecordCount 
  fldcnt=rs.Fields.Count
 'set obj=nothing  
 
%>
<title></title>
</head>
<body onload="List()">

<form name="frmpay">
  <input type="hidden" name="hval" value="<%=pay%>"><input type="hidden" id="htno" name="hrec" value="<%=rscnt%>"><input type="hidden" id="htno" name="hflds" value="<%=fldcnt%>"><center><font class="textblue">Processing..........</font></center>
</form>
<br>
<br>
<br>
<br>
<center><font class="textred">Error No:</font> <font size="2" face="verdana" color="blue"><b><%=err.number%> 
 -- <%=err.description%>
<p>&nbsp;</b></font></center>
<%	end if
	Response.End()%>

</body>

</html>
<%	if err.number<>0 then	%>
