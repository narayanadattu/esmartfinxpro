<%@ Page aspcompat="true" explicit="false" CodeBehind="pendingtransactions.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.pendingtransactions" %>
<html>

<%
vBranchCode=session("branchcode")
vCurCode=session("currencycode")
vBrnarration=session("branchnarration")
vCurnarration=session("currencynarration")
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Pending Transactions</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<!--
	function branch()
	{
	window.document.frmcashpendingquery.MsgfTran.Rows=1
	window.document.frmcashpendingquery.MsgfCashier.Rows=1
	window.document.frmcashpendingquery.txtCashierid.value=""
	window.document.frmcashpendingquery.txtCashierName.value=""
	st="Branch"
	window.showModalDialog("list.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:210px;DialogTop:150px")
	
	}
	
	function Branchid(kstr)
	{
		
		var balstr=new String()	
		balstr=kstr.split("-----")
		window.document.frmcashpendingquery.txtbranchcode.value =balstr[1]   
		window.document.frmcashpendingquery.txtbranchdesc.value =balstr[0]
	
	
	}
	
	function currency()
	{
	window.document.frmcashpendingquery.MsgfTran.Rows=1
	window.document.frmcashpendingquery.MsgfCashier.Rows=1
	window.document.frmcashpendingquery.txtCashierid.value=""
	window.document.frmcashpendingquery.txtCashierName.value=""
	
	st="Currency"
	window.showModalDialog("list.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:440px;DialogTop:150px")
	}
	
	function Currencyid(kstr)
	{
	var RowcntTran
	var rowcntCash
	

		var balstr=new String()	
		balstr=kstr.split("-----")
		window.document.frmcashpendingquery.txtcurrencycode.value =balstr[1]   
		window.document.frmcashpendingquery.txtcurrencydesc.value =balstr[0]
		
		
	}
	function NatBranch(){
     with(window.document.frmcashpendingquery)
         {
         
         txtbranchcode.value=strsessionflds[0];
         txtbranchdesc.value=strsessionflds[1];
         txtcurrencycode.value=strsessionflds[2];
         txtcurrencydesc.value=strsessionflds[3];
     
         }
}   

//----------------------------------------------------------------------------------
function PubVariables()
{
     strSessionFld=window.document.frmcashpendingquery.txtSessionflds.value
     strsessionflds=strSessionFld.split("~");
}
	//// sending parameters to cashpendingtransquery based on the option button
	function PendingQuery()
	{
	//GridClear	
	if ((window.document.frmcashpendingquery.txtbranchcode=="")||(window.document.frmcashpendingquery.txtcurrencycode==""))
	{
		alert("Please select Branchcode and Currencycode.")
		
		
		return
	}
	
	
	window.document.frmcashpendingquery.MsgfTran.Rows=1
	window.document.frmcashpendingquery.MsgfCashier.Rows=1
	window.document.frmcashpendingquery.txtCashierid.value=""
	window.document.frmcashpendingquery.txtCashierName.value=""
	s1=window.document.frmcashpendingquery.txtbranchcode.value  //BranchCode
	s2=window.document.frmcashpendingquery.txtcurrencycode.value //CurrencyCode
	s3="GENERAL"
	if (window.document.frmcashpendingquery.RadPending(0).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"ACCEPTANCE|"+s3
	}
	else if (window.document.frmcashpendingquery.RadPending(1).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"TRANSFER|"+s3
	}
	else if (window.document.frmcashpendingquery.RadPending(2).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"REFUND|"+s3
	
	}
	////alert (strPending)
	//window.open("CashPendingTransQuery.aspx"+"?"+"st="+strPending,"hell","width=10%,height=10%")
	window.document.all["iBatch"].src="CashPendingTransQuery.aspx?st="+strPending 
	//window.open("CashPendingTransQuery.aspx"+"?"+"strPending="+StrPending,"Branch","width=150%,height=150%")
	//window.open("CashPendingTransQuery.aspx"+"?"+"strPending="+StrPending,"Pendingtransactions","width=150%,height=150%")
	//alert("helllo")
	//window.open("CashPendingTransQuery.aspx" + "?"+"strPending="+strPending,"Pendingtransactions","width=150%,height=150%")
	}
	
	function TransPending(strpend)
	{
	var jcount
	var Colcount
	var Rowcount
	var strpendval
	var cntRow
	var Rowval
	
	////alert(strpend)
	cntRow=strpend.split("~")
	//alert(cntRow[1])
	
	
	
	
	if((cntRow[0]=="Error")||(cntRow[0]=="No Records"))
	{
		GridClear
		alert (cntRow[0])
	//window.document.frmcashpendingquery.MsgfTran.Rows=1
	//window.document.frmcashpendingquery.MsgfCashier.Rows=1
	}
	else
	{
	if (cntRow[2]=="GENERAL")
	{
	//window.document.frmcashpendingquery.MsgfCashier.Rows=2
	//window.document.frmcashpendingquery.MsgfCashier.FormatString="^ Sl No   |^Pending Transaction No    |^Transaction Amount       "
	//GridClear
	//alert("hello")
	Rowval=cntRow[0].split("|")
	//alert(cntRow[1])
	Rowcount=0
	Rowcount=cntRow[1]
	//alert(Rowcount)
	//alert(window.document.frmcashpendingquery.MsgfTran.Rows)
			//window.document.frmcashpendingquery.MsgfTran.Rows=1
			window.document.frmcashpendingquery.MsgfTran.Rows=eval(Rowcount)+1
		
		for(jcount=0;jcount<Rowcount;jcount++)
		{
		
		strpendval=Rowval[jcount].split(",")
		
		
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,0)=jcount+1
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,1)=strpendval[0]
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,2)=strpendval[3]
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,3)=strpendval[1]
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,4)=strpendval[2]
		window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,5)=strpendval[4]
		
		}
	}
	else if (cntRow[2]=="CASHIER")
	{
	//// code from 
	//alert (strpend)
	Rowval=cntRow[0].split("|")
	//alert(cntRow[1])
	Rowcount=cntRow[1]
			window.document.frmcashpendingquery.MsgfCashier.Rows=eval(Rowcount)+1
		for(jcount=0;jcount<Rowcount;jcount++)
		{
		
		strpendval=Rowval[jcount].split(",")
		
		
		window.document.frmcashpendingquery.MsgfCashier.TextMatrix(jcount+1,0)=jcount+1
		window.document.frmcashpendingquery.MsgfCashier.TextMatrix(jcount+1,1)=strpendval[1]
		window.document.frmcashpendingquery.MsgfCashier.TextMatrix(jcount+1,2)=ToIndianCurencyFormat(strpendval[2],2)
		//window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,3)=strpendval[1]
		//window.document.frmcashpendingquery.MsgfTran.TextMatrix(jcount+1,4)=strpendval[2]
		
		}
	
	}
	}
	}
	//st="Branch"
	//window.open("list.aspx" + "?"+"st="+st,"Branch","width=150%,height=150%")
	
//-->
</SCRIPT>




<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function MsgfTran_Click() {
var GridCol
var GridRow
var RowCheck
GridCol=window.document.frmcashpendingquery.MsgfTran.Col
GridRow=window.document.frmcashpendingquery.MsgfTran.Row
//alert (window.document.frmcashpendingquery.MsgfTran.Text)

////checking if the column of the grid is cashierid
if (window.document.frmcashpendingquery.MsgfTran.Rows>1)
{

	window.document.frmcashpendingquery.txtCashierid.value=window.document.frmcashpendingquery.MsgfTran.TextMatrix(GridRow,1)
	window.document.frmcashpendingquery.txtCashierName.value=window.document.frmcashpendingquery.MsgfTran.TextMatrix(GridRow,2)
	window.document.frmcashpendingquery.MsgfCashier.Rows=1
	//var rowcntCash
	//rowcntCash=window.document.frmcashpendingquery.MsgfCashier.Rows
	//window.document.frmcashpendingquery.MsgfCashier.Rows=window.document.frmcashpendingquery.MsgfCashier.Rows-(rowcntCash-1)
	//window.document.frmcashpendingquery.MsgfCashier.Rows=window.document.frmcashpendingquery.MsgfCashier.Rows+1
	
	s1=window.document.frmcashpendingquery.txtbranchcode.value  //BranchCode
	s2=window.document.frmcashpendingquery.txtcurrencycode.value //CurrencyCode
	s3="CASHIER"////storing the cashierid
	cashier=window.document.frmcashpendingquery.MsgfTran.TextMatrix(GridRow,1)
	if (window.document.frmcashpendingquery.RadPending(0).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"ACCEPTANCE|"+s3+"|"+cashier
	}
	else if (window.document.frmcashpendingquery.RadPending(1).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"TRANSFER|"+s3+"|"+cashier
	}
	else if (window.document.frmcashpendingquery.RadPending(2).checked==true)
	{
	strPending=s1+"|"+s2+"|"+"REFUND|"+s3+"|"+cashier
	}
	window.document.all["iBatch"].src="CashPendingTransQuery.aspx?st="+strPending 
	//window.open("CashPendingTransQuery.aspx" + "?"+"st="+strPending,"Pendingtransactions","width=150%,height=150%")
	
}

}

function GridClear()
{
	window.document.frmcashpendingquery.MsgfTran.Rows=1
	window.document.frmcashpendingquery.MsgfCashier.Rows=1
	
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=MsgfTran EVENT=Click>
<!--
 MsgfTran_Click()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();NatBranch()">

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmcashpendingquery">
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>Pending Cash Transactions</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>

  <input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">

  <table border="0" width="780" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <td width="100%">

      <table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="28"><img name="placeholder" border="0" src="file:///D:/prashanti/Newversion3.0/newhtmlfiles/dscript42/transparent.gif" width="1" height="22"></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  

  <table border="0" width="100%" height="65%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <p align="center"></td>
    </tr>
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="12%" align="right">&nbsp;Branch Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td width="30%"><input name="txtbranchcode" size="9" class="txtautofill" style="TEXT-ALIGN: right" readonly disabled><input type="button" class="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" readonly class="bgcolor1"></td>
            
            <td align="right" width="15%">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td align="left" width="30%"><input name="txtcurrencycode" class="txtautofill" size="9" readonly disabled>
            <input type="button" class="button" value=" L " id="butcur" name="butcur" onclick="currency()">
            <input name="txtcurrencydesc" size="16" readonly class="bgcolor1"></td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td width="10%></td>
            <td width="28%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="V1" name="RadPending" onclick="PendingQuery()">Acceptance</td>
            <td width="27%" |>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="V1" name="RadPending" onclick="PendingQuery()">Transfer</td>
            <td width="38%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="V1" name="RadPending" onclick="PendingQuery()">Refund</td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4" align="middle">
            <p align="center">
            <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="125" id="MsgfTran" name="MsgfTran" style="HEIGHT: 125px; LEFT: 94px; TOP: 0px; WIDTH: 666px" width="666" viewastext>
              <param name="_ExtentX" value="15293">
              <param name="_ExtentY" value="3307">
              <param name="_Version" value="393216">
              <param name="Rows" value="1">
              <param name="Cols" value="5">
              <param name="FixedRows" value="1">
              <param name="FixedCols" value="1">
              <param name="RowHeightMin" value="0">
              <param name="BackColor" value="-2147483643">
              <param name="ForeColor" value="-2147483640">
              <param name="BackColorFixed" value="-2147483633">
              <param name="ForeColorFixed" value="-2147483630">
              <param name="BackColorSel" value="-2147483635">
              <param name="ForeColorSel" value="-2147483634">
              <param name="BackColorBkg" value="8421504">
              <param name="GridColor" value="12632256">
              <param name="GridColorFixed" value="0">
              <param name="WordWrap" value="0">
              <param name="Redraw" value="-1">
              <param name="AllowBigSelection" value="-1">
              <param name="ScrollTrack" value="0">
              <param name="Enabled" value="-1">
              <param name="RightToLeft" value="0">
              <param name="TextStyle" value="0">
              <param name="TextStyleFixed" value="0">
              <param name="FocusRect" value="1">
              <param name="HighLight" value="1">
              <param name="FillStyle" value="0">
              <param name="GridLines" value="1">
              <param name="GridLinesFixed" value="2">
              <param name="ScrollBars" value="3">
              <param name="SelectionMode" value="0">
              <param name="MergeCells" value="0">
              <param name="AllowUserResizing" value="0">
              <param name="PictureType" value="0">
              <param name="BorderStyle" value="1">
              <param name="Appearance" value="1">
              <param name="MousePointer" value="0">
              <param name="GridLineWidth" value="1">
              <param name="FormatString" value="<Sl.No|<Cashier ID              |<Name                                            |<Counter No. |<Trans. Pending     |<Status">
              <param name="OLEDropMode" value="0">
            </object>
            </p>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="41%" colspan="0" height="10" align="right">Cashier&nbsp;&nbsp;</td>
            <td width="38%" colspan="3" height="10" align="left">
            <p align="left"><input name="txtCashierid" disabled size="20"><input name="txtCashierName" disabled size="20"></p>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4" align="middle">
            <p align="center">
            <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="150" id="MsgfCashier" name="MsgfCashier" style="HEIGHT: 125px; LEFT: 183px; TOP: 0px; WIDTH: 370px" width="370" viewastext>
              <param name="_ExtentX" value="10292">
              <param name="_ExtentY" value="3307">
              <param name="_Version" value="393216">
              <param name="Rows" value="2">
              <param name="Cols" value="3">
              <param name="FixedRows" value="1">
              <param name="FixedCols" value="1">
              <param name="RowHeightMin" value="0">
              <param name="BackColor" value="-2147483643">
              <param name="ForeColor" value="-2147483640">
              <param name="BackColorFixed" value="-2147483633">
              <param name="ForeColorFixed" value="-2147483630">
              <param name="BackColorSel" value="-2147483635">
              <param name="ForeColorSel" value="-2147483634">
              <param name="BackColorBkg" value="8421504">
              <param name="GridColor" value="12632256">
              <param name="GridColorFixed" value="0">
              <param name="WordWrap" value="0">
              <param name="Redraw" value="-1">
              <param name="AllowBigSelection" value="1">
              <param name="ScrollTrack" value="0">
              <param name="Enabled" value="-1">
              <param name="RightToLeft" value="0">
              <param name="TextStyle" value="0">
              <param name="TextStyleFixed" value="0">
              <param name="FocusRect" value="1">
              <param name="HighLight" value="1">
              <param name="FillStyle" value="0">
              <param name="GridLines" value="1">
              <param name="GridLinesFixed" value="2">
              <param name="ScrollBars" value="2">
              <param name="SelectionMode" value="0">
              <param name="MergeCells" value="0">
              <param name="AllowUserResizing" value="0">
              <param name="PictureType" value="0">
              <param name="BorderStyle" value="1">
              <param name="Appearance" value="1">
              <param name="MousePointer" value="0">
              <param name="GridLineWidth" value="1">
              <param name="FormatString" value="^ Sl No   |^Pending Transaction No    |^Transaction Amount       ">
              <param name="OLEDropMode" value="0">
            </object>
            </p>
            </td>
          </tr>
          <tr>
            <td width="100%" colspan="4" height="10"></td>
          </tr>
          <tr>
            <td width="100%" colspan="4">
            <p align="center"></td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
    <tr>
      <td width="100%" height="10"></td>
    </tr>
  </table>

  <div align="center">
    <center>

    <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
      <tr>
        <td width="100%"><input type="button" class="button"  value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.aspx&quot;)" ></td>
      </tr>
    </table>

    </center>
  </div>
  <input type="hidden" name="txtSessionflds" value="<%=vBranchCode & "~" & vBrnarration & "~" & vCurCode & "~" & vCurnarration & "~"%>">
  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="CashPendingTransQuery.aspx">
                                              </iframe>
      </td>
    </tr>
 
 </table>
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</form>

</body>

</html>
