<%@ Page aspcompat="true" explicit="false" CodeBehind="denominationwise.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.denominationwise" %>
<html>

<%
dim vUserid,vCounterNo,vAppdate,vCashierid,vCurCode,vCurnarration
vUserid=session("userid")
vCounterNo=session("Counterno")
vAppdate=session("applicationdate")
vCashierid=session("userid")
vBranchCode=session("branchcode")
'vCurCode=session("currencycode")
vBrnarration=session("branchnarration")
'vCurnarration=session("currencynarration")
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>New Page 1</title>

<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
var strSessionFld,strsessionflds
<!--

	function branch()
	 {
	   st="Branch"
	   window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	   window.document.all['ibranch'].src="branchdenomequery.aspx"
	   window.document.frmresult.txtctotal.value=""
	   window.document.frmresult.txtftotal.value=""
	   window.document.frmresult.txtvtotal.value=""
	 }
	 

	function currency()
	 {  
		st="Curr"
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
		window.document.all['ibranch'].src="branchdenomequery.aspx"
		window.document.frmresult.txtctotal.value=""
	   window.document.frmresult.txtftotal.value=""
	   window.document.frmresult.txtvtotal.value=""
	 }
	 

	function Branchid(kstr)
	 { 
//alert(kstr)
	 br=kstr.split("-----")
	 window.document.frmresult.txtbranchdesc.value =br[0]
	 window.document.frmresult.txtbranchcode.value =br[1]
	 // assign(kstr,window.document.frmresult.txtbranchdesc,window.document.frmresult.txtbranchcode)
  //window.document.frmresult.txtcurdate.value=""
	 } 

   //function Currencyid(kstr)
	// {
	//	assign(kstr,window.document.frmresult.txtcurrencydesc,window.document.frmresult.txtcurrencycode)
		
		//window.document.frmdata.txttotal.value=""
	// } 	 

function Currid(kstr)
{
curid=kstr.split("-----")

		window.document.frmresult.txtcurrencycode.value=curid[1]
		window.document.frmresult.txtcurrencydesc.value =curid[0]
		prn=curid[2].length-1
  window.document.frmresult.hpre.value=prn
  p=""
  for(f=1;f<=prn;f++)
  {
    p=p + "0"
  }
  pres= "." + p 
  window.document.frmresult.hpre.value=pres
 //window.document.frmresult.txtcurdate.value=""
}


function brquery()
{
if(window.document.frmresult.txtbranchcode.value=="")
{
  alert('Branch Code should not be null')
  return
}
if(window.document.frmresult.txtcurrencycode.value=="")
{
  alert('Currency Code should not be null')
  return
}
  t="frmresult"
  var brcode=window.document.frmresult.txtbranchcode.value 
 var crcode=window.document.frmresult.txtcurrencycode.value 
  pr=window.document.frmresult.hpre.value 
  curdt="<%=session("applicationdate")%>"
 
  
  st=t + "|"  + brcode + "|" + crcode + "|" + pr + "|" + curdt 

  window.document.frames(0).frmbrquery.hden.value=st
  window.document.frames(0).frmbrquery.action="branchdenomequery.aspx"
  window.document.frames(0).frmbrquery.method="post"
  window.document.frames(0).frmbrquery.submit() 
 
 
 
  
}


//----------------------------------------------------------------------------------
function NatBranch(){
     with(window.document.frmresult)
        {
//          alert(strsessionflds[6])
          txtbranchcode.value=strsessionflds[4]
          txtbranchdesc.value=strsessionflds[5]
          txtcurrencycode.value=strsessionflds[6]
          txtcurrencydesc.value=strsessionflds[7]
          
        }
}   
function PubVariables()
{
     strSessionFld=window.document.frmresult.txtSessionflds.value   
     strsessionflds=strSessionFld.split("~");
     //window.document.frmresult.dtpapplDate.Value="<%=session("applicationdate")%>"
}
 ///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {
 
	//for cashier description 
if(strTxt=="txtbranchcode")
{
if(window.document.frmresult.txtbranchcode.value=="")
{
return;
}

sBr=window.document.frmresult.txtbranchcode.value.toUpperCase()
st="GENBANKBRANCHMST"+"~"+"BRANCHNAME"+
	"~"+"branchcode='"+sBr+"'"+
	"~"+strTxt+"~"+"DescDisplay"
}
	//for cashier description 
if(strTxt=="txtcurrencycode")
{
sCur=window.document.frmresult.txtcurrencycode.value.toUpperCase()
if(window.document.frmresult.txtbranchcode.value=="")
{
alert("Select BranchCode")
return;
}

if(window.document.frmresult.txtcurrencycode.value=="")
{
return;
}
sBr=window.document.frmresult.txtbranchcode.value.toUpperCase()
st="GENCURRENCYTYPEMST"+"~"+"narration"+
	"~"+"currencycode='"+sCur+"'"+
	"~"+strTxt+"~"+"DescDisplay"
}
//post to ifrmae page to get desciptions
		window.document.frames(2).frmacc.hFlds.value=st
		window.document.frames(2).frmacc.action="counter.aspx"
		window.document.frames(2).frmacc.method="post"
		window.document.frames(2).frmacc.submit();
 }
 ///displaying the counterno
function Allot(kstr)
{

	var StrMainFld=new String()
	StrMainFld=kstr.split("~")
	StrFlds=StrMainFld[0].split("|")
	
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtbranchcode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid BranchCode ")
			window.document.frmresult.txtbranchcode.value=""
			window.document.frmresult.txtbranchdesc.value=""
			return;
		}
		window.document.frmresult.txtbranchdesc.value=StrFlds[0]
		
		
	}
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtcurrencycode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid CurrencyCode ")
			window.document.frmresult.txtcurrencycode.value=""
			window.document.frmresult.txtcurrencydesc.value=""
			return;
		}
		window.document.frmresult.txtcurrencydesc.value=StrFlds[0]
		
		
	}
}
///function for checking the login user is abb or not 
function abbcheck()
	{
		
		AbbStatus="<%=session("abbuser")%>"
		
		if(AbbStatus.toUpperCase()=="Y")
		{
		window.document.frmresult.buttbr.disabled=false
		window.document.frmresult.txtbranchcode.readOnly=false
		window.document.frmresult.buttbr.focus()
		}
		else
		{
		window.document.frmresult.buttbr.disabled=true
		window.document.frmresult.txtbranchcode.readOnly=true
		
		}
		
		
	}
//-->

</script>



</head>

<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();abbcheck();brquery()">

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmresult">

  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="588" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" valign="top" height="28">
          <p align="center">&nbsp;&nbsp;</p>
          </td>
        </tr>
      </table>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="34%" height="25"></td>
              <td width="33%" height="25">
              <p align="center"><font class="text">Cash Queries</font></td>
              <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
            </tr>
            <tr>
              <td width="100%" colspan="3" height="15">
              <p align="center"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="21%"><font class="textbold">&nbsp;Branch Code</font></td>
            <td width="43%"><input style="TEXT-ALIGN: right" 
            name="txtbranchcode" class=bgcolor2 size="7" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"  value="<%=session("branchcode")%>" 
            onblur='DescrptionDisp("txtbranchcode")'><input 
            type="button" value=" L " name="buttbr" onclick="branch()"><input 
            name="txtbranchdesc" size="18" value= "<%=session("branchnarration")%>"readonly class="bgcolor1"></td>
            <td width="52%" align="right"><font class="textbold">Currency Code</font></td>
            <td width="32%" align="right"><input name="txtcurrencycode" class=bgcolor2 style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left"
            size="9" value="<%=session("currencycode")%>" onblur='DescrptionDisp("txtcurrencycode")'><input type="button" 
            value=" L " name="buttcr" onclick="currency()"><input 
            name="txtcurrencydesc" size="16" readonly class="bgcolor1" value="<%=session("currencynarration")%>"></td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
              <tr>
                <td width="100%" height="10">
                <div align="center">
                  <center>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="80">&nbsp;<td width="52"></td><!--<font size="2" face="MS Sans Serif">Date</font></td>
                      <td width="86"><font size="2" face="MS Sans Serif"><input 
                      type="text" name="txtcurdate" class=bgcolor1 
                      readonly size="11" value="<%=session("applicationdate")%>"></font></td>
                      <td width="52"><font size="2" face="MS Sans Serif">
                      <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=23 id=dtpapplDate 
	name=dtpapplDate style="HEIGHT: 23px; LEFT: 0px; TOP: 0px; WIDTH: 28px" width=28>
	<PARAM NAME="_ExtentX" VALUE="741">
	<PARAM NAME="_ExtentY" VALUE="609">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>

                      

                      
                      </font></td>-->
                      <td width="510"><input type="button" value="Refresh" name="B3" onclick="brquery()" ></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
            </table>

            <div align="center">
              <center>

              <table border="0" width="86%" cellspacing="0" cellpadding="0">
                <tr>
                  <td>
                  <div align="center">
                    <center>

                    <table width="100%" cellpadding="0" class="tableborder2">
                      <tr>
                        <td>
                        <div align="center">
                          <center>

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tbody>
                              <tr class="bgcolor">
                                <td width="19%" align="right">
                                <p align="center"><font class="textwhite">Denom<br>
                                &nbsp;Value&nbsp;&nbsp;</p>
                                </font></td>
                                </font>
                                <td width="16%" align="right">
                                <p align="center"><font class="textwhite">No.of pieces<br>
                                &nbsp;in Vault&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                                </font></td>
                                <td width="16%" align="middle">
                                <p align="center"><font class="textwhite">Amount</p>
                                </font></td>
                              </center><center></center><center></center>
                              <td width="18%" align="middle">
                              <p align="left"><font class="textwhite">No.of pieces with
                              Cashier</p>
                              </font></td>
                              <center><center><center>
                              <td width="14%" align="middle">
                              <p align="center"><font class="textwhite">Amount</p>
                              </font></td>
                              </center></center></center>
                              <td width="17%" align="middle">
                              <p align="left"><font class="textwhite">Total Amt</p>
                              </font></td>
                            </tr>
                          </table>

                        </div>
                        <center><center>

                        <table border="0" width="70%" cellspacing="0" cellpadding="0" bordercolor="#7d5445">
                          <tr>
                            <td width="100%">
                            <td width="100%">
                            <td><iframe  align=center             
                  frameborder=0 framespacing=0 noresize id="ibranch"
                              
                       height=270 width=630 
                              valign="top" src="branchdenomequery.aspx" 
                              style="BACKGROUND-COLOR: darkred"></iframe></td>
                          </tr>
                        </table>

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="26%" height="10"></td>
                            <td width="8%" align="middle" height="10"></td>
                            <td width="16%" height="10"></td>
                            <td width="16%" height="10"></td>
                            <td width="16%" height="10"></td>
                            <td width="19%" height="10"></td>
                          </tr>
                          <tr>
                            <td width="26%" height="15"></td>
                            <td width="8%" align="middle" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="19%" height="15"></td>
                          </tr>
                          <tr>
                            <td width="26%"></td>
                            <td width="8%" align="middle"><font class="textred">Total</font></td>
                            <td width="16%"><input name="txtvtotal" size="16" style="TEXT-ALIGN: right" value="0.00" readonly class="bgcolor2"></td>
                            <td width="16%"></td>
                            <td width="16%"><input name="txtctotal" size="10" class="bgcolor2" style="TEXT-ALIGN: right" value="0.00" readonly></td>
                            <td width="19%"><input name="txtftotal" size="10" class="bgcolor2" style="TEXT-ALIGN: right" value="0.00" readonly></td>
                          </tr>
                          <tr>
                            <td width="26%" height="15"></td>
                            <td width="8%" align="middle" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="16%" height="15"></td>
                            <td width="19%" height="15"></td>
                          </tr>
                        </table>

                        </center></center></td>
                      </tr>
                    </table>

                    </center>
                  </div>
                  </td>
                </tr>
              </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        </div>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%" height="10"></td>
          </tr>
        </table>

        <div align="center">
          <center>

          <table border="0" width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
            <tr>
              <td width="100%"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.aspx&quot;)" ></td>
            </tr>
          </table>

          </center>
        </div>
      </center></td>
    </tr>
  </table>

  <div>
  </div>
  <center></center><input type="hidden" name="hpre" value="<%=session("precision")%>"><input type="hidden" name="txtSessionflds" value="<%=vUserid & "~" & vAppdate & "~" & vCounterno & "~" & vCashierid & "~" & vBranchCode & "~" & vBrnarration & "~" & vCurCode & "~" & vCurnarration & "~"%>">
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  
          height=0 width=0 >
          </iframe>
          </td>
        </tr>
      </table>
<table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%"><iframe id="idet" align=center frameBorder=0 frameSpacing=0  
          height=0 width=0 src="counter.aspx">
          </iframe>
          </td>
        </tr>
      </table>
      </center>
    </div>
    </td>
  </tr>
</table>

</body>

</html>
