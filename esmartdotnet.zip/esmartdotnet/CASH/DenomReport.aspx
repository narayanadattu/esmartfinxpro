<%@ Page  aspcompat="true" explicit="false"  Language="vb" AutoEventWireup="false" Codebehind="DenomReport.aspx.vb" Inherits="eSmartDotNet.DenomReport"%>
<HTML>
  <HEAD>
		<title>Denomination Reports</title>
<%
	
	Dim BrCode, CurCode, RepDate, CashId , DnomCash,apdat,rep
	
	BrCode = UCase(Trim(Request.Form("txtbranchcode")))
	CurCode = UCase(Trim(Request.Form("txtcurrencycode")))
	RepDate = Request.Form("txtDenomdate")
	CashId = UCase(Trim(Request.Form("txtcashid")))
	apdat = session("applicationdate")
	rep = UCase(Trim(Request.Form("hidRep")))
	dim strQuery,GrdTot
	GrdTot = 0
	
	dim tab,stTab,stcolTd,stctd,strNDm,strPDm,stDmn,stTot,Pdm,Ndm,Tdm
	dim strDenom,denom,DenFld,DenVal, strMain
	dim stCount
	dim strAlot,Alot
	dim stArr,stVal, StrTot
	dim stCnt,stReval,PstDm,NstDm
	
	if rep = "XL" then
		Response.ContentType = "application/vnd.ms-excel"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & "DenomRep.xls")
	end if					
												
	rs = server.CreateObject("adodb.recordset")
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	rsAlot = server.CreateObject("adodb.recordset")
	objAlot	= server.CreateObject("ReportPurposeOnly.Reportonly")
	rsDnom = server.CreateObject("adodb.recordset")
	objDnom	= server.CreateObject("ReportPurposeOnly.Reportonly")
	rsVal = server.CreateObject("adodb.recordset")
	objVal	= server.CreateObject("ReportPurposeOnly.Reportonly")
	
	rsPdm = server.CreateObject("adodb.recordset")
	objPdm	= server.CreateObject("ReportPurposeOnly.Reportonly")
	rsNdm = server.CreateObject("adodb.recordset")
	objNdm	= server.CreateObject("ReportPurposeOnly.Reportonly")	
	rsTot = server.CreateObject("adodb.recordset")
	objTot	= server.CreateObject("ReportPurposeOnly.Reportonly")
	
	rsaddress=server.CreateObject("adodb.recordset")
	objfetch =server.CreateObject("queryrecordsets.fetchrecordsets")

	rsaddress=objfetch.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & BrCode & "' and a.bankcode=b.bankcode")

%>

<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
<meta content="Visual Basic .NET 7.1" name="CODE_LANGUAGE">
<meta content="JavaScript" name="vs_defaultClientScript">
<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
<style>.break { page-break-after: always }
</style>
<script>
	function HandleBackFunctionality()
	{
		if(window.event)
		{
			if(window.event.clientX < 40 && window.event.clientY < 0)
			{
			var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
			else
			{
			//   alert("Browser refresh button is clicked...");
			}
		}
		else
		{
			if(event.currentTarget.performance.navigation.type == 1)
			{
			//   alert("Browser refresh button is clicked...");
	     
			}
			if(event.currentTarget.performance.navigation.type == 2)
			{
			//  alert("Browser back button is clicked...");
					var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
		}
	}


	function notAllowed()
	{
		if(event.ctrlKey)
		{
			event.keyCode=0;
			return false;
		}
		if(parseInt(event.button)==2 ||parseInt(event.button)==3 )
		{
			alert("This Operation Is Not Allowed");
			return false;     
		}
	} 


	function prnt()
	{
		window.document.all['divPrnt'].style.display="none";
		window.print()
		window.document.all['divPrnt'].style.display="block";
	}
		
	function SelCopy()
	{
		var copysuccess // var to check whether execCommand successfully executed
		try
		{
			copysuccess = document.execCommand("copy") // run command to copy selected text to clipboard
		} 
		catch(e)
		{
			copysuccess = false
		}
		return copysuccess
	}

	function selectText(containerid) 
	{
		if (document.selection) 
		{
			var range = document.body.createTextRange();
			range.moveToElementText(document.getElementById(containerid));
			range.select();
		} 
		else if (window.getSelection()) 
		{
			var range = document.createRange();
			range.selectNode(document.getElementById(containerid));
			window.getSelection().removeAllRanges();
			window.getSelection().addRange(range);
		}
	}

</script>
</HEAD>
<body leftMargin="0" topMargin="0" onmousedown="notAllowed();" onkeydown="notAllowed();" onbeforeunload="HandleBackFunctionality();" >
<form name="frmDenomReport">
	<div id = "divselcopy">
		<table width="100%" border=0>
			<tr>
				<td align="center" width="100%" colSpan="4">
					<%''''' Report Headings%>
					<center><font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
						</font>
						<br>
						<font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value) & "," & iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
						</font>
						<br>
						<font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
						</font>
					</center>
				</td>
			</tr>
		</table>
		<table width="100%">
			<tr>
				<td align="center" colSpan="2"><font face="courier new" color="#000000" size="2"><%=strRepTitle%><%=appdate%></font></td>
			</tr>
			<tr>
				<td align="left" width="50%"><font face="courier new" color="#000000" size="2">User ID&nbsp;:&nbsp;<%=session("userid")%></font></td>
				<td align="right" width="50%"><font face="courier new" color="#000000" size="2">Branch Code&nbsp;:&nbsp;<%=BrCode%></font></td>
			</tr>
		</table>
		
		
		<table width="100%">
		<!--- for Cash Allotment  And Cash Refund for Casher Id  Start --->
		
		<%	if ucase(Request.QueryString("strng"))="CASHALLOTDETAIL" or ucase(Request.QueryString("strng"))="CASHRFUNDDETAIL" then 
				
				if apdat = RepDate then
					tab = ""
				else
					tab = "BKP"
				end if
				
				if ucase(Request.QueryString("strng"))="CASHALLOTDETAIL"  then
					stTab = "CASHALLOTMENTSTRN"
					stcolTd = "cashierid"
					stctd = "ALLOTMENTNO"
				else if ucase(Request.QueryString("strng"))="CASHRFUNDDETAIL" then
					stTab = "CASHREFUNDSTRN"
					stcolTd = "REFUNDEDUSERID"
					stctd = "REFUNDNO"
				end if
				
				strQuery = ""
				
				strQuery = "SELECT DISTINCT COUNTERNO FROM " & stTab & "" & tab & " WHERE branchcode='" & BrCode & "' AND currencycode='" & CurCode & "' AND " & stcolTd & " ='" & CashId & "' AND APPLICATIONDATE = '" & RepDate & "' "
				
				rs = obj.SingleSelectStat(strQuery)
					
					if obj.ConnError="Connected" then
						if not rs.bof and not rs.eof then
							do until rs.eof
								
								stCount = rs(0).value
			
		
		%>
			<table width="100%">
				<tr>
					<%	if ucase(Request.QueryString("strng"))="CASHALLOTDETAIL"  then %>
					<td colSpan="5" width="100%"><center><font face="courier new" color="#000000" size="2">Cash Alloted for Cashier ID &nbsp;:&nbsp;<%=CashId%> and Counter No.&nbsp;:&nbsp;<%=stCount%>&nbsp; as On Date&nbsp;:&nbsp;<%=RepDate%>  </font> </center></td>
					<%	else if ucase(Request.QueryString("strng"))="CASHRFUNDDETAIL"  then %>
					<td colSpan="5" width="100%"><center><font face="courier new" color="#000000" size="2">Cash Refund for Cashier ID &nbsp;:&nbsp;<%=CashId%> and Counter No.&nbsp;:&nbsp;<%=stCount%>&nbsp; as On Date&nbsp;:&nbsp;<%=RepDate%>  </font> </center></td>
					<% End if %>
				</tr>
			</table>
			
			<table width="45%" class="tblebordermain" border="1" >
				<%
					
					strAlot = ""
					
					strAlot = "SELECT " & stctd & " FROM " & stTab & "" & tab & " WHERE STATUS = 'A' AND  branchcode='" & BrCode & "' AND currencycode='" & CurCode & "' AND " & stcolTd & " ='" & CashId & "' and counterno = '" & stCount & "'  AND APPLICATIONDATE = '" & RepDate & "' "
					
					rsAlot = objAlot.SingleSelectStat(strAlot)
					
					if objAlot.ConnError="Connected" then
						if not rsAlot.bof and not rsAlot.eof then
							do until rsAlot.eof
								
								Alot = rsAlot(0).value
				
				%>
				
				<tr>
					<%	if ucase(Request.QueryString("strng"))="CASHALLOTDETAIL"  then %>
					<td colSpan="5" ><center><font face="courier new" color="#000000" size="2">Alloted No.&nbsp;:&nbsp;<%=Alot%> </font> </center></td>
					<%	else if ucase(Request.QueryString("strng"))="CASHRFUNDDETAIL"  then %>
					<td colSpan="5" ><center><font face="courier new" color="#000000" size="2">Refund No.&nbsp;:&nbsp;<%=Alot%> </font> </center></td>
					<% End if %>
				</tr>
			
				<tr>
					<td align="center" width="14%"><font face="courier new" color="#000000" size="2">Denomination </font></td>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2">*</font></td>
					<td align="center" width="19%"><font face="courier new" color="#000000" size="2">No. of Piec</font></td>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2">=</font></td>
					<td align="center" width="14%"><font face="courier new" color="#000000" size="2">Amount</font></td>
				</tr>
				<%
					
					
					strDenom = ""
					
					strDenom = "  SELECT Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC "
					
					rsDnom = objDnom.SingleSelectStat(strDenom)
					
					if objDnom.ConnError="Connected" then
						if not rsDnom.bof and not rsDnom.eof then
							
							DenFld = ""
							DenVal = ""
						
							do until rsDnom.eof
								denom = " NVL(SUM(" & rsDnom(1).value & "),0)  " & rsDnom(1).value 
								
								DenFld = DenFld & rsDnom(0).value & ","
								
								strMain = "" 
					
								strMain = "SELECT " & denom & " FROM " & stTab & "" & tab & " WHERE  STATUS = 'A' AND " & stcolTd & " ='" & CashId & "' and counterno = '" & stCount & "' and " & stctd & " = '" & Alot & "' AND branchcode='" & BrCode & "' AND currencycode='" & CurCode & "'  AND APPLICATIONDATE = '" & RepDate & "' order by to_number(" & stctd & ") " 
								
								rsVal = objVal.SingleSelectStat(strMain)
								
								if objVal.ConnError="Connected" then
									if not rsVal.bof and not rsVal.eof then
										do until rsVal.eof
										
											DenVal = DenVal & rsVal(0).value & ","
											
										rsVal.movenext()
										loop
									end if
									rsVal = nothing
								end if
							
							
							rsDnom.movenext()
							loop
				
							DenFld = mid(DenFld,1,DenFld.length-1)
							DenVal = mid(DenVal,1,DenVal.length-1)
						end if
						rsDnom = nothing
					end if
					
					StrTot = 0
					
					stArr = DenFld.split(",")
					stVal = DenVal.split(",")
					
						for i=0  to ubound(stArr)
						
							if stVal(i) <> "0" then
					%>
					<tr>
						<td align="right"><font face="courier new" color="#000000" size="2"><%=stArr(i)%></font></td>
						<td align="center"><font face="courier new" color="#000000" size="2">*</font></td>
						<td align="right"><font face="courier new" color="#000000" size="2"><%=stVal(i)%></font></td>
						<td align="center"><font face="courier new" color="#000000" size="2">=</font></td>
						<td align="right"><font face="courier new" color="#000000" size="2"><%=Cdbl(stArr(i))*cdbl(stVal(i))%></font></td>
					
					</tr>
					<%
							StrTot = cdbl(StrTot) + (Cdbl(stArr(i))*cdbl(stVal(i)))
							
							end if
						
						next i
						
						GrdTot = cdbl(GrdTot) + cdbl(StrTot)
					%>
				<tr> 
					<td colspan="3" width="37%" align="right"><font face="courier new" color="#000000" size="2">Total</font></td>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2">=</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"> <% = cdbl(StrTot)%></font></td>
				</tr>
				<%
							rsAlot.movenext()
							loop
						end if
						rsAlot = nothing
					end if
				
				%>
			</table>
		
			
			
		<% 
							rs.movenext()
							loop
						end if
						rs = nothing
					end if
		%>
		</table>
		<table width="45%">
			<tr>
				<td colspan="3" width="37%" align="right"><font face="courier new" color="#000000" size="2">Grand Total</font></td>
				<td align="center" width="4%"><font face="courier new" color="#000000" size="2">=</font></td>
				<td align="right" width="14%"><font face="courier new" color="#000000" size="2"> <% = cdbl(GrdTot)%></font></td>
			</tr>
		</table>
		<!--- for Cash Allotment And Cash Refund for Casher Id  End  --->
		<!--- for Cash Exchange for Casher Id  Start  --->
		<% else if ucase(Request.QueryString("strng"))="CASHEXCHANGE" then 
		
			strDenom = ""
					
			strDenom = "  SELECT Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC "
			
			rsDnom = objDnom.SingleSelectStat(strDenom)
			
			if objDnom.ConnError="Connected" then
				if not rsDnom.bof and not rsDnom.eof then
					
					DenFld = ""
					
					do until rsDnom.eof
						
						denom = denom & " NVL((" & rsDnom(1).value & "),0)  " & rsDnom(1).value & ","
						
						stDmn = " NVL(SUM(" & rsDnom(1).value & "),0)  " & rsDnom(1).value 
						
						DenFld = DenFld & rsDnom(0).value & ","
						
						strNDm = ""
						strPDm = ""
						
						strNDm = "SELECT " & stDmn & " FROM CASHEXCHANGETRN WHERE UPPER(trim(Cashierid))='" & CashId & "' AND APPLICATIONDATE = '" & RepDate & "' AND UPPER(currencycode)='" & CurCode & "' AND UPPER(branchcode)='" & BrCode & "' AND " & rsDnom(1).value & " <= '0' "
						
						rsNdm = objNdm.SingleSelectStat(strNDm)
						
						if objNdm.ConnError="Connected" then
							if not rsNdm.bof and not rsNdm.eof then
								do until rsNdm.eof
									Ndm = Ndm & rsNdm(0).value & ","
								rsNdm.movenext()
								loop
							else
								Ndm = ""
							end if
							rsNdm = nothing
						end if
						
						
						strPDm = "SELECT " & stDmn & " FROM CASHEXCHANGETRN WHERE UPPER(trim(Cashierid))='" & CashId & "' AND APPLICATIONDATE = '" & RepDate & "' AND UPPER(currencycode)='" & CurCode & "' AND UPPER(branchcode)='" & BrCode & "' AND " & rsDnom(1).value & " > '0'"
						
						rsPdm = objPdm.SingleSelectStat(strPDm)
						
						if objPdm.ConnError="Connected" then
							if not rsPdm.bof and not rsPdm.eof then
								do until rsPdm.eof
									Pdm = Pdm & rsPdm(0).value & ","
								rsPdm.movenext()
								loop
							else
								Pdm = ""
							end if
							rsPdm = nothing
						end if
					
					rsDnom.movenext()
					loop
					
					
					DenFld = mid(DenFld,1,DenFld.length-1)
					denom = mid(denom,1,denom.length-1)
					Ndm = mid(Ndm,1,Ndm.length-1)
					Pdm = mid(Pdm,1,Pdm.length-1)
				end if
				rsDnom = nothing
			end if
				
				stTot = ""
				stTot =  "SELECT SUM(EXCHANGEAMOUNT) FROM CASHEXCHANGETRN WHERE UPPER(trim(Cashierid))='" & CashId & "' AND APPLICATIONDATE = '" & RepDate & "' AND UPPER(currencycode)='" & CurCode & "' AND UPPER(branchcode)='" & BrCode & "'"
				
				rsTot = objTot.SingleSelectStat(stTot)
				
				if objTot.ConnError="Connected" then
					if not rsTot.bof and not rsTot.eof then
						do until rsTot.eof
							Tdm = Tdm & rsTot(0).value 
						rsTot.movenext()
						loop
					else
						Tdm = "0"
					end if
					rsTot = nothing
				end if
				
				
				strMain = "" 
					
				strMain = "SELECT EXSNO,TO_CHAR(EXCHANGEAMOUNT)," & denom & ",SUBSTR(NARRATION,0,20) nar, MOBILE, PANNO, ''''||AADHARNO FROM CASHEXCHANGETRN WHERE  UPPER(trim(Cashierid))='" & CashId & "' AND APPLICATIONDATE = '" & RepDate & "' AND UPPER(currencycode)='" & CurCode & "' AND UPPER(branchcode)='" & BrCode & "' order by to_number(EXSNO)" 
				
				rsVal = objVal.SingleSelectStat(strMain)
				
				if objVal.ConnError="Connected" then
					if not rsVal.bof and not rsVal.eof then
						do until rsVal.eof
							
							for i = 0 to rsVal.fields.count - 1 
								DenVal = DenVal & rsVal(i).value & ","
							next i	
								
								DenVal = DenVal & "|"
						rsVal.movenext()
						loop
						
						DenVal = mid(DenVal,1,DenVal.length-1)
					else
						DenVal = ""
					end if
					rsVal = nothing
				end if
				
				
		%>
			<table width="100%">
				<tr>
					<td width="100%"><center><font face="courier new" color="#000000" size="2">Cash Exchange for Cashier ID &nbsp;:&nbsp;<%=CashId%> &nbsp; as On Date&nbsp;:&nbsp;<%=RepDate%>  </font> </center></td>
				</tr>
			</table>
			<table width="100%" class="tblebordermain" border="1" >
				<tr>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Exsno</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Exchange Amt</b></font></td>
					<% 
						stArr = DenFld.split(",")
						
						for i=0  to ubound(stArr)
						
							 %>
					<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
					<%  next i %>
					
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Naration</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Mobile</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Panno</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Aadhar</b></font></td>
					
				</tr>
				<% 
					if DenVal <> "" then
					
					stCnt  = DenVal.split("|")
					
					for i=0  to ubound(stCnt)
				%>
				<tr>
					<% stReval = stCnt(i).split(",")
						
						for j = 0 to ubound(stReval)%>
					<td align="right"><font face="courier new" color="#000000" size="2"><%=stReval(j)%></font></td>
					
					<%  next j %>
				</tr>
				<%  next i %>
				
				<tr>
					<td align="right"><font face="courier new" color="#000000" size="2">Out Total </font></td>
					<td align="right"><font face="courier new" color="#000000" size="2"><%=cdbl(Tdm)%></font></td>
					<% NstDm = Ndm.split(",")
						
						for i = 0 to ubound(NstDm)%>
					<td align="right"><font face="courier new" color="#000000" size="2"><%=NstDm(i)%></font></td>
					
					<%  next i %>
				</tr>
				
				<tr>
					<td align="right"><font face="courier new" color="#000000" size="2">In Total </font></td>
					<td align="right"><font face="courier new" color="#000000" size="2"><%=cdbl(Tdm)%></font></td>
					<% PstDm = Pdm.split(",")
						
						for j = 0 to ubound(PstDm)%>
					<td align="right"><font face="courier new" color="#000000" size="2"><%=PstDm(j)%></font></td>
					
					<%  next j %>
				</tr>
				
				
				<%	else   %>
				<tr>
					<td align="center"><font face="courier new" color="#000000" size="2">No Records Found For Cash Exchange</font></td> 
				</tr>
					
				<%	end if %>
			
			</table>
			<!--- for Cash Exchange for Casher Id  End  --->
			<!--- for Cash Counter Exchange for Casher Id  Start  --->
		<%
			else if ucase(Request.QueryString("strng"))="CASHCOUNTEXCHANGE" then 
			
			
			RepDate = Request.Form("txtRepvaultdate")
			
			strDenom = ""
					
			strDenom = "  SELECT Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC "
			
			rsDnom = objDnom.SingleSelectStat(strDenom)
			
			if objDnom.ConnError="Connected" then
				if not rsDnom.bof and not rsDnom.eof then
					
					DenFld = ""
					
					do until rsDnom.eof
						
						denom = denom & " NVL((" & rsDnom(1).value & "),0)  " & rsDnom(1).value & ","
						
						DenFld = DenFld & rsDnom(0).value & ","
					
					rsDnom.movenext()
					loop
		
					DenFld = mid(DenFld,1,DenFld.length-1)
					denom = mid(denom,1,denom.length-1)
				end if
				rsDnom = nothing
			end if
				
				strMain = "" 
					
				strMain = "SELECT CASHTRANSFERNO, FROMCASHIERID, TOCASHIERID, TO_CHAR(AMOUNT), NARRATION, FROMCOUNTERNO, TOCOUNTERNO," & denom & " FROM CASHTRANSBTCASHIERSTRN WHERE   STATUS = 'A' AND APPLICATIONDATE = '" & RepDate & "' AND UPPER(currencycode)='" & CurCode & "' AND UPPER(branchcode)='" & BrCode & "' " 
				
				rsVal = objVal.SingleSelectStat(strMain)
				
				if objVal.ConnError="Connected" then
					if not rsVal.bof and not rsVal.eof then
						do until rsVal.eof
							
							for i = 0 to rsVal.fields.count - 1 
								DenVal = DenVal & rsVal(i).value & ","
							next i	
								
								DenVal = DenVal & "|"
						rsVal.movenext()
						loop
						
						DenVal = mid(DenVal,1,DenVal.length-1)
					else
						DenVal = ""
					end if
					rsVal = nothing
				end if
				
				
		%>
			<table width="100%">
				<tr>
					<td width="100%"><center><font face="courier new" color="#000000" size="2">Cash Counter Exchange Refort as On Date&nbsp;:&nbsp;<%=RepDate%>  </font> </center></td>
				</tr>
			</table>
			<table width="100%"  border="1" >
				<tr>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Cash Tran No.</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>From Cash Id</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>To Cash Id</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Naration</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>Frm Cnt No.</b></font></td>
					<td align="center"><font face="courier new" color="#000000" size="2"><b>To Cnt No.</b></font></td>
					<% 
						stArr = DenFld.split(",")
						
						for i=0  to ubound(stArr)
						
							 %>
					<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
					<%  next i %>
					
				</tr>
					<%  
						if DenVal <> "" then
						
						stCnt  = DenVal.split("|")
						
							for i=0  to ubound(stCnt)
					%>
				<tr>
					<% stReval = stCnt(i).split(",")
						
								for j = 0 to ubound(stReval)%>
					<td align="center"><font face="courier new" color="#000000" size="2"><%=stReval(j)%></font></td> 
					
					<%			next j %>
				</tr>
					<%		next i  
					
						else   %>
					<tr>
						<td align="center"><font face="courier new" color="#000000" size="2">No Records Found For Cash Counter Exchange</font></td> 
					</tr>
					
					
					<%	end if  %>
			
			</table>
		<!--- for Cash Counter Exchange end   --->
		<%			
			end if 
			
		%>
			
		
		
		
		
		<table align=center width = "100%" >
			<tr>
				<td align =center >
					<div id="divPrnt">
					<input type="button" value="  Select All   " name="butSelectAll" onclick="selectText('divselcopy')" class="button">
					<input type="button" value="  Copy   " name="butCopy" onclick="SelCopy()" class="button"><input onclick="prnt()" type="button" value="  Print   " name="butprnt"><input class="bgcolor" onclick="location.href='cashierwisereport.aspx'" type="button" value="   Exit   "
													name="butok"></div>
				</td>
			</tr>
		</table>
	</form>
</body>
</HTML>
