<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="CashAllotInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CashAllotInsert" %>
<%	Dim Arrtrans(0,2)
    s=Request.Form("hcount")
    'Response.Write (s)
    Redim Arrtrans(s,2)
    
    '------------------Assigning the  values------------------------
    
	BrCode=Request.Form("txtbranchcode")
	CurCode=Request.Form("txtcurrencycode")
	CntCode=Request.Form("txtcounterno")
	CashId=Request.Form("txtCashierId")
	AmtAllot=Request.Form("txtAmount")
	DenomTot=Request.Form("txttotal")
	m=split(Request.Form("hvalue"),"|") 
	n=split(Request.Form("hpices"),"|") 
	p=split(Request.Form("htype"),"|") 
	appdate=session("APPLICATIONDATE")
	
	for i=1 to Request.Form("hcount") 
		Arrtrans(i,0)=m(i-1)
		Arrtrans(i,1)=n(i-1)
		Arrtrans(i,2)=p(i-1)
	next
   '---------------------------------------------------------------------
   '''' for autonumber genration of allotment no
   dim RecAllot
   RecAllot=server.CreateObject("adodb.recordset")
   '''calling general query component
   Objfetchrec=server.CreateObject("queryrecordsets.fetchrecordsets")
   RecAllot=ObjFetchRec.singlerecordset("CASHALLOTMENTSTRN", _
								"nvl(max(ALLOTMENTNO),0)+1", _
								"branchcode='" & ucase(trim(BrCode)) & "' and " & _
								"cashierid='" & ucase(trim(CashId)) & "'")
	if not RecAllot.EOF and not RecAllot.BOF then
		Allotno=RecAllot(0).value
	end if						

    ''''''-----------------------------------------------------------------------
	if len(Brcode)<>0 and len(CurCode)>0 and len(CntCode)>0 and  len(CashId)>0 then

		kstr="BRANCHCODE,CURRENCYCODE,APPLICATIONDATE,COUNTERNO,CASHIERID," & _
			"ALLOTMENTNO,ALLOTEDUSERID,MACHINEID,AMOUNTALLOTED,ALLOTMENTDATE," & _
			"STATUS,SYSTEMDATE,userid" 

		strvalues="'" & ucase(trim(BrCode)) & "','" & ucase(trim(CurCode)) & "'," & _
				"to_date('" & appdate & "','dd-Mon-yyyy')," & CntCode & "," & _
				"'" & ucase(trim(CashId)) & "', " & _
				"" & AllotNo & ",'" & ucase(trim(session("USERID"))) & "'," & _
				"'" & ucase(trim(session("MACHINEID"))) & "'," & AmtAllot & "," & _
				"to_date('" & appdate & "','dd-mm-yyyy'),'P',SYSDATE,'" & session("userid") & "'"
							
	'----------- Calling the Component	--------------------
	
		 obj=server.CreateObject("CashTransaction.Transactions")	
		 
		 'response.write("<br><br>'" & cstr(CurCode) & "','" & cstr(BrCode) & "'")
		 'response.write("<br><br>'" & cstr(CashId) & "','" & cstr(CntCode) & "'")
		 'response.end
		
		'strmsg=obj.CashTRNInserts("CASHALLOTMENTSTRN",cstr(kstr), _
				'cstr(strvalues),cstr(CurCode),Arrtrans)  
		strmsg=obj.CashTRNInserts("CASHALLOTMENTSTRN",cstr(kstr), _
				cstr(strvalues),cstr(CurCode),Arrtrans,cstr(BrCode),cstr(session("userid")), _
				cstr(session("machineid")),cstr(session("applicationdate")),"O", _
				ucase(cstr(CashId)),cstr(CntCode))  
		 obj=nothing
		strmsg = replace(strmsg,chr(10)," ") 
		strmsg = replace(strmsg,chr(13)," ")
		Response.Write (strmsg)
		'strmsg= strmsg '& " -:" & session("APPLICATIONDATE")
		
		strmsg= strmsg & ". Allotment No is " & Allotno  
	'-------------------------------------------------------
		
		Response.Redirect ("cashallot.aspx?record=" & strmsg)
	else
		Response.Write ("Fields should not be empty")
	end if


%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
