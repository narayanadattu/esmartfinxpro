<%@ Page Language="vb" CodeBehind="cashreport.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashreport" %>
<%
dim rs,obj
dim st,appdate
appdate=formatdatetime(date(),2)
'-------------------Getting values from Scroll Form--------------------

Brcode=request("txtbranchcode")
Crcode=request("txtcurrencycode")
Todate=request("txttodate")
Fromdate=request("txtfromdate")
ctype= Request("rdcash")
ptype=request("rdpay")

'--------------------Calling Component------------------------

set obj=server.CreateObject("CASHREPORTS.CASHREPORT")
 
if ctype= "cash" then
   if ucase(ptype)="PAYMENTS" then
      st=obj.GetReportData("cashpaymentstrn","glcode,paymentscrollno,tranno,chqno,accno,tokenno,narration,amount",cstr(fromdate),cstr(todate),cstr(brcode),cstr(crcode))
   elseif ucase(ptype)="RECEIPTS" then
      st=obj.GetReportData("cashreceiptstrn","glcode,receiptscrollno,tranno,chqno,accno,narration,amount",cstr(fromdate),cstr(todate),cstr(brcode),cstr(crcode))
   end if
end if

'---------------------------------------------------------------------------------
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript>
<!--
 function toprint()
 {
	window.document.frmpay.buttprint.style.visibility="hidden"
	window.document.frmpay.buttcan.style.visibility="hidden"
	alert("Do you want print")
	window.print()
	 
 }
//-->
</SCRIPT>


<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<body>

<form name="frmpay">

  <table align="center" border="0" cellspacing="1" cellpadding="1" width="754">
    <tr>
      <td align="center" width="604" colspan="4">
      <p align="left"><font size="3" face="MS Sans Serif"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      ESMART BANK</b></font></p>
      </td>
      <td width="136"><font size="2" face="MS Sans Serif">Date :<%=appdate%></font></td>
    </tr>
    <tr>
      <td align="center" colspan="5" width="746"><font size="3" face="MS Sans Serif">Srinagar
      Colony</font></td>
    </tr>
    <tr>
      <td align="center" colspan="5" width="746"><font size="3" face="MS Sans Serif">Hyderabad
      500 008<br>
      </font></td>
    </tr>
    <tr align="left">
      <td width="130"></td>
      <td width="111">&nbsp;Branch:<%=Brcode%></td>
      <td width="174">From Date:<%=Fromdate%></td>
      <td width="183">To Date:<%=Todate%></td>
    </tr>
    <tr align="left">
      <td width="130" height="10"></td>
      <td width="111" height="10"></td>
      <td width="174" height="10"></td>
      <td width="183" height="10"></td>
    </tr>
  </table>

  <%if ubound(st)>0 then%>
  <% if ucase(ptype)="PAYMENTS" then%>

  <table align="center" align="border=0">
    <tr>
      <td>Gl Code</td>
      <td>ScrollNo</td>
      <td>TranNo</td>
      <td>ChequeNo</td>
      <td>AccNo</td>
      <td>TokenNo</td>
      <td>Narration</td>
      <td>Amount</td>
    </tr>
	 <%elseif ucase(ptype)="RECEIPTS" then%>
    <tr>
      <td>

      <table align="center" align="border=0">
        <tr>
          <td>Gl Code</td>
          <td>ScrollNo</td>
          <td>TranNo</td>
          <td>ChqueNo</td>
          <td>AccNo</td>
          <td>Narration</td>
          <td>Amount</td>
        </tr>
	    <%end if%>	
	    <%end if%>	
        <%if ubound(st)>0 then
			Dim i,k,rep,opbal,clbal,Totrec,Totpay
			opbal=st(ubound(st)-3,0)
			Totrec=st(ubound(st)-2,0)
			Totpay=st(ubound(st)-1,0)
			clbal=eval(cdbl(opbal)+cdbl(Totrec))-cdbl(Totpay) %>
			<%FOR i =0 to ubound(st)-4%>
			<%rep=split(st(i,0),",")%>
        <tr>
			<%for k=0 to ubound(rep)%>
          <td align="right"><%=rep(k)%></td>
			<%next%>
        </tr>
			<%NEXT %>
        <tr>
          <td>

          <table align="center">
            <tr>
              <td>Opening Balance</td>
              <td>:<%=opbal%></td>
            </tr>
            <tr>
              <td>Total Receipts</td>
              <td>:<%=Totrec%></td>
            </tr>
            <tr>
              <td>Total Payments</td>
              <td>:<%=Totpay%></td>
            </tr>
            <tr>
              <td>Closing Balance</td>
              <td>:<%=clbal%></td>
            </tr>
          </table>

          <% else
            Response.Write"<table align=center>"
            Response.Write"<tr><td>"
            Response.Write"<font color=red size=+1>"
            Response.Write st(0,0)
            Response.Write"</font>" 
            Response.Write"</tr></td>"
            Response.Write"</table>" 
         end if   
          %>
  
      </table>

      <br>
      <center><input type="button" value="   Print   " name="buttprint" onclick="toprint()">
      <input type="button" value="Cancel" name="buttcan" onclick="location.href='scroll.asp'">
      </form>
      </center></td>
    </tr>
  </table>

</body>

