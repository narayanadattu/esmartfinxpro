<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="CashPaymentInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CashPaymentInsert" %>
<HEAD>
	<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CashPaymentInsert.aspx				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| T.Anil kumar         |    05-MAY-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
	<%
'This page is used to send data to parameters CashPayments method.
Response.Buffer=true
Response.Expires=0
On Error Resume Next
Dim BrchCd,BrchNm,CurrCd,CurrNm,mydate,appldt
Dim TknNo,ScrlNo,TrnId,ModId,GiCd,AccNo,amt,narrn,BatNo,chqNo,strMode,strVal
Dim Dval,Dtype,DPadamt,DExamt,totDenomValues
Dim Vartrans(0,0)
Dim i,J,K
dim vUserid,vAppldate,vCounterno
DIM dd,yy,mm,appldate
Dim kstr,strMsg,ObjPay 
dim brcode,Curcode	
dim verBy,verMC,apprBy,apprMC
verBy=""
verMC=""
apprBy=""
apprMC=""
chqNo=""

    vUserid=session("userid")
    vAppldate=session("applicationdate")
    vCounterno=session("counterno")
    vMachineId=session("machineid")

if len(Request.Form("hdnPayInsrt"))>0 then '1
totDenomValues=split(Request.Form("hdnPayInsrt"),"|")   
Dval=split(totDenomValues(0),"~")
DPadamt=split(totDenomValues(1),"~")
DExamt=split(totDenomValues(2),"~")
Dtype=split(totDenomValues(3),"~")

 strVal=split(totDenomValues(4),"~")   
 
BrchCd=strVal(0)
CurrCd=strVal(1)
BatNo=strVal(2)
TknNo=strVal(3)
ScrlNo=strVal(4)
TrnId=strVal(5)
ModId=strVal(6)
GiCd=strVal(7)
AccNo=strVal(8)
amt=strVal(9)
narrn=strVal(10)
strMode=strVal(11)



Redim Vartrans(ubound(dval)-1,3)

For i=0 to UBound(Vartrans) 
	Vartrans(i,0)=trim(Dval(i))
	Vartrans(i,1)=DPadamt(i)
	Vartrans(i,2)=DExamt(i)
	Vartrans(i,3)=Dtype(i)
next





'and Len(TknNo)>0   
  
if Len(BrchCd)<>0 and len(CurrCd)>0 and Len(TrnId)>0 then
		'----------- Calling the Component	--------------------
     dim recTrans,objTrans,fldnms,WhrCond
     
     fldnms="verifiedby,verifiedmachine,approvedby,approvedmachine"
     'old code commented and new code written by Radhika on 22 may 2008
     'Reason: ABB transactions not handled properly
'     WhrCond="branchcode='" & cstr(trim(BrchCd)) & "' and upper(currencycode)='" & _
'                cstr(ucase(trim(CurrCd))) & "' and batchno='" & cstr(BatNo) & _
'                "' and tranno='" & cstr(TrnId) & "'"
                
     WhrCond="(   (branchcode='" & cstr(trim(BrchCd)) & "' and abbyn <> 'Y') " & _
		     " OR (abbbranchcode='" & cstr(trim(BrchCd)) & "' AND abbyn='Y') )" & _      
			 " and upper(currencycode)='" & _
             cstr(ucase(trim(CurrCd))) & "' and batchno='" & cstr(BatNo) & _
             "' and tranno='" & cstr(TrnId) & "'"                
          
      recTrans=server.CreateObject("adodb.recordset")
      objTrans=server.CreateObject("queryRecordsets.fetchrecordsets")
      recTrans=objTrans.SingleRecordSet("gentranslog",cstr(fldnms),cstr(WhrCond))
         
           
   
         if recTrans.RecordCount>0 then
              'if  recTrans(0).value <>"" then                   
				if isdbnull(recTrans(0).value)=false then
					verBy=recTrans(0).value
				else
					verBy=""
				end if
              'if recTrans(1).value <>"" then  
               if isdbnull(recTrans(1).value)=false then
					verMC=recTrans(1).value
				else
					verMC=""
				end if
				if isdbnull(recTrans(2).value)=true then
					apprBy=""
				else
					apprBy=recTrans(2).value
				end if
				
				if isdbnull(recTrans(3).value)=true then
					apprMC=""
				else
					apprMC=recTrans(3).value
				end if
                
                
         end if   
  
      	 ObjPay = Server.CreateObject("cashtransaction.transactions")
		strMsg = ObjPay.CashPayments(CStr(BrchCd),CStr(CurrCd),cstr(ModId), _
		         CStr(GiCd),CStr(AccNo),CStr(TknNo),cstr(vUserid),CDbl(ScrlNo), _
		         CDbl(amt),CStr(narrn),"A",cstr(vUserid),cstr(vMachineId), _
		         cstr(verBy),cstr(verMC),cstr(apprBy),cstr(apprMC),cstr(vAppldate), _
			     cdbl(BatNo),CDbl(TrnId),cstr(chqNo),Vartrans)   

			 ObjPay=nothing
           
END IF
end if 

'if strMode="PAY" then
'	Response.Redirect ("cashpendingpayments.aspx?trn=<font size=2 face=verdana color=blue><b>"&strMsg&"</b></font>")
	'elseif strMode="TPAY" then
	'Response.Redirect ("http://" & session("moduledir")& "/GEN/cashreceipts.aspx?st=TPAY")
'end if
%>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
		<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
		<meta name="ProgId" content="FrontPage.Editor.Document">
		<script language="javascript">
	function Result(){
	    var vRslt=window.document.CashPayInsrt.hdnStrRslt.value
	        window.attachEvent(window.parent.PayRslt(vRslt));  
    }
//
		</script>
</HEAD>
<body onload="Result()">
	<form name="CashPayInsrt">
		<input type="input" name="hdnPayInsrt" id="hdnPayInsrt"> <input type=input name="hdnStrRslt" id="hdnStrRslt" value="<%=strMsg%>">
		<br>
		<br>
		<br>
		<br>
		<%if err.number<>0 then%>
		<center><font size="2" face="verdana" color="red"><b></b></font><font size="2" face="verdana" color="blue">
				<b>
					<%=err.number%>
					<%=err.description%>
					<p>
					&nbsp;</b></font></center>
		<%end if%>
	</form>
	</P>
</body>
