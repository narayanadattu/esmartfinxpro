<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="counter.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.counter" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<%userid=session("userid")%>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var kstr,bt,t,bl,s
  kstr= window.document.frmacc.hbno.value  
  
  if(kstr)
  {
  window.attachEvent(window.parent.Allot(kstr))  
  window.close()
  }
 
}
//-->
</SCRIPT>

<%dim rs,obj
	kstr=Request.Form("hFlds")
   if len(kstr)> 0 then
 StrmainFld=split(kstr,"~")
   k=split(kstr,"|") 
   '''for refund forms
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
   rs=server.CreateObject("adodb.recordset")
   rs1=server.CreateObject("adodb.recordset")
  if k(0)="cashrefundstrn" then
			if k(2)="refund" then	
				 rs=obj.singlerecordset(cstr(k(0)),"refundamount","refundeduserid='" & k(1) & "' and refundno='" & k(3) & "' and status='P'")
				counterno="R" & "|" & rs(0).value	
			elseif k(1)="counter" then
				 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen","distinct(cash.refundeduserid),gen.name"," cash.refundeduserid=gen.userid  and cash.status<>'A' and cash.counterno=" & k(2) & "")			
				counterno="C" & "|" & rs(0).value & "|" & rs(1).value
			else			
				 rs=obj.singlerecordset(cstr(k(0)),"distinct(counterno),applicationdate","refundeduserid='" & k(1)& "' and status='P' ")
				if not rs.EOF and not rs.bof then
					counterno="M" & "|" & rs(0).value	& "|" & rs(1).value	
				end if
			end if
			
elseif trim(k(0))="GENBANKLEVELMST" THEN
		 rs=obj.singlerecordset("GENBANKLEVELMST","NARRATION,HIERARCHY","CODE='" & k(1).value & "'")
		if not rs.EOF and not rs.bof then
			counterno= rs(0).value & "|" & rs(1).value
        end if
elseif trim(k(0))="cashcashierposmst" then 		
		 obj1=server.CreateObject("Autonumber.generation")
			refno=obj1.GetAutoNumber("cashrefundstrn","refundno","userid='" & cstr(userid) & "'")			
			 obj1=nothing			
		 rs=obj.singlerecordset(cstr(k(0)),"counterno,totamount","cashierid='" & cstr(userid) & "'")	
		if not rs.BOF and not rs.EOF then
		counterno= rs(0).value & "|" & rs(1).value & "|" & refno
		else
		counterno="No Records Found" 
		end if
end if	
'''for Cashh Allot ment form 
'''for getting counterno for selected cashierid	
if  StrmainFld(1)="CounterNo" then  
        res=split(StrmainFld(0),"|")        
		 rs=obj.singleRecordSet("Cashcountermst","counterno,narration", _
		"cashierid='" & cstr(res(0)) & "' and " & _
		"branchcode='" & cstr(res(1)) & "' and " & _
		"currencycode='" & cstr(res(2)) & "'")
		if not rs.EOF and not rs.bof then
		   CounterNo=rs(0).value & "|" & rs(1).value
		    obj=nothing	
		end if
        CounterNo=CounterNo & "~" &  StrmainFld(1)
elseif StrmainFld(4)="DescDisplay" then
	 RecGen=Obj.SingleRecordset(cstr(StrmainFld(0)),cstr(StrmainFld(1)),cstr(StrmainFld(2)))
			if not RecGen.BOF or not RecGen.EOF then
				for i=0 to RecGen.Fields.Count-1
					counterno=counterno &  recgen(i).value & "|"
				next
			else
			counterno= "No|"	
			end if
			counterno=counterno & "~" & StrmainFld(3)	
elseif StrmainFld(5)="AmountCheck" then
 ObjCheckMaxAmt=server.CreateObject("Cashquery.queries")
 strcheckAmt=ObjCheckMaxAmt.CheckCashLimit(cstr(StrmainFld(0)), _
				cstr(StrmainFld(1)),session("applicationdate"),cstr(StrmainFld(2)), _
                                cstr(StrmainFld(3)),cdbl(StrmainFld(4)))
   counterno= strcheckAmt
   Response.Write (countterno)
		counterno=counterno & "~" & StrmainFld(6)				
			
end if
 end if
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=counterno%>">
  <input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
