<%@ Page CodeBehind="cutandsoilednotes.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cutandsoilednotes" %>
<html>

<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CUTSOILEDNOTES.asp									*
'*	Purpose	  	     : This form is use to	accept the cash cut soiled      *
'*						pieces                                              *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   V.SriDevi	        |    2-MAY-2001    |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

'****' in this page serverside script execution pages are
		'cashNoteSolidInsert.asp ----  for all Dml operations according to the buttons
		'Single.asp				----  for CutSoiledtrannos displaying in the list
		'cutSoiledQuery.asp		----  display all fields of cutsolidtable in this form
		'cutsolidlist.asp		----  Display customer details from the customermaster table
		
'**** calling global function pages

%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>New Page 1</title>

<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<!--
**** checking all frontend validation
-->
<SCRIPT LANGUAGE=javascript>
<!--

var st
// calling branchcode and names from the list.asp and diplay it into frontend fields
function branch()
{   
	st="Branch"
	window.open("List.asp" + "?"+"st="+st,st,"width=200%,height=150%,left=150,top=125")
}

function Branchid(str)
{
	assign(str,window.document.frmCutSoiledNote.txtbranchdesc,window.document.frmCutSoiledNote.txtbranchcode)
}

// calling currencycodes and names from the list.asp and diplay it into frontend fields

function currency()
{ 
  st="Curr"
  window.open("List.asp" + "?"+"st="+st,st,"width=220%,height=150%,top=125,left=550")
}

function Currencyid(str)
{
  assign(str,window.document.frmCutSoiledNote.txtcurrencydesc,window.document.frmCutSoiledNote.txtcurrencycode)
  
}

// calling cutomerid and names from the list.asp and diplay it into frontend fields

function Custlist()
{
	//st="CustID"
	st=window.document.frmCutSoiledNote.txtbranchcode.value
	//window.open("List.asp" + "?"+"st="+st,st,"width=220%,height=150%,top=170,left=150")
	//window.open("CUSTLIST.asp" + "?"+"std="+st,st,"width=450%,height=155%,top=170,left=150")
	window.open("CASHCUSTLIST.asp" + "?"+"std="+st,st,"width=450%,height=155%,top=170,left=150")
	window.document.frmCutSoiledNote.txtAddress1.readOnly=true
	window.document.frmCutSoiledNote.txtaddress2.readOnly=true
	window.document.frmCutSoiledNote.txtaddress3.readOnly=true
	
}
function custid(str)
{

var strFlds=new String()
var strAdd=new String()
strFlds=str.split("|")
strAdd=strFlds[2].split(",")
window.document.frmCutSoiledNote.txtCustomerId.value=strFlds[0]
window.document.frmCutSoiledNote.txtCustomerName.value=strFlds[1]
window.document.frmCutSoiledNote.txtAddress1.value=strAdd[0]
window.document.frmCutSoiledNote.txtaddress2.value=strAdd[1]
window.document.frmCutSoiledNote.txtaddress3.value=strAdd[2]
  //assign(str,window.document.frmCutSoiledNote.txtCustomerName,window.document.frmCutSoiledNote.txtCustomerId)
  Custsolid()
  window.document.frmCutSoiledNote.cmdAdd.disabled =false
}

// calling the address respective to the customerid from the custsolidlist.asp 

function Custsolid()
{
var s,s1,s2,k
//s=window.document.frmCutSoiledNote.txtCustomerId.value 
s1=window.document.frmCutSoiledNote.txtcurrencycode.value 

//k="*" 
 //st=s+k+s1
 st=s1+"*List"
 window.open("custsolidlist.asp" + "?"+"st="+st,"Cust","width=220%,height=150%,,top=135,left=220")
}
function getcustid(str)
{

	var strg=new String
	strg=str.split("~")
	window.document.frmCutSoiledNote.txtCustomerId.value=strg[2]
window.document.frmCutSoiledNote.txtCustomerName.value=strg[1]
st=window.document.frmCutSoiledNote.txtCustomerId.value+"*"+window.document.frmCutSoiledNote.txtCustomerName.value+"*Addr"
window.open("custsolidlist.asp" + "?"+"st="+st,"Cust","width=1%,height=1%,top=135,left=220")	
}
// calling the cutsoilednos in the list from the single.asp

function CutsoiledNo()
	 {
	 s="CutsoiledNo"
	 s1=window.document.frmCutSoiledNote.txtbranchcode.value
	 s2=window.document.frmCutSoiledNote.txtcurrencycode.value
		k="|"
	   st=s+k+s1+k+s2
	   window.open("list.asp" + "?"+"st="+st,"soiledno","width=200%,height=150%,top=135,left=220")
	   window.document.frmCutSoiledNote.cmdAdd.disabled=true
	   window.document.frmCutSoiledNote.cmdModify.disabled=false
	   window.document.frmCutSoiledNote.cmdDelete.disabled=false
	   
	 }
/// calling  cutsoiledquery.asp and assigning all the matching criteria fields
/// retrieve all fields  to retrieve all the fields of the cutsoiledtable

function soliddisplay()
{
	st1=window.document.frmCutSoiledNote.txtbranchcode.value 
	st2=window.document.frmCutSoiledNote.txtcurrencycode.value 
	st3=window.document.frmCutSoiledNote.hSoiledNo.value 
	k="*"
	st=st1+k+st2+k+st3

	 window.open("cutSoiledQuery.asp" + "?"+"st="+st,"Cust","width=220%,height=150%,top=135,left=220")
}

function ChngAddStatus()
{

	window.document.frmCutSoiledNote.txtAddress1.readOnly=false
	window.document.frmCutSoiledNote.txtaddress2.readOnly=false
	window.document.frmCutSoiledNote.txtaddress3.readOnly=false
	window.document.frmCutSoiledNote.txtaddress3.disabled=false
	window.document.frmCutSoiledNote.txtAddress1.style.backgroundColor="white"
	window.document.frmCutSoiledNote.txtAddress1.style.color ="black"
	window.document.frmCutSoiledNote.txtaddress2.style.backgroundColor="white"
	window.document.frmCutSoiledNote.txtaddress2.style.color ="black"
	window.document.frmCutSoiledNote.txtaddress3.style.backgroundColor="white"
	window.document.frmCutSoiledNote.txtaddress3.style.color ="black"
	

}


//checking the enabled and disabled of the recieveEnable

function ReceiveEnable()
{
if (window.document.frmCutSoiledNote.txtCustomerId.value=="")
{
window.document.frmCutSoiledNote.txtReceivedFrom.disabled=false
}
else
{
window.document.frmCutSoiledNote.txtReceivedFrom.disabled=true
}
}
//-->
</SCRIPT>


<SCRIPT LANGUAGE=javascript>
//this function user to modify the status of the hidden field and calling the DmlOperations page
<!--
function Insert()
{
var st
if (window.document.frmCutSoiledNote.txtbranchcode.value=="")
{
	alert("Please enter BranchCode ")
	window.document.frmCutSoiledNote.txtbranchcode.focus

}
else if (window.document.frmCutSoiledNote.txtcurrencycode.value=="")
{
alert("Please enter CurrencyCode ")
window.document.frmCutSoiledNote.txtcurrencycode.focus
}
else if (window.document.frmCutSoiledNote.txtDenomination.value=="")
{
alert("Please enter Denomination ")
window.document.frmCutSoiledNote.txtDenomination.focus
}
else if (window.document.frmCutSoiledNote.txtCurNoteNo.value=="")
{
alert("Please enterCurrency Note No ")
window.document.frmCutSoiledNote.txtCurNoteNo.focus
}
else if (window.document.frmCutSoiledNote.txtnarration.value=="")
{
alert("Please enter narration ")
window.document.frmCutSoiledNote.txtnarration.focus
}
else if (window.document.frmCutSoiledNote.txtNoOfNotePiece.value=="")
{
alert("Please enter Number Of Pieces of Currency ")
window.document.frmCutSoiledNote.txtNoOfNotePiece.focus
}
else
{
	window.document.frmCutSoiledNote.status.value=""
	window.document.frmCutSoiledNote.status.value="INSERT"
	window.document.frmCutSoiledNote.action="CashNoteSolidInsert.asp"
	window.document.frmCutSoiledNote.method ="post"
	window.document.frmCutSoiledNote.submit();
}
}
function Modify()
{
if (window.document.frmCutSoiledNote.txtbranchcode.value=="")
{
alert("Please enter BranchCode ")
window.document.frmCutSoiledNote.txtbranchcode.focus
}
else if (window.document.frmCutSoiledNote.txtcurrencycode.value=="")
{
alert("Please enter CurrencyCode ")
}
//else if (window.document.frmCutSoiledNote.txtDenomination.value=="")
//{
//alert("Please enter Denomination ")
//}
else if (window.document.frmCutSoiledNote.txtCurNoteNo.value=="")
{
alert("Please enterCurrency Note No ")
}
else if (window.document.frmCutSoiledNote.txtnarration.value=="")
{
alert("Please enter narration ")
}
else if (window.document.frmCutSoiledNote.txtNoOfNotePiece.value=="")
{
alert("Please enter Number Of Pieces of Currency ")
}

	
else
	{
		window.document.frmCutSoiledNote.status.value=""
		window.document.frmCutSoiledNote.status.value="MODIFY"
		window.document.frmCutSoiledNote.action="CashNoteSolidInsert.asp"
		window.document.frmCutSoiledNote.method="post"
		window.document.frmCutSoiledNote.submit();
	}
}
function Delete()
{
	window.document.frmCutSoiledNote.status.value=""
	window.document.frmCutSoiledNote.status.value="DELETE"
	window.document.frmCutSoiledNote.action="CashNoteSolidInsert.asp"
	window.document.frmCutSoiledNote.method="post"
	window.document.frmCutSoiledNote.submit();
}

function cancel()
{
	location.href="cutandsoilednotes.asp"
	window.document.frmCutSoiledNote.cmdAdd.disabled=false
}

//-->
</SCRIPT>



<SCRIPT LANGUAGE=javascript>
<!--

function Allot(str)
{

var j,k
var St=new String()
var Con =new String()
var St1=new String()
Con=str.split("~")

if (Con[2]=="List")
{
St=Con[0].split("*")

k=Con[2]

St1=Con[1].split("*")
m=window.document.frmCutSoiledNote.txtDenomination.length
	for(j=1;j<m;j++)
     {
         eval("window.document.frmCutSoiledNote.txtDenomination.options[1]=null");
     }    
for(i=0;i<k;i++)
{

St1=Con[1].split("*")

 //var option0 = new Option(balstr[i+1],balstr[i+1])
 var option0 = new Option(St1[i],St1[i])
            eval("window.document.frmCutSoiledNote.txtDenomination.options[i]=option0")    
}
ReceiveEnable()
window.document.frmCutSoiledNote.txtDenomination.focus
}
else if (Con[1]=="Addr")
{
St=Con[0].split("*")
window.document.frmCutSoiledNote.txtAddress1.value=St[0]
window.document.frmCutSoiledNote.txtaddress2.value=St[1]
window.document.frmCutSoiledNote.txtaddress3.value=St[2]
}

}


function CutSoiledDisp(str)
{

var CutStr=new String()
if (str.length>0)

{
	CutStr=str.split("*")
	window.document.frmCutSoiledNote.txtCustomerId.value=CutStr[1]
	window.document.frmCutSoiledNote.txtReceivedFrom.value=CutStr[2]
	window.document.frmCutSoiledNote.txtAddress1.value=CutStr[3]
	window.document.frmCutSoiledNote.txtaddress2.value=CutStr[4]
	window.document.frmCutSoiledNote.txtaddress3.value=CutStr[5]
	window.document.frmCutSoiledNote.txtNoOfNotePiece.value=CutStr[6]
	window.document.frmCutSoiledNote.txtAmtPaid.value=CutStr[7]
	window.document.frmCutSoiledNote.txtnarration.value=CutStr[8]
	//window.document.frmCutSoiledNote.txtDenomination.value=CutStr[9]
	window.document.frmCutSoiledNote.txtCurNoteNo.value=CutStr[10]
	window.document.frmCutSoiledNote.txtCustomerName.value=CutStr[11]
	
	var option0 = new Option(CutStr[9],CutStr[9])
            eval("window.document.frmCutSoiledNote.txtDenomination.options[0]=option0")    
}
	
else
{
	alert("No records")
}
}

function CutSoiledid(str)
{
var Slno=new String()
	Slno=str.split("-----")
	
	  window.document.frmCutSoiledNote.hSoiledNo.value=Slno[1]
	   soliddisplay()
}


function Currid(str)
{
var k=new String()
var j
var pres
var p
var prn

 k=str.split("-----")
  window.document.frmCutSoiledNote.txtcurrencydesc.value =k[0]
  window.document.frmCutSoiledNote.txtcurrencycode.value =k[1]
  prn=k[2].length-1
  window.document.frmCutSoiledNote.hpr.value=prn
  
  p=""
  var p
  var pres
  for(j=1;j<=prn;j++)
  {
    p= p + "0"
  }
	pres= "0." + p 
	
window.document.frmCutSoiledNote.txtAmtPaid.value=pres	
 }

//-->
</SCRIPT>






</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;)">

<form name="frmCutSoiledNote">

  <table width="100%" cellspacing="0" cellpadding="0" height="588" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="28">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="100%" height="28">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="100%" height="28"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <%appdate=formatdatetime(session("applicationdate"),1)%>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25"></td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Cut and Soiled Notes</font></td>
          <td width="33%" height="25" align="right"><font color="white"><%=appdate%></font></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <div align="center" style="width: 760; height: 15">
            <center>

            <table width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td height="15"><font class="textblue">
                <p align="center"><%=Request.QueryString("record")%></font></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="85"><font class="textbold">&nbsp; Branch Code</font></td>
            <td width="252"><input name="txtbranchcode" size="9" value="<%=session("branchcode")%>" readonly><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
            <td width="171" align="right"><font class="textbold">Currency Code</font></td>
            <td width="232"><input name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" readonly><input type="button" value=" L " name="butcur" onclick="currency()"><input name="txtcurrencydesc" size="16" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

            <div align="center">
              <center>

              <table width="90%" cellpadding="0" class="tableborder2">
                <tr>
                  <td>
                  <div align="center">
                    <center>

                    <table border="0" width="100%" cellspacing="0" cellpadding="0" bordercolor="#D9D2B3">
                      <tr>
                        <td width="159" height="10">&nbsp;</td>
                        <td width="219" height="10">&nbsp;</td>
                        <td height="10" width="108">&nbsp;</td>
                        <td width="218" height="10">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="159">&nbsp;&nbsp;&nbsp; Cust. ID</td>
                        <td width="219"><input name="txtCustomerId" size="9" readonly><input type="button" value=" L " name="cmdCustList" onclick="Custlist()"><input name="txtCustomerName" size="15" readonly></td>
                      </center>
                      <td width="108">
                      <p align="left">&nbsp;&nbsp; Address</p>
                      </td>
                      <center>
                      <td><input name="txtAddress1" size="24" onblur="window.document.frmCutSoiledNote.txtaddress2.focus" maxlength="20" class="bgcolor1" readonly></td>
                      </tr>
                      <tr>
                        <td width="159">&nbsp;&nbsp;&nbsp; Recvd From</td>
                        <td width="219"><input name="txtReceivedFrom" size="29" onkeyup="ChngAddStatus()" onblur="window.document.frmCutSoiledNote.txtAddress1.focus,window.document.frmCutSoiledNote.cmdAdd.disabled =false" maxlength="30"></td>
                        <td width="108">&nbsp;</td>
                        <td width="218"><input name="txtaddress2" size="24" onblur="window.document.frmCutSoiledNote.txtaddress3.focus" maxlength="20" class="bgcolor1" readonly></td>
                      </tr>
                      <tr>
                        <td width="159">&nbsp;&nbsp;&nbsp; Denomination&nbsp;&nbsp;</td>
            
                        <!--
            <td width="32%" bgcolor="#c7ba95"><input name="txtDenomination" size="9" style="TEXT-ALIGN: right" onkeypress="numeric()" onblur="window.document.frmCutSoiledNote.txtNoOfNotePiece.focus" maxlength="10"></td>
            -->
                       
                        <td width="219"><select name="txtDenomination">
                        </select></td>
                        <td width="108">&nbsp;</td>
                        <td width="218"><input name="txtaddress3" size="24" disabled maxlength="20" class="bgcolor1" readonly></td>
                      </tr>
                      <tr>
                        <td width="159">&nbsp;&nbsp;&nbsp; No. of cut Note pcs.</td>
                        <td width="219"><input name="txtNoOfNotePiece" size="9" style="TEXT-ALIGN: right" onkeypress="numeric()" onblur="window.document.frmCutSoiledNote.txtCurNoteNo.focus" maxlength="5"></td>
                        <td width="108">&nbsp;&nbsp; Currency&nbsp; No.</td>
                        <td width="218"><input name="txtCurNoteNo" size="24" onblur="window.document.frmCutSoiledNote.txtAmtPaid.focus" maxlength="20"></td>
                      </tr>
                      <tr>
                        <td width="159">&nbsp;&nbsp;&nbsp; Amount Paid&nbsp;&nbsp;</td>
                        <td width="219"><input name="txtAmtPaid" size="9" value="0.00" style="TEXT-ALIGN: right" onblur="precision(window.document.frmCutSoiledNote.txtAmtPaid,window.document.frmCutSoiledNote.hpr.value)" onkeypress="numeric()" maxlength="17" onfocus="amtselect(window.document.frmCutSoiledNote.txtAmtPaid)"></td>
                        <td width="108">&nbsp;&nbsp; Narration</td>
                        <td width="218"><input name="txtnarration" size="24" maxlength="40"></td>
                      </tr>
                      <tr>
                        <td width="710" colspan="4" height="10">&nbsp;</td>
                      </tr>
                    </table>

                    </div>

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="100%" height="10"></td>
                      </tr>
                    </table>

                  </center>
              </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

            </center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

        </table>

      </div>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="10"></td>
        </tr>
        <tr>
          <td width="100%">
          <div align="center">
            <center>

            <table width="40%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="  Add  " disabled name="cmdAdd" onclick="Insert()" class="bgcolor"><input type="button" value="Modify" name="cmdModify" onclick="Modify(),window.document.frmCutSoiledNote.cmdAdd.disabled=false" disabled class="bgcolor"><input type="button" value="Delete" name="cmdDelete" onclick="Delete(),window.document.frmCutSoiledNote.cmdAdd.disabled=false" disabled class="bgcolor"><input type="button" value="  Query  " name="cmdSelect" onclick="CutsoiledNo()" class="bgcolor"><input type="button" value="Cancel" name="cmdCancel" onclick="cancel()" class="bgcolor"><input type="button" value=" Exit " name="cmdCancel" onclick="location.href=&quot;http://comserver/SMARTVER3/cash/cashmodule.asp&quot;" class="bgcolor"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%"></td>
        </tr>
        <tr>
          <td width="100%"></td>
        </tr>
      </table>

  </table>

  <input type="hidden" name="status"><input type="hidden" name="hSoiledNo"><input type="hidden" name="hpr"><input type="hidden" name="hDenom"><input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.asp">
          </iframe>
          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

