<%@ Page Language="vb" CodeBehind="cutSoiledQuery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cutSoiledQuery" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{
  var str
  str= window.document.frmacc.hbno.value
  
    window.attachEvent(window.opener.CutSoiledDisp(str))
  window.close()
 
}
//-->
</SCRIPT>

<%
  str=Request.QueryString("st")
  Response.Write str
  dim con
 ' for i=1 to 2
	con=split(str,"*")
'	next
  dim obj,rec,cnt,acc,rsSoiled,rsCust
  dim CounterNo
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  set rsSoiled=server.CreateObject("adodb.recordset")
  set Rscust=server.CreateObject("adodb.recordset")
  Response.Write str
  set rsSoiled=obj.singleRecordset("CASHCUTNSPOILNOTESMST","CUSTOMERID,RECEIVEDFROM," & _
			"Add1,Add2,Add3,NOOFCUTPIECES,PAIDAMOUNT,NARRATION,DENOMINATION,CURRENCYNOTENO", _
			"branchcode='" & con(0) & "' and currencycode='" & con(1) & "' and " & _
			"CUTSOILTRANNO='" & con(2) & "'")
  Response.Write rsSoiled(0)
  set rsCust=obj.singleRecordset("GENCUSTINFOMST","custname","customerid='" & rsSoiled(0) &"'")
  'Response.Write rssoiled(4)
  if not rsSoiled.EOF and not rsSoiled.bof then
	rsSoiled.MoveFirst
	for i=0 to rsSoiled.Fields.Count - 1
		  acc=acc &"*"& rsSoiled(i) &""
	next
  end if
 acc=acc & "*" & rscust(0) &""
 ''Response.Write acc
'onload='List()'
%>
 
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=acc%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
