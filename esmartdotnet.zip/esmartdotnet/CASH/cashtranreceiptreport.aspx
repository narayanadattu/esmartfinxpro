<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="cashtranreceiptreport.aspx.vb" Inherits="eSmartDotNet.cashtranreceiptreport"%>

<HTML>
	<HEAD>
		<title>STR Alert Generation Report</title>
		<meta http-equiv="Content-Language" content="en-us">
		<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
		<meta name="ProgId" content="FrontPage.Editor.Document">
		<SCRIPT LANGUAGE="javascript">
<!--
function prnt()
{
// hide all the buttons from the printing of report
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
// Print the report 
window.print()
window.document.frmList.butok.style.visibility="visible"
window.document.frmList.butprnt.style.visibility="visible"

}
//-->
		</SCRIPT>
		<%
dim kstr, mainstr
	dim cnt
	dim rsfetch
	dim objfetch
	dim arrtrans(1,4)
	dim objfrm

'width 
wtable = "800"
	wrsno="40"
	wbatchno= "40" 
	wtranno = "60"
	wglcode = "40"
	waccno = "100"
	wname = "200"
	wremarks = "200"
	wamount = "70"
	wcashierid = "70"
	wtokenno =  "80"
 
  
 'Alignment
arsno="left"
abatchno= "left" 
atranno = "right"
aglcode = "right"
aaccno = "left"
aname = "left"
aremarks = "left"
aamount = "right"
acashierid = "left"
atokenno = "right"

'font
fdetdata = "3"
fheaddata = "4"

kstr=Request.QueryString("st")

	if len(kstr)>0 then				'''''' If kstr is not empty string
		kstr=split(kstr,"~")			'''''' Split it
		strwise = trim(kstr(0))
		seldate = trim(kstr(3))
		appdate=session("applicationdate")
		userid=session("userid")	'''''' User id
		brcode=ucase(trim(kstr(1)))	'''''' Branchcode
		crcode=ucase(trim(kstr(2)))	'''''' Currncycode
		StRep = trim(kstr(4))
		stroperator =  kstr(5)
		strAmount =  kstr(6)
	end if
	
	if StRep = "XL" then
		Response.ContentType = "application/vnd.ms-excel"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & "CashRecPay.xls")
	end if	
	
ReportTitle = strwise & "  Report " & seldate

objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 
rs =server.CreateObject("adodb.recordset")
rsaddress=server.CreateObject("adodb.recordset")
RsDate = server.CreateObject("adodb.recordset")

objfetch1 =server.CreateObject("queryrecordsets.fetchrecordsets")

rsaddress=objfetch1.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & brcode & "' and a.bankcode=b.bankcode")

RsDate = objfetch1.SingleRecordSet("GENAPPLICATIONDATEMST", _
            "to_char(APPLICATIONDATE,'dd-Mon-yyyy')", "branchcode='" & BrCode & "'")


if strwise = "Receipts" then
amount = 0

if cdate(rsdate(0).value)=cdate(seldate) then
strmain = " SELECT  B.RECEIPTSCROLLNO RSNO, A.BATCHNO, A.TRANNO, B.GLCODE, ''''||B. ACCNO, substr(initcap(B.NAME),1,30) name,  A.REMARKS,B.AMOUNT," & _
" B.CASHIERID FROM CASHRECEIPTSTRN B,CASHTRANDAY A WHERE B.GLCODE=A.LINKGLCODE AND B.MODULEID=A.LINKMODULEID " & _
" AND B.TRANNO=A.TRANNO AND B.APPLICATIONDATE=A.APPLICATIONDATE AND B.APPLICATIONDATE='" & seldate & "' AND " & _
" A.MODEOFTRAN= 1 AND B.AMOUNT=ABS(A.AMOUNT)  and b.branchcode='" & BrCode & "' AND b.branchcode=a.branchcode and  B.AMOUNT " & stroperator &" " & strAmount &" ORDER BY B.RECEIPTSCROLLNO, " & _
" A.BATCHNO, A.TRANNO"

else
strmain = " SELECT  B.RECEIPTSCROLLNO RSNO, A.BATCHNO, A.TRANNO, B.GLCODE, ''''||B. ACCNO, substr(initcap(B.NAME),1,30) name,  A.REMARKS,B.AMOUNT," & _
" B.CASHIERID FROM CASHRECEIPTSTRNBKP B,CASHTRAN A WHERE B.GLCODE=A.LINKGLCODE AND B.MODULEID=A.LINKMODULEID " & _
" AND B.TRANNO=A.TRANNO AND B.APPLICATIONDATE=A.APPLICATIONDATE AND B.APPLICATIONDATE='" & seldate & "' AND " & _
" A.MODEOFTRAN= 1 AND B.AMOUNT=ABS(A.AMOUNT) and b.branchcode='" & BrCode & "' AND b.branchcode=a.branchcode and  B.AMOUNT " & stroperator &" " & strAmount &"  ORDER BY B.RECEIPTSCROLLNO, " & _
" A.BATCHNO, A.TRANNO"
end if

rsmain = objfetch.SingleSelectStat(strmain)

%>
	</HEAD>
	<body>
		<form name="frmList">
			<table width=<%=wtable%> align="left" border =0>
				<tr>
					<td colspan="9">
						<font color="#000000" size="3">
							<%''''' Report Headings%>
							<center>
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								<br>
								<br>
								<%'''''''Title of the report %>
								<%=ReportTitle%> 
								<br>
							</center>
						</font>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="9">User Id:
						<%=userid %>
						, Currency:
						<%=crcode %>, Date: <%=appdate%>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width=<%=wrsno%> align=<%=arsno%>>
						<font size=<%=fdetdata%>>RsNo</font>
					</td>
					<td width= <%=wbatchno%> align= <%=abatchno%>>
						<font size=<%=fdetdata%>>BtNo</font>
					</td>
					<td width= <%=wtranno %> align= <%=atranno%>>
						<font size=<%=fdetdata%>>TrNo</font>
					</td>
					<td width=<%=wglcode %> align=<%=aglcode%>>
						<font size=<%=fdetdata%>>GlCode</font>
					</td>
					<td width= <%=waccno %> align= <%=aaccno%>>
						<font size=<%=fdetdata%>>AccNo</font>
					</td>
					<td width=<%=wname %> align=<%=aname%> nowrap>
						<font size=<%=fdetdata%>>Name</font>
					</td>
					<td width=<%=wremarks %> align=<%=aremarks%>>
						<font size=<%=fdetdata%>>Remarks</font>
					</td>
					<td width=<%=wamount %> align=<%=aamount%>>
						<font size=<%=fdetdata%>>Amount</font>
					</td>
					<td width=<%=wcashierid %> align=<%=acashierid%>>
						<font size=<%=fdetdata%>>CshrId</font>
					</td>
					
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
<%				
if not rsmain.EOF and not rsmain.BOF then 

      do while not rsmain.EOF 

%>
							<tr>
								<td width= <%=wrsno %> align= <%=arsno %>>
								<font size=<%=fdetdata%>>	<%=rsmain(0).value %> </font>
								</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>
								<font size=<%=fdetdata%>>	<%=rsmain(1).value%> </font>
								</td>
								<td width= <%=wtranno %> align= <%=atranno%>>
									<font size=<%=fdetdata%>><%=rsmain(2).value	%></font>
								</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>
								<font size=<%=fdetdata%>><%=rsmain(3).value %> </font>
								</td>
								<td width= <%=waccno %> align= <%=aaccno%>>
									<font size=<%=fdetdata%>><%=rsmain(4).value	%></font>
								</td>
								<td width=<%=wname %> align=<%=aname%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(5).value %> </font>
								</td>
								<td width=<%=wremarks %> align=<%=aremarks%>>
								<font size=<%=fdetdata%>>	<%=rsmain(6).value %> </font>
								</td>
								<td width=<%=wamount %> align=<%=aamount%>>
								<font size=<%=fdetdata%>>	<%=FormatNumber(iif(isdbnull(rsmain(7).value),0,rsmain(7).value),2) %> </font>
								</td>
								<td width=<%=wcashierid %> align=<%=acashierid%>>
								<font size=<%=fdetdata%>>	<%=rsmain(8).value %> </font>
								</td>
							<%
							amount = amount  + cdbl(iif(isdbnull(rsmain(7).value),0,rsmain(7).value))	
							%>	
								
							</tr>
							<% rsmain.MoveNext 
							 loop
							end if	%>
				<tr>
					
								<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wglcode %> align= <%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>
				<tr>
					<td width="150" colspan="5"><font size=<%=fdetdata%>>
						Totals: </font></td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
			<!--	<td width=<%=wtranno %> align=<%=atranno %>><font size=<%=fdetdata%>><%=cnt%></font></td> -->
			
				<td width=<%=wamount %> align=<%=aamount %>><font size=<%=fdetdata%>><%=FormatNumber(amount,2)%></font></td>					
				</tr>
				<tr>
						<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width=<%=wname %> align=<%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>

				<tr>
					<td colspan="9">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="9">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="4" align="left">
						Verified By / Signature</td>
					<td colspan="5" align="right">
						Approved By / Signature</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						<center><input type="button" value="   Exit   " name="butok" onclick="location.href='frmCashReceiptTrans.aspx'"
								class="bgcolor"> <input type="button" value="  Print   " name="butprnt" onclick="prnt()"></center>
						</FONT></td>
				</tr>
			</table>
		</form>
	</body>
</HTML>
<%else if strwise = "Payments" then %>
<%
amount = 0

if cdate(rsdate(0).value)=cdate(seldate) then

strmain = "SELECT  B.PAYMENTSCROLLNO PSNO,  A.BATCHNO BTNO,A.TRANNO TRNO,A.TOKENNO TKNO,A.GLCODE, ''''||A.ACCNO," & _
" substr(initcap(A.NAME),1,30) name, A.REMARKS,ABS(A.AMOUNT) AMOUNT, A.CASHIERID FROM GENTRANSLOG A," & _
" CASHPAYMENTSTRN B WHERE A.APPLICATIONDATE='" & seldate & "'AND A.MODEOFTRAN=1 AND A.GLCODE<>201000 AND " & _
" A.TRANNO=B.TRANNO AND A.APPLICATIONDATE=B.APPLICATIONDATE AND A.CURRENCYCODE=B.CURRENCYCODE AND " & _  
" A.CASHIERID=B.CASHIERID AND B.BRANCHCODE = '"& BrCode &"' and  A.AMOUNT " & stroperator &" " & strAmount &"  ORDER BY A.CASHIERID, B.PAYMENTSCROLLNO,  A.BATCHNO, A.TRANNO"

else

strmain = "SELECT  B.PAYMENTSCROLLNO PSNO,  A.BATCHNO BTNO,A.TRANNO TRNO,A.TOKENNO TKNO,A.GLCODE, ''''||A.ACCNO," & _
" substr(initcap(A.NAME),1,30) name, A.REMARKS,ABS(A.AMOUNT) AMOUNT, A.CASHIERID FROM GENTRANSLOGBKP A," & _
" CASHPAYMENTSTRNBKP B WHERE A.APPLICATIONDATE='" & seldate & "'AND A.MODEOFTRAN=1 AND A.GLCODE<>201000 AND " & _
" A.TRANNO=B.TRANNO AND A.APPLICATIONDATE=B.APPLICATIONDATE AND A.CURRENCYCODE=B.CURRENCYCODE AND " & _  
" A.CASHIERID=B.CASHIERID AND B.BRANCHCODE = '"& BrCode &"' and  A.AMOUNT " & stroperator &" " & strAmount &" ORDER BY A.CASHIERID, B.PAYMENTSCROLLNO,  A.BATCHNO, A.TRANNO"

end if

rsmain = objfetch.SingleSelectStat(strmain)

%>
	</HEAD>
	<body>
		<form name="frmList">
			<table width=<%=wtable%> align="left" border =0>
				<tr>
					<td colspan="10">
						<font color="#000000" size="3">
							<%''''' Report Headings%>
							<center>
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								<br>
								<br>
								<%'''''''Title of the report %>
								<%=ReportTitle%> 
								<br>
							</center>
						</font>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="10">User Id:
						<%=userid %>
						, Currency:
						<%=crcode %>, Date: <%=appdate%>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width=<%=wrsno%> align=<%=arsno%>>
						<font size=<%=fdetdata%>>PsNo</font>
					</td>
					<td width= <%=wbatchno%> align= <%=abatchno%>>
						<font size=<%=fdetdata%>>BtNo</font>
					</td>
					<td width= <%=wtranno %> align= <%=atranno%>>
						<font size=<%=fdetdata%>>TrNo</font>
					</td>
					<td width= <%=wtokenno %> align= <%=atokenno%>>
						<font size=<%=fdetdata%>>TkNo</font>
					</td>
					<td width=<%=wglcode %> align=<%=aglcode%>>
						<font size=<%=fdetdata%>>GlCode</font>
					</td>
					<td width= <%=waccno %> align= <%=aaccno%>>
						<font size=<%=fdetdata%>>AccNo</font>
					</td>
					<td width=<%=wname %> align=<%=aname%>>
						<font size=<%=fdetdata%>>Name</font>
					</td>
					<td width=<%=wremarks %> align=<%=aremarks%>>
						<font size=<%=fdetdata%>>Remarks</font>
					</td>
					<td width=<%=wamount %> align=<%=aamount%>>
						<font size=<%=fdetdata%>>Amount</font>
					</td>
					<td width=<%=wcashierid %> align=<%=acashierid%>>
						<font size=<%=fdetdata%>>CshrId</font>
					</td>
					
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
<%				
if not rsmain.EOF and not rsmain.BOF then 

      do while not rsmain.EOF 

%>
							<tr>
								<td width= <%=wrsno %> align= <%=arsno %>>
								<font size=<%=fdetdata%>>	<%=rsmain(0).value %> </font>
								</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>
								<font size=<%=fdetdata%>>	<%=rsmain(1).value%> </font>
								</td>
								<td width= <%=wtranno %> align= <%=atranno%>>
									<font size=<%=fdetdata%>><%=rsmain(2).value	%></font>
								</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>
									<font size=<%=fdetdata%>><%=rsmain(3).value	%></font>
								</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>
								<font size=<%=fdetdata%>><%=rsmain(4).value %> </font>
								</td>
								<td width= <%=waccno %> align= <%=aaccno%>>
									<font size=<%=fdetdata%>><%=rsmain(5).value	%></font>
								</td>
								<td width=<%=wname %> align=<%=aname%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(6).value %> </font>
								</td>
								<td width=<%=wremarks %> align=<%=aremarks%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(7).value %> </font>
								</td>
								<td width=<%=wamount %> align=<%=aamount%>>
								<font size=<%=fdetdata%>>	<%=FormatNumber(iif(isdbnull(rsmain(8).value),0,rsmain(8).value),2) %> </font>
								</td>
								<td width=<%=wcashierid %> align=<%=acashierid%>>
								<font size=<%=fdetdata%>>	<%=rsmain(9).value %> </font>
								</td>
							<%
							amount = amount  + cdbl(iif(isdbnull(rsmain(8).value),0,rsmain(8).value))	
							%>	
								
							</tr>
							<% rsmain.MoveNext 
							 loop
							end if	%>
				<tr>
					
								<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>&nbsp;</td>
								<td width= <%=wglcode %> align= <%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>
				<tr>
					<td width="150" colspan="6"><font size=<%=fdetdata%>>
						Totals: </font></td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
			<!--	<td width=<%=wtranno %> align=<%=atranno %>><font size=<%=fdetdata%>><%=cnt%></font></td> -->
			
				<td width=<%=wamount %> align=<%=aamount %>><font size=<%=fdetdata%>><%=FormatNumber(amount,2)%></font></td>					
				</tr>
				<tr>
						<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>&nbsp;</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width=<%=wname %> align=<%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>

				<tr>
					<td colspan="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="5" align="left">
						Verified By / Signature</td>
					<td colspan="5" align="right">
						Approved By / Signature</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						<center><input type="button" value="   Exit   " name="butok" onclick="location.href='frmCashReceiptTrans.aspx'"
								class="bgcolor"> <input type="button" value="  Print   " name="butprnt" onclick="prnt()"></center>
						</FONT></td>
				</tr>
			</table>
		</form>
	</body>
</HTML>


<%end if%>