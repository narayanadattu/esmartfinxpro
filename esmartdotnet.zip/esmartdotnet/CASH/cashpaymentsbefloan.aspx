<%@ Page CodeBehind="cashpaymentsbefloan.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashpaymentsbefloan" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Payments</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>"></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>"></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>"></script>
<SCRIPT LANGUAGE=javascript src="trnClear.js"></SCRIPT>

<script language="Javascript">

//----------------------------------------------------------------------------------   
   var CrDrMode,CrDrDesc,blnMinBal,ChqYN,brCode,brDesc,curCode,curDesc,cashGlCode,cashGldesc
   function TranMode(){
     {
      CrDrMode="1"
      CrDrDesc="Cash"
      GlCode()
      }
   } 
//----------------------------------------------------------------------------------
  
 function display(str){
	var balstr=new String();
	balstr=str.split("|");
	window.document.frmTrans.txtClrBal.value=balstr[0];
	precision(window.document.frmTrans.txtClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtUnClrBal.value=balstr[1];
	precision(window.document.frmTrans.txtUnClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtNetBal.value=balstr[2];
	precision(window.document.frmTrans.txtNetBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtCustId.value=balstr[3];
	window.document.frmTrans.txtOpaBy.value=balstr[4];
	window.document.frmTrans.txtOpInstr.value=balstr[5];
 }
//----------------------------------------------------------------------------------
 function branch()
 {     
       brCode=window.document.frmTrans.txtbranchcode.value  
       brDesc=window.document.frmTrans.txtbranchdesc.value 
       window.document.frmTrans.trntype.checked=false
	   st="Branch";
	   window.open("List.asp" + "?"+"st="+st,st,"width=200%,height=150% left=100 top=170");
 }
 
//---------------------------------------------------------------------------------- 
 function curr()
 {   curCode=window.document.frmTrans.txtcurrencycode.value
	 curDesc=window.document.frmTrans.txtcurrencydesc.value
	 window.document.frmTrans.trntype.checked=false
     st="Curr";	 
	 window.open("List.asp" + "?"+"st="+st,st,"width=250%,height=150% left=520 top=170");
 }
//----------------------------------------------------------------------------------
 
 function module()
 {  
	 st="Module"
	 window.document.frmTrans.trntype.checked=false
	 window.open("List.asp?st="+st,st,"width=250%,height=150% left=60 top=50");
 }
//---------------------------------------------------------------------------------- 
 
function Glcode()
{  
	st="Glcode";
	atype=window.document.frmTrans.txtModId.value;
	if(atype!=""){
		 window.open("List.asp?st="+st+"&atype="+atype,st,"width=250%,height=150% left=60 top=300");
	 } 
}
//---------------------------------------------------------------------------------- 
 function AccCode()
{  
    st="Accno"
    brchCd=window.document.frmTrans.txtbranchcode.value;
    GlCd=window.document.frmTrans.txtGLcode.value;
    ModId=window.document.frmTrans.txtModId.value;
    if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
   	window.open("List.asp?st="+st+"&atype="+GlCd+"&Modid="+ModId+"&brchCd="+brchCd,st,"width=250%,height=150%")
 }
//----------------------------------------------------------------------------------	
function Accnoid(str)
 { 
    var strnew;
    strnew=str.split("-----")
	window.document.frmTrans.txtAccNm.value =strnew[0]
	window.document.frmTrans.txtAccNo.value =strnew[1]
	AmtNarrClear()//TO CLEAR AMOUNT AND NARRATION
	balanceDet() 
	
 } 	 
//----------------------------------------------------------------------------------	
function currency(str)
{ var k
    k=str.split("-----")
	window.document.frmTrans.txtcurrencydesc.value =k[0]
	window.document.frmTrans.txtcurrencycode.value =k[1]
	 ClearAlert("Cur")
	 prn=k[2].length-1
     window.document.frmTrans.hpr.value=prn
}	
	 
//----------------------------------------------------------------------------------
	
function Glcodeid(str)
 { 
	  assign(str,window.document.frmTrans.txtGLname,window.document.frmTrans.txtGLcode)
	  AccountClear();
 } 	 
//----------------------------------------------------------------------------------
	 
function Branchid(str)
 { 
	  assign(str,window.document.frmTrans.txtbranchdesc,window.document.frmTrans.txtbranchcode)
	  ClearAlert("Brn")
 } 
//----------------------------------------------------------------------------------

function Moduleid(str)
 {
	assign(str,window.document.frmTrans.txtModNm,window.document.frmTrans.txtModId);
	GLClear()
 } 	
//----------------------------------------------------------------------------------
	
///********** Cash Mode Display Validation ****************
function cashMode(){
	     TranMode()
	     ModuleClear()//clear module and 
	     Cls()
	     grid()
 }	     
//----------------------------------------------------------------------------------

//************** CHEQUE VALIDATION  ********************
function Cheque(){
	if(window.document.frmTrans.trntype.checked==true)
		window.document.all['ChqDtl'].style.display="block";
	if(window.document.frmTrans.trntype.checked==false)
		window.document.all['ChqDtl'].style.display="none";	
		window.document.frmTrans.txtChqNo.value ="";
		window.document.frmTrans.txtChqDt.value ="";
		window.document.frmTrans.txtChqFVG.value ="";
		
}
//----------------------------------------------------------------------------------
function display(str){
	var balstr=new String();
	balstr=str.split("|");
	window.document.frmTrans.txtClrBal.value=balstr[0];
	precision(window.document.frmTrans.txtClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtUnClrBal.value=balstr[1];
	precision(window.document.frmTrans.txtUnClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtNetBal.value=balstr[2];
	precision(window.document.frmTrans.txtNetBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtCustId.value=balstr[3];
	window.document.frmTrans.txtOpaBy.value=balstr[4];
	window.document.frmTrans.txtOpInstr.value=balstr[5];
  }
//---------------------------------------------------------------------------------- 
//********* Denomination pieces Joinning  *************************

function frmSub(){
    if(window.document.frmTrnsMain.Mfgpaydt.Rows<2){ 
   	if(window.document.frmTrans.txtAmt.value=="")
	    window.document.frmTrans.txtAmt.value="0.00";
	    
	if((window.document.frmTrans.txtbranchcode.value!="") &&
		(window.document.frmTrans.txtcurrencycode.value!="") &&
		(window.document.frmTrans.txtModId.value!="") &&
		(window.document.frmTrans.txtGLcode.value!="") &&
		(window.document.frmTrans.txtAccNo.value!="") &&
		(window.document.frmTrans.txtAmt.value!="") &&
		(window.document.frmTrans.txtTokenNo.value!=""))
      {
        ChqDtls();
        if(ChqYN!="Y")
      {  
        var paymode;
		    paymode="CH"
		var payType="Pay" //this function used to populate account details in to the Flexgrid	
	if(blnMinBal=="YES"){		
	        window.document.frmTrans.trntype.checked=false
			var strinsert=insertStrForm()// //call function for concating insert string
			
			if(window.document.frmTrnsMain.Mfgpaydt.Rows<2){
			   window.open("branchNoGen.asp?strIn="+strinsert+"&flag=&paymode="+paymode+"&PayType="+payType,"branch","width=20 height=20")//openning window for genarate BatchNo and trn No  	
			}
			else if(window.document.frmTrnsMain.Mfgpaydt.Rows>=2){ //openning window for genarate BatchNo and trn No 
				var bacthNo=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,0) 
				window.open("branchNoGen.asp?strIn="+strinsert+"&flag="+bacthNo+"&paymode="+paymode+"&PayType="+payType,"bran","width=400 height=400");		
		 }	
		}   
      }
        
		else 
		   {    
		   alert("Enter Cheque Details");
		   }
		   }
 else{   
   alert("Mandatory fields cannot be null");    
     }	
 }
 }
//----------------------------------------------------------------------------------

function insertStrForm(){
    var trnModVal="1"
	var strValues=window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+
		window.document.frmTrans.txtModId.value+"~"+window.document.frmTrans.txtGLcode.value+"~"+window.document.frmTrans.txtAccNo.value+"~"+
		window.document.frmTrans.txtCustId.value+"~"+window.document.frmTrans.txtAmt.value+"~"+
		trnModVal+"~"+window.frmTrans.txtClrBal.value+"~P~"+
		window.document.frmTrans.txtNarran.value+"~"+cashGlCode+"~";
    	return strValues;	
}

//----------------------------------------------------------------------------------

function FlexPopulate(str1,str2)
{
   if(eval(window.document.frmTrans.txtAmt.value==0))
   {
    alert("Amount should not be equal to zero")
   }
   else
   { 
   with(window.document.frmTrnsMain.Mfgpaydt){
   var flxRowCnt=Rows
   {
	   Rows=flxRowCnt+2

	  var genStr=str1.split('~')   
             //Creidit Details
			//************* Branch details send to flexgrid   ****************
		TextMatrix(flxRowCnt,0)=genStr[0];
		TextMatrix(flxRowCnt,1)=genStr[1];
		TextMatrix(flxRowCnt,8)=genStr[2];
		TextMatrix(flxRowCnt,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt,14)=window.document.frmTrans.txtcurrencycode.value
		//************* GL no,amount and moduleid etc... details send to flexgrid   ****************
		TextMatrix(flxRowCnt,19)=window.document.frmTrans.txtModId.value;
		TextMatrix(flxRowCnt,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt,2)=window.document.frmTrans.txtGLcode.value;
		TextMatrix(flxRowCnt,3)=window.document.frmTrans.txtGLname.value;
		TextMatrix(flxRowCnt,4)=window.document.frmTrans.txtAccNo.value;
		TextMatrix(flxRowCnt,5)=window.document.frmTrans.txtAccNm.value;
		Col=6;
		Row=flxRowCnt;
		CellForeColor=210,2,2;
		TextMatrix(flxRowCnt,6)='-'+window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt,21)=window.document.frmTrans.txtTokenNo.value;
		TextMatrix(flxRowCnt,22)=window.document.frmTrans.txtNarran.value;
		TextMatrix(flxRowCnt,23)=window.document.frmTrans.txtChqSrs.value;
		TextMatrix(flxRowCnt,24)=window.document.frmTrans.txtChqNo.value;
		TextMatrix(flxRowCnt,25)=window.document.frmTrans.txtChqDt.value;
		TextMatrix(flxRowCnt,26)=window.document.frmTrans.txtChqFVG.value;
		TextMatrix(flxRowCnt,9)=window.document.frmTrans.txtCustId.value;
					
			    TextMatrix(flxRowCnt,10)=CrDrMode  //window.document.frmTrans.trnMode(i).value; 
				TextMatrix(flxRowCnt+1,10)=CrDrMode //window.document.frmTrans.trnMode(i).value; 
				TextMatrix(flxRowCnt,11)=CrDrDesc  
				TextMatrix(flxRowCnt+1,11)=CrDrDesc
		
		TextMatrix(flxRowCnt,12)='P';
		TextMatrix(flxRowCnt+1,12)='P';
		TextMatrix(flxRowCnt,13)='Pending';
		TextMatrix(flxRowCnt+1,13)='Pending';
		
 //Debit details 
				var genStr1=str2.split("~")
				TextMatrix(flxRowCnt+1,0)=genStr1[0];
				TextMatrix(flxRowCnt+1,1)=genStr1[1];
				TextMatrix(flxRowCnt+1,8)=genStr1[2];
						
		
		TextMatrix(flxRowCnt+1,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt+1,14)=window.document.frmTrans.txtcurrencycode.value
	  	TextMatrix(flxRowCnt+1,19)="CASH";    //window.document.frmTrans.txtModId.value;
		TextMatrix(flxRowCnt+1,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt+1,2)=cashGlCode;
		TextMatrix(flxRowCnt+1,3)=cashGldesc;
		TextMatrix(flxRowCnt+1,4)="1";
		TextMatrix(flxRowCnt+1,5)=cashGldesc;
		Col=6;
		Row=flxRowCnt+1;
		CellForeColor=52,17,253;
		TextMatrix(flxRowCnt+1,6)=window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt+1,22)=window.document.frmTrans.txtNarran.value;
		TextMatrix(flxRowCnt+1,23)=window.document.frmTrans.txtChqSrs.value;
		TextMatrix(flxRowCnt+1,24)=window.document.frmTrans.txtChqNo.value;
		TextMatrix(flxRowCnt+1,25)=window.document.frmTrans.txtChqDt.value;
		TextMatrix(flxRowCnt+1,26)=window.document.frmTrans.txtChqFVG.value;
		TextMatrix(flxRowCnt+1,21)=window.document.frmTrans.txtTokenNo.value;
		TextMatrix(flxRowCnt+1,9)=window.document.frmTrans.txtCustId.value;
		
		window.document.frmTrnsMain.txtTotCredit.value=eval(window.document.frmTrnsMain.txtTotCredit.value)+eval(window.document.frmTrans.txtAmt.value);
		window.document.frmTrnsMain.txtTotDebit.value=eval(window.document.frmTrnsMain.txtTotDebit.value)+eval(window.document.frmTrans.txtAmt.value);
		window.document.frmTrnsMain.txtDiff.value=eval(window.document.frmTrnsMain.txtTotCredit.value)-eval(window.document.frmTrnsMain.txtTotDebit.value);
	}	
		precision(window.document.frmTrnsMain.txtTotCredit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtTotDebit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtDiff,window.document.frmTrans.hpr.value)
		
	ModuleClear();//to clear module and thier child fields	
	Cls();
	NoofAcc();
		      	 		
  }		
 }
}
//----------------------------------------------------------------------------------
function Cancel()
{
 cashMode()
 window.document.frmTrnsMain.Mfgpaydt.Clear();
 window.document.frmTrnsMain.Mfgpaydt.FormatString=">Batch No  |>Tran No   |<GlCode        |<Gl Description                   |>Acc No         |<Name                           |>Amount            |>Entered Time Bal |^Process Date   |<Cust Id               | |<Mode of Tran  ||<Status  |>Currency Code     |<Entered By             |<Enterd M/c             |<Approved By               |<Approved M/c         |<Module Id         |<Branch Code            |>Token No   |<Remarks                           |<Cheque Series  |>Cheque No             |^Cheque Date   |<Cheque Favouring         | | | | | | | | | | | | | | |>Counter No.  |<Cashier Id.          |>Scroll No. ";
 window.document.frmTrnsMain.Mfgpaydt.Rows=1;
 window.document.frmTrnsMain.txtTotCredit.value ="0.00"; 
 window.document.frmTrnsMain.txtTotDebit.value ="0.00";
 window.document.frmTrnsMain.NoDrTrn.value="0";
 window.document.frmTrnsMain.NoCrTrn.value="0";
 Flex()
 TempTranslog()
}
//----------------------------------------------------------------------------------

function NoofAcc()
{
  var NoCrAcc;
  var NoDrAcc;
      NoCrAcc=0;
      NoDrAcc=0;
 
  for(i=1;i<window.document.frmTrnsMain.Mfgpaydt.Rows;i++){
        if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,6))>0)
        {
          NoCrAcc=NoCrAcc+1;
          window.document.frmTrnsMain.NoCrTrn.value=NoCrAcc;
        }
          else
        {  
          NoDrAcc=NoDrAcc+1;   
          window.document.frmTrnsMain.NoDrTrn.value=NoDrAcc;
        }  
     }
 }  
      
//----------------------------------------------------------------------------------
function SubPost(){
if(window.document.frmTrnsMain.Mfgpaydt.Rows>1)
{
 var crDbDiff=eval(window.document.frmTrnsMain.txtTotCredit.value)-Math.abs(eval(window.document.frmTrnsMain.txtTotDebit.value));
 var actDiff=eval(window.document.frmTrnsMain.txtDiff.value); 
 if(crDbDiff==actDiff){
	RowCnt=window.document.frmTrnsMain.Mfgpaydt.Rows;
	ColCnt=window.document.frmTrnsMain.Mfgpaydt.Cols;
    var strRow="";
    var strTot="";
    for(i=1;i<RowCnt;i++){
		 strRow=""
		for(j=0;j<ColCnt;j++){
		 strRow=strRow+window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,j)+"~";    
		 } 
		 strTot=strTot+strRow+"|";
    }
      window.location.href="TrnInsert.asp?str="+strTot;
  }
 else{
	alert("Credit Amount and Debit Amount Should be Equal");
  } 
}
}
//----------------------------------------------------------------------------------

function Flex(){
       blnMinBal="YES"
window.document.frmTrnsMain.Mfgpaydt.ColWidth(2)=0;
window.document.frmTrnsMain.Mfgpaydt.ColWidth(10)=0;
window.document.frmTrnsMain.Mfgpaydt.ColWidth(12)=0;
}
//---------------------------------------------------------------------------------- 
function Allot(minBal,ChqNo,ChqSer,ChqDt,Rslt,Gcode)
   {
      if(minBal!=="")
         {
          MinBalVerify(minBal)
         }
      else if(ChqNo!=="")
         {
          ChqVerification(ChqNo)
         } 
      else if(ChqSer!=="")
         {
          ChqSerVerification(ChqSer)
         }
      else if(Rslt!=="")
         {
          DelTempTranslog(Rslt)
         }   
      else if(ChqDt!=="")
         {
          ChqDateVerify(ChqDt)
         } 
      else if(Gcode!=="")
         {
          CshCode(Gcode)
         }
    }   
//---------------------------------------------------------------------------------- 

 function MinBalVerify(minBal)
 { 
   var clBal=window.document.frmTrans.txtClrBal.value;
   var wdAmt=window.document.frmTrans.txtAmt.value;
   var Balance=clBal-wdAmt;
   var confm
   
        if(Balance<minBal)
         {
          if(Balance==0)
          {
          confm=confirm("Balance is 0. Do you want to close the account?")
          if(confm==true)
            {
             blnMinBal="YES"
            }
            else
            {
             blnMinBal="NO"
            }  
          }
          else
         {
          confm=confirm("Amount less than Minimum Balance? Do You want to continue")
          if(confm==true)
             {
               blnMinBal="YES"
             }
             else
            {
               blnMinBal="NO"
             }
          }
         }
  }     

//----------------------------------------------------------------------------------
function DelTran()
{
  if(window.document.frmTrnsMain.Mfgpaydt.Rows>1){
    strpm="";
    strpm="DEL"+"~"+window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,0);
	 window.open("minBalChk.asp?strparam="+strpm,"Delete","width=20 height=20");
	 }
}
//----------------------------------------------------------------------------------
function balanceDet()
{
	var str="";
	str=window.document.frmTrans.txtbranchcode.value+"~";
	str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	str=str+window.document.frmTrans.txtModId.value+"~";
    str=str+window.document.frmTrans.txtGLcode.value+"~";    
	str=str+window.document.frmTrans.txtAccNo.value+"~";
	window.open("balDetDisplay.asp?str="+str,"bal","width=250%,height=150%");
} 	 
//----------------------------------------------------------------------------------
function MinBalCheck()
 {
  var strprm="";
      strprm="MIN"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
      strprm=strprm+window.document.frmTrans.txtModId.value+"~";
      strprm=strprm+window.document.frmTrans.txtcurrencycode.value+"~";
      window.open("minBalChk.asp?strparam="+strprm,"MinBal","width=20 height=20");
 }  
//----------------------------------------------------------------------------------
 
function ChqDtls()
 {
 if(window.document.frmTrans.trntype.checked==true)
   
   {
   if((window.document.frmTrans.txtChqSrs.value.length>0)&&
    (window.document.frmTrans.txtChqNo.value.length>0)&&
    (window.document.frmTrans.txtChqDt.value.length>0)&&
    (window.document.frmTrans.txtChqFVG.value.length>0))
   {
      ChqYN="N";
      }
    else
      {
      ChqYN="Y";
      }  
   }
  else if (window.document.frmTrans.trntype.checked==false) 
   {
      ChqYN="N";
   }
 } 
//----------------------------------------------------------------------------------

function ChqValidation()
{
  if((window.document.frmTrans.txtbranchcode.value!="") &&
		(window.document.frmTrans.txtcurrencycode.value!="") &&
		(window.document.frmTrans.txtModId.value!="") &&
		(window.document.frmTrans.txtGLcode.value!="") &&
		(window.document.frmTrans.txtAccNo.value!="") &&
		(window.document.frmTrans.txtAmt.value!="") &&
		(window.document.frmTrans.txtTokenNo.value!="") &&
		(window.document.frmTrans.txtChqSrs.value!="")){
  if(window.document.frmTrans.txtChqNo.value.length>0){
     srt="";
     str="CHQN"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
	 str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	 str=str+window.document.frmTrans.txtModId.value+"~";
     str=str+window.document.frmTrans.txtGLcode.value+"~";    
	 str=str+window.document.frmTrans.txtAccNo.value+"~";
	 str=str+window.document.frmTrans.txtChqNo.value+"~";
	 window.open("minBalChk.asp?strparam="+str,"Select","width=1% height=1% left=1 top=1");
  }
  }
  else if(window.document.frmTrans.txtChqSrs.value=="")
     {
      alert("Cheque Series should be entered")
      window.document.frmTrans.txtChqNo.value=""
     }
}
//----------------------------------------------------------------------------------
function ChqSerValidation()
{
 if((window.document.frmTrans.txtbranchcode.value!="") &&
		(window.document.frmTrans.txtcurrencycode.value!="") &&
		(window.document.frmTrans.txtModId.value!="") &&
		(window.document.frmTrans.txtGLcode.value!="") &&
		(window.document.frmTrans.txtAccNo.value!="") &&
		(window.document.frmTrans.txtAmt.value!="") &&
		(window.document.frmTrans.txtTokenNo.value!=""))
  if(window.document.frmTrans.txtChqSrs.value.length>0){
     srt="";
     str="CHQS"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
	 str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	 str=str+window.document.frmTrans.txtModId.value+"~";
     str=str+window.document.frmTrans.txtGLcode.value+"~";    
	 str=str+window.document.frmTrans.txtAccNo.value+"~";
	 str=str+window.document.frmTrans.txtChqSrs.value+"~";
	 window.open("minBalChk.asp?strparam="+str,"Select","width=1% height=1% left=1 top=1");
  }
}
//----------------------------------------------------------------------------------
function ChqVerification(ChqNo)
 {
   if(ChqNo=="NOTVALID")
     {
      alert("Not a Valid Cheque")
      window.document.frmTrans.txtChqNo.value=""
     }
 }
//----------------------------------------------------------------------------------
function ChqSerVerification(ChqSer)
 {
   if(ChqSer=="NOTVALID")
     {
      alert("Not a Valid Series")
      window.document.frmTrans.txtChqSrs.value=""
     }
 }
//---------------------------------------------------------------------------------- 
function ClearAlert(code)
  {
   if(window.document.frmTrnsMain.Mfgpaydt.Rows>1)
     { 
      var confm
      if(code=="Cur")
         {
         confm=confirm("Chaning of Currency Code  at this stage will loose already entered data..."
         +"\n"+"\n"+"Do you want to Continue ?")
         if(confm==true)
            {
               Cancel()
             }  
         else if(confm==false)
            {                 
               window.document.frmTrans.txtcurrencycode.value=curCode
	           window.document.frmTrans.txtcurrencydesc.value=curDesc
            }   
         }
      else if(code=="Brn")
         { 
         confm=confirm("Chaning of Branch Code at this stage will loose already entered data..."
         +"\n"+"\n"+"Do you want to Continue ?")
         if(confm==true)
           {
              Cancel()
           }
         else if(confm==false)
            {                 
               window.document.frmTrans.txtbranchcode.value=brCode
	           window.document.frmTrans.txtbranchdesc.value=brDesc
            }     
         }
      } 
    else
      {
       ModuleClear()
       Cls()
      }         
 }
//----------------------------------------------------------------------------------
function TempTranslog()
{
var strprm="";
      if((window.document.frmTrans.txtbranchcode.value.length>0)&&
        (window.document.frmTrans.txtcurrencycode.value.length>0)&&
        (window.document.frmTrans.txtModId.value.length>0)&& 
        (window.document.frmTrans.txtGLcode.value.length>0)&&
        (window.document.frmTrans.txtAccNo.value.length>0))
      {
      strprm=window.document.frmTrans.txtbranchcode.value+"~";
      strprm=strprm+window.document.frmTrans.txtcurrencycode.value+"~";
      strprm=strprm+window.document.frmTrans.txtModId.value+"~";
      strprm=strprm+window.document.frmTrans.txtGLcode.value+"~";
      strprm=strprm+window.document.frmTrans.txtAccNo.value+"~";
      strprm=strprm+CrDrMode+"~";
      window.open("temptraninsrt.asp?st="+strprm,"Translog","width=1% height=1%");
      }
}
//----------------------------------------------------------------------------------
function TempTranslogpop(strdata)
{
 alert(strdata);
 var K,i,m,b,pos,j,h,n,p,s
	for(m=1;m<=2;m++){
	b=strdata.split("$")
	}
	 st=b[0]
	 	window.document.frmTrans.mfgTranslog.Rows = eval(b[1])+1
		window.document.frmTrans.mfgTranslog.Cols=b[2]

	for(p=1;p<=b[1];p++){
	      n=st.split("|")
	     if(b[1]>0){
			 for(j=0;j<b[2]-1;j++){
				k=n[p-1].split("~")
				window.document.frmTrans.mfgTranslog.TextMatrix(p,j)=k[j]
			 }
		  }
	}
}
//----------------------------------------------------------------------------------
function ChqDateVald()
{
  
  if(window.document.frmTrans.txtChqDt.value.length>0){
     var srt="";
     str="DTVL"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
	 str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	 str=str+window.document.frmTrans.txtModId.value+"~";
     str=str+window.document.frmTrans.txtGLcode.value+"~";    
     str=str+window.document.frmTrans.txtChqDt.value+"~";
     window.open("minBalChk.asp?strparam="+str,"DateVal","width=1% height=1% left=1 top=1");
     
  }
}
//----------------------------------------------------------------------------------
function ChqDateVerify(chqVldDt)
{
  if(chqVldDt=="INVALID")
     {   
        alert("Cheque has been Expired");
        window.document.frmTrans.DtpChq.Value=null
        window.document.frmTrans.txtChqDt.value=""
     }   
}

//----------------------------------------------------------------------------------
function flexClick()
{
  var batchno=""
  var strpm="";
  var cnfrm
      if(window.document.frmTrans.mfgTranslog.Rows>1){
      if((window.document.frmTrans.mfgTranslog.TextMatrix
         (window.document.frmTrans.mfgTranslog.Row,0)!="")&&
         (window.document.frmTrans.mfgTranslog.Rows>1)){
          batchno=window.document.frmTrans.mfgTranslog.TextMatrix
         (window.document.frmTrans.mfgTranslog.RowSel,0)
       cnfrm=confirm("Do you want to Delete Batch No  "+batchno)
			if(cnfrm==true)
			 {  
			 strpm="DELTR"+"~"+batchno;
			 window.open("minBalChk.asp?strparam="+strpm,"DelTrans","width=20 height=20");
			 }
			else
			 {
		   } 
         }
     }    
 }
//----------------------------------------------------------------------------------
function DelTempTranslog(Rst)
{ 
  var balstr=new String();
	  balstr=Rst.split("|")
	  if(balstr[0]="DEL")
	     { 
             for(i=1;i<window.document.frmTrnsMain.Mfgpaydt.Rows;i++){
                 if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,0))>0)
                {
                  if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,0))==balstr[1])
                  {
                   Cancel();
                   alert("Batch No : "+balstr[1]+" is Deleted");   
                  }
                }
             } 
             TempTranslog()  
         }
       else
         {
          alert("Cannot Delete this Batch");
         } 
}
//----------------------------------------------------------------------------------
function Cls()
{
   window.document.frmTrans.txtTokenNo.value="";
   window.document.all['ChqDtl'].style.display="none";
}
//----------------------------------------------------------------------------------
function grid()
{
 window.document.frmTrans.mfgTranslog.Clear();
 window.document.frmTrans.mfgTranslog.FormatString=">Batch No  |>Tran No   |<GlCode        |<Gl Description                   |>Acc No         |>Amount            |>Entered Time Bal |^Process Date   |<Cust Id               |<Mode of Tran  |<Status  |>Currency Code     |<Entered By             |<Enterd M/c             |<Approved By               |<Approved M/c         |<Module Id         |<Branch Code            |>Token No   |<Remarks                           ";
 window.document.frmTrans.mfgTranslog.Rows=1;
}
//----------------------------------------------------------------------------------
function GlCode()
{
var str="";
if((window.document.frmTrans.txtbranchcode.value.length>0)&&
   (window.document.frmTrans.txtcurrencycode.value.length>0)){
     str="CASHGL"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
	 str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	 window.open("minBalChk.asp?strparam="+str,"cashGL","width=1% height=1% left=1 top=1");
  }
}
//----------------------------------------------------------------------------------
function CshCode(code)
 {
   var strVal;
   if(code!=="NOGLCODE")
     {
     strVal=code.split("~");
     cashGlCode=strVal[0];
     cashGldesc=strVal[1];
     }
 }
//----------------------------------------------------------------------------------
</script>
<SCRIPT LANGUAGE=javascript FOR=mfgTranslog EVENT=dblClick>
<!--
 flexClick();
//-->
</SCRIPT>
 
</script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function DtpChq_Change() 
{
  Datepick(window.document.frmTrans.DtpChq,window.document.frmTrans.txtChqDt)
  window.document.frmTrans.txtChqDt.focus()
}

//-->
</SCRIPT>


<SCRIPT LANGUAGE=javascript FOR=DtpChq EVENT=Change>
<!--
 DtpChq_Change()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Flex();cashMode()">

<form name="frmTrans">

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tbody>
      <tr>
        <td width="100%">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="11%"></td>
            <td width="89%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%"><img border="0" height="22" name="placeholder" src="transparent.gif" width="1"></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="100%" nowrap height="25">
            <p align="center"><font class="text">Cash Payments</font></p>
            </td>
          </tr>
        </table>

        <table align="center" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font class="textblue">
            <p align="center"><%=Request.QueryString("record")%></font></td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0" height="27">
          <tr class="bgcolor">
            <td width="80" height="27"><font class="textbold">&nbsp;Branch Code</font></td>
            <td width="289" height="27"><input name="txtbranchcode" size="9" value="0001" readonly><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" value="Main Branch" readonly></td>
            <td width="160" align="right" height="27"><font class="textbold">Currency
            Code&nbsp;&nbsp; &nbsp;</font></td>
            <td width="227" height="27"><input name="txtcurrencycode" value="INR" size="9" readonly><input type="button" value=" L " name="buttcur" onclick="curr()"><input name="txtcurrencydesc" size="16" value="INDIAN RUPEES" readonly></td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="48%" height="10"></td>
            <td width="55%" valign="top" height="10"></td>
          </tr>
          <tr>
            <td width="48%" rowspan="3" valign="top">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="66" height="26">&nbsp;Module ID</td>
                <td width="261" colspan="2" height="26"><input name="txtModId" size="11" readonly><input type="button" value=" L " name="B1" onclick="module()"><input name="txtModNm" size="14" readonly></td>
              </tr>
              <tr>
                <td width="66" height="26">&nbsp;GL Code</td>
                <td width="261" colspan="2" height="26"><input name="txtGLcode" size="11" readonly><input type="button" value=" L " name="B2" onclick="Glcode()"><input name="txtGLname" size="14" readonly></td>
              </tr>
              <tr>
                <td width="66" height="26">&nbsp;Acct No</td>
                <td width="261" colspan="2" height="26"><input name="txtAccNo" size="11" readonly><input type="button" value=" L " name="B3" onclick="AccCode()"><input name="txtAccNm" size="14" readonly></td>
              </tr>
              <tr>
                <td width="66" height="26">&nbsp;Amount</td>
                <td width="259" height="26" colspan="2"><input name="txtAmt" size="18" onkeypress="numdec(window.document.frmTrans.txtAmt.value)" onblur="precision(window.document.frmTrans.txtAmt,window.document.frmTrans.hpr.value);MinBalCheck()" style="TEXT-ALIGN: right"></td>
              </tr>
              <tr>
                <td width="66" height="26">&nbsp;Token No</td>
                <td width="85" height="26"><input name="txtTokenNo" size="11" onkeypress="numeric()"></td>
                <td width="174" 29%? 26?><input type="checkbox" value="chq" name="trntype" onclick="Cheque()"><font face="MS Sans Serif" size="1">Cheque</font></td>
              </tr>
              <tr>
                <td width="66" height="26">&nbsp;Narration</td>
                <td width="261" colspan="2" height="26"><input name="txtNarran" size="30"></td>
              </tr>
              <tr>
                <td width="66" height="26"></td>
                <td width="261" colspan="2" height="26"></td>
              </tr>
            </table>

            </td>
            <td width="55%" valign="top">
            <div id="trnsfer" style="DISPLAY: block; HEIGHT: 158px; WIDTH: 429px">

              <table align="right" cellpadding="0" cellspacing="0" width="0" height="0" class="tablebordermain">
                <tr>
                  <td>

                  <table align="right" cellpadding="0" cellspacing="0" style="HEIGHT: 100px" width="425">
                    <tr>
                      <td width="92"><font class="textsmall">&nbsp; Clear Bal</font></td>
                      <td width="100"><input name="txtClrBal" readonly size="18" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-FAMILY: ; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                      <td width="96"><font class="textsmall">&nbsp;Unclear Bal</font></td>
                      <td width="96"><input name="txtUnClrBal" readonly size="15" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                    </tr>
                    <tr>
                      <td width="130"><font class="textsmall">&nbsp; Net Bal</font></td>
                      <td width="119"><input name="txtNetBal" onkeypress="numeric()" readonly size="18" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                      <td width="140"><font class="textsmall">Operating Instr</font></td>
                      <td width="99"><input name="txtOpInstr" readonly size="15" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold"></td>
                    </tr>
                    <tr>
                      <td width="130"><font class="textsmall">&nbsp; Operated by</font></td>
                      <td width="314" colspan="3"><input name="txtOpaBy" readonly size="30" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="130" height="0"><font class="textsmall">&nbsp; Cust ID</font></td>
                      <td width="119" colspan="3" height="0"><input name="txtCustId" readonly size="30" class="bgcolor4" style=" BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold"></td>
                    </tr>
                  </table>

                  </td>
                </tr>
              </table>

            </div>

            <table cellspacing="0" cellpadding="0">
              <tr>
                <td>
                <div id="Denom" style="DISPLAY: block; HEIGHT: 100px; LEFT: 319px; POSITION: absolute; TOP: 108px; WIDTH: 449px">
                </div>
                </td>
              </tr>
            </table>

            </td>
          </tr>
          <tr>
            <td width="55%" valign="top">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" valign="top"><center>
                <object align="left" classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="70" id="mfgTranslog" name="Mfgpaydt" style="display: block; width=" 428" width="428">
                  <param name="_ExtentX" value="11324">
                  <param name="_ExtentY" value="1852">
                  <param name="_Version" value="393216">
                  <param name="Rows" value="1">
                  <param name="Cols" value="23">
                  <param name="FixedRows" value="1">
                  <param name="FixedCols" value="0">
                  <param name="RowHeightMin" value="0">
                  <param name="BackColor" value="-2147483643">
                  <param name="ForeColor" value="-2147483640">
                  <param name="BackColorFixed" value="-2147483633">
                  <param name="ForeColorFixed" value="-2147483630">
                  <param name="BackColorSel" value="-2147483635">
                  <param name="ForeColorSel" value="-2147483634">
                  <param name="BackColorBkg" value="8421504">
                  <param name="GridColor" value="12632256">
                  <param name="GridColorFixed" value="0">
                  <param name="WordWrap" value="0">
                  <param name="Redraw" value="-1">
                  <param name="AllowBigSelection" value="-1">
                  <param name="ScrollTrack" value="0">
                  <param name="Enabled" value="-1">
                  <param name="RightToLeft" value="0">
                  <param name="TextStyle" value="0">
                  <param name="TextStyleFixed" value="0">
                  <param name="FocusRect" value="1">
                  <param name="HighLight" value="1">
                  <param name="FillStyle" value="0">
                  <param name="GridLines" value="1">
                  <param name="GridLinesFixed" value="2">
                  <param name="ScrollBars" value="3">
                  <param name="SelectionMode" value="0">
                  <param name="MergeCells" value="0">
                  <param name="AllowUserResizing" value="0">
                  <param name="PictureType" value="0">
                  <param name="BorderStyle" value="1">
                  <param name="Appearance" value="1">
                  <param name="MousePointer" value="0">
                  <param name="GridLineWidth" value="1">
                  <param name="FormatString" value="&gt;Batch No  |&gt;Tran No   |&lt;GlCode        |&lt;Gl Description                   |&gt;Acc No         |&gt;Amount            |&gt;Entered Time Bal |^Process Date   |&lt;Cust Id               |&lt;Mode of Tran  |&lt;Status  |&gt;Currency Code     |&lt;Entered By             |&lt;Enterd M/c             |&lt;Approved By               |&lt;Approved M/c         |&lt;Module Id         |&lt;Branch Code            |&gt;Token No   |&lt;Remarks                           ">
                  <param name="OLEDropMode" value="0">
                </object>
                </center>
                <p align="center">&nbsp;</p>
                </td>
              </tr>
              <tr>
                <td>
                <div align="center">
                  <center>

                  <table class="tablebordermain" cellspacing="0" cellpadding="0" width="10">
                    <tr>
                      <td width="100%" valign="top">
                      <p align="center"><input type="button" value="Refresh" name="B6" style="LEFT: 276px; RIGHT: 300px; TOP: 19px" onclick="TempTranslog()" class="bgcolor"><input type="button" value=" Delete " name="B6" style="RIGHT: 300px" onclick="flexClick()" class="bgcolor"></p>
                      </td>
                    </tr>
                  </table>

                  </center>
                </div>
            </table>

            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="43%"></td>
            <td width="57%"></td>
          </tr>
        </table>

        <div id="ChqDtl" style="DISPLAY: none">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="40%" colspan="4"><font class="subheading">&nbsp;Cheque Details</font></td>
              <td width="9%">&nbsp;</td>
              <td width="17%" colspan="2">&nbsp;</td>
              <td width="14%">&nbsp;</td>
              <td width="25%">&nbsp;</td>
            </tr>
            <tr>
              <td width="5%">&nbsp;Chq.Series</td>
              <td width="7%"><input name="txtChqSrs" size="5" onblur="ChqSerValidation()"></td>
              <td width="11%">Chq. No</td>
              <td width="20%"><input name="txtChqNo" onblur="ChqValidation()" onkeypress="numeric()" size="18" style="LEFT: -2px; TOP: 14px"></td>
              <td width="9%" align="right">Chq Dt&nbsp;</td>
              <td width="13%"><input name="txtChqDt" size="11" readonly onblur="ChqDateVald()"></td>
              <td width="8%">
              <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="23" id="DtpChq" name="DtpChq" style="LEFT: 0px; TOP: 23px" width="39">
                <param name="_ExtentX" value="1032">
                <param name="_ExtentY" value="609">
                <param name="_Version" value="393216">
                <param name="MousePointer" value="0">
                <param name="Enabled" value="1">
                <param name="OLEDropMode" value="0">
                <param name="CalendarBackColor" value="-2147483643">
                <param name="CalendarForeColor" value="-2147483630">
                <param name="CalendarTitleBackColor" value="-2147483633">
                <param name="CalendarTitleForeColor" value="-2147483630">
                <param name="CalendarTrailingForeColor" value="-2147483631">
                <param name="CheckBox" value="1">
                <param name="CustomFormat" value="dd-mmm-yyyy">
                <param name="DateIsNull" value="1">
                <param name="Format" value="662831107">
                <param name="UpDown" value="0">
                <param name="CurrentDate" value="37029">
                <param name="MaxDate" value="2958465">
                <param name="MinDate" value="-109205">
              </object>
              </td>
              <td width="12%">
              <p align="right">Chq. FVG&nbsp;&nbsp;</p>
              </td>
              <td width="25%"><input name="txtChqFVG" size="25"></td>
            </tr>
          </table>

        </div>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%" height="10"></td>
          </tr>
          <tr>
            <td>
            <div align="center">
              <center>

              <table class="tablebordermain" width="10" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" align="middle">
                  <p align="center"><input type="button" value="   Ok   " name="B4" onclick="frmSub()" class="bgcolor"><input type="reset" value=" Clear " name="B5" onclick="cashMode()" class="bgcolor"></p>
                  </td>
                </tr>
              </table>

              </center>
            </div>
        </table>

        <input type="hidden" name="hpr">
        </form>
        <form name="frmTrnsMain" action>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%"><input type="hidden" name="DemonValue"><input type="hidden" name="DenomType"><input type="hidden" name="PaidAmt"><input type="hidden" name="ExchgAmt">

              <table align="center">
                <tr>
                  <td><center><!--
                  <OBJECT classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height=132 id=Mfgpaydt 
	name=Mfgpaydt style="HEIGHT: 132px; LEFT: 1px; TOP: 1px; WIDTH: 759px" width=627>
	<PARAM NAME="_ExtentX" VALUE="20082">
	<PARAM NAME="_ExtentY" VALUE="3493">
	<PARAM NAME="_Version" VALUE="393216">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="Cols" VALUE="44">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="HighLight" VALUE="1">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="FormatString" VALUE=">Batch No  |>Tran No   |<GlCode        |<Gl Description                   |>Acc No         |<Name                           |>Amount            |>Entered Time Bal |^Process Date   |<Cust Id               | |<Mode of Tran  ||<Status  |>Currency Code     |<Entered By             |<Enterd M/c             |<Approved By               |<Approved M/c         |<Module Id         |<Branch Code            |>Token No   |<Remarks                           |<Cheque Series  |>Cheque No             |^Cheque Date   |<Cheque Favouring         | | | | | | | | | | | | | | |>Counter No.  |<Cashier Id.          |>Scroll No. ">
	<PARAM NAME="OLEDropMode" VALUE="0"></OBJECT>
	-->
                  <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="132" id="Mfgpaydt" name="Mfgpaydt" style="HEIGHT: 132px; LEFT: 1px; TOP: 1px; WIDTH: 759px" width="627">
                    <param name="_ExtentX" value="20082">
                    <param name="_ExtentY" value="3493">
                    <param name="_Version" value="393216">
                    <param name="Rows" value="1">
                    <param name="Cols" value="44">
                    <param name="FixedRows" value="1">
                    <param name="FixedCols" value="0">
                    <param name="RowHeightMin" value="0">
                    <param name="BackColor" value="-2147483643">
                    <param name="ForeColor" value="-2147483640">
                    <param name="BackColorFixed" value="-2147483633">
                    <param name="ForeColorFixed" value="-2147483630">
                    <param name="BackColorSel" value="-2147483635">
                    <param name="ForeColorSel" value="-2147483634">
                    <param name="BackColorBkg" value="8421504">
                    <param name="GridColor" value="12632256">
                    <param name="GridColorFixed" value="0">
                    <param name="WordWrap" value="0">
                    <param name="Redraw" value="-1">
                    <param name="AllowBigSelection" value="-1">
                    <param name="ScrollTrack" value="0">
                    <param name="Enabled" value="-1">
                    <param name="RightToLeft" value="0">
                    <param name="TextStyle" value="0">
                    <param name="TextStyleFixed" value="0">
                    <param name="FocusRect" value="1">
                    <param name="HighLight" value="1">
                    <param name="FillStyle" value="0">
                    <param name="GridLines" value="1">
                    <param name="GridLinesFixed" value="2">
                    <param name="ScrollBars" value="3">
                    <param name="SelectionMode" value="0">
                    <param name="MergeCells" value="0">
                    <param name="AllowUserResizing" value="0">
                    <param name="PictureType" value="0">
                    <param name="BorderStyle" value="1">
                    <param name="Appearance" value="1">
                    <param name="MousePointer" value="0">
                    <param name="GridLineWidth" value="1">
                    <param name="FormatString" value="&gt;Batch No  |&gt;Tran No   |&lt;GlCode        |&lt;Gl Description                   |&gt;Acc No         |&lt;Name                           |&gt;Amount            |&gt;Entered Time Bal |^Process Date   |&lt;Cust Id               | |&lt;Mode of Tran  ||&lt;Status  |&gt;Currency Code     |&lt;Entered By             |&lt;Enterd M/c             |&lt;Approved By               |&lt;Approved M/c         |&lt;Module Id         |&lt;Branch Code            |&gt;Token No   |&lt;Remarks                           |&lt;Cheque Series  |&gt;Cheque No             |^Cheque Date   |&lt;Cheque Favouring         | | | | | | | | | | | | | | |&gt;Counter No.  |&lt;Cashier Id.          |&gt;Scroll No. ">
                    <param name="OLEDropMode" value="0">
                  </object>
                  </center></td>
                </tr>
              </table>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tbody>
                  <tr>
                    <td width="112" height="25">&nbsp;&nbsp; Dr. Transactions:</td>
                    <td width="22"><input name="NoDrTrn" size="2" style="BACKGROUND-COLOR: white; COLOR: red; LEFT: -3px; TOP: 13px; 
            WIDTH: 
            25px" readonly value="0" width="25"></td>
                    <td width="138" height="25">&nbsp;Cr. Transactions:&nbsp;<input name="NoCrTrn" size="2" readonly style="COLOR: blue; WIDTH: 25px" value="0" width="25"></td>
                    <td width="41" height="25" align="right"><font class="textred">Total&nbsp;</font></td>
                    <td width="286" height="25"><input name="txtTotCredit" size="18" style="BACKGROUND-COLOR: white; COLOR: blue; TEXT-ALIGN: right" value="0.00" readonly><input name="txtTotDebit" size="18" maxlength="13" style="COLOR: red; TEXT-ALIGN: right" value="0.00" readonly></td>
                    <td width="61" height="25">Difference</td>
                    <td width="90" height="25"><input name="txtDiff" size="11" style="COLOR: blue; TEXT-ALIGN: right" value="0.00" maxlength="15" readonly></td>
                  </tr>
                  <tr>
                    <td width="670" colspan="6" height="10">
                    <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </td>
                  </tr>
              </table>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                  <div align="center">
                    <center>

                    <table border="0" width="40%" cellspacing="0" cellpadding="0" class="tablebordermain">
                      <tr>
                        <td width="100%"><input type="button" value="  Post  " name="B6" onclick="SubPost()" class="bgcolor"><input type="button" value="Modify" name="B9" class="bgcolor"><input type="button" value="Delete" name="B10" onclick="DelTran();Cancel()" class="bgcolor"><input type="button" value="Cancel" name="B7" onclick="DelTran();Cancel()" class="bgcolor"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.asp&quot;)" class="bgcolor"></td>
                      </tr>
                    </table>

                    </center>
                  </div>
                  </td>
                </tr>
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          <input type="hidden" name="txtGridStr">
        </form>
        </td>
      </tr>
    </tbody>
  </table>

</body>

