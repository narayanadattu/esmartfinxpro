<%@ Page aspcompat="true" explicit="false" CodeBehind="cashrefund.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashrefund" %>
<html>
<!--This Form is used for  Cash Refund by the Cashier -->
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashRefund.aspx
''''' ListForm:List
''''' iFramepage:cashrehcounter.aspx
''''' Trnsactionpages:CashrefundInsert.aspx
''''------------------------------------------------------------------------------------------
%>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : cashrefund.aspx										*
'*	Purpose	  	     : This form is used to refund the available cash.   	*
'*																			*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|    Shobanbabu	    |    30-MAY-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Refund</title>
<%
' Menu and Client side validations '
%>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>

/*
//--------- This function is for assigning the selected branch code,description-------------------
function Bruser(kstr)
{
  assign(kstr,window.document.frmrefund.txtBranchdesc,window.document.frmrefund.txtBranchCode)  
  window.document.all.den.src="masterdenom.aspx"   
  window.document.frmrefund.txtRefundno.value =""
  window.document.frmrefund.txtCounterno.value ="" 
  window.document.frmrefund.txtCurrencyCode.value ="" 
  window.document.frmrefund.txtCurrencyDesc.value ="" 
  window.document.frmrefund.txtctotal.value ="0.00"
  window.document.frmrefund.txtavtotal.value ="0.00"
  window.document.frmrefund.txtRefundamt.value ="0.00"
  window.document.frmrefund.txttotal.value ="0.00"
}

//--------- This function is for selecting Branch code-------------------
function branch()
{   
	st="Bruser"
	window.open("List.aspx" + "?"+"st="+st,st,"width=200%,height=150% left=140 top=210")
}
//--------- This function is for selecting Currency code-------------------
function currency()
{ 	 
  st="Curr"
  window.open("List.aspx" + "?"+"st="+st,"st","width=200%,height=150% left=550 top=210")    
}
//-------To assign the currencycode and description to the controls

function  Currid(kstr)
{
var pr,tot="",k,inti
	clear()
	k=kstr.split("-----")
	var v1=0 
	window.document.frmrefund.txtCurrencyDesc.value =k[0]
	window.document.frmrefund.txtCurrencyCode.value =k[1]	
	pr=k[2].length-1
	
	window.document.frmrefund.hpr.value=pr
	v1="0."
	for(inti=1;inti<=pr;inti++)
	{
		tot=tot + "0"
	}	
	tot= v1+tot
	
	window.document.frmrefund.txtavtotal.value=tot
	window.document.frmrefund.txttotal.value=tot
	
	window.document.frmrefund.txtRefundamt.value=tot  
//--------- This function is for getting counter No------------------------	
Getcounterid()
//--------- This function is to display the denom values available for the currency code for the Cashier ------------------------
denom()

}
*/

var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

//--------- This function is for clearing the controls------------------------

function clear()
{
	window.document.frmrefund.txtCounterno.value =""    
	window.document.frmrefund.txtctotal.value =""
	window.document.frmrefund.txtRefundno.value =""
	window.document.frmrefund.txtRefundamt.value =""
	window.document.frmrefund.txttotal.value =""   
}

//--------- This function is to get Counter No------------------------

function Getcounterid()
	{
		var tab="cashcashierposmst"		
		var brcode=window.document.frmrefund.txtBranchCode.value 
		var crcode=window.document.frmrefund.txtCurrencyCode.value       
		st=tab+"|"+brcode+"|"+crcode	
		
		//Window.document.all["iBatch"].src="CashRefCounter.aspx"
						
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="CashRefCounter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
	}
//--------- This function is for showing available Denomination values with the Cashier------------------------

function denom()
{
	//alert(CashDenom)
	if (CashDenom=='Y')
	{
		window.document.all.divdenom.style.display="block"
		window.document.all.total.style.visibility="visible" 
		window.document.all.Castotal.style.visibility="visible" 
		window.document.all.Difftotal.style.visibility="visible" 
		window.document.frmrefund.txtavtotal.style.visibility="visible" 
		window.document.frmrefund.txttotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.divdenom.style.display="none"
		window.document.all.total.style.visibility="hidden" 
		window.document.all.Castotal.style.visibility="hidden" 
		window.document.all.Difftotal.style.visibility="hidden" 
		window.document.frmrefund.txtavtotal.style.visibility="hidden" 
		window.document.frmrefund.txttotal.style.visibility="hidden" 
	}
	var tab="cashcashierposmst"  
	var brcode=window.document.frmrefund.txtBranchCode.value 
	var crcode=window.document.frmrefund.txtCurrencyCode.value 				
	var frm="frmrefund"		
		st= frm + "|" + tab + "|" + brcode + "|" + crcode+"|"+CashDenom
        ///alert(" st = "+st)
		window.document.frames(0).frmdm.hdenom.value=st
		window.document.frames(0).frmdm.action="masterdenom.aspx"
		window.document.frames(0).frmdm.method="post"
		window.document.frames(0).frmdm.submit()    
}

// If the cash refund is in full then the total denomination values must be automatically
//refunded

function equaldenom()
{

if(window.document.frmrefund.txtctotal.value>0)
{
	
	if(window.document.frmrefund.txtctotal.value==window.document.frmrefund.txtRefundamt.value)
	{
	precision(window.document.frmrefund.txtctotal,window.document.frmrefund.hpr.value)
	
		var tab="cashcashierposmst" 
		var brcode=window.document.frmrefund.txtBranchCode.value 
		var crcode=window.document.frmrefund.txtCurrencyCode.value 				
		var frm="frmrefund"		
		var st= frm + "|" + tab + "|" + brcode + "|" + crcode
		//alert("st " + st)
        window.document.frames(0).frmdm.hdenom.value=st
		window.document.frames(0).frmdm.action="masterdenomref.aspx"
		window.document.frames(0).frmdm.method="post"
		window.document.frames(0).frmdm.submit()    
	}
	else
	{
		denom()
	}
}


}

//--------- This function is for setting the Precision ------------------------
function refamount()
{	
window.document.frmrefund.txtRefundamt.value=window.document.frmrefund.txttotal.value
	var prvalue=window.document.frmrefund.hpr.value    
	var pr=prvalue.length-1 	
	precision(window.document.frmrefund.txttotal,pr)
}

//--------- This function is for to highlight  the refundamount control value------------------------
function select()
{
	window.document.frmrefund.txtRefundamt.focus()    
}
//--------- This function is  to assign CounterNo And Refund No------------------------
function  Allot(kstr) 
{

//alert("kstr=" + kstr)

if(kstr=="No Records Found")
{
return;
}
else
{
 	v=kstr.split("|")   
  			  			  			  	     
 	window.document.frmrefund.txtCounterno.value=v[0] 			
 	window.document.frmrefund.txtRefundno.value=v[2]    			
 	//window.document.frmrefund.txtctotal.value=v[1]
}
}

//--------- This function is to save the refund Amount by the Cashier------------------------

function save()
{
	//window.document.frmrefund.hchkrefund.value=""
	var  inti,intk=0,count=0,precision="",pieces="",type=""
	if(eval(window.document.frmrefund.txtRefundamt.value)==0)
	{
		alert("Enter refund Amount")
		return;
	}
	if (CashDenom=='Y')
	{
	
		if(eval(window.document.frmrefund.txtDiffTot.value) != "0")
		{
			if (confirm("Total Amt Not Equal to Denomination Amt, Diff:"+window.document.frmrefund.txtDiffTot.value+" is there \nDue You Want Continue..Y/N ?") == true)
			{
				if(confirm("Are You Sure") == true)
				{
					if(confirm("Are You Sure") == true)
					{
					
					}
					else
					{
						return;
					}
				}
				else
				{
					return;
				}
			}
			else
			{
				return;
			}
		}
	
	if(eval(window.document.frmrefund.txtRefundamt.value) == eval(window.document.frmrefund.txttotal.value))    
	{
		if(eval(window.document.frmrefund.txtRefundamt.value)<=eval(window.document.frmrefund.txtctotal.value)) 
		{
			count=window.document.frames(0).frmdm.hcnt.value     
			
			if(count.length>0)
			{
			//for single text boxes (denominations)
				if(window.document.frames(0).frmdm.txtpieces.length>0)
				{			
					for(inti=0;inti<=count-1;inti++)
					{
					 if(window.document.frames(0).frmdm.txtpieces(inti).value !="")
					 {
						 intk=eval(intk)+1					 
						 precision= precision + eval(window.document.frames(0).frmdm.hps(inti).value)  + "|" 
						 pieces =pieces +  eval(window.document.frames(0).frmdm.txtpieces(inti).value) + "|"
					     type= type+ window.document.frames(0).frmdm.htype(inti).value + "|"
					 }
				
					}
				}
				else//for multiple text boxes
				{
					for(inti=0;inti<=count-1;inti++)
					{
					 if(window.document.frames(0).frmdm.txtpieces.value !="")
					 {
						 intk=eval(intk)+1					 
						 precision= precision + eval(window.document.frames(0).frmdm.hps.value)  + "|" 
						 pieces =pieces +  eval(window.document.frames(0).frmdm.txtpieces.value) + "|"
					     type= type+ window.document.frames(0).frmdm.htype.value + "|"
					 }
				
					}	
				}
				/*if(window.document.frmrefund.chkRefund.checked==true)
				{
				window.document.frmrefund.hchkrefund.value='C'
				}
				else
				{
				window.document.frmrefund.hchkrefund.value=""
				}*/
				/* window.document.frmrefund.hcount.value=intk   
				window.document.frmrefund.hvalue.value=precision
				window.document.frmrefund.hpices.value=pieces
				window.document.frmrefund.htype.value=type
				window.document.frmrefund.action="cashrefundinsert.aspx"
				window.document.frmrefund.method="post"
				window.document.frmrefund.submit() */
				}
			else
			{	
				alert("No Cash Entered To Refund")
			}
			}			
		else
		  {
			alert("Refund Amount Should Be Less Than  Amount of Cash in Hand")
			window.document.frmrefund.txtRefundamt.value=""
			return
		  }
		 } 
	else
	{
		alert("Refund amount And Denomination amount must be equal")
		return
		
	}
	} /// Cash denomination if
	window.document.frmrefund.hcount.value=intk   
	window.document.frmrefund.hvalue.value=precision
	window.document.frmrefund.hpices.value=pieces
	window.document.frmrefund.htype.value=type
	window.document.frmrefund.action="cashrefundinsert.aspx"
	window.document.frmrefund.method="post"
	window.document.frmrefund.submit()
	
}
//--------- This function is to check the refundamount is less than  amount of cash in hand ------------------------

function checkamount()
{
	window.document.frmrefund.txttotal.value=""
	
	if(eval(window.document.frmrefund.txtRefundamt.value)>
	eval(window.document.frmrefund.txtctotal.value))
	{
		alert("Refund Amount Is GreaterThan Amount Available in Hand")
		window.document.frmrefund.txtRefundamt.value=""
		window.document.frmrefund.txtRefundamt.select() 
	}        
}
/*function chkrefunddisp()
{
	if(eval(window.document.frmrefund.txtRefundamt.value)==eval(window.document.frmrefund.txtctotal.value))
	{
	
	window.document.frmrefund.all.divrefund.style.display="Block"
	}
	else
	{
	
	window.document.frmrefund.all.divrefund.style.display="none"
	}
}*/
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashrefund.aspx" 
		
	}
}	

function TotalSumAmount(kstr)
{
	window.document.frmrefund.txttotal.value=kstr 
	
	window.document.frmrefund.txttotal.value= gridprecision(window.document.frmrefund.txttotal.value,
					window.document.frmrefund.hpr.value)
}

function GetAvgTotRefAmt(kstr)
{
//alert("hi")
k=kstr.split("|")
	window.document.frmrefund.txtavtotal.value =k[0]  // avg total
	window.document.frmrefund.txtavtotal.value= gridprecision(window.document.frmrefund.txtavtotal.value,window.document.frmrefund.hpr.value)
	window.document.frmrefund.txtctotal.value =k[1]  // c total
	window.document.frmrefund.txtctotal.value= gridprecision(window.document.frmrefund.txtctotal.value,window.document.frmrefund.hpr.value)
	window.document.frmrefund.txtCaTot.value =k[2]  // ca tot
	window.document.frmrefund.txtCaTot.value= gridprecision(window.document.frmrefund.txtCaTot.value,window.document.frmrefund.hpr.value)
	window.document.frmrefund.txtDiffTot.value =k[3] // diff total
	window.document.frmrefund.txtDiffTot.value= gridprecision(window.document.frmrefund.txtDiffTot.value,
					window.document.frmrefund.hpr.value)
					
	/*window.document.frmrefund.txttotal.value =k[4] //  total
	window.document.frmrefund.txttotal.value= gridprecision(window.document.frmrefund.txttotal.value,
					window.document.frmrefund.hpr.value)				*/
}

function GetTotalRefAmt(kstr)
{
//alert("hiii")
	window.document.frmrefund.txttotal.value =kstr //  total
	window.document.frmrefund.txttotal.value= gridprecision(window.document.frmrefund.txttotal.value,
					window.document.frmrefund.hpr.value)				
}

</script>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);
Getcounterid();denom();DispTranMsg()">

<form name="frmrefund">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%" border="0">
				<tr>
					<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="38%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;Cash Refund</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>
		
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tbody>
      <tr>
        <td width="100%" valign="top">

        <table border="0" width="100%" cellspacing="0" cellpadding="0" height="0">
          <tr>
            <td width="100%" nowrap>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="11%" ></td>
                <td width="89%" >

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="100%"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" ></td>
                  </tr>
                </table>

                </td>
              </tr>
            </table>
<%
 appdate=formatdatetime(session("Applicationdate"),1)
%>
            
            </td>
          </tr>
        </table>

        <%
        ' To display the application date
        %>
       	

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">

          <!--  <table align="center" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td height="15"><font class="textblue">
                <p align="center"></font></td>
              </tr>
            </table> --->

            <div align="center">
              <center>

              <table border="0" width="98%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="12%" height="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
                  <td width="32%" height="27">&nbsp;<input
                  name="txtBranchCode" size="9" readonly class="txtautofill"
                  value="<%=session("branchcode")%>"><input 
                  type="button" class="button" value=" L " name="cmdbranch" disabled
                  onclick="branch()"><input name="txtBranchdesc" size="16" readonly 
                  class="bgcolor1" value="<%=session("branchnarration")%>"></td>
                  
                  <td width="20%" align="right" height="27">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  <td width="26%" height="27"><input 
                  name="txtCurrencyCode" size="9" class="txtautofill"
                  readonly value="<%=session("currencycode")%>"><input 
                  type="button" class="button" value=" L " name="cmdcur" disabled 
                  onclick="currency()"><input 
                  name="txtCurrencyDesc" size="16" readonly 
                  class="bgcolor1" value="<%=session("currencynarration")%>"></td>
                </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
        </table>

        <div align="center">
          <center>

          <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
            <tr>
              <td>
              <div align="center">
                <center>

                <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td width="53%" valign="top">
                    <div align="center">
                      <center>

                      <table width="96%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td>

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr class="bgcolor">
                              <td width="100%" height="30" colspan="4">

                              <table border="0" width="97%" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td width="100%">

                                  <table border="0" width="87%" cellspacing="0" cellpadding="0">
                                    <tr class="bgcolor">
                                      <td width="43%"></td>
                                      <td width="57%">

                                      <table width="63%" cellspacing="0" cellpadding="0" class="tablebordermain" border="1">
                                        <tr class="bgcolor">
                                          <td width="100%">
                                          <p align="center"><font class="subheading">Refund
                                          Details</font></p>
                                          </td>
                                        </tr>
                                      </table>

                                      </td>
                                    </tr>
                                  </table>

                                  </td>
                                </tr>
                              </table>

                              </td>
                            </tr>
                            <tr>
                              <td width="24%" height="20"></td>
                              <td width="24%" height="20"></td>
                              <td width="26%" height="20"></td>
                              <td width="26%" height="20"></td>
                            </tr>
                            <tr>
                              <td width="12%%" height="30">&nbsp;&nbsp; Counter No&nbsp;&nbsp;</td>
                              <td width="24%" height="30"><input name="txtCounterno" size="15" readonly class="txtautofill" style="TEXT-ALIGN: right; WIDTH: 100px"></td>
                              
                              <td width="12%" height="30" align="right">&nbsp; Cash in
                              hand&nbsp; &nbsp;</td>
                              <td width="26%" height="30"><input 
                              name="txtctotal" size="11" class="txtautofill" 
                              style="TEXT-ALIGN: right; WIDTH: 91px" readonly value="0.00"></td>
                            </tr>
                            <tr>
                              <td width="12%" height="30">&nbsp;&nbsp;&nbsp;Refund Amt</td>
                              <td width="24%" height="30"><input name="txtRefundamt" class="txtautofill"
                              size="11" style="TEXT-ALIGN: right" value="0.00" maxlength=16
                              onkeypress="numdec(window.document.frmrefund.txtRefundamt.value,
                                  window.document.frmrefund.hpr.value);" 
                                  onfocus="select()" 
                                  onchange="precision(window.document.frmrefund.txtRefundamt,
                                  window.document.frmrefund.hpr.value)" 
                                  onblur="checkamount();equaldenom();
                                  CheckZero(window.document.frmrefund.txtRefundamt)" ></td>
                                  
                              <td width="12%" height="30" align="right">&nbsp;&nbsp;
                              Refund No&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;</td>
                              <td width="26%" height="30"><input name="txtRefundno" readonly class="txtautofill" style="TEXT-ALIGN: right; WIDTH: 91px" size="15" onkeypress="numeric()"></td>
                            </tr>
                            <tr>
                              <td width="24%" height="30">&nbsp;</td>
                              <td width="24%" height="30"></td>
                              <td width="26%" height="30" align="right">&nbsp;&nbsp;
                              &nbsp;&nbsp; &nbsp;&nbsp;</td>
                              <td width="26%" height="30"></td>
                            </tr>
                            <tr>
                              <td width="24%" height="30">&nbsp;</td>
                              <td width="24%" height="30"></td>
                              <td width="26%" height="30" align="right">&nbsp;&nbsp;
                              &nbsp;&nbsp; &nbsp;&nbsp;</td>
                              <td width="26%" height="30"></td>
                            </tr>
                            <tr>
                              <td width="24%" height="30">&nbsp;</td>
                              <td width="24%" height="30"></td>
                              <td width="26%" height="30" align="right">&nbsp;&nbsp;
                              &nbsp;&nbsp; &nbsp;&nbsp;</td>
                              <td width="26%" height="30"></td>
                            </tr>
                            <tr>
                              <td width="24%" height="36">&nbsp;</td>
                              <td width="24%" height="36"></td>
                              <td width="26%" height="36" align="right">&nbsp;&nbsp;
                              &nbsp;&nbsp; &nbsp;&nbsp;</td>
                              <td width="26%" height="36"></td>
                            </tr>
                            
                            </table>
                            <!--<div id="divrefund" style="display:none">
                            <table>
                            <tr>
                              <td width="100%" height="125" colspan="4">Are You Sure to Close the Counter<input
                               type="Checkbox" name="chkRefund" ></td>
                            </tr>
                            </table>
                            </div>-->
                          

                          </td>
                        </tr>
                        
                      </table>

                      </center>
                    </div>
                    <td width="58%" valign="top">
                    <div align="center" id="divdenom">
                      <center>

                      <table width="95%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td>
                          <div align="center">
                            <center>

                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="100%" align="middle" valign="top">
                                <td align="middle" valign="top"><iframe id="den" align=center            
                  frameborder=0 framespacing=0 noresize height=380 width=320 
                              valign="top" src="masterdenom.aspx" 
                              style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                          </td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                  </tr>
                </table>

                </center>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="38%" height="20" colspan="2"></td>
                    <td width="12%" height="20"></td>
                    <td width="10%" align="right" height="20"></td>
                    <td width="11%" align="right" height="20"></td>
                    <td width="7%" align="right" height="20"></td>
                    <td width="16%" height="20"></td>
                  </tr>
                  <tr>
                    <td width="38%"><font class="textred"><span id="Castotal" style="VISIBILITY: hidden">Total Cash &nbsp;&nbsp; </font>&nbsp;<input name="txtCaTot" class="bgcolor1" style=" TEXT-ALIGN: right" value="0.00" size="11" onkeypress="numeric()" readonly ><font class="textred"><span id="Difftotal" style="VISIBILITY: hidden">Differance &nbsp;&nbsp; </font>&nbsp;<input name="txtDiffTot" class="bgcolor1" style=" TEXT-ALIGN: right" value="0.00" size="11" onkeypress="numeric()" readonly ></td>
                
                    <td width="12%"></td>
                    <td width="10%" align="right"><font class="textred"><span id="total" style="VISIBILITY: hidden">Total&nbsp;&nbsp; </font>&nbsp;</td>
                    <td width="11%" align="right"><input name="txtavtotal" class="bgcolor1" style=" TEXT-ALIGN: right" value="0.00" size="11" onkeypress="numeric()" readonly onchange="amountdigits(window.document.frmrefund.txttotal);window.document.frmrefund.txtRefundamt.value=window.document.frmrefund.txttotal.value "></td>
                    <td width="7%" align="right"></td>
                    <td width="16%"><input name="txttotal" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00" size="11" onkeypress="numeric()" readonly onchange="refamount()"></td>
                  </tr>
                  <tr>
                    <td width="11%" height="10"></td>
                    <td width="27%" height="10"></td>
                    <td width="12%" height="10"></td>
                    <td width="10%" align="right" height="10"></td>
                    <td width="11%" align="right" height="10"></td>
                    <td width="7%" align="right" height="10"></td>
                    <td width="16%" height="10"></td>
                  </tr>
                </table>

              </div>
              </td>
            </tr>
                <td width="27%">

                    <table width="86%" cellspacing="0" cellpadding="0" class="tablebordermain" align="center">
                      <tr>
                        <td width="100%" align="center"><input type="button" value="    Ok     " 
                        name="butOk" onclick="save()" class="button"><input 
                        type="button" value="Cancel" name="butCancel" 
                        onclick="location.href=&quot;cashrefund.aspx&quot;" class="button"><input 
                        type="button" value="   Exit   " 
                        name="cmdexit" 
                        onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" class="button"></td>
                      </tr>
                    </table>

                    </td>
          </table>
          
          
          

          </center>
        </div>
        <input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
        <input type="hidden" name="htype" value="0">
        <input type="hidden" name="hvalue" value="0">
        <input type="hidden" name="hpices" value="0">
        <input type="hidden" name="hcount" value="0">
        <!--<input type="hidden" name="hchkrefund" value="0">-->
        <input type="hidden" name="hpr" value="2">
            


              </form></td>
      </tr>
    </tbody>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="cashrefcounter.aspx">
                                              </iframe>
                  </td>
                </tr>
              </table>


        </center>
      </div>
      </td>
    </tr>
  </table>

  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</body>

