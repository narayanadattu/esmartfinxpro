<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="cashrefundinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashrefundinsert" %>
<%
	a=Request.Form("hcount")     
	if len(trim(a))>0 then
	dim Arrtrans(0,2)
	redim Arrtrans(a,2)
	'table="cashrefundstrn"
	brcode=Request.Form("txtBranchcode")
	userid=session("userid")
	cntr=Request.Form("txtCounterno")
	curcode=Request.form("txtCurrencycode")	
	applicationdate=session("applicationdate")	
	refno=Request.Form("txtRefundno") 
	refundamt=Request.Form("txtRefundamt") 
	machineId=session("machineId")
	Response.Write (cntr)
	dim kstr,values
	m=split(Request.Form("hvalue"),"|") 
	n=split(Request.Form("hpices"),"|") 
	p=split(Request.Form("htype"),"|") 
	 ''spliting the denomination sened from cleine side page 	
	for i=1 to Request.Form("hcount") 
		arrtrans(i,0)=m(i-1)
		arrtrans(i,1)=n(i-1)
		arrtrans(i,2)=p(i-1)
	
	next
	''storing the value  in the variables 	
	kstr="branchcode,currencycode,counterno,refundno,applicationdate," _
			& "refundamount,userid,status, REFUNDEDUSERID,REFUNDEDMACHINEID,REFUNDEDDATE,machineid"
	strvalues="'" & brcode & "','" & curcode & "','" & cntr & "'," _
			& " " & refno & ",'" & applicationdate & "'," & refundamt & " ,'" & userid & "'," _
			&"'P','" & userid & "','" & machineId & "',to_date(sysdate,'dd-Mon-yy'),'" & session("machineid") & "'"	
		
	''calling refund component to do the refund transaction	
	 obj=server.CreateObject("CashTransaction.Transactions")
		'''calling component method 
	
strmsg=obj.CashTrnInserts("cashrefundstrn",cstr(kstr),cstr(strvalues), _
	cstr(curcode),arrtrans,cstr(brcode),cstr(session("userid")),cstr(session("machineid")), _
				cstr(session("applicationdate")),,cstr(session("userid")),cstr(cntr)) 
	
		Response.Write (strmsg)
	Response.Redirect ("cashrefund.aspx?record="& strmsg)
	
	else
	Response.Write ("Cash Not Available To Refund")
		
	end if
	
%>
	
	
	
	
	
	
	
	








			

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
