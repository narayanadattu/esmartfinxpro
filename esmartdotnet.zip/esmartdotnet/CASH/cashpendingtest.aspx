<%@ Page CodeBehind="cashpendingtest.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashpendingtest" %>
<html>

<%
dim vUserid,vAppldate,vCounterno,vCashierid,vBrcode,vBrdesc,vCurCode,vCurdesc
    vUserid=session("userid")
    vAppldate=session("applicationdate")
    vCounterno=session("Counterno")
    vCahierid=session("userid")
    vBrcode=session("branchcode")
    vBrdesc=session("branchnarration")
    vCurCode=session("currencycode")
    vCurdesc=session("currencynarration")
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var strSessionFld,strsessionflds
//----------------------------------------------------------------------------------   
//This function was written to send values to list form for Branch details display
function branch()
{   
	st="Bruser"
	window.open("List.asp" + "?"+"st="+st,st,"width=213%,height=150%,left=120,top=135")
}
//----------------------------------------------------------------------------------   	 
//This function is used to send parameters to List form to get various currency codes and
//descriptions available.
function currency()
{  
	 st="Currency"
	 window.open("List.asp" + "?"+"st="+st,st,"width=250%,height=150%")
 }
//----------------------------------------------------------------------------------   
 function Bruser(str)
{
   assign(str,window.document.frmtrans.txtbranchdesc,window.document.frmtrans.txtbranchcode)
   window.document.frmtrans.txtcurrencycode.value="";
   window.document.frmtrans.txtcurrencydesc.value="";
   window.document.frmtrans.Mfgpaydt.Clear();
   window.document.frmtrans.Mfgpaydt.FormatString="^       Batch No|^       Tran No |^     Token No |^       AccType     |^     AccNo |^  Amount   |^   Narration||"
   window.document.frmtrans.Mfgpaydt.Rows=1;
}
//----------------------------------------------------------------------------------   	  
//This function is used to display currency codes,descriptions
function Currencyid(str)
 {
	assign(str,window.document.frmtrans.txtcurrencydesc,window.document.frmtrans.txtcurrencycode)
	pay()
	
 } 	
//----------------------------------------------------------------------------------   	  
//This function used to send parameters to get data from gentranslog
  function pay()
  {
	var s,s1
	s=window.document.frmtrans.txtbranchcode.value 
	s1=window.document.frmtrans.txtcurrencycode.value 
	st =s+"|"+ s1
	window.open("paylist.asp"+"?"+"st="+st,"hello","width=1%,height=1%")
  }	
//----------------------------------------------------------------------------------     
//This function is used to call cashpaymentdetails.asp form and sends parameter 
//values to it.
  function flexClick(){
	var i
	var brhStr=window.document.frmtrans.txtbranchcode.value+"~"+window.document.frmtrans.txtbranchdesc.value+"~"+window.document.frmtrans.txtcurrencycode.value+"~"+window.document.frmtrans.txtcurrencydesc.value+"~"
	if((window.document.frmtrans.Mfgpaydt.TextMatrix(window.document.frmtrans.Mfgpaydt.Row,0)!="")&&(window.document.frmtrans.Mfgpaydt.Rows>1)){
		var str
		var trnid
		var Bstr
		str=""
		var str1
		for(i=0;i<window.document.frmtrans.Mfgpaydt.Cols;i++){
			str1=window.document.frmtrans.Mfgpaydt.TextMatrix(window.document.frmtrans.Mfgpaydt.Row,i)
			str=str+str1+"~"
		}
	 str=brhStr+str;	 	 
	 window.location.href="cashpaymentdetails.asp?str="+str
	}
  }
//----------------------------------------------------------------------------------     
//This function is used to populate flexgrid.
function  payid(str){
	var K,i,m,b,pos,j,h,n,p,s
	for(m=1;m<=2;m++){
	b=str.split("$")
	}
	 st=b[0]
	 	window.document.frmtrans.Mfgpaydt.Rows = eval(b[1])+1
		window.document.frmtrans.Mfgpaydt.Cols=b[2]

	for(p=1;p<=b[1];p++){
	      n=st.split("|")
	     if(b[1]>0){
			 for(j=0;j<b[2];j++){
				k=n[p-1].split("~")
				window.document.frmtrans.Mfgpaydt.TextMatrix(p,j)=k[j]
			 }
		  }
	}
  	
}
//----------------------------------------------------------------------------------   
//This function is used to get the native branch and native currency codes.
function NatBranch(){
         
     with(window.document.frmtrans)
         {
          txtbranchcode.value=strsessionflds[4];
          txtbranchdesc.value=strsessionflds[5];
          txtcurrencycode.value=strsessionflds[6];
          txtcurrencydesc.value=strsessionflds[7];
         }
}   
//----------------------------------------------------------------------------------
//This function is used to split session variables.
function PubVariables()
{
     strSessionFld=window.document.frmtrans.txtSessionflds.value
     strsessionflds=strSessionFld.split("~");
}
//----------------------------------------------------------------------------------

//-->
</script>

<SCRIPT LANGUAGE=javascript FOR=Mfgpaydt EVENT=Click>
<!--
 flexClick();
//-->
</SCRIPT>
<title></title>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();NatBranch();pay();">

<%appdate=formatdatetime(session("applicationdate"),1)%>

<form name="frmtrans">

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="28"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25"></td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Cash Payments</font></td>
          <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" nowrap height="15">
          <p align="center"></p>
          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <div align="center">
            <center>

            <table border="0" width="98%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100"><font class="textbold">&nbsp;&nbsp; Branch Code</font></td>
                <td width="266"><input name="txtbranchcode" size="9" readonly><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" readonly class="bgcolor1"></td>
                <td width="160" align="right"><font class="textbold">Currency
                Code&nbsp;&nbsp;</font></td>
                <td width="226" align="right"><input name="txtcurrencycode" size="9" readonly><input type="button" value=" L " name="buttcur" onclick="currency()"><input name="txtcurrencydesc" size="16" readonly class="bgcolor1"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td><br>
            <%if Len(Request("trn"))>0 then%>
            <center><%Response.Write Request("trn")
      end if
            %></center>
            <div align="center">
              <center>

              <table width="70%" cellpadding="0" class="tableborder2">
                <tr>
                  <td>
                  <p>
<OBJECT classid="clsid:76661273-C3DD-4D7A-87A9-690C1029411A" id=UserControl11 style="LEFT: 0px; TOP: 0px">
	<PARAM NAME="_ExtentX" VALUE="8467">
	<PARAM NAME="_ExtentY" VALUE="6350"></OBJECT>
                  

            -------------------------------------------------------
             </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="20"></td>
              </tr>
              <tr>
                <td width="100%" height="20">
                <div align="center">
                  <center>

                  <table width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                    <tr>
                      <td width="100%"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.asp&quot;)" class="bgcolor"></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
              <tr>
                <td width="100%" height="5"></td>
              </tr>
            </table>

        </table>

        </center>
      </div>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="20"></td>
        </tr>
      </table>

  </table>

  <input type="hidden" name="txtSessionflds" value="<%=vUserid&"~"&vAppldate&"~"&vCounterno&"~"&vCahierid&"~"&vBrcode&"~"&vBrdesc&"~"&vCurCode&"~"&vCurdesc&"~"%>">
</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.asp">
          </iframe>
          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

</html>
