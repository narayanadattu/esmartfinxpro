<%@ Page Language="vb" CodeBehind="LGlist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.LGlist" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>e-SMART</title>
<%
strType=Request.QueryString("st")

'Response.Write strtype
'strCurrcode=trim(ucase(Request.Form("txtcurrencycode")))

%>
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
function List() {
	var str,ints,intk,intp
	
	if(window.document.frmList.cmbList.selectedIndex < 0 )  {
		alert("Select Any Code") 
	}
	else {
		str= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
		type="<%=strType%>"
		if(type=="Branch")	{
		  window.attachEvent(window.opener.Branchid(str))
		  window.close()
		}
	else if (type.substring(0,8)=="Moduleid")
{
	window.attachEvent(window.opener.Modulecode(str))
	window.close()
}

else if (type.substring(0,6)=="Glcode")
{
	window.attachEvent(window.opener.Glid(str))
	window.close()
}

else if (type=="Org")
{

  window.attachEvent(window.opener.OrgType(str))
  window.close()
  
}
else if (type=="Charge")
{

  window.attachEvent(window.opener.ChargeCode(str))
  window.close()
  }
else if (type=="NongrCustid")
{
  window.attachEvent(window.opener.Nongroupcust(str))
  window.close()
  
}
else if (type.substring(0,7)=="AccCode")
{
	window.attachEvent(window.opener.Accid(str))
	window.close()
}
		else if (type=="Custorg")	{
			window.attachEvent(window.opener.Custorgid(str))
			window.close()
		}
		else if (type=="Currency")
{
	window.attachEvent(window.opener.Currencyid(str))
	window.close()
}	

		else if (type.substring(0,6)=="Custgm")	{
			window.attachEvent(window.opener.Custinfo(str))
			window.close()
		}
		else if (type=="LgLc")	{
			window.attachEvent(window.opener.lglccode(str))
			window.close()
		}
		
		else if (type=="Security")	{
			window.attachEvent(window.opener.Securityid(str))
			window.close()
		}
		else if (type.substring(0,5)=="Custg")	{
			window.attachEvent(window.opener.Custg(str))
			window.close()
		}
		else if (type.substring(0,6)=="Custnm")	{
			window.attachEvent(window.opener.Custnm(str))
			window.close()
		}
		else if (type.substring(0,5)=="Custn")	{
			window.attachEvent(window.opener.Custn(str))
			window.close()
		}
	}
}
</SCRIPT>
<%
	dim obj,rs
	set rs=server.CreateObject("adodb.recordset")
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set obj1=server.CreateObject("GeneralTranQueries.TransactionQueries")

if strType ="Branch" then
		set rs=obj.singlerecordset("GENBANKBRANCHMST","Branchcode,narration")
		'rs.Open "select Branchcode,narration from GENBANKBRANCHMST@lnnew",con,3,3
elseif strType="Custorg" then
		set rs=obj.singlerecordset("CUSTORGGROUPMST","ORGANISATIONID,ORGANISATIONNAME")
		'rs.open "select orgcode,orgtype from CUSTORGTYPEMST@lnnew",con,3,3
elseif strType="LgLc" then
		set rs=obj.singlerecordset("LGLCTYPEMST","CODE,NARRATION")
elseif strType="Charge" then
		set rs=obj.singlerecordset("GENGLSHEETMST","GLCODE,NARRATION","MODULEID='PL'")		
elseif strType="NongrCustid" then
		set rs=obj.singlerecordset("GENCUSTINFOMST","CUSTOMERID,CUSTNAME","SUBSTR(CUSTOMERID,8) BETWEEN '0000000001' AND '9999999999'")		
elseif strType="Currency" then
	   set rs=obj.singlerecordset("GENCURRENCYTYPEMST","currencycode,narration")
elseif strType="Security" then
	   set rs=obj.singlerecordset("LOANSECTYPESMST","SECTYPECODE,NARRATION")
elseif left(strType,8)="Moduleid" then
       atype=mid(strType,9,len(strType))
       set  rs=obj1.ModuleID(cstr(atype),,"N")
elseif left(strtype,6)="Glcode" then
          k=split(strtype,"|")
          set  rs=obj1.GLCodes(cstr(k(1)),cstr(k(2))) 
elseif left(strtype,7)="AccCode" then
          k=split(strtype,"|")
          set  rs=obj1.AccountNumbers(cstr(k(1)),cstr(k(2)),cstr(k(3)))           
elseif left(strtype,6)="Custgm" then
		brcode=split(strtype,"|")
	    set rs=obj.singlerecordset("GENCUSTINFOMST G,CUSTMEMBERIDMST M","G.customerid,G.custname","G.customerid=M.customerid and G.branchcode='" & cstr(brcode(1)) & "'")
elseif left(strtype,5)="Custg" then
		brcode=split(strtype,"|")
	    set rs=obj.singlerecordset("GENCUSTINFOMST","cashiertypeid,narration","STATUS is null and (currencycode='" & branchcode(2) & "' and branchcode='" & branchcode(1) & "')")
elseif strtype="Org" then
		set rs=obj.singlerecordset("CUSTORGTYPEMST","OrgCode,OrgType","")
elseif left(strtype,6)="Custnm" then
		brcode=split(strtype,"|")
	    set rs=obj.singlerecordset("GENCUSTINFOMST G,CUSTMEMBERIDMST M","cashiertypeid,narration","STATUS is null and (currencycode='" & branchcode(2) & "' and branchcode='" & branchcode(1) & "')")
elseif left(strtype,5)="Custn" then
		brcode=split(strtype,"|")
	    set rs=obj.singlerecordset("GENCUSTINFOMST","cashiertypeid,narration","STATUS is null and (currencycode='" & branchcode(2) & "' and branchcode='" & branchcode(1) & "')")
 end if
					set obj1=nothing
					set obj=nothing
%>
</head>
<body>

<form name="frmList">
  <div align="center">
    <center>

    <table class="tablebordermain" cellspacing="0" cellpadding="0">
      <tr class="bgcolor">
        <%	if len(strType)>8 then	%>
    
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(stname)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%	else	%>
        <th style="FONT-SIZE:xx-small" align="left"><font class="textbold"><%'=UCASE(strType)%>&nbsp;DESCRIPTION
          - CODE</font></th>
        <%end if	%>
      <tr>
        <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	      <%  
	do until rs.EOF
		if rs.Fields.Count < 2 then%>
          <option><%=rs(0)%></option>
			<%elseif rs.Fields.Count=3 then%>
          <option><%=rs(1)%>-----<%=rs(0)%>-----<%=rs(2)%></option>
			<%elseif rs.Fields.Count=4 then%>
          <option><%=rs(1)%>-----<%=rs(0)%>-----<%=rs(2)%>-----<%=rs(3)%></option>
			<%elseif rs.Fields.Count=41 then%>
          <option><%=rs(1)%>-----<%=rs(0)%></option>
			<%else%>
          <option><%=rs(1)%>-----<%=rs(0)%></option>
		  <%end if%>
		  <%rs.MoveNext
	loop
	      %>     

        </select></td>
      </tr>
    </table>

    </center>
  </div>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="bgcolor"><input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="bgcolor"></center>
</form>

</body>

</html>
