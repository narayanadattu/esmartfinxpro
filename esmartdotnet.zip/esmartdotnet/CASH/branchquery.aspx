<%@ Page Language="vb" CodeBehind="branchquery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.branchquery" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<%Dim obj,st,str,rs,a,b,k
	str=Request.Form("hden")
	k=split(str,"|")
	
	if len(str)>0 then
	
		set obj=server.CreateObject("Cashquery.queries")
		st=obj.CashInEachBranch(cstr(k(1)),cstr(k(2)))

    end if%><SCRIPT LANGUAGE=vbscript>
   sub total()
    window.parent.window.document.forms("frmresult").txtvtotal.value=window.document.frmbrquery.hvtot.value
	window.parent.window.document.forms("frmresult").txtctotal.value=window.document.frmbrquery.hctot.value
	window.parent.window.document.forms("frmresult").txtftotal.value=window.document.frmbrquery.hftot.value
   end sub
</SCRIPT>

<title></title>
</head>
<body>

<form name="frmbrquery">

  <%if len(str)>0 then%>
    <%if ubound(st)<>0 then%>  
    <%for i=0 to ubound(st)%>
 
  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <%if st(i,0)<>"" then %>
      <td width="17%" align="right">  <%=st(i,0)%></td>
      <td width="18%" align="right"><%=st(i,1)%></td>
      <% if instr(st(i,2),".")>0 then
			vtot=(vtot)+st(i,2)
	  %>
      <td width="17%" align="right"><%= st(i,2)%></td>
	  <% else %>
      <td width="17%" align="right"><%= st(i,2) & ".00"%></td>
	  <% 	vtot=(vtot)+st(i,2) & ".00"
	    end if%>
      <td width="18%" align="right"><%=st(i,3) %></td>
      <% if instr(st(i,4),".")>0 then
			ctot=(ctot)+st(i,4)
			%>
      <td width="16%%" align="right"><%=st(i,4) %></td>
      <%else %>
      <td width="16%%" align="right"><%=st(i,4)& ".00"%></td>
      <% 	ctot=(ctot)+st(i,4) & ".00"
      
         end if%>
      <% if instr(st(i,5),".")>0 then
			ftot=(ftot)+st(i,5)
			%>
      <td width="17%" align="right"><%= st(i,5)%></td>
      <%else %>
      <td width="17%" align="right"><%= st(i,5)& ".00"%></td>
      <% ftot=(ftot)+st(i,5) &".00"
     
      end if%>
    </tr>
    <%end if%>
    <% next %>
    <input type="hidden" name="hvtot" id="hvtot" value="<%=vtot%>"><input type="hidden" name="hctot" id="hctot" value="<%=ctot%>"><input type="hidden" name="hftot" id="hftot" value="<%=ftot%>">
    <%
      Response.Write "<script language=vbscript>"
      Response.Write "call total()"
      Response.Write "</script>"
    %>
    <%else%>
    <tr>
      <td>

      <table>
        <tr>
          <td><%=st(0,0)%>
          </td>
        </tr>
      </table>

      <%end if%>
      <%end if%>
 
  </table>

  <input type="hidden" name="hden" id="hden">
</form>

</body>

</html>
