<%@ Page Language="vb" CodeBehind="styleexp.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.styleexp" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Accepence</title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmcashacp">
  <input name="h" type="hidden"><input type="hidden" name="hnote">
  <div align="center">
    <center>

    <table border="0" width="780" bordercolor="#643428" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%" valign="top" height="22">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="100%" height="22">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%" height="28"><img name="placeholder" border="0" src="file://Comserver/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="34%" height="25"></td>
            <td width="33%" height="25">
            <p align="center"><font class="text">Cash Acceptance</font></td>
            <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
          </tr>
        </table>

        <table align="center" width="100%" cellspacing="0" cellpadding="0" height="18">
          <tr>
            <td height="18"><font class="textblue"></font>
            <p align="center"></td>
          </tr>
        </table>

        <div align="center">
          <center>

          <table border="0" width="98%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="105"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp; Branch
              Code&nbsp;</font></td>
              <td width="227"><input name="txtbranchcode" size="9" value="<%=SESSION("branchcode")%>" readonly><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" class="bgcolor1" value="<%=SESSION("branchnarration")%>" readonly></td>
              <td align="right" width="169">
              <p align="right"><font class="textbold">Currency Code</font></p>
              </td>
              <td align="right" width="241"><input name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" readonly>
              <input type="button" value=" L " name="butcur" onclick="currency()"> <input name="txtcurrencydesc" size="16" class="bgcolor1" value="<%=SESSION("currencynarration")%>" readonly></td>
            </tr>
          </table>

          </center>
        </div>
        <div align="center">
          <center>

          <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          </center>
          <tr>
            <td>
            <div align="center">
              <center>

              <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="47%" valign="top">
                  <div align="center">
                    <center>

                    <table width="96%" cellpadding="0" class="tableborder2">
                      <tr>
                        <td>&nbsp;

                        <table border="0" width="320" cellspacing="0" cellpadding="0">
                          <tr>
                            <td valign="top" width="112">&nbsp; Allotment No</td>
                            <td width="204" height="30" valign="top"><input name="txtallotment" size="9" readonly class="bgcolor1"><input type="button" value=" L " name="cmdallot" onclick="Allotment()"></td>
                          </tr>
                          <tr>
                            <td valign="top" width="112">&nbsp; Alloted&nbsp;Cashierid&nbsp;</td>
                            <td valign="top" height="30" width="204"><input name="txtcashcode" size="9" readonly class="bgcolor1"><!--<input type="button" value=" L " name="buttcash" onclick="Cashiercode()">--><input name="txtcashdesc" size="16" readonly class="bgcolor1"></td>
                          </tr>
                          <tr>
                            <td valign="top" width="112">&nbsp; Counter No</td>
                            <td width="204" valign="top" height="30"><input name="txtcounterno" size="9" class="bgcolor1" style="TEXT-ALIGN:right" onkeypress="numeric()" readonly></td>
                          </tr>
                          <tr>
                            <td valign="top" width="112">&nbsp; Amt Accepted</td>
                            <td width="204" height="30" valign="top"><input name="txtamount" size="9" value="0.00" class="bgcolor1" style="TEXT-ALIGN: right" readonly></td>
                          </tr>
                          <tr>
                            <td width="318" height="60" valign="top" colspan="2"></td>
                          </tr>
                        </table>

                    </table>

                    </center>
                  </div>
                  </td>
                  <td width="64%" valign="top">
                  <div id="denom" align="center">
                    <div align="center">
                      <center>

                      <table width="95%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td>
                          <div align="center">
                            <center>

                            <table border="0" cellspacing="0" cellpadding="0" width="60%">
                              <tr>
                                <td><iframe id=den align=center  frameborder=0 framespacing=0   noresize height=200 width=380 valign="top" src="acceptdenom.asp" 
				                 style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                      </table>

                      </center>
                    </div>
                  </div>
                  <font size="2" face="MS Sans Serif">&nbsp;&nbsp;&nbsp;</font></td>
                </tr>
              </table>

              </center>
            </div>
            <div align="center">
              <center>

              <table border="0" width="99%" cellspacing="0" cellpadding="0">
                <tbody>
                  <tr>
                    <td width="47%" height="5"></td>
                    <td width="41%" align="right" height="5"></td>
                    <td width="12%" height="5"></td>
                  </tr>
                  <tr>
                    <td width="47%">
                    <div align="center">
                      <center>

                      <table width="50%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="100%" align="middle"><input type="button" value="Accept" name="butaccpt" onclick="accept()" class="bgcolor"><input type="button" value="Reject" name="butreject" onclick="reject()" class="bgcolor"><input type="reset" value="Cancel" name="Cmdcancel" onclick="can()" class="bgcolor"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.asp&quot;)" class="bgcolor"></td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                    <td width="41%" align="right"><b><font color="#cc0000"><font class="textred">Total</font>&nbsp;</font></b></td>
                    <td width="12%"><input id="txttotal" name="txttotal" size="9" class="bgcolor1" style=" TEXT-ALIGN: right" readonly value="0.00"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                </center><center></center>
                <tr>
                  <td width="100%" colspan="3" align="middle">
              </table>

              <input type="hidden" name="hpr"></center><input type="hidden" name="hStatus">
            </div>
            <center><center></center></center>
        </table>

        </div>
      </td>
    </tr>
    </table>

  </div>
</form>

</body>

</html>
