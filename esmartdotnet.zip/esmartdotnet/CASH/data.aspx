<%@ Page Language="vb" CodeBehind="data.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.data" %>
<HTML>
<HEAD>

<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
</HEAD>
<%
set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=server.CreateObject("adodb.recordset")
	
 set rs=obj.singlerecordset("sbmst","BRANCHCODE, CURRENCYCODE, " & _
	"GLCODE, ACCNO, APPLICATIONDATE, NAME, CHEQUEBOOK, OPDATE, " & _
	"OPBAL, CLOSEDATE, EFFECTIVEDATE, MATURITYDATE, MATURITYVALUE, " & _
	"TDSYN, STATUS, NARRATION, USERID")
		

%><BODY>
<form name="dd" id="dd">
<TABLE border=0 cellpadding=0 cellspacing=0  bordercolor=#9999cc>
  <TBODY>
          <TR>    
             <TD><CENTER><H2> </H2></CENTER></TD>
             </TR>
             <TR>
            <TD width=610 valign=top width="20%",width=600>
              <TABLE border=0 align=center cellpadding=0 cellspacing=10 height=40 width="20%">
                <TBODY>
                 <TR>
                    <TD align= RIGHT>
                       <TABLE   ALIGN=border=0 bgcolor=#6699ff width="100%">
                         <TR bgcolor=Black> 
                           <TH nowrap><FONT color=#33ff99> Sl.No</FONT> </th>
                             <% FOR i=0 to RS.Fields.Count - 1 %>
                         <TH nowrap><FONT color=#33ff99><% = RS(i).name %></FONT> </TH>
                         <% NEXT %>
                         </TR>
                         <% WHILE not RS.EOF%>
                         <%j=j+1%>
  
                    <TR bgcolor=#ccffff>
                    <TD nowrap>
                    <INPUT name=check1 type=checkbox ><FONT COLOR=#993300><%=j%></FONT></TD>
                    <% FOR i = 0 to RS.Fields.Count - 1 %>
                    <TD  nowrap><FONT color=#993300 ><% = RS(i) %></FONT> </TD>
                    <% NEXT %>
                    </TR>
                    <% RS.MoveNext
                    WEND
                    RS.Close
                    %>
                    </TR>
                    </TBODY>
                    </TABLE><br>
                    <table align=center>
                    <tr><td><INPUT type="submit" value="approved" id=submit1 name=submit1></td><td><INPUT type="reset" value="Reset" id=reset1 name=Cancel></td></tr></form>


</BODY>
</HTML>
