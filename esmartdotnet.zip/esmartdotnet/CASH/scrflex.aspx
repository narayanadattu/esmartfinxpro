<%@ Page Language="vb" CodeBehind="scrflex.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.scrflex" %>
<%
	dim obj
	dim catdtls,dtls,balance
	dim prec,reamount,tempamt
	catdtls = Request.QueryString("catdtls")
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rsscr=server.CreateObject("adodb.recordset")
	set rsdtls=server.CreateObject("adodb.recordset")
	set rscontra=server.CreateObject("adodb.recordset")
	
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function scrflex_DblClick() 
{
	var jsel,scrcatcd,scrcatdes
	var scrcat=""
	sel=window.document.frmscr.scrflex.RowSel
	if (eval(window.document.frmscr.scrflex.Cols)>1)
	{
		var scrcatcd=window.document.frmscr.scrflex.textmatrix(sel,0)
		var scrcatdes=window.document.frmscr.scrflex.textmatrix(sel,1)
		var scrcat=scrcatcd+"~!~"+scrcatdes
		for(jsel=4;jsel<8;jsel++)
		{
			scrcat=scrcat+"~!~"+window.document.frmscr.scrflex.textmatrix(sel,jsel)
		}
		window.attachEvent(window.opener.categorycode(scrcat))
		window.close();
	}
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=scrflex EVENT=DblClick>
<!--
 scrflex_DblClick()
//-->
</SCRIPT>
<title>Suspence Account Details</title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmscr">
  <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="128" id="scrflex" style="HEIGHT: 150px; LEFT: 0px; TOP: 0px; WIDTH: 687px" width="687">
    <param name="_ExtentX" value="18177">
    <param name="_ExtentY" value="3969">
    <param name="_Version" value="393216">
    <param name="Rows" value="1">
    <param name="Cols" value="10">
    <param name="FixedRows" value="1">
    <param name="FixedCols" value="0">
    <param name="RowHeightMin" value="0">
    <param name="BackColor" value="-2147483643">
    <param name="ForeColor" value="-2147483640">
    <param name="BackColorFixed" value="-2147483633">
    <param name="ForeColorFixed" value="-2147483630">
    <param name="BackColorSel" value="-2147483635">
    <param name="ForeColorSel" value="-2147483634">
    <param name="BackColorBkg" value="8421504">
    <param name="GridColor" value="12632256">
    <param name="GridColorFixed" value="0">
    <param name="WordWrap" value="0">
    <param name="Redraw" value="-1">
    <param name="AllowBigSelection" value="-1">
    <param name="ScrollTrack" value="0">
    <param name="Enabled" value="-1">
    <param name="RightToLeft" value="0">
    <param name="TextStyle" value="0">
    <param name="TextStyleFixed" value="0">
    <param name="FocusRect" value="1">
    <param name="HighLight" value="1">
    <param name="FillStyle" value="0">
    <param name="GridLines" value="1">
    <param name="GridLinesFixed" value="2">
    <param name="ScrollBars" value="3">
    <param name="SelectionMode" value="0">
    <param name="MergeCells" value="0">
    <param name="AllowUserResizing" value="0">
    <param name="PictureType" value="0">
    <param name="BorderStyle" value="1">
    <param name="Appearance" value="1">
    <param name="MousePointer" value="0">
    <param name="GridLineWidth" value="1">
    <param name="FormatString" value="Category Code |&gt; Category Description |&gt; Sanctioned Amount |&gt; Returned Amount |&gt; Balance |^ Opening Date |&lt;Tranno |&lt; batchno|^ Remarks  |^ Application Date">
    <param name="OLEDropMode" value="0">
  </object>
  <input type="hidden" name="hpr" value="<%=prec%>">
  <%
  if len(catdtls)> 0 then 
	dtls=split(catdtls,"~!~")
	set rsscr=obj.singlerecordset("SCRMST S,SCRCATEGORYMST C,GENTRANSLOG G","S.CONTRACOMPLETE,S.CATEGORYCODE,c.CATEGORYNAME, nvl(S.OPBAL,0),S.OPDATE,S.TRANNO,S.BATCHNO,s.narration,S.APPLICATIONDATE","S.CONTRACOMPLETE<>'F' AND G.TRANNO=S.TRANNO AND G.STATUS='A' and  S.GLCODE='" & dtls(0) &"' and s.branchcode='" &  dtls(2) & "' and s.CURRENCYCODE='" &  dtls(3) &"' and s.CATEGORYCODE=c.CATEGORYCODE","TRANNO")
	if len(dtls(1))>0 then
		prec=dtls(1)
	else
		prec=session("precision")
	end if
	Response.Write "<script language=vbscript>" & chr(13)
	Response.Write "sub scrdtls()" & chr(13)
	if rsscr.EOF<>true then
	for irow=1 to rsscr.recordcount
	Response.Write "window.document.frmscr.scrflex.rows=window.document.frmscr.scrflex.rows+1" & chr(13)
	set rsdtls=obj.singlerecordset("SCRCONTRADTLS","NVL(sum(AMOUNT),0)","branchcode='" &  dtls(2) & "'  and CURRENCYCODE='" &  dtls(3) &"' and  ORIGINATINGTRANNO='" & rsscr(5) &"'")
	set rscontra=obj.singlerecordset("GENTEMPTRANSLOG","NVL(sum(AMOUNT),0)","branchcode='" &  dtls(2) & "'  and CURRENCYCODE='" &  dtls(3) &"' and moduleid='SCR' AND CONTRATRANNO='"& rsscr(5) &"'")
	if rscontra.EOF<>TRUE then
		if cdbl(rscontra(0))< 0  then
			tempamt=mid(rscontra(0),2)
		else
			tempamt=rscontra(0)
		end if
	else
		tempamt=0
	end if
	if ucase(trim(rsscr(0)))="P" then
		set rsdtls=obj.singlerecordset("SCRCONTRADTLS","sum(AMOUNT)","branchcode='" &  dtls(2) & "'  and CURRENCYCODE='" &  dtls(3) &"' and  ORIGINATINGTRANNO='" & rsscr(5) &"'")
		if cdbl(rsscr(3))< 0 then
			amount=mid(rsscr(3),2)
		else
			amount=rsscr(3)
		end if
		if rsdtls.BOF<>true and rsdtls.EOF<> true then
			if cdbl(rsdtls(0))< 0 then
				reamount=mid(rsdtls(0),2)+cdbl(tempamt)
			else
				reamount=cdbl(rsdtls(0))+cdbl(tempamt)
			end if
			balance=cdbl(amount)-cdbl(reamount)
		end if
	else
		if cdbl(rsscr(3))< 0 then
			amount=mid(rsscr(3),2)
		else
			amount=rsscr(3)
		end if
		reamount=0+cdbl(tempamt)
		balance=cdbl(amount)-cdbl(reamount)
	end if
	
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",0)=" & chr(34) & rsscr(1)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",1)=" & chr(34) & rsscr(2)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",2)=" & chr(34) & amount & chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",2)=gridprecision(window.document.frmscr.scrflex.textmatrix(" & irow & ",2),window.document.frmscr.hpr.value)" & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",3)=" & chr(34) & reamount & chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",3)=gridprecision(window.document.frmscr.scrflex.textmatrix(" & irow & ",3),window.document.frmscr.hpr.value)" & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",4)=" & chr(34) & balance & chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",4)=gridprecision(window.document.frmscr.scrflex.textmatrix(" & irow & ",4),window.document.frmscr.hpr.value)" & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",5)=" & chr(34) & rsscr(4)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",6)=" & chr(34) & rsscr(5)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",7)=" & chr(34) & rsscr(6)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",8)=" & chr(34) & rsscr(7)& chr(34) & chr(13)
	Response.Write "window.document.frmscr.scrflex.textmatrix("& irow &",9)=" & chr(34) & rsscr(8)& chr(34) & chr(13)
	rsscr.MoveNext()
	next
	elseif rsscr.BOF=true then
		str="^                         Description                                                    "
		status="No records Found"
		Response.Write "window.document.frmscr.scrflex.formatstring=" & chr(34) & str & chr(34) & chr(13)
		Response.Write "window.document.frmscr.scrflex.rows=2" & chr(13)
		Response.Write "window.document.frmscr.scrflex.cols=1" & chr(13)
		Response.Write "window.document.frmscr.scrflex.textmatrix(1,0)="& chr(34)& status & chr(34)& chr(13)
	end if
	Response.Write "end sub" & chr(13)
	Response.Write "call scrdtls()"	& chr(13)
	Response.Write "</script>" & chr(13)
	set obj=nothing
	set rsscr=nothing
	set rsdtls=nothing
end if
  %>

  <table align="center" class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"><input type="button" value=" Cancel " id="butcancel" name="butcancel" onclick="window.close()" class="bgcolor"></td>
    </tr>
  </table>

</form>

</body>

</html>
