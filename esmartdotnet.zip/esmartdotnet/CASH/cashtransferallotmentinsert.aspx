<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashtransferallotmentinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashtransferallotmentinsert" %>
<%a=Request.Form("hcount")
if len(trim(a))>0 then
	dim Arrtrans(0,2)
	redim Arrtrans(a,2)
	userid=session("userid")
	brcode=	Request.form("txtbranchcode")
	crcode=Request.form("txtcurrencycode")
	tocounterno=Request.form("txtcounterno")
	tocashid=Request.form("txtcashierid")
	
	amt=Request.form("txtamount")
	narration=Request.form("txtnarration")
	 rs=server.CreateObject("adodb.recordset")
	 objcou=server.CreateObject("queryrecordsets.fetchrecordsets")
	 rs=objcou.singlerecordset("cashcountermst","counterno", _
	"branchcode='" & brcode & "' and currencycode='" & crcode & "' and " & _
	"cashierid ='" & ucase(userid) & "'")
	if rs.EOF<>true and rs.BOF<> true then
	fromcounterno=rs(0).value
	end if
	 objcou=NOTHING
	dim kstr,values
	m=split(Request.Form("hvalue"),"|") 
	n=split(Request.Form("hpices"),"|") 
	p=split(Request.Form("htype"),"|") 
	for i=1 to Request.Form("hcount") 
		arrtrans(i,0)=m(i-1)
		arrtrans(i,1)=n(i-1)
		arrtrans(i,2)=p(i-1)					
	next
	'---------------------------------------------------------------------
   '''' for autonumber genration of allotment no
   dim RecTran
    RecTran=server.CreateObject("adodb.recordset")
   '''calling general query component
    Objfetchrec=server.CreateObject("queryrecordsets.fetchrecordsets")
    RecTran=ObjFetchRec.singlerecordset("CASHTRANSBTCASHIERSTRN", _
								"nvl(max(CASHTRANSFERNO),0)+1", _
								"branchcode='" & ucase(trim(BrCode)) & "'")' and " & _
								'"TOCASHIERID='" & ucase(trim(CashId)) &"'")
		if not RecTran.EOF and not RecTran.BOF then
			Transno=RecTran(0).value
		end if						
   ''''''-----------------------------------------------------------------------
   ''storing value in variables 
	kstr="BRANCHCODE,CURRENCYCODE,CASHTRANSFERNO,FROMCASHIERID,TOCASHIERID," & _
	"AMOUNT,STATUS,APPLICATIONDATE,SYSTEMDATE,FROMCOUNTERNO,TOCOUNTERNO,FROMMACHINEID"
	
	strvalues="'" & ucase(trim(brcode)) & "','" & ucase(trim(crcode)) & "'," & _
			  "'" & transno & "','" & ucase(trim(userid)) & "'," & _
			  "'" & ucase(trim(tocashid)) & "'," & amt & ",'P'," & _
			  "to_date('" & session("Applicationdate") & "', 'dd-mm-yyyy')," & _
			  "sysdate,'" & fromcounterno & "' ,'" & tocounterno & "'," & _
			  "'" & ucase(trim(SESSION("MACHINEID"))) & "'"
	 obj=server.CreateObject("CashTransaction.Transactions")	
	strmsg=obj.CashTrnInserts("CASHTRANSBTCASHIERSTRN",cstr(kstr),cstr(strvalues), _
				cstr(crcode),arrtrans) 
				Response.Write (strmsg)
	 obj=nothing	
	Response.Redirect ("cashtransferallotment.aspx?record="& strmsg)
	
	else
	
	strmsg="Cash Not Available To Transfer"
	Response.Redirect ("cashtransferallotment.aspx?record="& strmsg)
	
	end if


%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
