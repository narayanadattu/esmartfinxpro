<%@ Page Language="vb" CodeBehind="DayBeginChk.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.DayBeginChk" %>
<%
''''' for cashDayBegin

dim ObjDayBegin,
dim StrDayBegin,TransStatus
TransStatus=Request.Form("status"))
if TransStatus="CASH" then
	set ObjDayBegin=server.CreateObject("DayBegin.Transactions")
	StrDayBegin=ObjDayBegin.DayBeginCashQueryTrans(cstr(session(branchCode)),cstr(session(applicationdate)))
end if
Response.Redirect "DayBegin.asp?strmsg=" & StrDayBegin
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
