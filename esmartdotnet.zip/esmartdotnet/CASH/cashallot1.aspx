<%@ Page CodeBehind="cashallot1.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashallot1" %>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Allotment</title>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<script language="JavaScript" src="dhtmllib.js"></script>
<script language="JavaScript" src="navbar.js"></script>
<script language="JavaScript" src="menus.js"></script>
<SCRIPT LANGUAGE=javascript>
<!--
var st
function branch()
{   
	st="Bruser"
	window.open("List.asp" + "?"+"st="+st,st,"width=213%,height=150%,left=120,top=135")
}

function Bruser(str)
{
   assign(str,window.document.frmallot.txtbranchdesc,window.document.frmallot.txtbranchcode)
   window.document.all.den.src="masterdenom.asp"
   window.document.frmallot.txtavtotal.value ="0.00"
   window.document.frmallot.txttotal.value ="0.00"
   window.document.frmallot.txtcurrencycode.value =""
   window.document.frmallot.txtcurrencydesc.value =""
}

function currency()
{ 
  st="Curr"
  window.open("List.asp" + "?"+"st="+st,st,"width=220%,height=150%,left=550,top=135")
}

function Cashiercode()
{
   s1="CashID"
   s2=window.document.frmallot.txtbranchcode.value
   st=s1+"|"+s2
   
   window.open("List.asp" + "?"+"st="+st,"cash","width=170%,height=150%,left=120,top=180")

}
function Cashierid(str)
{   
	 assign(str,window.document.frmallot.txtCashierDesc,window.document.frmallot.txtCashierId)
	 count()
}

function  count()
{
		s = window.document.frmallot.txtCashierId.value 
		s1=window.document.frmallot.txtbranchcode.value 
		s2=window.document.frmallot.txtcurrencycode.value 
		st=s+"|"+s1+"|"+s2
		window.open ("counter.asp" + "?"+"st="+st,"counter","width=1%,height=1%")
}

function numeric()
{
 if(!(((event.keyCode>=48)&&(event.keyCode<=57))||(event.keyCode==46)))
   event.keyCode=0;
}


function Modify()
{
	window.document.frmallot.status.value=""
	window.document.frmallot.status.value="MODIFY"
	window.document.frmallot.action="CashAllotInsert.asp"
	window.document.frmallot.method="post"
	window.document.frmallot.submit();
	
}


function Currid(str)
{
var p
  k=str.split("-----")
  window.document.frmallot.txtcurrencydesc.value =k[0]
  window.document.frmallot.txtcurrencycode.value =k[1]
  prn=k[2].length-1
  window.document.frmallot.hpr.value=prn
  p=""
  for(f=1;f<=prn;f++)
  {
    p=p + "0"
  }
  pres= "0." + p 
  window.document.frmallot.txttotal.value=pres
  window.document.frmallot.txtamount.value =pres
  window.document.frmallot.txtavtotal.value =window.document.frmallot.txtamount.value
  Denom()
}

function Denom()
{ 
  frm="frmallot"
  s=window.document.frmallot.txtbranchcode.value
  s1=window.document.frmallot.txtcurrencycode.value 
  st=frm +"|"+"CASHVAULTMST"+"|"+s+ "|" + s1
  window.document.frames(0).frmdm.hdenom.value=st
  window.document.frames(0).frmdm.hspr.value=window.document.frmallot.hpr.value 
  window.document.frames(0).frmdm.method="post"
  window.document.frames(0).frmdm.action="masterdenom.asp"
  window.document.frames(0).frmdm.submit()
}

function Allot(str)
{
	var k,i,m
	k=str.split("*")
	window.document.frmallot.txtcounterno.value =k[0]
	window.document.frmallot.txtallotmentNo.value =k[1]
	window.document.frmallot.txtamount.focus()
}


function Insert()
{
var i,n,p,a,b,c
var k=1,a="",b="",c=""
 if (window.document.frmallot.txtamount.value==window.document.frmallot.txttotal.value)
 {
     p=window.document.frames(0).frmdm.hcnt.value
     for(i=0;i<=p-1;i++)
     {
        if(window.document.frames(0).frmdm.txtpieces(i).value!=0)
        {
		 k=k+1
		 a1=window.document.frames(0).frmdm.hps(i).value
		 a=a+a1+"|"
		 b1=window.document.frames(0).frmdm.txtpieces(i).value
		 b=b+b1+"|"
         c1=window.document.frames(0).frmdm.htype(i).value
         c=c+c1+"|"
        }
     }		 
		window.document.frmallot.hcount.value=k   
		window.document.frmallot.hvalue.value=a
		window.document.frmallot.hpices.value=b
		window.document.frmallot.htype.value=c
		window.document.frmallot.action="CashAllotInsert.asp"
		window.document.frmallot.method ="post"
		window.document.frmallot.submit()
		
 }	
 else
 {
	    alert("Amounts should be Equal")
		return
 }	
 	
}
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" bgcolor="#c7ba95" onload="init();Denom()">

<form name="frmallot">

  <table border="0" width="100%" bordercolor="#643428" cellspacing="0" cellpadding="0" height="480">
    <tr>
      <td width="100%" bgcolor="#C7BA95" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" bgcolor="#7d5445">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" bgcolor="#7d5445"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

       <%appdate=formatdatetime(date(),1)%>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="88%" bgcolor="#7d5445" colspan="4" align="middle"><b><font face="MS Sans Serif" color="#ffffff" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              Cash Allotment</font></b></td>
              <td width="52%" bgcolor="#7d5445" nowrap><font color="white"><%=appdate%></font></td>
            </tr>
          </table>

          <center>

          <table>
            <tr>
              <td height="15"><font face="MS Sans Serif" color="blue" size="4"><%=Request.QueryString("record")%></font></td>
            </tr>
          </table>

          </center>
          <div align="center">
            <center>

            <table width="99%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%" bgcolor="#7D5445"><b><font color="#ffffff" face="MS Sans Serif" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Branch Code</font></b></td>
                <td width="33%" bgcolor="#7d5445"><input name="txtbranchcode" size="9" value="0001" readonly><input type="button" value=" L " name="B3" onclick="branch()"><input name="txtbranchdesc" size="16" value="Main Branch" readonly style="BACKGROUND-COLOR: #B3A597; COLOR:WHITE"></td>
                <td width="36%" bgcolor="#7D5445" align="right"><b><font color="#ffffff" face="MS Sans Serif" size="1">Currency
                Code&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</font></b></td>
                <td width="51%" bgcolor="#7d5445"><input name="txtcurrencycode" size="9" value="INR" readonly><input type="button" value=" L " name="B3" onclick="currency()"><input name="txtcurrencydesc" size="16" value="Indian Rupees" readonly style="BACKGROUND-COLOR: #B3A597; COLOR:WHITE"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table border="1" width="98%" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top">
            <div align="center">
              <center>

              <table border="1" width="762" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="406" valign="top">
                  <div align="center">
                    <center>

                    <table border="1" width="98%" cellspacing="1" cellpadding="0" bordercolor="#D9D2B3">
                      <tbody>
                        <tr>
                          <td width="43%" bgcolor="#c7ba95" valign="top">

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="100%" height="30"></td>
                            </tr>
                          </table>

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="13%" bgcolor="#c7ba95" height="30"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;
                              Cashier ID&nbsp;&nbsp;</font></td>
                              <td width="42%" bgcolor="#c7ba95" height="30"><input name="txtCashierId" size="9" readonly style="BACKGROUND-COLOR: #B3A597; COLOR: white;"><input type="button" value=" L " name="B4" onclick="Cashiercode()" tabindex="0"><input name="txtCashierDesc" size="16" readonly style="BACKGROUND-COLOR: #B3A597; COLOR: white;"></td>
                            </tr>
                            <tr>
                              <td width="12%" bgcolor="#c7ba95" height="30"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;
                              Counter No&nbsp;</font></td>
                              <td width="41%" bgcolor="#c7ba95" height="30"><input name="txtcounterno" size="11" style="BACKGROUND-COLOR: #B3A597; COLOR: white; TEXT-ALIGN: right" readonly></td>
                            </tr>
                            <tr>
                              <td width="12%" bgcolor="#c7ba95" height="30"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;
                              Allotment No&nbsp;</font></td>
                              <td width="41%" bgcolor="#c7ba95" height="30"><input name="txtallotmentNo" size="11" style="BACKGROUND-COLOR: #B3A597; COLOR: white; TEXT-ALIGN: right" readonly></td>
                            </tr>
                            <tr>
                              <td width="12%" bgcolor="#c7ba95" height="30"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;
                              Amt Alloted&nbsp;</font></td>
                              <td width="41%" bgcolor="#c7ba95" height="30"><input name="txtamount" size="11" style="TEXT-ALIGN: right" value="0.00" onfocus="window.document.frmallot.txtamount.select()" onkeypress="numeric()" onblur="precision(window.document.frmallot.txtamount,window.document.frmallot.hpr.value)" tabindex="1"></td>
                            </tr>
                            <tr>
                              <td width="12%" bgcolor="#c7ba95" height="30">&nbsp;</td>
                              <td width="41%" bgcolor="#c7ba95" height="30">&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="53%" bgcolor="#C7BA95" height="38" colspan="2">&nbsp;</td>
                            </tr>
                          </table>

                    </table>

                    </div>
                  </center>
                  <td width="350" bgcolor="#c7ba95" valign="top">
                  <div id="denom" align="center">
                    <div align="center">
                      <center>

                      <table border="1" width="97%" cellspacing="1" cellpadding="0" bordercolor="#D9D2B3">
                        <tr>
                          <td width="100%">
                          <p align="center"><b><font color="#800000" size="2" face="MS Sans Serif">Available
                          Denominations in Vault</font></b></td>
                        </tr>
                        <tr>
                          <td>
                          <div align="center">
                            <center>

                            <table border="0" bordercolor="#7D5445" cellspacing="0" cellpadding="0" width="60%">
                              <tr>
                                <td valign="top"><iframe id=den align=center  frameborder=0 framespacing=0   noresize height=200 width=328 valign="top" src = "masterdenom.asp" 
                  style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                      </table>

                      </center>
                    </div>
                  </div>
                  </td>
              </table>

              </center>
            </div>

            <table border="0" width="762" cellspacing="0" cellpadding="0" height="0">
              <tr>
                <td width="389" colspan="2" height="5"></td>
                <td width="64" align="right" height="5"></td>
                <td width="166" height="5"></td>
                <td align="middle" width="124" height="5"></td>
                <td width="9" height="5"></td>
              </tr>
              <tr>
                <td width="389" colspan="2">
                <div align="center">
                  <center>

                  <table border="1" width="20%" bordercolor="#7D5445" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%"><input type="button" value="    OK    " name="buttInsert" onclick="Insert()" tabindex="2" style="BACKGROUND-COLOR: #7D5445; COLOR:WHITE"><input type="button" value="Cancel" name="buttcancel" onclick="window.location.href='cashallot.asp'" style="BACKGROUND-COLOR: #7D5445; COLOR:WHITE"></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
                <td width="64" align="right"><b><font size="2" face="MS Sans Serif" color="#cc0000">Total&nbsp;</font></b></td>
                <td width="166"><input type="text" name="txtavtotal" size="9" value="0.00" style="BACKGROUND-COLOR: #B3A597; COLOR: white;TEXT-ALIGN: right" disabled onchange="precision(window.document.frmallot.txtavtotal,window.document.frmallot.hpr.value)"></td>
                <td align="middle" width="124">&nbsp;&nbsp;<input name="txttotal" value="0.00" size="9" style="BACKGROUND-COLOR: #B3A597; COLOR: white;TEXT-ALIGN: right" disabled onblur="precision(window.document.frmallot.txttotal,window.document.frmallot.hpr.value)"></td>
                <td width="9"></td>
              </tr>
              <tr>
                <td width="173" height="13"></td>
                <td width="216" height="13"></td>
                <td width="230" align="right" height="13" colspan="2"></td>
                <td align="middle" width="124" height="13"></td>
                <td width="9" height="13"></td>
              </tr>
              <tr>
                <td width="752" height="13" colspan="6">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" height="20"></td>
                  </tr>
                </table>

            </table>

        </table>

        </center>
      </div>
    </tr>
  </table>

  <input type="hidden" name="txtctotal"><input type="hidden" name="status"><input type="hidden" name="htype" value="0"><input type="hidden" name="hvalue" value="0"><input type="hidden" name="hpices" value="0"><input type="hidden" name="hcount" value="0"><input type="hidden" name="hpr">
</form>

</body>

</html>
