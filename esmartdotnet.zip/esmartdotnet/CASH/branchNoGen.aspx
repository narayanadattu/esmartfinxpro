<%@ Page Language="vb" CodeBehind="branchNoGen.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.branchNoGen" %>
<%on error resume next
Dim ArrTrans(0,4),actualAmt
Dim strvalues,strvalue,objNoGen,ObjIns,strinsrt,strtranno,strbatchno,strfldnms,paymode,i,strWhrCond
set objNoGen=Server.CreateObject("GeneralTranQueries.TransactionQueries")

paymode=Request("paymode")

select case paymode
'--------------------------------------------------------------------------------------------
CASE "CH" ''''CASH MODE
	 if  Request.QueryString("flag")="" then
		  strbatchno=objNoGen.getbatchno
		  Redim strtranno(2)
		  for i=0 to 1	
		    strtranno(i)=objNoGen.gettranno		
		  next
	 else
		strbatchno=Trim(Request.QueryString("flag"))
		Redim strtranno(2)
		for i=0 to 1	
			strtranno(i)=objNoGen.gettranno		
		next
	 End if
	'''================
	set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")	
	strvalue=Split(Request.QueryString("strIn"),"~")
	
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
		"ENTEREDTIMEBAL,STATUS,NARRATION,BATCHNO,TRANNO,CASHIERID,ENTEREDBY,"&_
		"ENTEREDMACHINE,SYSTEMDATE,APPLICATIONDATE"  
		
    actualAmt="-"&strvalue(6)
	actbal=strvalue(6)	
	
if Request("paytype")="Rcpt" then
	actualAmt=strvalue(6)
elseif Request("paytype")="pay" then
	actualAmt="-"&strvalue(6)
end if
 

   strvalues="'"&strvalue(0)&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			actualAmt&"','"&strvalue(7)&"','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(0)&"','123','','V3',to_date('11-Jun-2001','dd-mon-yyyy'),to_date('11-Jun-2001','dd-mon-yyyy')"
					                                                         
   strvalues1="'"&strvalue(0)&"','"&strvalue(1)&"','CASH','"&strvalue(11)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			actbal&"','"&strvalue(7)&"','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(1)&"','123','','V3',to_date('11-Jun-2001','dd-mon-yyyy'),to_date('11-Jun-2001','dd-mon-yyyy')"					
  
   strvar=strvalues &"|" & strvalues1
   
   ArrTrans(0,0)="I"     
   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
   ArrTrans(0,2)=strfldnms 'passing columns 
   ArrTrans(0,3)=strvar  'passing values
   ArrTrans(0,4)=""'passing where condition
   
  strinsrt=ObjIns.DataTransactions(ArrTrans)
  
   
sub onTransactionCommit()
	Response.Write "commit"
end sub

sub onTransactionAbort()
	Response.Write "rollback"
end sub

set ObjIns=nothing
  
'--------------------------------------------------------------------------------------------
 CASE "TRINS"   '''''TRANSFER MODE(Insertion)
        
		if  Request.QueryString("flag")="" then
		  strbatchno=objNoGen.getbatchno
		  strtranno=objNoGen.gettranno		
		else
			 strbatchno=Trim(Request.QueryString("flag"))
			 strtranno=objNoGen.gettranno		
		End if

	''================
	set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")
	strvalue=Split(Request.QueryString("strIn"),"~")
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
			"ENTEREDTIMEBAL,STATUS,NARRATION,BATCHNO,TRANNO,CASHIERID,ENTEREDBY,"&_
			"ENTEREDMACHINE,SYSTEMDATE,APPLICATIONDATE"  

	strvalues="'"&strvalue(0)&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			strvalue(6)&"','"&strvalue(7)&"','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno&"','123','','V3',to_date('11-Jun-2001','dd-mon-yyyy'),to_date('11-Jun-2001','dd-mon-yyyy')"		
     
   ArrTrans(0,0)="I"     
   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
   ArrTrans(0,2)=strfldnms  'passing columns
   ArrTrans(0,3)=strvalues  'passing values
   ArrTrans(0,4)="" 'passing where condition
   
	strinsrt=ObjIns.DataTransactions(ArrTrans)  ''INSERTING THROUH OBJECT

End select
'--------------------------------------------------------------------------------------------
	dd=day(date())
	mm=month(date())
	yy=year(date())		
	formatdate=dd&"-"&mm&"-"&yy%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<script language="javascript">
	function sendBatchNo(){
	  var str1=window.document.frm1.batGenNo1.value;
	  var str2=window.document.frm1.batGenNo2.value;
	  var str='<%=Request("paytype")%>'
	  if(str=='Rcpt'){
		window.attachEvent(window.opener.ReceiptFlexPopulate(str1,str2));
	  }
	  else if(str=='Pay'){
		window.attachEvent(window.opener.FlexPopulate(str1,str2));
	  }
	  else if(str=='transfer'){
		window.attachEvent(window.opener.FlexPopulate(str1,str2));
	  }
	  else{}
	  window.close();// 
	}
</script>
<body onload="sendBatchNo()">

<form name="frm1">
  <%if paymode="CH" then%>
  <input name="batGenNo1" value="<%=strbatchno%>~<%=strtranno(0)%>~<%=formatdate%>~" size="20">
  <input name="batGenNo2" value="<%=strbatchno%>~<%=strtranno(1)%>~<%=formatdate%>~" size="20">
  <%elseif paymode="TRINS" then%>
  <input name="batGenNo1" value="<%=strbatchno%>~<%=strtranno%>~<%=formatdate%>~" size="20">
  <input name="batGenNo2" value size="20">
  <%end if%>
  <p>&nbsp;</p>
</form>

</body>

</html>
