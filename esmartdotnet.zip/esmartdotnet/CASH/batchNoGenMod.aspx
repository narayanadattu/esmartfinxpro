<%@ Page Language="vb" CodeBehind="batchNoGenMod.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.batchNoGenMod" %>
<%on error resume next
Dim ArrTrans(3,4),actualAmt
dim strabbbrcode
Dim strvalues,strvalue,stvalue1,objNoGen,ObjIns,strinsrt,strtranno,strbatchno,strfldnms,paymode,i,strWhrCond,strWhrCnd
set objNoGen=Server.CreateObject("GeneralTranQueries.TransactionQueries")
dim vUserid,vMachineId,vAppdate
    vUserid=session("userid")
    vMachineId=session("machineid")
    vAppdate=session("applicationdate")
    paymode=Request("paymode")
    strabbbrcode=Request("abbbrcode")
    dim contra
     contra=Request.QueryString("Contran")
     Response.Write Request("abbbrcode")
select case paymode
'--------------------------------------------------------------------------------------------
	CASE "TRMOD"   '''''TRANSFER MODE(updation)
	
	strvalue=Split(Request.QueryString("strIn"),"~")
	Response.Write strvalue
	modid=strvalue(2)
	modetran=strvalue(7)
if modid="REM" and modetran="2" then 
	strbatchno=strvalue(11)
	strtranno=strvalue(12)	
	strtranno2=strvalue(14)
	strtranno3=strvalue(15)
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,"&_
			"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
			"MACHINEID,SYSTEMDATE,APPLICATIONDATE"  
                         ''"&strvalue(7)&"'~=MODE OF TRAN 17OCT 
	strvalues="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'"&strvalue(2)&"'~'"&strvalue(3)&"'~'"&strvalue(4)&"'~'"&strvalue(5)&"'~'"& _
			strvalue(6)&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
			strbatchno&"'~'"&strtranno&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')"	
            'commission-------- '"&strvalue(7)&"'~                                      '"&strvalue(2)&"          '"&strvalue(4)&"
  	strvalue1="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'"& strvalue(16)&"'~'"& strvalue(17)&"'~''~'"&strvalue(5)&"'~'"& _
			strvalue(18)&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
			strbatchno&"'~'"&strtranno2&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')"	
			
			'cash -------	'"&strvalue(7)&"'~						
    strvalue2="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'CASH'~'"&strvalue(13)&"'~'1'~'"&strvalue(5)&"'~'"& _
			strvalue(19)&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
			strbatchno&"'~'"&strtranno3&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')"	
   
    
    strWhrCond="batchno='"&trim(strbatchno)&"' and tranno='"&trim(strtranno)&"'"
    strWhrCnd1="batchno='"&trim(strbatchno)&"' and tranno='"&trim(strtranno2)&"'"
    strWhrCnd2="batchno='"&trim(strbatchno)&"' and tranno='"&trim(strtranno3)&"'"
    
   
            
   ArrTrans(0,0)="U"    'remtransaction
   ArrTrans(0,1)="GENTEMPTRANSLOG"  'passing the table name
   ArrTrans(0,2)=strfldnms  'passing columns
   ArrTrans(0,3)=strvalues  'passing values
   ArrTrans(0,4)=strWhrCond 'passing where condition
   
   ArrTrans(1,0)="U" 'commisiontransaction
   ArrTrans(1,1)="GENTEMPTRANSLOG"
   ArrTrans(1,2)=strfldnms
   ArrTrans(1,3)=strvalue1
   ArrTrans(1,4)=strWhrCnd1
   
   ArrTrans(2,0)="U"'cashtransaction
   ArrTrans(2,1)="GENTEMPTRANSLOG"
   ArrTrans(2,2)=strfldnms
   ArrTrans(2,3)=strvalue2
   ArrTrans(2,4)=strWhrCnd2
    
   set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")
   strinsrt=ObjIns.DataTransactions(ArrTrans)  ''Updating
	
elseif len(strabbbrcode)>0 then     'Y.naveen Kumar If ABB

dim strabbresbr,strabborgbr,strresbatchno,strorgbatchno,strrestranno1,strrestranno2
dim strorgtranno1,strorgtranno2
    strabbresbr=strvalue(15)
    strresbatchno=strvalue(16)
    strrestranno1=strvalue(17)
    strrestranno2=strvalue(18)
    strorgbatchno=strvalue(11)
    strabborgbr=strvalue(0)
    strorgtranno1=strvalue(12)
    strorgtranno2=strvalue(14)
    
    strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
			"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
			"MACHINEID,SYSTEMDATE,APPLICATIONDATE"  
			
    strvalues="'"&strabborgbr&"'~'"&strvalue(1)&"'~'"&strvalue(2)&"'~'"&strvalue(3)&"'~'"&strvalue(4)&"'~'"&strvalue(5)&"'~'"& _
				strvalue(6)&"'~'"&"2"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strorgbatchno&"'~'"&strorgtranno1&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'"& contra &"'"	
             
    'Response.Write strfldnms
  	strvalue1="'"&strabborgbr&"'~'"&strvalue(1)&"'~'ABB'~'" & strvalue(19)& "'~'1'~'"&strvalue(5)&"'~'-"& _
				strvalue(6)&"'~'"&"1"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strorgbatchno&"'~'"&strorgtranno2&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'" & contra &"'"	
				
    strvalue2="'"&strabbresbr&"'~'"&strvalue(1)&"'~'ABB'~'" &strvalue(19)& "'~'"&strvalue(4)&"'~'"&strvalue(5)&"'~'"& _
				strvalue(6)&"'~'"&"2"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strresbatchno&"'~'"&strrestranno1&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'"& contra &"'"	
             
     
  	strvalue3="'"&strabbresbr&"'~'"&strvalue(1)&"'~'CASH'~'"&strvalue(13)&"'~'1'~'"&strvalue(5)&"'~'-"& _
				strvalue(6)&"'~'"&"1"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strresbatchno&"'~'"&strrestranno2&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'" & contra &"'"					
    
    
    'Response.Write 	strvalues & "ynk" & strvalue1 & "ynk" & strvalue2 & "ynk" & strvalue3
   
    
    strWhrCond="batchno='"&trim(strorgbatchno)&"' and tranno='"&trim(strorgtranno1)&"' and branchcode='"&trim(strabborgbr)&"'"
    strWhrCnd1="batchno='"&trim(strorgbatchno)&"' and tranno='"&trim(strorgtranno2)&"' and branchcode='"&trim(strabborgbr)&"'"
    strWhrCnd2="batchno='"&trim(strresbatchno)&"' and tranno='"&trim(strrestranno1)&"' and branchcode='"&trim(strabbresbr)&"'"
    strWhrCnd3="batchno='"&trim(strresbatchno)&"' and tranno='"&trim(strrestranno2)&"' and branchcode='"&trim(strabbresbr)&"'"
   
            
   ArrTrans(0,0)="U"    'remtransaction
   ArrTrans(0,1)="GENTEMPTRANSLOG"  'passing the table name
   ArrTrans(0,2)=strfldnms  'passing columns
   ArrTrans(0,3)=strvalues  'passing values
   ArrTrans(0,4)=strWhrCond 'passing where condition
   
   ArrTrans(1,0)="U" 'commisiontransaction
   ArrTrans(1,1)="GENTEMPTRANSLOG"
   ArrTrans(1,2)=strfldnms
   ArrTrans(1,3)=strvalue1
   ArrTrans(1,4)=strWhrCnd1
   
   ArrTrans(2,0)="U"'cashtransaction
   ArrTrans(2,1)="GENTEMPTRANSLOG"
   ArrTrans(2,2)=strfldnms
   ArrTrans(2,3)=strvalue2
   ArrTrans(2,4)=strWhrCnd2
   
   ArrTrans(3,0)="U"'cashtransaction
   ArrTrans(3,1)="GENTEMPTRANSLOG"
   ArrTrans(3,2)=strfldnms
   ArrTrans(3,3)=strvalue3
   ArrTrans(3,4)=strWhrCnd3
    
   set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")
   strinsrt=ObjIns.DataTransactions(ArrTrans)  ''Updating
	Response.Write strinsrt
	
else	
strvalue=Split(Request.QueryString("strIn"),"~")

REDim ArrTrans(1,4)
	modid=strvalue(2)
	strbatchno=strvalue(11)
	strtranno=strvalue(12)	
	strtranno2=strvalue(14)
	'strvalue(7)
	' Response.Write "ynk"
	if ucase(modid)="SCR" then 
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
			"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
			"MACHINEID,SYSTEMDATE,APPLICATIONDATE,contratranno"  

	strvalues="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'"&strvalue(2)&"'~'"&strvalue(3)&"'~'"&strvalue(4)&"'~'"&strvalue(5)&"'~'"& _
				strvalue(6)&"'~'"&"2"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strbatchno&"'~'"&strtranno&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'"& contra &"'"	
             
     
  	strvalue1="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'CASH'~'"&strvalue(13)&"'~'1'~'"&strvalue(5)&"'~'"& _
				strvalue(6)&"'~'"&"1"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
				strbatchno&"'~'"&strtranno2&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')~'" & contra &"'"	
	
	strWhrCond="batchno='"&trim(strbatchno)&"' and tranno='"&trim(strtranno)&"'"
	
	strWhrCnd="batchno='"&trim(strbatchno)&"'  and tranno='"&trim(strtranno2)&"'"

	else
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
			"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
			"MACHINEID,SYSTEMDATE,APPLICATIONDATE" 
			
	strvalues="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'"&strvalue(2)&"'~'"&strvalue(3)&"'~'"&strvalue(4)&"'~'"&strvalue(5)&"'~'"& _
			strvalue(6)&"'~'"&"2"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
			strbatchno&"'~'"&strtranno&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')"
			
                                                   '"&strvalue(2)&"          '"&strvalue(4)&"
  	strvalue1="'"&strvalue(0)&"'~'"&strvalue(1)&"'~'CASH'~'"&strvalue(13)&"'~'1'~'"&strvalue(5)&"'~'"& _
			strvalue(6)&"'~'"&"1"&"'~'"&strvalue(8)&"'~'"&strvalue(9)&"'~'"&strvalue(10)&"'~'"&_
			strbatchno&"'~'"&strtranno2&"'~'"&vUserid&"'~'"&vUserid&"'~'"&vMachineId&"'~to_date('"&sysdate&"','dd-mon-yyyy')~to_date('"&vAppdate&"','dd-mon-yyyy')"	

    strWhrCond="batchno='"&trim(strbatchno)&"' and tranno='"&trim(strtranno)&"'"
	
	strWhrCnd="batchno='"&trim(strbatchno)&"'  and tranno='"&trim(strtranno2)&"'"

	end if							
	
	 ArrTrans(0,0)="U"    
	 ArrTrans(0,1)="GENTEMPTRANSLOG"	'passing the table name
	 ArrTrans(0,2)=strfldnms			'passing columns
	 ArrTrans(0,3)=strvalues			'passing values
	 ArrTrans(0,4)=strWhrCond			'passing where condition
	 
	 ArrTrans(1,0)="U"
     ArrTrans(1,1)="GENTEMPTRANSLOG"
     ArrTrans(1,2)=strfldnms
     ArrTrans(1,3)=strvalue1
     ArrTrans(1,4)=strWhrCnd
   
     set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")
	 strinsrt=ObjIns.DataTransactions(ArrTrans)  ''Updating	
	
     Response.Write strinsrt
    
     
end if   

End select %>
	
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<script language="javascript">
	function sendBatchNo(){
	  var str1=window.document.frm1.Trans.value;
	  var str='<%=Request("paytype")%>'
	  var str2=window.document.frm1.remTrans.value;    
	  var vRslt=window.document.frm1.trnRslt.value;
	  var strabbcode='<%=Request("abbbrcode")%>'
	  //alert("ok")
	 // alert(strabbcode)
	  if(strabbcode.length>0)
	  {
	  window.attachEvent(window.opener.AbbReceiptFlexPopulatemod(vRslt));
	  }
	  else if((str=='Rcpt')&& (str2=="REM")){
	   	window.attachEvent(window.opener.RemFlexPopulateMod(vRslt));
	  }
	  else if(str=='Rcpt'){
		window.attachEvent(window.opener.FlexPopulateMod(str1,vRslt));
	  }
	  else if(str=='Pay'){
		window.attachEvent(window.opener.FlexPopulate(str1,vRslt));
	  }
	  else if(str=='transfer'){
		window.attachEvent(window.opener.FlexPopulateMod(str1,vRslt));
	  }
	  else{}
	  window.close(); //
	} 
	//onload="sendBatchNo()"
</script>
<body onload="sendBatchNo()">

<form name="frm1">
  <%if paymode="TRMOD" then%>
  <input type="hidden" id="hbno4" name="Trans" value="<%=strinsrt%>"><input type="hidden" id="hbno4" name="remTrans" value="<%=modid%>"><input name="trnRslt" value="<%=strinsrt%>" size="20">
  <%end if%>
  <p>&nbsp;</p>
</form>

</body>

</html>
