<%@ Page aspcompat="true" explicit="false" CodeBehind="cashtransferacceptinsert.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashtransferacceptinsert" %>
<%
dim strmsg
Dim  ArrTran(0,4)
dim status
status=trim(Request.Form("hStatus"))
	brcode=Request.Form("txtbranchcode")
	crcode=Request.Form("txtcurrencycode")
	userid=session("userid")
	Fromcashierid=Request.Form("txtcashierid")
	transno=Request.Form("txttransno")
	
IF len(brcode)>0 and len(crcode)>0 and len(Fromcashierid)>0 and len(transno)>0 then
 if Status="TRANSFER" then	  
	 Obj=server.CreateObject("CashTransaction.Transactions")
	strmsg=Obj.CashTransferAcceptance(cstr(ucase(trim(brcode))),cstr(ucase(trim(crcode))), _
			cstr(session("Applicationdate")),cstr(ucase(trim(userid))), _
			cstr(ucase(trim(Fromcashierid))),cstr(transno),cstr(ucase(trim(session("Machineid")))))
 elseif Status="REJECT" then
		StrTabName="CASHTRANSBTCASHIERSTRN"
		StrFldNames="status"
		StrUpFldvalues="'R'"
		strCondition="branchcode='" & ucase(trim(brcode)) &"' and " & _
		"currencycode='" & ucase(trim(crcode)) &"' and " & _
		"CASHTRANSFERNO='" & transno & "' and FROMCASHIERID='" & ucase(trim(Fromcashierid)) & "'"
		 Obj=SERVER.CreateObject("GeneralTransactions.DBTransactions")
			
			ArrTran(0,0)="U"			'passing the TransactionType
			ArrTran(0,1)=StrTabName		'passing the tablename
			ArrTran(0,2)=StrFldNames	'passing the FieldNames
			ArrTran(0,3)=StrUpFldvalues	'passing the Fieldvalues
			ArrTran(0,4)=strCondition	'passing the Fieldvalues
			
			Strmsg= Obj.DataTransactions(ArrTran)
			'Response.Write (strmsg)
	end if		
   OBJ=NOTHING
  Response.Redirect ("cashtransferaccept.aspx?record=" &strmsg)
else
  strmsg="Fields Should not be Null"
  Response.Redirect ("cashtransferaccept.aspx?record=" &strmsg)
end if
 
 %> 

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
