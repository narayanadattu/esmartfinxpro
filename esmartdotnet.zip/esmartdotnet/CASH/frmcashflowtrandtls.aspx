<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmcashflowtrandtls.aspx.vb" Inherits="eSmartDotNet.frmcashflowtrandtls"%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--

// to return and close the list window
function List()
{
  var kstr
  kstr= window.document.frmacc.hbno.value 
  if(kstr)
  window.attachEvent(window.parent.DisplayCode(kstr))  // retunn the value and raise the event 
  window.close()								// close the window
 
}

//-->
</SCRIPT>

<%
  '''''' Variable Declaration
  dim rs,obj,c,obj1,rs1,str1,table1
  '''' read the value from calling form
  str1=Request.QueryString("strval")     
    	rsAppDt=server.CreateObject("adodb.recordset")
			objAppDt=server.CreateObject("ReportPurposeOnly.Reportonly")
				objRep=server.CreateObject("ReportPurposeOnly.Reportonly")
  '''''' create the instance of componenets
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  
  ''''' create the instance of recordsets
   rs=server.CreateObject("adodb.recordset")
  if(len(str1)>0) then
	Response.Write (str1)
	str1=split(str1,"|")
	
	
	if str1(2)="Consolidated" then
			strApplDate=session("applicationdate")
	else if (str1(2)="Branchwise") then 
	
			strAppDt="SELECT TO_CHAR(APPLICATIONDATE,'DD-Mon-YYYY') FROM GENAPPLICATIONDATEMST WHERE " & _
			"BRANCHCODE='" & str1(1) & "' AND ((DAYBEGINSTATUS='O' AND DAYENDSTATUS='N' " & _
			"AND HODAYBEGINSTATUS='O' AND HODAYENDSTATUS='N') OR (DAYBEGINSTATUS='O' AND " & _
			"DAYENDSTATUS='O' AND HODAYBEGINSTATUS='O' AND HODAYENDSTATUS='N'))"
		
			rsAppDt = objAppDt.SingleSelectStat(strAppDt)
			if objAppDt.ConnError="Connected" then 
				if not rsAppDt.bof and not rsAppDt.eof then
					strApplDate=rsAppDt(0).value
				end if
			end if
			rsAppDt=nothing
			objAppDt=nothing
	
	end if
	
	
	if ((str1(2)="Branchwise") or (str1(2)="Consolidated")) then 
		if cDate(str1(4))=cDate(strApplDate) then

	dim glBalUp as new Gengldaybookupd.Gengldaybook
	dim rtnMsg as boolean
	objBrCode=server.CreateObject("ReportPurposeOnly.Reportonly")
	if str1(2)="Consolidated" then
		strBrCodeCons="SELECT  a.branchcode FROM GENBANKBRANCHMST a,GENBRANCHPMT b WHERE a.status='R' AND BRANCHTYPE<>'HO' AND a.branchcode=b.branchcode ORDER BY a.branchcode"
		rsBrCode = objBrCode.SingleSelectStat(strBrCodeCons)
		if objBrCode.ConnError="Connected" then 
			if not rsBrCode.bof and not rsBrCode.eof then
				do until rsBrCode.eof
					rtnMsg = glBalUp.Gengldaybookupd(rsBrCode(0).value, str1(6), str1(4), session("userid"),session("Machineid"))
				rsBrCode.movenext()
				loop
			end if
		end if
	else
		rtnMsg = glBalUp.Gengldaybookupd(str1(1), str1(6), str1(4), session("userid"),session("Machineid"))
	end if
	glBalUp=nothing
  end if
	end if 
	
if str1(2)="Branchwise" then
	counterno1 = ""
	strSql = "select applicationdate,SUM(OPENINGBALANCE),SUM(gtotal1) , SUM(gtotal2),SUM(CLOSINGBALANCE)  from GENGLDAYBOOK where applicationdate BETWEEN '" & str1(3) & "' AND '" & str1(4) & "' AND glcode='" & str1(5) & "' and moduleid = '"& str1(7) &"' and branchcode='" & str1(1) & "' and currencycode='" & str1(6) & "'  GROUP BY 	applicationdate ORDER BY applicationdate "


			
			rs = objRep.SingleSelectStat(strSql)
if not rs.EOF and not rs.BOF then
		do while not rs.eof
						counterno1=counterno1 & rs(0).value  & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~"  & "|"			
			
			rs.MoveNext 
		loop  
	else
		counterno1="No Data found"
	end if		 
	
	
	rs=nothing
	counterno2= ""
	strSql = "SELECT NVL(a.moduleid,b.moduleid),NVL(a.receipts,0) receipts,NVL(b.payments,0) payments FROM(SELECT moduleid,SUM(amount) receipts FROM CASHRECEIPTSTRNbkp WHERE branchcode = '" & str1(1) & "' AND  applicationdate BETWEEN '" & str1(3) & "'  AND '" & str1(4) & "'	GROUP BY moduleid) a FULL outer join (SELECT moduleid,SUM(amount) payments FROM CASHPAYMENTSTRNBKP WHERE branchcode = '" & str1(1) & "' AND  applicationdate BETWEEN '" & str1(3) & "' AND '" & str1(4) & "'	GROUP BY moduleid) b ON  a.moduleid= b.moduleid"
			
			rs = objRep.SingleSelectStat(strSql)
if not rs.EOF and not rs.BOF then
		do while not rs.eof
						counterno2=counterno2 & rs(0).value  & "~" & rs(1).value & "~" & rs(2).value & "~"   & "|"			
			
			rs.MoveNext 
		loop  
	else
		counterno2="No Data found"
	end if		 
	
	else if str1(2)="Consolidated" then
	
	counterno1 = ""
	strSql = "select applicationdate,SUM(OPENINGBALANCE),SUM(gtotal1) , SUM(gtotal2),SUM(CLOSINGBALANCE)  from GENGLDAYBOOK where applicationdate BETWEEN '" & str1(3) & "' AND '" & str1(4) & "' AND glcode='" & str1(5) & "' and moduleid = '"& str1(7) &"'  and currencycode='" & str1(6) & "'  GROUP BY 	applicationdate ORDER BY applicationdate "


			
			rs = objRep.SingleSelectStat(strSql)
	if not rs.EOF and not rs.BOF then
			do while not rs.eof
							counterno1=counterno1 & rs(0).value  & "~" & rs(1).value & "~" & rs(2).value & "~" & rs(3).value & "~" & rs(4).value & "~"  & "|"			
				
				rs.MoveNext 
			loop  
		else
			counterno1="No Data found"
		end if		 
	
	
	rs=nothing
	counterno2= ""
	strSql = "SELECT NVL(a.moduleid,b.moduleid),NVL(a.receipts,0) receipts,NVL(b.payments,0) payments FROM(SELECT moduleid,SUM(amount) receipts FROM CASHRECEIPTSTRNbkp WHERE   applicationdate BETWEEN '" & str1(3) & "'  AND '" & str1(4) & "'	GROUP BY moduleid) a FULL outer join (SELECT moduleid,SUM(amount) payments FROM CASHPAYMENTSTRNBKP WHERE   applicationdate BETWEEN '" & str1(3) & "' AND '" & str1(4) & "'	GROUP BY moduleid) b ON  a.moduleid= b.moduleid"
			
			rs = objRep.SingleSelectStat(strSql)
	if not rs.EOF and not rs.BOF then
			do while not rs.eof
							counterno2=counterno2 & rs(0).value  & "~" & rs(1).value & "~" & rs(2).value & "~"   & "|"			
				
				rs.MoveNext 
			loop  
		else
			counterno2="No Data found"
		end if		 
	
	end if
	
		
	
	obj=nothing
    rs=nothing
  
  counterno = counterno1 & "$" &  counterno2
 end if 
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=counterno%>">
<input type="hidden" name="hidstat">
</form>

</body>

</html>