<%@ Page CodeBehind="cashrefundaccp.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashrefundaccp" %>
<html>
<!-- This form is used for Refund Acceptence  -->
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : cashrefundaccp.aspx									*
'*	Purpose	  	     : This form is used to accept the refunded amount     	*
'*																			*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|    Shobanbabu	    |    5-MAY-2001    |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Refund Acceptence</title>
<%
' Menu and Client side validations '
%>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
/*
//---------------This Function is  to select Branch code--------------
function branch()
{   
	st="Bruser"
	window.open("List.aspx" + "?"+"st="+st,st,"width=200%,height=145% left=117 top=206")
}
//---------------This Function is  to assign  Branch code,Description--------------
function Bruser(kstr)
{  
	assign(kstr,window.document.frmrefundAccept.txtBranchdesc,window.document.frmrefundAccept.txtBranchcode) 
	window.document.frmrefundAccept.txtCurrencycode.value =""
	window.document.frmrefundAccept.txtCurrencydesc.value =""    
	window.document.frmrefundAccept.txtCashid.value =""
	window.document.frmrefundAccept.txtCashdesc.value =""
	window.document.frmrefundAccept.txtCounterNo.value =""
	window.document.frmrefundAccept.txtRefundno.value =""
	window.document.frmrefundAccept.txtRefundAmt.value ="0.00"
	window.document.all.refcash.src="acceptdenom1.aspx"  	     
}
//---------------This Function is  to select Currency code--------------
function currency()
{ 
	st="Curr"
	window.open("List.aspx" + "?"+"st="+st,st,"width=220%,height=150% left=550 top=206")
}
//---------------This Function is  to assign  Currency code,Description--------------
 function Currid(kstr)
 {
	var precision,total,k,inti	
	//k=kstr.split("-----")
	//window.document.frmrefundAccept.txtCurrencydesc.value =k[0]
	//window.document.frmrefundAccept.txtCurrencycode.value =k[1]	
	assign(kstr,window.document.frmrefundAccept.txtCurrencydesc,window.document.frmrefundAccept.txtCurrencycode)
	precision=k[2].length -1
	window.document.frmrefundAccept.hpr.value =precision	
	v1="0."
	for(inti=1;inti<=precision;inti++)
	{
		total=total + "0"
	}
	total=v1 + total		
	window.document.frmrefundAccept.txtRefundAmt.value=total   
	precision(window.document.frmrefundAccept.txtRefundAmt,window.document.frmrefundAccept.hpr.value) 	
	window.document.frmrefundAccept.txtCashid.value =""
	window.document.frmrefundAccept.txtCashdesc.value =""
	window.document.frmrefundAccept.txtCounterNo.value =""
	window.document.frmrefundAccept.txtRefundno.value =""
	window.document.frmrefundAccept.txtRefundAmt.value ="0.00"
	precision(window.document.frmrefundAccept.txtRefundAmt,window.document.frmrefundAccept.hpr.value) 
	window.document.all.refcash.src="acceptdenom1.aspx"   	 
}
*/
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

//---------------This Function is to select cashierid who has refunded the cash--------------
function Cashiercode()
{
  var tab="Cashrefundaccept" 	
  var brcode =window.document.frmrefundAccept.txtBranchcode.value 
  var crcode=window.document.frmrefundAccept.txtCurrencycode.value   
  st= tab + "*" + brcode + "*" + crcode 
  window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
//---------------This Function is to assign  Cashierid and Name--------------
function Cashiercodeid(kstr)
{	
	assign(kstr,window.document.frmrefundAccept.txtCashdesc,
	window.document.frmrefundAccept.txtCashid)
	splitString("window.document.frmrefundAccept","txtRefundno,txtRefundAmt")  
	Getcounterid()	
	window.document.frmrefundAccept.txtCounterNo.value =""
	window.document.frmrefundAccept.txtRefundno.value =""
	window.document.frmrefundAccept.txtRefundAmt.value ="0.00"	
	window.document.all.refcash.src="acceptdenom1.aspx"  
		
}
//---------------This Function is  to get counterno of refunded cashierid--------------
function counter()
{
  var gen="refCounter" 	
  var brcode=window.document.frmrefundAccept.txtBranchcode.value 
  var crcode=window.document.frmrefundAccept.txtCurrencycode.value    
  st= gen + "*" + brcode + "*" + crcode  
  window.showModalDialog("single.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
//---------------This Function is to assign Counter No of refunded Cashierid-------------
function  Cashcounterid(kstr)
{	
	window.document.frmrefundAccept.txtCounterNo.value =kstr
	splitString("window.document.frmrefundAccept","txtRefundno,txtRefundAmt")
	Getcounterid("counter")
}
//---------------This Function is to get Refundno of refunded cashierid--------------
function Cashrefund()
{	
  var gen="refundno" 	
  var brcode=window.document.frmrefundAccept.txtBranchcode.value 
  var crcode=window.document.frmrefundAccept.txtCurrencycode.value 
   var cashid=window.document.frmrefundAccept.txtCashid.value 
   cashid=cashid.toUpperCase()
  if(cashid=="") 
	{
		alert("CashierId or Counter No Should Not Be Null")
    }        
  else
	 {	st=""	
		st= gen+"*"+brcode+"*"+crcode+"*"+cashid
		
		window.showModalDialog("single.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	}
}
//---------------This Function is  to assign Refund No of refunded Cashierid-------------
function Cashrefundid(kstr)
{
	window.document.frmrefundAccept.txtRefundno.value =kstr	
	splitString("window.document.frmrefundAccept","txtRefundAmt")	
	Getcounterid("refund")	
	window.document.frmrefundAccept.txtRefundAmt.value ="0.00"	
	window.document.all.refcash.src="acceptdenom1.aspx"  	   
}

//---------------This Function is to get Counter No of refunded Cashierid-------------
function Getcounterid(kstr)
	{	
	
		var tab="cashrefundstrn"
		var cashid=window.document.frmrefundAccept.txtCashid.value
		var counter=window.document.frmrefundAccept.txtCounterNo.value    
		var refundno=window.document.frmrefundAccept.txtRefundno.value    
		var genrefund="refund"	
		var gencounter="counter"
		cashid=cashid.toUpperCase()
		
		if(kstr=="refund")
		{
			st=tab+"|"+cashid+"|"+genrefund+"|"+refundno	
								
		}
		else if(kstr=="counter")
		{								
				 st=tab+"|"+gencounter+"|"+counter				  
		}  
		else
		{
				 st=tab+"|"+cashid+"|"+"Cash"
				 	  
		}
			
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="CashRefCounter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
	}
	
//---------------This Function is to assign Refund Amount of refunded Cashierid-------------	
function  Allot(kstr) 
{

 var appdate,d
  	    v=kstr.split("|")  	      	    
	 if(v[0]=="R")	 {
	
		window.document.frmrefundAccept.txtRefundAmt.value =v[1]
		prvalue=window.document.frmrefundAccept.hpr.value   		
		pr=prvalue.length-1 		
		precision(window.document.frmrefundAccept.txtRefundAmt,pr)		  		
//---------------This Function is  to display the Denominatins of refunded Cashierid-------------
		Denom()
	}
//---------------This Function is  to assign the Counter No of refunded Cashierid-------------
	else if(v[0]=="M")
	{
		y=v[1].split("*")			  	    				
		window.document.frmrefundAccept.txtCounterNo.value =y[0]
	}
//---------------This Function is  to assign the Cashierid and Name of refunded Cashierid-------------	
	else if(v[0]=="C")
	{					  	    
		window.document.frmrefundAccept.txtCashid.value =v[1]
		window.document.frmrefundAccept.txtCashdesc.value =v[2]
	}
// for display the desscription of cashier id 
	else if (v[1]=="txtCashid")
	{
		var StrFld=new String()
		StrFld=v[0].split("*")
		if(StrFld[0]=="No")
		{
		
			alert("Invalid Cashier ID")
			splitString("window.document.frmrefundAccept","txtCashid,txtCashdesc,"+
			"txtCounterNo,txtRefundno,txtRefundAmt")
			return;
		}
		window.document.frmrefundAccept.txtCashdesc.value=StrFld[0]
		
		Getcounterid()	
		window.document.frmrefundAccept.txtCounterNo.value =""
		window.document.frmrefundAccept.txtRefundno.value =""
		window.document.frmrefundAccept.txtRefundAmt.value ="0.00"	
		window.document.all.refcash.src="acceptdenom1.aspx"  
	}
// for display the counter is valid or not 
	else if (v[1]=="txtCounterNo")
	{
		
		var StrFld=new String()
		StrFld=v[0].split("*")
		if(StrFld[0]=="No")
		{
			alert("Invalid Cashier ID")
			splitString("window.document.frmrefundAccept","txtCounterNo,txtRefundno,txtRefundAmt")
			return;
		}
		
		
		splitString("window.document.frmrefundAccept","txtRefundno,txtRefundAmt")
		Getcounterid("counter")	
		
	}	
	//window.document.frmrefundAccept.txtRefundno
	// for enytered refund No is valid or not 
	else if (v[1]=="txtRefundno")
	{
		
		var StrFld=new String()
		StrFld=v[0].split("*")
		if(StrFld[0]=="No")
		{
			alert("Invalid Cashier ID")
			splitString("window.document.frmrefundAccept","txtRefundno,txtRefundAmt")
			return;
		}
		
		
		Getcounterid("refund")	
	window.document.frmrefundAccept.txtRefundAmt.value ="0.00"	
	window.document.all.refcash.src="acceptdenom1.aspx"  	 
		
	}	
}
//---------------This Function is  to display the Denominations of refunded Cashierid-------------
function  Denom()
{
	var tab="cashrefundstrn"	
	var brcode=window.document.frmrefundAccept.txtBranchcode.value
	var crcode=window.document.frmrefundAccept.txtCurrencycode.value 
	var cashid=window.document.frmrefundAccept.txtCashid.value    
	var cntno=window.document.frmrefundAccept.txtCounterNo.value   
	var refno=window.document.frmrefundAccept.txtRefundno.value   
	var del="|"	
	var frm="frmrefundAccept"
		cashid=cashid.toUpperCase()		
	st=frm+del+tab+del+brcode+del+crcode+del+cashid+del+cntno+del+refno		
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="acceptdenom1.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()    	
}
//---------------This Function is to save the record-------------
function save()
{	
   window.document.frmrefundAccept.hStatus.value=""
   var brcode=window.document.frmrefundAccept.txtBranchcode.value 
   var crcode=window.document.frmrefundAccept.txtCurrencycode.value    
   var cashid=window.document.frmrefundAccept.txtCashid.value    
   var refno=window.document.frmrefundAccept.txtRefundno.value    
    
   if((cashid=="")||(refno==""))
	{
   		alert("CashierId or Counter No or Refund No or Refund Amount should Not Be Null")	
	}
   else if ((CashDenom == "Y") && ((eval(window.document.frmrefundAccept.txtRefundAmt.value)) != eval((window.document.frmrefundAccept.txttotal.value))))
   {
		alert("Denomination Value are not Available")
		return;
   }
   else    
	{
		window.document.frmrefundAccept.hStatus.value="REFUND"
		st=brcode + "|" + crcode + "|" +cashid + "|" + refno
		window.document.frmrefundAccept.hstr.value=st
		window.document.frmrefundAccept.action="cashrefundacceptinsert.aspx"       
		window.document.frmrefundAccept.method="post"
		window.document.frmrefundAccept.submit()
	}
   
}

//// For Reject Button
function Reject()
{
   window.document.frmrefundAccept.hStatus.value=""
   var brcode=window.document.frmrefundAccept.txtBranchcode.value 
   var crcode=window.document.frmrefundAccept.txtCurrencycode.value    
   var cashid=window.document.frmrefundAccept.txtCashid.value    
   var refno=window.document.frmrefundAccept.txtRefundno.value    
      
   if((cashid=="")||(refno==""))
   {
   		alert("CashierId or Counter No or Refund No or Refund Amount should Not Be Null")	
   }	
   else    
   {
		 window.document.frmrefundAccept.hStatus.value="REJECT"
		 st=brcode + "|" + crcode + "|" +cashid + "|" + refno
		 window.document.frmrefundAccept.hstr.value=st
		 window.document.frmrefundAccept.action="cashrefundacceptinsert.aspx"       
		 window.document.frmrefundAccept.method="post"
		 window.document.frmrefundAccept.submit()
	}
   
}
///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {

 sBr=window.document.frmrefundAccept.txtBranchcode.value
sBr=sBr.toUpperCase()
sCur=window.document.frmrefundAccept.txtCurrencycode.value
sRef=window.document.frmrefundAccept.txtRefundno.value
sCash=window.document.frmrefundAccept.txtCashid.value
sCash=sCash.toUpperCase();
sUser="<%=session("userid")%>"
sUser=sUser.toUpperCase()
sCur=sCur.toUpperCase()
if(window.document.frmrefundAccept.txtBranchcode.value=="")
{
	alert("Select BranchCode")
	return;
}
 	//for cashierid  description 
if(strTxt=="txtCashid")
{
if(window.document.frmrefundAccept.txtCashid.value=="")
{
return;
}
st="cashcountermst cash,genusermst gen"+"|"+"gen.name"+
	"|"+"cash.branchcode='" + sBr + "' and cash.currencycode='" + sCur + "' and " +
	"cash.cashierid='"+ sCash+"' and "+
	"cash.cashierid=gen.userid and cash.cashierid not in ('" + sUser +"')"+
	"|"+strTxt+"|"+"DescripDisplay"
}
//for counterno

if(strTxt=="txtCounterNo")
{
if(window.document.frmrefundAccept.txtCounterNo.value=="")
{
return;
}
st="CASHREFUNDSTRN"+"|"+"DISTINCT(COUNTERNO)"+
	"|"+"branchcode='" + sBr + "' and currencycode='" + sCur + "'"+
	"|"+strTxt+"|"+"DescripDisplay"
}
//for counterno

if(strTxt=="txtRefundno")
{

if(window.document.frmrefundAccept.txtRefundno.value=="")
{
return;
}

		st="CASHREFUNDSTRN"+"|"+"DISTINCT(refundno)"+
				"|"+"branchcode='"+ sBr+"' and " +
					"currencycode='"+ sCur+"' and " +
					"refundno='"+sRef+"' and " +
					"refundeduserid='"+ sCash+"' and status='P'"+
					"|"+strTxt+"|"+"DescripDisplay"
	

}

//post to ifrmae page to get desciptions

	
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="CashRefCounter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();	
 }
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashrefundaccp.aspx" 
	}
}	

function Denom1()
{
	if (CashDenom=='Y')
	{
		window.document.all.divdenom.style.display="block"
		window.document.all.total.style.visibility="visible" 
		window.document.frmrefundAccept.txttotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.divdenom.style.display="none"
		window.document.all.total.style.visibility="hidden" 
		window.document.frmrefundAccept.txttotal.style.visibility="hidden" 
	}
}

//-->

function TotalSumAmount(kstr)
{
	window.document.frmrefundAccept.txttotal.value = kstr
	window.document.frmrefundAccept.txttotal.value= gridprecision(window.document.frmrefundAccept.txttotal.value,
					window.document.frmrefundAccept.hpr.value)
}

</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg();Denom1()">

<form name="frmrefundAccept">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>Cash Refund Acceptance</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>
  <table border="0" width="100%" height="588" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" nowrap>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="100%" ><img border="0" name="placeholder" src="file://Comserver/c/CashFinal/dscript42/transparent.gif" width="1"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          <%
          'To diplay application dte
          %>
		  <%appdate=formatdatetime(session("Applicationdate"),1)%>

          

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">

         <!--- <table align="center" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td height="15"><font class="textblue">
              <p align="center"></font></td>
            </tr>
          </table> --->

          <div align="center">
            <center>

            <table border="0" width="98%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="15%">&nbsp; Branch Code</td>
                <td width="35%"><input name="txtBranchcode" size="9" 
                value="<%=session("Branchcode")%>" readonly class="txtautofill"><input 
                type="button" class="button" value=" L " name="cmdbranch" disabled
                onclick="branch()"><input name="txtBranchdesc" size="16" 
                class="bgcolor1" readonly value="<%=session("Branchnarration")%>"></td>
                
                <td width="20%" align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td width="35%" align="left"><input name="txtCurrencycode" 
                size="9" value="<%=session("currencycode")%>" readonly class="txtautofill"><input type="button" 
                class="button" value=" L " name="cmdcur" disabled onclick="currency()"><input 
                name="txtCurrencydesc" size="16" class="bgcolor1" 
                value="<%=session("currencynarration")%>" readonly></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0">
          <tr>
            <td>
            <div align="center">
              <center>

              <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="49%" valign="top">
                  <div align="center">
                    <center>

                    <table width="98%" cellpadding="0">
                      <tr>
                        <td>

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="100%" height="30" colspan="2">
                            <div align="center">
                              <center>

                              <table width="50%" cellspacing="0" cellpadding="0" class="tablebordermain">
                                <tr class="bgcolor">
                                  <td width="100%">
                                  <p align="center"><font class="subheading">Acceptance
                                  Details</font></td>
                                </tr>
                              </table>

                              </center>
                            </div>
                            </td>
                          </tr>
                          <tr>
                            <td width="14%" height="20"></td>
                            <td width="32%" height="20"></td>
                          </tr>
                          <tr>
                            <td width="14%" height="30">&nbsp; &nbsp;Cashier ID</td>
                            <td width="32%" height="30"><input name="txtCashid" 
                            size="9" class="txtautofill" style="TEXT-ALIGN: right" style="TEXT-TRANSFORM: uppercase"                  maxlength=20 onblur='Dataarrange(window.document.frmrefundAccept.txtCashid);
                            DescrptionDisp("txtCashid")'><input type="button" class="button" value=" L " 
                            name="cmdcashier" onclick="Cashiercode()"><input 
                            name="txtCashdesc" size="16" style="TEXT-ALIGN: right" 
                            readonly class="bgcolor1"></td>
                          </tr>
                          <tr>
                            <td width="14%" height="30">&nbsp;&nbsp; Counter No</td>
                            <td width="32%" height="30"><input name="txtCounterNo" 
                            class="txtautofill" style="TEXT-ALIGN: right" maxlength=6 onkeypress='numeric()'
                            onblur='Dataarrange(window.document.frmrefundAccept.txtCounterNo);
                                  DescrptionDisp("txtCounterNo")' size="9" onkeypress="numeric()"><input 
                            type="button" class="button" value=" L " name="butCounter" 
                            onclick="counter()"></td>
                          </tr>
                          <tr>
                            <td width="14%" height="30">&nbsp; &nbsp;Refund No</td>
                            <td width="32%" height="30"><input class="txtautofill" 
                            style="TEXT-ALIGN: right" name="txtRefundno" maxlength=2 
                            onkeypress='numeric()'
                            onblur='Dataarrange(window.document.frmrefundAccept.txtRefundno);
                                  DescrptionDisp("txtRefundno")' size="9" 
                                  onkeypress="numeric()"><input type="button" class="button" 
                                  value=" L " name="butRefund" 
                                  onclick="Cashrefund()"></td>
                          </tr>
                          <tr>
                            <td width="14%" height="30">&nbsp;&nbsp; Refund Amt</td>
                            <td width="32%" height="30"><input name="txtRefundAmt" class="txtautofill" style="TEXT-ALIGN: right" readonly size="12" value="0.00" onchange="amountdigits(window.document.frmrefundAccept.txtRefundAmt)"></td>
                          </tr>
                          <tr>
                            <td width="100%" height="80" colspan="2"></td>
                          </tr>
                        </table>

                    </table>

                    </center>
                  </div>
                  </td>
                  <td width="51%" valign="top">
                  <div align="center" id="divdenom">
                    <center>

                    <table width="98%" cellpadding="0" class="tableborder2">
                      <tr>
                        <td>

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="100%" align="middle" valign="top">
                            <td align="middle" valign="top"><iframe id=refcash 
                            align=center  frameborder=0 framespacing=0   
                            noresize height=380 width=380 valign="top" 
                            src ="acceptdenom1.aspx" 
                  style="BACKGROUND-COLOR: darkred"></iframe></td>
                          </tr>
                        </table>

                    </table>

                    </center>
                  </div>
                  </td>
                </tr>
              </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
         
              <tr>
                <td width="14%"></td>
                <td width="37%">

                

                </td>
                <td width="9%" align="right"></td>
                <td width="19%" align="right"><font ><span id="total" style="VISIBILITY: hidden">Total:&nbsp;&nbsp;</font></td>
                <td width="3%">&nbsp;</td>
                <td width="13%"><input name="txttotal" size="9" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00" readonly onload="amountdigits(window.document.frmrefundAccept.txtTotal)"></td>
              </tr>
              <tr>
                <td width="50%" colspan="2"></td>
                <td width="36%" align="right" colspan="3">&nbsp;</td>
                <td width="14%"></td>
              </tr>
              <tr>
                <td width="100%" colspan="6" align="middle"></td>
              </tr>
              
              <table width="25%" cellspacing="0" cellpadding="0" class="tablebordermain" align="center">
                  <tr>
                    <td width="100%" align="middle"><input type="button" value="Accept" name="butOk" onclick="save()" class="button"><input type="button" value="Reject" name="butRej" onclick="Reject()" class="button"><input 
                    type="button" value="Cancel" name="butCancel" onclick="location.href=&quot;cashrefundaccp.aspx&quot;" class="button"><input type="button" value="   Exit   " name="cmdexit" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" class="button"></td>
                  </tr>
                </table>
              
              
            </table>

        </table>

        </center>
      </div>
  </table>

  <input type="hidden" name="hstr"><input type="hidden" name="hStatus"><input type="hidden" name="hpr" value="0.0"><input type="hidden" id="hrdate" name="hrdate">
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</form>


<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="CashRefCounter.aspx">
                                              </iframe>
                  </td>
                </tr>
              </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

</html>
