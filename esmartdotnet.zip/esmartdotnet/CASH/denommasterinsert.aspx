<%@ Page Language="vb" CodeBehind="denommasterinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.denommasterinsert" %>
<%
dim Arrtrans(0,4)
dim OBJ,Strmsg,status,curcode,denomtype,denomval,denomcode,appdate
Set Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")
			strvalue=Request.Form("hstr")   
			status=right(strvalue,1)					
			curcode=Request.Form("txtcurrencycode") 
			denomtype=Request.Form("optdenomtype")
			denomval=Request.Form("txtdenomval")
			denomcode=Request.Form("txtdenomno")
			appdate=Request.Form("hdate")
			'Response.Write appdate
''***************** Inserting the values into database ********************
		'str="CURRENCYCODE,DENOMINATIONTYPE,DENOMINATIONCODE,DENOMINATIONVALUE," & _
		'	"USERID,MACHINEID,APPLICATIONDATE,SYSTEMDATE" 
		
			

'*************************** end  ****************************

			if status="I" then
			
			str="CURRENCYCODE,DENOMINATIONTYPE,DENOMINATIONCODE,DENOMINATIONVALUE," & _
			"USERID,MACHINEID,APPLICATIONDATE,SYSTEMDATE" 
			
			i=instrrev(strvalue,"|")
			strvalues=mid(strvalue,1,i-1)
			'Response.Write strvalues
			    Arrtrans(0,0)="I"
			'passing the table name
				Arrtrans(0,1)="CASHDENOMINATIONMST"
			'passing columns
			    Arrtrans(0,2)=str
			'passing values
				Arrtrans(0,3)=strvalues
			'passing where condition
				Arrtrans(0,4)=""			
				
			elseif status="M" then
						
			   Arrtrans(0,0)="U"
			'passing the table name
				Arrtrans(0,1)="CASHDENOMINATIONMST"
			'passing columns
			str="DENOMINATIONTYPE,DENOMINATIONVALUE" 
			Arrtrans(0,2)=str
			'passing values
			strvalues=""
			strvalues=" '" & denomtype & "' ~ '" & denomval & "'"   
			'~ '"& appdate &"'~'"& appdate &"'"											
			Arrtrans(0,3)=strvalues
			'passing where condition
				Arrtrans(0,4)="CURRENCYCODE='"& curcode &"' and DENOMINATIONCODE='" & denomcode & "'"								  
				
			elseif status="D" then
			'passing the mode of operation
			   Arrtrans(0,0)="D"
			'passing the table name
				Arrtrans(0,1)="CASHDENOMINATIONMST"			
			'passing where condition			
					Arrtrans(0,4)="CURRENCYCODE='"& curcode &"' and DENOMINATIONCODE='" & denomcode & "'"								  					
			end if	
		Strmsg= OBJ.DataTransactions(Arrtrans)
			set OBJ=nothing
			
			Response.Redirect "denominationmaster.asp?record=" & strmsg	

			




  %>
  
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
