<%@ Page Language="vb" CodeBehind="DayBegin.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.DayBegin" %>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<title>New Page 1</title>
<SCRIPT LANGUAGE=javascript>
<!--
function CashClick()
{
	window.document.frmDayBegin.status.value=""
	window.document.frmDayBegin.status.value="CASH"
	window.document.frmDayBegin.action="DayBeginChk.asp"
	window.document.frmDayBegin.method ="post"
	window.document.frmDayBegin.submit();
}

function Cancel()
{
	window.document.frmDayBegin.action="DayBeginTrans.asp"
	window.document.frmDayBegin.method ="post"
	window.document.frmDayBegin.submit();
}
//-->
</SCRIPT>
</head>
<%
	if session("Str")<>"CASHTRUE" then
	strFlds=Request.QueryString("str")
	sCnt=split(strFlds,"|")
	end if
%>
<body topmargin="0" leftmargin="0" background="cutimages/daybegin.jpg">

<form name="frmDayBegin">

  <table width="100%" border="0" cellspacing="1" cellpadding="1">
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
  </table>

  <div align="center">
    <center>

    <table width="98%" align="right" cellspacing="1" cellpadding="1">
      <%
    
    
    for i=0 to ubound(sCnt)-1
    'sMod=split(sCnt(1),"|")
    smod=scnt(i)
    flen=len(smod)
	   p=(10-cint(flen))/2
	   w=p*3
	  Response.Write Request.QueryString("strmsg")
	  %>
      <tr>
	    <% if flen>0 then %>
        <td><input type="button" name="buttform" value="<%=space(w)%><%=sMod%><%=space(w)%>" size="10" onclick="CashClick()"></td>
        <% end if%>
      </tr>
      
	 
	  
      <%
      
	next  
	   %>
      <tr>
        <td><input name="cmdCancel" type="button" value=" Exit " onclick="Cancel()"></td>
      </tr>
    </table>

    </center>
  </div>
  <input type="hidden" name="status">

  <table>
  </table>

</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</body>

</html>
