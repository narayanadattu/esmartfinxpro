<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashmastersinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashmastersinsert" %>
<%
'''''this form is used to do the transaction for cashmasters(cashiertype,countermst)

dim obj,strmsg,status,currcode,cashiernarr,branchid,cashiertype


    status=Request.Form("Status")
    currcode=trim(ucase(Request.Form("txtcurrencycode")))
    cashiernarr=trim(Request.Form("txtnarration"))
    branchid=trim(ucase(Request.Form("txtbranchcode")))
    cashiertype=trim(ucase(Request.Form("txtcashiertype")))
    receipt=Request.Form("cmbreceipts")
    payment=Request.Form("cmbpayments")
    tellerreceipt=Request.Form("cmbtellerreceipts")
    tellerpayment=Request.Form("cmbtellerpayments")
    UsrId=session("userId")
    MachineId=session("machineId")
    
'''' Transactioons for CashierTypeMaster form-----------------------------------------------------  
if Ucase(trim(Request.QueryString("strng")))="CASHIERTYPEMST" then
'---------------- Values -------------
redim arrtrans(0,4)
 obj = server.createobject("GeneralTransactions.DBTransactions")

strinsertvalues = "'" & currcode & "', '" & cashiernarr & "','" & cashiertype & "'," & _
"'" & branchid & "','" & receipt & "','" & payment & "','" & tellerreceipt & "','" & tellerpayment & "','R'"


strupdatevalues ="'" & currcode & "'~ '" & cashiernarr & "'~" & _
"'" & cashiertype & "'~'" & branchid & "'~'" & receipt & "'~'" & payment & "'~" & _
"'" & tellerreceipt & "'~'" & tellerpayment & "'~'R'"


'-------Inserting values into the database
kstr = "currencycode,narration,cashiertypeid,branchcode," & _
	  "receiptsyn,paymentsyn,tellerreceiptsyn,tellerpaymentsyn,status"

'------------------

if status="INSERT" then
	   arrtrans(0,0)="I"
	   arrtrans(0,1)="CASHCASHIERTYPEMST"
	   arrtrans(0,2)=kstr
	   arrtrans(0,3)=strinsertvalues
	   arrtrans(0,4)=""
elseif status="MODIFY" then
	   arrtrans(0,0)="U"
	   arrtrans(0,1)="CASHCASHIERTYPEMST"
	   arrtrans(0,2)=kstr
	   arrtrans(0,3)=strupdatevalues
	   arrtrans(0,4)="upper(cashiertypeid)='" & trim(ucase(cashiertype)) & "'" 	
elseif status="DELETE" then
	   arrtrans(0,0)="U"
	   arrtrans(0,1)="CASHCASHIERTYPEMST"
	   arrtrans(0,2)="STATUS"
	   arrtrans(0,3)="'D'"
	   arrtrans(0,4)="upper(cashiertypeid)='" & trim(ucase(cashiertype)) & "'" 		   
end if
		
strmsg= obj.datatransactions(arrtrans)
 obj=nothing
Response.Redirect ("cashmasters.aspx?record=" & strmsg)

'''Transactions for Countermst form -------------------------------------------------------
elseif Ucase(trim(Request.QueryString("strng")))="CASHCOUNTERMST" then
'''assigning values to variables(tablename,fieldnames,values,conditions ) to do 
''transactions 
redim arrtrans(1,4)
CounterNo=Request.Form("txtCode")
narration=Request.Form("txtDesc")
CurencyCodes=split(Request.Form("hCur"),"|")
Response.Write (ubound(CurencyCodes) & "<br>")
StrTabName="CASHCOUNTERMST"
StrFldNames="BRANCHCODE,CURRENCYCODE,USERID,MACHINEID," & _
			"APPLICATIONDATE,SYSTEMDATE,NARRATION,counterno"
for icnt=0 to ubound(CurencyCodes)-1
	StrFldValues=StrFldValues & "'" & branchid	& "','" & CurencyCodes(icnt) & "'," & _
			"'" & UsrId & "','" & MachineId & "'," & _
			"to_Date('" & session("Applicationdate") & "','dd-mm-yyyy')," & _
			"sysdate,'" & narration & "'" & "|"
	StrUpFldValues=StrUpFldValues & "'" & branchid & "','" & CurencyCodes(icnt) & "'," & _
			"'" & UsrId & "','" & MachineId & "'," & _
			"to_Date('"& session("Applicationdate") & "','dd-mm-yyyy')," & _
			"sysdate,'" & narration & "'," & counterno & "" & "|"	
next
StrFldValues=left(StrFldValues,LEN(StrFldValues)-1)	
StrUpFldValues=left(StrUpFldValues,LEN(StrUpFldValues)-1)	
Response.Write (StrFldNames & "<br>")		
Response.Write (StrUpFldValues)
'StrUpFldValues="'" & branchid &"'~'" & currcode &"'~" & _
			'"'" & UsrId &"'~'" & MachineId &"'~" & _
			'"to_Date('"& session("Applicationdate") &"','dd-mm-yyyy')~" & _
			'"sysdate~'" & narration &"'~" & counterno &""
StrCondition="upper(trim(branchcode))='" & 	branchid & "' and " & _
			"trim(counterno)=" & counterno & ""						
'''settion for Autonumber Generation values
AutoFlds="BranchCode,maxautotablename,maxautofieldName"
AutoValues="'" & branchid & "','CASHCOUNTERMST','COUNTERNO'" 
AutoCondition="branchcode='" & branchid & "' and " & _
			  "maxautotablename='CASHCOUNTERMST' and " & _
			 "maxautofieldName='COUNTERNO'" 		
''''''****************Setting the TransactionComponent****************
  ObjTran = SERVER.CreateObject("GeneralTransactions.DBTransactions")
''''*********************Assigning the tablenames and flds and values to Arrayvariable
'''''						 for update ****
		
if ucase(trim(Status))="ADD" then
		reDim  ArrTran(1,4)	
		'''for autonumber
		ArrTran(0,0)="A"					'passing the TransactionType
		ArrTran(0,1)="GETAUTONUMBER|MAXAUTOTABLENAME='CASHCOUNTERMST' and " & _
					"MAXAUTOFIELDNAME='COUNTERNO'"		'passing the tablename
		ArrTran(0,2)=AutoFlds				'passing the FieldNames
		ArrTran(0,3)=AutoValues				'passing the Fieldvalues
		ArrTran(0,4)=AutoCondition			'passing the condition
		ArrTran(1,0)="I"			'passing the TransactionType
		ArrTran(1,1)=StrTabName	'passing the tablename
		ArrTran(1,2)=StrFldNames	'passing the FieldNames
		ArrTran(1,3)=StrFldValues	'passing the Fieldvalues
		ArrTran(1,4)=""'passing the condition
elseif ucase(trim(Status))="MODIFY" then		
	redim arrtran(1,4)
		ArrTran(0,0)="D"			'passing the TransactionType
		ArrTran(0,1)=StrTabName		'passing the tablename
		ArrTran(0,2)=""				'passing the FieldNames
		ArrTran(0,3)=""				'passing the Fieldvalues
		ArrTran(0,4)=StrCondition	'passing the condition
		ArrTran(1,0)="I"			'passing the TransactionType
		ArrTran(1,1)=StrTabName		'passing the tablename
		ArrTran(1,2)=StrFldNames	'passing the FieldNames
		ArrTran(1,3)=StrUpFldValues	'passing the Fieldvalues
		ArrTran(1,4)=""				'passing the condition
elseif ucase(trim(Status))="DELETE" then		
	redim arrtran(0,4)
		ArrTran(0,0)="D"			'passing the TransactionType
		ArrTran(0,1)=StrTabName		'passing the tablename
		ArrTran(0,2)=""				'passing the FieldNames
		ArrTran(0,3)=""				'passing the Fieldvalues
		ArrTran(0,4)=StrCondition	'passing the condition	
end if	
	
''calling transaction component method to update status as'A' in clg voucherdtls table
		Strmsg= ObjTran.DataTransactions(ArrTran)
		
		  Objtran=nothing
		' redirects to client page
		
		if ucase(trim(Status))="ADD" then
			strfld=split(Strmsg,"|",-1)
				if strfld(0)="Transaction Sucessful." then
				kStr="Counter No " & strfld(1) & "is Generated"
				else
				kStr=strfld(0)
				end if
		else
		kstr=strmsg
		end if
		Response.Redirect ("cashmasters.aspx?record=" & kStr)
end if

'''---------------------------------------------------------------------------------------

%>