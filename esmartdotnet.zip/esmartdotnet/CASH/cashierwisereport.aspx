<%@ Page aspcompat="true" explicit="false" CodeBehind="cashierwisereport.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashierwisereport" %>
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:Cashwisereport.aspx
''''' ListForm:List
''''' iFramepage:cashCountermgtQury.aspx
'''''reporttransactionpage: reportdisplay.aspx
''''------------------------------------------------------------------------------------------
%>


<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Reports</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<!--
var mode=""
var RepStatus=""
//this function is used to set mode status depending upon the the option buttons clicked
function modeStatus()
{
	RepStatus="CASHIERPOS"
	if(window.document.frmCashierReport.optTran(0).checked==true)
	{
		mode="All"
		
	}
	else if(window.document.frmCashierReport.optTran(1).checked==true)
	{
		mode="RecPay"
	}	
	
}
///for sending parameters to list form for branchCode

function branch()
{  
	st="Bruser"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	splitString("window.document.frmCashierReport","txtCurrencyCode,txtCurrencyDesc,txtcid,"+
				"txtcdesc,txtRepdate")
		
}	
function Bruser(kstr)
{	
	assign(kstr,window.document.frmCashierReport.txtBranchDesc,
	window.document.frmCashierReport.txtBranchCode)
}	
///for sending parameters to list form for CurrencyCode
function currency()
{	
if(window.document.frmCashierReport.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
	st="Curr"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
			
	splitString("window.document.frmCashierReport","txtcid,"+
				"txtcdesc,txtRepdate")
}
//displaying cashiercode,name which are returned by list page
function  Currid(kstr)
{var p,prn,j,k
  var k=kstr.split("-----")
  window.document.frmCashierReport.txtCurrencyDesc.value =k[0]
  window.document.frmCashierReport.txtCurrencyCode.value =k[1]
  CurrencyClick()
  var prn=eval(k[2].length)-1
  window.document.frmCashierReport.hpr.value=prn
  p=""
  for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	
	
 }	

///for sending parameters to list form for cashiercode 
function Cashiercode()
{	
		
		if(window.document.frmCashierReport.txtCurrencyCode.value=="")
		{
			alert("Select CurrencyCode")
			return;
		}
		
		kstr="ReportCashier"
		brcode=window.document.frmCashierReport.txtBranchCode.value
		crcode=window.document.frmCashierReport.txtCurrencyCode.value
		brcode=brcode.toUpperCase()
		crcode=crcode.toUpperCase()
		
		if (window.document.frmCashierReport.all.divcashierpos.style.display=="block" )
		{
			splitString("window.document.frmCashierReport","txtcdesc")
			RepDate=window.document.frmCashierReport.txtRepdate.value
		}
		if(window.document.frmCashierReport.all.divDenominationreport.style.display=="block")
		{
			splitString("window.document.frmCashierReport","txtcashdesc")
			RepDate=window.document.frmCashierReport.txtDenomdate.value
		}
		st=kstr+"*"+brcode+"*"+crcode+"*"+RepDate
		
		
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:420px;DialogTop:210px")
		
}
///function for dispalying the cashierid,name returned from list page 
function ReportCashierid(kstr)
{		
	if (window.document.frmCashierReport.all.divcashierpos.style.display=="block" )
	{
		assign(kstr,window.document.frmCashierReport.txtcdesc,window.document.frmCashierReport.txtcid)
	}
	if (window.document.frmCashierReport.all.divDenominationreport.style.display=="block" )
	{
		assign(kstr,window.document.frmCashierReport.txtcashdesc,window.document.frmCashierReport.txtcashid)
	}
	
}

//finction for displaying the description fro selcted code	
function CashierDisp(strTxt)
{
//for brancgdescription
if(strTxt=="txtBranchCode")
{ 
sBr=window.document.frmCashierReport.txtBranchCode.value
sBr=sBr.toUpperCase()
st="GENBANKBRANCHMST~BRANCHNAME~branchcode='"+sBr+"'~"+strTxt+"~DescDisplay"
}
if(strTxt=="txtCurrencyCode")
{
if(window.document.frmCashierReport.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
sCur=window.document.frmCashierReport.txtCurrencyCode.value
sCur=sCur.toUpperCase()
st="GENCURRENCYTYPEMST~narration,PRECISION~upper(trim(currencycode))='"+sCur+"'"+
	"~"+strTxt+"~DescDisplay"
}
//for cashier description 
if(strTxt=="txtcid")
{
// value is not there in text box return the function
if(window.document.frmCashierReport.txtcid.value=="")
{
	return
}
if(window.document.frmCashierReport.txtCurrencyCode.value=="")
{
	alert("Select CurrencyCode")
	return;
}

		sBr=window.document.frmCashierReport.txtBranchCode.value
		sCur=window.document.frmCashierReport.txtCurrencyCode.value
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCashId=window.document.frmCashierReport.txtcid.value
		
		sRepDate=window.document.frmCashierReport.txtRepdate.value
		sCashId=sCashId.toUpperCase()
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sdt="<%=session("applicationdate")%>"
		if(sdt==sRepDate)
		{
			st="CASHALLOTMENTSTRN cash,GENUSERMST u"+"~"+"u.Name"+
				"~"+"cash.BRANCHCODE='" + sBr + "' and "+
				"cash.currencycode='"+sCur+"' and u.userid=cash.cashierid and " +
				"cash.cashierid='"+sCashId+"' and cash.applicationdate='" +sRepDate+"'"+
				"~"+strTxt+"~"+"DescDisplay"
		}
		else
		{
			st="CASHALLOTMENTSTRNhist cash,GENUSERMST u"+"~"+"u.Name"+
			"~"+"cash.BRANCHCODE='" + sBr + "' and "+
			"cash.currencycode='"+sCur+"' and u.userid=cash.cashierid and " +
			"cash.cashierid='"+sCashId+"' and cash.applicationdate='" +sRepDate+"'"+
			"~"+strTxt+"~"+"DescDisplay"
		}
}

//for Date Checking
if(strTxt=="DateCheck")
{

	if(window.document.frmCashierReport.all.divcashierpos.style.display=="block")
	{
	sDate=window.document.frmCashierReport.txtRepdate.value
	}
	else
	{
		sDate=window.document.frmCashierReport.txtRepvaultdate.value
	}
	st=""+"~"+""+"~"+sDate+"~"+strTxt+"~"+"DateDisplay"
	
}

		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
}

////function for displaying the values which are returned iframe page
function Countermgtdts(kstr)
{
var strtype=new String()
var det=new String()
strtype=kstr.split("~")
det=strtype[0].split("*")
//for description displaying  split the values
var StrArrFld=new String()
StrArrFld=strtype[0].split("|")
///for displaying branchdesc
if(strtype[1]=="txtBranchCode")
	{
	
		window.document.frmCashierReport.txtCurrencyCode.value=""
		window.document.frmCashierReport.txtCurrencyDesc.value=""
		if(StrArrFld[0]=="No")
		{
			alert("Invalid Cashier ID")
			window.document.frmCashierReport.txtBranchCode.value=""
			window.document.frmCashierReport.txtBranchDesc.value=""
			return;
		}
		window.document.frmCashierReport.txtBranchDesc.value=StrArrFld[0]
		
		
	}
	///for displaying Currencydesc
if(strtype[1]=="txtCurrencyCode")
	{)
		
		if(StrArrFld[0]=="No")
		{
			alert("Invalid Cashier ID")
			window.document.frmCashierReport.txtCurrencyCode.value=""
			window.document.frmCashierReport.txtCurrencyDesc.value=""
			return;
		}
		window.document.frmCashierReport.txtCurrencyDesc.value=StrArrFld[0]
		CurrencyClick()
		
	}
///for displaying Cashierdesc
	if(strtype[1]=="txtcid")
	{
	
		
		if(StrArrFld[0]=="No")
		{
		alert("Invalid Cashier ID")
		window.document.frmCashierReport.txtcid.value=""
		window.document.frmCashierReport.txtcdesc.value=""
		return;
		}
		window.document.frmCashierReport.txtcdesc.value=StrArrFld[0]
		
		
	}
	//for datedisplaying 
	if(strtype[1]=="DateCheck")
	{
		if(StrArrFld[0]=="NotValid")
		{
			alert("Report Date should be less than CurrentDate")
			window.document.frmCashierReport.txtRepdate.value=""
			return;
		}	
	}	
	
	}

function TempDataGenerate(strrep)
{
var stt=""

	window.document.frmCashierReport.hidRep.value = strrep

	if(window.document.frmCashierReport.txtBranchCode.value=="")
	{
		
		alert("Enter All Fields")
		return;
	}	
if(window.document.frmCashierReport.optVaultTran[0].checked==true)
	//(window.document.frmCashierReport.optTran[0].checked==true)||
	//(window.document.frmCashierReport.optTran[1].checked)==true)
	{
		if((RepStatus=="CASHIERPOS")||
		(window.document.frmCashierReport.all.divcashierpos.style.display=="block"))
		{
			/*if((window.document.frmCashierReport.txtRepdate.value=="")||
			(window.document.frmCashierReport.txtcid.value=="")||
			(window.document.frmCashierReport.txtCurrencyCode.value==""))
			{
				alert("Enter All Fields")
				return;
			}*/
			
			if(mode=="All")
			{
				if(window.document.frmCashierReport.txtBranchCode.value=="")
				{
				alert("Please Select Branch Code.")
				return;
				}
				else if(window.document.frmCashierReport.txtRepdate.value=="")
				{
				alert("Please Select Report Date.")
				return;
				}
				else if(window.document.frmCashierReport.txtCurrencyCode.value=="")
				{
				alert("Please Select Currency Code.")
				return;
				}
				else
				{
				stt="ALLTEMPDATAGENERATE"
				}
			}
			else if(mode=="RecPay")
			{
				if(window.document.frmCashierReport.txtBranchCode.value=="")
				{
				alert("Please Select Branch Code.")
				return;
				}
				else if(window.document.frmCashierReport.txtcid.value=="")
				{
				alert("Please Select Cashier Id.")
				return;
				}
				else if(window.document.frmCashierReport.txtRepdate.value=="")
				{
				alert("Please Select Report Date.")
				return;
				}
				else
				{
				stt="RECPAYTEMPDATAGENERATE"
				}
			}
		}			
///for Vaultposition report		
		else if(RepStatus=="VAULTPOS")
		{		
			if(window.document.frmCashierReport.txtRepvaultdate.value=="")
			{
				alert("Enter All Fields")
				return;
			}
				//checking for all currency or single currency
			if(window.document.frmCashierReport.optVaultTran[0].checked==true)
			{
				stt="ALLVAULTPOS"
			}
			else
			{
				stt="SINGLEVAULTPOS"
			}
		}
///for VaultCASH report		
		else if(RepStatus=="VAULTCASH")
			{
			if(window.document.frmCashierReport.txtRepvaultdate.value=="")
		
			{
				alert("Enter All Fields")
				return;
			}
			//checking for all currency or single currency
			if(window.document.frmCashierReport.optVaultTran[0].checked==true)
			{
				stt="ALLVAULTCASH"
			}
			else
			{
				stt="SINGLEVAULTCASH"
			}
		}
///for Consolidated reciepts&payments cashiers report
		else if(RepStatus=="CONSCASHIER")
		{
			if(window.document.frmCashierReport.txtRepvaultdate.value=="")
			{
				alert("Enter All Fields")
				return;
			}
		stt="CONSCASHIER"
		}	
		/// for Cash Allotment Details
		else if((RepStatus=="CASHALLOT") || (RepStatus=="CASHREFND") ||(RepStatus=="CASHEXCHANGE") || (RepStatus=="CASHCUNTEXCH"))
		{
			DinomReport()
			return;
		}	
		
		if(RepStatus=="CONSCASHIER")
		{
			var st1 = "CONSCASHIER" +"~"+ window.document.frmCashierReport.txtBranchCode.value +"~"+ window.document.frmCashierReport.txtCurrencyCode.value 
			+"~"+ window.document.frmCashierReport.txtRepvaultdate.value +"~"+ strrep
	
	
			window.document.frmCashierReport.action="cashierrecieptsrep.aspx?st="+st1
			window.document.frmCashierReport.method="post"
			window.document.frmCashierReport.submit();
		}
		else
		{
		
			window.document.frmCashierReport.hreport.value = strrep
			//alert(" Reddy = "+strrep+" stt = "+stt)
			window.document.frmCashierReport.action="ReportDisplay.aspx?strng="+stt
			window.document.frmCashierReport.method="post"
			window.document.frmCashierReport.submit();
		}
}
//receipts
else if (window.document.frmCashierReport.optVaultTran[1].checked==true)
{
	var st1 = "Receipts" +"~"+ window.document.frmCashierReport.txtBranchCode.value +"~"+ window.document.frmCashierReport.txtCurrencyCode.value +"~"+ window.document.frmCashierReport.txtRepvaultdate.value +"~"+ strrep
	
	
	window.document.frmCashierReport.action="cashierrecieptsrep.aspx?st="+st1
	window.document.frmCashierReport.method="post"
	window.document.frmCashierReport.submit();	
	
	}
//payments
else if (window.document.frmCashierReport.optVaultTran[2].checked==true)
{
var st1 = "Payments" +"~"+ window.document.frmCashierReport.txtBranchCode.value +"~"+ window.document.frmCashierReport.txtCurrencyCode.value +"~"+ window.document.frmCashierReport.txtRepvaultdate.value  +"~"+ strrep

	window.document.frmCashierReport.action="cashierrecieptsrep.aspx?st="+st1
	window.document.frmCashierReport.method="post"
	window.document.frmCashierReport.submit();
}
// closing balance details
	if((RepStatus=="CLSBALDTLS")||	(window.document.frmCashierReport.all.divclsBalDtls.style.display=="block"))
		{
	var brcd 
	var st1
	if(window.document.frmCashierReport.repsch1(0).checked==true)	
	{
		brcd = " BRANCHCODE = '"+ window.document.frmCashierReport.txtBranchCode.value +"' AND "
	}
	if(window.document.frmCashierReport.repsch1(1).checked==true)
	{
		brcd = ""
	}
	
		st1 = brcd		
		window.document.frmCashierReport.action="clsbaldtlsrep.aspx?st="+st1
		window.document.frmCashierReport.method="post"
		window.document.frmCashierReport.submit();
		}
}

function DinomReport()
{
	if((RepStatus=="CASHALLOT")||(RepStatus=="CASHREFND")||(RepStatus=="CASHEXCHANGE"))
	{
		if(window.document.frmCashierReport.txtDenomdate.value=="")
		{
			alert("Please Select The Date")
			return;
		}
		if(window.document.frmCashierReport.txtcashid.value =="")
		{
			alert("Please Select The Casher Id")
			return;
		}
	}
	if(RepStatus=="CASHALLOT")
	{
		stt="CASHALLOTDETAIL"
	}
	if(RepStatus=="CASHREFND")
	{
		stt="CASHRFUNDDETAIL"
	}
	if(RepStatus=="CASHEXCHANGE")
	{
		stt="CASHEXCHANGE"
	}
	if(RepStatus=="CASHCUNTEXCH")
	{
		if(window.document.frmCashierReport.txtRepvaultdate.value=="")
		{
			alert("Enter All Fields")
			return;
		}
			
		stt="CASHCOUNTEXCHANGE"
	}
	
	//alert(" stt = "+stt)
	window.document.frmCashierReport.action="DenomReport.aspx?strng="+stt
	window.document.frmCashierReport.method="post"
	window.document.frmCashierReport.submit();
	
}

//clearing the fields in the form
function ClearFlds()
{
	splitString("window.document.frmCashierReport","txtcid,txtcdesc")
	splitString("window.document.frmCashierReport","txtcashid,txtcashdesc")
				
}
//displaying of the cashierposdiv tag	
function CashierPosDivDisp()
{
	window.document.frmCashierReport.optVaultTran[0].checked=true
	window.document.frmCashierReport.all.divcashierpos.style.display="Block"
	window.document.frmCashierReport.all.divvault.style.display="none"
	window.document.frmCashierReport.all.divDenominationreport.style.display="none"
	window.document.frmCashierReport.txtnm.value="Cashier Position"
	window.document.frmCashierReport.all.divclsBalDtls.style.display="none"
}

function DenomRepDisp()
{
	window.document.frmCashierReport.optVaultTran[0].checked=true
	window.document.frmCashierReport.all.divcashierpos.style.display="none"
	window.document.frmCashierReport.all.divvault.style.display="none"	
	window.document.frmCashierReport.all.divclsBalDtls.style.display="none"
	window.document.frmCashierReport.all.divDenominationreport.style.display="block"
	if (RepStatus=="CASHALLOT")
	{
		window.document.frmCashierReport.txtDenomRep.value="Cash Allotment Details"
	}
	if (RepStatus=="CASHREFND")
	{
		window.document.frmCashierReport.txtDenomRep.value="Cash Refund Details"
	}
	if (RepStatus=="CASHEXCHANGE")
	{
		window.document.frmCashierReport.txtDenomRep.value="Cash Exchange Details"
	}
}

function ClsBalDtlsDisp()
{
	window.document.frmCashierReport.all.divcashierpos.style.display="none"
	window.document.frmCashierReport.all.divvault.style.display="none"	
	window.document.frmCashierReport.all.divDenominationreport.style.display="none"
	window.document.frmCashierReport.all.divclsBalDtls.style.display="block"
}
//displaying of the Valult div tag	
function VaultDivDisp()
{

if(RepStatus=="VAULTCASH")
{
	window.document.frmCashierReport.txtnm1.value="Vault Cash"
	window.document.frmCashierReport.optVaultTran[0].checked=true;
	window.document.frmCashierReport.optVaultTran[1].style.visibility="hidden"
	window.document.frmCashierReport.optVaultTran[2].style.visibility="hidden"
	window.document.frmCashierReport.txtreceipts.style.visibility="hidden"
	window.document.frmCashierReport.txtpayments.style.visibility="hidden"
}
else if(RepStatus=="CONSCASHIER")
{
	window.document.frmCashierReport.txtnm1.value="Receipts & Payments"
	window.document.frmCashierReport.optVaultTran[0].checked=true;
	window.document.frmCashierReport.optVaultTran[1].style.visibility="visible"
	window.document.frmCashierReport.optVaultTran[2].style.visibility="visible"
	window.document.frmCashierReport.txtreceipts.style.visibility="visible"
	window.document.frmCashierReport.txtpayments.style.visibility="visible"

}
else if(RepStatus=="VAULTPOS")
{
	window.document.frmCashierReport.txtnm1.value="Vault Position"
	window.document.frmCashierReport.optVaultTran[0].checked=true;
	window.document.frmCashierReport.optVaultTran[1].style.visibility="hidden"
	window.document.frmCashierReport.optVaultTran[2].style.visibility="hidden"
	window.document.frmCashierReport.txtreceipts.style.visibility="hidden"
	window.document.frmCashierReport.txtpayments.style.visibility="hidden"
}
else if(RepStatus=="CASHCUNTEXCH")
{
	window.document.frmCashierReport.txtnm1.value="Cash Counter Exchange"
	window.document.frmCashierReport.optVaultTran[0].checked=true;
	window.document.frmCashierReport.optVaultTran[1].style.visibility="hidden"
	window.document.frmCashierReport.optVaultTran[2].style.visibility="hidden"
	window.document.frmCashierReport.txtreceipts.style.visibility="hidden"
	window.document.frmCashierReport.txtpayments.style.visibility="hidden"
}
window.document.frmCashierReport.all.divcashierpos.style.display="none"
window.document.frmCashierReport.all.divDenominationreport.style.display="none"
window.document.frmCashierReport.all.divvault.style.display="Block"	
window.document.frmCashierReport.all.divclsBalDtls.style.display="none"
}
///function to clear the currencycode,desc if ALl radio button is checked
function VaultCheck()
{
//window.document.frmCashierReport.txtCurrencyCode.value=""
//window.document.frmCashierReport.txtCurrencyDesc.value=""
}
///function to un check the  ALL radio button  if currency code is clicked
function CurrencyClick()
{
	if((RepStatus!="CASHIERPOS")||
	(window.document.frmCashierReport.all.divvault.style.display=="block"))
	{
		window.document.frmCashierReport.optVaultTran[0].checked=false
	}

}
//-->
</SCRIPT>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
function dtpReportDt_CloseUp() {

Datepick(window.document.frmCashierReport.dtpReportDt,
window.document.frmCashierReport.txtRepdate)
splitString("window.document.frmCashierReport","txtcid,txtcdesc")
CashierDisp("DateCheck")
}
function dtpVaultRepDate_CloseUp() {
Datepick(window.document.frmCashierReport.dtpVaultRepDate,
window.document.frmCashierReport.txtRepvaultdate)
CashierDisp("DateCheck")

}
function dtpDenomDt_CloseUp() {
Datepick(window.document.frmCashierReport.dtpDenomDt,
window.document.frmCashierReport.txtDenomdate)
CashierDisp("DateCheck")

}

function dtpclsbalVltRepDate_CloseUp() {
Datepick(window.document.frmCashierReport.dtpclsbalVltRepDate,
window.document.frmCashierReport.txtclsbalRepvltdate)
CashierDisp("DateCheck")

}

///function for checking the login user is abb or not 
function abbcheck()
	{
		
		AbbStatus="<%=session("abbuser")%>"
		window.document.frmCashierReport.dtpReportDt.Value="<%=session("applicationdate")%>"
		window.document.frmCashierReport.dtpVaultRepDate.Value="<%=session("applicationdate")%>"
		window.document.frmCashierReport.txtRepdate.value="<%=session("applicationdate")%>"
		window.document.frmCashierReport.txtRepvaultdate.value="<%=session("applicationdate")%>"
		window.document.frmCashierReport.txtDenomdate.value="<%=session("applicationdate")%>"
		window.document.frmCashierReport.txtclsbalRepvltdate.value="<%=session("applicationdate")%>"
		
		if(AbbStatus.toUpperCase()=="Y")
		{
		
		window.document.frmCashierReport.B3.disabled=false
		window.document.frmCashierReport.txtBranchCode.readOnly=false
		window.document.frmCashierReport.B3.focus()
		}
		else
		{
		window.document.frmCashierReport.B3.disabled=true
		window.document.frmCashierReport.txtBranchCode.readOnly=true
		
		}
		
		
	}
	///function for returning the message from serverside page after transaction
function DispTranMsg()
{
window.document.frmCashierReport.txtcdesc.value=""
window.document.frmCashierReport.txtcid.value=""
window.document.frmCashierReport.txtRepdate.value="<%=session("applicationdate")%>"
window.document.frmCashierReport.txtRepvaultdate.value="<%=session("applicationdate")%>"
window.document.frmCashierReport.txtDenomdate.value="<%=session("applicationdate")%>"

var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashierwisereport.aspx" 
		
	}
}	
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpReportDt EVENT=CloseUp>
<!--
 dtpReportDt_CloseUp()
//-->
</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=dtpVaultRepDate EVENT=CloseUp>
<!--
 dtpVaultRepDate_CloseUp()
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=dtpDenomDt EVENT=CloseUp>
<!--
 dtpDenomDt_CloseUp()
//-->
</SCRIPT>

<SCRIPT LANGUAGE=javascript FOR=dtpclsbalVltRepDate EVENT=CloseUp>
<!--
 dtpclsbalVltRepDate_CloseUp()
//-->
</SCRIPT>


</head>
<body topmargin="0" leftmargin="0" topmargin="0" leftmargin="0" 
onload="GetMenu(&quot;<%=session("menustring")%>&quot;);modeStatus();abbcheck();DispTranMsg()">

<form name="frmCashierReport">
<div class="header">
<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="2%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>Cashier Wise Report</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>


  <table width="100%" border="0" height="74%" cellspacing="0" cellpadding="0" class="tblebordermain">
    <tr>
      <td>

     <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="89%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
          </table>

          </td>
        </tr>
      </table> -->

    <tr>
      <td width="100%" valign="top">

     <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" valign="top" height="28">
          <p align="center">&nbsp;&nbsp;</p>
          </td>
        </tr>
      </table> -->

      <%appdate=formatdatetime(session("applicationdate"),1)%>


      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="1">
        <tr>
          <td width="100%" height="29">

         <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
            
            <tr>
              <td width="100%" colspan="3" align="center" height="15">
              <p align="center"></p>
              </td>
            </tr>
          </table> -->

          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="12%" height="27">
                <p align="right">&nbsp;Branch Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                </td>
                <td width="30%" height="27"><input class="txtautofill" name="txtBranchCode" style="TEXT-TRANSFORM: uppercase" 
                size="9" value="<%=session("branchcode")%>" onblur="Dataarrange(txtBranchCode);CashierDisp(&quot;txtBranchCode&quot;)" maxlength="10"><input type="button" class="button" value=" L " name="B3" onclick="branch()"><input name="txtBranchDesc" size="16" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
                
                <td width="15%" align="right" height="27">Currency Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td width="30%" height="27"><input class="txtautofill" name="txtCurrencyCode" style="TEXT-TRANSFORM: 
                          uppercase" size="9" maxlength="10" onblur="Dataarrange(txtCurrencyCode);CashierDisp(&quot;txtCurrencyCode&quot;)" value="<%=session("currencycode")%>"><input type="button" class="button" value=" L " name="B9" onclick="currency()"><input name="txtCurrencyDesc" size="16" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
              <!--<tr>
                <td width="88" height="20"></td>
                <td width="282" height="20"></td>
                <td width="153" align="right" height="20"></td>
                <td width="231" height="20"></td>
              </tr> --->
            </table>

            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="18%" valign="top">

                <table border="0" width="100%" cellspacing="1" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" style="text-decoration:none" onclick="RepStatus=&quot;CASHIERPOS&quot;; window.document.frmCashierReport.optVaultTran[0].disabled=true; CashierPosDivDisp()"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Cashier Position</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" style="text-decoration:none" onclick="RepStatus=&quot;CONSCASHIER&quot;; window.document.frmCashierReport.optVaultTran[0].disabled=false; VaultDivDisp()"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Receipts & Payments</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" style="text-decoration:none" 
                    onclick="RepStatus=&quot;VAULTPOS&quot;; window.document.frmCashierReport.optVaultTran[0].disabled=false; VaultDivDisp();"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Vault Position</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;VAULTCASH&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;VaultDivDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Vault Cash</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;CASHCUNTEXCH&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;VaultDivDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Cash Counter Exchange</font></a></td>
                  </tr>
                  
                  <% 
						dim denomyn
					
						denomyn = session("cashdenomyn")
				
					if denomyn="Y" then  %>
                  
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;CASHALLOT&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;DenomRepDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Cash Allotment</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;CASHREFND&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;DenomRepDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Cash Refund</font></a></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;CASHEXCHANGE&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;DenomRepDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Cash Exchange</font></a></td>
                  </tr>
                  
                  <tr class="bgcolor">
                    <td width="100%" height="18">&nbsp;<a href="#" onclick="RepStatus=&quot;CLSBALDTLS&quot;;window.document.frmCashierReport.optVaultTran[0].disabled=false;ClsBalDtlsDisp()" style="text-decoration:none"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;Closing Bal Dtls</font></a></td>
                  </tr>
                  <% end if %>
                </table>

                </td>
                <td width="82%" valign="top">
					<div id="divcashierpos" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%">
									<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
										<tr class="bgcolor">
											<td align="middle" width="26%"><p align="left"><font class="textbold"><input name="txtnm" class="button" value="Cashier Position"></font></p></td>
											<td align="middle" width="27%"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
								<div align="center">
									<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
										<tr>
											<td width="613" colspan="5" height="10">
												<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
													<tr class="bgcolor1">
														<td align="middle" width="26%"><p align="center"><input name="optTran" onclick="mode=&quot;All&quot;;;ClearFlds();" type="radio" checked><font class="textblack"> All</font></p></td>
														<td align="middle" width="27%"><p align="center"><input name="optTran" onclick="mode=&quot;RecPay&quot;;ClearFlds();" type="radio" value="MODIFY"><font class="textblack">Receipts &amp; Payements</font></p></td>
													</tr>
												</table>
											</td>
										</tr>
										<tr>
											<td width="88" height="20"></td>
											<td width="78" height="20"></td>
											<td width="127" height="20" align="right"></td>
											<td width="70" height="20"></td>
											<td width="242" height="20"></td>
										</tr>
										<tr>
											<td width="12%" height="27" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Report Date</td>
											<td width="12%" height="27" align="right"><input name="txtRepdate" size="10" style="TEXT-ALIGN: right" maxlength="16" readonly class="txtautofill"></td>
											<td width="5%" height="27">
				  
  <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=22 id=dtpReportDt 
	name=dtpReportDt style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 26px" width=26 >
	<PARAM NAME="_ExtentX" VALUE="688">
	<PARAM NAME="_ExtentY" VALUE="582">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>
                          
											</td>
											<td width="15%" height="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cashier ID</td>
											<td width="30%" height="27"><input name="txtcid" size="9" maxlength="20" style="TEXT-TRANSFORM: uppercase" class="txtautofill" onblur="Dataarrange(txtcid);CashierDisp(&quot;txtcid&quot;)" class="bgcolor1"><input type="button" class="button" value=" L " name="butcashid" onclick="Cashiercode()"><input name="txtcdesc" size="16" readonly class="bgcolor1"></td>
										</tr>
										<tr>
											<td width="88" height="20"></td>
											<td width="78" height="20"></td>
											<td width="127" height="20" align="right"></td>
											<td width="70" height="20"></td>
											<td width="242" height="20"></td>
										</tr>
									</table>
								</div>
								</tr>
							</table>
						</div>
						<div id="divvault" style="display: none; width: 619; height: 69">
							<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor">
												<td align="middle" width="26%">
												<p align="left"><font class="textbold"><input name="txtnm1" class="button" ></font></p>
												</td>
												<td align="middle" width="27%"></td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<div>
												<tr class="bgcolor1">
													<td align="middle" width="26%"><p align="center"><font class="textblack"><input name="optVaultTran" onclick="VaultCheck()" type="radio" > All</font></p></td>
													<td align="middle" width="50%"><font class="textblack"><input name="optVaultTran" onclick="VaultCheck()" type="radio" ></font><input name="txtreceipts" readonly size="10" class="bgcolor4" value =  "Receipts" style="background-color:transparent;BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; font-size: 14px;TEXT-ALIGN: left "></td>
													<td align="middle" width="26%"><p align="center"><font class="textblack"><input name="optVaultTran" onclick="VaultCheck()" type="radio" > &nbsp;<input name="txtpayments" readonly size="10" class="bgcolor4" value = "Payments" style="background-color:transparent;BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300;  font-size: 14px; TEXT-ALIGN: left "></font></p></td>
													<td align="middle" width="27%"></td>
												</tr>
											</div>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table border="1" width="100%" cellspacing="0" cellpadding="0">
											<tr>
												<td width="50%" height="27" align="right">Report Date&nbsp;&nbsp;&nbsp;&nbsp;</td>
												<td width="12%" height="27"><input name="txtRepvaultdate" size="10" style="TEXT-ALIGN: right" maxlength="16" readonly></td>
												<td width="12" height="27">
                          <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=22 id=dtpVaultRepDate 
	name=dtpVaultRepDate style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 28px" width=28 >
	<PARAM NAME="_ExtentX" VALUE="741">
	<PARAM NAME="_ExtentY" VALUE="582">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>

												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</div>
						<div id="divDenominationreport" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%">
									<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
										<tr class="bgcolor">
											<td align="middle" width="26%"><p align="left"><font class="textbold"><input name="txtDenomRep" class="button" value="Cashier Position"></font></p></td>
											<td align="middle" width="27%"></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
								<div align="center">
									<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
										<tr>
											<td width="613" colspan="5" height="10">
												<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
													<tr class="bgcolor1">
														<td align="middle" width="26%"><p align="center"><input name="optTran" onclick="mode=&quot;All&quot;;;ClearFlds();" type="radio" checked><font class="textblack"> All</font></p></td>
														<td align="middle" width="27%"></td>
													</tr>
												</table>
											</td>
										</tr>
										<tr>
											<td width="88" height="20"></td>
											<td width="78" height="20"></td>
											<td width="127" height="20" align="right"></td>
											<td width="70" height="20"></td>
											<td width="242" height="20"></td>
										</tr>
										<tr>
											<td width="12%" height="27" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Report Date</td>
											<td width="12%" height="27" align="right"><input name="txtDenomdate" size="10" style="TEXT-ALIGN: right" maxlength="16" readonly class="txtautofill"></td>
											<td width="5%" height="27">
				  
  <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=22 id=dtpDenomDt 
	name=dtpDenomDt style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 26px" width=26 >
	<PARAM NAME="_ExtentX" VALUE="688">
	<PARAM NAME="_ExtentY" VALUE="582">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>
                          
											</td>
											<td width="15%" height="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cashier ID</td>
											<td width="30%" height="27"><input name="txtcashid" size="9" maxlength="20" style="TEXT-TRANSFORM: uppercase" class="txtautofill" onblur="Dataarrange(txtcashid);CashierDisp(&quot;txtcashid&quot;)" class="bgcolor1"><input type="button" class="button" value=" L " name="butcashid" onclick="Cashiercode()"><input name="txtcashdesc" size="16" readonly class="bgcolor1"></td>
										</tr>
										<tr>
											<td width="88" height="20"></td>
											<td width="78" height="20"></td>
											<td width="127" height="20" align="right"></td>
											<td width="70" height="20"></td>
											<td width="242" height="20"></td>
										</tr>
									</table>
								</div>
								</tr>
							</table>
						</div>

						<div id="divclsBalDtls" style="display: none; width: 619; height: 69">
							<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<tr class="bgcolor">
												<td align="middle" width="26%">
												<p align="left"><font class="textbold"><input name="txtclsbal" class="button" value = "Closing Balance Details" ></font></p>
												</td>
												<td align="middle" width="27%"></td>
											</tr>
											<tr>
											<td width="30%" align="center"><input type="radio" name="repsch1" id="frmsub" onclick="show1()" checked><font class="textblack">Branch Wise </font></td>
											<td width="30%" align="center"><input type="radio" name="repsch1" id="frmnosub" onclick="show1()" ><font class="textblack">Consolidate Wise </font></td>
										</tr>
										</table>
									</td>
								</tr>
								
								<tr>
									<td width="100%">
										<table border="1" width="100%" cellspacing="0" cellpadding="0">
											<tr>
												<td width="50%" height="27" align="right">Report Date&nbsp;&nbsp;&nbsp;&nbsp;</td>
												<td width="12%" height="27"><input name="txtclsbalRepvltdate" size="10" style="TEXT-ALIGN: right" maxlength="16" readonly></td>
												<td width="12" height="27">
                          <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=22 id=dtpclsbalVltRepDate 
	name=dtpclsbalVltRepDate style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 28px" width=28 >
	<PARAM NAME="_ExtentX" VALUE="741">
	<PARAM NAME="_ExtentY" VALUE="582">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>

												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</div>
						
					</td>
				</tr>
			</table>

            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="100%" height="32"></td>
        </tr>
        <tr>
          <td width="100%" height="32"><center>
          <div align="center">
            <center>

            <table width="30%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="Generate" name="cmdAdd" onclick="TempDataGenerate('HTML')" class="button">
               
                <input type="button" value="XL Generate" name="cmdAdd" onclick="TempDataGenerate('XL')" class="button">
               
                <input type="reset" value="Cancel" name="cmdCancel" onclick="location.href=&quot;Cashierwisereport.aspx&quot;" class="button"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;"  width="100%" height="20"></td>
              </tr>
            </table>

            <input type="hidden" name="hpr" value="<%=session("PRECISION")%>">
            <input type="hidden" name="hreport">
            </div>
          </center></center></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="hmod" value="<%=session("module")%>"><input type="hidden" name="status"><input type="hidden" name="hidRep">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="cashcountermgtquery.aspx">
                                              </iframe>
      </td>
    </tr>
  </table>
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
					&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	
</form>


</body>

</html>
