<%@ Page Language="vb" CodeBehind="custsolidlist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.custsolidlist" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var str,bt,t,bl,s
 // str= window.document.frmsolid.hbno.value
  
  //k="~"
  
  b2=window.document.frmsolid.hdno.value
  //str=str+k+b2
  str=b2
   window.attachEvent(window.opener.Allot(str))
    window.close()
  // onload='List()'
 }
//-->
</SCRIPT>

<%

  str=Request.QueryString("st")

  dim rsCust,obj,CustAdd1,CustAdd2,CustAdd3,con,rsDenom
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  set rsCust=server.CreateObject("adodb.recordset")
  set RsDenom =server.CreateObject("adodb.recordset")
  con=split(str,"*")
  if con(2)="Addr" then
  Response.Write con(1)
  set rsCust=obj.singleRecordSet("GENCUSTINFOMST","CUSTMAILHNO,CUSTMAILSTREET,CUSTMAILTOWN," & _
						"CUSTMAILDIST,CUSTMAILSTATE,CUSTMAILPINCODE"," customerid='"& con(1) &"'")
  custAdd1=rscust(0)& "" & "; " & rscust(1) &""
  custAdd2=rscust(2)& "" & "; " & rscust(3) &""
  custAdd3=rscust(4)& "" & "; " & rscust(5) &""
  acc=custAdd1 & "*" & custAdd2 & "*" & CustAdd3 &"~Addr"
  'acc=Addr & "~Addr"
  set rsCust=nothing
elseif con(1)="List" then
     set RsDenom=obj.singlerecordset("CASHDENOMINATIONMST","denominationvalue","upper(trim(currencycode))='" & ucase(trim(str)) &"'")
     if not rsDenom.EOF then
     cnt=rsDenom.RecordCount
	 do until rsDenom.eof
		acc=acc & rsDenom(0) & "*"
		rsDenom.MoveNext
		'cnt=cnt+1
	 loop
	 acc=left(acc,len(acc)-1)
	acc=acc&"~" & cnt & "~List"
     end if
end if     
  'onload='List()'
%>
<title></title>
</head>
<body onload="List()">

<form name="frmsolid">
  <input type="hidden" id="hbno" name="hbno" value="<%=Addr%>"><input type="hidden" id="hcno" name="hdno" value="<%=acc%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
