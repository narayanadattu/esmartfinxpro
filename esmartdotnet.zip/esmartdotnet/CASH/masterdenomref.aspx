<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="masterdenomref.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.masterdenomref" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>

<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<script language="javascript">

function List()
{
var kstr
  kstr= window.document.frmdm.hcounter.value
  
  if(kstr)
  {
  window.attachEvent(window.parent.GetTotalRefAmt(kstr))
  window.close()
  }
}

</script>
<%
	Dim obj,st,kstr,d
	kstr=Request.Form("hdenom")
	k=split(kstr,"|")	
	userid=session("userid")
	   
%>
<title></title>
</head>
<body topmargin="0" leftmargin="0"  onload = "List()" >

<form name="frmdm">
  <% dim ind,cnt
if len(kstr)>0 then
		 obj=server.CreateObject("cashquery.queries")
		if Ucase(k(1))="CASHVAULTMST" then
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)))
		else
		 rs=server.CreateObject("adodb.recordset")
		 objcou=server.CreateObject("queryrecordsets.fetchrecordsets")
		 rs=objcou.singlerecordset("cashcountermst","counterno","branchcode='" & k(2) & "' and currencycode='" & k(3) & "' and cashierid ='" & ucase(userid) & "'")
			if rs.EOF<>true and rs.BOF<> true then
				countno=rs(0).value
				 objcou=nothing
			end if
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(session("Applicationdate")),cstr(userid),cstr(countno))
			 obj=nothing
	    end if
	    tval=k(3)
if ubound(st)>0 then  %>

  <table border="1" cellspacing="0" cellpadding="0" width="310">
    <%	
 	for j=0 to ubound(st)
 		if cdbl(st(i,1))>0 and cdbl(st(i,2))>0 then
 		if st(j,0)="CP" then
 			ind=ind+1
 		end if
 		end if
 	next
 	m=0
 	pr=len(st(1,3))-1
 	
    %>
    <input type="hidden" name="hpr" value="<%=pr%>"><input type="hidden" name="hfrm" value="<%=k(0)%>">
    <!--<tr>-->
    <tr class="bgcolor">
      <td width="90" height="10" align="center" valign="top"><font class="textwhite">Denom</font></td>
      <td width="90" height="10" align="center"><font class="textwhite">Avail Peices</font></td>
      <td width="26" height="10" align="center"><font class="textwhite"></font>&nbsp;</td>
      <td width="26" height="10" align="center">
      <p align="right"><font class="textwhite">No.of&nbsp; Pieces</font></p>
      </td>
      <td width="26" height="10" align="center"><font class="textwhite"></font>&nbsp;</td>
      <td width="26" height="10" align="right"><font class="textwhite">Amount</font></td>
      <%FOR i=0 TO ubound(st)%>
      <%if st(i,1)<>"" then%>
 	  <%if cdbl(st(i,1))>0 and cdbl(st(i,2))>0 then
 		cnt=cnt+1
 		cal=st(i,3)
		p=len(cal)-1%>	
    <tr align="center">
      <td width="90" height="10" align="right"><%=st(i,1)%></td>
      <input type="hidden" name="hps" value="<%=st(i,1)%>">
      <td width="90" height="10" align="right"><%=st(i,2)%><input type="hidden" name="htype" value="<%=st(i,0)%>"></td>
      <input type="hidden" name="havail" value="<%=st(i,2)%>">
      <td width="26" height="10" valign="top">*</td>
	  <%Tot=cdbl(st(i,1))*cdbl(st(i,2))
	    Avtot=cdbl(Avtot)+cdbl(Tot)
	      %>
	    <% if st(i,0)="CP" then
	       cal=st(i,3)
	       p=len(cal)-1
	       amt=st(i,1)/cal
	     %>
      <input type="hidden" name="hamt" value="<%=amt%>"> 

	  <%if ind>1 then	%>
						
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" readonly style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" value="<%=st(i,2)%>"></td>
	  <%m=m+1
			
			else%>
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" readonly style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" value="<%=st(i,2)%>"></td>
			
		  <%end if %>
		<%else%>
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" readonly style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" value="<%=st(i,2)%>"></td>
		<%end if%>
      <td width="31" height="10" align="center">=</td>
       <% if tval="INR" then
             des="0.00"
          elseif tval="USD" THEN
             des="0.000"
          end if      
			pr=len(st(i,3))-1
            dec=""	
		if trim(st(i,0))="CP" then
			cal=st(i,3)
			Tot=(cdbl(st(i,1))*cdbl(st(i,2)) /cal)
			k=split(Tot,".",-1)
				if ubound(k)>0 then
		    		if len(k(1))<pr then
						z=pr- len(k(1))
					   dec1=""
						for j=1 to z
						dec1=dec1 & "0"
						next
						dec=k(1) & dec1
					else
						dec=k(1)
					end if
				else
					for j=1 to pr
						dec=dec & "0"
					next
				end if
				      Total=k(0) & "." & dec 
		else
		       Tot=cdbl(st(i,1))*cdbl(st(i,2))
		       for j=1 to pr
				dec=dec & "0"
			   next
			   Total=Tot & "." & dec 
		end if	
	  %>	 
      <td width="71"><input type="text" id="txtamt" name="txtamt" value="<%=Total%>" style="FONT-SIZE: x-small; HEIGHT: 18px ;text-align:right" size="9" disabled></td>
    </tr>
    <%Amount=cdbl(Amount)+cdbl(Total) %>
    <%end if%>
    <%end if%>
	<%next%>
	
    <%
     if len(trim(Avtot ))> 0 then
     counter = Amount
     end if
     'if len(trim(Avtot ))> 0 then
	'Response.Write ("<script language=vbscript>")
	
	'Response.Write ("window.parent.window.document.forms(frm).txttotal.value=" & Amount & chr(13))
	 
    'Response.Write ("call precision(window.parent.window.document.forms(frm).txttotal,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
    
    'Response.Write ("</script>") 
   'end if%>
  </table>

  <%else 
        Response.Write ("<table>")
        Response.Write ("<tr>")
        Response.Write ("<td>")
        Response.Write ("<font size=+1 color=blue>")
		Response.Write (st(0,0))
		Response.Write ("</font>")	
		Response.Write ("</td>")
		Response.Write ("</tr>")
		Response.Write ("</table>")
  %>  
  <% end if%>
  <% end if%>
  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" id="hspr" name="hspr"><input type="hidden" name="hcnt" value="<%=cnt%>">
  <input type="hidden" name="hcounter" value="<%=counter%>">
</form>

</body>

</html>
