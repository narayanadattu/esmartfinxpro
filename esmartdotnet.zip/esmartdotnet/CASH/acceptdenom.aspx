<%@ Page Language="vb" aspcompat="true" explicit="False" CodeBehind="acceptdenom.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.acceptdenom" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") &"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="vbscript">
sub total()
   	window.parent.window.document.forms(frm).txttotal.value=window.document.frmdm.hamount.value
end sub
</SCRIPT>
<%
Dim obj,st,kstr
	kstr=Request.Form("hdenom")	
	
	k=split(kstr,"|")
	userid=session("userid")	
	
%>
</head>
<body>

<form name="frmdm">
<center>
  <table border="0" width="280" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <td width="100%"><font class="textblack">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      No.of<br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Denoms&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Pieces&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Amount</font></td>
    </tr>
  </table>

  <%
  if len(kstr)>0 then
  		
		 obj=server.CreateObject("cashquery.queries")
		if ucase(cstr(k(1)))="CASHTRANSBTCASHIERSTRN" then
		
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)), _
					cstr(session("Applicationdate")),cstr(userid),cstr(k(4)),cstr(k(5)))
			
		elseif ucase(cstr(k(1)))="CASHREFUNDSTRN" then
		
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)), _
					cstr(k(3)),cstr(session("Applicationdate")),cstr(k(4)),cstr(k(5)),cstr(k(6)))
			
		elseif ucase(cstr(k(1)))="CASHALLOTMENTSTRN" then
		
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)), _
					cstr(k(3)),cstr(session("Applicationdate")),cstr(userid), _
					cstr(k(5)),cstr(k(6)))	
		elseif ucase(cstr(k(1)))="CANCEL_CASHALLOTMENTSTRN" then
		
			st=obj.CashDenominationsAsarray("CASHALLOTMENTSTRN",cstr(k(2)), _
					cstr(k(3)),cstr(session("Applicationdate")),cstr(k(7)), _
					cstr(k(5)),cstr(k(6)))					
		end if
		kctype=k(3)
		
		'This part of code was written to help the user, while debugging  
		'FOR i=0 TO ubound(st)
		'	response.write(st(i,0) & "," & st(i,1) & "," & st(i,2) & "," & st(i,3) & "<br>")
		'next i
		
		if ubound(st)>0 then    
	    	
   %>

  <table cellspacing="0" cellpadding="0" width="280" class="tableborder1" border="1">
  <tr class="bgcolor" valign="top">
      <td height="10" align="center" valign="top"><font class="textbold">Notes</font></td>
      <td height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      
    </tr>
    
    <input type="hidden" name="hfrm" value="<%=k(0)%>">
 	
 	<%FOR i=0 TO ubound(st)
 	 	if isdbnull(st(i,1))=false and st(i,1)<>"" then 
 			cnt=cnt+1 
 	
			if ((st(i,0)="CF" and c = 0) or (st(i,0)="CP" and c = 0)) then 
				c = 1
        
    %>
        
    <tr class="bgcolor">
      <td height="10" align="center" valign="top"><font class="textbold">Coins</font></td>
      <td height="10" align="center" valign="top">&nbsp;</td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      
    </tr>
    <%		end if%>	
    <tr align="center">
      <td width="90" height="10" align="right">
		<%=st(i,1)%></td>
      <td width="26" height="10" valign="top">*</td>
      <td width="50" height="10" align="right">
	  <%=st(i,2)%></td>
      <td width="31" height="10" align="center">=</td>
      <% pr=len(st(i,3))-1
        dec=""	
        if ucase(st(i,0))="CP" then
	       cal=st(i,3)
	       Tot=(cdbl(st(i,1))*cdbl(st(i,2)) /cal)
		   k=split(Tot,".",-1)
		   if ubound(k)>0 then
			  if len(k(1))<pr then
			     z=pr- len(k(1))
				 dec1=""
				 for j=1 to z
					dec1=dec1 & "0"
				 next
				 dec=k(1) & dec1
			  else
			     dec=k(1)
			  end if
		   else
			 for j=1 to pr
				dec=dec & "0"
			 next
		   end if
		   Total=k(0) & "." & dec 
		else
		   Tot=cdbl(st(i,1))*cdbl(st(i,2))
		   for j=1 to pr
		     dec=dec & "0"
		   next
		   Total=Tot & "." & dec 
		end if	
	  %>	 
      <td width="71" align="right"><%=total%><input type="hidden" name="htot" value="<%=total%>"></td>
      <% Amount=cdbl(Amount)+cdbl(Total)
   end if%>
    </tr>
    <%next%>
    <input type="hidden" name="hpr" value="<%=pr%>"><input type="hidden" name="hamount" value="<%=Amount%>">
    <%  Response.Write ("<script language=vbscript>")
     Response.Write ("call total()" & chr(13))
     Response.Write ("call precision(window.parent.window.document.forms(frm).txttotal,window.document.frmdm.hpr.value)" & chr(13))
     Response.Write ("</script>") %>
  </table>
</center>
  <%
  else
	Response.Write (st(0,0))
   end if
  end if%>
  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" id="hcou" name="hcou" value="<%=cnt%>">
</form>

</body>

</html>
