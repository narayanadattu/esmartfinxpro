<%@ Page Language="vb" CodeBehind="cashreceiptsrem.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashreceiptsrem" %>
<%
dim vUserid,vCounterNo,vAppdate,vCashierid,vMachineId
vUserid=session("userid")
vCounterNo=session("Counterno")
vAppdate=session("applicationdate")
vCashierid=session("userid")
vBranchCode=session("branchcode")
vCurCode=session("currencycode")
vBrnarration=session("branchnarration")
vCurnarration=session("currencynarration")
vMachineId=session("machineid")
'---------
 dim CshType,Rfldnms,RwhrCond
        Rfldnms="cashiertypeid" 
        
        RwhrCond="upper(branchcode)='"&cstr(ucase(trim(vBranchCode)))&"' and upper(currencycode)='"&cstr(ucase(trim(vCurCode)))&"' and upper(cashierid)='"&cstr(ucase(trim(vUserid)))&"'"
        
        set recLmt=server.CreateObject("adodb.recordset")
        set objLmt=server.CreateObject("queryrecordsets.fetchrecordsets")
        set recLmt=objLmt.SingleRecordset("CASHCOUNTERMST",cstr(Rfldnms),cstr(RwhrCond))
            if recLmt.RecordCount>0 then
                CshType=recLmt(0)
                Rfldnms="receiptsyn"
                RwhrCond="upper(branchcode)='"&cstr(ucase(trim(vBranchCode)))&"' and upper(currencycode)='"&cstr(ucase(trim(vCurCode)))&"' and upper(cashiertypeid)='"&cstr(ucase(trim(CshType)))&"'"
                set recLmt=objLmt.singlerecordset("CASHCASHIERTYPEMST",cstr(Rfldnms),cstr(RwhrCond))
				if recLmt.recordcount>0 then
				CshType=recLmt(0)   
				end if
            else
                CshType="NORECLMT"
            end if   
           
'---------
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Reciepts</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript src="trnClear.js"></SCRIPT>
<script language=javascript>

//---------------------------------------------------------------------------------- 
//Declaring Public variables  
   var CrDrMode,CrDrDesc,blnMinBal,ChqYN,brCode,brDesc,curCode,curDesc,fnlStr,cashGlCode
   var cashGldesc,strsessionflds,strSessionFld,Amt,mode,Rselect,oldAmt,accnoChng,MaxRcptAmt
   var instr,modid,modeval,chknull,commtranno,comglcode,commodid,remtype,comgldesc,nullchk,stremval

var issonbnk="" 
//---------------------------------------------------------------------------------- 
//It gives mode of transaction.
   function TranMode()
     {
      accnoChng="false"
      CrDrMode="2"
      CrDrDesc="Cash"
      GlCode()
     }
 
//----------------------------------------------------------------------------------
//This function is used to display denominations or account details depending on 
//user selection.
  var stpay
  function balDisplay(){
		if(window.document.frmTrans.balChk.checked==true){			
	  		window.document.all['Denom'].style.display="none";
			window.document.all['trnsfer'].style.display="block"
		  }
		 else {
	  		window.document.all['Denom'].style.display="block";
			window.document.all['trnsfer'].style.display="none"
		  }
	}
//----------------------------------------------------------------------------------
//Is used to display pending transaction grid based on user selection
function transDisp()

{
        {
		if(window.document.frmTrans.chkTrandtls.checked==true)
		{			
	  		window.document.all['dtemp'].style.display="block";
	  		window.document.all['iloandtls'].style.display="none";
		  }
		 else 
		 {  
		    {
	  	   	window.document.all['dtemp'].style.display="none";
	  	   	}
	  		{
	  		if(window.document.frmTrans.txtModId.value=='LOAN')
	  		{
	  		window.document.all['iloandtls'].style.display="block";
	  		}
	  		}
	  		//window.document.all['iloandtls'].style.display="block";
		  }
		 } 
}
//----------------------------------------------------------------------------------
//This function was written to display account holder details like Current Balance,...
//coming from server page
 function display(str){
	var balstr=new String();
	
	balstr=str.split("|");
	window.document.frmTrans.txtClrBal.value=balstr[0];
	precision(window.document.frmTrans.txtClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtUnClrBal.value=balstr[1];
	precision(window.document.frmTrans.txtUnClrBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtNetBal.value=balstr[2];
	precision(window.document.frmTrans.txtNetBal,window.document.frmTrans.hpr.value)
	window.document.frmTrans.txtCustId.value=balstr[3];
	window.document.frmTrans.txtOpaBy.value=balstr[4];
	window.document.frmTrans.txtOpInstr.value=balstr[5];
	
	if(window.document.frmTrnsMain.Mfgpaydt.Rows>1){
	AccChange(Rselect)
	if(accnoChng=="false"){
	window.document.frmTrans.txtClrBal.value=eval(balstr[0])-eval(window.document.frmTrnsMain.hdntxtBal.value)
	window.document.frmTrans.txtNetBal.value=eval(balstr[2])-eval(window.document.frmTrnsMain.hdntxtBal.value)
	precision(window.document.frmTrans.txtClrBal,window.document.frmTrans.hpr.value)
	precision(window.document.frmTrans.txtNetBal,window.document.frmTrans.hpr.value)
	}
	}
  }
//----------------------------------------------------------------------------------
//function branch()
//This function was written to send values to list form for Branch details display,
//and used to store already selected brach code and description for later use. 
 function Tellerbranch()
 {     
       brCode=window.document.frmTrans.txtbranchcode.value  
       brDesc=window.document.frmTrans.txtbranchdesc.value 
	   st="Tellerbranch";
	   window.open("List.asp" + "?"+"st="+st,st,"width=200%,height=150% left=100 top=170");
 }
 //---------------------------------------------------------------------------------
 //This function is used to send parameters to List form to get various currency codes and
 //descriptions available and also used for storing already selected currency code and
 //currency description
function curr()
 {   curCode=window.document.frmTrans.txtcurrencycode.value
	 curDesc=window.document.frmTrans.txtcurrencydesc.value
	 st="Curr";	 
	 window.open("List.asp" + "?"+"st="+st,st,"width=250%,height=150% left=520 top=170");
 }
//----------------------------------------------------------------------------------
 //This function was written to send parameters values to List form to get various modules
 //and it displays modules only when Mfgpaydt(flexgrid) rows <2 or if the mode is MODIFY.
 //function module()
 function Tellermodule()
 { 
     if((window.document.frmTrnsMain.Mfgpaydt.Rows<2)||(mode=="MODIFY")){
     stmod="Tellermodule"; 
	 stbr=window.document.frmTrans.txtbranchcode.value
	 str=stmod+"|"+stbr
	 window.open("List.asp?st="+str,"st","width=250%,height=150% left=60 top=50");
	 }
	 else
	 {
	 alert("Post already entered data")
	 }
 }
//---------------------------------------------------------------------------------- 
//This function is used to send parameters to List form to display various Glcodes avialabe
//It displays Glcodes based on branchcode and module id.  
function Glcode()
{  
	telgl="Tellerglcode";
	brcode=window.document.frmTrans.txtbranchcode.value;
	modid=window.document.frmTrans.txtModId.value;
	str=telgl+"|"+brcode+"|"+modid
	if(modid!=""){
		 window.open("List.asp?st="+str,"gl","width=250%,height=150% left=60 top=300");
	 } 
}

//---------------------------------------------------------------------------------- 
//This function is used to send paramters to List form to display various account No. and
//names,it sends parameters if,branchcode,glcode,modid fields were filled.
function AccCode()
{  
    stacc="Telleraccno";
    brchCd=window.document.frmTrans.txtbranchcode.value;
    ModId=window.document.frmTrans.txtModId.value;
    GlCd=window.document.frmTrans.txtGLcode.value;
    str=stacc+"|"+brchCd+"|"+ModId+"|"+GlCd
    if((brchCd.length>0)&&(GlCd.length>0)&&(ModId.length>0))
   	window.open("List.asp?st="+str,"acc","width=250%,height=150%")
 }
//----------------------------------------------------------------------------------
//This function is used to display Account No. and Names.It clears amount and narration
//fields and also displays account holder details.	
 function accountid(str)
 { 
    var strnew;
    strnew=str.split("-----")
    window.document.frmTrans.txtAccNm.value =strnew[0]
    window.document.frmTrans.txtAccNo.value =strnew[1] 
  	AmtNarrClear()//TO CLEAR AMOUNT AND NARRATION
	balanceDet()
	{
	if(window.document.frmTrans.txtModId.value=="LOAN")
		{
		funloanintdetails()
		}
	}
 } 
//----------------------------------------------------------------------------------
//This function is used to display Glcodes.And it clears all the lower level fields	
function Glcodeid(str)
  { 
     assign(str,window.document.frmTrans.txtGLname,window.document.frmTrans.txtGLcode)
	 AccountClear();
	 funloanclear()
	 getremtype()
 } 	 
//----------------------------------------------------------------------------------
//function Branchid(str)
//This function is used to display Branchcodes and descriptions and it also gives alert
//if user changes branch code after entering some data in the flex grid.
 function Branchcode(str)
 {   
      assign(str,window.document.frmTrans.txtbranchdesc,window.document.frmTrans.txtbranchcode)
	  ClearAlert("Brn")
 } 
//----------------------------------------------------------------------------------
//This function is used to display currency codes,descriptions and precission.
//It gives an alert if user is trying to change currency code after entering some data to
//the flex grid. 
//Changing of currency code will display denominations for that particular currency code.

function Currid(str)
{ var k

    k=str.split("-----")
	window.document.frmTrans.txtcurrencydesc.value =k[0]
	window.document.frmTrans.txtcurrencycode.value =k[1]
	ClearAlert("Cur")
	  prn=k[2].length-1
      window.document.frmTrans.hpr.value=prn
      
      Denom()
      
}	
//-----------------------------------------------------------------------------------
//This function displays various moduleids and descriptions,it also clear all lower level
//fields.
//function Moduleid(str)
function modulecode(str)
 {  
   var vStr=str.split("-----");
    window.document.frmTrans.txtModNm.value=vStr[0];
    window.document.frmTrans.txtModId.value=vStr[1]; 
   // assign(str,window.document.frmTrans.txtModNm,window.document.frmTrans.txtModId);
   
	GLClear()
	funselectmodule()	
	funloanclear()
 
 } 	
 //---------------Prashant (Remittence)
 function getremtype ()
 {
   var atype;
   atype=window.document.frmTrans.txtModId.value;
if(atype=="REM")
 {
  st=window.document.frmTrans.txtGLcode.value;
  window.open("remtypeflylst.asp" + "?"+"st="+st,"prre","width=1%,height=1%left=0 top=0")
   }		 
 }

function remitype(str)
{
alert(str)
var ins=str.split("~")

    window.document.frmTrans.txtissbnkcode.value=ins[1]
    window.document.frmTrans.txtissbnkdesc.value=ins[2]
    issonbnk=ins[1]
    comglcode=ins[3]
    commodid=ins[4]
    comgldesc=ins[5] 
    remtype=ins[0]
    //alert(comgldesc);
   // alert(issonbnk)   
}
 
 //----------------------------------------------------------------------
//-----------------------------------y.naveen kumar (LOANS)
//For LOAN Module




function funselectmodule()
{
  {
  if(window.document.frmTrans.txtModId.value=='LOAN')
  {
  
  window.document.frmTrans.chkTrandtls.checked=false
  window.document.all['dtemp'].style.display="none";
  window.document.all['iloandtls'].style.display="block";
  window.document.all['remcr'].style.display="none";   
  }
  else if(window.document.frmTrans.txtModId.value=='REM'){
  window.document.all['iloandtls'].style.display="none";
  window.document.all['remcr'].style.display="block";   //
  }
  else
  {
  window.document.all['iloandtls'].style.display="none";
  window.document.all['remcr'].style.display="none";   
  }
  }
}


//insert interest dtls into loaninterest frame
function funloanintdetails() 
{
var str
str="frmtrans"+"~"+"loandetails"+"~"+window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+window.document.frmTrans.txtAccNo.value+"~"+window.document.frmTrans.txtGLcode.value 
window.document.all['iloandtls'].src="loaninterestdetails.asp?str="+str;
precision(window.document.frames("iloandtls").frmloaninterestdetails.txtintpending,window.document.frmTrans.hpr.value)
funinsertloan()
}

function funinsertloan()
{
var strqry
strqry="frmtrans"+"|"+"loanpreference"
window.open("cashloangetdtls.asp" + "?"+"strqry="+strqry,"ddd","width=457%,height=160%,,top=135,left=220")
}


function getloandtls(strvals)
{
var strsplit
strsplit=strvals.split("|")
{
if(strsplit[0]=="loanpreference")
	{	
	window.document.frmTrans.hdloandetails.value=strvals.substring(15)
	}
}
}

//after entering amount and filling the amount into 
//respective fields into loanframe
function funinsertintdtls()
{
var strloansplit
   inttot=window.document.frmTrans.txtAmt.value 
   strloansplit=(window.document.frmTrans.hdloandetails.value).split("|")
   {
   window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt.value=""
   }
   
	{
	if(window.document.frmTrans.hdloandetails.value!="0" && window.document.frmTrans.hdloandetails.value.length>0)
	{
      {
      for(var intcnt=1;intcnt<5;intcnt++)
		{
         {
         if(strloansplit[0]==(eval(intcnt)-1) && eval(inttot)>0)
			{
			   {
			    if(eval(inttot)>eval(window.document.frames("iloandtls").frmloaninterestdetails.txtintpending.value))
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value=window.document.frames("iloandtls").frmloaninterestdetails.txtintpending.value
			    inttot=eval(inttot)-eval(window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value)
			    }
			    else
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value=inttot
			    inttot=eval(inttot)-eval(inttot)
			    }
			   } 
			}
		 else if(strloansplit[1]==(eval(intcnt)-1) && eval(inttot)>0)
		    {
			   {
			    if(eval(inttot)>eval(window.document.frames("iloandtls").frmloaninterestdetails.txtchrgpending.value))
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value=window.document.frames("iloandtls").frmloaninterestdetails.txtchrgpending.value
			    inttot=eval(inttot)-eval(window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value)
			    }
			    else
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value=inttot
			    inttot=eval(inttot)-eval(inttot)
			    }
			   } 
			}
	     else if(strloansplit[2]==(eval(intcnt)-1) && eval(inttot)>0)
		    {
			   {
			    if(eval(inttot)>eval(window.document.frames("iloandtls").frmloaninterestdetails.txtinsurpending.value))
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value=window.document.frames("iloandtls").frmloaninterestdetails.txtinsurpending.value
			    inttot=eval(inttot)-eval(window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value)
			    }
			    else
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value=inttot
			    inttot=eval(inttot)-eval(inttot)
			    }
			   } 
			}	
		else if(strloansplit[3]==(eval(intcnt)-1) && eval(inttot)>0)
		    {
			   {
			    if(eval(inttot)>eval(window.document.frames("iloandtls").frmloaninterestdetails.txtnpapending.value))
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value=window.document.frames("iloandtls").frmloaninterestdetails.txtnpapending.value
			    inttot=eval(inttot)-eval(window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value)
			    }
			    else
			    {
			    window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value=inttot
			    inttot=eval(inttot)-eval(inttot)
			    }
			   } 
			}					
         }
		}
      }
      
      {
      if(eval(inttot)>0)
      {
      window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt.value=inttot
      }
      }
      
      {
      precision(window.document.frames("iloandtls").frmloaninterestdetails.txtintamt,window.document.frmTrans.hpr.value)
      precision(window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt,window.document.frmTrans.hpr.value)
      precision(window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt,window.document.frmTrans.hpr.value)
      precision(window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt,window.document.frmTrans.hpr.value)
      precision(window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt,window.document.frmTrans.hpr.value)
      }
      
	}
	}
}

//if loan module then allot columns from 44 in flex grid for loans
function funfillloanflex()
{
//alert("ok1")
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,44)="Interestamount"
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,45)="Chargesamount"
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,46)="Insuranceamount"
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,47)="NPAamount"
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,48)="Principalamount"

window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,44)=window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,45)=window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,46)=window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,47)=window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value
window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,48)=window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt.value
}

function funloanclear()
{
//alert("ok")
   window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtintpending.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtchrgpending.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtinsurpending.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtnpapending.value=""
   window.document.frames("iloandtls").frmloaninterestdetails.txtprncexcess.value=""   
}


//----------------------------------------------------------------------------------
//This function is used to call if the mode of transaction is cash while form is loading,
//it also populates native branch and currency details.It also displays capions to the 
//flexgrid.
function cashMode(){
        // cashierType();
         mode="ADD";
	     TranMode();
         ModuleClear();
         grid();
         NatBranch();
	}
//----------------------------------------------------------------------------------
//This function is used to generate Batchno and Tranno if all the data is entered properly
//and if the mode is "ADD". If the mode is "MODIFY" then if will call

function frmSub(){
  
    if(window.document.frmTrnsMain.Mfgpaydt.Rows<4){ 
    if(window.document.frmTrans.txttotal.value=="") 
		window.document.frmTrans.txttotal.value="0.00";
	if(window.document.frmTrans.txtAmt.value=="")
	    window.document.frmTrans.txtAmt.value="0.00";
	    
	if((window.document.frmTrans.txtbranchcode.value!="") &&
		(window.document.frmTrans.txtcurrencycode.value!="") &&
		(window.document.frmTrans.txtModId.value!="") &&
		(window.document.frmTrans.txtGLcode.value!="") &&
		(window.document.frmTrans.txtAccNo.value!="") &&
		(window.document.frmTrans.txtAmt.value!="0.00"))
	{  	   
 	   var totAmt=eval(window.document.frmTrans.txttotal.value);
	   var amt=eval(window.document.frmTrans.txtAmt.value);
	 if(totAmt==amt)
	  {	 
		 var paymode;
		     paymode ="CH"
	     var payType="Rcpt"
	   
	      {
         //this function use to populate account details in to the Flexgrid
		 var strinsert=insertStrForm()// //call function for concating insert string\
//		 alert(strinsert) 
		   if((mode=="ADD")&&(window.document.frmTrnsMain.Mfgpaydt.Rows<2)){	
		   
		      window.open("batchNoGen.asp?strIn="+strinsert+"&flag=&paymode="+paymode+"&PayType="+payType,"branch","width=20 height=20")//openning window for genarate BatchNo and trn No  	
		      
			}
		  else if(mode=="MODIFY"){
		  
		      paymode="TRMOD" 
		      strinsert=modifyStrForm()
//		      alert("modify0")
		      window.open("batchNoGenMod.asp?strIn="+strinsert+"&flag=&paymode="+paymode+"&PayType="+payType,"branch","width=20 height=20")//openning window for genarate BatchNo and trn No  	
//		      alert("modify1")
		  	  FlexPopulateMod()
			}   
		      LockControls(true)		
	   }
	}
   else
	{
		alert("Paid Amount and Denomination amount should be equal");
    }	
 }
 else{   
     alert("Mandatory fields cannot be null");    
     }	
 }
 //mode="ADD"	
 }
//----------------------------------------------------------------------------------
//This function was written to form denomination values,no of pieces,available amount,
//exchange amount array values.
 function denomStrForm(){
            
            fnlStr=""
		//to form denom value string	 
			var DValStr
			var DVal
			DValStr=""
			for(i=0;i<window.document.frames("idenom").frmdm.hps.length;i++){
				DVal=window.document.frames("idenom").frmdm.hps[i].value;
				DValStr=DValStr+DVal+"~"
			}
			window.document.frmTrnsMain.DemonValue.value=DValStr
		//to form denom Type  string	 
			var DTypStr;
			var DTyp;
			DTypStr="";
			for(i=0;i<window.document.frames("idenom").frmdm.htype.length;i++){
				DTyp=window.document.frames("idenom").frmdm.htype[i].value;
				DTypStr=DTypStr+DTyp+"~";
			}
			window.document.frmTrnsMain.DenomType.value=DTypStr;
			
		//to form Paid amount string	 
			var DPayamtStr;
			var DPayamt;
			DPayamtStr="";
	
			for(i=0;i<window.document.frames("idenom").frmdm.txtpieces.length;i++){
			  DPayamt=window.document.frames("idenom").frmdm.txtpieces[i].value;
				DPayamtStr=DPayamtStr+DPayamt+"~";
			}
			window.document.frmTrnsMain.PaidAmt.value=DPayamtStr;
			
		//to form Exchange amount string	 
			var DExamtStr
			var DExamt
			DExamtStr=""
			for(i=0;i<window.document.frames("idenom").frmdm.txtExaPic.length;i++){
				DExamt=window.document.frames("idenom").frmdm.txtExaPic[i].value;
				DExamtStr=DExamtStr+DExamt+"~"
			}    //cash trntype if condition close
			
			window.document.frmTrnsMain.ExchgAmt.value=DExamtStr;
		
			fnlStr=DValStr+"|"+DPayamtStr+"|"+DExamtStr+"|"+DTypStr;
		    
		    //demonination joinning closed here  	
  }
 
//----------------------------------------------------------------------------------
//This function was used to form string of branchcode,currencycode...
function insertStrForm(){
   
    var trnModVal="2"
	var strValues=window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+
		window.document.frmTrans.txtModId.value+"~"+window.document.frmTrans.txtGLcode.value+"~"+window.document.frmTrans.txtAccNo.value+"~"+
		window.document.frmTrans.txtCustId.value+"~"+window.document.frmTrans.txtAmt.value+"~"+
		trnModVal+"~"+window.frmTrans.txtClrBal.value+"~P~"+
		window.document.frmTrans.txtNarran.value+"~"+cashGlCode+"~";
		return strValues;	
}
//----------------------------------------------------------------------------------
//This function is used to populate details to the flex grid,batchno,tranno,applicationdate
//will come from serverside page and remaining values will be populated from respective 
//textboxes.
function ReceiptFlexPopulate(str1,str2){


  with(window.document.frmTrnsMain.Mfgpaydt){   
   var flxRowCnt=Rows
       Rows=flxRowCnt+2
       var genStr=str1.split('~')   
  //Credit Details
			//************* Branch details send to flexgrid   ****************
		TextMatrix(flxRowCnt,0)=genStr[0];
		TextMatrix(flxRowCnt,1)=genStr[1];
		TextMatrix(flxRowCnt,2)=window.document.frmTrans.txtGLcode.value;
		TextMatrix(flxRowCnt,3)=window.document.frmTrans.txtGLname.value;
		TextMatrix(flxRowCnt,4)=window.document.frmTrans.txtAccNo.value;
		TextMatrix(flxRowCnt,5)=window.document.frmTrans.txtAccNm.value;
		Col=6;
		Row=flxRowCnt;
		CellForeColor=52,17,253;
		TextMatrix(flxRowCnt,6)=window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt,8)=strsessionflds[1];
		TextMatrix(flxRowCnt,9)=window.document.frmTrans.txtCustId.value;
		TextMatrix(flxRowCnt,10)="1"//CrDrMode 
		TextMatrix(flxRowCnt+1,10)=CrDrMode 
		TextMatrix(flxRowCnt,11)=CrDrDesc  
		TextMatrix(flxRowCnt+1,11)=CrDrDesc
		TextMatrix(flxRowCnt,12)='P';
		TextMatrix(flxRowCnt+1,12)='P';
		TextMatrix(flxRowCnt,13)='Pending';
		TextMatrix(flxRowCnt+1,13)='Pending';
		TextMatrix(flxRowCnt,14)=window.document.frmTrans.txtcurrencycode.value;
		TextMatrix(flxRowCnt,15)=strsessionflds[0];
		TextMatrix(flxRowCnt,16)=strsessionflds[8];
		TextMatrix(flxRowCnt,19)=window.document.frmTrans.txtModId.value;
		TextMatrix(flxRowCnt,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt,22)=window.document.frmTrans.txtNarran.value;
	    TextMatrix(flxRowCnt,41)=strsessionflds[2];//Should be replaced with Counter No.
	    TextMatrix(flxRowCnt,42)=strsessionflds[3];   
	    TextMatrix(flxRowCnt,43)="1";
 //Debit details 
 //To populate Debit details to flexgrid.
				var genStr1=str2.split("~")
				TextMatrix(flxRowCnt+1,0)=genStr1[0];
				TextMatrix(flxRowCnt+1,1)=genStr1[1];
				TextMatrix(flxRowCnt+1,8)=strsessionflds[1];
						
		TextMatrix(flxRowCnt+1,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt+1,14)=window.document.frmTrans.txtcurrencycode.value
		TextMatrix(flxRowCnt+1,15)=strsessionflds[0];
		TextMatrix(flxRowCnt+1,16)=strsessionflds[8];
	  	TextMatrix(flxRowCnt+1,19)="CASH";
		TextMatrix(flxRowCnt+1,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt+1,2)=cashGlCode
		TextMatrix(flxRowCnt+1,3)=cashGldesc;
		TextMatrix(flxRowCnt+1,4)="1";
		TextMatrix(flxRowCnt+1,5)=cashGldesc;
		Col=6;
		Row=flxRowCnt+1;
		CellForeColor=210,2,2;
		TextMatrix(flxRowCnt+1,6)='-'+window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt+1,22)=window.document.frmTrans.txtNarran.value;
		TextMatrix(flxRowCnt+1,9)=window.document.frmTrans.txtCustId.value;
		window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,41)=strsessionflds[2];
        window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,42)=strsessionflds[3];
        window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,43)="1";
        	
		window.document.frmTrnsMain.txtTotCredit.value=eval(window.document.frmTrnsMain.txtTotCredit.value)+eval(window.document.frmTrans.txttotal.value);
		window.document.frmTrnsMain.txtTotDebit.value=eval(window.document.frmTrnsMain.txtTotDebit.value)+eval(window.document.frmTrans.txttotal.value);
		window.document.frmTrnsMain.txtDiff.value=eval(window.document.frmTrnsMain.txtTotCredit.value)-eval(window.document.frmTrnsMain.txtTotDebit.value);
		}
		precision(window.document.frmTrnsMain.txtTotCredit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtTotDebit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtDiff,window.document.frmTrans.hpr.value)
		
	    {
	    if(window.document.frmTrans.txtModId.value=="LOAN")
	    {
	    //alert("loanfill")
	    
	    funfillloanflex()
	    }
	    }
		
     funloanclear()		
	 ModuleClear();//to clear module and thier child fields		 		
	 NoofAcc()
	 
  }		
//----------------------------------------------------------------------------------
//This function is used to send parameters to get account holder details like Current Balance
//Clear Bal,operating instructions,...
function balanceDet(){
	var str="";
	str=window.document.frmTrans.txtbranchcode.value+"~";
	str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	str=str+window.document.frmTrans.txtModId.value+"~";
    str=str+window.document.frmTrans.txtGLcode.value+"~";    
	str=str+window.document.frmTrans.txtAccNo.value+"~";
//	alert(str)
	window.open("balDetDisplay.asp?str="+str,"bal","width=250%,height=150%");
} 	 
//----------------------------------------------------------------------------------
//Function is used to Clear all the fields on the form and to populate default values to 
//some controls.
function Cancel()
{
 cashMode();
 window.document.frmTrnsMain.Mfgpaydt.Clear();
 window.document.frmTrnsMain.Mfgpaydt.FormatString=">Batch No  |>Tran No   |<GlCode        |<Gl Description                   |>Acc No         |<Name                           |>Amount            |>Entered Time Bal |^Application Date   |<Cust Id               | |<Mode of Tran  ||<Status  |>Currency Code     |<Entered By             |<Enterd M/c             |<Approved By               |<Approved M/c         |<Module Id         |<Branch Code            |>Token No   |<Remarks                           |<Cheque Series  |>Cheque No             |^Cheque Date   |<Cheque Favouring         | | | | | | | | | | | | | | |>Counter No.  |<Cashier Id.          |>Scroll No.";
 window.document.frmTrnsMain.Mfgpaydt.Rows=1;
 window.document.frmTrnsMain.txtTotCredit.value ="0.00"; 
 window.document.frmTrnsMain.txtTotDebit.value ="0.00";
 window.document.frmTrnsMain.NoDrTrn.value="0";
 window.document.frmTrnsMain.NoCrTrn.value="0";
 window.document.all['iloandtls'].style.display="none";
 denomClear();
 Flex();
 funloanclear()
 LockControls(false);
}
//----------------------------------------------------------------------------------
//This function was written to display No.of debit and No. of credit accounts.
function NoofAcc()
{
  var NoCrAcc;
  var NoDrAcc;
      NoCrAcc=0;
      NoDrAcc=0;
  for(i=1;i<window.document.frmTrnsMain.Mfgpaydt.Rows;i++){
        if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,6))>0)
        {
          NoCrAcc=NoCrAcc+1;
          window.document.frmTrnsMain.NoCrTrn.value=NoCrAcc;
        }
          else
        {  
          NoDrAcc=NoDrAcc+1;   
          window.document.frmTrnsMain.NoDrTrn.value=NoDrAcc;
        }  
     }
 }  
    
//----------------------------------------------------------------------------------
//This function is used to send all the values to the component from the form.
//This function is called on click of "Post" button.
function SubPost(){
 if(window.document.frmTrnsMain.Mfgpaydt.Rows>1){
 var crDbDiff=eval(window.document.frmTrnsMain.txtTotCredit.value)-Math.abs(eval(window.document.frmTrnsMain.txtTotDebit.value));
 var actDiff=eval(window.document.frmTrnsMain.txtDiff.value);
 var totCr=eval(window.document.frmTrnsMain.txtTotCredit.value)
 var denTot=eval(window.document.frmTrans.txttotal.value)
    
 if(crDbDiff==actDiff){
 if(totCr==denTot){
    window.document.frmTrnsMain.cmdPost.disabled=true;
	RowCnt=window.document.frmTrnsMain.Mfgpaydt.Rows;
	ColCnt=window.document.frmTrnsMain.Mfgpaydt.Cols;
    var strRow="";
    var strTot="";
    var strArr="";
    for(i=1;i<RowCnt;i++){
		 strRow=""
		for(j=0;j<ColCnt;j++){
		 strRow=strRow+window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,j)+"~";    
		 } 
		 strTot=strTot+strRow+"|";
    }
         denomStrForm();
         strArr=strTot+"^~^~^"+fnlStr
   
    window.location.href="RecTrnInsert.asp?str="+strArr;
  }
  
 else{
    alert("Denominations not tallied");
 } 
 }
 else{
	alert("Credit Amount and Debit Amount Should be Equal");
  }
 }  
}

//----------------------------------------------------------------------------------
//This function is used to format amount fields 
function amtFormat(textvalue){
  textvalue=textvalue+"";
  var sum;
	if(textvalue!="")
	{ 	
	    var dotindex=textvalue.indexOf('.');
		if(dotindex==-1)
		  {
			sum=textvalue+".00";
		  }
		else 
		 {
		   var a=textvalue.substring(textvalue.indexOf('.'),textvalue.length);
		   if(a.length<2)
		     sum = textvalue+".0";
		   if((a.length)>2)
		    var b=textvalue.substring(0,textvalue.indexOf('.')+3);
		    sum = b;
		  }
	return  sum;
	}
}
//----------------------------------------------------------------------------------
//This function was written to hide some columns of the flexgrid in order to not display
function Flex(){
window.document.frmTrnsMain.Mfgpaydt.ColWidth(2)=0;
window.document.frmTrnsMain.Mfgpaydt.ColWidth(10)=0;
window.document.frmTrnsMain.Mfgpaydt.ColWidth(12)=0;
}
//----------------------------------------------------------------------------------
//This function is used to get Deleted batchno from sever page and to know the glcode of 
//cash.
 function Allot(minBal,ChqNo,ChqSer,ChqDt,Rslt,Gcode,sRLimit)
   {
     if(Rslt!=="")
         {
          DelTempTranslog(Rslt)
         }  
     else if(Gcode!=="")
         {
          CshCode(Gcode)
         } 
     else if(sRLimit!=="")
         {
          RecLimit(sRLimit)
         }    
   }   
//----------------------------------------------------------------------------------
//This function is used to send batchno of the selected row of the flexgrid.
function DelTran()
{
   if(window.document.frmTrnsMain.Mfgpaydt.Rows>1){
     strpm="";
     strpm="DEL"+"~"+window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,0);
	 window.open("minBalChk.asp?strparam="+strpm,"Delete","width=20 height=20");
	 }
}
//----------------------------------------------------------------------------------
//This function was written to give an alert when user is trying to change branch code or 
//currency code after populateing some data to the flexgrid.
function ClearAlert(code)
  {
    if(window.document.frmTrnsMain.Mfgpaydt.Rows>1)
     { 
      var confm
      if(code=="Cur")
         {
         confm=confirm("Chaning of Currency Code  at this stage will loose already entered data..."
         +"\n"+"\n"+"Do you want to Continue ?")
         if(confm==true)
            {
               Cancel()
            }  
         else if(confm==false)
            {                 
               window.document.frmTrans.txtcurrencycode.value=curCode
	           window.document.frmTrans.txtcurrencydesc.value=curDesc
            }   
         }
      else if(code=="Brn")
         { 
         confm=confirm("Chaning of Branch Code at this stage will loose already entered data..."
         +"\n"+"\n"+"Do you want to Continue ?")
         if(confm==true)
           {
              Cancel()
           }
         else if(confm==false)
            {                 
               window.document.frmTrans.txtbranchcode.value=brCode
	           window.document.frmTrans.txtbranchdesc.value=brDesc
            }     
         }
      } 
    else
      {
       ModuleClear()
      }         
  }
//----------------------------------------------------------------------------------
//This function was written to send batchno to the server page to delete the batch
//from temporary table(GenTempTranslog).
function flexClick()
{
  var batchno=""
  var strpm="";
  var cnfrm
      if(window.document.frmTrans.mfgTranslog.Rows>1){
      if((window.document.frmTrans.mfgTranslog.TextMatrix
         (window.document.frmTrans.mfgTranslog.Row,0)!="")&&
         (window.document.frmTrans.mfgTranslog.Rows>1)){
          batchno=window.document.frmTrans.mfgTranslog.TextMatrix
         (window.document.frmTrans.mfgTranslog.RowSel,0)
       cnfrm=confirm("Do you want to Delete Batch No  "+batchno)
			if(cnfrm==true)
			 {  
			 strpm="DELTR"+"~"+batchno;
			 window.open("minBalChk.asp?strparam="+strpm,"DelTrans","width=20 height=20");
			 }
			else
			 {
		   } 
         }
     }    
 }
//----------------------------------------------------------------------------------
//This function was written to give message to the user after deleting particular batchno.
function DelTempTranslog(Rst)
{ 
  var balstr=new String();
	  balstr=Rst.split("|")
	  if(balstr[0]="DEL")
	     { 
             for(i=1;i<window.document.frmTrnsMain.Mfgpaydt.Rows;i++){
                 if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,0))>0)
                {
                  if(eval(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(i,0))==balstr[1])
                  {
                   Cancel();
                   alert("Batch No : "+balstr[1]+" is Deleted");   
                  }
                }
             } 
             TempTranslog()  
         }
       else
         {
          alert("Cannot Delete this Batch");
         } 
}
//----------------------------------------------------------------------------------
//This function was written to send parameters to insert values to Gentemptranslog table.
function TempTranslog()
{
var strprm="";
      if((window.document.frmTrans.txtbranchcode.value.length>0)&&
        (window.document.frmTrans.txtcurrencycode.value.length>0)&&
        (window.document.frmTrans.txtModId.value.length>0)&& 
        (window.document.frmTrans.txtGLcode.value.length>0)&&
        (window.document.frmTrans.txtAccNo.value.length>0))
      {
      strprm=window.document.frmTrans.txtbranchcode.value+"~";
      strprm=strprm+window.document.frmTrans.txtcurrencycode.value+"~";
      strprm=strprm+window.document.frmTrans.txtModId.value+"~";
      strprm=strprm+window.document.frmTrans.txtGLcode.value+"~";
      strprm=strprm+window.document.frmTrans.txtAccNo.value+"~";
      strprm=strprm+CrDrMode+"~";
      window.open("temptraninsrt.asp?st="+strprm,"Translog","width=1% height=1%");
      }
}
//----------------------------------------------------------------------------------
//This function is used to populate data to the grid from gentemptranslog table for the
//selected account number.
function TempTranslogpop(strdata)
{
  var K,i,m,b,pos,j,h,n,p,s
	for(m=1;m<=2;m++){
	b=strdata.split("$")
	}
	 st=b[0]
	 	window.document.frmTrans.mfgTranslog.Rows = eval(b[1])+1
		window.document.frmTrans.mfgTranslog.Cols=b[2]

	for(p=1;p<=b[1];p++){
	      n=st.split("|")
	     if(b[1]>0){
			 for(j=0;j<b[2]-1;j++){
				k=n[p-1].split("~")
				window.document.frmTrans.mfgTranslog.TextMatrix(p,j)=k[j]
			 }
		  }
	}
}
//----------------------------------------------------------------------------------
//This function is used to Clear denomination values from the form.
function denomClear(){
      if(window.document.frmTrnsMain.Mfgpaydt.Rows<1){
            for(i=0;i<window.document.frames("idenom").frmdm.txtpieces.length;i++){
			    window.document.frames("idenom").frmdm.txtpieces[i].value=""
			}
			for(i=0;i<window.document.frames("idenom").frmdm.txtExaPic.length;i++){
				window.document.frames("idenom").frmdm.txtExaPic[i].value=""
			} 
			for(i=0;i<window.document.frames("idenom").frmdm.txtamt.length;i++){
				window.document.frames("idenom").frmdm.txtamt[i].value="0.00"
				precision(window.document.frames("idenom").frmdm.txtamt(i),window.parent.window.document.forms(0).hpr.value)
			}
			    window.document.frmTrans.txttotal.value="0.00"
	  }		    
			   // window.document.frmTrans.txttotal.value=precision(window.document.frmTrans.txttotal,window.document.frmTrans.hpr.value)     
  }
//---------------------------------------------------------------------------------- 
//This function is used to clear grid,giving captions to the grid,setting grid rows to 1.
function grid()
{
 window.document.frmTrans.mfgTranslog.Clear();
 window.document.frmTrans.mfgTranslog.FormatString=">Batch No  |>Tran No   |<GlCode        |<Gl Description                   |>Acc No         |>Amount            |>Entered Time Bal |^Application Date   |<Cust Id               |<Mode of Tran  |<Status  |>Currency Code     |<Entered By             |<Enterd M/c             |<Approved By               |<Approved M/c         |<Module Id         |<Branch Code            |>Token No   |<Remarks                           ";
 window.document.frmTrans.mfgTranslog.Rows=1;
}
//----------------------------------------------------------------------------------
//This function was written to send parameters to get cash GL code. 
function GlCode()
{
var str="";
if((window.document.frmTrans.txtbranchcode.value.length>0)&&
        (window.document.frmTrans.txtcurrencycode.value.length>0)){
     str="CASHGL"+"~"+window.document.frmTrans.txtbranchcode.value+"~";
	 str=str+window.document.frmTrans.txtcurrencycode.value+"~";
	 window.open("minBalChk.asp?strparam="+str,"cashGL","width=1% height=1% left=1 top=1");
  }
}
//----------------------------------------------------------------------------------
//This function is used to get Cash GL code.
function CshCode(code)
 {
   var strVal;
   if(code!=="NOGLCODE")
     {
     strVal=code.split("~");
     cashGlCode=strVal[0];
     cashGldesc=strVal[1];
     }
 }
//---------------------------------------------------------------------------------- 
//This function is used to modify already entered data.
function Mfgpaydt_DblClick()
{
 Rselect=window.document.frmTrnsMain.Mfgpaydt.RowSel;
 {
 if(window.document.frmTrnsMain.Mfgpaydt.RowSel==1)
 {
	mode="MODIFY";
	oldAmt=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,6);
	LockControls(false);
//	alert(window.document.frmTrnsMain.Mfgpaydt.RowSel)
	window.document.frmTrans.cmdClear.disabled=true;
	FlexModify(Rselect);
 }
 }
 {
 if(window.document.frmTrans.txtModId.value=="LOAN")
	{
	funloanintdetails()
	//alert("ok")
	window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,44)
    window.document.frames("iloandtls").frmloaninterestdetails.txtchrgamt.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,45)
    window.document.frames("iloandtls").frmloaninterestdetails.txtinsuramt.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,46)
    window.document.frames("iloandtls").frmloaninterestdetails.txtnpaamt.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,47)
    window.document.frames("iloandtls").frmloaninterestdetails.txtprncpalamt.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,48)
    window.document.frmTrans.txtAmt.value=""
	}
 }
}
//----------------------------------------------------------------------------------
//This function is used to get the native branch and native currency codes.
function NatBranch(){
     with(window.document.frmTrans)
         {
          txtbranchcode.value=strsessionflds[4];
          txtbranchdesc.value=strsessionflds[5];
          txtcurrencycode.value=strsessionflds[6];
          txtcurrencydesc.value=strsessionflds[7];
          }
}   
//----------------------------------------------------------------------------------
//This function is used to send parmeters to get denominations.
function Denom()
{
var str=window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+strsessionflds[0]+"~";window.document.all['idenom'].src="cashDenomRcpt.asp?str="+str;
window.document.all['iloandtls'].src="loaninterestdetails.asp" //?str="+str
}
//----------------------------------------------------------------------------------
//This function is used to split session variables.
function PubVariables()
{
     strSessionFld=window.document.frmTrnsMain.txtSessionflds.value
     strsessionflds=strSessionFld.split("~");
     window.document.all['iloandtls'].style.display="none";
     
}
//----------------------------------------------------------------------------------	
//This function is used to modify already entered data,by double clicking on 
//flexgrid data will populate to the respective test boxes and user can modidy the
//data.
function FlexModify(GridRowSel)
{
//   alert(GridRowSel)
   ModuleClear();//to clear module and thier child fields	
   NoofAcc();
   var flxRowCnt=window.document.frmTrnsMain.Mfgpaydt.RowSel; 
   {
   with(window.document.frmTrnsMain.Mfgpaydt)
       {
        window.document.frmTrnsMain.txtBatchno.value=TextMatrix(flxRowCnt,0);
        window.document.frmTrnsMain.txtTranno.value=TextMatrix(flxRowCnt,1);
        window.document.frmTrans.txtGLcode.value=TextMatrix(flxRowCnt,2);
		window.document.frmTrans.txtGLname.value=TextMatrix(flxRowCnt,3);
		window.document.frmTrans.txtAccNo.value=TextMatrix(flxRowCnt,4);
		window.document.frmTrans.txtAccNm.value=TextMatrix(flxRowCnt,5);
		window.document.frmTrans.txtAmt.value=Math.abs(TextMatrix(flxRowCnt,6));
		window.document.frmTrans.txtCustId.value=TextMatrix(flxRowCnt,9)
		window.document.frmTrans.txtcurrencycode.value=TextMatrix(flxRowCnt,14);
		window.document.frmTrans.txtModId.value=TextMatrix(flxRowCnt,19);
		window.document.frmTrans.txtbranchcode.value=TextMatrix(flxRowCnt,20);
		window.document.frmTrans.txtNarran.value=TextMatrix(flxRowCnt,22);
     }  
        window.document.frmTrnsMain.hdntxtBal.value=window.document.frmTrnsMain.Mfgpaydt.TextMatrix(1,6);
        balanceDet()
        
        precision(window.document.frmTrans.txtAmt,window.document.frmTrans.hpr.value)
	    precision(window.document.frmTrans.txtUnClrBal,window.document.frmTrans.hpr.value)
		window.document.frmTrnsMain.txtDiff.value=eval(window.document.frmTrnsMain.txtTotCredit.value)-eval(window.document.frmTrnsMain.txtTotDebit.value);
	    
		precision(window.document.frmTrnsMain.txtTotCredit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtTotDebit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtDiff,window.document.frmTrans.hpr.value) 
		
     
  }		
 }

//-----------------------------------------------------------------------------------	
//This function is used to populate the modified data to the flexgrid.
function FlexPopulateMod(){
  with(window.document.frmTrnsMain.Mfgpaydt){   
     var flxRowCnt=1
//     alert("ok010")
    //Credit Details
			//************* Branch details send to flexgrid   ****************
	   	TextMatrix(flxRowCnt,0)=window.document.frmTrnsMain.txtBatchno.value;
		TextMatrix(flxRowCnt,1)=window.document.frmTrnsMain.txtTranno.value;
		TextMatrix(flxRowCnt,2)=window.document.frmTrans.txtGLcode.value;
		TextMatrix(flxRowCnt,3)=window.document.frmTrans.txtGLname.value;
		TextMatrix(flxRowCnt,4)=window.document.frmTrans.txtAccNo.value;
		TextMatrix(flxRowCnt,5)=window.document.frmTrans.txtAccNm.value;
		Col=6;
		Row=flxRowCnt;
		CellForeColor=52,17,253;
		TextMatrix(flxRowCnt,6)=window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt,9)=window.document.frmTrans.txtCustId.value;
		TextMatrix(flxRowCnt,10)=CrDrMode 
		TextMatrix(flxRowCnt+1,10)=CrDrMode 
		TextMatrix(flxRowCnt,11)=CrDrDesc  
		TextMatrix(flxRowCnt+1,11)=CrDrDesc
		TextMatrix(flxRowCnt,12)='P';
		TextMatrix(flxRowCnt+1,12)='P';
		TextMatrix(flxRowCnt,13)='Pending';
		TextMatrix(flxRowCnt+1,13)='Pending';
		TextMatrix(flxRowCnt,14)=window.document.frmTrans.txtcurrencycode.value;
		TextMatrix(flxRowCnt,15)=strsessionflds[0];
		TextMatrix(flxRowCnt,16)=strsessionflds[8];
		TextMatrix(flxRowCnt,19)=window.document.frmTrans.txtModId.value;
		TextMatrix(flxRowCnt,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt,22)=window.document.frmTrans.txtNarran.value;
	    TextMatrix(flxRowCnt,41)=strsessionflds[2];//Should be replaced with Counter No.
	    TextMatrix(flxRowCnt,42)=strsessionflds[3];   
	    TextMatrix(flxRowCnt,43)="1";
	   	   
 //Debit details 
			
		TextMatrix(flxRowCnt+1,20)=window.document.frmTrans.txtbranchcode.value
		TextMatrix(flxRowCnt+1,14)=window.document.frmTrans.txtcurrencycode.value
		TextMatrix(flxRowCnt+1,15)=strsessionflds[0];
		TextMatrix(flxRowCnt+1,16)=strsessionflds[8];
	  	TextMatrix(flxRowCnt+1,19)="CASH";
		TextMatrix(flxRowCnt+1,7)=window.document.frmTrans.txtClrBal.value;
		TextMatrix(flxRowCnt+1,2)=cashGlCode
		TextMatrix(flxRowCnt+1,3)=cashGldesc;
		TextMatrix(flxRowCnt+1,4)="1";
		TextMatrix(flxRowCnt+1,5)=cashGldesc;
		
		Col=6;
		Row=flxRowCnt+1;
		CellForeColor=210,2,2;
		TextMatrix(flxRowCnt+1,6)='-'+window.document.frmTrans.txtAmt.value;
		TextMatrix(flxRowCnt+1,22)=window.document.frmTrans.txtNarran.value;
		TextMatrix(flxRowCnt+1,9)=window.document.frmTrans.txtCustId.value;
		window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,41)=strsessionflds[2];
        window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,42)=strsessionflds[3];
        window.document.frmTrnsMain.Mfgpaydt.TextMatrix(flxRowCnt+1,43)="1";
        window.document.frmTrnsMain.txtTotCredit.value=0;
        window.document.frmTrnsMain.txtTotDebit.value=0;
        
		window.document.frmTrnsMain.txtTotCredit.value=eval(window.document.frmTrnsMain.txtTotCredit.value)+eval(window.document.frmTrans.txttotal.value);
		window.document.frmTrnsMain.txtTotDebit.value=eval(window.document.frmTrnsMain.txtTotDebit.value)+eval(window.document.frmTrans.txttotal.value);
		window.document.frmTrnsMain.txtDiff.value=eval(window.document.frmTrnsMain.txtTotCredit.value)-eval(window.document.frmTrnsMain.txtTotDebit.value);
		
		{
	    if(window.document.frmTrans.txtModId.value=="LOAN")
	    {
	    //alert("loanfill")
	    
	    funfillloanflex()
	    }
	    }
		
		}
//		alert("ok00")
		precision(window.document.frmTrnsMain.txtTotCredit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtTotDebit,window.document.frmTrans.hpr.value)
		precision(window.document.frmTrnsMain.txtDiff,window.document.frmTrans.hpr.value)
//     alert("ok0")		
	 ModuleClear();//to clear module and thier child fields		 		
	 NoofAcc() 
//	 alert("ok1")
	 funloanclear()
	 
  }		
//--------------------------------------------------------------------------------------
//This function is used to Lock or Unlock controls by sending parameter value as
//"true" or "false".
function LockControls(trueOrfalse)
{
 
 with(window.document.frmTrans)
     {
      cmdBranch.disabled=trueOrfalse
      cmdCurrency.disabled=trueOrfalse
      cmdModuleid.disabled=trueOrfalse
      cmdGlcode.disabled=trueOrfalse
      cmdAccNo.disabled=trueOrfalse
      txtAmt.disabled=trueOrfalse
      txtNarran.disabled=trueOrfalse
      cmdClear.disabled=trueOrfalse
    }  

with(window.document.frames("idenom").frmdm)
     {     
      for(i=0;i<txtpieces.length;i++){
      	  txtpieces[i].disabled=trueOrfalse
		  txtExaPic[i].disabled=trueOrfalse
		}
     }	
//     alert("siv2")	
}
//----------------------------------------------------------------------------------
function modifyStrForm(){
        TranMode();
        
	var strValues=window.document.frmTrans.txtbranchcode.value+"~"+
	              window.document.frmTrans.txtcurrencycode.value+"~"+
		          window.document.frmTrans.txtModId.value+"~"+
		          window.document.frmTrans.txtGLcode.value+"~"+
		          window.document.frmTrans.txtAccNo.value+"~"+
	              window.document.frmTrans.txtCustId.value+"~"+
	              window.document.frmTrans.txtAmt.value+"~"+
	              CrDrMode+"~"+window.frmTrans.txtClrBal.value+"~P~"+
	              window.document.frmTrans.txtNarran.value+"~"+
		          window.document.frmTrnsMain.txtBatchno.value+"~"+
		          window.document.frmTrnsMain.txtTranno.value+"~"+
		          cashGlCode+"~"+window.document.frmTrnsMain.Mfgpaydt.TextMatrix(2,1)+"~"
	
   	return strValues;	
}
//-----------------------------------------------------------------------------------
function AccChange(RowSel){
     with(window.document.frmTrnsMain.Mfgpaydt){ 
     if(window.document.frmTrans.txtbranchcode.value==TextMatrix(RowSel,20)&&
        window.document.frmTrans.txtcurrencycode.value==TextMatrix(RowSel,14)&&
        window.document.frmTrans.txtModId.value==TextMatrix(RowSel,19)&&
        window.document.frmTrans.txtGLcode.value==TextMatrix(RowSel,2)&&
		window.document.frmTrans.txtAccNo.value==TextMatrix(RowSel,4))
		  {
	      accnoChng="false"
          }
      else{
           accnoChng="true"     		 
          }
      }     
  }

//-----------------------------------------------------------------------------------
 function TransMod(msgStatus){
 
 }
//-----------------------------------------------------------------------------------
 function RecPayLmt(){
      var str="";
      with(window.document.frmTrans){
           str="RPLMT"+"~"+txtbranchcode.value+"~"+
                  txtcurrencycode.value+"~"+
                  strsessionflds[0]
           window.open("minBalChk.asp?strparam="+str,"RecPayLmt","width=1% height=1% left=1 top=1");       
      
      }
 }
//-----------------------------------------------------------------------------------
 function RecLimit(vRLmt){
  var RcptLmt="";
      RcptAmt=vRLmt.split("~");
      MaxRcptAmt=RcptAmt[0]
  }
//-----------------------------------------------------------------------------------
 function RecLmtChk()
 {   {
     if(eval(window.document.frmTrans.txtAmt.value)>eval(MaxRcptAmt)){
       alert("Cashier "+strsessionflds[0]+ " " + "cannot receive more than " +MaxRcptAmt);
       window.document.frmTrans.txtAmt.value="";
       return
       }
     }
     
     {
     if(eval(window.document.frmTrans.txtAmt.value)<1)
     {
     return
     }
     }
     
     {
     if(window.document.frmTrans.txtModId.value=="LOAN")
     {
     //alert("ok")
     funinsertintdtls()
     }
     }  
 }
//-----------------------------------------------------------------------------------
function testing()
{
//window.document.all['iloandtls'].style.display="block"
//window.document.all['iloandtls'].
//alert("ok")
alert(window.document.frames("iloandtls").frmloaninterestdetails.txtprincipalamt.value)
//window.document.all['Denom'].style.display="none";
//window.document.all['iloandtls'].style.display="none";
//alert(window.document.frames("iloandtls").frmloaninterestdetails.txtintamt.value)
//window.document.frmTrnsMain.Mfgpaydt.FormatString=window.document.frmTrnsMain.Mfgpaydt.FormatString+"|xxx"
//alert(window.document.frmTrnsMain.Mfgpaydt.TextMatrix(0,43)) 
//alert(window.document.frmTrans.mfgTranslog
//alert(window.document.frmTrans.mfgTranslog.TextMatrix(0,33))
//alert(window.document.frmTrans.hpr.value)
//window.document.frames("iloandtls").frmloaninterestdetails.txtintpending.value='YNK'
//alert(window.document.all['iloandtls'].frmloaninterestdetails.txtintpending.value)
//alert(window.document.frames("iloandtls").frmloaninterestdetails.txtintpending.value)
}
</script>
<SCRIPT LANGUAGE=javascript FOR=mfgTranslog EVENT=dblClick>
<!--
 flexClick();
//-->
</SCRIPT>
</script>
</script>
<SCRIPT LANGUAGE=javascript FOR=Mfgpaydt EVENT=DblClick>
<!--
 Mfgpaydt_DblClick()
//------------------------------------------------------------------------------------------>
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();NatBranch();cashMode();Denom();Flex();RecPayLmt()">

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmTrans">
  <%if ucase(CshType)="Y" then%>

  <table width="100%" cellspacing="0" cellpadding="0" height="400" class="tablebordermain">
    <tbody>
      <tr>
        <td width="100%" valign="top">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="89%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%" height="28"><img border="0" height="22" name="placeholder" src="transparent.gif" width="1"></td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="34%" height="25"></td>
                <td width="33%" height="25">
                <p align="center"><font class="text">Cash Receipts</font></td>
                <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <table align="center" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td height="15"><font class="textblue">
            <p align="center"><%=Request.QueryString("record")%></font></td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0" height="27">
          <tr class="bgcolor">
            <td width="89" height="27"><font class="textbold">Branch Code</font></td>
            <td width="341" height="27"><input name="txtbranchcode" size="9" readonly><input type="button" value=" L " name="cmdBranch" onclick="Tellerbranch()"><input name="txtbranchdesc" size="16" readonly class="bgcolor1"></td>
            <td width="184" align="right" height="27"><font class="textbold">Currency Code</font></td>
            <td width="262" height="27" align="right"><input name="txtcurrencycode" size="9" readonly><input type="button" value=" L " name="cmdCurrency" onclick="curr()"><input name="txtcurrencydesc" size="16" readonly style="background-color: #B3A597; color: #FFFFFF" color="white"></td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="47%" height="10" valign="top"></td>
            <td width="55%" valign="top" height="10"></td>
          </tr>
          <tr>
            <td width="47%" rowspan="3" valign="top">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="23%" height="26">&nbsp;Module ID</td>
                <td width="79%" height="26" colspan="2"><input name="txtModId" size="11" readonly><input type="button" value=" L " name="cmdModuleid" onclick="Tellermodule()"><input name="txtModNm" size="14" readonly></td>
              </tr>
              <tr>
                <td width="23%" height="26">&nbsp;GL Code</td>
                <td width="79%" height="26" colspan="2"><input name="txtGLcode" size="11" readonly><input type="button" value=" L " name="cmdGlcode" onclick="Glcode()"><input name="txtGLname" size="14" readonly></td>
              </tr>
              <tr>
                <td width="23%" height="26">&nbsp;Acc. No</td>
                <td width="79%" height="26" colspan="2"><input name="txtAccNo" size="11" readonly><input type="button" value=" L " name="cmdAccNo" onclick=" AccCode()"><input name="txtAccNm" size="14" readonly></td>
              </tr>
              <tr>
                <td width="23%" height="26">&nbsp;Amount</td>
                <td width="100%" height="26" colspan="2"><input name="txtAmt" size="18" onkeypress="numdec(window.document.frmTrans.txtAmt.value)" onblur="precision(window.document.frmTrans.txtAmt,window.document.frmTrans.hpr.value);RecLmtChk()" style="TEXT-ALIGN: right"></td>
              </tr>
              <tr>
                <td width="23%" height="26">&nbsp;Narration</td>
                <td width="79%" height="26" colspan="2"><input name="txtNarran" size="30"></td>
              </tr>
              <tr>
                <td width="23%" height="26">&nbsp;</td>
                <td width="34%" height="26"><span id="bal" align="left"><input type="checkbox" name="balChk" onclick="balDisplay()" value="ON">&nbsp;<b><font face="MS Sans Serif" size="1">Account
                Details</font></b></span></td>
                <td width="66%" height="26"><input type="checkbox" name="chkTrandtls" onclick="transDisp()" value="ON">
                <font face="MS Sans Serif" size="1"><b><span id="bal0" align="left">Trans
                Details</span></b></font></td>
              </tr>
              <tr>
                <td width="123%" height="26" colspan="3"></td>
              </tr>
              <tr>
                <td width="123%" height="26" colspan="3">
                <div id="dtemp" style="DISPLAY: none">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%"><center>
                      <object align="left" classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="70" id="mfgTranslog" name="Mfgpaydt" style="DISPLAY: block; LEFT: 7px; POSITION: absolute; TOP: 270px" width="302" codebase="http://comserver/smartver3/cash/msflxgrd.ocx" viewastext>
                        <param name="_ExtentX" value="7990">
                        <param name="_ExtentY" value="1852">
                        <param name="_Version" value="393216">
                        <param name="Rows" value="1">
                        <param name="Cols" value="23">
                        <param name="FixedRows" value="1">
                        <param name="FixedCols" value="0">
                        <param name="RowHeightMin" value="0">
                        <param name="BackColor" value="-2147483643">
                        <param name="ForeColor" value="-2147483640">
                        <param name="BackColorFixed" value="-2147483633">
                        <param name="ForeColorFixed" value="-2147483630">
                        <param name="BackColorSel" value="-2147483635">
                        <param name="ForeColorSel" value="-2147483634">
                        <param name="BackColorBkg" value="8421504">
                        <param name="GridColor" value="12632256">
                        <param name="GridColorFixed" value="0">
                        <param name="WordWrap" value="0">
                        <param name="Redraw" value="-1">
                        <param name="AllowBigSelection" value="-1">
                        <param name="ScrollTrack" value="0">
                        <param name="Enabled" value="-1">
                        <param name="RightToLeft" value="0">
                        <param name="TextStyle" value="0">
                        <param name="TextStyleFixed" value="0">
                        <param name="FocusRect" value="1">
                        <param name="HighLight" value="1">
                        <param name="FillStyle" value="0">
                        <param name="GridLines" value="1">
                        <param name="GridLinesFixed" value="2">
                        <param name="ScrollBars" value="3">
                        <param name="SelectionMode" value="0">
                        <param name="MergeCells" value="0">
                        <param name="AllowUserResizing" value="0">
                        <param name="PictureType" value="0">
                        <param name="BorderStyle" value="1">
                        <param name="Appearance" value="1">
                        <param name="MousePointer" value="0">
                        <param name="GridLineWidth" value="1">
                        <param name="FormatString" value="&gt;Batch No  |&gt;Tran No   |&lt;GlCode        |&lt;Gl Description                   |&gt;Acc No         |&gt;Amount            |&gt;Entered Time Bal |^Application Date   |&lt;Cust Id               |&lt;Mode of Tran  |&lt;Status  |&gt;Currency Code     |&lt;Entered By             |&lt;Enterd M/c             |&lt;Approved By               |&lt;Approved M/c         |&lt;Module Id         |&lt;Branch Code            |&gt;Token No   |&lt;Remarks                           ">
                        <param name="OLEDropMode" value="0">
                      </object>
                      </center></td>
                    </tr>
                    <tr>
                      <td width="100%">
                      <p align="center"><br>
                      <br>
                      <br>
                      <input type="button" value="Refresh" name="B7" style="RIGHT: 300px; TOP: 320px" onclick="TempTranslog()"><input type="button" value=" Delete " name="B6" style="RIGHT: 300px" onclick="flexClick()"></p>
                      </td>
                    </tr>
                  </table>

                </div>
                
                <IFRAME id="iloandtls" align=center frameBorder=0 frameSpacing=0 height=100 noResize        
            src="loaninterestdetails.asp" 
            style="BACKGROUND-COLOR: darkred;  HEIGHT: 140px; LEFT: 
            0px; TOP: 0px" 
            width=318 valign="top"></IFRAME>
            
                </td>
              </tr>
              <tr>
                <td width="123%" height="20" colspan="3">
                <div id="remcr" style="DISPLAY:none;HEIGHT: 100px; LEFT: 2px; POSITION: absolute; TOP: 260px; WIDTH: 429px">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%">

                      <table style="height: 120px" width="308" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="304">

                          <table border="0" width="100%" cellspacing="0" cellpadding="0" height="131">
                            <tr>
                              <td width="42%" height="25"><font class="textsmall">Issued
                              on Bank</font></td>
                              <td width="75%" colspan="2" height="25"><input name="txtissbnkcode" size="9"><input type="button" value=" L " name="cmdissbnl" onclick="issbank()"><input name="txtissbnkdesc" size="15"></td>
                            </tr>
                            <tr>
                              <td width="42%" height="25"><font class="textsmall">Issuedon
                              Branch</font></td>
                              <td width="75%" colspan="2" height="25"><input name="txtissbrcode" size="9"><input type="button" value=" L " name="cmdissbrl" onclick="issbrnch()"><input name="txtissbrdesc" size="15"></td>
                            </tr>
                            <tr>
                              <td width="42%" height="23"><font class="textsmall">Commission</font></td>
                              <td width="24%" height="23"><input name="txtcomm" size="9" onkeypress="numdec(window.document.frmTrans.txtcomm.value)" onblur="precision(window.document.frmTrans.txtcomm,window.document.frmTrans.hpr.value)"></td>
                              <td width="49%" height="23"></td>
                            </tr>
                            <tr>
                              <td width="42%" height="23"><font class="textsmall">Favouring</font></td>
                              <td width="75%" colspan="2" height="23"><input name="txtfavg" size="29"></td>
                            </tr>
                            <tr>
                              <td width="42%" height="25"><font class="textsmall">Cust. ID</font></td>
                              <td width="75%" colspan="2" height="25"><input name="txtcustrid" size="9"><input type="button" value=" L " name="cmdcul" onclick="customerscreen(txtcusn)"><input name="txtcusn" size="15"></td>
                            </tr>
                          </table>

                          </td>
                        </tr>
                      </table>

                      </td>
                    </tr>
                  </table>

                </div>
                </td>
              </tr>
            </table>

            </td>
            <td width="55%" valign="top">
            <div id="trnsfer" style="DISPLAY: none; HEIGHT: 120px; LEFT: 321px; POSITION: absolute; TOP: 110px; WIDTH: 449px">

              <table align="right" cellpadding="0" cellspacing="0" class="tablebordermain">
                <tr>
                  <td>

                  <table border="0" align="right" cellpadding="0" cellspacing="0" style="HEIGHT: 100px" width="425">
                    <tr>
                      <td width="92"><font class="textsmall">&nbsp; Clear Bal</font></td>
                      <td width="100"><input name="txtClrBal" readonly size="18" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-FAMILY: ; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                      <td width="96"><font class="textsmall">&nbsp;Unclear Bal</font></td>
                      <td width="96"><input name="txtUnClrBal" readonly size="15" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                    </tr>
                    <tr>
                      <td width="130"><font class="textsmall">&nbsp; Net Bal</font></td>
                      <td width="119"><input name="txtNetBal" onkeypress="numeric()" readonly size="18" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold; TEXT-ALIGN: right"></td>
                      <td width="140"><font class="textsmall">Oper. Instr.</font></td>
                      <td width="99"><input name="txtOpInstr" readonly size="15" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold"></td>
                    </tr>
                    <tr>
                      <td width="130"><font class="textsmall">&nbsp; Oper. by</font></td>
                      <td width="314" colspan="3"><input name="txtOpaBy" readonly size="30" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="130" height="0"><font class="textsmall">&nbsp; Cust ID</font></td>
                      <td width="119" colspan="3" height="0"><input name="txtCustId" readonly size="30" style="BACKGROUND-COLOR: #c7ba95; BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300; FONT-WEIGHT: bold"></td>
                    </tr>
                  </table>

                  </td>
                </tr>
              </table>

            </div>
            <div id="Denom" style="HEIGHT: 120px; LEFT: 320px; POSITION: absolute; TOP: 99px; WIDTH: 449px">

              <IFRAME id="idenom" align=center frameBorder=0 frameSpacing=0 height=200 noResize        
            src="cashdenomRcpt.asp" 
            style="BACKGROUND-COLOR: darkred; HEIGHT: 250px; LEFT: 
            0px; TOP: 0px" 
            width=450 valign="top"></IFRAME>
              <p align="center"><font class="textboldblack"><strong><font class="textred">*&nbsp;</font>
              Available&nbsp;Amount&nbsp;</font>&nbsp;<input name="txtavtotal" size="15" style="TEXT-ALIGN: right" value="0.00" readonly>&nbsp;<font class="textred">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              Total : </font></strong><input name="txttotal" size="12" value="0.00" maxlength="15" style="TEXT-ALIGN: right" readonly></p>
            </div>
            </td>
          </tr>
          <tr>
            <td width="55%" valign="top"></td>
          </tr>
          <tr>
            <td width="55%" valign="top"></td>
          </tr>
        </table>

        </td>
      </tr>
    </tbody>
    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" valign="top" height="5"></td>
        </tr>
        <tr>
          <td>
          <div align="center">
            <center>

            <table class="tablebordermain" width="10%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" align="middle">
                <p align="center"><input type="button" value="   Ok   " name="cmdOk" onclick="frmSub()" class="bgcolor"><input type="button" value=" Clear " name="cmdClear" onclick="cashMode();denomClear();funloanclear()" class="bgcolor"></p>
                </td>
              </tr>
            </table>

            </center>
          </div>
      </table>

      <input type="hidden" name="hpr">
      <%else%>
  <script language="javascript">
   location.replace("cashmodule.asp")
      alert("This user cannot Receive Cash")
  </script>
      <%end if%>
      <input type="hidden" name="hdloandetails" id="hdloandetails">
      </form>
      <form name="frmTrnsMain" action>
        <%if ucase(CshType)="Y" then%>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%"><input type="hidden" name="DemonValue"><input type="hidden" name="DenomType"><input type="hidden" name="PaidAmt"><input type="hidden" name="ExchgAmt">

            <table align="center">
              <tr>
                <td><center>
                <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="132" id="Mfgpaydt" name="Mfgpaydt" style="HEIGHT: 132px; LEFT: 1px; TOP: 1px; WIDTH: 759px" width="627">
                  <param name="_ExtentX" value="20082">
                  <param name="_ExtentY" value="3493">
                  <param name="_Version" value="393216">
                  <param name="Rows" value="1">
                  <param name="Cols" value="49">
                  <param name="FixedRows" value="1">
                  <param name="FixedCols" value="0">
                  <param name="RowHeightMin" value="0">
                  <param name="BackColor" value="-2147483643">
                  <param name="ForeColor" value="-2147483640">
                  <param name="BackColorFixed" value="-2147483633">
                  <param name="ForeColorFixed" value="-2147483630">
                  <param name="BackColorSel" value="-2147483635">
                  <param name="ForeColorSel" value="-2147483634">
                  <param name="BackColorBkg" value="8421504">
                  <param name="GridColor" value="12632256">
                  <param name="GridColorFixed" value="0">
                  <param name="WordWrap" value="0">
                  <param name="Redraw" value="-1">
                  <param name="AllowBigSelection" value="-1">
                  <param name="ScrollTrack" value="0">
                  <param name="Enabled" value="-1">
                  <param name="RightToLeft" value="0">
                  <param name="TextStyle" value="0">
                  <param name="TextStyleFixed" value="0">
                  <param name="FocusRect" value="1">
                  <param name="HighLight" value="1">
                  <param name="FillStyle" value="0">
                  <param name="GridLines" value="1">
                  <param name="GridLinesFixed" value="2">
                  <param name="ScrollBars" value="3">
                  <param name="SelectionMode" value="0">
                  <param name="MergeCells" value="0">
                  <param name="AllowUserResizing" value="0">
                  <param name="PictureType" value="0">
                  <param name="BorderStyle" value="1">
                  <param name="Appearance" value="1">
                  <param name="MousePointer" value="0">
                  <param name="GridLineWidth" value="1">
                  <param name="FormatString" value="&gt;Batch No  |&gt;Tran No   |&lt;GlCode        |&lt;Gl Description                   |&gt;Acc No         |&lt;Name                           |&gt;Amount            |&gt;Entered Time Bal |^Application Date   |&lt;Cust Id               | |&lt;Mode of Tran  ||&lt;Status  |&gt;Currency Code     |&lt;Entered By             |&lt;Enterd M/c             |&lt;Approved By               |&lt;Approved M/c         |&lt;Module Id         |&lt;Branch Code            |&gt;Token No   |&lt;Remarks                           |&lt;Cheque Series  |&gt;Cheque No             |^Cheque Date   |&lt;Cheque Favouring         | | | | | | | | | | | | | | |&gt;Counter No.  |&lt;Cashier Id.          |&gt;Scroll No.  |                 |            |          |               |           ">
                  <param name="OLEDropMode" value="0">
                </object>
                </center></td>
              </tr>
            </table>

            <table border="0" width="764" cellspacing="0" cellpadding="0">
              <tr>
                <td width="120" height="25">&nbsp;&nbsp; &nbsp;Dr. Transactions:</td>
                <td width="17"><input name="NoDrTrn" size="1" style="BACKGROUND-COLOR: white; COLOR: red; WIDTH: 20px" readonly value="0" width="20"></td>
                <td width="138" height="25">&nbsp;&nbsp;&nbsp;&nbsp; Cr.
                Transactions:&nbsp;<input name="NoCrTrn" size="1" readonly style="COLOR: blue; WIDTH: 20px" value="0" width="20"></td>
                <td width="38" height="25" align="right"><font size="2" face="MS Sans Serif" color="#000000">Total&nbsp;</font></td>
                <td width="286" height="25"><input name="txtTotCredit" size="18" style="BACKGROUND-COLOR: white; COLOR: blue; TEXT-ALIGN: right" value="0.00" readonly><input name="txtTotDebit" size="18" maxlength="13" style="COLOR: red; TEXT-ALIGN: right" value="0.00" readonly></td>
                <td width="61" height="25">Difference</td>
                <td width="90" height="25"><input name="txtDiff" size="11" style="COLOR: blue; TEXT-ALIGN: right" value="0.00" maxlength="15" readonly></td>
              </tr>
              <tr>
                <td width="279" colspan="3" height="10"></td>
                <td width="389" colspan="3" height="10"></td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">
                <div align="center">
                  <center>

                  <table border="0" width="35%" cellspacing="0" cellpadding="0" class="tablebordermain">
                    <tr>
                      <td width="100%"><input type="button" value="  Post  " name="cmdPost" class="bgcolor" color="white" onclick="SubPost()"><input type="button" value="Modify" name="cmdmodify" style="color=" white" onclick="testing()" " class="bgcolor"><input type="button" value="Delete" name="B10" style="color=" white"" class="bgcolor"><input type="button" value="Cancel" name="B7" onclick="DelTran();Cancel()" style="color=" white"" class="bgcolor"><input type="button" value="   Exit   " name="cmdExit" onclick="location.replace(&quot;cashmodule.asp&quot;)" style="color=" white"" class="bgcolor"></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <input type="hidden" name="txtGridStr">

<SCRIPT LANGUAGE=javascript>
</SCRIPT>
        <input type="hidden" name="txtBatchno"><input type="hidden" name="txtTranno"><input type="hidden" name="appDt"><input type="hidden" name="hdntxtBal"><input type="hidden" name="txtSessionflds" value="<%=vUserid&"~"&vAppdate&"~"&vCounterno&"~"&vCashierid&"~"&vBranchCode&"~"&vBrnarration&"~"&vCurCode&"~"&vCurnarration&"~"&vMachineId&"~"%>"><input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
        <%else%>
<script language="javascript">
  location.replace("cashmodule.asp")
  alert("This user cannot Receive Cash")
</script>
        <%end if%>

      </form>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="90%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.asp">
            </iframe>
            </td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
  </table>

</body>

</html>
