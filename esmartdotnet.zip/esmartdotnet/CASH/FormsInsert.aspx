<%@ Page Language="vb" CodeBehind="FormsInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.FormsInsert" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<%
'''''****************Declaring Variables ***************

Dim Objfrm,vark,str
Dim  ArrTran(0,4)
str=Request.Form("hadd")
vark=split(str,"|")
dim varx
dim icount
if len(str)>0 then

			if Request.Form("hok")="userid" then
						StrTabName="GENUSERIDFORMSMST"   
						StrFldNames="userid,moduleid,branchcode,forms,status"
			   for icount=1 to vark(4)
			     varx=vark(icount+4)
			     StrUpCondition=" branchcode='"& cstr(vark(1)) &"' and userid='"& cstr(vark(2)) &"' and moduleid='"& cstr(vark(3))&"'"
			     StrCondition=" branchcode='"& cstr(vark(1)) &"' and userid='"& cstr(vark(2)) &"' and moduleid='"& cstr(vark(3))&"' and forms='"& cstr(varx) &"'" & "|"
			     StrFldValues="'" & cstr(vark(2)) &"','"& cstr(vark(3)) &"','" & cstr(vark(1)) &"','"& cstr(varx)&"','P'" & "|"
			   	 stflds=stflds &	StrFldValues 
			  	 StrCond=StrCond & StrCondition
			   next
				 stflds=left(stflds,len(stflds)-1)
				 StrCond=left(StrCond,len(StrCond)-1)
  
	             Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")

			if vark(0)="add" then
					ArrTran(0,0)="I"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=StrFldNames	
					ArrTran(0,3)=stflds	
					ArrTran(0,4)=""	
					StrMsg= Objfrm.DataTransactions(ArrTran)
					Set Objfrm=nothing
					Response.Redirect "workallotment.asp?record=" & StrMsg			
			elseif vark(0)="delete" then
					ArrTran(0,0)="D"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=""				
					ArrTran(0,3)=""				
					ArrTran(0,4)=StrCond
					StrMsg= Objfrm.DataTransactions(ArrTran)
					Set Objfrm=nothing
					Response.Redirect "workallotment.asp?record=" & Strmsg
			end if
		
		if vark(0)="modify" then
		        ArrTran(0,0)="D"			
				ArrTran(0,1)=StrTabName		
				ArrTran(0,2)=""				
				ArrTran(0,3)=""				
				ArrTran(0,4)=StrUpCondition
				StrMsg= Objfrm.DataTransactions(ArrTran)
		        set objfrm=nothing
		        
		         
                Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
                ArrTran(0,0)="I"			
				ArrTran(0,1)=StrTabName		
				ArrTran(0,2)=StrFldNames	
				ArrTran(0,3)=stflds	
				ArrTran(0,4)=""			
		
		        StrMsg= Objfrm.DataTransactions(ArrTran)
	            Set Objfrm=nothing
	            Response.Redirect "workallotment.asp?record=" & StrMsg
        end if

  elseif Request.Form("hok")="groupid" then
		StrTabName="gengroupformsmst"   
		StrFldNames="groupcode,moduleid,branchcode,forms,status"
		
        for icount=1 to vark(4)
          varx=vark(icount+4)
          StrCondition=" branchcode='"& cstr(vark(1)) &"' and Groupcode='"& cstr(vark(2)) &"' and moduleid='"& cstr(vark(3))&"' and forms='"& cstr(varx) &"'" & "|"
          StrFldValues="'" & cstr(vark(2)) &"','"& cstr(vark(3)) &"','" & cstr(vark(1)) &"','"& cstr(varx)&"','P'" & "|"
       	  stflds=stflds &	StrFldValues 
       	  StrCond=StrCond & StrCondition
        next
		  stflds=left(stflds,len(stflds)-1)
		  StrCond=left(StrCond,len(StrCond)-1)
 	      Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")


			if vark(0)="add" then
					ArrTran(0,0)="I"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=StrFldNames	
					ArrTran(0,3)=stflds	
					ArrTran(0,4)=""				
				    StrMsg= Objfrm.DataTransactions(ArrTran)
	                Set Objfrm=nothing
	                Response.Redirect "workallotment.asp?record=" & StrMsg
				elseif vark(0)="delete" then
					ArrTran(0,0)="D"			
					ArrTran(0,1)=StrTabName		
					ArrTran(0,2)=""				
					ArrTran(0,3)=""				
					ArrTran(0,4)=StrCond	
				    StrMsg= Objfrm.DataTransactions(ArrTran)
	                Set Objfrm=nothing
	                Response.Redirect "workallotment.asp?record=" & Strmsg

			end if
							
		if  vark(0)="modify" then
			Response.Write str 
			StrUpCondition=" branchcode='"& cstr(VARk(1)) &"' and groupcode='"& cstr(vark(2)) &"' and moduleid='"& cstr(vark(3))&"'"
			Response.Write StrUpCondition
			Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")

			ArrTran(0,0)="D"			
			ArrTran(0,1)=StrTabName		
			ArrTran(0,2)=""				
			ArrTran(0,3)=""				
			ArrTran(0,4)=StrUpCondition	
			StrMsg= Objfrm.DataTransactions(ArrTran)
            set objfrm=nothing
             
			Set Objfrm=SERVER.CreateObject("GeneralTransactions.DBTransactions")
			ArrTran(0,0)="I"			
			ArrTran(0,1)=StrTabName		
			ArrTran(0,2)=StrFldNames	
			ArrTran(0,3)=stflds	
			ArrTran(0,4)=""				
			StrMsg= Objfrm.DataTransactions(ArrTran)
			Set Objfrm=nothing
			Response.Redirect "workallotment.asp?record=" & StrMsg
	      end if
      end if
else
			StrMsg="Fields does not empty"
			Response.Redirect "workallotment.asp?record=" & Strmsg
end if
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
