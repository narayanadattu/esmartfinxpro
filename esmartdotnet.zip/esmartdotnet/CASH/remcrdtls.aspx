<%@ Page CodeBehind="remcrdtls.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.remcrdtls" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="trnClear.js"></SCRIPT>
<script language="Javascript">
//<title>New Page 1</title>
function issbank(){
if (issonbnk==""){
st="issonbnk";
  window.open("List.asp" + "?"+"st="+st,st,"width=200%,height=150% left=100 top=170");
}
 }
 function issuedonbnk(str){

var k
    k=str.split("-----")
    window.document.frmloaninterestdetails.txtissbnkcode.value =k[1]
    window.document.frmloaninterestdetails.txtissbnkdesc.value =k[0]
}
 
 
 
</script>
<title></title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmloaninterestdetails">

  <table border="0" width="780" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">

      <table style="height: 120px" width="308" cellspacing="0" cellpadding="0" class="tablebordermain">
        <tr>
          <td width="304">

          <table border="0" width="100%" cellspacing="0" cellpadding="0" height="131">
            <tr>
              <td width="42%" height="25"><font class="textsmall">Issued on Bank</font></td>
              <td width="75%" colspan="2" height="25"><input name="txtissbnkcode" size="9"><input type="button" value=" L " name="cmdissbnl" onclick="issbank()"><input name="txtissbnkdesc" size="15"></td>
            </tr>
            <tr>
              <td width="42%" height="25"><font class="textsmall">issuedon branch</font></td>
              <td width="75%" colspan="2" height="25"><input name="txtissbrcode" size="9"><input type="button" value=" L " name="cmdissbrl" onclick="issbrnch()"><input name="txtissbrdesc" size="15"></td>
            </tr>
            <tr>
              <td width="42%" height="23"><font class="textsmall">Commission</font></td>
              <td width="24%" height="23"><input name="txtcomm" size="9" onkeypress="numdec(window.document.frmTrans.txtcomm.value)" onblur="precision(window.document.frmTrans.txtcomm,window.document.frmTrans.hpr.value)"></td>
              <td width="49%" height="23"></td>
            </tr>
            <tr>
              <td width="42%" height="23"><font class="textsmall">Favouring</font></td>
              <td width="75%" colspan="2" height="23"><input name="txtfavg" size="29"></td>
            </tr>
            <tr>
              <td width="42%" height="25"><font class="textsmall">Cust. ID</font></td>
              <td width="75%" colspan="2" height="25"><input name="txtcustrid" size="9"><input type="button" value=" L " name="cmdcul" onclick="customerscreen(txtcusn)"><input name="txtcusn" size="15"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

</form>

</body>

</html>
