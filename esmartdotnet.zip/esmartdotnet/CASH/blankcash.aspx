<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="blankcash.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.blankcash" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title></title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmmasters">

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tbody>
    </tbody>
  </table>

</form>

</body>

</html>
