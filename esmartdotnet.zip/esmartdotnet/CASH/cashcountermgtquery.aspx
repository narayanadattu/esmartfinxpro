<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashcountermgtquery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashcountermgtquery" %>
<%
kstr=Request.Form("hFlds")
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{
  var kstr
  kstr= window.document.frmacc.hbno.value
  if(kstr)
  {
   window.attachEvent(window.parent.Countermgtdts(kstr))
  window.close()
  } 
}
//-->
</SCRIPT>
<%
  dim rs,obj,rec,cnt,acc,CounterNo
 if len(kstr)> 0 then
 Response.Write (kstr)
  strFlds=split(kstr,"~")
  alloamt=split(strFlds(0),"*")
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
   rs=server.CreateObject("adodb.recordset")
 if ubound(strFlds)<2 then
  
 
  
 if strFlds(1)="CounterDetails" then
	 rs=obj.singleRecordSet("cashcountermst C", _
	"C.maxcashlimit," & _
	"C.paymentlimit,C.receiptlimit", _
	"C.branchcode='" & alloamt(0) & "' and " & _
	"upper(C.currencycode)='" & ucase(trim(alloamt(1))) & "' and " & _
	"C.counterno=" & alloamt(2) & "")
	
	'if 1=2 then
	if not rs.EOF and not rs.bof then
			rs.MoveFirst
			for i=0 to rs.Fields.Count - 1
				  acc=acc &"*"& rs(i).value
			next
			acc=acc & "~" & strFlds(1)
	end if
	'end if

'''for cashcountmgt form selected cashiertype is whether teller or receipts or
''' teller recipts or teller payaments 
elseif strFlds(1)="checkCashier" then
 rs=obj.singleRecordSet("CASHCASHIERTYPEMST", _
	"RECEIPTSYN,PAYMENTSYN,TELLERRECEIPTSYN,TELLERPAYMENTSYN", _
	"branchcode='" & alloamt(0) & "' and " & _
	"upper(currencycode)='" & ucase(trim(alloamt(1))) &"' and " & _
	"CASHIERTYPEID='" & ucase(trim(alloamt(2))) &"' and status='R'")
	Response.Write ( "branchcode='" & alloamt(0) & "' and " & _
	"upper(currencycode)='" & ucase(trim(alloamt(1))) &"' and " & _
	"CASHIERTYPEID='" & ucase(trim(alloamt(2))) &"' and status='R'" & "<br>" )
	acc=""
	'if 1=2 then
	if not rs.EOF and not rs.bof then
			rs.MoveFirst
			for i=0 to rs.Fields.Count - 1
				  acc=acc & rs(i).value & "*"
			next
			acc=acc & "~" & strFlds(1)
	end if
	Response.Write (acc & "ok"&  "<br>")
	'end if
	''''for counter closing cashier details fetching from cashcountermst
elseif strFlds(1)="closeCounterDetails" then

	 rs=obj.singleRecordSet("cashcountermst C,CASHCASHIERTYPEMST b,GENUSERMST u", _
	"C.maxcashlimit," & _
	"C.paymentlimit,C.receiptlimit,c.CASHIERTYPEID,b.NARRATION,c.narration,u.name", _
	"C.branchcode='" & alloamt(0) & "' and " & _
	"upper(C.currencycode)='" & ucase(trim(alloamt(1))) & "' and " & _
	"C.counterno='" & alloamt(2) & "' and b.branchcode='" & alloamt(0) & "' and " & _
	"b.currencycode='" & ucase(trim(alloamt(1))) & "' and b.CASHIERTYPEID=c.CASHIERTYPEID and " & _
	"c.COUNTERSTATUS='O' and u.branchcode='" & alloamt(0) & "' and " & _
	"upper(trim(u.userid))='" & ucase(trim( alloamt(3))) & "'")
	acc=""	
	Response.Write ( "cashcountermst C,CASHCASHIERTYPEMST b,GENUSERMST u" & "<br>" )
	Response.Write ( "C.maxcashlimit," & _
	"C.paymentlimit,C.receiptlimit,c.CASHIERTYPEID,b.NARRATION,c.narration,u.name" & "<br>" )
	Response.Write ( "C.branchcode='" & alloamt(0) & "' and " & _
	"upper(C.currencycode)='" & ucase(trim(alloamt(1))) & "' and " & _
	"C.counterno='" & alloamt(2) & "' and b.branchcode='" & alloamt(0) & "' and " & _
	"b.currencycode='" & ucase(trim(alloamt(1))) & "' and b.CASHIERTYPEID=c.CASHIERTYPEID and " & _
	"c.COUNTERSTATUS='O' and u.branchcode='" & alloamt(0) & "' and " & _
	"upper(trim(u.userid))='" & ucase(trim( alloamt(3))) & "'")
	'if 1= 2 then
	'if not rs.EOF and not rs.bof then
	if rs.RecordCount>0 then
			rs.MoveFirst
			for i=0 to rs.Fields.Count - 1
				  acc=acc &"*"& rs(i).value
			next
			acc=acc & "~" & strFlds(1)
	else
		acc=acc & "~" & strFlds(1)		
	end if
	'end if
 elseif strFlds(1)="Cashier" then
 
	' Rs=obj.singlerecordset("GENUSERMST","GROUPID,GROUPNAME",  _ 
						'"trim(branchcode)='" & trim(alloamt(0)) & "' and " & _
						'"trim(userid)='" & alloamt(1) &"'")
	'if rs.RecordCount<>0 then
		 rscount=obj.singleRecordSet("cashcountermst C", _
		"c.CASHIERTYPEID,(select NARRATION from CASHCASHIERTYPEMST " & _
		" where CASHIERTYPEID=c.CASHIERTYPEID and branchcode='"&ucase(trim(alloamt(0)))&"' and " & _
		"currencycode='"&ucase(trim(alloamt(2)))&"'),nvl(C.maxcashlimit,0)," & _
		"nvl(C.paymentlimit,0),nvl(C.receiptlimit,0),c.counterno,c.narration," & _
		"nvl(C.TELLERPAYMENTLIMIT,0),nvl(C.TELLERRECEIPTLIMIT,0)", _
		"upper(C.cashierid)='" & alloamt(1) & "' AND C.branchcode='" & alloamt(0) & "' and " & _
		"upper(C.currencycode)='" & ucase(trim(alloamt(2))) & "'")
		'"C.counterno=" & alloamt(2) &""
 
		if not rscount.EOF and not rscount.bof then
				'acc=acc & rs(0) &"*"& rs(1)
			for i=0 to rscount.Fields.Count - 1
				  acc=acc & rscount(i).value & "*"
			next
			acc=acc & "~" & strFlds(1)
		end if
		
	'end if
	'''for cashiertype for inserting in cash countermgt form
	elseif strFlds(1)="typeCashier" then
 
	 Rs=obj.singlerecordset("GENUSERMST","GROUPID,GROUPNAME",  _ 
						"trim(branchcode)='" & trim(alloamt(0)) & "' and " & _
						"trim(userid)='" & alloamt(1) & "'")
	if rs.RecordCount<>0 then
		
			for i=0 to rs.Fields.Count - 1
				  acc=acc &"*"& rs(i).value
			next
			acc=acc & "~" & strFlds(1)
		
	end if		
 end if
 Response.Write ( acc & "kkk" )
elseif ubound(strFlds)>2 then

		if 	strFlds(4)="DescDisplay" then
		 RecGen=Obj.SingleRecordset(cstr(strFlds(0)),cstr(strFlds(1)),cstr(strFlds(2)))
		 
		 'response.write("<br><br>table= " + cstr(strFlds(0)))
		 'response.write("<br><br> " + cstr(strFlds(1)))
		 'response.write("<br><br> " + cstr(strFlds(2)))
		 'response.end
		 
					if not RecGen.BOF or not RecGen.EOF then
						for i=0 to RecGen.Fields.Count-1
							acc=acc &  recgen(i).value & "|"
						next
					else
					acc= "No|"	
					end if
					acc=acc & "~" & strFlds(3)	
					
		end if
''' for Date checjking in cashierwise report form 
		if 	strFlds(4)="DateDisplay" then
			if datediff("d",strFlds(2),session("applicationdate"))<0 then
			''' checking the passed issue date is greater than  currentdate
					acc="NotValid|"
			end if	
					acc=acc & "~" & strFlds(3)	
					
		end if
end if
end if 			
Response.Write ( acc )
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=acc%>">
  <input type="hidden" id="hFlds" name="hFlds">
  <center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
