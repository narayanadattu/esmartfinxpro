<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CashAllotDelete.aspx.vb" Inherits="eSmartDotNet.CashAllotDelete"%>
<%	
	Dim Arrtrans(0,4)
    Dim AllotmentNo, strCondition
    
    '------------------Assigning the  values------------------------
	BrCode=Request.Form("txtbranchcode")
	CurCode=Request.Form("txtcurrencycode")
	CntCode=Request.Form("txtcounterno")
	CashId=Request.Form("txtCashierId")
	AllotmentNo=Request.Form("txtallotment")
	AmtAllot=Request.Form("txtamount")
	DenomTot=Request.Form("txttotal")
	appdate=session("APPLICATIONDATE")

	if len(Brcode)<>0 and len(CurCode)>0 and len(CntCode)>0 and  len(CashId)>0 then

		strCondition="branchcode='" & trim(Brcode) & "' and currencycode='" & _
			trim(Curcode) & "' and upper(trim(CashierId))='" & ucase(trim(CashId)) & "'" & _
			" and COUNTERNO='" & trim(CntCode) & "'" & _
			" and ALLOTMENTNO=" & AllotmentNo  & " and status='P'"
		
		Arrtrans(0,0)="U"
		Arrtrans(0,1)="CASHALLOTMENTSTRN"
		Arrtrans(0,2)="status"
		Arrtrans(0,3)="'J'" '"'R'"
		Arrtrans(0,4) = strCondition
							
		'----------- Calling the Component	--------------------
	
		Obj=SERVER.CreateObject("GeneralTransactions.DBTransactions")
		Strmsg= Obj.DataTransactions(Arrtrans)
		obj=nothing
		
		'to remove NEW line characters in the return message
		strmsg = replace(strmsg,chr(13),"")	
		strmsg = replace(strmsg,chr(10),"")	
	else
		strmsg="Required Values should not be empty"
	end if
	Response.Redirect ("DeleteCashAllotment.aspx?record=" & strmsg)

%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
