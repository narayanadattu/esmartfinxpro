<%@ Page aspcompat="true" explicit="false" CodeBehind="cashtransferaccept.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashtransferaccept" %>
<html>
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashTransferAcceptance.aspx
''''' ListForm:List,single
''''' iFramepage:getcounternocashier.aspx
''''' Trnsactionpages:CashtransferAcceptInsert.aspx
''''------------------------------------------------------------------------------------------
%>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
/*
function branch()
	 {
	   st="Bruser"
	   window.open("List.aspx" + "?"+"st="+st,st,"width=210%,height=150%,left=120%,top=230%")
	   
	 }
		 
function currency()
		
	 {		
		st="Curr"
		window.open("List.aspx" + "?"+"st="+st,st,"width=210%,height=150%,left=540%,top=230%")
	 }		
		

function Bruser(kstr)
	 { 
		assign(kstr,window.document.frmtrans.txtbranchdesc,window.document.frmtrans.txtbranchcode)
		window.document.frmtrans.txttotal.value="0.00"
		window.document.frmtrans.txtamount.value ="0.00"
		window.document.all.den.src="acceptdenom.aspx"
		window.document.frmtrans.txtcurrencycode.value=""
		window.document.frmtrans.txtcurrencydesc.value=""
		window.document.frmtrans.txtcashierid.value=""
		window.document.frmtrans.txtcashierdesc.value=""
		window.document.frmtrans.txtcounterid.value=""
		window.document.frmtrans.txttransno.value=""
		window.document.frmtrans.txtnarration.value=""
		
	 }
	 function Currid(kstr)
{
	var p
	k=kstr.split("-----")
	window.document.frmtrans.txtcurrencydesc.value =k[0]
	window.document.frmtrans.txtcurrencycode.value =k[1]
	prn=k[2].length-1
	window.document.frmtrans.hpr.value=prn
	p=""
	for(f=1;f<=prn;f++)
	{
		p=p + "0"
	}
	pres= "0." + p 
	window.document.frmtrans.txttotal.value=pres
	window.document.frmtrans.txtamount.value=pres
	window.document.all.den.src="acceptdenom.aspx"
	window.document.frmtrans.txtcashierid.value=""
	window.document.frmtrans.txtcashierdesc.value=""
	window.document.frmtrans.txtcounterid.value=""
	window.document.frmtrans.txttransno.value=""
	window.document.frmtrans.txtnarration.value=""
}
 
*/
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

// To send parameters to list page to fetch cashierids
function Cashierid()
{

		st1="Cashacc"
		st2=window.document.frmtrans.txtbranchcode.value
		st3=window.document.frmtrans.txtcurrencycode.value
		st=st1+"*"+st2+"*"+st3
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
///displaying the cashier,description which is returned in list page 	 
function Cashieracc(kstr){
	assign(kstr,window.document.frmtrans.txtcashierdesc,
	window.document.frmtrans.txtcashierid)
	Getcounterid()
}

// To send parameters to list page to fetch Counterno
function Counter(){

		st1="Counteracc"
		st2=window.document.frmtrans.txtbranchcode.value
		st3=window.document.frmtrans.txtcurrencycode.value
		st=st1+"*"+st2+"*"+st3
		window.showModalDialog("single.aspx"+"?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
///displaying the counterno which is returned in list page
function Counteraccid(kstr){
		window.document.frmtrans.txtcounterid.value=kstr
		Getcounterid()
}
/// To send parameters to list page to fetch TransFerNo
function Trans(){
		st1="Transfer"									
		sBr=window.document.frmtrans.txtbranchcode.value
		sCur=window.document.frmtrans.txtcurrencycode.value
		sCash=window.document.frmtrans.txtcashierid.value
		sCnt=window.document.frmtrans.txtcounterid.value
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCash=sCash.toUpperCase()
		st=st1+"*"+sBr+"*"+sCur+"*"+sCash+"*"+sCnt
		window.showModalDialog("single.aspx"+"?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
///displaying the Transfer which is returned in list page
function Transno(kstr){
	window.document.frmtrans.txttransno.value =kstr
	Getamount()
}
//To send parameters to iframe page to Get counterid depend on cashierid
function Getcounterid(){
//for Counterno
if(window.document.frmtrans.txtcashierid.value!=""){

		st1="Countacc"
		sBr=window.document.frmtrans.txtbranchcode.value
		sCur=window.document.frmtrans.txtcurrencycode.value
		sCash=window.document.frmtrans.txtcashierid.value
		k="*"
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCash=sCash.toUpperCase()
		st=st1+k+sBr+k+sCur+k+sCash
		//post to iframe page
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
		
	}
	///for casier,name 
else if(window.document.frmtrans.txtcounterid.value!=""){

		st1="Cashacc"
		sBr=window.document.frmtrans.txtbranchcode.value
		sCur=window.document.frmtrans.txtcurrencycode.value 
		sCnt=window.document.frmtrans.txtcounterid.value 
		k="*"
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCnt=sCnt.toUpperCase()
		st=st1+k+sBr+k+sCur+k+sCnt
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
	
	}

}
///for  displaying counterno which is returned in iframe page 
function Allotcounteraccno(stri){
if(stri!=""){
		window.document.frmtrans.txtcounterid.value=stri
}
}
///for  displaying CashierCode,cashierName  which is returned in iframe page 
function  Allotcashieraccno(stri){
	
	var kstr=stri.split("*")
	window.document.frmtrans.txtcashierid.value=kstr[1]
	window.document.frmtrans.txtcashierdesc.value=kstr[2]
}
///send paremeters to iframe page to get the trnsfer amount for login cashierid 
function Getamount(){

	st1="Getamount"
	sBr=window.document.frmtrans.txtbranchcode.value
	sCur=window.document.frmtrans.txtcurrencycode.value
	sCash=window.document.frmtrans.txtcashierid.value
	sCnt=window.document.frmtrans.txtcounterid.value
	stran=window.document.frmtrans.txttransno.value
	k="*"
	sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCnt=sCnt.toUpperCase()
		sCash=sCash.toUpperCase()
	st=st1+k+sBr+k+sCur+k+sCash+k+sCnt+k+stran
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
}
/////for  displaying Transfer Amount  which is returned in iframe page 
function Amount(kstr){

	window.document.frmtrans.txtamount.value =kstr
	precision(window.document.frmtrans.txtamount,window.document.frmtrans.hpr.value)
	precision(window.document.frmtrans.txttotal,window.document.frmtrans.hpr.value)
	Denom()
}
//send parameters to denominations iframe page to fetch denominations 
function Denom()
{
	
	tname="CASHTRANSBTCASHIERSTRN"
	brcode=window.document.frmtrans.txtbranchcode.value		
	crcode=window.document.frmtrans.txtcurrencycode.value	
	counter=window.document.frmtrans.txtcounterid.value
	transno=window.document.frmtrans.txttransno.value
	sy="|"
	fname="frmtrans"
	st=fname+sy+tname+sy+brcode+sy+crcode+sy+counter+sy+transno
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="acceptdenom.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()
}	
///post to server side page to do transactions while accepting
function Insert(){
	window.document.frmtrans.hStatus.value=""
	//checking the null values in mandtory firlds 
	if((window.document.frmtrans.txtcashierid.value=="")||
	(window.document.frmtrans.txtcounterid.value=="")||
	(window.document.frmtrans.txttransno.value=="")||
	(window.document.frmtrans.txtamount.value==""))
	{
		alert("Cashier ID and Transfer No Should be Select to Accept the Cash Transfer")
		return
	}	
	
	if(eval(window.document.frmtrans.txtamount.value)>0)
	{	
		if (CashDenom=='Y')
		{
		if(eval(window.document.frmtrans.txtamount.value)==eval(window.document.frmtrans.txttotal.value))
		{
			/* window.document.frmtrans.hStatus.value="TRANSFER"
			window.document.frmtrans.action="cashtransferacceptinsert.aspx"
			window.document.frmtrans.method="post"
			window.document.frmtrans.submit() */
		}
		else
		{
			alert('Denomination Amount and Transfer Amount Should equal')
			window.document.frmtrans.txtamount.focus()
			return;
		}
		}// cash denomination if
	}	
	else
	{	
		alert('Accepted Amount Should not be Null')
		window.document.frmtrans.txtamount.focus()
		return;
	}	
	
	
	window.document.frmtrans.hStatus.value="TRANSFER"
	window.document.frmtrans.action="cashtransferacceptinsert.aspx"
	window.document.frmtrans.method="post"
	window.document.frmtrans.submit()
}	

/// post to server side page to do transactions while rejecting
function Reject(){
	
	window.document.frmtrans.hStatus.value=""	
	//checking the null values in mandtory firlds 
	if((window.document.frmtrans.txtcashierid.value=="")||
	(window.document.frmtrans.txtcounterid.value=="")||
	(window.document.frmtrans.txttransno.value=="")||
	(window.document.frmtrans.txtamount.value==""))
	{
		alert("Cashier ID and Transfer No Should be Select to Reject the Cash Transfer")
		return
	}		
	if(eval(window.document.frmtrans.txtamount.value)>0)
	{	
		if (CashDenom=='Y')
		{
		if(window.document.frmtrans.txtamount.value==window.document.frmtrans.txttotal.value)
		{
			/* window.document.frmtrans.hStatus.value="REJECT"
			window.document.frmtrans.action="cashtransferacceptinsert.aspx"
			window.document.frmtrans.method="post"
			window.document.frmtrans.submit() */
		}
		else
		{
			alert('Denomination Amount and Transfer Amount Should equal')
			window.document.frmtrans.txtamount.focus()
			return
		}
		}//cash denomination if
	}	
	else
	{	
		alert('Accepted Amount Should not be Null')
		window.document.frmtrans.txtamount.focus()
		return
	}
	
	window.document.frmtrans.hStatus.value="REJECT"
	window.document.frmtrans.action="cashtransferacceptinsert.aspx"
	window.document.frmtrans.method="post"
	window.document.frmtrans.submit()
		
}
///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {
 
 ///string values in variables 
 sCur=window.document.frmtrans.txtcurrencycode.value
sBr=window.document.frmtrans.txtbranchcode.value
sCnt=window.document.frmtrans.txtcounterid.value
sTrn=window.document.frmtrans.txttransno.value
sBr=sBr.toUpperCase()
sCur=sCur.toUpperCase()
sCashId=window.document.frmtrans.txtcashierid.value
sCashId=sCashId.toUpperCase()
sUser="<%=session("userid")%>"
//for cashier description 
if(strTxt=="txtcashierid")
{
	if(window.document.frmtrans.txtcashierid.value=="")
	{
	return;
	}
st="DescDisplay"+"*"+"CASHTRANSBTCASHIERSTRN cash,genusermst gen"+"*"+"gen.name"+
	"*"+"cash.branchcode='" + sBr + "' and " +
			"cash.currencycode='" + sCur + "' and " +
			"cash.FROMcashierid=gen.userid and " +
			"cash.status='P' and "+
			"cash.tocashierid='" + sUser + "' and "+
			"cash.fromcashierid='"+sCashId+"'"+"*"+strTxt
}
//for counterNo
if(strTxt=="txtcounterid")
{
	if(window.document.frmtrans.txtcounterid.value=="")
	{
		return;
	}
	st="DescDisplay"+"*"+"CASHTRANSBTCASHIERSTRN"+"*"+"distinct(fromCOUNTERNO)" +
		"*"+"branchcode='" + sBr + "' and " +
				"currencycode='" + sCur + "' and STATUS='P' and " +
				"tocashierid='" + sUser + "' and " +
				"fromCOUNTERNO='"+sCnt+"'"+"*"+strTxt
	
}
//for transferNo

if(strTxt=="txttransno")
{
	if(window.document.frmtrans.txttransno.value=="")
	{
		return;
	}
	
	st="DescDisplay"+"*"+"CASHTRANSBTCASHIERSTRN"+"*"+"distinct(CASHTRANSFERNO)" +
		"*"+"branchcode='" + sBr + "' and " +
			"currencycode='" + sCur + "' AND STATUS='P' AND " +
			"tocashierid='" + sUser + "' and " +
			"fromcashierid='" + sCashId + "' and " +
			"fromcounterno='" + sCnt + "' and " +
			"CASHTRANSFERNO="+ sTrn +""+"*"+strTxt
	
}
//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
 }	
///functions for displaying the descriptions which is returned in iframe page 
 function DescDisplay(stri)
 {
 
	var StrMain=new String()
	var StrFlds=new String()
	StrMain=stri.split("~")
	StrFlds=StrMain[0].split("|")
	//displaying the cashiername
	if(StrMain[1]=="txtcashierid")
	{
	
		if(StrFlds[0]=="No")
		{
			alert("Invalid Cashier ID")
			splitString("window.document.frmtrans","txtcashierid,"+
			"txtcashierdesc,txtcounterid,txtamount,txttransno")
			return;
		}
		window.document.frmtrans.txtcashierdesc.value=StrFlds[0]
		Getcounterid()
	}	
	//for counterno
	if(StrMain[1]=="txtcounterid")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid Counter No")
			splitString("window.document.frmtrans","txtcounterid,txtamount,txttransno")
			return;
		}
		
		Getcounterid()
	}
///for TransferNo

	if(StrMain[1]=="txttransno")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid Transfer No")
			splitString("window.document.frmtrans","txttransno,txtamount")
			return;
		}
		
		Getamount()
	}	
 }
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashtransferaccept.aspx" 
		
	}
}	
///function for checking the number validation
function numbercheck(txtStr)
{
if(isNaN(txtStr.value))
	{
	alert("Enter Numbers Only")
	
	txtStr.value=""
	return;
	}
}

function Denom1()
{
	if (CashDenom=='Y')
	{
		window.document.all.divdenom.style.display="block"
		window.document.all.total.style.visibility="visible" 
		window.document.frmtrans.txttotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.divdenom.style.display="none"
		window.document.all.total.style.visibility="hidden" 
		window.document.frmtrans.txttotal.style.visibility="hidden" 
	}
}
//-->
</script>
<title></title>
</head>
<body topmargin="0" leftmargin="0" 
onload="GetMenu(window.document.frmtrans.hmenuvals.value);DispTranMsg();Denom1()">

<form name="frmtrans">
<div class="header">
            <table  cellpadding="0" cellspacing="0" width="100%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>

    <div class="menuBar"><%appdate=formatdatetime(session("applicationdate"),1)%>
             <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
					<td width="30%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                    <td width="5%" height="22" class="subHeader" align="center"></td>
                    <td width="30%" align="center" height="22" class="subHeader">
                        <h2 align="left">Cash Transfer Acceptance</h2></td>           
				    <td width="20%" height="22" align="right" class="subHeader"><%=APPDATE%></td>

                    <table width="100%" align="left">

 </table>
                </tr>
            </table>
    </div>
     <div id="menucontrol"></div>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain" >
    <tr>
      <td width="100%" valign="top">

    <!--  <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="11%" height="28"></td>
          <td width="11%" height="28"></td>
          <td width="89%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <!--<td width="100%" bgcolor="#7D5445"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>-->
        <!--    </tr>
          </table>

          </td>
        </tr>
      </table> --->

      <%appdate=formatdatetime(session("Applicationdate"),1)%>

      

      <table align="center" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td height="15"><font class="textblue">
          <p align="center"></font></td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">
                <div align="center">
                  <center>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr class="bgcolor">
                      <td width="15%"><font>&nbsp;&nbsp;&nbsp;&nbsp;Branch
                      Code</font></td>
                      <td width="35%">&nbsp;<input name="txtbranchcode" class="txtautofill"
                      size="9" value="<%=session("branchcode")%>" readonly><input 
                      type="button" class="button" value=" L " name="buttbr" disabled
                      onclick="branch()"><input name="txtbranchdesc" size="16" class="bgcolor1"
                      value="<%=session("branchnarration")%>" readonly></td>
                      <td width="20%" align="center"><font>Currency
                      Code&nbsp;&nbsp;</font></td>
                      <td width="35%" align="left"><input class="txtautofill"
                      name="txtcurrencycode" value="<%=session("currencycode")%>" 
                      size="9" readonly><input type="button" class="button" value=" L " disabled
                      name="buttcur" onclick="currency()"><input class="bgcolor1"
                      name="txtcurrencydesc" size="16" 
                      value="<%=session("currencynarration")%>" readonly></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
              <tr>
                <td width="100%">
                <div align="center">
                  <center>

                  <table width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="48%" valign="top">
                      <div align="center">
                        <center>

                        <table width="98%" cellpadding="0" class="tableborder2">
                          <tr>
                            <td width="100%">
                            <div align="center">
                              <center>

                              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td width="100%" colspan="2" height="15">

                                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td width="26%" height="8"></td>
                                      <td width="44%" height="8"></td>
                                      <td width="30%" height="8"></td>
                                    </tr>
                                    <tr class="bgcolor">
                                      <td width="26%"></td>
                                      <td width="44%">
                                      <p align="center"><font class="subheading">Cashier
                                      Details</font></td>
                                      <td width="30%"></td>
                                    </tr>
                                  </table>

                                  </td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" height="15"></td>
                                </tr>
                                <tr>
                                  <td width="32%">&nbsp;Cashier ID</td>
                                  <td width="78%"><input name="txtcashierid" size="9" 
                                  maxlength=20 style="TEXT-TRANSFORM: uppercase"
                                  onblur='Dataarrange(window.document.frmtrans.txtcashierid);
                                  DescrptionDisp("txtcashierid")'
                                  class="txtautofill"><input type="button" class="button" 
                                  value=" L " name="buttbr1" 
                                  onclick="Cashierid()"><input 
                                  name="txtcashierdesc" size="15" 
                                  readonly class="bgcolor1"></td>
                                </tr>
                                <tr>
                                  <td width="32%">&nbsp;Counter ID</td>
                                  <td width="78%"><input name="txtcounterid" maxlength=2
                                  onblur='Dataarrange(window.document.frmtrans.txtcounterid);
                                  DescrptionDisp("txtcounterid")'
                                  size="9"  class="txtautofill"><input 
                                  type="button" class="button" value=" L " name="buttbr2" 
                                  onclick="Counter()"></td>
                                </tr>
                                <tr>
                                  <td width="32%">&nbsp;Cash Transfer No</td>
                                  <td width="78%"><input name="txttransno" 
                                  size="9" maxlength=20 class="txtautofill"
                                  onblur='Dataarrange(window.document.frmtrans.txttransno);
                                  numbercheck(window.document.frmtrans.txttransno)
                                  DescrptionDisp("txttransno")'><input 
                                  name="buttbr2" onclick="Trans()" 
                                  type="button" class="button" value=" L "></td>
                                </tr>
                                <tr>
                                  <td width="32%">&nbsp;Amount</td>
                                  <td width="78%"><input name="txtamount" 
                                  size="9" class="txtautofill" style="TEXT-ALIGN: right" 
                                  readonly value="0.00"></td>
                                </tr>
                                <tr>
                                  <td width="32%">&nbsp;Narration</td>
                                  <td width="78%"><input name="txtnarration" size="29" 
                                  maxlength="40"
                                  onblur='Dataarrange(window.document.frmtrans.txtnarration)'></td>
                                </tr>
                                <tr>
                                  <td width="116%" height="40" colspan="2">&nbsp;</td>
                                </tr>
                              </table>

                              </center>
                            </div>
                            </td>
                          </tr>
                        </table>

                        </center>
                      </div>
                      </td>
                      <td width="61%" height="10" valign="top">
                      <div align="center" id="divdenom">
                        <center>

                        <table width="96%" cellpadding="0" class="tableborder2">
                          <tr>
                            <td>

                            <table border="0" width="60%" cellspacing="0" cellpadding="0">
                              <tr>
                                <td><iframe  align=center           
                  id=den frameborder=0 framespacing 
                        =0 noresize height=380 width=380 valign="top" src 
                       ="acceptdenom.aspx" style="BACKGROUND-COLOR: darkred" 
                       ></iframe></td>
                              </tr>
                            </table>

                        </table>

                        </center>
                      </div>
                      </td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0" >
            <!--  <tr>
                <td width="47%" height="5"></td>
                <td width="28%" height="5"></td>
                <td width="8%" height="5"></td>
                <td width="17%" height="5"></td>
              </tr> --->
              <tr>
                
                <td width="28%" ></td>
                <td width="8%" align="right"><font class="textred"><span id="total" style="VISIBILITY:abort">Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                <td width="17%" ><input name="txttotal" size="11" value="0.00" class="bgcolor1" readOnly style="TEXT-ALIGN: right" onload="amountdigits(window.document.frmtrans.txttotal)"></td>
              </tr>
            </table>
            
            

           <!---  <table border="0" width="100%" cellspacing="0" cellpadding="0">
             <tr>
                <td width="116%" height="5">&nbsp;</td>
              </tr>
              <tr>
                <td width="116%" height="15">&nbsp;</td>
              </tr> 
              <tr>
                <td width="116%" height="5">&nbsp;</td>
                <input type="hidden" name="hpr"><input type="hidden" name="hStatus">
              </tr>
            </table>-->

        </table>
        

        </center>
      </div>


      </td>
      </tr>
      <td width="47%" >
                <div align="center">
                  <center>

                  <table cellspacing="0" cellpadding="0"  class="tablebordermain">
                    <tr>
                      <td width="100%" height="10">
                      <p align="center"><input type="button" value="Accept" 
                      name="cmdok" onclick="Insert()" class="button"><input 
                      type="button" class="button" value="Reject" name="cmdok" onclick="Reject()" 
                      class="bgcolor"><input type="reset" value="Cancel" 
                      name="cmdcancel" onclick="location.href=&quot;cashtransferaccept.aspx&quot;"
                      class="button"><input type="button" class="button" value="   Exit   " 
                      name="cmdexit" 
                      onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" class="bgcolor"></p>
                      </td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
  </table>

  <input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%"><input type="hidden" name="hpr"><input type="hidden" name="hStatus">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="getcounternocashier.aspx">
                                              </iframe>
      </td>
    </tr>
  </table>

      </center>
    </div>
    </td>
  </tr>
</table>

</body>

</html>
