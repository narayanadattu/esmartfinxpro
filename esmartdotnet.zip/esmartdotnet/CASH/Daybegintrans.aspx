<%@ Page Language="vb" CodeBehind="Daybegintrans.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Daybegintrans" %>
<%
dim ObjLogin,ObjWorkAllotment
dim UsrId,Paswd,bio
dim trans(0,4)
dim StrMsg,St,Status
dim recdaybegin
Dim RecWorkAllot
Dim rscnt,rsdate
Set RecWorkAllot=server.CreateObject("Adodb.recordset")

'============================SESSION TRACKING==========================
set rscnt=server.CreateObject("adodb.recordset")
set rsdate=server.CreateObject("adodb.recordset")
set objcnt=server.CreateObject("queryrecordsets.fetchrecordsets")
set rscnt=objcnt.singlerecordset("cashcountermst","counterno","cashierid='"& session("userid") & "'")	

usrid=session("userid")
set objcnt=nothing
if not rscnt.BOF and not rscnt.EOF then
	session("counterno")=rscnt(0)
end if
set objcnt=server.CreateObject("queryrecordsets.fetchrecordsets")
set rsdate=objcnt.singlerecordset("GENAPPLICATIONDATEMST","to_char(applicationdate,'dd-Mon-yyyy')","")
set objcnt=nothing
session("applicationdate")=rsdate(0)
session("machineid")=Request.ServerVariables("REMOTE_ADDR")	



	

						
			set ObjWorkAllotment=server.CreateObject("QueryRecordsets.Fetchrecordsets")
			set RecWorkAllot= ObjWorkAllotment.SingleRecordset("GenWorKAllotmentmst","moduleid,branchcode","upper(userid)='" & ucase(UsrId) &"'")
			set recdaybegin=server.CreateObject("adodb.recordset")
			do while not RecWorkAllot.EOF 
				chkst=chkst& ",'" & recworkallot(0) &"'"
				RecWorkAllot.MoveNext 
			loop
			RecWorkAllot.MoveFirst 
			
			chkst=right(chkst,len(chkst)-1)
			
			if not recworkAllot.EOF then
					set recdaybegin=ObjWorkAllotment.SingleRecordset("Genmoduleactivitylog","moduleid,daybeginstatus","to_char(daybegindate,'dd-Mon-yyyy')='" & rsdate(0) &"' and moduleid in(" & chkst &")")
					
					do while not recdaybegin.EOF 
						if recdaybegin(1)="O" then
							Stx=Stx & RecWorKAllot(0) & ":F" & "|" 
						else
								Stx=Stx & RecWorKAllot(0) & ":T" & "|" 
						end if
						st=st&",'" & recworkallot(0) &"'"
						recdaybegin.MoveNext 
					loop
					st=right(st,len(st)-1)
					dim recchk
					set recchk=server.CreateObject("adodb.recordset")
					set recchk=objWorkAllotment.SingleRecordset("Genworkallotmentmst","moduleid,branchcode","upper(userid)='" & ucase(UsrId) &"' and moduleid not in(" & st &")")
					do while not recchk.EOF 
								Stx=Stx & Recchk(0) & ":T" & "|" 
							recchk.MoveNext 
					loop
					
		
'=============================================================================
			end if			
			
			Response.Redirect "Modulescr.asp?record=" & Stx
		
%>


<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
