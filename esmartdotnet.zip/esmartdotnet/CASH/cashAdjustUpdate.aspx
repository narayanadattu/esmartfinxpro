<%@ Page aspcompat="true" explicit="false"  Language="vb" AutoEventWireup="false" Codebehind="cashAdjustUpdate.aspx.vb" Inherits="eSmartDotNet.cashAdjustUpdate"%>

<%
dim ObjExNoGen,objDel
	dim BrCode,CurCode,CntNo,ExNo,CashId,Amt,d1,status,AdjAmt,appdate
	Dim kstr,RsExChng
	Dim ObjExCng,RowNos,ObjCash,RecCash
	Dim DenomArr(1,4)
	rownos=Request.Form("hcount")
	BrCode=ucase(trim(Request.Form("txtbranchcode")))
	CurCode=ucase(trim(Request.Form("txtcurrencycode")))
	cashid=ucase(trim(Request.Form("txtCashierId")))
	Amt = Request.Form("txttotal")
	AdjAmt = Request.Form("txtrtotal")
	appdate = session("applicationdate")
	userid=session("userid")
	machineid=ucase(trim(session("Machineid")))
	
	m=split(Request.Form("hvalue"),"|") 'a = denomination
	n=split(Request.Form("hrec"),"|")	'b = adjust denomination
	q=split(Request.Form("htype"),"|")	'd = Denomination type
    r=split(Request.Form("havail"),"|") 'e = Original denomination
    
    DIM strFeld,strFeldval,stAdenom,strUpfeld,strUpValue,strUpcond,strAdval,strMafeld,strMaval
    
    ObjCash=server.CreateObject("QueryRecordsets.fetchRecordsets")
	RecCash=server.CreateObject("adodb.recordset")

	RecCash=ObjCash.singlerecordset("cashcashierposmst","counterno","upper(trim(cashierid))='" & cashid & "'")
	if not RecCash.EOF then
		countno=RecCash(0).value
	end if
	RecCash=nothing
	ObjCash=nothing
	
	
	strMafeld = "BRANCHCODE, CURRENCYCODE, CASHIERID, COUNTERNO, AMOUNT, ADJAMOUNT, APPLICATIONDATE, USERID, MACHINEID"
    strMaval = "'" & BrCode & "','" & CurCode & "','" & cashid & "','" & countno & "','" & Amt & "','" & AdjAmt & "','" & appdate & "','" & userid & "','" & machineid & "'"
	
	dim rs,obj2,rs1,obj1
	
	rs=server.CreateObject("adodb.recordset")
	obj2 = server.CreateObject("ReportPurposeOnly.Reportonly")
	rs1=server.CreateObject("adodb.recordset")
	obj1 = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	sqlStr = ""
	
	'SELECT * FROM CashRefundsTrn WHERE UPPER(trim(Branchcode))='101' AND UPPER(trim(currencycode))='INR' AND UPPER(trim(REFUNDEDUSERID))='SATYABALA' AND UPPER(trim(status))='P'
	
	sqlStr="SELECT * FROM CashRefundsTrn WHERE UPPER(trim(Branchcode))='" & BrCode & "' AND UPPER(trim(currencycode))='" & CurCode & "' AND UPPER(trim(REFUNDEDUSERID))='" & cashid & "' AND UPPER(trim(status))='P'"
	
	rs1=obj1.SingleSelectStat(sqlStr)
	
	if obj1.ConnError="Connected" then
		if not rs1.BOF and not rs1.EOF then
		
			Strmsg = "CASH Refund Is Pending For these User Id \n Please Accept The Refund Amount"
		
		else
			
			'"SELECT Denominationvalue,Denominationcode,denominationtype FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY denominationtype DESC, TO_NUMBER(denominationvalue) DESC"
			sqlStr = ""
			
			sqlStr="SELECT Denominationvalue,Denominationcode,denominationtype FROM CashDenominationMst WHERE UPPER(Currencycode)='" & CurCode & "' ORDER BY denominationtype DESC, TO_NUMBER(denominationvalue) DESC" ''for Denomination code name 

			rs=obj2.SingleSelectStat(sqlStr)
			
			if obj2.ConnError="Connected" then
				if not rs.BOF and not rs.EOF then
					strField = ""
					strVal = ""
					
					do until rs.EOF
						
							For i=1 to RowNos
								
								if (rs(0).value = m(i-1)) and  (rs(2).value = q(i-1)) then
									
									stAdenom = "A" & rs(1).value
									
									strFeld = strFeld & rs(1).value & "," & stAdenom & ","  ' for insert field
									
									strUpfeld = strUpfeld & rs(1).value & ","  ' for update field
									
									if n(i-1) = "" then
										strAdval = "0"
									else
										strAdval = n(i-1)
									end if
									
									strFeldval = strFeldval & r(i-1) & "," & strAdval & "," 'for insert field value
									strUpValue = strUpValue & strAdval & "~"  ' for update field value
									
								end if
								
							next
				
						rs.movenext()
					loop
					
					
					strFeld=mid(strFeld,1,strFeld.length-1)
					strUpfeld=mid(strUpfeld,1,strUpfeld.length-1)
					strFeldval=mid(strFeldval,1,strFeldval.length-1)
					strUpValue=mid(strUpValue,1,strUpValue.length-1)
					
					'BRANCHCODE='101' AND CURRENCYCODE='INR' AND CASHIERID='SATYABALA' AND COUNTERNO='2'
					strUpcond = " BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND CASHIERID='" & cashid & "' AND COUNTERNO='" & countno & "' "
								
				end if
			end if
			
			rs = nothing
			obj2 = nothing	
				
				
				DenomArr(0,0) = "I"
				DenomArr(0,1) = "CASHDENOMADJDTLS"
				DenomArr(0,2) = strMafeld & "," & strFeld
				DenomArr(0,3) = strMaval & "," & strFeldval
				DenomArr(0,4) = ""
				
				DenomArr(1,0) = "U"
				DenomArr(1,1) = "CASHCASHIERPOSMST"
				DenomArr(1,2) = strUpfeld
				DenomArr(1,3) = strUpValue
				DenomArr(1,4) = strUpcond
				
				Response.Write (DenomArr(acnt,0) & "<br>")
				Response.Write (DenomArr(acnt,1) & "<br>")
				Response.Write (DenomArr(acnt,2) & "<br>")
				Response.Write (DenomArr(acnt,3) & "<br>")
				Response.Write (DenomArr(acnt,4) & "<br>")
				
				objDel=server.CreateObject("GeneralTransactions.DBTransactions")
				
				Strmsg= objDel.DataTransactions(DenomArr,cstr(session("branchcode")),cstr(Session("Userid")),cstr(session("machineid")),cstr(appdate))
				
				objDel = nothing
		end if
	end if
	
	
	
		
		Response.Redirect ("frmcashAdjust.aspx?record=" & Strmsg)
    
    

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <title>cashAdjustUpdate</title>
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
  </head>
  <body MS_POSITIONING="GridLayout">

    <form id="Form1" method="post" runat="server">

    </form>

  </body>
</html>
