<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmAtmCashPosition.aspx.vb" Inherits="eSmartDotNet.frmAtmCashPosition"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
    <title>frmAtmCashPosition</title>
    <SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
	<script language=javascript>
	
	function show()
	{
		var strVal,br
		
		window.document.frmAtmPosition.mfgCash.rows=1
		
		if(window.document.frmAtmPosition.txtdate.value=="")
		{
			alert("Please Enter Date")
			return;
		}
		
		strVal="ATMPOSITION"+"|"+window.document.frmAtmPosition.txtdate.value
		
		window.document.all['iVinFrame'].src="../GEN/getDtls.aspx?st="+strVal;
	}
	
	function popAtmDetail(str)
	{
		window.document.frmAtmPosition.mfgCash.rows=1
		
		if(str=="No Records")
		{
			alert("No Records Found")
			return;
		}
		
		var stDval = str.split("|")
		
		window.document.frmAtmPosition.mfgCash.formatstring = "<SlNo  |<Branch          |<Acc No           |<ATM ID         |<Name               |>Open Balance         |>Debit                   |>Credit                 |>Close Balance                 " ;
		
		for(aCnt=0;aCnt<=stDval.length-1;aCnt++)
		{
			window.document.frmAtmPosition.mfgCash.rows=window.document.frmAtmPosition.mfgCash.rows+1
			
			var strCols=stDval[aCnt].split("~")
			
			window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				if(strCols[4] > "0")
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=strCols[4]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)),2)+" Cr"
				}
				else if(strCols[4] < "0")
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=strCols[4]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)),2)+" Dr"
				}
				else
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=strCols[4]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,5)),2)
				}
				
				window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,6)=strCols[5]
				window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,6)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,6)),2)
				
				window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,7)=strCols[6]
				window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,7)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,7)),2)
				
				if(strCols[7] > "0")
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=strCols[7]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)),2)+" Cr"
				}
				else if(strCols[7] < "0")
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=strCols[7]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)),2)+" Dr"
				}
				else
				{
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=strCols[7]
					window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)=ToIndianCurencyFormat(Math.abs(window.document.frmAtmPosition.mfgCash.textmatrix(aCnt+1,8)),2)
				}
				
			}
		}
		
	}
	
	</script>
  </head>
  <body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg()">
	<form name="frmAtmPosition">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%">
			<tr>
				<td align="left" class="bankHeaderLogo"></td>
				<td align="right" class="esmartBankerLogo"></td>
			</tr>
		</table>			
	</div>
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="35%" align="center" height="22" class="subHeader"><h2>Atm Position</h2></td>
				<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
		<table width="100%" cellspacing="0" height="74%" cellpadding="0" class="tablebordermain">
			<tr>
				<td width="100%" valign="top">
					<%appdate=formatdatetime(session("applicationdate"),1)%>
					</center>
					<div align="center">
						<center>
						<table border="0" width="98%" cellspacing="0" cellpadding="0">
							<tr class="bgcolor">
								<td width="12%" align="center">&nbsp;Branch Code</td>
								<td width="30%"><input type="text"  class="txtautofill" name="txtbranchcode" size="9" value="<%=session("branchcode")%>" readonly><input type="button" class="button" value=" L " name="butbr" onclick="branch()"><input type="text" class="bgcolor1" name="txtbranchdesc" value="<%=session("branchnarration")%>" size="16" readonly></td>
								<td width="20%" align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency
								Code</td>
								<td width="30%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="txtautofill" name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" readonly><input type="button" class="button" value=" L " name="butcur" onclick="currency()"><input class="bgcolor1" type="text" name="txtcurrencydesc" value="<%=session("currencynarration")%>" size="16" readonly></td>
							</tr>
						</table>
						</center>
					</div>
					<div align="center">
						<center>
						<table border="0" width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
							<tr>
								<td width="149%"></td>
							</tr>
							<tr>
								<td width="139%"></td>
							</tr>
							<tr>
								<td width="139%">
									<table border="0" width="100%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="12%" align="right"><font size="2" face="MS Sans Serif">Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
											<td width="88%">&nbsp;<input type="text" name="txtdate" size="10" readonly  value="<%=session("applicationdate")%>"></td>
										</tr>
									</table>
								</td>
								<td>&nbsp;</td>
							</tr>
							<tr>
								<td width="50%" align="center"><input type="button" value="Refresh" name="buttcbal" onclick="show()" class="button"></td>
							</tr>
							<tr>
								<td width="100%" align="center" colspan='8'>
								<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgCash name=mfgCash style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 950px" width=750 >
								<PARAM NAME="_ExtentX" VALUE="15055">
								<PARAM NAME="_ExtentY" VALUE="3757">
								<PARAM NAME="BackColor" VALUE="-2147483643">
								<PARAM NAME="ForeColor" VALUE="-2147483640">
								<PARAM NAME="Enabled" VALUE="-1">
								<PARAM NAME="BackStyle" VALUE="0">
								<PARAM NAME="BorderStyle" VALUE="1">
								<PARAM NAME="AllowBigSelection" VALUE="-1">
								<PARAM NAME="AllowUserResizing" VALUE="1">
								<PARAM NAME="Appearance" VALUE="1">
								<PARAM NAME="BackColorBkg" VALUE="8421504">
								<PARAM NAME="BackColorFixed" VALUE="-2147483633">
								<PARAM NAME="BackColorSel" VALUE="-2147483635">
								<PARAM NAME="CausesValidation" VALUE="-1">
								<PARAM NAME="Cols" VALUE="1">
								<PARAM NAME="ColWidth0" VALUE="1725">
								<PARAM NAME="DrawMode" VALUE="0">
								<PARAM NAME="FillStyle" VALUE="0">
								<PARAM NAME="FixedCols" VALUE="0">
								<PARAM NAME="FixedRows" VALUE="1">
								<PARAM NAME="FocusRect" VALUE="1">
								<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
								<PARAM NAME="ForeColorSel" VALUE="-2147483634">
								<PARAM NAME="FormatString" VALUE="">
								<PARAM NAME="GridColor" VALUE="12632256">
								<PARAM NAME="GridColorFixed" VALUE="0">
								<PARAM NAME="GridLines" VALUE="1">
								<PARAM NAME="GridLinesFixed" VALUE="2">
								<PARAM NAME="GridLineWidth" VALUE="1">
								<PARAM NAME="MergeCells" VALUE="0">
								<PARAM NAME="MergeCol0" VALUE="0">
								<PARAM NAME="MergeRow0" VALUE="0">
								<PARAM NAME="MousePointer" VALUE="0">
								<PARAM NAME="OLEDropMode" VALUE="0">
								<PARAM NAME="PictureType" VALUE="0">
								<PARAM NAME="Redraw" VALUE="-1">
								<PARAM NAME="RightToLeft" VALUE="0">
								<PARAM NAME="RowHeightMin" VALUE="0">
								<PARAM NAME="Rows" VALUE="1">
								<PARAM NAME="ScrollBars" VALUE="3">
								<PARAM NAME="ScrollTrack" VALUE="0">
								<PARAM NAME="SelectionMode" VALUE="0">
								<PARAM NAME="TextStyle" VALUE="0">
								<PARAM NAME="TextStyleFixed" VALUE="0">
								<PARAM NAME="ToolTipText" VALUE="">
								<PARAM NAME="WhatsThisHelpID" VALUE="0">
								<PARAM NAME="WordWrap" VALUE="0">
								<PARAM NAME="ColAlignment0" VALUE="9">
								<PARAM NAME="ColData0" VALUE="0">
								<PARAM NAME="FixedAlignment0" VALUE="4">
								<PARAM NAME="FontWidth" VALUE="0">
								<PARAM NAME="hWnd" VALUE="0">
								<PARAM NAME="RowData0" VALUE="0">
								<PARAM NAME="RowHeight0" VALUE="240">
								<PARAM NAME="TextArray0" VALUE="S.No">
								<PARAM NAME="TextMatrix0" VALUE="S.No">
								<PARAM NAME="row" VALUE="">
								<PARAM NAME="col" VALUE="">
								<PARAM NAME="RowSel" VALUE="">
								<PARAM NAME="ColSel" VALUE="">
								<PARAM NAME="CellBackColor" VALUE="">
								<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
								</td>
							</tr>
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100%" align="center"><!--<input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input type="button" value="Show Details" name="cmdshowdet" onClick="ShowDetails()" class="button">--><input type="button" value=" Exit  " name="B3" class="button" onclick="window.location.href=
									&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;"><input type="Button" name="cmdcancel" value=" Cancel " onclick="location.href='frmAtmCashPosition.aspx'" class="button"></td>
								</tr>
							</table>
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr>
								<td width="100%" height="20">
								<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
								
								</td>
								<input type="hidden" name="hreport">
								<input type="hidden" name="reptitle">
								</tr>
							</table>
						</table>
  
<div class="footer">
	<div class="logo"></div>
	<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
</div>  

    </form>

  </body>
</html>
