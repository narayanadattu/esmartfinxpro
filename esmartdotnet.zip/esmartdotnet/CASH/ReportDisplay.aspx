<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="ReportDisplay.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.ReportDisplay" %>

<script language=vbscript runat=server>
function toPrecision(number)
 '''''function for precision calling 	
 	pr=session("PRECISION")
	dim i,j,k,n,m,v
	if(len(pr)=0) then
		p=2
	else
		p=pr
	end if
	j=0
	k=0
	n=0
	
	dim textvalue
	textvalue=number
	if isdbnull(textvalue)  or mid(textvalue,1,2)="--" then
		toPrecision=number
		exit function
	else
		for i=1 to p-1
			j=j & "0"	 
		next	
		m= "."& j

	end if	
	
	if not isdbnull(textvalue) then
		 dotindex=instr(1,textvalue,".")
		 			
		if dotindex=0 then
			number=textvalue &  m
			toPrecision=number
			exit function
		elseif dotindex>-1 then
			dotafterchars=mid(textvalue,dotindex+1)			
			k=len(dotafterchars)
			
			if k<p then
				t=val(p)-val(k)
				for i=0 to t-2
					n=n & "0"					
				next		
				number =textvalue &  n	 				
				 toPrecision=number
				 exit function
			elseif k=p then
				number=number
			else
				number=number & m
			end if				
		else
			number= mid(textvalue,0,dotindex) & mid(textvalue,dotindex,p+1)			
			 toPrecision=number
			 
			 exit function			
		end if				
		
			
	end if	
		toPrecision=number

end function	
</script>
<%
  
  
  ''''declaring the variables 
    Dim ArrTran(1,4)
	Dim BrCode, CurCode, RepDate, CashId 
	Dim BankParamDate,RsAllot,RsReceipts
	Dim  RsToTransfer,RsFromTransfer,RsRefunds
	Dim  RsDate,RepType,StrTabSuffix,GrandTotal,rep
	BrCode = UCase(Trim(Request.Form("txtbranchcode")))
	CurCode = UCase(Trim(Request.Form("txtcurrencycode")))
	RepDate = Request.Form("txtrepdate")
	RepVaultDate=Request.Form("txtRepvaultdate")
	CashId = UCase(Trim(Request.Form("txtcid")))
	StrDelstatus=""
	StrFldValues=""
	 RsAllot = CreateObject("ADODB.Recordset")
	 RsReceipts = CreateObject("ADODB.Recordset")
	 RsPayments = CreateObject("ADODB.Recordset")
	 RsToTransfer = CreateObject("ADODB.Recordset")
	 RsFromTransfer = CreateObject("ADODB.Recordset")
	 RsRefunds = CreateObject("ADODB.Recordset")
	 RsReceipts = CreateObject("ADODB.Recordset")
	 RsDate = CreateObject("ADODB.Recordset")
	 Rstemp = CreateObject("adodb.recordset")
	 RsCurrency=server.CreateObject("adodb.recordset")
	 rep = Request.Form("hreport")
	StrTabName="REPCASHTEMP"
	''''''****************Setting the TransactionComponent****************
	 ObjTran = SERVER.CreateObject("GeneralTransactions.DBTransactions") 
	''''calling general component  to  for setting the recordsets and
	'''''''querying the records
	 objQuery = CreateObject("QueryRecordsets.FetchRecordsets")
	 RsDate = objQuery.SingleRecordSet("GENAPPLICATIONDATEMST", _
            "to_char(APPLICATIONDATE,'dd-Mon-yyyy')", "branchcode='" & BrCode & "'")
		If Not RsDate.EOF And Not RsDate.BOF Then
		'''checking the bank Parameter date is equal to front end paramet date
		''' if dates are equal then fetch the data from 'TRN' table
		'''else 'HIST' table
			
	if ucase(Request.QueryString("strng"))="ALLTEMPDATAGENERATE" or _
	 ucase(Request.QueryString("strng"))="RECPAYTEMPDATAGENERATE" then							
				if cdate(rsdate(0).value)=cdate(repdate) then
					StrTabSuffix = "TRN"
				Else
					StrTabSuffix = "TRNBKP"
				End If
	else
				if cdate(rsdate(0).value)=cdate(repvaultdate) then
					StrTabSuffix = "TRN"
				Else
					StrTabSuffix = "TRNBKP"
				End If
	end if
				
		End If
		
'''--------------------------------------------------------------------------------------------
''''' for all transaction('All' opt button is checked ) in cashierwisereport form 
if ucase(Request.QueryString("strng"))="ALLTEMPDATAGENERATE" then	'''for fetching the General bank application date from the
	RepCode=3
	RepId=1
	strwhcond=" and applicationdate='" & RepDate & "'"
'''All trn table data insert into cashreporttemp  table with credit and debit transactions 
    ''' a recordset for fetching the Allotmentno,amount from the
                '''cashallotmentstrn or cashallotmentstrnhist table	           
                 RsAllot = objQuery.SingleRecordSet("CASHALLOTMENTS" & StrTabSuffix, _
                                        "ALLOTMENTNO,AMOUNTALLOTED", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "CASHIERID='" & CashId & "' and " & _
                                        "status='A'" & strwhcond, "allotmentno")
                 If RsAllot.RecordCount <> 0 Then
                 'If not re
					For icnt = 0 To RsAllot.RecordCount - 1
					  StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "" & RsAllot(0).value & ",'ALLOTMENT'," & RsAllot(1).value & ",null," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
                                  
						RsAllot.MoveNext
						
		            Next
				 End If
''' a recordset for fetching the Refundno,amount from the
                '''CASHREFUNDSTRNtrn or CASHREFUNDSTRNtrnhist table
                 RsRefunds = objQuery.SingleRecordSet("CASHREFUNDS" & StrTabSuffix, _
                                        "REFUNDNO,REFUNDAMOUNT", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "REFUNDEDUSERID='" & CashId & "' and " & _
                                        "status='A'" &strwhcond, "REFUNDNO")
                 If RsRefunds.RecordCount <> 0 Then
                       For icnt = 0 To RsRefunds.RecordCount - 1
						StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "" & RsRefunds(0).value & ",'REFUND'," & _
                                     "null," & RsRefunds(1).value & "," & _
                                   "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                   "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
                                     
							RsRefunds.MoveNext
             			Next
                 End If
''
 ''' a recordset for fetching the Transferno,amount from the
                '''CASHTRANSBTCASHIERSTRN or CASHTRANSBTCASHIERstrnhist table
                '''for From Cashier
                 RsFromTransfer = objQuery.SingleRecordSet("CASHTRANSBTCASHIERS" & _
                                StrTabSuffix, _
                                "CASHTRANSFERNO,AMOUNT,FROMCASHIERID,TOCASHIERID", _
                                "branchcode='" & BrCode & "' and " & _
                                "currencycode='" & CurCode & "' and  " & _
                                "(FROMCASHIERID='" & CashId & "' or " & _
                                "TOCASHIERID='" & CashId & "') and " & _
                                "status='A'" & strwhcond, "CASHTRANSFERNO")
                 If RsFromTransfer.RecordCount <> 0 Then
                      For icnt = 0 To RsFromTransfer.RecordCount - 1
                  '''' parameter cashierid is from cashier id credit the transaction  
                      if RsFromTransfer(2).value=cashid then
					StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "" & RsFromTransfer(0).value & ",'TRANSFER'," & _
                                    "null," & RsFromTransfer(1).value & "," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode &"','" & repid & "','" & RepDate & "'" & "|"
                  '''' parameter cashierid is to cashier id Debit the transaction                   
                       elseif RsFromTransfer(3).value=cashid then
                   StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "" & RsFromTransfer(0).value & ",'TRANSFER'," & _
                                    "" & RsFromTransfer(1).value & ",null," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"             
                        end if              
                         
                                  
						RsFromTransfer.MoveNext
						 
					 Next
                 End If
                 
  ''' a recordset for fetching the total Reciepts amount  from the
                '''CASHRECEIPTStrn or CASHRECEIPTShist table
                 RsReceipts = objQuery.SingleRecordSet("CASHRECEIPTS" & StrTabSuffix, _
                                        "sum(AMOUNT)", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "CASHIERID ='" & CashId & "' " & _
                                        "" & strwhcond)
                 If RsReceipts.RecordCount <> 0 Then
                    If not isdbnull(RsReceipts(0).value) Then
                       StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "null,'RECEIPTS'," & _
                                    "" & RsReceipts(0).value & ",null," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
                                   
                     End If
                 End If  
                       
 ''' a recordset for fetching the total Reciepts amount  from the
                '''CASHPAYMENTSStrn or CASHPAYMENTShist table
                 RsPayments = objQuery.SingleRecordSet("CASHPAYMENTS" & StrTabSuffix, _
                                        "sum(AMOUNT)", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "CASHIERID='" & CashId & "' " & _
                                        " " & strwhcond)
                 If RsPayments.RecordCount <> 0 Then
                    If not isdbnull(RsPayments(0).value) Then
                     
                      StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & _
                                    "null,'PAYMENTS'," & _
                                    "null," &  RsPayments(0).value & "," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
                                     
                     End If
                 End If
                 
       '''inserting a row for grnd total with branccode,currencycode,casierid,reportquerydate      
		if StrFldValues="" then
		Response.Redirect ("cashierwisereport.aspx?record=" & "No Transactions on selected Date")
		end if
    
          StrFldValues=left(StrFldValues,len(StrFldValues)-1)
  '''checking for recors are already exists in the cashreporttemp table for given
 '''cashierid,branchcode,currencycode,date
 ''' a recordset for fetching the total Reciepts amount  from the
                '''CASHPAYMENTSStrn or CASHPAYMENTShist table
                 '"REPORTQUERYDATE='" & RepDate & "' and " & _
                StrDelCondition="branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "CASHIERID='" & CashId & "' and " & _
										"reportcode='" & repcode & "' and " & _
                                        "reportid='" & repid & "'" 
                                       
                                    
                 Rstemp = objQuery.SingleRecordSet(cstr(StrTabName),"*", _
							cstr(StrDelCondition))
                                        
                 If Rstemp.RecordCount <> 0 Then
                 	StrDelstatus="DELETE"
                 End If   
		''storing values for insert table(CASHREPORTTEMP) for inserting
         
           StrFldNames = "BRANCHCODE,CURRENCYCODE,CASHIERID,TRANNO," & _
                        "MODEOFTRAN,CREDIT,DEBIT,REPORTQUERYDATE," & _
                        "reportcode,reportid,applicationdate"		                       
         ''''-------------------------------------------------------------------------------
				if strDelstatus="DELETE" then
					''''if status mode 'DELETE' 
					redim ArrTran(1,4)
					ArrTran(0,0)="D"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=""					'passing the FieldNames
					ArrTran(0,3)=""					'passing the Fieldvalues
					ArrTran(0,4)=StrDelCondition
					ArrTran(1,0)="I"				'passing the TransactionType
					ArrTran(1,1)=StrTabName			'passing the tablename
					ArrTran(1,2)=StrFldNames		'passing the FieldNames
					ArrTran(1,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(1,4)=""
				else
				''''if status mode is null
					redim ArrTran(0,4)
					ArrTran(0,0)="I"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=StrFldNames		'passing the FieldNames
					ArrTran(0,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(0,4)=""
				end if       
           ''calling componenet method
			Strmsg= ObjTran.DataTransactions(ArrTran)
			 Objtran=nothing
			Response.Write (Strmsg)
	'''CALLING report templatepage 
	IF STRMSG="Transaction Sucessful." then
		
		'''''setting parameter string which is send to report template page
		'''this parameters are used in where condition to fetch the data from the
		''cashreporttemp table with the format of operator,value 
		StrRepCondition= "=" & "|<" &  "'" & BrCode & "'" & "|<!~" &   _		
					 "=" & "|<"  & "'" & CurCode & "'" & "|<!~" &  _		
					 "=" & "|<"  & "'" & CashId & "'" & "|<!~" &  _		
					"=" & "|<" & "'" & RepDate & "'"  	& "|<!~" & _
					"=" & "|<" & "'" & Repcode & "'"  	& "|<!~" & _
					"=" & "|<" & "'" & RepId & "'"  	& "|<!~"  & _
					"RGT" & "|<abs(sum(credit)-sum(debit))|<!~" 
					'"GROUP" & "|<" & "SUM" & "|<" & "AMOUNT"  & "|<" & "MODEOFTRAN" & "!~"				
		StrMainFlds=BrCode & "^^" & CurCode & "^^" & RepDate & "^^" & _
		CashId &"^^" & RepCode &"^^" & RepId & "^^" & 	StrRepCondition	
		
		Response.Write ("http://" & session("moduledir"))
		Session("strMainFlds")=StrMainFlds
		
		if rep = "HTML" then
			Response.Redirect("http://" & session("moduledir") & "/ReportTemplate.aspx")
		else
			Response.Redirect("http://" & session("moduledir") & "/ReportTemplateXL.aspx")
		end if
		'Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx?repstring="& _
		'				StrMainFlds)
	end if	
'''--------------------------------------------------------------------------------------------
''''' for Receipts and payments transaction('Receipts&Payments' opt button is checked ) 
''''in cashierwisereport form 
elseif ucase(Request.QueryString("strng"))="RECPAYTEMPDATAGENERATE" then
RepCode=3
		RepId=2	
		strwhcond=" and applicationdate='" & RepDate & "'"
		 rsacc=server.CreateObject("adodb.recordset")	
	''' a recordset for fetching the transaction details of Reciepts  from the
                '''CASHRECEIPTStrn or CASHRECEIPTSbkp table
                 RsReceipts = objQuery.SingleRecordSet("CASHRECEIPTS" & StrTabSuffix  & _
								" Cash", _
                                 "Cash.GLCODE,Cash.ACCNO,Cash.RECEIPTSCROLLNO,Cash.AMOUNT," & _
                                 "cash.moduleid,DECODE(cash.moduleid,'REM','Instr Issued',cash.name),cash.ACCBRANCHCODE", _
                                 "Cash.branchcode='" & BrCode & "' and " & _
                                 "Cash.currencycode='" & CurCode & "' and  " & _
                                 "Cash.CASHIERID ='" & CashId & "' " & _
                                 "" & strwhcond,"RECEIPTSCROLLNO")
                         staccname=""        
                
                dim AccBrCode 
                 
				If RsReceipts.RecordCount <> 0 Then
					
					For icnt = 0 To RsReceipts.RecordCount - 1
					if not isdbnull(RsReceipts(4).value)  and not isdbnull(RsReceipts(0).value) then
						
						AccBrCode = ""
						staccname=""
						staccname=iif(isdbnull(RsReceipts(5).value),"", _
						RsReceipts(5).value)
						AccBrCode = iif(isdbnull(RsReceipts(6).value),BrCode, _
						RsReceipts(6).value)
						
						if trim(staccname)="" then
							
							if trim(cstr(RsReceipts(4).value)) = "REM" then 
							staccname="Instr Issued"
							else
								rsacc = objQuery.SingleRecordSet( _
								cstr(RsReceipts(4).value) & "mst" , "name", _
                                "branchcode='" & AccBrCode & "' and " & _
                                "currencycode='" & CurCode & "' and  " & _
                                "glcode='" & RsReceipts(0).value & "' and " & _
                                "accno='" & RsReceipts(1).value & "'")
                                 
                                 if rsacc.RecordCount<>0 then
                                 staccname=""
									staccname=rsacc(0).value
									
                                end if
                            end if
                        end if  
                        
                        
                         
						 StrFldValues = StrFldValues &"'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & RsReceipts(2).value & "," & _
                                    "'" & RsReceipts(0).value & "','" & RsReceipts(1).value & "'," & _
                                    "'" & staccname & "'," & _
                                    "'RECEIPTS'," & _
                                    "" & RsReceipts(3).value & ",null," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
							
                     end if
                     RsReceipts.movenext              
                     
                    next
                    
                 End If 
               
    ''' a recordset for fetching the total Reciepts amount  from the
                '''CASHPAYMENTSStrn or CASHPAYMENTSbkp table
                 rsacc=server.CreateObject("adodb.recordset")	
                 RsPayments = objQuery.SingleRecordSet("CASHPAYMENTS" & StrTabSuffix & _
								" cash", _
								 "Cash.GLCODE,Cash.ACCNO,Cash.PAYMENTSCROLLNO," & _
								 "Cash.AMOUNT,Cash.moduleid,DECODE(cash.moduleid,'REM','Instr Paid',cash.name),cash.ACCBRANCHCODE", _
                                 "Cash.branchcode='" & BrCode & "' and " & _
                                 "Cash.currencycode='" & CurCode & "' and  " & _
                                 "Cash.CASHIERID='" & CashId & "'" & _
                                 "" & strwhcond, _
                                 "PAYMENTSCROLLNO")
                                
                 If RsPayments.RecordCount <> 0 Then
                    For icnt = 0 To RsPayments.RecordCount - 1
                    if not isdbnull(RsPayments(4).value)  and not isdbnull(RsPayments(0).value) then
					AccBrCode=""
                    staccname=""
                    staccname=iif(isdbnull(RsPayments(5).value),"", _
                    RsPayments(5).value)
					AccBrCode = iif(isdbnull(RsPayments(6).value),BrCode, _
					RsPayments(6).value)
                    
                    if trim(staccname)="" then 

						if trim(cstr(RsPayments(4).value)) = "REM" then 
							staccname="Instr Paid"
						else
							rsacc = objQuery.SingleRecordSet(cstr(RsPayments(4).value) & _
							"mst" , _
								 "name", _
                                 "branchcode='" & AccBrCode & "' and " & _
                                 "currencycode='" & CurCode & "' and  " & _
                                 "glcode='" & (RsPayments(0).value) & "' and " & _
                                 "accno='" & (RsPayments(1).value) & "'")
                                 
                                 if rsacc.RecordCount<>0 then
                                 staccname=""
									staccname=rsacc(0).value
									
                                 end if
                           end if
                    end if      
                    
                    StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
                                    "'" & CashId & "'," & RsPayments(2).value & "," & _
                                    "'" & RsPayments(0).value & "','" & RsPayments(1).value & "'," & _
                                    "'" & staccname & "','PAYMENTS'," & _
                                    "null," & RsPayments(3).value & "," & _
                                    "to_date('" & RepDate & "','dd-mm-yyyy')," & _
                                    "'" & repcode & "','" & repid & "','" & RepDate & "'" & "|"
                      end if         
                      RsPayments.MoveNext
                      
                    NEXT 
                 End If 
         if StrFldValues="" then
		Response.Redirect ("cashierwisereport.aspx?record=" & "No Transactions on selected Date")
		end if 
    StrFldValues=left(StrFldValues,len(StrFldValues)-1)  
       rsacc=nothing                       
	''''''****************Setting the TransactionComponent****************
	 ObjTran = SERVER.CreateObject("GeneralTransactions.DBTransactions")
 '''checking for recors are already exists in the cashreporttemp table for given
 '''cashierid,branchcode,currencycode,date
 ''' a recordset for fetching the total Reciepts amount  from the
                '''CASHPAYMENTSStrn or CASHPAYMENTShist table
           '"REPORTQUERYDATE='" & RepDate & "' and " & _    
                StrDelCondition="branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "CASHIERID='" & CashId & "' and " & _
                                        "reportcode='" & repcode & "' and " & _
                                        "reportid='" & repid & "'" 
                                       
                                    
                 Rstemp = objQuery.SingleRecordSet(cstr(StrTabName),"*", _
							cstr(StrDelCondition))
                                        
                 If Rstemp.RecordCount <> 0 Then
                 	StrDelstatus="DELETE"
                 End If   
		''storing values for insert table(CASHREPORTTEMP) for inserting
         
           StrFldNames = "BRANCHCODE,CURRENCYCODE,CASHIERID,Scrollno,glcode,accno,name," & _
                        "MODEOFTRAN,CREDIT,DEBIT,REPORTQUERYDATE," & _
                        "reportcode,reportid,applicationdate"	
                     
           ''''-------------------------------------------------------------------------------
				if strDelstatus="DELETE" then
					''''if status mode 'DELETE' 
					redim ArrTran(1,4)
					ArrTran(0,0)="D"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=""					'passing the FieldNames
					ArrTran(0,3)=""					'passing the Fieldvalues
					ArrTran(0,4)=StrDelCondition
					ArrTran(1,0)="I"				'passing the TransactionType
					ArrTran(1,1)=StrTabName			'passing the tablename
					ArrTran(1,2)=StrFldNames		'passing the FieldNames
					ArrTran(1,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(1,4)=""
					
				else
				''''if status mode is null
					redim ArrTran(0,4)
					ArrTran(0,0)="I"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=StrFldNames		'passing the FieldNames
					ArrTran(0,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(0,4)=""
					
				end if       
           ''calling componenet method
          
			Strmsg= ObjTran.DataTransactions(ArrTran)
			Response.Write (sTRMSG)
			 Objtran=nothing
	'''CALLING report templatepage 
	IF STRMSG="Transaction Sucessful." then
		
		'''''setting parameter string which is send to report template page
		'''this parameters are used in where condition to fetch the data from the
		''cashreporttemp table with the format of operator,value 
		StrRepCondition= "=" & "|<" &  "'" & BrCode & "'" & "|<!~" &   _		
					 "=" & "|<"  & "'" & CurCode & "'" & "|<!~" &  _		
					 "=" & "|<"  & "'" & CashId & "'" & "|<!~" &  _		
					"=" & "|<" & "'" & RepDate & "'"  	& "|<!~" & _	
					"=" & "|<" & "'" & Repcode & "'"  	& "|<!~" & _
					"=" & "|<" & "'" & RepId & "'"  	& "|<!~"  & _
					"RGT" & "|<sum(credit)-sum(debit)|<!~"  	
					'"GROUP" & "|<" & "SUM" & "|<" & "AMOUNT"  & "|<" & "MODEOFTRAN" & "!~"				
		StrMainFlds=BrCode & "^^" & CurCode & "^^" & RepDate & "^^" & _
		CashId &"^^" & RepCode &"^^" & RepId & "^^" & 	StrRepCondition	
		session("strMainFlds")=StrMainFlds
		if rep = "HTML" then
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx")
		else
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplateXL.aspx")
		end if
		
		'Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx?repstring="& _
						'StrMainFlds)
					
	end if
''''' for VaultPosition report(All option button checked) 
''''in cashierwisereport form 
'''for this report no inserting into temp table diectly using the cashvalutmst table 
elseif ucase(Request.QueryString("strng"))="ALLVAULTPOS"  or _
		ucase(Request.QueryString("strng"))="SINGLEVAULTPOS" then
	'''checking if cash is there in vault for selected branch	
		 RsTemp=objQuery.singlerecordset("cashvaultmst v,gencurrencytypemst c", _
						"v.currencycode,c.narration,v.totamount", _
						"v.currencycode=c.currencycode and " & _
						"v.branchcode='" & BrCOde &"'")
			if rstemp.BOF and  rstemp.EOF then
				Response.Redirect ("cashierwisereport.aspx?record=" &  _
									" Cash is not there Vault "	)
			end if
	'''''setting parameter string which is send to report template page
		'''this parameters are used in where condition to fetch the data from the
		''cashreporttemp table with the format of operator,value 
		if ucase(Request.QueryString("strng"))="ALLVAULTPOS" then
		if session("applicationdate")=RepVaultDate then
		RepCode=3
		RepId=3	
		StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~" &   _		
					 "=" & "|<"  & "c.currencycode" & "|<!~" 
		else
		RepCode=3
		RepId=9	
		StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~" &   _		
					 "=" & "|<"  & "c.currencycode" & "|<!~"& _
							"=" & "|<"  & "(select max(systemdate) from cashvaultmsthist where " & _
							" applicationdate<='" & RepVaultDate & "' and branchcode='" & BrCode & "')" & _
							"" & "|<!~" 
		end if			 
					
		elseif ucase(Request.QueryString("strng"))="SINGLEVAULTPOS" then
			if session("applicationdate")=RepVaultDate then
			RepCode=3
			RepId=4
			StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~" &   _		
							"=" & "|<"  & "c.currencycode" & "|<!~" & _
							"=" & "|<"  & "'" & CurCode & "'" & "|<!~" 
				Response.Write (StrRepCondition	)
			else
			RepCode=3
			RepId=8
			StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~" &   _		
							"=" & "|<"  & "c.currencycode" & "|<!~" & _
							"=" & "|<"  & "'" & CurCode & "'" & "|<!~"  & _
							"=" & "|<"  & "(select max(systemdate) from cashvaultmsthist where " & _
							" applicationdate<='" & RepVaultDate & "' and branchcode='" & BrCode & "' and " & _
							" currencycode='" & CurCode & "')" & "|<!~"
				Response.Write (StrRepCondition	)
			end if			
		end if				 	
					 
		StrMainFlds=BrCode & "^^" & CurCode & "^^" & RepVaultDate & "^^" & _
		CashId &"^^" & RepCode &"^^" & RepId & "^^" & 	StrRepCondition	
				
		Session("strMainFlds")=StrMainFlds
		if rep = "HTML" then
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx")
		else
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplateXL.aspx")
		end if
		'Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx?repstring=" & _
						'StrMainFlds	)

''''' for VaultCash report in cashierwisereport form
elseif ucase(Request.QueryString("strng"))="SINGLEVAULTCASH"  or _
		ucase(Request.QueryString("strng"))="ALLVAULTCASH" then
	'calling denominations component to disaplay the denominationcode,value
				 obj=server.CreateObject("cashquery.queries")
			
			StrFldNames="BRANCHCODE,CURRENCYCODE,AMOUNT,REPORTQUERYDATE," & _
						"REPORTCODE,REPORTID,DENOMINATIONVALUE," & _
						"DENOMINATIONSYMBOL,NOOFPIECES,AMOUNTSYMBOL,DENOMINATIONTYPE,applicationdate"		
''' for single currencycode 
	if ucase(Request.QueryString("strng"))="SINGLEVAULTCASH"  then
	pres=Request.Form("hpr")
	
			RepCode=3
			RepId=5	
			StrDelstatus=""
		'''delete denomination details from the repcashtemp table if existing
		StrDelCondition="branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and  " & _
                                        "reportcode='" & repcode & "' and " & _
                                        "reportid='" & repid & "'" 
     RsCurrency=objQuery.singlerecordset("GENCURRENCYTYPEMST", _
		"PRECISION","currencycode='" & CurCode &"'")	
			if not RsCurrency.EOF and not RsCurrency.BOF then
				pres=rscurrency(0).value
			end if
			
        ''calling general denomination component method
        if  session("applicationdate")=RepvaultDate then                               
		st=obj.CashDenominationsAsarray("cashvaultmst",cstr(BrCode),cstr(CurCode))
		else
		st=obj.CashDenominationsAsarray("cashvaultmst",cstr(BrCode),cstr(CurCode),cstr(RepvaultDate))	
		end if
		'st=obj.CashInEachBranch(cstr(BrCode),cstr(CurCode))
		
			''''storing the denomination details with currencycode in repcashtemp table
			for icnt=0 to ubound(st)
			  if not isdbnull(st(icnt,2)) then
				if 1=2 then
				amt=cdbl(st(icnt,0))*cdbl(st(icnt,1))
				'''checking the denomination as coins or notes  and stroing it in varaibles
				'''for inserting
				strpres=split(cstr(st(icnt,0)),".")
				if ubound(strpres)>0 then
					denomtype="Coins"
					strpresval=toPrecision(cstr(st(icnt,0)))
					else
					denomtype="Notes"
					strpresval=cstr(st(icnt,0))
					end if
				end if	
					if st(icnt,0)="NF" then
						denomtype="Notes"
						amt=cdbl(st(icnt,1))*cdbl(st(icnt,2))
					elseif st(icnt,0)="CF"  then
					amt=cdbl(st(icnt,1))*cdbl(st(icnt,2))
						denomtype="FullCoin"
					elseif  st(icnt,0)="CP" then
						denomtype="Coin"
						''''amt=cdbl(st(icnt,0))/pres * cdbl(st(icnt,1))
						amt=cdbl("0." & st(icnt,1))* cdbl(st(icnt,2))
						if st(icnt,1)<10 then
						amt=cdbl("0.0" & st(icnt,1))* cdbl(st(icnt,2))
						end if
					end if	
						
						
				
				'StrFldValues = StrFldValues & "'" & BrCode &"','" & CurCode &"'," & _
								'"" & amt &",to_Date('" & RepVaultDate &"','dd-mm-yyyy')," & _
								'"'" & RepCode &"','" & RepId &"','" & strpresval &"'," & _
								'"'*'," & st(icnt,1) &",'=','" & denomtype &"','"&RepvaultDate&"'" & "|"
				StrFldValues = StrFldValues & "'" & BrCode &"','" & CurCode & "'," & _
								"" & amt & ",to_Date('" & RepVaultDate & "','dd-mm-yyyy')," & _
								"'" & RepCode & "','" & RepId & "','" & st(icnt,1) &"'," & _
								"'*','" & st(icnt,2) & "','=','" & denomtype & "','" & RepvaultDate & "'" & "|"				
				vaultst="YES"					
			  end if	
			next
			if vaultst="YES" then
				StrFldValues=left(StrFldValues,len(StrFldValues)-1)
			end if
			
	 end if					 
''''for multiple currenccy					 
	if ucase(Request.QueryString("strng"))="ALLVAULTCASH" then
		RepCode=3
		RepId=6
		StrDelstatus=""
		
	'''delete denomination details from the repcashtemp table if existing
		StrDelCondition="branchcode='" & BrCode & "' and " & _
                                    "reportcode='" & repcode & "' and " & _
                                      "reportid='" & repid & "'" 
                                      
    '''for multiplae currency fetch all currency from gencurrencttypemst
                                      			
		 RsCurrency=objQuery.singlerecordset("GENCURRENCYTYPEMST c,cashvaultmst V", _
						"distinct(v.CURRENCYCODE),c.PRECISION","v.currencycode=c.currencycode and " & _
						"v.branchcode='" & BrCode & "'")	
			if not RsCurrency.EOF and not RsCurrency.BOF then
			
			  do until RsCurrency.EOF
					''calling general denomination component method  
		 if  session("applicationdate")=RepvaultDate then  			                              
		st=obj.CashDenominationsAsarray("cashvaultmst",cstr(BrCode),cstr(RsCurrency(0).value))
		else
		st=obj.CashDenominationsAsarray("cashvaultmst",cstr(BrCode),cstr(RsCurrency(0).value),cstr(RepvaultDate))	
		end if
		'st=obj.CashInEachBranch(cstr(BrCode),cstr(RsCurrency(0)))
			''''storing the denomination details with currencycode in repcashtemp table
			
			for icnt=0 to ubound(st)
			  if  not isdbnull(st(icnt,2))  then
			 if st(icnt,0) <> "" then
				amt=cdbl(st(icnt,1))*cdbl(st(icnt,2))
				if 1=2 then
				amt=cdbl(st(icnt,0))*cdbl(st(icnt,1))
				'''checking the denomination as coins or notes  and stroing it in varaibles
				'''for inserting
				strpres=split(cstr(st(icnt,0)),".")
				if ubound(strpres)>0 then
					denomtype="Coins"
					strpresval=toPrecision(cstr(st(icnt,0)))
					else
					denomtype="Notes"
					strpresval=cstr(st(icnt,0))
					end if
				end if	
				''for denominationtype as notefull or coinfull or coinpaise
					if st(icnt,0)="NF" then
							denomtype="Notes"
					elseif st(icnt,0)="CF"  then
							denomtype="FullCoin"
					elseif  st(icnt,0)="CP" then
							denomtype="Coin"
					amt= cdbl(st(icnt,1))/cdbl(RsCurrency(1).value) * cdbl(st(icnt,2))	
							
					  end if
					  		
				'StrFldValues = StrFldValues & "'" & BrCode &"','" & RsCurrency(0) &"'," & _
								'"" & amt &",to_Date('" & RepVaultDate &"','dd-mm-yyyy')," & _
								'"'" & RepCode &"','" & RepId &"','" & st(icnt,0) &"'," & _
								'"'*'," & st(icnt,1) &",'=','" & denomtype &"','"&RepvaultDate&"'" & "|"
				StrFldValues = StrFldValues & "'" & BrCode & "','" & RsCurrency(0).value & "'," & _
								"" & amt & ",to_Date('" & RepVaultDate &"','dd-mm-yyyy')," & _
								"'" & RepCode & "','" & RepId & "','" & st(icnt,1) & "'," & _
								"'*','" & st(icnt,2) & "','=','" & denomtype & "','" & RepvaultDate & "'" & "|"				
				vaultst="YES"	
				end if				
			  end if	
			next
				
			  rsCurrency.MoveNext
			  loop	
			end if
			if vaultst="YES" then
				StrFldValues=left(StrFldValues,len(StrFldValues)-1)
			end if						
	end if
	
		''''  delete the existing denomination detail rows from the repcashtemp atbel
		 Rstemp = objQuery.SingleRecordSet(cstr(StrTabName),"*", _
							cstr(StrDelCondition))
                                        
                 If Rstemp.RecordCount <> 0 Then
                 	StrDelstatus="DELETE"
                 End If  
			if StrDelstatus="DELETE" then
			
				redim ArrTran(1,4)
					ArrTran(0,0)="D"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=""					'passing the FieldNames
					ArrTran(0,3)=""					'passing the Fieldvalues
					ArrTran(0,4)=StrDelCondition
					ArrTran(1,0)="I"				'passing the TransactionType
					ArrTran(1,1)=StrTabName			'passing the tablename
					ArrTran(1,2)=StrFldNames		'passing the FieldNames
					ArrTran(1,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(1,4)=""
			else
			
				redim ArrTran(1,4)
					ArrTran(0,0)="I"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=StrFldNames		'passing the FieldNames
					ArrTran(0,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(0,4)=""
			end if		
				
				Response.Write 	(ArrTran(0,0) & "<br>")
				Response.Write (ArrTran(0,1) & "<br>")
				Response.Write (ArrTran(0,2) & "<br>")
				Response.Write (ArrTran(0,3) & "<br>")
				Response.Write (ArrTran(0,4) & "<br>")
				Response.Write (ArrTran(1,0) & "<br>")
				Response.Write (ArrTran(1,1) & "<br>")
				Response.Write (ArrTran(1,2) & "<br>")
				Response.Write (ArrTran(1,3) & "<br>")
				Response.Write (ArrTran(1,4) & "<br>")
				
			''calling componenet method
		Strmsg= ObjTran.DataTransactions(ArrTran)
			 Objtran=nothing
			Response.Write (Strmsg)
		'''CALLING report templatepage 
	IF STRMSG="Transaction Sucessful." then
		if ucase(Request.QueryString("strng"))="ALLVAULTCASH" then
			RepCode=3
			RepId=6	
		StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~" & _
						"=" & "|<" &"'" &  RepCode & "'" & "|<!~" & _
						"=" & "|<" &"'" &  RepId & "'" & "|<!~" 
		 		
			 Response.Write (StrRepCondition)
		elseif ucase(Request.QueryString("strng"))="SINGLEVAULTCASH"  then
				RepCode=3
				RepId=5	
			StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~"  & _
							"=" & "|<" &"'" &  CurCode & "'" & "|<!~"  & _		
							"=" & "|<" &"'" &  RepCode & "'" & "|<!~" & _
							"=" & "|<" &"'" &  RepId & "'" & "|<!~" 
					 Response.Write (StrRepCondition)
		end if
		StrMainFlds=BrCode & "^^" & CurCode & "^^" & RepVaultDate & "^^" & _
		CashId &"^^" & RepCode &"^^" & RepId & "^^" & 	StrRepCondition	
		'Response.Write (StrRepCondition)
		session("strMainFlds")=StrMainFlds
		if rep = "HTML" then
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx")
		else
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplateXL.aspx")
		end if
		'Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx?repstring=" & _
		'				StrMainFlds	)
	end if
	
'''for consolidated reciepts & payments cashier report
elseif ucase(Request.QueryString("strng"))="CONSCASHIER" then
	RepCode=3
	RepId=7
	 RsReceipts=objQuery.SingleRecordSet("CASHRECEIPTS" & StrTabSuffix, _
                                        "Cashierid,Count(*),sum(Amount)", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and " & _
                                        "applicationdate='" & RepVaultDate & "'  GROUP BY Cashierid ")
      if not RsReceipts.eof  and not RsReceipts.bof then
       if trim(RsReceipts(0).value)<>"" then
		do until RsReceipts.eof
			StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
				"'" & RsReceipts(0).value & "'," & RsReceipts(2).value & ",null," & _
				"" & RsReceipts(1).value  & "," & _
				"to_Date('" & RepVaultDate & "','dd-mm-yyyy')," & _
				"'" & RepCode & "','" & RepId & "','" & RepVaultDate & "'" & "|"
		RsReceipts.movenext
		loop
	   end if					
      end if
      RsPayments=objQuery.SingleRecordSet("CASHPAYMENTS" & StrTabSuffix, _
                                        "Cashierid,Count(*),sum(Amount)", _
                                        "branchcode='" & BrCode & "' and " & _
                                        "currencycode='" & CurCode & "' and " & _
                                        "applicationdate='" & RepVaultDate & "' GROUP BY Cashierid ")
              If RsPayments.RecordCount <> 0 Then
				if trim(RsPayments(0).value)<>"" then
				do until RsPayments.EOF
				StrFldValues = StrFldValues & "'" & BrCode & "','" & CurCode & "'," & _
				"'" & RsPayments(0).value & "',null," & RsPayments(2).value & "," & _
				"" & RsPayments(1).value  & "," & _
				"to_Date('" & RepVaultDate & "','dd-mm-yyyy')," & _
				"'" & RepCode & "','" & RepId & "','" & RepVaultDate & "'"  & "|"
				RsPayments.MoveNext
				loop
				end if				
             end if 
             if StrFldValues<>"" then
     StrFldValues=left(StrFldValues,len(StrFldValues)-1) 
     else
     Response.Redirect ("cashierwisereport.aspx?record=" & "No Transactions on selected Date")
     end if                                          
	 StrFldNames = "BRANCHCODE,CURRENCYCODE,CASHIERID," & _
                        "CREDIT,DEBIT,NOOFTRANS,REPORTQUERYDATE," & _
                        "reportcode,reportid,applicationdate"
    '''delete Consolidated receipts,payments details from the repcashtemp table if existing
    '"REPORTQUERYDATE='" & RepvaultDate & "' and " & _
		StrDelCondition="branchcode='" & BrCode & "' and " & _
                                      "reportcode='" & repcode & "' and " & _
                                      "reportid='" & repid & "'"                    
      ''''  delete the existing denomination detail rows from the repcashtemp atbel
		 Rstemp = objQuery.SingleRecordSet(cstr(StrTabName),"*", _
							cstr(StrDelCondition))
                                        
                 If Rstemp.RecordCount <> 0 Then
                 	StrDelstatus="DELETE"
                 End If  
			if StrDelstatus="DELETE" then
				redim ArrTran(1,4)
					ArrTran(0,0)="D"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=""					'passing the FieldNames
					ArrTran(0,3)=""					'passing the Fieldvalues
					ArrTran(0,4)=StrDelCondition
					ArrTran(1,0)="I"				'passing the TransactionType
					ArrTran(1,1)=StrTabName			'passing the tablename
					ArrTran(1,2)=StrFldNames		'passing the FieldNames
					ArrTran(1,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(1,4)=""
			else
				redim ArrTran(0,4)
					ArrTran(0,0)="I"				'passing the TransactionType
					ArrTran(0,1)=StrTabName			'passing the tablename
					ArrTran(0,2)=StrFldNames		'passing the FieldNames
					ArrTran(0,3)=StrFldValues		'passing the Fieldvalues
					ArrTran(0,4)=""
			end if		
			Response.Write 	(StrFldValues)
			''calling componenet method
			Strmsg= ObjTran.DataTransactions(ArrTran)
			 Objtran=nothing
			Response.Write (Strmsg)
          '''CALLING report templatepage 
	IF STRMSG="Transaction Sucessful." then
		
			StrRepCondition= "=" & "|<" &"'" &  BrCode & "'" & "|<!~"  & _
							"=" & "|<" &"'" &  CurCode & "'" & "|<!~"  & _
							"=" & "|<" &"'" &  RepvaultDate & "'" & "|<!~"  & _		
							"=" & "|<" &"'" &  RepCode & "'" & "|<!~" & _
							"=" & "|<" &"'" &  RepId & "'" & "|<!~" 
					 
		StrMainFlds=BrCode & "^^" & CurCode & "^^" & RepDate & "^^" & _
		CashId &"^^" & RepCode &"^^" & RepId & "^^" & 	StrRepCondition	
		session("strMainFlds")=StrMainFlds
		
		if rep = "HTML" then
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx")
		else
			Response.Redirect ("http://" & session("moduledir") & "/ReportTemplateXL.aspx")
		end if
		'Response.Redirect ("http://" & session("moduledir") & "/ReportTemplate.aspx?repstring="& _
		'				StrMainFlds)
	end if						              				             	
end if		
	

	
		                     
  
  
  
%>

