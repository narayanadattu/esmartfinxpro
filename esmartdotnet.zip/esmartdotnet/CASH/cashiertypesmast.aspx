<%@ Page CodeBehind="cashiertypesmast.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashiertypesmast" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Single Record Entry</title>
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var st,val,flag
function branch()
{
    
	window.document.frmcashiertype.txtbranchdesc.value=""
	window.document.frmcashiertype.txtcurrencycode.value=""
	window.document.frmcashiertype.txtcurrencydesc.value=""
	window.document.frmcashiertype.txtcashiertype.value=""
	window.document.frmcashiertype.txtnarration.value=""
	st="Branch"
	
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
    
    			
}	 
// To assign the values for the respective branch related text boxes
function Branchid(kstr)
{
	assign(kstr,window.document.frmcashiertype.txtbranchdesc,window.document.frmcashiertype.txtbranchcode)
}	 
// To get the values for the currencycode

// To assign the values for the respective branch related text boxes

function Branchid(kstr)
{
	assign(kstr,window.document.frmcashiertype.txtbranchdesc,window.document.frmcashiertype.txtbranchcode)
}	 
// To get the values for the currencycode

function currency()
{

	
	window.document.frmcashiertype.txtcashiertype.value=""
	window.document.frmcashiertype.txtnarration.value=""
	st="Currency"
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
}

// To assing the values for the respective currency related text boxes
function Currencyid(kstr)
{
assign(kstr,window.document.frmcashiertype.txtcurrencydesc,window.document.frmcashiertype.txtcurrencycode)
}


function query()
{
	stc=window.document.frmcashiertype.txtbranchcode.value
	stb=window.document.frmcashiertype.txtcurrencycode.value 
	st="cashiertypes"+"|"+stc+"|"+stb
	
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	
 
}

function cashiertypes(kstr)
{
	
   k=kstr.split("-----")
   st=k[1]
   window.document.frmcashiertype.txtcashiertype.value=k[1]
   window.document.frmcashiertype.txtnarration.value=k[0]
   
   callfl()
   
}


function callfl()
{
	var sCash=window.document.frmcashiertype.txtcashiertype.value
	st=sCash+"~CashierDetails"
	//window.open("cashmasterfly.aspx"+ "?"+"st="+st,"cashier","width=1,height=1,left=0,top=0")
		//Window.document.all["iBatch"].src="cashmasterfly.aspx"
		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashmasterfly.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
}

function flycash(kstr)
{
   k=kstr.split("|")
   window.document.frmcashiertype.cmbpayments.value=k[0]
   window.document.frmcashiertype.cmbreceipts.value=k[1]
   window.document.frmcashiertype.cmbtellerreceipts.value=k[2]
   window.document.frmcashiertype.cmbtellerpayments.value=k[3]
   
}

function rdentry_onclick()
 {
   
   if(window.document.frmcashiertype.rdentry(3).checked==true)
   {
     query()
     with(window.document.frmcashiertype)
         {
           butok.disabled=true
           txtcashiertype.readOnly=true
           txtnarration.readOnly=true
           cmbreceipts.disabled=true
		   cmbpayments.disabled=true
		   cmbtellerpayments.disabled=true
		   cmbtellerreceipts.disabled=true
         }  
    
     
   } 
   else if(window.document.frmcashiertype.rdentry(0).checked==true)
   { 
    
     with(window.document.frmcashiertype)
     {   
        txtcashiertype.value=""
        txtnarration.value=""
        txtcashiertype.readOnly=false
        txtnarration.readOnly=false
        txtcashiertype.focus()
        butok.disabled=false
        txtcashiertype.focus()
        cmbreceipts.disabled=false
		cmbpayments.disabled=false
		cmbtellerpayments.disabled=false
		   cmbtellerreceipts.disabled=false
     }   
        
   } 
   else if(window.document.frmcashiertype.rdentry(1).checked==true)
   {    
        window.document.frmcashiertype.txtcashiertype.value=""
        window.document.frmcashiertype.txtnarration.value=""
        window.document.frmcashiertype.cmbpayments.value="N"
        window.document.frmcashiertype.cmbreceipts.value="N"
        query()
        
        with(window.document.frmcashiertype)
        {
		   butok.disabled=false
		   txtcashiertype.readOnly=true
		   txtnarration.readOnly=false
		   cmbreceipts.disabled=false
		   cmbpayments.disabled=false
		   cmbtellerpayments.disabled=false
		   cmbtellerreceipts.disabled=false
		}   
   }		
  
  else if(window.document.frmcashiertype.rdentry(2).checked==true)
   {    
        window.document.frmcashiertype.txtcashiertype.value=""
        window.document.frmcashiertype.txtnarration.value=""
        window.document.frmcashiertype.cmbpayments.value="N"
        window.document.frmcashiertype.cmbreceipts.value="N"
        query()
        with(window.document.frmcashiertype)
        {
		   butok.disabled=false
		   fl=false
		   txtcashiertype.readOnly=true
		   txtnarration.readOnly=true
		   cmbreceipts.disabled=true
		   cmbpayments.disabled=true
		   cmbtellerpayments.disabled=true
		   cmbtellerreceipts.disabled=true
		}   
    }		
  } 

function butok_onclick() 
{
  if(window.document.frmcashiertype.rdentry(0).checked==true)
  { 
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
		stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="INSERT"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
	}
  }
  else if(window.document.frmcashiertype.rdentry(1).checked==true)
  {
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
    stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="MODIFY"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
		
		//Window.document.all["iBatch"].src="cashmastersinsert.aspx?strng="+stt
		
		
	}
  }
  else if(window.document.frmcashiertype.rdentry(2).checked==true)
  { 
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
		stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="DELETE"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
	}
  }

}


function butcancel_onclick()
 {
   location.replace("cashiertypesmast.aspx")
 }

/*function butexit_onclick() 
{
   //location.replace("blankcash.aspx")
    window.parent.window.location.replace("MASTERmodule.aspx")
}*/

function txtcashiertype_onkeypress()
 {
   if((window.document.frmcashiertype.txtcashiertype.value).length>20)
   event.keyCode=0
 }
 
function txtnarration_onkeypress() 
{
   if((window.document.frmcashiertype.txtnarration.value).length>40)
   event.keyCode=0
}

function DescrptionDisp(strTxt)
 {
		sBr=window.document.frmcashiertype.txtbranchcode.value.toUpperCase()
		sCur=window.document.frmcashiertype.txtcurrencycode.value.toUpperCase()
		sCash=window.document.frmcashiertype.txtcashiertype.value.toUpperCase()

	//for cashier description 
if(strTxt=="txtbranchcode")
{
		window.document.frmcashiertype.txtbranchdesc.value=""
		window.document.frmcashiertype.txtcurrencycode.value=""
		window.document.frmcashiertype.txtcurrencydesc.value=""
		window.document.frmcashiertype.txtcashiertype.value=""
		window.document.frmcashiertype.txtnarration.value=""
	if(window.document.frmcashiertype.txtbranchcode.value=="")
		{
			return;
		}


		st="GENBANKBRANCHMST"+"~"+"BRANCHNAME"+
			"~"+"branchcode='"+sBr+"'"+
			"~"+strTxt+"~"+"DescDisplay"
 }
	//for cashier description 
if(strTxt=="txtcurrencycode")
{

			window.document.frmcashiertype.txtcurrencydesc.value=""
			window.document.frmcashiertype.txtcashiertype.value=""
			window.document.frmcashiertype.txtnarration.value=""
		if(window.document.frmcashiertype.txtbranchcode.value=="")
		{
		alert("Select BranchCode")
		return;
		}

	  if(window.document.frmcashiertype.txtcurrencycode.value=="")
	   {
	     return;
	   }

		st="GENCURRENCYTYPEMST"+"~"+"narration"+
			"~"+"currencycode='"+sCur+"'"+
			"~"+strTxt+"~"+"DescDisplay"
}
///for duplicate cashier checking
 if(strTxt=="CashierCheck")
		{
			st="CASHCASHIERTYPEMST"+"~"+"CASHIERTYPEID"+
			"~"+"branchcode='"+sBr+"' and currencycode='"+sCur+"' and "+
			"CASHIERTYPEID='"+sCash+"'"+
			"~"+strTxt+"~"+"DescDisplay"	
		}

//post to ifrmae page to get desciptions
		
		Window.document.all["iBatch"].src="counter.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="counter.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
}


///function for sending parameters to display the description on blur event
 ///displaying the counterno
function Allot(kstr)
{

	var StrMainFld=new String()
	StrMainFld=kstr.split("~")
	StrFlds=StrMainFld[0].split("|")
	
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtbranchcode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid BranchCode ")
			window.document.frmcashiertype.txtbranchcode.value=""
			window.document.frmcashiertype.txtbranchdesc.value=""
			return;
		}
		window.document.frmcashiertype.txtbranchdesc.value=StrFlds[0]
		
		
	}
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtcurrencycode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid CurrencyCode ")
			window.document.frmcashiertype.txtcurrencycode.value=""
			window.document.frmcashiertype.txtcurrencydesc.value=""
			return;
		}
		window.document.frmcashiertype.txtcurrencydesc.value=StrFlds[0]
	
	}
	///for duplicate cashiers checking
	if(StrMainFld[1]=="CashierCheck")
	{
		if(StrFlds[0]!="No")
		{
			alert("Cashier Type Already exists ")
			window.document.frmcashiertype.txtcashiertype.value=""
			window.document.frmcashiertype.txtnarration.value=""
			return;
		}
	}
}


///function for checking the login user is abb or not 
  function abbcheck()
	 {
		
		AbbStatus="<%=session("abbuser")%>"
		
		if(AbbStatus.toUpperCase()=="Y")
		{
		window.document.frmcashiertype.buttbr.disabled=false
		window.document.frmcashiertype.txtbranchcode.readOnly=false
		window.document.frmcashiertype.buttbr.focus()
		}
		else
		{
		window.document.frmcashiertype.buttbr.disabled=true
		window.document.frmcashiertype.txtbranchcode.readOnly=true
		
		}
		
	}

	///function for checking the duplicate cashiers 
  function cashiercheck()
   {
    if(window.document.frmcashiertype.rdentry[0].checked==true)
     {
     DescrptionDisp("CashierCheck")
     }
   }
   
  
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	      alert(strtran)
		window.location.href="cashiertypesmast.aspx" 
		
	}
}	


//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="abbcheck();DispTranMsg()">

<form name="frmcashiertype">

  <input type="hidden" name="status">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tbody>
      <tr>
        <td width="100%" height="15"></td>
      </tr>
      <tr>
        <td width="100%" align="middle"><font face="MS Sans Serif" color="blue" size="2"><b></b></font></td>
      </tr>
      <tr>
        <td>
    </tbody>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
    <tr class="bgcolor">
    
    
      <td width="100%"><font class="text">&nbsp;&nbsp;&nbsp;Cashier Type</font></td>
    </tr>
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" colspan="4" height="16"></td>
        </tr>
        <tr class="bgcolor">
          <td width="20%">&nbsp;&nbsp;&nbsp;Branch Code</td>
          <td width="25%"><input name="txtbranchcode" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" value="<%=session("branchcode")%>" size="9" onblur='Dataarrange(txtbranchcode);DescrptionDisp("txtbranchcode")' 
          style="HEIGHT: 22px; WIDTH: 66px" class="txtautofill"><input type="button" value=" L " name="buttbr" style="HEIGHT: 23px" onclick="branch()" class="button"><input name="txtbranchdesc" value="<%=session("branchnarration")%>" size="16" readonly style="HEIGHT: 22px; WIDTH: 116px" class="bgcolor1"></td>
          
          <td width="22%">
          <p align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
          <td width="29%"><input name="txtcurrencycode" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" value="<%=session("currencycode")%>" onblur='Dataarrange(txtcurrencycode);DescrptionDisp("txtcurrencycode")' size="9"  style="HEIGHT: 22px; WIDTH: 66px" class="txtautofill"><input type="button" value=" L " name="buttcur" style="HEIGHT: 23px" onclick="currency()" class="button"><input name="txtcurrencydesc" value="<%=session("currencynarration")%>" size="16" readonly style="HEIGHT: 22px; WIDTH: 116px" class="bgcolor1"></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
        <tr class="bgcolor1">
          <td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" checked language="javascript" onclick="return rdentry_onclick()">
          New</font></td>
          <td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
          Modify</font></td>
          <td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
          Delete</font></td>
          <td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
          View</font></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="10"></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
              <tr>
                <td width="20%" height="10"></td>
                <td width="47%" height="10" colspan="4"></td>
                <td width="29%" align="left" height="10"></td>
              </tr>
              <tr>
                <td width="15%">&nbsp;&nbsp;Cashier Type&nbsp;&nbsp;</td>
                <td width="14%"><input size="12" name="txtcashiertype" 
                language="javascript" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onkeypress="return txtcashiertype_onkeypress()" onblur='Dataarrange(txtcashiertype);cashiercheck()' class="txtautofill"></td>
                <td width="19%" colspan="3">
                <p align="right">Narration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                </td>
                <td width="29%" align="left"><input name="txtnarration" 
                style="HEIGHT: 22px; WIDTH: 143px" 
                language="javascript" onblur='Dataarrange(txtnarration)' onkeypress="return txtnarration_onkeypress()" size="20"></td>
              </tr>
              <tr>
                <td width="20%" height="15"></td>
                <td width="47%" height="15" colspan="4"></td>
                <td width="29%" height="15"></td>
              </tr>
              <tr>
                <td width="15%">&nbsp;&nbsp;Receipts&nbsp;&nbsp;</td>
                <td width="14%"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbreceipts">
                  <option value="N" selected>N</option>
                  <option value="Y">Y</option>
                </select></td>
                <td width="19%" colspan="3">
                <p align="right">Payments&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                </td>
                <td width="29%" align="left"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbpayments">
                  <option value="N" selected>N</option>
                  <option value="Y">Y</option>
                </select></td>
              </tr>
              <tr>
                <td width="20%" height="15"></td>
                <td width="47%" height="15" colspan="4"></td>
                <td width="29%" height="15"></td>
              </tr>
              <tr>
                <td width="15%">&nbsp;&nbsp;Teller Receipts</td>
                <td width="14%"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbtellerreceipts">
                  <option value="N" selected>N</option>
                  <option value="Y">Y</option>
                </select></td>
                <td width="19%" colspan="3">
                <p align="right">Teller Payments&nbsp;&nbsp;&nbsp;</p>
                </td>
                <td width="29%" align="left"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbtellerpayments">
                  <option value="N" selected>N</option>
                  <option value="Y">Y</option>
                </select></td>
              </tr>
              <tr>
                <td width="20%" height="10"></td>
                <td width="14%" height="10"></td>
                <td width="14%" height="10"></td>
                <td width="7%" height="10"></td>
                <td width="12%" height="10"></td>
                <td width="29%" align="left" height="10"></td>
              </tr>
            </table>

            </center>
          </div>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="10"></td>
            </tr>
            <tr>
              <td width="100%" height="20"></td>
            </tr>
            <tr>
              <td width="100%" height="22"></td>
            </tr>
            <tr>
              <td width="100%" height="25"></td>
            </tr>
            <tr>
              <td width="100%">
              <div align="center">
                <center>

                <table border="0" width="10%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td width="100%"><input type="button" value="    Ok    " 
                    name="butok" language="javascript" onclick="return butok_onclick()" 
                    class="button"><input type="button" value="Cancel" name="butcancel" 
                    language="javascript" onclick="return butcancel_onclick()" 
                    class="button"><!--<input type="button" value="   Exit   " name="butexit" language="javascript" onclick="return butexit_onclick()" class="bgcolor">--></td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" height="25"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <table>
    <tr>
      <td width="100%"></td>
    </tr>
    <tr>
      <td width="100%"></td>
    </tr>
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="CashMasterFly.aspx">
                                              </iframe>
          </td>
        </tr>
      </table>

      </td>
    </tr>
    </form>

<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

  </table>

</body>

