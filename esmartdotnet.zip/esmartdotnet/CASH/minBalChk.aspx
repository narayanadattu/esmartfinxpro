<%@ Page Language="vb" CodeBehind="minBalChk.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.minBalChk" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
 function results(){
        var strM=window.document.frmacc.strmod.value
        if(strM=="MIN"){
       // Bal=window.document.frmacc.mBal.value  
       // window.attachEvent(window.opener.MinBalVerify(Bal))
        }
        else if(strM=="CHQN"){
        strChq=window.document.frmacc.chqNo.value
        window.attachEvent(window.opener.ChqVerification(strChq))
        }
        else if(strM=="CHQS"){
        ChqSrs=window.document.frmacc.chqSer.value
        window.attachEvent(window.opener.ChqSerVerification(ChqSrs))
        }
        else if(strM=="DEPMST"){
        dpParam=window.document.frmacc.dParam.value 
        window.attachEvent(window.opener.Depmstvals(dpParam))
        }
        else if(strM=="DTVL"){
        ChqVldDt=window.document.frmacc.chqDt.value
        window.attachEvent(window.opener.ChqDateVerify(ChqVldDt))
        }
        else if(strM=="DELTR"){
        Reslt=window.document.frmacc.detBat.value 
        window.attachEvent(window.opener.DelTempTranslog(Reslt))
        }
 
        else if(strM=="CASHGL"){
        CGlcode=window.document.frmacc.gCode.value
        window.attachEvent(window.opener.CshCode(CGlcode))
        }
        else if(strM=="ABBGL"){
        abbglcode=window.document.frmacc.abb.value
        window.attachEvent(window.opener.abbcode(abbglcode))
        }
        else if(strM=="loantrantype"){
        loantrantype=window.document.frmacc.ltrn.value 
        window.attachEvent(window.opener.funfillloantrantype(Reslt))
        }
        else if(strM=="DEPPARAMS"){
        dpParam=window.document.frmacc.dParam.value 
        window.attachEvent(window.opener.depParam(dpParam))
        }
        //for IneardClearings
        else if(strM=="CLGTypes"){
        ClearType=window.document.frmacc.dClear.value 
        window.attachEvent(window.opener.CLGTypes(ClearType))
        }
        else if(strM=="RPLMT"){
        recLmt=window.document.frmacc.rplmt.value 
        window.attachEvent(window.opener.PayLimit(recLmt))
        }
        window.close()
  }
//-->
</SCRIPT>

<%Dim strMod,strVal,mode,batNo
strMod=Request.QueryString("strparam")
       strVal=Split(strMod,"~")
       mode=strVal(0)
       
select case mode

'------------------------------------------------    
case "MIN"  
                
  		'set recMod=server.CreateObject("adodb.recordset")   
		'set Obj=Server.CreateObject("GeneralTranQueries.TransactionQueries")
		'set recMod =obj.ModuleParameters(cstr(trim(strVal(1))),cstr(trim(strVal(2))),cstr(trim(strVal(3))))
		   
		'  recMod.filter="(ACCOUNTTYPE)='WithoutCheque'"
		'		if recMod.RecordCount>0 then 
		'			 counterno=recMod("MINBALANCE")
		'		else
		'			 counterno=""
		'		end if
		'   set obj=nothing
'------------------------------------------------      
case "DEL"
       Dim ArrTrans(0,4),objDel,strWhCond,strDel
           batNo=strVal(1)
       set objDel=server.CreateObject("GeneralTransactions.DBTransactions")
            strWhCond="batchno='" & trim(batNo) & "'"
	        ArrTrans(0,0)="D"     
			ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
			ArrTrans(0,2)=""  
			ArrTrans(0,3)=""
			ArrTrans(0,4)=strWhCond 'passing where condition 
            strDel=objDel.DataTransactions(ArrTrans) 'Deleting Record  
	        
	        set objDel=nothing
'------------------------------------------------         
case "CHQN"
       dim fldnms,WhrCond,strresult,blnChqNo
       fldnms="chqseriesno,chequeno"
       WhrCond="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
                cstr(trim(strVal(2))) & "' and moduleid='" & cstr(trim(strVal(3))) & _
                "' and glcode='" & cstr(trim(strVal(4))) & _
                "' and accno='" & cstr(trim(strVal(5))) & _
                "' and upper(chequeno)='" & cstr(ucase(trim(strVal(6)))) & _
                "' and status='A' and (stopstatus<>'S' OR stopstatus is null)" 
      
       set recChq=server.CreateObject("adodb.recordset")
       set objChq=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recChq=objChq.SingleRecordSet("GENCHEQUEDTLS",Cstr(fldnms),cstr(WhrCond))
                             
           if recChq.RecordCount>0 then
              blnChqNo="VALID"
              else
              blnChqNo="NOTVALID"
           end if  
       set objChq=nothing     
 '------------------------------------------------           
 case "CHQS"
        
       dim fldnames,WhrCnd,strrslt,blnChqSer
       fldnames="chqseriesno,chequeno"
       WhrCnd="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
                cstr(trim(strVal(2))) & "' and moduleid='" & cstr(trim(strVal(3))) & _
                "' and glcode='" & cstr(trim(strVal(4))) & _
                "' and accno='" & cstr(trim(strVal(5))) & _
                "' and upper(chqseriesno)='" & cstr(ucase(trim(strVal(6)))) & _
                "' and status='A' and (stopstatus<>'S' OR stopstatus is null) " 
      
       set recChqSer=server.CreateObject("adodb.recordset")
       set objChqSer=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recChqSer=objChqSer.SingleRecordSet("GENCHEQUEDTLS",Cstr(fldnames),cstr(WhrCnd))
                             
           if recChqSer.RecordCount>0 then
              blnChqSer="VALID"
              else
              blnChqSer="NOTVALID"
           end if  
       set objChqSer=nothing               
  '------------------------------------------------           
  case "DTVL"
 
       dim chqPrd,maxDt,fnlDt,dtDiff,chqDt,applDt,vldChqDt
       fldnames="chqvalidperiod"
       WhrCnd="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
                cstr(trim(strVal(2))) & "' and moduleid='" & cstr(trim(strVal(3))) & _
                "' and glcode='" & cstr(trim(strVal(4))) & "'"
        
       set recChqDt=server.CreateObject("adodb.recordset")
       set objChqDt=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recChqDt=objChqDt.SingleRecordSet("GENCHARGESPMT",Cstr(fldnames),cstr(WhrCnd))
                       
           if recChqDt.RecordCount>0 then
               chqPrd=recChqDt(0)
                    chqDt=trim(strVal(5))
                    y=year(chqDt)
                    m=month(chqDt)
                    d=day(chqDt)
                    chqDt=d&"-"&m&"-"&y
                        maxDt=dateadd("M",chqPrd,chqDt)
						yy=year(maxDt)
						mm=month(maxDt)
						dd=day(maxDt)
						fnlDt=dd&"-"&mm&"-"&yy
 applDt="04-07-2001"

			    if datediff("D",fnlDt,applDt)>1 then
		           vldChqDt="INVALID"
		        else
		           vldChqDt="VALID" 
			    end if
          end if  
          set objChqDt=nothing
  '------------------------------------------------ 
  case "DELTR"
       Dim Rslt
       Dim ArrTran(0,4),objDelete,strWhCnd,strDelete
           batNo=strVal(1)
       set objDelete=server.CreateObject("GeneralTransactions.DBTransactions")
            strWhCnd="batchno='" & trim(batNo) & "'"
	        ArrTran(0,0)="D"     
			ArrTran(0,1)="GENTEMPTRANSLOG" 'passing the table name
			ArrTran(0,2)=""  
			ArrTran(0,3)=""
			ArrTran(0,4)=strWhCnd 'passing where condition 
            strDelete=objDelete.DataTransactions(ArrTran) 'Deleting Record  
	        If strDelete="Transaction Sucessful." then
	           Rslt="DEL"&"|"&batNo
	           else
	           Rslt="Cannot Delete this Batch"
	        end if
	        set objDel=nothing  
  '------------------------------------------------  	    
  case "CASHGL"	        
       dim cfldnms,cWhrCond,cstrresult,GLcode
       fldnms="glcode,narration"
       WhrCond="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
                cstr(trim(strVal(2))) & "' and moduleid='CASH'"
                
       set recGL=server.CreateObject("adodb.recordset")
       set objGL=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recGL=objGL.SingleRecordSet("GENGLSHEETMST",Cstr(fldnms),cstr(WhrCond))
                             
           if recGL.RecordCount>0 then
              GLcode=recGL(0)&"~"&recGL(1)
              else
              GLcode="NOGLCODE"
           end if  
      set objGL=nothing     
  '------------------------------------------------  
  case "loantrantype"
         dim recloantrantype
         dim loantrn
         set recloantrantype=server.CreateObject("adodb.recordset")
         set objLmt=server.CreateObject("queryrecordsets.fetchrecordsets")
         set recloantrantype=objLmt.SingleRecordset("loantransactiontype","description","UPPER(description)!='NPA'")
         if recloantrantype.RecordCount>0 then
         while not recloantrantype.EOF 
         loantrn=loantrn & "~" & recloantrantype(0)
         recloantrantype.MoveNext
         wend
         else
         loantrn=""
         end if
   '------------------------------------------------ 
   '------------------------------------------------------------------------------------
   case "DEPMST"
    dim depmstfldnames,depmstWhrCnd
    depmstWhrCnd="branchcode='" & cstr(trim(strVal(1)))& "' and currencycode='" & cstr(trim(strVal(2)))& "' and " & _
    "glcode='"& cstr(trim(strVal(4))) & "' and accno='" & cstr(trim(strVal(5)))& "' and status='R'"  
     depmstfldnames="to_char(MATURITYDATE,'dd-Mon-yyyy'),nvl(NOOFUNITS,0)" 
    set recdepType=server.CreateObject("adodb.recordset")
    set objdepType=server.CreateObject("queryrecordsets.fetchrecordsets")
    set recdepType=objdepType.SingleRecordSet("DEPMST",Cstr(depmstfldnames),cstr(depmstWhrCnd))
    if recdepType.RecordCount>0 then
           depParam=recdepType(0)& "~" & recdepType(1)
           Response.Write depParam
    else
    depParam="NORECORD"
    end if
   '------------------------------------------------------------------------------------     
   case "DEPPARAMS"
       dim depfldnames,depWhrCnd
       depfldnames="MINAMOUNT,MAXAMOUNT,MINPERIODYEARS,MINPERIODMON,MINPERIODDAYS," & _
                "MAXPERIODYEARS,MAXPERIODMON,MAXPERIODDAYS,RENODDAMOUNTSYN,INTCOMPOUNDYN," & _
                "INTPAYPERIODICALLYYN,INTPERIODICITYPYMNT,INTPAYMETHOD,FIXEDDAYOFMON," & _
                "INTDEBITGLCODE,INTCREDITGLCODE,INTACCRUEDGLCODE,OVERDUEGLCODE,INSTSYN," & _
                "LATEFEECHARGESYN,INSTPERIODICITY,INSTTYPE,RETROSPECTIVEYN,RETROSYEAR," & _
                "RETROSMON,RETROSDAYS,UNITSYN,UNITVALUE,CASHYN,PREMATWDYN,TDSYN," & _
                "INTROUNDOFFTO,MATDATEHOLIDAYPAID,PNLINTFORPREMATCLOSUREYN,LOANONDEPOSITYN" 
                
      ' depWhrCnd="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
      '          cstr(trim(strVal(2))) & "' and moduleid='" & cstr(trim(strVal(3))) & _
      '          "' and glcode='" & cstr(trim(strVal(4))) & _
      '          "' and status='R'" 
       depWhrCnd="moduleid='" & cstr(trim(strVal(3))) & "' and glcode='" & _
                  cstr(trim(strVal(4))) & "' and status='R'" 
                  
       set recdepType=server.CreateObject("adodb.recordset")
       set objdepType=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recdepType=objdepType.SingleRecordSet("DEPTYPEMST",Cstr(depfldnames),cstr(depWhrCnd),"","9999","anupama","192.9.200.23","minBalChk")
           
       if recdepType.RecordCount>0 then
           depParam=recdepType(0)&"~"&recdepType(1)&"~"&recdepType(2)&"~"&recdepType(3)&"~"& _
              recdepType(4)&"~"&recdepType(5)&"~"&recdepType(6)&"~"&recdepType(7)&"~"& _
              recdepType(8)&"~"&recdepType(9)&"~"&recdepType(10)&"~"&recdepType(11)&"~"& _
              recdepType(12)&"~"&recdepType(13)&"~"&recdepType(14)&"~"&recdepType(15)&"~"& _
              recdepType(16)&"~"&recdepType(17)&"~"&recdepType(18)&"~"&recdepType(19)&"~"& _
              recdepType(20)&"~"&recdepType(21)&"~"&recdepType(23)&"~"&recdepType(24)&"~"& _
              recdepType(25)&"~"&recdepType(26)&"~"&recdepType(27)&"~"&recdepType(28)&"~"& _
              recdepType(29)&"~"&recdepType(30)&"~"&recdepType(31)&"~"&recdepType(32)&"~"& _
              recdepType(33)&"~"&recdepType(34)
        else
           depParam="NORECORD"
        end if  
       set objdepType=nothing               
          ' Response.Write depParam
  '------------------------------------------------------------------------------------  
  ''''inwardclearing transactions   
   case "CLGTypes" 
	    set recClear=server.CreateObject("adodb.recordset")
       set objClear=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recClear=objClear.SingleRecordset("CLGINWARDBATCHDTLS b," & _
								"clgclearingtypepmt c", _
								"distinct(b.clearingtype),c.clearingtype", _
								"b.clearingtype=c.clearingcode and upper(trim(b.status))='O' and " & _
								"upper(trim(branchcode))='" & strVal(1) &"' and " & _
								"upper(trim(currencycode))='" & strVal(2) &"' and " & _
								"applicationdate=to_date('" & session("applicationdate") &"','dd-mm-yyyy') and " & _
								"b.clearingtype in (select clearingtype from " & _
								"CLGLODGEMENTVOUCHERDTLS  where status='P' and " & _
								"lodgementdate=to_date('" & session("applicationdate") &"','dd-mm-yyyy') and " & _
								"upper(trim(branchcode))='" & strVal(1) &"' and " & _
								"upper(trim(currencycode))='" & strVal(2) &"')")
								do until RecClear.EOF
									ClearingTypes=ClearingTypes & RecClear(0) & _
												  "*" & RecClear(1) & "|"
									RecClear.MoveNext
								loop
							ClearingTypes=ClearingTypes & "~" & RecClear.RecordCount-1
							
 '------------------------------------------------  
  case "RPLMT"	           
         dim RLimit,Rfldnms,RwhrCond
         Rfldnms="Receiptlimit,paymentlimit,tellerpaymentlimit,tellerreceiptlimit" 
         RwhrCond="upper(branchcode)='"&cstr(ucase(trim(strVal(1))))& _
                  "' and upper(currencycode)='"&cstr(ucase(trim(strVal(2))))& _
                  "' and upper(cashierid)='"&cstr(ucase(trim(strVal(3))))&"'"
         set recLmt=server.CreateObject("adodb.recordset")
         set objLmt=server.CreateObject("queryrecordsets.fetchrecordsets")
         set recLmt=objLmt.SingleRecordset("CASHCOUNTERMST",cstr(Rfldnms),cstr(RwhrCond))
          
            if recLmt.RecordCount>0 then
               RLimit=recLmt(0)&"~"&recLmt(1)
            else
               RLimit="NORECLMT"
            end if 
              
 '------------------------------------------------      
       	
 case "ABBGL"	        
       'dim cfldnms,cWhrCond,cstrresult,
       dim abbGLcode
       fldnms="glcode,narration"
       WhrCond="branchcode='" & cstr(trim(strVal(1))) & "' and currencycode='" & _
                cstr(trim(strVal(2))) & "' and moduleid='ABB'"
                
       set recGL=server.CreateObject("adodb.recordset")
       set objGL=server.CreateObject("queryrecordsets.fetchrecordsets")
       set recGL=objGL.SingleRecordSet("GENGLSHEETMST",Cstr(fldnms),cstr(WhrCond))
                             
           if recGL.RecordCount>0 then
              abbGLcode=recGL(0)&"~"&recGL(1)
              else
              abbGLcode="NOGLCODE"
           end if  
      set objGL=nothing     							
end select       
' 
%>
<title></title>
</head>
<body onload="results()">

<form name="frmacc">
  <input type="hidden" id="strmod" name="strmod" value="<%=mode%>">
  <input type="hidden" id="mBal" name="mBal" value="<%=minBal%>">
  <input type="hidden" id="chqNo" name="chqNo" value="<%=blnChqNo%>">
  <input type="hidden" id="chqSer" name="chqSer" value="<%=blnChqSer%>">
  <input type="hidden" id="chqDt" name="chqDt" value="<%=vldChqDt%>">
  <input type="hidden" id="detBat" name="delBat" value="<%=Rslt%>">
  <input type="hidden" id="gCode" name="gCode" value="<%=GLcode%>">
  <input type="hidden" id="ltrn" name="ltrn" value="<%=loantrn%>">
  <input type="hidden" id="dParam" name="dParam" value="<%=depParam%>">
  <input type="hidden" id="dClear" name="dClear" value="<%=ClearingTypes%>">
  <input type="hidden" id="rplmt" name="rplmt" value="<%=RLimit%>">
  <input type="hidden" id="abb" name="abb" value="<%=abbGLcode%>">
  <font class="textred">Processing..........</font>
</form>

</body>

</html>
