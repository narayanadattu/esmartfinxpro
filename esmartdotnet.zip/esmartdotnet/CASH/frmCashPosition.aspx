<%@ Page Language="vb" AutoEventWireup="false" aspcompat="true" explicit="false"  Codebehind="frmCashPosition.aspx.vb" Inherits="eSmartDotNet.frmCashPosition"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Position</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<script language=javascript>

function show()
{
	var strVal,br
	
	
	if(window.document.frmCashPosition.txtdate.value=="")
	{
		alert("Please Enter Date")
		return;
	}
	
	strVal="CASHPOSITION"+"|"+window.document.frmCashPosition.txtdate.value
	
	window.document.all['iVinFrame'].src="../GEN/getDtls.aspx?st="+strVal;
	
}

function popCash(str)
{ //alert(" str = "+str)
	window.document.frmCashPosition.mfgCash.rows=1
	
	//var strResult=str.split("|")
	
	var strResult=str.split("$")
	
	var stDenom = strResult[1].split("#")
	
	var stDval = stDenom[0].split("|")
	
	var stVa = stDenom[1].split("|")
	
	
	if(stDval=="")
	{
		alert("No Records Found")
		return;
	}
	
		/*window.document.frmCashPosition.mfgCash.cols=5;
		window.document.frmCashPosition.mfgCash.formatstring="<SlNo  |<Branch          |>Open Balance         |>Vault Balance                  |>Close Balance                  ";*/
		
		var strformatstring 
		
		strformatstring = "<SlNo  |<Branch          |>Open Balance         |>Vault Balance                  |>Close Balance                 " 
		
		strformatstring = strformatstring + strResult[0]
		
		
		window.document.frmCashPosition.mfgCash.formatstring = strformatstring
		
		
		for(aCnt=0;aCnt<=stDval.length-1;aCnt++)
		{
			window.document.frmCashPosition.mfgCash.rows=window.document.frmCashPosition.mfgCash.rows+1
			
			var strCols=stDval[aCnt].split("~")
			
			window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,0)=aCnt+1
			
			for(vCnt=0;vCnt<=strCols.length-1;vCnt++)
			{
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,vCnt+1)=strCols[vCnt]
				
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,2)=strCols[1]
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,2)=ToIndianCurencyFormat(Math.abs(window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,2)),2)
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,3)=strCols[2]
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,3)=ToIndianCurencyFormat(Math.abs(window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,3)),2)
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,4)=strCols[3]
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,4)=ToIndianCurencyFormat(Math.abs(window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,4)),2)
				
			}
			
			var stDcva =  stVa[aCnt].split("~")
			
			for(vCnt=0;vCnt<=stDcva.length-1;vCnt++)
			{
				window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,vCnt+5)=stDcva[vCnt]
				//window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,vCnt+5)=ToIndianCurencyFormat(Math.abs(window.document.frmCashPosition.mfgCash.textmatrix(aCnt+1,vCnt+5)),2)
			}
			
		}
}

function option()
{
	window.document.frmCashPosition.mfgCash.rows=1
}
function ShowDetails()
{
	if(window.document.frmCashPosition.mfgCash.rows<=1)
	{
		alert("No Records To Show Details");
		return false;
	}
			
			row=window.document.frmCashPosition.mfgCash.RowSel
			brcode = window.document.frmCashPosition.mfgCash.TextMatrix(row,1)
			crcode = window.document.frmCashPosition.txtcurrencycode.value
			date = window.document.frmCashPosition.txtdate.value
			
			details=brcode+"~"+crcode+"~"+date
			
			window.showModalDialog("CashPositiondetail.aspx?tds="+details,window,"status:no;dialogWidth:750px;dialogHeight:205px;dialogleft=100%,dialogtop=100%")
}

function mfgCash_Click()
{
	row=window.document.frmCashPosition.mfgCash.Row
		
	for(icnt=1;icnt<=window.document.frmCashPosition.mfgCash.Rows-1;icnt++)
	{
		if(row!=icnt)
		{
			for (d=0 ;d<window.document.frmCashPosition.mfgCash.Cols;d++) 
			{
				window.document.frmCashPosition.mfgCash.Row=icnt	
				window.document.frmCashPosition.mfgCash.Col=d	
				window.document.frmCashPosition.mfgCash.CellBackColor=16777215 
			}
		}
		else
		{
			for (d=0 ;d<window.document.frmCashPosition.mfgCash.Cols;d++) 
			{
				window.document.frmCashPosition.mfgCash.Row=icnt	
				window.document.frmCashPosition.mfgCash.Col=d	
				window.document.frmCashPosition.mfgCash.CellBackColor=5831256
			}
		}
	}
	
	window.document.frmCashPosition.mfgCash.Row = row
	
}
/*function Report(strrep)
{
	var StrCol=""
	var StrRow=""
	var StrHead=""
	var StrCols=""
	var StrColRow=""
	var strheadsub=""
	var strheadtype = ""
	var strSum = ""
	
		strheadtype = "Cash Position"
		//window.document.frmCashPosition.reptype.value=window.document.frmCashPosition.txtGLname.value
		strheadsub = "CASH POSITION AS ON DATES "+ window.document.frmCashPosition.txtdate.value
	
		StrHead= strheadsub + ",60,80"
		window.document.frmCashPosition.reptitle.value=strheadtype
		
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,0)+",4,L"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,1)+",10,L"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,2)+",20,L"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,3)+",16,R"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,4)+",16,R"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,5)+",16,R"+"~"
		StrCol=StrCol+window.document.frmCashPosition.mfgCash.textmatrix(0,6)+",16,R"+"|"
	
		for(icnt=1;icnt<=window.document.frmCashPosition.mfgCash.rows-1;icnt++)
		{
			StrCols=""
			for(jcnt=0;jcnt<=window.document.frmCashPosition.mfgCash.Cols-1;jcnt++)
			{
				StrCols=StrCols+window.document.frmCashPosition.mfgCash.textmatrix(icnt,jcnt)+"~"
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
		}
		StrColRow=StrColRow.substr(0,StrColRow.length-1)
		StrCol=StrCol+StrColRow
		StrArr=StrHead+"|"+StrCol	
	
	
	
	window.document.frmCashPosition.hreport.value=StrArr
	
	if (strrep == "HTML") 
	{
		window.document.frmCashPosition.action="../ReportGridTemplate.aspx?strng="+"/CASH/frmCashPosition"
	}
	else
	{
		window.document.frmCashPosition.action="../ReportGridTemplateXL.aspx?strng="+"/CASH/frmCashPosition"
	}
	
	window.document.frmCashPosition.method="post"
	window.document.frmCashPosition.submit() 
}*/
</script>
<SCRIPT LANGUAGE=javascript FOR=mfgCash EVENT=Click>
<!--
 mfgCash_Click()
//-->
</script>
  </head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg()">
<form name="frmCashPosition">
<div class="header">
	<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
</div>
<div class="menuBar">
	<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
			<td width="5%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
			<td width="35%" align="center" height="22" class="subHeader"><h2>Cash Position</h2></td>
			<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
		</tr>
	</table>
</div>
<div id="menucontrol"></div>
	<table width="100%" cellspacing="0" height="74%" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="100%" valign="top">
				<table border="0" width="100%" cellspacing="0" cellpadding="0">
					<tr class="bgcolor">
						<td width="11%" height="28"></td>
						<td width="89%" height="28"></td>
					</tr>
				</table><%appdate=formatdatetime(session("applicationdate"),1)%>
				<table border="0" width="100%" cellspacing="0" cellpadding="0">
					<tr>
						<td width="100%"></td>
					</tr>
				</table>
				<center>
				<table width="100%" cellspacing="0" cellpadding="0">
					<tr>
					<td height="15" align="center"><font class="textblue"></font></td>
					</tr>
				</table>
				</center>
				<div align="center">
					<center>
					<table border="0" width="98%" cellspacing="0" cellpadding="0">
						<tr class="bgcolor">
							<td width="12%" align="center">&nbsp;Branch Code</td>
							<td width="30%"><input type="text"  class="txtautofill" name="txtbranchcode" size="9" value="<%=session("branchcode")%>" readonly><input type="button" class="button" value=" L " name="butbr" onclick="branch()"><input type="text" class="bgcolor1" name="txtbranchdesc" value="<%=session("branchnarration")%>" size="16" readonly></td>
							<td width="20%" align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency
							Code</td>
							<td width="30%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="txtautofill" name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" readonly><input type="button" class="button" value=" L " name="butcur" onclick="currency()"><input class="bgcolor1" type="text" name="txtcurrencydesc" value="<%=session("currencynarration")%>" size="16" readonly></td>
						</tr>
					</table>
					</center>
				</div>
				<div align="center">
					<center>
					<table border="0" width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
						<tr>
							<td width="149%"></td>
						</tr>
						<tr>
							<td width="139%"></td>
						</tr>
						<tr>
							<td width="139%">
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="12%" align="right"><font size="2" face="MS Sans Serif">Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
										<td width="88%">&nbsp;<input type="text" name="txtdate" size="10" readonly  value="<%=session("applicationdate")%>"></td>  
										<!--<td width="30%" align="center"><input type="radio" name="rebrcd" id="frmsub" onclick="option()" checked><font class="textblack">Branch Wise </font>
										</td>
										<td width="30%" align="center"><input type="radio" name="rebrcd" id="frmnosub" onclick="option()" ><font class="textblack">Consolidate Wise </font>
										</td> --->
									</tr>
								</table>
							</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td width="50%" align="center"><input type="button" value="Refresh" name="buttcbal" onclick="show()" class="button"></td>
						</tr>
						<tr><td width="100%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size="2" color="blue">Select Row and Click Show Details to View the Details</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
						<tr>
		<td width="100%" align="center" colspan='8'>
		<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=200 id=mfgCash name=mfgCash style="HEIGHT: 200px; LEFT: 0px; TOP: 0px; WIDTH: 950px" width=750 VIEWASTEXT>
		<PARAM NAME="_ExtentX" VALUE="15055">
		<PARAM NAME="_ExtentY" VALUE="3757">
		<PARAM NAME="BackColor" VALUE="-2147483643">
		<PARAM NAME="ForeColor" VALUE="-2147483640">
		<PARAM NAME="Enabled" VALUE="-1">
		<PARAM NAME="BackStyle" VALUE="0">
		<PARAM NAME="BorderStyle" VALUE="1">
		<PARAM NAME="AllowBigSelection" VALUE="-1">
		<PARAM NAME="AllowUserResizing" VALUE="1">
		<PARAM NAME="Appearance" VALUE="1">
		<PARAM NAME="BackColorBkg" VALUE="8421504">
		<PARAM NAME="BackColorFixed" VALUE="-2147483633">
		<PARAM NAME="BackColorSel" VALUE="-2147483635">
		<PARAM NAME="CausesValidation" VALUE="-1">
		<PARAM NAME="Cols" VALUE="1">
		<PARAM NAME="ColWidth0" VALUE="1725">
		<PARAM NAME="DrawMode" VALUE="0">
		<PARAM NAME="FillStyle" VALUE="0">
		<PARAM NAME="FixedCols" VALUE="0">
		<PARAM NAME="FixedRows" VALUE="1">
		<PARAM NAME="FocusRect" VALUE="1">
		<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
		<PARAM NAME="ForeColorSel" VALUE="-2147483634">
		<PARAM NAME="FormatString" VALUE="">
		<PARAM NAME="GridColor" VALUE="12632256">
		<PARAM NAME="GridColorFixed" VALUE="0">
		<PARAM NAME="GridLines" VALUE="1">
		<PARAM NAME="GridLinesFixed" VALUE="2">
		<PARAM NAME="GridLineWidth" VALUE="1">
		<PARAM NAME="MergeCells" VALUE="0">
		<PARAM NAME="MergeCol0" VALUE="0">
		<PARAM NAME="MergeRow0" VALUE="0">
		<PARAM NAME="MousePointer" VALUE="0">
		<PARAM NAME="OLEDropMode" VALUE="0">
		<PARAM NAME="PictureType" VALUE="0">
		<PARAM NAME="Redraw" VALUE="-1">
		<PARAM NAME="RightToLeft" VALUE="0">
		<PARAM NAME="RowHeightMin" VALUE="0">
		<PARAM NAME="Rows" VALUE="1">
		<PARAM NAME="ScrollBars" VALUE="3">
		<PARAM NAME="ScrollTrack" VALUE="0">
		<PARAM NAME="SelectionMode" VALUE="0">
		<PARAM NAME="TextStyle" VALUE="0">
		<PARAM NAME="TextStyleFixed" VALUE="0">
		<PARAM NAME="ToolTipText" VALUE="">
		<PARAM NAME="WhatsThisHelpID" VALUE="0">
		<PARAM NAME="WordWrap" VALUE="0">
		<PARAM NAME="ColAlignment0" VALUE="9">
		<PARAM NAME="ColData0" VALUE="0">
		<PARAM NAME="FixedAlignment0" VALUE="4">
		<PARAM NAME="FontWidth" VALUE="0">
		<PARAM NAME="hWnd" VALUE="0">
		<PARAM NAME="RowData0" VALUE="0">
		<PARAM NAME="RowHeight0" VALUE="240">
		<PARAM NAME="TextArray0" VALUE="S.No">
		<PARAM NAME="TextMatrix0" VALUE="S.No">
		<PARAM NAME="row" VALUE="">
		<PARAM NAME="col" VALUE="">
		<PARAM NAME="RowSel" VALUE="">
		<PARAM NAME="ColSel" VALUE="">
		<PARAM NAME="CellBackColor" VALUE="">
		<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
		</td>
	</tr>  
                
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="center"><!--<input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button">--><input type="button" value="Show Details" name="cmdshowdet" onClick="ShowDetails()" class="button"><input type="button" value=" Exit  " name="B3" class="button" onclick="window.location.href=
								&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;"><input type="Button" name="cmdcancel" value=" Cancel " onclick="location.href='frmCashPosition.aspx'" class="button"></td>
							</tr>
						</table>
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tr>
							<td width="100%" height="20">
							<iframe id="iVinFrame" name="iVinFrame" align=center frameBorder=0 frameSpacing=0  height=0 width=0></iframe>
							
							</td>
							<input type="hidden" name="hreport">
							<input type="hidden" name="reptitle">
							</tr>
						</table>
					</table>
  
<div class="footer">
	<div class="logo"></div>
	<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
</div>
</form>
</body>
