<%@ Page Language="vb" CodeBehind="RecTrnInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.RecTrnInsert" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<body>

<%on error resume next

		Dim strComp,strVal,strRow,strCol,gridarr(),Vartrans()
		strComp=Request.QueryString("str")
		       strVal=split(strComp,"^~^~^")
		       strRow=Split(strVal(0),"|")
		      
		for i=0 to UBound(strRow)-1
		    strCol=Split(strRow(i),"~")
		    if i=0 then 
		 		Redim gridarr(UBound(strRow),UBound(strCol))
			end if
			
			for J=0 to UBound(strCol)-1
			    gridarr(i,j)=strCol(j)	
			    	
			next
		next 
		
 '------------------------------------------------------------------
        strRow=""
        strCol=""
        strRow=split(strVal(1),"|")
   
        for i=0 to UBound(strRow) 
		    strCol=Split(strRow(i),"~")
		    if i=0 then 
		 		Redim Vartrans(UBound(strCol),UBound(strRow))
			end if
			
			for J=0 to UBound(strCol)-1
			    Vartrans(j,i)=strCol(j)
			next
		next 
       
  
 '------------------------------------------------------------------
		'set Obj=Server.CreateObject("transactionsremscr.Transactionremscr")
		'set Obj=Server.CreateObject("transactionsloan.transactionloan")
	set Obj=Server.CreateObject("transactionsremscr.transactionremscr")
		
		str =obj.TranInsert(gridarr,Vartrans)
		set obj=nothing%>
<%if err.number<>0 then%>
<p>&nbsp;<font color="red"><strong><font class="textred">ERROR </font>:<font class="textblue"></font>-<%=err.number%>  
 - <%=err.description%></font></strong></p>
<%
  
%>
<%ELSE%>
<%
response.Redirect "cashreceipts.asp?record="& str
end if%>

</body>

</html>
