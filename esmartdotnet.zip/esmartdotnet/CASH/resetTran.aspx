<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="resetTran.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.resetTran" %>
<%
dim strmsg
dim struserid
dim strgroupcode
dim strmodule
dim strval
dim strwhere

dim strfldval
dim strtab
dim obj
dim strCols


strQueryCols="BRANCHCODE, CURRENCYCODE, MODULEID," & _
		" GLCODE, ACCNO, BATCHNO, TRANNO, GLDESC, NAME, AMOUNT, ENTEREDTIMEBAL, " & _
		"CUSTOMERID, MODEOFTRAN, MODEOFTRANDESC, TOKENNO, REMARKS, CHQSERIESNO, " & _
		"CHQNO, to_char(CHQDATE,'dd-Mon-yyyy'), CHQFVG, SYSTEMGENERATEDYN, MODULEDESC, to_char(EFFECTIVEDATE,'dd-Mon-yyyy'), " & _
		"CLGRATETYPE, RATE, FCURRENCYCODE, FAMOUNT, LINKMODULEID, LINKMODULEDESC, " & _
		"LINKGLCODE, LINKGLDESC, LINKACCTYPE, LINKACCNO, LINKACCNAME, SERVICEID, " & _
		"SERVICEDESC, RESPONDINGBRANCHCODE, RESPONDINGBRANCHDESC, RESPONDINGSECTIONCODE, " & _
		"RESPONDINGSECTIONDESC, DISPOSALBATCHNO, DISPOSALTRANNO, ACCOUNTCHECKYN, " & _
		"EXCEPTIONYN, EXCEPTIONCODES, RESPONDINGBANKCODE, RESPONDINGBANKDESC, " & _
		"STANDINSTRYN, COUNTERNO, CASHIERID, SCROLLNO, RATEREFCODE, RATEREFDESC, " & _
		"C61, C62, C63, C64, C65, C66, C67, C68, C69, C70, C71, C72, C73, C74, C75, " & _
		"C76, C77, C78, C79, C80, C81, C82, C83, C84, C85, C86, C87, C88, C89, C90, " & _
		"C91, C92, C93, C94, C95, C96, C97, C98, C99, C100, to_char(APPLICATIONDATE,'dd-Mon-yyyy'), " & _
		"USERID, MACHINEID, 'P', ABBBRANCHCODE, BRANCHNARRATION, " & _
		"to_char(SYSTEMDATE,'dd-Mon-yyyy'), to_char(APPROVEDDATE,'dd-Mon-yyyy'), to_char(ABBAPPLICATIONDATE,'dd-Mon-yyyy')"



strCols="BRANCHCODE, CURRENCYCODE, MODULEID," & _
		" GLCODE, ACCNO, BATCHNO, TRANNO, GLDESC, NAME, AMOUNT, ENTEREDTIMEBAL, " & _
		"CUSTOMERID, MODEOFTRAN, MODEOFTRANDESC, TOKENNO, REMARKS, CHQSERIESNO, " & _
		"CHQNO, CHQDATE, CHQFVG, SYSTEMGENERATEDYN, MODULEDESC, EFFECTIVEDATE, " & _
		"CLGRATETYPE, RATE, FCURRENCYCODE, FAMOUNT, LINKMODULEID, LINKMODULEDESC, " & _
		"LINKGLCODE, LINKGLDESC, LINKACCTYPE, LINKACCNO, LINKACCNAME, SERVICEID, " & _
		"SERVICEDESC, RESPONDINGBRANCHCODE, RESPONDINGBRANCHDESC, RESPONDINGSECTIONCODE, " & _
		"RESPONDINGSECTIONDESC, DISPOSALBATCHNO, DISPOSALTRANNO, ACCOUNTCHECKYN, " & _
		"EXCEPTIONYN, EXCEPTIONCODES, RESPONDINGBANKCODE, RESPONDINGBANKDESC, " & _
		"STANDINSTRYN, COUNTERNO, CASHIERID, SCROLLNO, RATEREFCODE, RATEREFDESC, " & _
		"C61, C62, C63, C64, C65, C66, C67, C68, C69, C70, C71, C72, C73, C74, C75, " & _
		"C76, C77, C78, C79, C80, C81, C82, C83, C84, C85, C86, C87, C88, C89, C90, " & _
		"C91, C92, C93, C94, C95, C96, C97, C98, C99, C100, APPLICATIONDATE, " & _
		"USERID, MACHINEID, TRANSTATUS, ABBBRANCHCODE, BRANCHNARRATION, " & _
		"SYSTEMDATE, APPROVEDDATE, ABBAPPLICATIONDATE"



strval=Request.QueryString("vals")
strval=split(strval,"|")

brcode= strval(0)
crcode = strval(1)
batchno = strval(2)


	strwhere="branchcode='" & brcode & _
		"' and upper(currencycode)='" &  ucase(crcode) & "' and batchno=" & batchno & _
		" and " & _
		" applicationdate='" & session("applicationdate") & "'"
 objTrans=server.CreateObject("GeneralTransactions.DBTransactions")
 rs=server.CreateObject("adodb.recordset")  
 obj=server.CreateObject("queryrecordsets.fetchrecordsets")
 
 rs=obj.singlerecordset("GENTEMPTRANSLOGDEM",cstr(strQueryCols),cstr(strwhere)  )

dim icnt
dim jcnt
dim strFldVals

if not rs.EOF and not rs.BOF then
icnt=0
dim transarray()
redim transarray(cint(rs.RecordCount) ,4)


	do while not rs.EOF 
		transarray(icnt,0)="I"
		transarray(icnt,1)="GENTEMPTRANSLOG"
		transarray(icnt,2)=strCols
		strFldVals=""
		for jcnt=0 to rs.Fields.count-1
			if strFldVals="" then
				strFldVals =  "'" & rs(jcnt) & "'"
			else
				strFldVals = strFldVals &  " , '" & rs(jcnt) & "'"
			end if
		next
		transarray(icnt,3)= strFldVals
		transarray(icnt,4)=""
		icnt=icnt+1	
		
			
		rs.MoveNext 
	loop


		transarray(icnt,0)="D"
		transarray(icnt,1)="GENTEMPTRANSLOGDEM"
		transarray(icnt,2)=""
		transarray(icnt,3)= ""
		transarray(icnt,4)=strwhere
	
	strmsg=objTrans.DataTransactions(transarray)
	Response.Write (strmsg)
end if

		'Response.Write strFldVals & "<br>"
				'Response.Write strcols & "<br>"

	
	
	
	'Response.End 
	
	
'	response.Redirect "workallotmentapproval.aspx?record=" & strmsg
%>

<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>

<script language=javascript>
	function Result(){
        var vRslt=window.document.frmPost.hdnStrRslt.value
        window.attachEvent(window.parent.Result(vRslt));  
        window.close()
	}

</script>


<body onload="Result()">
<form name="frmPost">
<input type=input name="hdnFlexPost" id="hdnFlexPost">
<input type=input name="hdnStrRslt" id="hdnStrRslt" value="<%=strmsg%>">	

<%if err.number<>0 then%>
<p>&nbsp;<font color="red"><strong><font face="Verdana">ERROR </font>:<font color="blue" face="Verdana"></font>-<%=err.number%>  
 - <%=err.description%></font></strong></p>
<%end if%>

</body>
</form>
</html>
