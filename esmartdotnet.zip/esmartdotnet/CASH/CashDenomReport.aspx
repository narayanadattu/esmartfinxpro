<%@ Page aspcompat="true" explicit="false"  Language="vb" AutoEventWireup="false" Codebehind="CashDenomReport.aspx.vb" Inherits="eSmartDotNet.CashDenomReport"%>
<HTML>
	<HEAD>
		<title>Cash Denomination Reports</title>
		<%
	
	Dim BrCode, CurCode, apdat, rep, StDaCod,stDatcmd, stFrdat, stTodat,Stitle,stCid
	
	recnfts=server.CreateObject("adodb.recordset")
	objnfts=server.CreateObject("queryrecordsets.fetchrecordsets")
	recnfts=objnfts.singlerecordset("genbankparm","NFTSCONVYN","")

	if objnfts.ConnError="Connected" then
		if recnfts.RecordCount<>0 then
			strnftsconvyn=cstr(recnfts(0).value)
		end if
	end if
	recnfts=nothing
	objnfts=nothing
	
	BrCode = UCase(Trim(Request.Form("txtBrcode")))
	CurCode = UCase(Trim(Request.Form("txtCrcode")))
	apdat = cstr(session("applicationdate"))
	stDatcmd = UCase(Trim(Request.Form("cmbDateOper")))
	
	stFrdat = UCase(Trim(Request.Form("txtFromDate")))
	stTodat = UCase(Trim(Request.Form("txtToDate")))
	Stitle = UCase(Trim(Request.Form("txtDenomRep")))
	stCid = UCase(Trim(Request.Form("txtcashid")))
	
	rsaddress=server.CreateObject("adodb.recordset")
	objfetch =server.CreateObject("queryrecordsets.fetchrecordsets")

	rsaddress=objfetch.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & BrCode & "' and a.bankcode=b.bankcode")
	
	rsDnom = server.CreateObject("adodb.recordset")
	objDnom	= server.CreateObject("ReportPurposeOnly.Reportonly")
	rsVal = server.CreateObject("adodb.recordset")
	objVal	= server.CreateObject("ReportPurposeOnly.Reportonly")
	
	rsTotVal = server.CreateObject("adodb.recordset")
	objTotVal	= server.CreateObject("ReportPurposeOnly.Reportonly")
	
	
	dim StDat,StValdat
	
	StDat = Request.QueryString("strng")
	
	StValdat = StDat.split("|")
	
	StDaCod = StValdat(0)
	rep = StValdat(1)
	
	if rep = "XL" then
		Response.ContentType = "application/vnd.ms-excel"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & "CashDenomRep.xls")
	end if	
	
	
	dim strDenom, DenFld, DenVal, denom, stArr, stCnt, stReval, stDnm, stQtot, DenTotVal, stTotCnt, stTotReval
	
%>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="Visual Basic .NET 7.1" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<style>.break { page-break-after: always }
		</style>
		<script>
	function HandleBackFunctionality()
	{
		if(window.event)
		{
			if(window.event.clientX < 40 && window.event.clientY < 0)
			{
			var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
			else
			{
			//   alert("Browser refresh button is clicked...");
			}
		}
		else
		{
			if(event.currentTarget.performance.navigation.type == 1)
			{
			//   alert("Browser refresh button is clicked...");
	     
			}
			if(event.currentTarget.performance.navigation.type == 2)
			{
			//  alert("Browser back button is clicked...");
					var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
		}
	}


	function notAllowed()
	{
		if(event.ctrlKey)
		{
			event.keyCode=0;
			return false;
		}
		if(parseInt(event.button)==2 ||parseInt(event.button)==3 )
		{
			alert("This Operation Is Not Allowed");
			return false;     
		}
	} 


	function prnt()
	{
		window.document.all['divPrnt'].style.display="none";
		window.print()
		window.document.all['divPrnt'].style.display="block";
	}
		
	function SelCopy()
	{
		var copysuccess // var to check whether execCommand successfully executed
		try
		{
			copysuccess = document.execCommand("copy") // run command to copy selected text to clipboard
		} 
		catch(e)
		{
			copysuccess = false
		}
		return copysuccess
	}

	function selectText(containerid) 
	{
		if (document.selection) 
		{
			var range = document.body.createTextRange();
			range.moveToElementText(document.getElementById(containerid));
			range.select();
		} 
		else if (window.getSelection()) 
		{
			var range = document.createRange();
			range.selectNode(document.getElementById(containerid));
			window.getSelection().removeAllRanges();
			window.getSelection().addRange(range);
		}
	}

		</script>
	</HEAD>
	<body leftMargin="0" topMargin="0" onmousedown="notAllowed();" onkeydown="notAllowed();"
		onbeforeunload="HandleBackFunctionality();">
		<form name="frmCashDenomReport">
			<div id="divselcopy">
				<table width="100%" border="0">
					<tr>
						<td align="center" width="100%" colSpan="4">
							<%''''' Report Headings%>
							<center><font color="#000000" size="3">
									<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								</font>
								<br>
								<font color="#000000" size="3">
									<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value) & "," & iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								</font>
								<br>
								<font color="#000000" size="3">
									<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								</font>
							</center>
						</td>
					</tr>
				</table>
				<table width="100%">
					<tr>
						<td align="center" colSpan="2"><font face="courier new" color="#000000" size="2"><%=strRepTitle%><%=appdate%></font></td>
					</tr>
					<tr>
						<td align="left" width="50%"><font face="courier new" color="#000000" size="2">User 
								ID&nbsp;:&nbsp;<%=session("userid")%></font></td>
						<td align="right" width="50%"><font face="courier new" color="#000000" size="2">Branch 
								Code&nbsp;:&nbsp;<%=BrCode%></font></td>
					</tr>
				</table>
				<!--- for Cash Receipt And Payment Report --->
		<%	if StDaCod = "CASHRECPAY"  then 
				
		
			strDenom = ""
					
			strDenom = "  SELECT Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC "
			
			rsDnom = objDnom.SingleSelectStat(strDenom)
			
			if objDnom.ConnError="Connected" then
				if not rsDnom.bof and not rsDnom.eof then
					
					denom = ""
					DenFld = ""
					DenVal = ""
					stDnm = ""
				
					do until rsDnom.eof
						
						denom = denom & " NVL(SUM(" & rsDnom(1).value & "),0)  " & rsDnom(1).value & ","
						
						stDnm = stDnm & " NVL((" & rsDnom(1).value & "),0)  " & rsDnom(1).value & ","
						
						DenFld = DenFld & rsDnom(0).value & ","
					
					rsDnom.movenext()
					loop
		
					DenFld = mid(DenFld,1,DenFld.length-1)
					denom = mid(denom,1,denom.length-1)
					stDnm = mid(stDnm,1,stDnm.length-1)
				end if
				rsDnom = nothing
			end if
			
			strMain = "" 
			
			if stDatcmd = "=" then
				
				
				if strnftsconvyn = "Y" then
					
					if  StValdat(5) = "" and StValdat(6) = "" then '' if date = appdate and brcode and customerid is null
						strMain = " SELECT branchcode,TO_CHAR(NVL(SUM(amount),0)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " GROUP BY branchcode ORDER BY branchcode "
					else if  StValdat(5) <> "" and StValdat(6) <> "" then '' if date = appdate and brcode and customerid not null
						strMain = " SELECT ROWNUM, ''''||Accno, SUBSTR(name,0,20)name,TO_CHAR((amount)) amt," & stDnm & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " "
					else if StValdat(5) <> "" and StValdat(6) = "" then '' if date = appdate and brcode not null and customerid null
						strMain = " SELECT ROWNUM, ''''||Accno, SUBSTR(name,0,20)name,TO_CHAR((amount)) amt," & stDnm & ",cashierid FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " "
					end if
				
				else
					if  StValdat(5) = "" and StValdat(6) = "" then '' if date = appdate and brcode and customerid is null
						strMain = " SELECT branchcode,TO_CHAR(NVL(SUM(amount),0)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " GROUP BY branchcode ORDER BY branchcode "
					else if  StValdat(5) <> "" and StValdat(6) <> "" then '' if date = appdate and brcode and customerid not null
						strMain = " SELECT ROWNUM, ''''||(branchcode||''||glcode||''||LPAD(Accno,6,0)) acno, SUBSTR(name,0,20)name,TO_CHAR((amount)) amt," & stDnm & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " "
					else if StValdat(5) <> "" and StValdat(6) = "" then '' if date = appdate and brcode not null and customerid null
						strMain = " SELECT ROWNUM, ''''||(branchcode||''||glcode||''||LPAD(Accno,6,0)) acno, SUBSTR(name,0,20)name,TO_CHAR((amount)) amt," & stDnm & ",cashierid FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " "
					'else if StValdat(5) = "" and StValdat(6) = "" then 'if branchcode and cashierid is null
					'	strMain = " SELECT TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
					'else if StValdat(5) <> "" and StValdat(6) = "" then 'if branchcode is not null and cashierid is null
					'	strMain = " SELECT TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
					
					'else if StValdat(5) <> "" and StValdat(6) <> "" then 'if branchcode is not null and cashierid is not null
					'	strMain = " SELECT TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
					end if
				
				end if
				
				
				
				if StValdat(5) = "" and StValdat(6) = "" then '' for total values
					stQtot = ""
					
					stQtot = "SELECT TO_CHAR(NVL(SUM(amount),0)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & " "
					
					rsTotVal = objTotVal.SingleSelectStat(stQtot)
				
					if objTotVal.ConnError="Connected" then
						if not rsTotVal.bof and not rsTotVal.eof then
							do until rsTotVal.eof
							
								for i = 0 to rsTotVal.fields.count - 1 
									DenTotVal = DenTotVal & rsTotVal(i).value & ","
								next i	
									
									DenTotVal = DenTotVal & "|"
							rsTotVal.movenext()
							loop
							
							DenTotVal = mid(DenTotVal,1,DenTotVal.length-1)
						else
							DenTotVal = ""
						end if
					end if
					
				end if
				
			else if stDatcmd <> "=" then
				
				if StValdat(5) = "" and StValdat(6) = "" then 'if branchcode and cashierid is null
					strMain = " SELECT TO_CHAR(APPLICATIONDATE, 'DD-Mon-YYYY' ) APPDATE,TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
				else if StValdat(5) <> "" and StValdat(6) = "" then 'if branchcode is not null and cashierid is null
					strMain = " SELECT TO_CHAR(APPLICATIONDATE, 'DD-Mon-YYYY' ) APPDATE,TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
				else if StValdat(5) <> "" and StValdat(6) <> "" then 'if branchcode is not null and cashierid is not null
					strMain = " SELECT TO_CHAR(APPLICATIONDATE, 'DD-Mon-YYYY' ) APPDATE,TO_CHAR(SUM(amount)) amt," & denom & " FROM " & StValdat(2) & "" & StValdat(3) & " WHERE  CURRENCYCODE = '" & CurCode & "' " & StValdat(6) & " " & StValdat(4) & " " & StValdat(5) & "  GROUP BY APPLICATIONDATE ORDER BY APPLICATIONDATE " 
				end if
			
			end if
			
			
			rsVal = objVal.SingleSelectStat(strMain)
			
			if objVal.ConnError="Connected" then
				if not rsVal.bof and not rsVal.eof then
					do until rsVal.eof
					
						for i = 0 to rsVal.fields.count - 1 
							DenVal = DenVal & rsVal(i).value & ","
						next i	
							
							DenVal = mid(DenVal,1,DenVal.length-1)
							
							DenVal = DenVal & "|"
					rsVal.movenext()
					loop
					
					DenVal = mid(DenVal,1,DenVal.length-1)
				else
					DenVal = ""
				end if
			end if
			
			
			
		
		%>
		
		<table width="100%">
			<tr>
				<td>
					<table width="100%">
						<tr>
							<%	if stDatcmd = "BETWEEN" then %>
								<% if StValdat(5) = "" and StValdat(6) = "" then %>
								<td><center><font face="courier new" color="#000000" size="2">Consolidate Cash
											<%=Stitle%>
											Report As On Date Between
											<%=stFrdat%>
											to
											<%=stTodat%>
										</font>
									</center>
								</td>
								<% else if StValdat(5) <> "" and StValdat(6) = "" then  %>
								<td><center><font face="courier new" color="#000000" size="2">Cash
											<%=Stitle%>
											Report For Branchcode =
											<%=BrCode%>
											As On Date Between
											<%=stFrdat%>
											to
											<%=stTodat%>
										</font>
									</center>
								</td>
								<% else if StValdat(5) <> "" and StValdat(6) <> "" then %>
								<td><center><font face="courier new" color="#000000" size="2">Cash
											<%=Stitle%>
											Report For Cashier Id =
											<%=stCid%>
											And Branchcode =
											<%=BrCode%>
											As On Date Between
											<%=stFrdat%>
											to
											<%=stTodat%>
										</font>
									</center>
								</td>
								<% end if %>
							<%	else  %>
								<% if StValdat(5) = "" and StValdat(6) = "" then %>
								<td><center><font face="courier new" color="#000000" size="2">Consolidate Cash
											<%=Stitle%>
											Report As On Date
											<%=stDatcmd%>
											<%=stFrdat%>
										</font>
									</center>
								</td>
								<% else if StValdat(5) <> "" and StValdat(6) = "" then  %>
								<td><center><font face="courier new" color="#000000" size="2">Cash
											<%=Stitle%>
											Report For Branchcode =
											<%=BrCode%>
											As On Date
											<%=stDatcmd%>
											<%=stFrdat%>
										</font>
									</center>
								</td>
								<% else if StValdat(5) <> "" and StValdat(6) <> "" then %>
								<td><center><font face="courier new" color="#000000" size="2">Cash
											<%=Stitle%>
											Report For Cashier Id =
											<%=stCid%>
											And Branchcode =
											<%=BrCode%>
											As On Date
											<%=stDatcmd%>
											<%=stFrdat%>
										</font>
									</center>
								</td>
								<% end if %>
							<% End if %>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td>
					<table border="1">
						<tr>
							<% if stDatcmd = "=" then %>
							
							
								<%  if StValdat(5) = "" and StValdat(6) = "" then   %>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Br Code</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
									
									<% 
									stArr = DenFld.split(",")
									
									for i=0  to ubound(stArr)
									
										%>
									<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
									<%  next i %>
								
								<% else if  StValdat(5) <> "" and StValdat(6) = "" then %>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Sl No</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Accno</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Name</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
									
									<% 
									stArr = DenFld.split(",")
									
									for i=0  to ubound(stArr)
									
										%>
									<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
									<%  next i %>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Cashier Id</b></font></td>
								
								<% else %>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Sl No</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Accno</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Name</b></font></td>
									<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
									<% 
									stArr = DenFld.split(",")
									
									for i=0  to ubound(stArr)
									
										%>
									<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
									<%  next i %>
								<% end if%>
								
								
							<% else if stDatcmd <> "=" then %>
								<% if StValdat(5) = "" and StValdat(6) = "" then  %>
								<td align="center"><font face="courier new" color="#000000" size="2"><b>App Date</b></font></td>
								<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
								<% 
								stArr = DenFld.split(",")
								
								for i=0  to ubound(stArr)
								
									%>
								<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
								<%  next i %>
								<% else %>
								<td align="center"><font face="courier new" color="#000000" size="2"><b>App Date</b></font></td>
								<td align="center"><font face="courier new" color="#000000" size="2"><b>Amount</b></font></td>
								<% 
								stArr = DenFld.split(",")
								
								for i=0  to ubound(stArr)
								
									%>
								<td align="center"><font face="courier new" color="#000000" size="2"><b><%=stArr(i)%></b></font></td>
								<%  next i %>
								<% end if%>
							<% end if %>
						</tr>
						<% 
							if DenVal <> "" then
							
							stCnt  = DenVal.split("|")
							
							for i=0  to ubound(stCnt)
						%>
						<tr>
							<% stReval = stCnt(i).split(",")
						
								for j = 0 to ubound(stReval)%>
							<td align="right"><font face="courier new" color="#000000" size="2"><%=stReval(j)%></font></td>
								<%  next j %>
						</tr>
						<%  next i %>
						
							<% if stDatcmd = "=" then %>
						
								<% if StValdat(5) = "" and StValdat(6) = "" then %>
								
									<% 
										if DenTotVal <> "" then
										
										stTotCnt  = DenTotVal.split("|")
										
										for i=0  to ubound(stTotCnt)
									%>
								<tr>
									
									<td align="right"><font face="courier new" color="#000000" size="2"><b>Total</b></font></td>
									<% stTotReval = stTotCnt(i).split(",")
								
											for j = 0 to ubound(stTotReval)%>
									<td align="right"><font face="courier new" color="#000000" size="2"><%=stTotReval(j)%></font></td>
											<%  next j %>
								</tr>
										<%  next i %>
									<% end if%>
								
								<% end if %>
							<% end if %>
						
						<% Else  %>
						<tr>
							<td align="Center"><font face="courier new" color="#000000" size="2">No Records Found</font></td>
						</tr> 
						<% End If  %>
						
					</table>
				</td>
			</tr>
			<tr>
				<td>
					<table>
						
					</table>
				</td>
			</tr>
		</table>
		
		<% end if%>
				
				<table align="center" width="100%">
					<tr>
						<td align="center">
							<div id="divPrnt">
								<input type="button" value="  Select All   " name="butSelectAll" onclick="selectText('divselcopy')"
									class="button"> <input type="button" value="  Copy   " name="butCopy" onclick="SelCopy()" class="button"><input onclick="prnt()" type="button" value="  Print   " name="butprnt"><input class="bgcolor" onclick="location.href='frmCashReport.aspx'" type="button" value="   Exit   "
									name="butok"></div>
						</td>
					</tr>
				</table>
		</form>
	</body>
</HTML>
