<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="acceptamount.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.acceptamount" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{
var kstr
  kstr= window.document.frmacc.hbno.value
  
  if(kstr)
  {
  window.attachEvent(window.parent.Allotedamount(kstr))
  window.close()
  }
 
}
//-->
</SCRIPT>

<%
kstr=Request.Form("hFlds")
dim rs,obj,rec,cnt,acc
  ''kstr=Request.QueryString("st")
 
if len(kstr)> 0 then
  strFlds=split(kstr,"~")
   	k=split(strFlds(0),"|")
   	 			
	
	dim CounterNo
	 obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	 rs=server.CreateObject("adodb.recordset")
	 rscounter=server.CreateObject("adodb.recordset")
	'''for fetching the counterdetails for cash acceptance form for selcted cashier id 
    
	if strFlds(1)="AcceptAmount" then 	
		rs=obj.singleRecordSet("cashallotmentstrn c,Genusermst g", _
			"c.ALLOTEDUSERID,g.name,c.AMOUNTALLOTED", _
			"upper(c.alloteduserid)=upper(g.userid) and " & _
			"c.branchcode='" &  k(0) & "' and " & _
			"c.currencycode='" & k(1) & "'  and  " & _
			"c.status='P' and c.allotmentno='" & k(2) & "' and " & _
			"c.cashierid ='" & session("userid") & "'")
				'if 1=2 then
		if not rs.EOF and not rs.BOF then
			if not rs.EOF and not rs.BOF then
				rs.MoveFirst
				for i=0 to rs.Fields.Count - 1
					  acc=acc &"*"& rs(i).value
				next
			end if
			'rscounter=obj.singleRecordSet("cashcountermst","counterno", _
					'	"cashierid='" & rs(0)&"'")
			'if not rscounter.EOF and not rscounter.BOF then
					' acc=acc &"*"& rscounter(0)
			'end if
			acc=acc & "*"& session("counterno")
			acc=acc & "~" & strFlds(1)	
		end if
	elseif strFlds(1)="CashierAllotedAmount" then 	
		rs=obj.singleRecordSet("cashallotmentstrn c,Genusermst g", _
			"c.ALLOTEDUSERID,g.name,c.AMOUNTALLOTED,c.counterno", _
			"upper(c.alloteduserid)=upper(g.userid) and " & _
			"c.branchcode='" &  k(0) & "' and " & _
			"c.currencycode='" & k(1) & "'  and  " & _
			"c.status='P' and c.allotmentno='" & k(2) & "' and " & _
			"upper(trim(c.alloteduserid))='" & ucase(trim(session("userid"))) & "' and " & _
			"upper(trim(c.cashierid))='" & ucase(trim(k(3))) & "'")

		if not rs.EOF and not rs.BOF then
			if not rs.EOF and not rs.BOF then
			rs.MoveFirst
				for i=0 to rs.Fields.Count - 1
					  acc=acc &"*"& rs(i).value
				next
			end if
			'acc=acc & "*"& session("counterno")
			acc=acc & "~" & strFlds(1)	
		end if		
		
		'response.write(acc)
		'response.end 
		
'''for descriptions fetching
elseif 	strFlds(4)="DescDisplay" then
 RecGen=Obj.SingleRecordset(cstr(strFlds(0)),cstr(strFlds(1)),cstr(strFlds(2)))
			if not RecGen.BOF or not RecGen.EOF then
				for i=0 to RecGen.Fields.Count-1
					acc=acc &  recgen(i).value & "*"
				next
			else
			acc= "No*"	
			end if
			acc=acc & "~" & strFlds(3)	
			
	Response.Write (acc)
	end if
   
end if
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=acc%>">
  <input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
