<%@ Page Language="vb" CodeBehind="moduleidapproval.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.moduleidapproval" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>


<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<%  Dim obj,rs1,vark
	str=Request.Form("hden")
%>	
<title></title>
</head>
<body>

<form name="frmmodule">
  <%
		if len(str)>0 then
			set rs1=server.CreateObject("adodb.recordset")
			set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
			set rs1=obj.singlerecordset("GENMODULETYPESMST","moduleid,narration"," branchcode='"& cstr(str)&"'  and IMPLEMENTEDYN='Y'")
  %>

  <table border="0" width="140" cellspacing="0" cellpadding="0">
    <tr align="left">
      <td width="30%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modules</font></td>
    </tr>
  </table>

  <table>
     <%if rs1.EOF=false and rs1.BOF=false then%>
		<%rs1.MoveFirst%>
		<%do until rs1.EOF%>
    <tr>
      <td><input type="radio" name="optmoduleid" id="optmoduleid" value="<%=rs1(0)%>"><font color="black"><%=rs1(1)%></font></td>
            <%rs1.MoveNext%>
    </tr>
		<%loop%>
      <%else%>
          <%="Data does not exists"%>
         <% Response.Write"<script language=vbscript>"
           Response.Write "window.parent.window.document.frmworkallot.cmdDisplay.disabled=true" & chr(13)
           Response.Write "window.parent.window.document.frmworkallot.cmdok.disabled=true" & chr(13)
           Response.Write "window.parent.window.document.frmworkallot.cmdreject.disabled=true" & chr(13)
           	Response.Write"</script>" %>
    <%end if%>
    <%end if%>
    <input type="hidden" name="hden" id="hden">
    </form>
  </table>

</body>

