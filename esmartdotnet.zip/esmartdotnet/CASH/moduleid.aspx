<%@ Page Language="vb" CodeBehind="moduleid.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.moduleid" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : GenUserCreation.ASP									*
'*	Purpose	  	     : To create application users in database          	*
'*						             										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   T. Chandana Reddy  |    18-JUN-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************


%>


<html>

<SCRIPT LANGUAGE=javascript>
<!--
function clearframe()
{
	
	parent.frames(1).frmforms.action="formid.asp"
	parent.frames(1).frmforms.method="post"
	parent.frames(1).frmforms.submit()
}



//-->
</SCRIPT>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">

<%  Dim obj,rs1,vark
	str=Request.Form("hden")
%>	
<title></title>
</head>
<body>

<form name="frmmodule">
  <%
		if len(str)>0 then
			set rs1=server.CreateObject("adodb.recordset")
			set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
			set rs1=obj.singlerecordset("GENMODULETYPESMST","moduleid,narration"," branchcode='"& cstr(str)&"'  and IMPLEMENTEDYN='Y'")
  %>

  <table border="0" width="140" cellspacing="0" cellpadding="0">
    <tr align="left">
      <td width="30%"><font face="MS Sans Serif" size="2" color="blue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modules</font></td>
    </tr>
  </table>

  <table>
     <%if rs1.EOF=false and rs1.BOF=false then%>
		<%rs1.MoveFirst%>
		<%do until rs1.EOF%>
    <tr>
      <td><input type="radio" name="optmoduleid" id="optmoduleid" value="<%=rs1(0)%>" onclick="clearframe()"><font color="black"><%=rs1(1)%></font></td>
            <%rs1.MoveNext%>
    </tr>
		<%loop%>
      <%else%>
          <% Response.Write "Data does not exists"%>
          <% 
       		Response.Write"<script language=vbscript>"
			'Response.Write "window.parent.window.document.frmworkallot.hstatus.value=False"
			Response.Write "window.parent.window.document.frmworkallot.cmdAdd.disabled=true" & chr(13)
			Response.Write "window.parent.window.document.frmworkallot.cmddelete.disabled=true" & chr(13)
			Response.Write "window.parent.window.document.frmworkallot.cmdModify.disabled=true" & chr(13)
			Response.Write "window.parent.window.document.frmworkallot.cmdQuery.disabled=true"
			Response.Write"</script>" 
      			   
      end if%>
    <%end if%>
    <input type="hidden" name="hden" id="hden">
    </form>
  </table>

</body>

