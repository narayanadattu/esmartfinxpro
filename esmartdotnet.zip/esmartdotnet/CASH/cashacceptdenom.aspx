<%@ Page Language="vb" CodeBehind="cashacceptdenom.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashacceptdenom" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
function CashMultiply(Note,Rs,Amt)

{
	
 var i,T
  if (Rs.value=="")
  {
     Amt.value="0.00"
     total()
  }
  else
  {
  
	Amt.value=eval(Note)* eval(Rs.value)
     total()
  }
    
}

//-->
</SCRIPT>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=vbscript>
sub total()
    Cnt=window.document.frmdm.hcnt.value 
    frm=window.document.frmdm.hfrm.value
    for i=0 to Cnt-1
	    k=cdbl(k)+ cdbl(window.document.frmdm.txtamt(i).value)
	next
    window.parent.window.document.forms(frm).txttotal.value=k
    window.parent.window.document.forms(frm).txttotal.onchange()
    
end sub
</SCRIPT>

<%Dim obj,st,str
	str=Request.Form("hdenom")
	Response.Write str
	k=split(str,"|")
	Response.Write k(0)
	Response.Write k(1)0.
%>
</head>
<body>

<form name="frmdm">

  <table border="0" width="280" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <td width="100%"><font class="textwhite">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Avail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; No.of<br>
      &nbsp;Denoms&nbsp;&nbsp; Pieces&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      pieces&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Amount</font></td>
    </tr>
  </table>

  <%
	if len(str)>0 then
		set obj=server.CreateObject("cashquery.queries")
		if ubound(k)<4 then
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)),"25-Apr-2001")
		else
		    st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(k(4)),cstr(k(5)),cstr(k(6)))
	    end if
	if ubound(st)>0 then    
	    	    	
   %>
  <input type="hidden" name="hfrm" value="<%=k(0)%>">

  <table cellspacing="0" cellpadding="0" width="280" class="tablebordermain">
 	<%
 	
 	dim ind,cnt
 	for j=0 to ubound(st)
 	if st(j,0)="CP" then
 	   ind=ind+1
 	end if
 	next
 	FOR i=0 TO ubound(st)%>
 	<%if st(i,1)<>"" then%>
 	<%cnt=cnt+1%>	
    <tr align="center">
      <td width="90" height="10" align="right">
		<%=st(i,1)%></td>
      <input type="hidden" name="hps" value="<%=st(i,1)%>">
      <td width="90" height="10" align="right">
		<%=st(i,2)%><input type="hidden" name="htype" value="<%=st(i,0)%>"></td>
      <td width="26" height="10" valign="top">*</td>
	    <% if st(i,0)="CP" then
	       cal=st(i,3)
		   amt=st(i,1)/cal
		%>
      <input type="hidden" name="hamt" value="<%=amt%>"> 
			<%if ind>1 then
				m=0%>				
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hamt(<%=m%>).value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.txtamt(<%=i%>));amountdigits(window.document.frmdm.txtamt(<%=i%>))"></td>
			  <%m=m+1
			else%>
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hamt.value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.txtamt(<%=i%>));amountdigits(window.document.frmdm.txtamt(<%=i%>))"></td>
		  <%end if %>
		<%else%>
      <td width="50"><input type="text" id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hps(<%=i%>).value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.txtamt(<%=i%>));amountdigits(window.document.frmdm.txtamt(<%=i%>))"></td>
		<%end if%>
      <td width="31" height="10" align="center">=</td>
      <td width="71"><input type="text" id="txtamt" name="txtamt" value="0.00" style="FONT-SIZE: x-small; HEIGHT: 18px ;text-align:right" size="9" readonly disabled></td>
      <%end if%>
    </tr>
	<%next %>
	
  </table>

  <%else
	Response.Write st(0,0)
  %>  
  <% end if%>
  <% end if%>
  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" name="hcnt" value="<%=cnt%>">
</form>

</body>

</html>
