<%@ Page Language="vb" AutoEventWireup="false" aspcompat="true" explicit="false" Codebehind="frmcashAdjust.aspx.vb" Inherits="eSmartDotNet.frmcashAdjust" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
	<meta name="ProgId" content="FrontPage.Editor.Document">
	<title>Cash Adjustment</title>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
	<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
	<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
	<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
	<SCRIPT LANGUAGE=javascript>
	
	var st
	var CashDenom
	CashDenom='<%=session("cashdenomyn")%>'
	
	function Cashiercode()
	{	
		s1="CashID"
		s2=window.document.frmAdjust.txtbranchcode.value
		st=s1+"|"+s2
	   
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
				"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	}
	//function for displaying the CashierCode, description whixh is returned by list page 
	function Cashierid(kstr)
	{   
		//alert(kstr)
		assign(kstr,window.document.frmAdjust.txtCashierDesc,window.document.frmAdjust.txtCashierId)
		Denomination()
	}
	
	function Denomination()
	{
		var tab="cashcashierposmst" 
		var brcode=window.document.frmAdjust.txtbranchcode.value 
		var crcode=window.document.frmAdjust.txtcurrencycode.value 				
		var frm="frmrefund"		
		var cashid= window.document.frmAdjust.txtCashierId.value
		var st= frm + "|" + tab + "|" + brcode + "|" + crcode+"|"+cashid
		//alert(" st = "+st)
        window.document.frames(0).frmdm.hdenom.value=st
		window.document.frames(0).frmdm.action="frmDenomAdjust.aspx"
		window.document.frames(0).frmdm.method="post"
		window.document.frames(0).frmdm.submit() 
		cashAdju()
	}
	
	function cashAdju()
	{
		var m="cashcashierposmst"  
		var n=window.document.frmAdjust.txtbranchcode.value 
		var p=window.document.frmAdjust.txtcurrencycode.value 
		var f="frmAdjust"
		var cashid= window.document.frmAdjust.txtCashierId.value
		var st = f + "|" + m + "|" + n + "|" + p + "|"+ cashid 
		//alert(" st = "+st)  
		window.document.frames(1).frmdm.hdenom.value=st
		window.document.frames(1).frmdm.action="frmAdjustCash.aspx"
		window.document.frames(1).frmdm.method="post"
		window.document.frames(1).frmdm.submit()
	
	}
	
	function Insert()
	{
		var chTotal,denomTotal
		chTotal = window.document.frmAdjust.txtCaTot.value
		denomTotal = window.document.frmAdjust.txtrtotal.value
		
		if((denomTotal!="0")||(denomTotal!="0.00"))
		{
			if(chTotal==denomTotal)
			{
				var j,a="",b="",c="",d="",e="",k
				k=1
				
				p=window.document.frames(1).frmdm.hcnt.value
    			
    			for(j=0;j<p;j++)
				{
					if (window.document.frames(1).frmdm.hps[j].value != "")
					{
						a1 =window.document.frames(1).frmdm.hps[j].value 
						a=a+a1+"|"
						b1 =window.document.frames(1).frmdm.txtrec[j].value 
						b=b+b1+"|" 
						d1 =window.document.frames(1).frmdm.htype[j].value 
						d=d+d1+"|" 
						e1 =window.document.frames(1).frmdm.havail[j].value 
						e=e+e1+"|" 
						k=k+1;
					}
				}
				
				//alert("a = "+a+" b = "+b+" d = "+d+" e = "+e+" K = "+k)
				
				window.document.frmAdjust.hcount.value=k   
				window.document.frmAdjust.hvalue.value=a
				window.document.frmAdjust.hrec.value=b
				//window.document.frmAdjust.hpaid.value=c
				window.document.frmAdjust.htype.value =d
				window.document.frmAdjust.havail.value =e
				window.document.frmAdjust.action="cashAdjustUpdate.aspx"
				window.document.frmAdjust.method ="post"
				window.document.frmAdjust.submit()
						
			}
			else
			{
				alert("Cash Denomination Total and Cash In Hand Total not Equal")
			}
		}
	}
	
	function DispTranMsg()
	{
		var strtran
		strtran="<%=Request.QueryString("record")%>"
		
		if(strtran!="")
		{
			alert(strtran)
			//window.document.frmAdjust.buttInsert.disabled = false
			window.location.href="frmcashAdjust.aspx" 
		}
	}	
	
	
function GetAvgTot(kstr)
{
k=kstr.split("|")
	window.document.frmAdjust.txttotal.value =k[0]  // avg total
	window.document.frmAdjust.txttotal.value= gridprecision(window.document.frmAdjust.txttotal.value,window.document.frmAdjust.hpr.value)
	window.document.frmAdjust.txtCaTot.value =k[1]  // ca total
	window.document.frmAdjust.txtCaTot.value= gridprecision(window.document.frmAdjust.txtCaTot.value,window.document.frmAdjust.hpr.value)
	
}

function TotalSumAmountR(kstr)
{

	window.document.frmAdjust.txtrtotal.value=kstr 
	window.document.frmAdjust.txtrtotal.value= gridprecision(window.document.frmAdjust.txtrtotal.value,
					window.document.frmAdjust.hpr.value)
}

function TotalSumAmountP(kstr)
{
	window.document.frmAdjust.txtptotal.value=kstr
	window.document.frmAdjust.txtptotal.value= gridprecision(window.document.frmAdjust.txtptotal.value,
					window.document.frmAdjust.hpr.value)
}

function GetAtotal(kstr)
{
window.document.frmAdjust.txtAtotal.value =  kstr
window.document.frmAdjust.txtAtotal.value= gridprecision(window.document.frmAdjust.txtAtotal.value,
					window.document.frmAdjust.hpr.value)

}


	</script>
  </SCRIPT>
</head>
	<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg()">

	<form name="frmAdjust">

	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
    
	<div class="menuBar">
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="40%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Adjustment</h2></td>
				<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div>
	<div id="menucontrol"></div>
		
		<table border="0" width="100%" cellspacing="0" cellpadding="0" >
			<tr>
				<td width="100%" valign="top"><%appdate=formatdatetime(session("applicationdate"),1)%>
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td width="100%"><center></center>
							<div align="center">
								<center>

								<table width="98%" cellspacing="0" cellpadding="0" border="0">
								<tr class="bgcolor">
									<td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
									<td width="32%"><input name="txtbranchcode" size="9" readonly style="TEXT-TRANSFORM: uppercase" class="txtautofill" value="<%=Session("BranchCode")%>" ><input type="button" class="button" value=" L " name="B3" disabled onclick="branch()"><input name="txtbranchdesc" size="16" value="<%=session("branchnarration")%>" style="TEXT-TRANSFORM: uppercase" readonly class="bgcolor1"></td>
					                
									<td width="25%" align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
									<td width="32%"><input name="txtcurrencycode" style="TEXT-TRANSFORM: uppercase" readonly class="txtautofill" size="9" value="<%=session("currencyCode")%>"><input type="button" class="button" value=" L " name="B3" disabled onclick="currency()"><input name="txtcurrencydesc" size="16" style="TEXT-TRANSFORM: uppercase" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
								</tr>
								</table>

								</center>
							</div>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table border="0" width="99%" cellspacing="0" cellpadding="0">
			<tr>
                <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cashier ID </td>
                <td width="32%">&nbsp;&nbsp;&nbsp;<input name="txtCashierId" onblur="Dataarrange (txtCashierId);;DescrptionDisp(&quot;txtCashierId&quot;)"  style="TEXT-TRANSFORM: uppercase" size="9" class="txtautofill" readonly><input type="button" class="button" value=" L " name="B4" onclick="Cashiercode()" tabindex="0"><input name="txtCashierDesc" size="16" readonly class="bgcolor1"></td>
                <td width="25%" align="right">Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td width="32%">&nbsp;<input name="txtCaTot" onchange="precision(window.document.frmAdjust.txtCaTot,window.document.frmAdjust.hpr.value)" readonly size="9" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"> </td>
            </tr>
            <tr>
                <td width="50%" colspan='2'><font size="2" face="MS Sans Serif" color="#cc0000"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Original Denomination</b></font></td>
                <td width="50%" colspan='2'><font size="2" face="MS Sans Serif" color="#cc0000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Adjusted Denomination</b></font></td>
            </tr>
		</table>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
                <td width="425" valign="top">&nbsp;
					<table border="0" cellspacing="0" cellpadding="0" width="60%" class="tablebordermain">
						<tr>
							<td valign="top"><iframe id=denOriginal align=center  frameborder=0 framespacing=0 noresize height=340 width=440 valign="top" src = "frmDenomAdjust.aspx" style="BACKGROUND-COLOR: darkred"></iframe></td>
						</tr>
					</table>
                 
                </td>
                <td width="425" valign="top">&nbsp;
					<table border="0" cellspacing="0" cellpadding="0" width="60%" class="tablebordermain">
						<tr>
							<td valign="top"><iframe id=den align=center  frameborder=0 framespacing=0 noresize height=340 width=440 valign="top" src = "frmAdjustCash.aspx" style="BACKGROUND-COLOR: darkred"></iframe></td>
						</tr>
					</table>
                
                </td>
            </tr>
		</table>
		<table  border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td width="25%">Denomination Total : </td>
				<td width="25%">&nbsp;&nbsp;<input name="txttotal" onchange="precision(window.document.frmAdjust.txttotal,window.document.frmAdjust.hpr.value)" readonly size="9" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"></td>
				<td width="10%"></td>
				<td width="40%">Adjust Total&nbsp;<input name="txtrtotal" onchange="precision(window.document.frmAdjust.txtrtotal,window.document.frmAdjust.hpr.value)" readonly size="10" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"><!--Out Total&nbsp;<input name="txtptotal" onchange="precision(window.document.frmAdjust.txtptotal,window.document.frmAdjust.hpr.value)" readonly size="10" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"> --></td>
			</tr>
		</table>
		<table  border="01" width="100%" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%"><center> <input type="button" value="    Ok    " name="buttInsert" onclick="Insert()" onblur='window.document.frmAdjust.buttcancel.focus()' tabindex="2" class="button"><input type="button" value="Cancel" name="buttcancel" tabindex="3" onclick="window.location.href='frmcashAdjust.aspx'" class="button"><input type="button" value="   Exit   " name="cmdexit" tabindex="4" class="button" onclick="location.replace(&quot;cashmodule.aspx&quot;)"></center></td>
			</tr>
		</table>
		<input name="hcount" type="hidden"><input name="hpr" type="hidden"><input name="hvalue" type="hidden"><input name="hrec" type="hidden"><input name="hpaid" type="hidden"><input name="htype" type="hidden"><input name="havail" type="hidden">
		<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises</div>
		</div>	


	</form>
  </body>
</html>
