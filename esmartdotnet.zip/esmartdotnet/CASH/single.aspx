<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="single.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet._single" %>

<% Response.CacheControl = "no-cache" %>
<% Response.AddHeader("Pragma", "no-cache") %>
<% Response.Expires = -1 %>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>eSmartBanker</title>
<%strType=Request.QueryString("st")
userid=session("userid")
%>
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE="javascript">
function List()
{
var callerWindowObj = dialogArguments;
var kstr,ints,intk,intp
 if(window.document.frmList.cmbList.selectedIndex < 0 ) 
	{
		alert("Select Any Code") 
	}
else
   {
	kstr= window.document.frmList.cmbList.options[window.document.frmList.cmbList.selectedIndex].text
	
	type="<%=strType%>"
/// for cash acceptance form------------------------------------------------------	
///for allotment no
	if (type.substring(0,9)=="Allotment" || type.substring(0,12)=="AllotmentDel")
		{
		//window.attachEvent(window.opener.Allotmentid(kstr))
		callerWindowObj.Allotmentid(kstr)
		window.close()
		}
////-----------------------------------------------------------------------------------------		
	else if (type.substring(0,9)=="Counterno")
		{
		window.attachEvent(window.opener.Counternos(kstr))
		window.close()
		}
	else if (type.substring(0,8)=="Bankcode")
		{
		window.attachEvent(window.opener.Bankid(kstr))
		window.close()
		}
	
	else if (type.substring(0,12)=="Adbranchcode")
		{
		window.attachEvent(window.opener.Assignadbranchcode(kstr))
		window.close()
		}
////----for cash transaferallotment form------------------------------------------------
		//// for counterno 
	else if (type.substring(0,8)=="Tcounter")
		{
		//window.attachEvent(window.opener.Counterid(kstr))
		callerWindowObj.Counterid(kstr)
		window.close()
		}
		
/////---------------------------------------------------------------------------------
////----for cash transaferAcceptance form------------------------------------------------
		//// for counterno 		
	else if (type.substring(0,10)=="Counteracc")
		{
		//window.attachEvent(window.opener.Counteraccid(kstr))
		 callerWindowObj.Counteraccid(kstr)
		window.close()
		}
		//for transferNo
	else if (type.substring(0,8)=="Transfer")
		{
		//window.attachEvent(window.opener.Transno(kstr))
		callerWindowObj.Transno(kstr)
		window.close()
		}	
////-----------------------------------------------------------------------------------		
		
	else if (type.substring(0,12)=="Getbankcodes")
		{
		window.attachEvent(window.opener.Bankcodeassign(kstr))
		window.close()
		}
////----------- for Cash RefundacceptForm---------------------------------------	
/// to get counter no
	else if(type.substring(0,10)=="refCounter")
	{
		//window.attachEvent(window.opener.Cashcounterid(kstr))
		callerWindowObj.Cashcounterid(kstr)
		window.close()
	}

/// to get refund counter no
	else if(type.substring(0,8)=="refundno")
	{
		//window.attachEvent(window.opener.Cashrefundid(kstr))
		callerWindowObj.Cashrefundid(kstr)
		window.close()
	}	
	/////------------------------------------------------------------------------
	else if(type=="Banklevel")
	{
		window.attachEvent(window.opener.banklevelid(kstr))
		window.close()
	}			
	}
}
</SCRIPT>
<%
dim obj,rs,sname
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
   rs=server.CreateObject("adodb.recordset")
  '''' for cash acceptance form------------------------------------------------------
  '''for fetching the allotmentno according the brancgcode,login user id 
if left(strType,12)="AllotmentDel" then
	sname="Allotment"
	k=split(strType,"*")
	
	 rs=obj.singlerecordset("cashallotmentstrn","Allotmentno", _
		"upper(trim(cashierid))='" & ucase(trim(k(3))) & "' and " & _
		"status='P' and branchcode='" & k(1) & "' and " & _
		" upper(trim(alloteduserid))='" & ucase(trim(session("userid"))) & "' and " & _
		" currencycode='" & k(2) & "'","allotmentno")
elseif left(strType,9)="Allotment" then
	sname="Allotment"
	k=split(strType,"*")
	
	 rs=obj.singlerecordset("cashallotmentstrn","Allotmentno", _
		"cashierid='" & session("userid") & "' and " & _
		"status='P' and branchcode='" & k(1) & "' and " & _
		"currencycode='" & k(2) & "'","allotmentno")
''''-------------------------------------------------------------------------		
elseif left(strType,9)="Counterno" then
	sname="Counter"
	k=split(strType,"*")
	 rs=obj.singlerecordset("cashcountermst","counterno","branchcode='" & k(1)& "' and currencycode='" & k(2) & "'","counterno")
	
elseif strType="Bankcode" then
	sname="Bank"
	  rs=obj.singlerecordset("Genbankmst","Bankcode","","Bankcode")
	 
elseif strType="Adbranchcode" then
	sname="Adbranch"
	 rs=obj.singlerecordset("Genbankbranchmst","Branchcode","","Branchcode")
''' for cashtransaferalloment from ----------------------------------------------------------
'''for fetching counterno according the branchcode,cashierid 
elseif left(strType,8)="Tcounter" then
	sname="counter"
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHCOUNTERMST","distinct(counterno)", _
	"branchcode='" & k(1) & "' and currencycode='" & k(2) &  "' and "& _
	"cashierid not in ('" & userid & "')","counterno")
''''-----------------------------------------------------------------------------------	
'''' for cash transferAcceptance form-----------------------------------------------
'''for counterno 
elseif left(strType,10)="Counteracc" then
	sname="Counter"
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN", _
			"distinct(fromCOUNTERNO)","branchcode='" & k(1) & "' and " & _
			"currencycode='" & k(2) & "' AND STATUS='P' AND " & _
			"tocashierid='" & userid & "'","fromcounterno")
'''for transfernNo	
elseif left(strType,8)="Transfer" then
	sname="Transfer"
	k=split(strType,"*")
	 rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN", _
			"distinct(CASHTRANSFERNO)","branchcode='" & k(1) & "' and " & _
			"currencycode='" & k(2) & "' AND STATUS='P' AND " & _
			"tocashierid='" & session("userid") & "' and " & _
			"fromcashierid='" & k(3) & "' and " & _
			"fromcounterno='" & k(4) & "'","CASHTRANSFERNO")
''''------------------------------------------------------------------------------------
elseif strType="Getbankcodes" then
	sname="Bank"
	 rs=obj.singlerecordset("Genbankbranchmst","Branchcode","","Branchcode")
elseif strType="Banklevel" then
   sname="Banklevel"
    rs=obj.singlerecordset("Genbanklevelmst","Code","")	
''' for cash refunf accp form(refund accept)-------------------------------------------
'''for fetching counter no
elseif left(strtype,10)="refCounter" then
	strFlds=split(strtype,"*")
	sname="Refcounter"
	 rs=obj.singlerecordset("CASHREFUNDSTRN","DISTINCT(COUNTERNO)", _
	"branchcode='" & strFlds(1) & "' and currencycode='" & strFlds(2) & "'")
''''''for fetching the refund no	
elseif left(strtype,8)="refundno" then
	sname="Refund"
	k=split(strtype,"*")	
	 rs=obj.singlerecordset("CASHREFUNDSTRN", _
			"distinct(refundno)","branchcode='" & k(1) & "' and " & _
			"currencycode='" & k(2) & "' and " & _
			"refundeduserid='" & k(3) & "' and status='P'")			
''''----------------------------------------------------------------------------------------
end if
%>
</head>
<body>

<form name="frmList">
  <%IF  NOT rs.EOF   AND NOT rs.BOF THEN%>
<center>
  <table class="tablebordermain" cellspacing="0" cellpadding="0">
    <tr class="bgcolor">
      <th style="FONT-SIZE:xx-small"><font class="textbold">&nbsp;<%=ucase(sname)%>&nbsp;NO</font></th>
    <tr class="bgcolor">
      <td style="FONT-SIZE:xx-small"><select name="cmbList" size="4" style="FONT-SIZE:x-small" ondblclick="List()">
	    <%  
	do until rs.EOF
	if rs.Fields.Count < 2 then%>
        <option><%=rs(0).value%></option>
	    <%else%>
        <option><%=rs(0).value & "----" & rs(1).value &"----" & rs(2).value%></option>
	    <%end if%>
	    <%rs.MoveNext
  loop
	Response.Write ("<script language=vbscript>")
	  Response.Write ("window.document.frmList.cmbList.item(0).selected=true" & chr(13))
      Response.Write ("</script>")
     
   rs=nothing
   obj=nothing
        %>     
      </select></td>
    </tr>
  </table>
</center>
  <center><input type="button" value="   OK   " name="butmd" onclick="List()" class="button">
  <input type="button" value="Cancel" name="butcancel" onclick="window.close()" class="button">
  </center>
  <%else
		Response.Write ("<font color=white size=3><b>No Records Found<b></font>") %>
  <br>
  <br>
  <center><input type="button" value="   OK   " name="butok" onclick="window.close()" class="button"></center>

  <%end if%>


</form>

</body>

</html>
