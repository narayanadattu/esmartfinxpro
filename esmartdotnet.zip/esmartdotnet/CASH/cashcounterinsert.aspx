<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashcounterinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashcounterinsert" %>
<%
DIM OBJ 'object variable
Dim Strvalues  'to store values
DIM  Str1
reDim ArrTrans(0,4)
dim Status
	status=Request.Form("hidstatus")
	brcode=	Request.form("txtBranchCode")
	crcode=Request.form("txtCurrencyCode")
	counterno=Request.form("txtcounterno")
	limit=Request.form("txtmlimit")
	cashid=Request.form("txtcid")
	cashtype=Request.form("txtctypeid")
	limitpay=Request.form("txtlimitpay")
	receipt=Request.form("txtreceipt")
	tellerlimitpay=Request.form("txttellerlimitpay")
	tellerreceipt=Request.form("txttellerreceipt")
	userid=session("userid")
	machineid=session("machineid")
	if len(limit)=0 then
	limit=0
	end if
	if len(limitpay)=0 then
	limitpay=0
	end if
	if len(receipt)=0 then
	receipt=0
	end if
	if len(tellerlimitpay)=0 then
	tellerlimitpay=0
	end if
	if len(tellerreceipt)=0 then
	tellerreceipt=0
	end if
	
if len(brcode) > 0 and len(crcode) > 0 and len(counterno) > 0 then
 rsinsert = server.CreateObject("adodb.recordset")
 Obj = SERVER.CreateObject("GeneralTransactions.DBTransactions")
'storing  all values into strvalues variable
kstr="APPLICATIONDATE,CASHIERID,CASHIERTYPEID,PAYMENTLIMIT," & _
			"RECEIPTLIMIT,TELLERPAYMENTLIMIT,TELLERRECEIPTLIMIT,MAXCASHLIMIT,COUNTERSTATUS,USERID,MACHINEID"
strvalues="'" & SESSION("APPLICATIONDATE") & "'~'" & ucase(trim(cashid)) & "'~" & _
				"'" & ucase(trim(cashtype)) & "'~" & limitpay & "~" & receipt & "~" & _
				""& tellerlimitpay & "~" & tellerreceipt & "~" & _
				"" & limit & "~'C'~'" & ucase(trim(session("userid"))) & "'~" & _
				"'" & ucase(trim(SESSION("MACHINEID"))) & "'"
				
StrCondition="branchcode='" & brcode & "' and " & _
					"currencycode='" & crcode & "' and " & _
					"counterno='" & counterno & "'"
StrDELCondition="branchcode='" & brcode & "' and " & _
					"currencycode='" & crcode & "' and " & _
					"counterno=" & counterno & " and cashierid='" &ucase(trim(cashid)) & "'"
StrDelFlds="'" & SESSION("APPLICATIONDATE") & "'~''~" & _
				"''~''~''~" & _
				"''~''~" & _
				"''~'C'~'" & ucase(trim(SESSION("UserId"))) & "'~" & _
				"'" & ucase(trim(SESSION("MACHINEID"))) & "'"
if status="ADD" then
reDim ArrTrans(1,4)
		Arrtrans(0,0)="U"				'passing Transaction Type	
		Arrtrans(0,1)="CASHCOUNTERMST"	'passing the table name
		Arrtrans(0,2)=kstr				'passing columns
		Arrtrans(0,3)=strvalues			'passing values
		Arrtrans(0,4)=StrCondition		'passing where condition
		Arrtrans(1,0)="I"				'passing Transaction Type	
		Arrtrans(1,1)="CASHCOUNTERCASHIERLNK"	'passing the table name
		Arrtrans(1,2)="branchcode,currencycode,counterno,cashierid,applicationdate,"& _
					"systemdate,userid,machineid"			'passing columns
		Arrtrans(1,3)="'" & brcode & "','" & crcode & "','" & counterno & "','" & ucase(trim(cashid)) & "'," & _
					  "to_date('" & session("applicationdate") & "','dd-Mon-yyyy'),sysdate," & _
					  "'" & session("userid") & "','" & session("machineid") & "'"		'passing values
		Arrtrans(1,4)=""			  
					  
					  
		Arrtrans(0,4)=StrCondition		'passing where condition
		Response.Write (Arrtrans(0,0) & "<br>")
		Response.Write (Arrtrans(0,1) & "<br>")
		Response.Write (Arrtrans(0,2) & "<br>")
		Response.Write (Arrtrans(0,3) & "<br>")
		Response.Write (Arrtrans(0,4) & "<br>")
		
		Strmsg= OBJ.DataTransactions(ArrTrans)
		Response.Write (strmsg)
elseif status="MODIFY" then
		Arrtrans(0,0)="U"
		Arrtrans(0,1)="CASHCOUNTERMST"	'passing the table name
		Arrtrans(0,2)=kstr				'passing columns
		Arrtrans(0,3)=strvalues			'passing values
		Arrtrans(0,4)=StrCondition		'passing where condition
		Strmsg= OBJ.DataTransactions(ArrTrans)
elseif status="DELETE" then

'''checking if any pending transaction are there in allotments and transfers and refunds
	 objFetchRec=server.CreateObject("queryrecordsets.fetchrecordsets")
	dim recAllot
	dim recTransfer
	dim recRefund
	 recAllot=server.CreateObject("adodb.recordset")
	 recTransfer=server.CreateObject("adodb.recordset")
	 recRefund=server.CreateObject("adodb.recordset")
	 recCashpos=server.CreateObject("adodb.recordset")
	 recAllot=objFetchRec.singlerecordset("CASHALLOTMENTSTRN","counterno", _
			"branchcode='" & brcode & "' and currencycode='" & crcode & "' and " & _
			"counterno='" & counterno & "' and cashierid='" & ucase(trim(cashid)) & "' and status='P'")
		if recAllot.recordcount<>0 then
			strmsg="Pending transactions are there in Cash Allotments for  Cashier   :" & ucase(trim(cashid))
			Response.Redirect ("cashcountermgt.aspx?record="& strmsg)
		end if	
	 recTransfer=objFetchRec.singlerecordset("CASHTRANSBTCASHIERSTRN","FROMCASHIERID", _
			"branchcode='" & brcode & "' and currencycode='" & crcode & "' and " & _
			"(FROMCOUNTERNO='" & counterno & "' and FROMCASHIERID='" & ucase(trim(cashid)) & "' and status='P') or " & _
			"(TOCOUNTERNO='" & counterno & "' and TOCASHIERID='" & ucase(trim(cashid)) & "' and status='P')")
			
		if recTransfer.recordcount<>0 then
			strmsg="Pending transactions are there in Cash Transafer for  Cashier   :" & ucase(trim(cashid))
			Response.Redirect ("cashcountermgt.aspx?record="& strmsg)
		end if	
	 recRefund=objFetchRec.singlerecordset("cashrefundstrn","*", _
			"branchcode='" & brcode & "' and currencycode='" & crcode & "' and " & _
			"COUNTERNO='" & counterno & "' and REFUNDEDUSERID='" & ucase(trim(cashid)) & "' and status='P'")
		if recRefund.recordcount<>0 then
			strmsg="Pending transactions are there in Cash Refunds for Cashier   :" & ucase(trim(cashid))
			Response.Redirect ("cashcountermgt.aspx?record="& strmsg)
		end if	
		
		 recCashpos=objFetchRec.singlerecordset("CASHCASHIERPOSMST","nvl(totamount,0)", _
			"branchcode='" & brcode & "' and currencycode='" & crcode & "' and " & _
			"COUNTERNO='" & counterno & "' and cashierid='" & ucase(trim(cashid)) & "'")
		if recCashpos.recordcount>0 then
			if clng(recCashpos(0).value)>0 then
			
			strmsg="Balance Exists with  Cashier   :" & ucase(trim(cashid))
			Response.Redirect ("cashcountermgt.aspx?record="& strmsg)
			end if
		end if	


reDim ArrTrans(1,4)
		Arrtrans(0,0)="U"
		Arrtrans(0,1)="CASHCOUNTERMST" 'passing the table name
		Arrtrans(0,2)=kstr			'passing columns
		Arrtrans(0,3)=StrDelFlds			'passing values
		Arrtrans(0,4)=StrCondition		'passing where condition
		Arrtrans(1,0)="D"
		Arrtrans(1,1)="CASHCOUNTERCASHIERLNK" 'passing the table name
		Arrtrans(1,2)=""			'passing columns
		Arrtrans(1,3)=""		'passing values
		Arrtrans(1,4)=StrDELCondition		'passing where condition	
		Response.Write (Arrtrans(0,0) & "<br>")
		Response.Write (Arrtrans(0,1) & "<br>")
		Response.Write (Arrtrans(0,2) & "<br>")
		Response.Write (Arrtrans(0,3) & "<br>")
		Response.Write (Arrtrans(0,4) & "<br>")
		Strmsg= OBJ.DataTransactions(ArrTrans)
		'Response.Write (strmsg)
		
end if
	if kstr="Transaction Sucessful." then
	strmsg="Transaction Successful."
		Response.Redirect ("cashcountermgt.aspx?record=" & strMSG)
	else
	Response.Redirect ("cashcountermgt.aspx?record=" & strMSG)
	end if	
else
		strmsg="Fields Should not be Null"
		Response.Redirect ("cashcountermgt.aspx?record=" & strmsg)
end if
%>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
