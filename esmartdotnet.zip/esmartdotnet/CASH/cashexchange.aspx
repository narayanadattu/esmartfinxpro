<%@ Page aspcompat="true" explicit="false" CodeBehind="cashexchange.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashexchange" %>
<html>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : cashexchange.aspx										*
'*	Purpose	  	     : This form is use to exchange cash between counters	*
'*						and customers										*
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'|   V.SriDevi	        |    15-May-2001   |   3.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

	function branch()
	 {
	   st="Bruser"
	   window.open("List.aspx" + "?"+"st="+st,st,"width=200%,height=150%,left=130,top=125")
	 }
	
	function currency()
	
	 {  
	 st="Curr"
	 window.open("List.aspx" + "?"+"st="+st,st,"width=220%,height=150%,left=550,top=125")
	
	 }
	 
	function Bruser(kstr)
	 { 
	 window.document.frmex.txtcurrencycode.value=""
	 window.document.frmex.txtcurrencydesc.value=""
	 window.document.frmex.all.denom.style.display="none"
	 window.document.frmex.txtAtotal.value="0.00"
	  assign(kstr,window.document.frmex.txtbranchdesc,window.document.frmex.txtbranchcode)
	 } 

  
	 
	
	function  denomdisp()
	{
		st = window.document.frmex.txtCashierId.value 
		window.open ("EXDenom.aspx" + "?"+"st="+st,st,"width=220%,height=150%")
	}
	
	function panCheck()
	{
	
	var panNum
		panNum=window.document.frmex.txtPann.value
		
		if(window.document.frmex.txtPann.value=="")
		{
			alert("Please Enter Pan Number")
			return;
		}
		else
		{
			if((panNum.length=="10")&&(panNum.substring(0,10)).match("[(/).]+"))
			{
				alert("Not a valid PanNumber")
				window.document.frmex.txtPan.value=""
			}
			else
			{
				if(panNum.length=="10")
				{
					if((panNum.substring(0,5)).match(/^[a-zA-Z]+$/)&&(panNum.substring(5,9)).match(/^[0-9]+$/)&&(panNum.substring(9,10)).match(/^[a-zA-Z]+$/))
					{
						
					}
					else
					{
						alert("Not a valid PanNumber")
						window.document.frmex.txtPann.value=""
						window.document.frmex.txtPann.focus()
						return;
					}
				}
				else
				{
					alert("Not a valid PanNumber")
					window.document.frmex.txtPann.value=""
					window.document.frmex.txtPann.focus()
					return;
				}
			}
		}
		
	}
  
function total1()
{ var i;

window.document.frmex.txtPTotal.value="0.00"


  for(i=0;i<19;i++)
  {
  
 	window.document.frmex.txtPTotal.value =eval(eval(window.document.frmex.txtPTotal.value)+ eval(window.document.frmex.txtPAmt(i).value))
  } 
 }
   
     
 


function CashMultiply(Note,Rs,Amt)
{ var i,T

  if (Rs.value=="")
  {
 
    Amt.value="0.00"
  }
  else
  {
   
    Amt.value=parseInt(Note)* parseInt(Rs.value)
    
   amountdigits(Amt)
  }
    
}
     
function denom()
{
	m="cashcashierposmst"  
	n=window.document.frmex.txtbranchcode.value 
	p=window.document.frmex.txtcurrencycode.value 
	f="frmex"
	st= f + "|" + m + "|" + n + "|" + p   
	//alert(" st = "+st) 
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="masterdenomex.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()    
	//alert(CashDenom)
	if (CashDenom=='Y')
	{
		window.document.all.denom.style.display="block"
		window.document.all.total.style.visibility="visible" 
		window.document.frmex.txtAtotal.style.visibility="visible"
		window.document.frmex.txtrtotal.style.visibility="visible" 
		window.document.frmex.txtptotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.denom.style.display="none"
		window.document.all.total.style.visibility="hidden" 
		window.document.frmex.txtAtotal.style.visibility="hidden" 
		window.document.frmex.txtrtotal.style.visibility="hidden" 
		window.document.frmex.txtptotal.style.visibility="hidden" 
	}
	
	/* m="cashcashierposmst"  
	n=window.document.frmex.txtbranchcode.value 
	p=window.document.frmex.txtcurrencycode.value 
	//q="04-May-2001"
	//r="V3"
	//s="1"
	f="frmex"
	st= f + "|" + m + "|" + n + "|" + p    
	//st= f + "|" + m + "|" + n + "|" + p + "|" + q + "|" + r + "|" + s   
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="masterdenomex.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()    
	window.document.frmex.all.denom.style.display="Block"  */
}     
     
 
//-->
</SCRIPT>

<SCRIPT LANGUAGE=javascript>
<!--
function Currid(kstr)
{
var k=new String()
var j
var pres
var p
var prn

 k=kstr.split("-----")
  window.document.frmex.txtcurrencydesc.value =k[0]
  window.document.frmex.txtcurrencycode.value =k[1]
  prn=k[2].length-1
  window.document.frmex.hpr.value=prn
  p=""
  var p
  var pres
  for(j=1;j<=prn;j++)
  {
    p= p + "0"
  }
	pres= "0." + p 
	window.document.frmex.txtrtotal.value=pres
  window.document.frmex.txtptotal.value=pres
  window.document.frmex.txtExAmt.value =pres
  window.document.frmex.txtAtotal.value =pres
  window.document.frmex.txtnarration.value=""
	denom()
 }
function Allot(kstr)
{
	var k
	var i=new String()
	var m
	//for(i=0;i<parent.frames(0).frmCatDisp.txtcat.length;i++)
	//for i=1 to 1
	//for(i=1;i
	//{
	k=kstr.split("*")
	//}
	window.document.frmex.txtCounterNo.value =k[0]
	window.document.frmex.txtnarration.focus()
}

function  Insert()
{
	if (CashDenom=='Y')
	{
	if ((window.document.frmex.txtExAmt.value=="0.00")&&(window.document.frmex.txtrtotal.value=="0.00"))
	{
		alert("Enter All fields")
	}
	else
	{
		var j,a="",b="",c="",d="",e="",k
		k=1
		//**********calling this function into Insert button to call the Asp Page
		//**********to insert the values into datatbase
		if (window.document.frmex.txtptotal.value==window.document.frmex.txtrtotal.value)
		{
			if (window.document.frmex.txtExAmt.value==window.document.frmex.txtptotal.value)
			{
				p=window.document.frames(0).frmdm.hcnt.value
    		    for(j=0;j<p;j++)
				{
					if (window.document.frames(0).frmdm.hps[j].value != "")
					{
						a1 =window.document.frames(0).frmdm.hps[j].value 
						a=a+a1+"|"
						b1 =window.document.frames(0).frmdm.txtrec[j].value 
						b=b+b1+"|" 
						c1 =window.document.frames(0).frmdm.txtpaid[j].value 
						c=c+c1+"|" 
						d1 =window.document.frames(0).frmdm.htype[j].value 
						d=d+d1+"|" 
						e1 =window.document.frames(0).frmdm.havail[j].value 
						e=e+e1+"|" 
						k=k+1;
					}
				}
			    /*
			    window.document.frmex.hcount.value=k   
				window.document.frmex.hvalue.value=a
				window.document.frmex.hrec.value=b
				window.document.frmex.hpaid.value=c
				window.document.frmex.htype.value =d
				window.document.frmex.havail.value =e
    
				window.document.frmex.action="CashExchangeInsert.aspx"
				window.document.frmex.method ="post"
				window.document.frmex.submit()*/
			}
			else
			{
				alert("Amounts must be equal")
				return;
			}
		} 
		else
		{
			alert("Received Denomination Total Should be Equal to Paid Denomination Total")
			return;
		}
	}
	}//denomination if
	
	if (CashDenom=='N')
	{	k=0;
	}
	window.document.frmex.hcount.value=k   
	window.document.frmex.hvalue.value=a
	window.document.frmex.hrec.value=b
	window.document.frmex.hpaid.value=c
	window.document.frmex.htype.value =d
	window.document.frmex.havail.value =e
    window.document.frmex.action="CashExchangeInsert.aspx"
	window.document.frmex.method ="post"
	window.document.frmex.submit()
	
}

///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashexchange.aspx" 
		
	}
}	

function GetATotal(kstr)
{
window.document.frmex.txtAtotal.value = kstr
window.document.frmex.txtAtotal.value= gridprecision(window.document.frmex.txtAtotal.value,
					window.document.frmex.hpr.value)
}

function ptotalSumAmount(kstr)
{
window.document.frmex.txtptotal.value = kstr
window.document.frmex.txtptotal.value= gridprecision(window.document.frmex.txtptotal.value,
					window.document.frmex.hpr.value)
}

function rtotalSumAmount(kstr)
{
window.document.frmex.txtrtotal.value = kstr
window.document.frmex.txtrtotal.value= gridprecision(window.document.frmex.txtrtotal.value,
					window.document.frmex.hpr.value)
}




//-->
</SCRIPT>
<SCRIPT LANGUAGE=vbscript>



</SCRIPT>
 
<title></title>
</head>
<body topmargin="0" leftmargin="0" 
onload="denom();GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg()">
<script language="javascript">
	if (CashDenom!="Y")
	{      
      alert("User is not allowed to do Cash Exchange")
      location.replace('http://<%=session("moduledir")& "/" & session("moddir")& "/"%>'+"cashmodule.aspx")
     }
</script>

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmex">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="42%" height="22" class="subHeader">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>Cash Exchange</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
	    <div id="menucontrol"></div>
	    


  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%">

     <!-- <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="11%" height="28"></td>
          <td width="11%" height="28"></td>
          <td width="89%" height="28">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <!-- <td width="100%" bgcolor="#7D5445"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>-->
        <!--    </tr>
          </table>

          </td>
        </tr>
      </table> --->

      <input type="hidden" name="hnote" value="500"><input type="hidden" name="hnote" value="50"><input type="hidden" name="hnote" value="5"><input type="hidden" name="hnote" value="5"><input type="hidden" name="hnote" value="3"><input type="hidden" name="hnote" value="3"><input type="hidden" name="hnote" value="20"><input type="hidden" name="hnote" value="2"><input type="hidden" name="hnote" value="11"><input type="hidden" name="hnote" value="1000"><input type="hidden" name="hnote" value="100"><input type="hidden" name="hnote" value="10"><input type="hidden" name="hnote" value="1">

      <table border="0" width="100%" cellspacing="0" cellpadding="0" id="TABLE1">
        <tr>
          <td width="100%">

         <!--- <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="34%" height="25"></td>
            </tr>
          </table>

          <div align="center">

            <table width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td height="15"><font class="textblue">
                <p align="center"></font></td>
              </tr>
            </table> 

            <center> --->
            <div align="center">
              <center>

              <table border="0" width="98%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td  width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
                  <td  width="32%"><input name="txtbranchcode" size="7" class="txtautofill"
                  value="<%=session("branchcode")%>" readonly><input 
                  type="button" value=" L " name="buttbr" disabled onclick="branch()" class="button"><input 
                  name="txtbranchdesc" readonly size="18" class="bgcolor1" value=" <%=session("branchnarration")%>" ></td>
                  <td align="right" width="20%">Currency Code</td>
                  <td width="32%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtcurrencycode"  class="txtautofill"
                  readonly size="9" value="<%=session("currencycode")%>"><input 
                  name="buttcr" onclick="currency()" disabled type="button" value=" L " class="button"><input 
                  name="txtcurrencydesc" readonly size="16" class="bgcolor1" 
                  value="<%=session("currencynarration")%>"></td>
                </tr>
              </table>

              </center>
            </div>
            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>
        <div align="center">
          <center>

          <table cellpadding="0" cellspacing="0" width="98%" class="tablebordermain">
            <tr>
              <td>
              <div align="center">
                <center>

                <table cellpadding="0" cellspacing="0" width="100%" class="tablebordermain">
                  <tr>
                    <td colspan="2" valign="top" width="115%">
                    <td>&nbsp;
                  </tr>
                  <tr>
                    <td height="105" rowspan="2" valign="top" width="53%">
                    <div align="center">
                      <center>

                      <table cellpadding="0" width="98%" class="tableborder2">
                        <tr>
                          <td width="100%">

                          <table border="0" cellpadding="0" cellspacing="0" height="134" width="100%">
                            <tr>
                              <td colspan="2" height="21" width="66%">&nbsp;</td>
                            </tr>
                            <tr>
                              <td height="27" width="12%">&nbsp; Exg. Amt.</td>
                              <td height="26" width="32%">&nbsp;<input maxlength="16" class="txtautofill" name="txtExAmt" 
                              onkeypress="numdec(window.document.frmex.txtExAmt.value,
                                  window.document.frmex.hpr.value);"
                              onblur="precision(window.document.frmex.txtExAmt,window.document.frmex.hpr.value);
                              CheckZero(window.document.frmex.txtExAmt)
                             " onfocus="amtselect(window.document.frmex.txtExAmt)" 
                             onkeypress="numeric()" size="11" style="TEXT-ALIGN: right" value="0.00"></td>
                            </tr>
                            <tr>
                              <td height="27" width="12%">&nbsp; Narration</td>
                              <td height="27" width="32%">&nbsp;<input maxlength="20" onkeypress="Alphanum()"
                              name="txtnarration" size="25" 'Dataarrange(window.document.frmex.txtnarration)' style="TEXT-ALIGN: left"></td>
                            </tr>
                            <tr>
                              <td height="27" width="12%">&nbsp; MOBILE</td>
                              <td height="27" width="32%">&nbsp;<input maxlength="10" onkeypress="numeric()"
                              name="txtMobile" size="25" 'Dataarrange(window.document.frmex.txtMobile)' style="TEXT-ALIGN: left" ></td>
                            </tr>
                            <tr>
                               <td height="27" width="12%">&nbsp; PANNO</td>
                              <td height="27" width="32%">&nbsp;<input maxlength="10" onkeypress="Alphanum()"  onblur="panCheck()"
                              name="txtPann" size="25" 'Dataarrange(window.document.frmex.txtPann)' style="TEXT-ALIGN: left"></td>
                            </tr>
                            <tr>
                              <td height="27" width="12%">&nbsp; AADHARNO</td>
                              <td height="27" width="32%">&nbsp;<input maxlength="12" onkeypress="numeric()"
                              name="txtAdhar" size="25" 'Dataarrange(window.document.frmex.txtAdhar)' style="TEXT-ALIGN: left"></td>
                            </tr>
                            <tr>
                              <td height="28" width="12%">&nbsp;</td>
                              <td height="28" width="32%">&nbsp;</td>
                            </tr>
                            <tr>
                              <td height="23" width="12%">&nbsp;</td>
                              <td height="23" width="32%">&nbsp;</td>
                            </tr>
                          </table>

                          </td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td valign="top" width="62%"><!-- -----------------------DENOMINATIONS---------------------------------->
                    <div align="center" id="denom" >

                      <table cellpadding="0" width="100%" class="tableborder2">
                        <tr>
                          <td>

                          <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                              <td width="100%">
                              <td><IFRAME align=center frameBorder=0 
                              frameSpacing=0 height=380 noResize 
                              src="masterdenomex.aspx" 
                              style="BACKGROUND-COLOR: darkred" width=446 
                              valign="top"></IFRAME></td>
                            </tr>
                          </table>

                          </td>
                        </tr>
                      </table>

                    </div>
                    <!--------------------------------END DENOMINATIONS--------------------------></td>
                  </tr>
                </table>

                </center>
              </div>
              <center></center>

              <table border="0" cellpadding="0" cellspacing="0" width="98%">
                <tr>
                  <td height="8" width="41%"></td>
                  <td align="right" height="8" valign="top" width="6%"></td>
                  <td align="right" height="8" valign="top" width="11%"></td>
                  <td align="right" height="8" valign="top" width="17%"></td>
                  <td height="8" valign="top" width="11%"></td>
                  <td height="8" valign="top" width="18%"></td>
                </tr>
                <tr>
                 
                  <td align="right" height="31" width="6%"><font class="textred"><span id="total" style="VISIBILITY: hidden">Total&nbsp;</font></td>
                  <td align="right" height="31" valign="top" width="11%"><input name="txtAtotal" onchange="precision(window.document.frmex.txtrtotal,window.document.frmex.hpr.value)" readonly size="10" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"></td>
                  <td align="right" height="31" valign="top" width="17%"></td>
                  <td height="31" valign="top" width="11%"><font class="textred"><span id="intotal" style="VISIBILITY: hidden">In Total&nbsp;</font><input name="txtrtotal" onchange="precision(window.document.frmex.txtrtotal,window.document.frmex.hpr.value)" readonly size="10" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"></td>
                  <td height="31" valign="top" width="18%"><font class="textred"><span id="outtotal" style="VISIBILITY: hidden">Out Total&nbsp;</font><input name="txtptotal" onchange="precision(window.document.frmex.txtptotal,window.document.frmex.hpr.value)" readonly size="10" class="bgcolor1" style="TEXT-ALIGN: right" value="0.00"></td>
                </tr>
                <tr>
                  <td colspan="6" width="100%" height="5"></td>
                </tr>
              </table>

              </td>
            </tr>
            
             <td height="31" width="41%">
                  <div align="center">
                    <center>

                    <table cellpadding="0" cellspacing="0" height="19" width="15%" class="tablebordermain" align="center">
                      <tr>
                        <td height="19" align="center" width="100%">
                        <p align="center"><input name="cmdAdd" onclick="Insert()" 
                        style="LEFT: 14px; TOP: 0px" type="button" 
                        value="   Ok    " class="button"><input 
                        name="cmdcancel" 
                        onclick="window.location.href='cashexchange.aspx'" 
                        class="button" style=" HEIGHT: 24px; WIDTH: 69px" 
                        type="button" value=" Cancel "><input 
                        name="cmdExit" 
                        onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" class="button" style=" HEIGHT: 24px; WIDTH: 69px" type="button" value="   Exit  "></p>
                        </td>
                      </tr>
                    </table>

                    </center>
                  </div>
                  </td>
          </table>

          </center>
        </div>
        <input name="hcount" type="hidden"><input name="hpr" type="hidden"><input name="hvalue" type="hidden"><input name="hrec" type="hidden"><input name="hpaid" type="hidden"><input name="htype" type="hidden"><input name="havail" type="hidden">

        </form>
        </div>
      </center></td>
    </tr>
  </table>
  
  <div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
  
</body>
</html>
