<%@ Page Language="vb" CodeBehind="remtypeflylst.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.remtypeflylst" %>
<%str=Request.QueryString("st")%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title></title>
</head>
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{  var s,rec,fld
  str=window.document.frmremtype.hval.value    
  //alert(str)
  window.attachEvent(window.opener.remitype(str))  
  window.close()
}
//-->
</SCRIPT>

<%
dim glcode
glcode=str
set recrtype=server.CreateObject("adodb.recordset")
set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
set recrtype=obj.singleRecordSet("REMTYPEPMT","REMTYPE,ISSUEDONBANKCODE,ISSUEDONBANKDESC,COMMGLCODE,COMMMODULEID,COMGLDESC ","REMGLCODE='" & glcode & "'")
dtls=recrtype(0)&"~" & recrtype(1)&"~" & recrtype(2)&"~" & recrtype(3)&"~" & recrtype(4)&"~" & recrtype(5)
'for desc for brdesc
'Response.Write dtls
'onload="list()"
%>

<body onload="List()">

<form name="frmremtype">
  <input type="hidden" name="hval" value="<%=dtls%>">
  <p>&nbsp;</p>
</form>

</body>

</html>
