<%@ Page CodeBehind="CashForCashier.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.CashForCashier" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<%
dim vUserid,vCounterNo,vAppdate,vCashierid
vUserid=session("userid")
vCounterNo=session("Counterno")
vAppdate=session("applicationdate")
vCashierid=session("userid")
vBranchCode=session("branchcode")
vCurCode=session("currencycode")
vBrnarration=session("branchnarration")
vCurnarration=session("currencynarration")
%>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>New Page 1</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<script language=javascript>
<!--
var strSessionFld,strsessionflds
function branch()
	{
	
	window.document.frmcashforcashier.MsgfCashier.Rows=1
	window.document.frmcashforcashier.txtCashierId.value=""
	window.document.frmcashforcashier.txtCashierName.value=""
	st="Branch"
	window.open("list.asp" + "?"+"st="+st,"Branch","width=300%,height=150%")
	
	}
	
	function Branchid(str)
	{
		//alert(str)
		//var balstr=new String()	
		assign(str,window.document.frmcashforcashier.txtbranchdesc,window.document.frmcashforcashier.txtbranchcode)
		//balstr=str.split("-----")
		//window.document.frmcashforcashier.txtbranchcode.value =balstr[1]   
		//window.document.frmcashforcashier.txtbranchdesc.value =balstr[0]
	
	
	}
	
	function currency()
	{
	
	window.document.frmcashforcashier.MsgfCashier.Rows=1
	window.document.frmcashforcashier.txtCashierId.value=""
	window.document.frmcashforcashier.txtCashierName.value=""
	
	st="Currency"
	window.open("list.asp" + "?"+"st="+st,"Branch","width=300%,height=150%")
	}
	
	function Currencyid(str)
	{
	var RowcntTran
	var rowcntCash
	
		assign(str,window.document.frmcashforcashier.txtcurrencydesc,window.document.frmcashforcashier.txtcurrencycode)
		//var balstr=new String()	
		//balstr=str.split("-----")
		//window.document.frmcashforcashier.txtcurrencycode.value =balstr[1]   
		//window.document.frmcashforcashier.txtcurrencydesc.value =balstr[0]
		
		
	}
	
	////calling list for cashiers
	function Cashiers()
	{
		window.document.frmcashforcashier.MsgfCashier.Rows=1
		st1="ALLCASHIERS"
		st2=window.document.frmcashforcashier.txtbranchcode.value
		st3=window.document.frmcashforcashier.txtcurrencycode.value
		st=st1+"|"+st2+"|"+st3
		////alert(st)
		window.open("List.asp" + "?"+"st="+st,"cash","width=300%,height=150%,left=132%,top=300%")
	}
	
	function Cashiercd(str)
	{
		//var balstr=new String()	
		//alert(str)
		balstr=str.split("-----")
		window.document.frmcashforcashier.txtCashierId.value=balstr[1]
		window.document.frmcashforcashier.txtCashierName.value=balstr[0]
		window.document.frmcashforcashier.txtCounterNo.value=balstr[2]
		getCashPosition()
	}
	
	//To Get cash from cashierposmst depending on cahierid
	function getCashPosition()
	
	{
	var cashier,Counter
	var strPending
	
	s1=window.document.frmcashforcashier.txtbranchcode.value  //BranchCode
	s2=window.document.frmcashforcashier.txtcurrencycode.value //CurrencyCode
	s3="CASHIERPOSITION"
	Counter=window.document.frmcashforcashier.txtCounterNo.value
	cashier=window.document.frmcashforcashier.txtCashierId.value////storing the cashierid
	strPending=s1+"|"+s2+"|"+"CASHCASHIERPOSMST|"+s3+"|"+cashier+"|"+Counter
	window.open("CashPendingTransQuery.asp"+"?"+"st="+strPending,"hell","width=10%,height=10%")
	}

	function TransPending(strpend)
	{
	var Rowvals=new String()
	var colvals=new String()
	var rowcnt
	Rowvals=strpend.split("|")
	window.document.frmcashforcashier.MsgfCashier.Rows=window.document.frmcashforcashier.MsgfCashier.Rows+(Rowvals.length-1)
	//alert(Rowvals.length)
	rowcnt=Rowvals.length-1
	for(i=1;i<Rowvals.length;i++)
		{
			colvals=Rowvals[i-1].split("$")
			//alert(Rowvals[i-1])
			window.document.frmcashforcashier.MsgfCashier.TextMatrix(i,0)=colvals[0]
			window.document.frmcashforcashier.MsgfCashier.TextMatrix(i,1)=colvals[1]
			window.document.frmcashforcashier.MsgfCashier.TextMatrix(i,2)=colvals[2]
		}
	window.document.frmcashforcashier.txtAmount.value=Rowvals[i-1]
	
	}
	
	//----------------------------------------------------------------------------------
function NatBranch(){
     with(window.document.frmcashforcashier)
         {
         txtbranchcode.value=strsessionflds[4];
         txtbranchdesc.value=strsessionflds[5];
         txtcurrencycode.value=strsessionflds[6];
         txtcurrencydesc.value=strsessionflds[7];
         }
}   

//----------------------------------------------------------------------------------
function PubVariables()
{
     strSessionFld=window.document.frmcashforcashier.txtSessionflds.value
     strsessionflds=strSessionFld.split("~");
}
//----------------------------------------------------------------------------------

	//alert (strPending)
	//window.open("CashPendingTransQuery.asp"+"?"+"st="+strPending,"hell","width=10%,height=10%")
//-->
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();NatBranch()">

<%appdate=formatdatetime(session("applicationdate"),1)%>

<form name="frmcashforcashier">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%"><img name="placeholder" border="0" src="file:///D:/prashanti/Newversion3.0/newhtmlfiles/dscript42/transparent.gif" width="1" height="22"></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25"></td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Cash Position For Cashier</font></td>
          <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" nowrap align="right" height="15">
      <p align="center">
    </tr>
    <tr>
      <td width="100%">
      <div align="center">

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="116">
            <p align="right"><font class="textbold">&nbsp; Branch Code</font></p>
            </td>
            <center>
            <td width="249"><input name="txtbranchcode" size="9" style="TEXT-ALIGN: right" readonly disabled><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="16" readonly class="bgcolor1"></td>
            </center>
            <td align="right" width="126">
            <p align="right"><font class="textbold">Currency Code</font></p>
            </td>
            <center>
            <td align="right" width="249"><input name="txtcurrencycode" size="9" readonly disabled>
            <input type="button" value=" L " id="butcur" name="butcur" onclick="currency()">
            <input name="txtcurrencydesc" size="16" readonly class="bgcolor1"></td>
            </tr>
          </table>

        </center>
      </div>
      </td>
    </tr>
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td width="100%">
              <div align="center">
                <center>

                <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tbody>
                    <tr>
                      <td width="725" valign="top">

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="100%" height="10"></td>
                        </tr>
                        <tr>
                          <td width="100%">
                          <div align="center">
                            <center>

                            <table width="91%" cellpadding="0" class="tableborder2">
                              <tbody>
                                <tr>
                                  <td width="100%" valign="top">

                                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td width="13%" height="26">&nbsp; Cashier</td>
                                      <td width="32%" height="26"><input name="txtCashierId" size="9" disabled><input type="button" value=" L " name="butCashier" onclick="Cashiers()"><input name="txtCashierName" size="16" disabled></td>
                                      <center></center><center></center><center></center>
                                      <td width="30%" height="26">
                                      <p align="right">&nbsp;Counter
                                      No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                                      </td>
                                      <center>
                                      <td width="25%" height="26"><input name="txtCounterNo" size="4" disabled></td>
                                      </tr>
                                      <tr>
                                        <td width="13%" height="15"></td>
                                        <td width="32%" height="15"></td>
                                        <td width="30%" height="15"></td>
                                        <td width="25%" height="15"></td>
                                      </tr>
                                    </table>

                                  </center></td>
                                </tr>
                            </table>

                            </div>
                            <div align="center">
                              <center>

                              <table border="0" width="91%" cellspacing="0" cellpadding="0">
                                <tr class="bgcolor">
                                  <td width="100%"><font class="subheading">&nbsp; Cash
                                  Amount</font></td>
                                </tr>
                                <tr>
                                  <td width="100%">

                                  <table width="100%" cellpadding="0" class="tableborder2">
                                    <tr>
                                      <td width="100%">
                                      <p align="center">
                                      <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="233" id="MsgfCashier" name="MsgfCashier" style="LEFT: 22px; TOP: 0px" width="409" viewastext>
                                        <param name="_ExtentX" value="10821">
                                        <param name="_ExtentY" value="6165">
                                        <param name="_Version" value="393216">
                                        <param name="Rows" value="2">
                                        <param name="Cols" value="3">
                                        <param name="FixedRows" value="1">
                                        <param name="FixedCols" value="0">
                                        <param name="RowHeightMin" value="0">
                                        <param name="BackColor" value="-2147483643">
                                        <param name="ForeColor" value="-2147483640">
                                        <param name="BackColorFixed" value="-2147483633">
                                        <param name="ForeColorFixed" value="-2147483630">
                                        <param name="BackColorSel" value="-2147483635">
                                        <param name="ForeColorSel" value="-2147483634">
                                        <param name="BackColorBkg" value="8421504">
                                        <param name="GridColor" value="12632256">
                                        <param name="GridColorFixed" value="0">
                                        <param name="WordWrap" value="0">
                                        <param name="Redraw" value="-1">
                                        <param name="AllowBigSelection" value="1">
                                        <param name="ScrollTrack" value="0">
                                        <param name="Enabled" value="-1">
                                        <param name="RightToLeft" value="0">
                                        <param name="TextStyle" value="0">
                                        <param name="TextStyleFixed" value="0">
                                        <param name="FocusRect" value="1">
                                        <param name="HighLight" value="1">
                                        <param name="FillStyle" value="0">
                                        <param name="GridLines" value="1">
                                        <param name="GridLinesFixed" value="2">
                                        <param name="ScrollBars" value="2">
                                        <param name="SelectionMode" value="0">
                                        <param name="MergeCells" value="0">
                                        <param name="AllowUserResizing" value="0">
                                        <param name="PictureType" value="0">
                                        <param name="BorderStyle" value="1">
                                        <param name="Appearance" value="1">
                                        <param name="MousePointer" value="0">
                                        <param name="GridLineWidth" value="1">
                                        <param name="FormatString" value="^Denominations       |^Pieces          |&gt; Amount                                ">
                                        <param name="OLEDropMode" value="0">
                                      </object>
                                      </p>
                                      </td>
                                    </tr>
                                  </table>

                                  </td>
                                </tr>
                                <tr>
                                  <td width="100%" height="15"></td>
                                </tr>
                              </table>

                              </center>
                            </div>
                          </center></td>
                        </tr>
                        <tr>
                          <td width="100%" height="10">
                          <div align="center">
                            <center>

                            <table border="0" width="91%" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="61%" height="26">
                                <p align="right">&nbsp; Total Cash
                                Amt&nbsp;&nbsp;&nbsp;&nbsp;</p>
                                </td>
                                <td width="45%" height="26"><input name="txtAmount" size="16" disabled></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                          </td>
                        </tr>
                      </table>

                      <center></center>

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <center>
                        <tr>
                          <td width="50%" height="10"></td>
                          <td width="50%" height="10"></td>
                        </tr>
                        </table>

                      </center></td>
                    </tr>
                  </tbody>
                </table>

                </div>

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                  <tr>
                    <td width="100%" height="10">
                    <div align="center">
                      <center>

                      <table width="5%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="100%"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.asp&quot;)" class="bgcolor"></td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td width="100%" height="10"></td>
                  </tr>
                </table>

              </center></td>
            </tr>
          </tbody>
        </table>

        </center>
      </div>
      </td>
    </tr>
    <tr>
      <td width="100%"></td>
    </tr>
    <tr>
      <td width="100%"></td>
    </tr>
    <tr>
      <td width="100%"></td>
    </tr>
  </table>

  <input type="hidden" name="txtSessionflds" value="<%=vUserid&"~"&vAppdate&"~"&vCounterno&"~"&vCashierid&"~"&vBranchCode&"~"&vBrnarration&"~"&vCurCode&"~"&vCurnarration&"~"%>">
</form>

</body>

</html>
