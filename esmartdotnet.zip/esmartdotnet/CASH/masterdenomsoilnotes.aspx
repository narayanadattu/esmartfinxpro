<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="masterdenomsoilnotes.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.masterdenomsoilnotes" %>


<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--

function CashMultiply(Note,Rs,Amt,NoteType,paid,pval)
{//alert(" Mahender Note = "+Note+" Rs = "+Rs.value+" Amt = "+Amt.value+" NoteType = "+NoteType + "paid " + paid.value)
 var i,T
 if(NoteType=="CP")
{
Note="0."+Note	
}
	
  if(Rs.value!="")
  {
	paid.value=""
	pval.value="0.00"
	//paid.disabled=true
	Ptotal()
  }
  else
  {
	paid.value=""
	pval.value="0.00"
	//paid.disabled=false
	Ptotal()
  }
  
  if (Rs.value=="")
  {
     Amt.value="0.00"
     Rtotal()
  }
  else
  {
  	   Amt.value=eval(Note)* eval(Rs.value)
	   Rtotal()
  }	
 
    
}


function PCashMultiply(Note,Rs,Av,Amt,NoteType)
{
	//alert(" Reddy Note = "+Note+" Rs = "+Rs.value+" Av = "+Av.value+" Amt = "+Amt.value+" NoteType = "+NoteType)
 var i,T
 if(NoteType=="CP")
{
Note="0."+Note	
}
  if (Rs.value=="")
  {
     Amt.value="0.00"
    Rtotal()
    Ptotal()
  }
  else
  {
   if(eval(Rs.value)<=eval(Av.value))
    {
		Amt.value=eval(Note)* eval(Rs.value)
		Rtotal()
    Ptotal()
	}
	else
	{
	   alert("Should not exchange more than Available Pieces")
	   Rs.value=""
	   Amt.value="0.00"
	   Ptotal()
	}	
  }
  }

//}

function Ptotal()
{
var i,k
var Cnt,frm
    Cnt=window.document.frmdm.hcnt.value 
        
   k=0
for (i=0;i< Cnt; i++)   
{
		k = eval(k) + eval(window.document.frmdm.txtpamt(i).value)
}
    
 window.attachEvent(window.parent.ptotalSumAmount(k))
   
}    

function Rtotal()
{
	var Cnt
	var i,k
    Cnt=window.document.frmdm.hcnt.value 
    
	k=0
    for (i= 0; i < Cnt; i++)
	{
		k = eval(k) + eval(window.document.frmdm.txtramt(i).value)
	}

    window.attachEvent(window.parent.rtotalSumAmount(k))	
      
}



function List()
{
var kstr
  kstr= window.document.frmdm.hcounter.value
  var kstrsv
  kstrsv= window.document.frmdm.hcountersv.value
//  alert("kstrsv" + kstrsv)
  if(kstr)
  {
  window.attachEvent(window.parent.GetATotal(kstr,kstrsv))
  window.close()
  }
}

//-->
</SCRIPT>


<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=vbscript>
sub Rtotal1()
	dim Cnt
	dim frm
	dim i,k
    Cnt=window.document.frmdm.hcnt.value 
    frm=window.document.frmdm.hfrm.value
    
    for i=0 to Cnt-1
	    k=cdbl(k)+ cdbl(window.document.frmdm.txtramt(i).value)
	next
	
	
    window.parent.window.document.forms(frm).txtrtotal.value=k
    window.parent.window.document.forms(frm).txtrtotal.onchange()
    
end sub

sub Ptotal1()
dim i,k
dim Cnt,frm
    Cnt=window.document.frmdm.hcnt.value 
    frm=window.document.frmdm.hfrm.value
    
    
    for i=0 to Cnt-1
	    k=cdbl(k)+ cdbl(window.document.frmdm.txtpamt(i).value)
	next
	
	
    window.parent.window.document.forms(frm).txtptotal.value=k
    window.parent.window.document.forms(frm).txtptotal.onchange()
    
end sub
</SCRIPT>

<%
dim counter
Dim obj,st,kstr
	kstr=Request.Form("hdenom")
	k=split(kstr,"|")
	'Response.Write k(0) & "<br>"
	'Response.Write k(1) & "<br>"
	'Response.Write k(2) & "<br>"
	
%>
<title></title>
</head>
<body topmargin="0" leftmargin="0"  onload = "List()">

<form name="frmdm">
  <!--<table border="0" width="100%" cellspacing="0" cellpadding="0" style="height: 32px">
<tr>
  <td>-->

  

  <%
  
DIM ObjCash,RecCash
dim Cashid,countno
CashId=ucase(trim(session("userid")))

'Session("applicationdate")="06-May-2001"
'BrCode=session("branchcode")
'CurCode=session("CurrencyCode")
appdate=session("applicationdate ")
'Response.Write appdate
'countno=session("counterno")
 ObjCash=server.CreateObject("QueryRecordsets.fetchRecordsets")
 RecCash=server.CreateObject("adodb.recordset")

 RecCash=ObjCash.singlerecordset("cashcashierposmst","counterno","upper(trim(cashierid))='" & CashId & "'")
if not RecCash.EOF then
countno=RecCash(0).value
end if
 RecCash=nothing
 ObjCash=nothing
if len(kstr)>0 then
	'	 obj=server.CreateObject("cashquery.queries")
			 obj=server.CreateObject("SoilNotesQuery.soilnotesqueries")
		st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)),cstr(appdate),cstr(cashid),cstr(countno),,"Y")
		
		'st=obj.CashDenominationsAsarray("cashcashierposmst",cstr(BrCode),cstr(CurCode),cstr(appdate),cstr(cashid),cstr(countno))
		
		tval=k(3)
				
	if ubound(st)>0 then    
  %>
  <!-- </td>
  </tr>
  <tr>
  <td>-->
  <%
  %>
  <input type="hidden" name="hfrm" value="<%=k(0)%>">

  <table border="0" width="410" cellspacing="0" cellpadding="0" style="height: 32px">
    <tr class="bgcolor">
      <td width="418"><font class="textwhite">&nbsp;Denoms&nbsp;&nbsp;&nbsp;
      Avail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Received&nbsp;&nbsp;&nbsp; Paid&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RecAmt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      PaidAmt&nbsp;<br>
      <!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
      Pieces&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      Pieces&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Pieces</font></td>
    </tr>
  </table>

  <table border="1" cellspacing="0" cellpadding="0" width="280" style="HEIGHT: 68px; WIDTH: 410px">
    <%dim ind,m ',cnt
 	for j=0 to ubound(st)
 	if st(j,0)="CP" then
 	   ind=ind+1
 	end if
 	next
 	 m=0
 	 cal=st(1,3)
	  p=len(cal)-1%>
    <input type="hidden" name="hpr" value="<%=p%>">
    <tr class="bgcolor">
      <td height="10" align="center"><font class="textbold">Notes</font></td>
      <td height="10" align="center" valign="top"><font class="textbold">CashVal</font></td>
      <td height="10" align="center" valign="top"><font class="textbold">SoilVal</font></td> 
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"><font class="textbold">Soil In</font></td>
      <td width="90" height="10" align="center"><font class="textbold">Cash Out</font></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
    </tr>
    
    
	  <%
	  c =  0
	   m=0 
 	FOR i=0 TO ubound(st)-1 %>
 	<%'if st(i,1)<>"" then %>
 	<%cnt=cnt+1
 	  cal=st(i,3)
	  p=len(cal)-1
	  'total=cdbl(st(i,1)) * cdbl(st(i,2))
	 ' Response.Write total
	 ' Tot=cdbl(Tot)+cdbl(total)
	  
	  
	 ' Response.Write Tot
	  
	  %>
    <input type="hidden" name="hTot" value="<%=Tot%>"><input type="hidden" name="hTotsv" value="<%=Totsv%>">    
    <input type="hidden" name="hps" value="<%=st(i,1)%>"><input type="hidden" name="htype" value="<%=st(i,0)%>"><input type="hidden" name="havail" value="<%=st(i,2)%>">
    <input type="hidden" name="havailsn" value="<%=st(i,4)%>">
   <%if ((st(i,0)="CF" and c = 0) or (st(i,0)="CP" and c = 0)) then 
        c = 1
       
        %>
    <tr class="bgcolor">
      <td height="10" align="center"><font class="textbold">Coins</font></td>
      <td height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
      <td width="90" height="10" align="center"></td>
    </tr>
    <%end if%>	
    
    
    <tr align="middle">
      <td width="60" height="10" align="right">
		<%=st(i,1)%></td>
      <!-- <input type="hidden" name="hps" value="<%=st(i,1)%>">-->
      <td width="60" height="10" align="right">
		<%=st(i,2)%>
		<!--<input type="hidden" name="htype" value="<%=st(i,0)%>">--></td>
		<td width="26" height="10" valign="top"><%=st(i,4)%></td>
      <td width="26" height="10" valign="top">*</td>
      <!--<input type="hidden" name="havail" value="<%=st(i,2)%>">-->
      <%if st(i,0)="CP" then
           cal=st(i,3)
           
		   amt=st(i,1)'/cal
		   
		  'Response.Write  val(st(i,1)&"")
		  'Response.End 
		   if (st(i,1))<>"" then
		 	total=("." & st(i,1) * cdbl(st(i,2)))
		 	totalsv=("." & st(i,1) * cdbl(st(i,4)))
		   end if  	 
	  Tot=cdbl(Tot)+cdbl(total)  
	 
		   Totsv=cdbl(Totsv)+cdbl(totalsv)  
		   
	  %>
      <input type="hidden" name="hamt" value="<%=amt%>">
      
			<%if ind>1 then	
			
			%>	
     <td width="26" height="10" align="middle"><input id="txtrec" name="txtrec" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" 
      onkeyup='CashMultiply(window.document.frmdm.hamt(<%=m%>).value,
      window.document.frmdm.txtrec(<%=i%>),
      window.document.frmdm.txtramt(<%=i%>),&quot;<%=st(i,0)%>&quot;,window.document.frmdm.txtpaid(<%=i%>),window.document.frmdm.txtpamt(<%=i%>));
      precision(window.document.frmdm.txtramt(<%=i%>),<%=p%>)'></td>
      <td width="26" height="10" align="middle"><input id="txtpaid" 
      name="txtpaid" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" 
      size="7" onkeypress="numeric()" 
      onkeyup='PCashMultiply(window.document.frmdm.hamt(<%=m%>).value,
      window.document.frmdm.txtpaid(<%=i%>),
      window.document.frmdm.havail(<%=i%>),
      window.document.frmdm.txtpamt(<%=i%>),"<%=st(i,0)%>");
      precision(window.document.frmdm.txtpamt(<%=i%>),<%=p%>)'></td>
			<%
			m=m+1%>
			<%else
			 %>
      <td width="26" height="10" align="middle"><input id="txtrec" name="txtrec" 
      style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" size="6" 
      onkeypress="numeric()" 
      onkeyup='CashMultiply(window.document.frmdm.hamt.value,
      window.document.frmdm.txtrec(<%=i%>),
      window.document.frmdm.txtramt(<%=i%>),"<%=st(i,0)%>",window.document.frmdm.txtpaid(<%=i%>),window.document.frmdm.txtpamt(<%=i%>));
      precision(window.document.frmdm.txtramt(<%=i%>),<%=p%>)'></td>
      <td width="26" height="10" align="middle"><input id="txtpaid" 
      name="txtpaid" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" 
      size="7" onkeypress="numeric()" 
      onkeyup='PCashMultiply(window.document.frmdm.hamt.value,
      window.document.frmdm.txtpaid(<%=i%>),
      window.document.frmdm.havail(<%=i%>),
      window.document.frmdm.txtpamt(<%=i%>),"<%=st(i,0)%>");
      precision(window.document.frmdm.txtpamt(<%=i%>),<%=p%>)'></td>
			<%end if%>	
		<%else
		total=cdbl(st(i,1)) * cdbl(st(i,2))
		
	  Tot=cdbl(Tot)+cdbl(total)
	  totalsv = cdbl(st(i,1)) * cdbl(st(i,4))
	  
	   Totsv=cdbl(Totsv)+cdbl(totalsv)
		%>
      <td width="26" height="10" align="middle"><input id="txtrec" name="txtrec" 
      style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" 
      size="6" onkeypress="numeric()" 
      onkeyup='CashMultiply(window.document.frmdm.hps(<%=i%>).value,
      window.document.frmdm.txtrec(<%=i%>),
      window.document.frmdm.txtramt(<%=i%>),"<%=st(i,0)%>",window.document.frmdm.txtpaid(<%=i%>),window.document.frmdm.txtpamt(<%=i%>));
      precision(window.document.frmdm.txtramt(<%=i%>),<%=p%>)'></td>
      <td width="26" height="10" align="middle"><input id="txtpaid" 
      name="txtpaid" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" 
      size="7" onkeypress="numeric()" 
      onkeyup='PCashMultiply(window.document.frmdm.hps(<%=i%>).value,
      window.document.frmdm.txtpaid(<%=i%>),
      window.document.frmdm.havail(<%=i%>),
      window.document.frmdm.txtpamt(<%=i%>),"<%=st(i,0)%>");
      precision(window.document.frmdm.txtpamt(<%=i%>),<%=p%>) '></td>
		<%end if%>	
		<% if tval="INR" then
             des="0.00"
          elseif tval="USD" THEN
             des="0.000"
          end if      
       %>	
      <td width="71"><input id="txtramt" name="txtramt" value="<%=des%>" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" size="9" readonly disabled></td>
      <td width="71"><input id="txtpamt" name="txtpamt" value="<%=des%>" style="FONT-SIZE: x-small; HEIGHT: 22px; TEXT-ALIGN: right" size="9" readonly disabled></td>
      <%'end if%>
    </tr>
	<%next%> 
	
	<%
	if len(Tot)>0 then
	counter = Tot
	else
	counter = 0
	end if
	
	if len(Totsv)>0 then
	countersv = Totsv
	else
	countersv = 0
	end if
	'Response.Write ("<script language=vbscript>" & chr(13))
	'if len(Tot)>0 then
    '  Response.Write ("window.parent.window.document.forms(frm).txtAtotal.value="& Tot & chr(13))
    '  Response.Write ("call precision(window.parent.window.document.forms(frm).txtAtotal,window.document.frmdm.hpr.value)" & chr(13))
   ' end if
    '  Response.Write ("</script>") %>
	
  </table>

  <!--</td>
  </tr>
  </table>-->
  <%else
	Response.Write (st(0,0))
  %>  
  <% end if%>
  <% end if%>
  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" name="hcnt" value="<%=cnt%>">
  <input type="hidden" name="hcounter" value="<%=counter%>">
   <input type="hidden" name="hcountersv" value="<%=countersv%>">
</form>
</body>
</html>
