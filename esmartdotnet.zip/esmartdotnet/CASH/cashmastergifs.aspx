<%@ Page Language="vb" aspcompat="true" explicit="false"  CodeBehind="cashmastergifs.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashmastergifs" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title></title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmmasters">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tbody>
    </tbody>
  </table>

  <table width="98%">
    <tr>
      <td width="100%" height="12"></td>
    </tr>
  </table>

  <table width="100%" class="tablebordermain" cellspacing="0" cellpadding="0">
    <tbody>
      <tr>
        <td>

        <table border="0" width="97%" cellspacing="0" cellpadding="0">
          <tr>
            <td>

            <table width="98%">
              <tr>
                <td width="100%" height="20">&nbsp;&nbsp;&nbsp;<b><span id="spanLO1" style="VISIBILITY: visible"><a href="http://<%=session("moduledir") & "/" & session("module") & "/cashiertypesmast.aspx"%>" target="forms"><font class="textbold">Cashier Type</span></font></a></td>
              </tr>
              <tr>
                <td width="100%" height="20">&nbsp;&nbsp;&nbsp;<b><span id="spanLO1" style="VISIBILITY: visible"><a href="http://<%=session("moduledir") & "/" & session("module") & "/cashcountermst.aspx"%>" target="forms"><font class="textbold">Cash Counter</span></font></a></td>
              </tr>
              <tr>
                <td width="100%">&nbsp;&nbsp;&nbsp;<b><span id="spanLO1" style="VISIBILITY: visible"><a href="http://<%=session("moduledir") & "/" & session("module") & "/" & session("module") & "module.aspx"%>" target="_top"><font class="textbold">EXIT</span></font></a></b></td>
              </tr>
              <tr>
                <td width="100%" height="200">
              </tr>
            </table>

        </table>

        </td>
      </tr>
    </tbody>
  </table>

</form>

</body>

</html>
