<%@ Page language="vb" CodeBehind="Tellerpaymentdetails.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.Tellerpaymentdetails" %>
<%
dim batch,trnno,glcode,gldesc,accno,accnm,amt,moddesc
dim narration,curdesc,curr,modid,branch,str,brname,strcom

applDt=session("applicationdate")
userId=session("userid")
counterId=session("Counterno")

str=Request.QueryString("record")
if len(str)> 0 then
 strcom=split(str,"*||*")
if ucase(trim(strcom(1)))="TELLERPAYMENT" then

	str=Split(strcom(0),"~")
	if len(str(0))> 0 then
	
		batch=str(0)
		trnno=str(1)
		glcode=str(2)
		gldesc=str(3)
		accno=str(4)
		accnm=str(5)
	 if sgn(str(6))="-1" then
		amt=mid(str(6),2)
		else
		amt=str(6)
	 end if
		curr=str(14)
		modid=str(19)
		branch=str(20)
		narration=str(22)
	
		str1=branch&"~"&curr&"~"&applDt&"~"&userId&"~"&counterId&"~"
		set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
		set rsbranch=server.CreateObject("adodb.recordset")
		set rsgl=server.CreateObject("adodb.recordset")
		set rsaccno=server.CreateObject("adodb.recordset")
		set rscur=server.CreateObject("adodb.recordset")
		set rsbranch=obj.singlerecordset("GENBANKBRANCHMST","distinct BRANCHNAME","BRANCHCODE='" & branch & "'")
		set rscur=obj.singlerecordset("GENCURRENCYTYPEMST","DISTINCT narration","CURRENCYCODE='" & curr & "'")
	IF rsbranch.EOF<>TRUE AND rsbranch.BOF<>TRUE THEN

	brname=rsbranch(0)

	end if
	IF rscur.EOF<>TRUE AND rscur.BOF<>TRUE THEN
		curdesc=rscur(0)
	END IF
	Set rsmod=obj.singlerecordset("GENMODULETYPESMST","distinct NARRATION","MODULEID='" & modid & "'")
	IF rsmod.EOF<>TRUE AND rsmod.BOF<>TRUE THEN
 
	moddesc=rsmod(0)
 
	end if
	SET rsbranch=NOTHING
	SET rsaccno=NOTHING
	SET rsgl=NOTHING
	SET rscur=NOTHING
	
  end if
elseif ucase(trim(strcom(1)))="PENDINGPAYMENTS" then
str=Split(strcom(0),"~")
if len(str(0))> 0 then
	branch=str(0)
	brname=str(1)
	curr=str(2)
	curdesc=str(3)
	batch=str(4)
	trnno=str(5)
	modid=str(10)
	glcode=str(6)
	accno=str(7)
	amt=str(8)
	narration=str(9)
	
	str1=branch&"~"&curr&"~"&applDt&"~"&userId&"~"&counterId&"~"
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=server.CreateObject("adodb.recordset")
	
	set rsgl=server.CreateObject("adodb.recordset")
	
	set rsaccno=server.CreateObject("adodb.recordset")
	
	set rs=obj.singlerecordset("GENMODULEMST","distinct MASTERTABLE,narration","BRANCHCODE='" & branch & "' AND CURRENCYCODE='" & curr & "' AND MODULEID='" & modid & "'")
	set rsgl=obj.singlerecordset("GENGLSHEETMST","DISTINCT narration","BRANCHCODE='" & branch & "' AND CURRENCYCODE='" & curr & "' AND MODULEID='" & modid & "' AND GLCODE='"& glcode &"'")
	IF rsgl.EOF<>TRUE AND rsgl.BOF<>TRUE THEN
		gldesc=rsgl(0)
	end if
	IF RS.EOF<>TRUE AND RS.BOF<>TRUE THEN
	moddesc=rs(1)
	Set rsaccno=obj.singlerecordset(CSTR(RS(0)),"distinct(name)","BRANCHCODE='" & branch & "' AND CURRENCYCODE='" & curr & "' and glcode='" & glcode & "' AND ACCNO='" & accno & "'")
	IF rsaccno.EOF<>TRUE AND rsaccno.BOF<>TRUE THEN
		 accnm=rsaccno(0)
	end if
	end if
	SET RS=NOTHING
	SET rsgl=NOTHING
	SET rsaccno=NOTHING
end if
end if
END IF
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<title>Payments</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<script language=javascript>
<!--
function branch()
	 {
	   st="Branch";
	   window.open("List.asp" + "?"+"st="+st,st,"width=200%,height=150%");
	 }
	 

	function currency()
	
	 {  
	 st="Currency"
	 window.open("List.asp" + "?"+"st="+st,st,"width=250%,height=150%")
	 }
	 

	function Branchid(str)
	 { 
	  assign(str,window.document.frmtrans.txtbranchdesc,window.document.frmtrans.txtbranchcode)
	 } 

   function Currencyid(str)
	 {
		assign(str,window.document.frmtrans.txtcurrencydesc,window.document.frmtrans.txtcurrencycode)
	 } 	 
	 
	 function frmSub(){
	 if(eval(window.document.frmtrans.txttotal.value)==eval(window.document.frmtrans.txtAmt.value)){
		//to form denom value string	 
		var DValStr
		var DVal
		DValStr=""
		for(i=0;i<window.document.frames(0).frmdm.hps.length;i++){
			DVal=window.document.frames(0).frmdm.hps[i].value;
			DValStr=DValStr+DVal+"~"
		}
		window.document.frmtrans.DemonValue.value=DValStr
		

		//to form denom Type  string	 
		var DTypStr
		var DTyp
		DTypStr=""
		for(i=0;i<window.document.frames(0).frmdm.htype.length;i++){
			DTyp=window.document.frames(0).frmdm.htype[i].value;
			DTypStr=DTypStr+DTyp+"~"
		}
		window.document.frmtrans.DenomType.value=DTypStr
	
		//to form Paid amount string	 
		var DPayamtStr
		var DPayamt
		DPayamtStr=""
		for(i=0;i<window.document.frames(0).frmdm.txtpaid.length;i++){
			DPayamt=window.document.frames(0).frmdm.txtpaid[i].value;
			DPayamtStr=DPayamtStr+DPayamt+"~"
		}
		window.document.frmtrans.PaidAmt.value=DPayamtStr;
			
		//to form Paid amount string	 
		var DExamtStr
		var DExamt
		DExamtStr=""
		for(i=0;i<window.document.frames(0).frmdm.txtrec.length;i++){
			DExamt=window.document.frames(0).frmdm.txtrec[i].value;
			DExamtStr=DExamtStr+DExamt+"~"
		}
		window.document.frmtrans.ExchgAmt.value=DExamtStr;
	
		window.document.frmtrans.action="TellerPaymentInsert.asp";
		window.document.frmtrans.method="post"	;
		window.document.frmtrans.submit();
    }
   else
	{
		alert("Paid Amount and Denomination amount should be Equal");
	 
    }
	 
	 }
	 
function Pentran()
{

if(window.document.frmtrans.chkpen.checked==true)
	{
		
		location.href="Tellercashpayments.asp"
		
	}
}
 
	 
	 
	 
//-->
</script>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;)">

<form name="frmtrans">
  <input type="hidden" name="DemonValue"><input type="hidden" name="DenomType"><input type="hidden" name="PaidAmt"><input type="hidden" name="ExchgAmt">

  <table width="780" bordercolor="#643428" cellspacing="0" cellpadding="0" height="588" class="tablebordermain">
    <tbody>
      <tr>
        <td width="100%" valign="top">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="11%"></td>
            <td width="89%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr class="bgcolor">
            <td width="34%" height="25"></td>
            <td width="33%" height="25">
            <p align="center"><font class="text">Teller Payments Details</font></td>
            <td width="33%" height="25" align="right"></td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="758" colspan="4">
                <p align="center"></td>
              </tr>
              <tr class="bgcolor">
                <td width="94"><font class="textbold">&nbsp;Branch Code</font></td>
                <td width="272"><input name="txtbranchcode" size="9" value="<%=branch%>" readonly><input type="button" value=" L " name="buttbr" onclick="branch()" readonly disabled><input name="txtbranchdesc" size="16" value="<%=brname%>" readonly></td>
                <td width="157" align="right"><font class="textbold">Currency Code&nbsp;</font></td>
                <td width="229" align="right"><input name="txtcurrencycode" value="<%=curr%>" size="9" readonly><input type="button" value=" L " name="buttcur" onclick="currency()" disabled><input name="txtcurrencydesc" size="16" value="<%=curdesc%>" readonly></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td width="116%" colspan="2">&nbsp;</td>
            </tr>
            <tr>
              <td width="116%" colspan="2">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="7%"><font class="textsmall">&nbsp;Scroll No</font></td>
                  <td width="35%"><input name="txtScrollNo" size="10" value="1" readonly></td>
                  <!--<td width="8%">&nbsp;Token
                  No</font></td>-->
                  <td width="13%"><!--<input name="txtTokenNo" size="9" value="<%'=str(6)%>" readonly>
                  <input type="hidden" name="HidTokenNo" size="9" value="<%'=str(6)%>" readonly></td>
                  <td width="59%">--></td>
                </tr>
              </table>

              </td>
            </tr>
            <tr>
              <td width="46%" valign="top">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Batch No</font></td>
                  <td width="75%"><input name="txtbatch" size="10" value="<%=batch%>" readonly></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Tran No</font></td>
                  <td width="75%"><input name="txtTrnNo" size="10" value="<%=trnno%>" readonly>
                  <input name="applDt" type="hidden" size="10" value="<%'=str(12)%>" readonly></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Module ID</font></td>
                  <td width="75%"><input name="txtModuleId" size="10" value="<%=modid%>" readonly><input type="button" name="B3" value=" L " readonly disabled><input name="txtmoddesc" size="15" readonly value="<%=moddesc%>"></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Gl Code</font></td>
                  <td width="75%"><input name="txtGLCode" size="10" value="<%=glcode%>" readonly><input type="button" name="B2" value=" L " readonly disabled><input name="txtgldesc" size="15" value="<%=gldesc%>" readonly></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Acct No</font></td>
                  <td width="75%"><input name="txtAccNo" size="10" value="<%=accno%>" readonly><input type="button" name="B1" value=" L " disabled><input name="txtaccnm" size="15" readonly value="<%=accnm%>"></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Amount [Rs]</font></td>
                  <td width="75%"><input name="txtAmt" size="10" value="<%=amt%>" readonly></td>
                </tr>
                <tr>
                  <td width="27%"><font class="textsmall">&nbsp;Narration</font></td>
                  <td width="75%"><input name="txtNarration" size="30" value="<%=narration%>" readonly></td>
                </tr>
                <tr>
                  <td width="27%">&nbsp;</td>
                  <td width="75%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="100%" colspan="2"><input type="checkbox" name="chkpen" value="ON" onclick="Pentran()">
                  <font class="textblue"><a href="Tellercashpayments.asp">Pending
                  Transactions</a></font>&nbsp;</td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%">&nbsp;&nbsp;&nbsp;</td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%">&nbsp; <input type="button" name="B4" value="   Ok   " onclick="frmSub()" class="bgcolor"><input type="button" name="B5" value="Cancel" onclick="frmSub()" class="bgcolor"><input type="button" name="B6" value="  Exit  " onclick="frmSub()" class="bgcolor"></td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="27%"></td>
                  <td width="75%"></td>
                </tr>
                <tr>
                  <td width="27%">&nbsp;</td>
                  <td width="75%"></td>
                </tr>
              </table>

              </td>
              <td width="70%" valign="top">

          
              <!-- -----------------------DENOMINATIONS---------------------------------->
              <div id="denom" align="center" style="DISPLAY: block; HEIGHT: 358px; POSITION: absolute; TOP: 130px; WIDTH: 300px">

                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr>
                      <td><iframe id=idenom align=center frameborder=0 framespacing=0 noresize 
                   height=200 width=550 valign="top" src="CashDenome.asp?str=<%=str1%>" style="BACKGROUND-COLOR: darkred; HEIGHT: 260px; WIDTH: 392px"></iframe> 
                      </td>
                    </tr>
                  </tbody>
                </table>

              </div>
              <div style="DISPLAY: block; HEIGHT: 71px; LEFT: 454px; POSITION: absolute; TOP: 400px; WIDTH: 309px">
                <strong><font class="textred">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total
                </font></strong><input name="txttotal" size="11" value="0.00" class="bgcolor2" style="WIDTH: 85px">
                <input type="hidden" name="txttotal1" size="11" value="0.00" class="bgcolor2" style="HEIGHT: 22px; WIDTH: 85px">
              </div>
              </td>
            </tr>
          </tbody>
        </table>

        </td>
      </tr>
    </tbody>
  </table>

  <input type="hidden" name="hmenuvals" value="<%=session("menustring")%>">
</form>

</body>

