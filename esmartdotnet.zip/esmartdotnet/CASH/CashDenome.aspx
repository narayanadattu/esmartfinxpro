<%@ Page Language="vb" CodeBehind="CashDenome.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CashDenome" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CashDenome.asp				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| T.Anil kumar         |    04-MAY-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<%'option explicit
Response.Buffer=true
Response.Expires=0
On Error Resume Next
Dim obj,st,str,i,cnt
strDeno=Request.QueryString("str")

strDenom=split(Request.QueryString("str"),"~")
if not strDenom(0)="" and not strDenom(1)="" then 
set obj=server.CreateObject("cashquery.queries")

st=obj.CashDenominationsAsarray("cashcashierposmst",cstr(strDenom(0)),cstr(strDenom(1)),cstr(strDenom(2)),cstr(strDenom(3)),"","Y","Y") 
set obj=nothing
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
function CashMultiply(Note,Rs,Amt,subAmt,avlPiec)
{	
 var i,T;

  
  if (Rs.value=="")
  {	
   	if(subAmt.value==""){
		Amt.value="0.00";
	}
	else{
		Amt.value=eval(Note)*eval(subAmt.value);
    }
      totValue();
     
   }
  else
  {  
  	var ExAmt=subAmt.value;
	if(ExAmt=="")
		ExAmt=0;
		
		var avlChk=eval(ExAmt)+eval(Rs.value);
		
		//if(eval(avlPiec.value)<=avlChk)
		if(eval(avlChk) > eval(avlPiec.value))
		{
		    alert("Can not Give more than Available Pieces");
			Rs.value=0;
			Rs.focus();
			Rs.select();	
		}	
		
		Amt.value=(eval(Note)* eval(Rs.value))-(eval(Note)*eval(ExAmt));
	    totValue();
	   
   }
    
}

function CashSubsraction(Note,Rs,Amt,PaidAmt)
{
var i,T;
  if (Rs.value=="")
  {
    if(PaidAmt.value==""){
		Amt.value="0.00";
	}
	else{
		Amt.value=eval(Note)*eval(PaidAmt.value);
    }
    totValue();
  
   }
  else
  {  
  var pamt=PaidAmt.value;
  
	if(pamt=="")
		pamt=0;
	
	Amt.value=(eval(Note)* eval(pamt))-(eval(Note)* eval(Rs.value));
    totValue();
   
   }
}

function totValue(){
 var k=0;
  for(i=0;i<frmdm.hps.length;i++){
             
        k=eval(k)+ eval(window.document.frmdm.txtpamt(i).value);
	}  
	parent.document.forms[0].txttotal.value=k;
	//precision(window.parent.window.document.forms[0].txttotal,window.document.frmdm.hpr.value)
	
} 

  
//-->
</SCRIPT>

</SCRIPT>

<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<body>

<form name="frmdm">
  <div align="right">

    <table cellspacing="0" cellpadding="0" width="347" style="HEIGHT: 68px" class="tablebordermain">
      <tr class="bgcolor">
        <td width="1" height="10" align="middle" valign="top"><font class="textwhite">Denomination<br>
        value</font></td>
        <td width="46" height="10" align="middle" valign="top"><font class="textwhite">Available
        Pieces</font></td>
        <td width="40" height="10" align="middle" valign="top"><font class="textwhite">Paid
        Pieces</font></td>
        <td width="30" height="10" align="middle" valign="top"><font class="textwhite">Exchange<br>
        Pieces</font></td>
        <td width="7" height="10" align="middle" valign="top">&nbsp;</td>
        <td width="31" height="10" valign="top" align="middle"><font class="textwhite">Amount</font></td>
      </tr>
      <%if ubound(st)>0 then        	
  	FOR i=0 TO ubound(st)%>
 	  <%if st(i,1)<>"" then%>
 	  <%cnt=cnt+1%>	
      <tr align="middle">
        <td width="1" height="10" align="right"><font face="Arial" size="2">
		<%=st(i,1)%></font><input type="hidden" name="hps" value="<%=st(i,1)%>"><input type="hidden" name="htype" value="<%=st(i,0)%>"></td>
        <td width="46" height="10" align="right"><font face="Arial" size="2"><%=st(i,2)%><input type="hidden" name="AvlPiec" value="<%=st(i,2)%>"></font></td>
        <td width="40" height="10">
        <p><font face="Arial" size="2"><input id="txtpaid" name="txtpaid" onkeypress="numeric();" onkeyup="CashMultiply(window.document.frmdm.hps(<%=i%>).value,window.document.frmdm.txtpaid(<%=i%>),window.document.frmdm.txtpamt(<%=i%>),window.document.frmdm.txtrec(<%=i%>),window.document.frmdm.AvlPiec(<%=i%>));amountdigits(window.document.frmdm.txtpamt(<%=i%>))" size="6" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right"></font></p>
        </td>
        <td width="20" height="10" align="middle">
        <p><font face="Arial" size="2"><input id="txtrec" name="txtrec" onkeypress="numeric();" onkeyup="CashSubsraction(window.document.frmdm.hps(<%=i%>).value,this,window.document.frmdm.txtpamt(<%=i%>),window.document.frmdm.txtpaid(<%=i%>));amountdigits(window.document.frmdm.txtpamt(<%=i%>))" size="6" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right"></font></p>
        </td>
        <td width="7" height="10" align="middle">
        <p align="center"><b><font face="Arial" size="2">=</font></b></p>
        </td>
        <td width="52"><font face="Arial" size="2"><input readonly id="txtpamt" name="txtpamt" size="9" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" value="0.00"></font></td>
        <%end if%>
      </tr>
	  <%next %>
	
    </table>

  </div>

  <%else%>
  <p><font size="2" face="verdana" color="blue"><b><%=st(0,0)%></b></font></p>
    
  <% end if%>
  <%'end if%>

  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" name="hcnt" value="<%=cnt%>">

  <%if err.number<>0 then%>

  <br>
  <br>
  <br>
  <br>
  <center><font size="2" face="verdana" color="red"><b>Error No:</b></font> <font size="2" face="verdana" color="blue"><b><%=err.number%> 
  -- <%'=err.description%>
  <p>&nbsp;</b></font></center>
  <%end if%>
  <%END IF%>
  </p>
</form>

</body>

</html>
<%Response.End()%>