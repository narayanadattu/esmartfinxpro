<%@ Page Language="vb" CodeBehind="batchNoGenrem.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.batchNoGenrem" %>
<%on error resume next
Dim ArrTrans(0,4),actualAmt
Dim strvalues,strvalues1,strvalues2,strvalue,objNoGen,strvaluesabb1,strvaluesabb2
dim ObjIns,strinsrt,strtranno,strbatchno,strfldnms,paymode,i,strWhrCond,strabbbrcode
dim strabbbatchno,strabbtranno
set objNoGen=Server.CreateObject("GeneralTranQueries.TransactionQueries")
dim vUserid,vMachineId,vAppdate
    vUserid=session("userid")
    vMachineId=session("machineid")
    vAppdate=session("applicationdate")
paymode=Request("paymode")
strabbbrcode=Request("abbbrcode")
Response.Write Request("abbbrcode")
'Response.Write"ok"
 dim contra
     contra=Request.QueryString("Contran")
select case paymode
'--------------------------------------------------------------------------------------------
CASE "CH" ''''CASH MODE

strvalue=Split(Request.QueryString("strIn"),"~")

    strmodule=""
    strmode=""
    strmodule=strvalue(2)
   ' Response.Write strmodule
    strmode=2   'strvalue(7)
 if len(strabbbrcode)>0 then
 'redim ArrTrans(1,4)
		     if  Request.QueryString("flag")="" then
			        	  strbatchno=objNoGen.getbatchno(strabbbrcode)
				     Redim strtranno(2)
				       for i=0 to 1	
				         strtranno(i)=objNoGen.gettranno(strabbbrcode)		
				        next
			         else
				        strbatchno=Trim(Request.QueryString("flag"))
				       Redim strtranno(2)
				    for i=0 to 1	
					    strtranno(i)=objNoGen.gettranno(strabbbrcode)		
				  next
			   End if
			   
			   if  Request.QueryString("flag")="" then
			           strabbbatchno=objNoGen.getbatchno(strvalue(0))
				       Redim strabbtranno(2)
				       for i=0 to 1	
				         strabbtranno(i)=objNoGen.gettranno(strvalue(0))	
				        next
			         else
				        strabbbatchno=Trim(Request.QueryString("flag"))
				       Redim strabbtranno(2)
				    for i=0 to 1	
					    strabbtranno(i)=objNoGen.gettranno(strvalue(0))		
				  next
			   End if
			   
			   
			   
			  
			'''================
			set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")	
			
			strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
				"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
				"MACHINEID,SYSTEMDATE,APPLICATIONDATE,COL48"  
				
		   ' actualAmt="-"&strvalue(6)
		   ' actbal=strvalue(6)
			
'			Response.Write Request("paytype")
			
		    if Request("paytype")="Rcpt" then
				actualAmt="-"&strvalue(6)
				actbal=strvalue(6)	
				strCshMode="1"
			    strGlMode="2"
			elseif Request("paytype")="pay" then
				actualAmt="-"&strvalue(6)
				strCshMode="2"
			    strGlMode="1"
			end if

		   strvalues="'"&strabbbrcode&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
					actbal&"','"& strGlMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
					strbatchno&"','"&strtranno(0)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"		
           
		   'Response.Write ArrTrans(0,3)					             
					                                                                  '"&strvalue(4)&"to_date(sysdate,'dd-mon-yyyy')
		   strvalues1="'"&strabbbrcode&"','"&strvalue(1)&"','ABB','"&strvalue(11)&"','1','"&strvalue(5)&"','"& _
					actualAmt&"','" & strCshMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
					strbatchno&"','"&strtranno(1)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"					
		  
		  
		  strvaluesabb1="'"&strvalue(0)&"','"&strvalue(1)&"','ABB','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
					actbal&"','"& strGlMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
					strabbbatchno&"','"&strabbtranno(0)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"		
					                                                                  '"&strvalue(4)&"to_date(sysdate,'dd-mon-yyyy')
		   strvaluesabb2="'"&strvalue(0)&"','"&strvalue(1)&"','CASH','"&strvalue(11)&"','1','"&strvalue(5)&"','"& _
					actualAmt&"','" & strCshMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
					strabbbatchno&"','"&strabbtranno(1)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"					
		  
		  
		   strvar=strvalues &"|" & strvalues1 &"|" & strvaluesabb1 &"|" & strvaluesabb2
		   ArrTrans(0,0)="I"     
		   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
		   ArrTrans(0,2)=strfldnms 'passing columns 
		   ArrTrans(0,3)=strvar  'passing values
		   ArrTrans(0,4)=""'passing where condition
		   
		   
		   
		   
		  
		  
		  
		  ' strvar=strvaluesabb1 &"|" & strvaluesabb2
		  ' ArrTrans(1,0)="I"     
		  ' ArrTrans(1,1)="GENTEMPTRANSLOG" 'passing the table name
		  ' ArrTrans(1,2)=strfldnms 'passing columns 
		  ' ArrTrans(1,3)=strvar  'passing values
		  ' ArrTrans(1,4)=""'passing where condition
		  ' Response.Write ArrTrans(1,3)
		   
		   strinsrt=ObjIns.DataTransactions(ArrTrans)
'		     Response.Write strinsrt
		  
	'	End if


		set ObjIns=nothing

 elseif strmodule="REM"and strmode="2" then '---------remitttence csah transaction+comm tran 

     	 if  Request.QueryString("flag")="" then
	        	  strbatchno=objNoGen.getbatchno
		     Redim strtranno(3)
		       for i=0 to 2
		         strtranno(i)=objNoGen.gettranno		
		        next
	       else
		        strbatchno=Trim(Request.QueryString("flag"))
		       Redim strtranno(3)
		      for i=0 to 2	
			    strtranno(i)=objNoGen.gettranno		
		     next
	    End if
	'''================
	set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")	
	
	
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
		"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
		"MACHINEID,SYSTEMDATE,APPLICATIONDATE"  
    actualAmt="-"&strvalue(6)
	actbal=strvalue(15)	
'	Response.Write Request("paytype") 
      if Request("paytype")="Rcpt" then
		actualAmt=strvalue(6)
		strCshMode="1"
	    strGlMode="2"
	  elseif Request("paytype")="pay" then
		actualAmt="-"&strvalue(6)
		strCshMode="2"
	    strGlMode="1"
	  end if


strvalues="'"&strvalue(0)&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			actualAmt&"','"& strGlMode& "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(0)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy')"		

strvalues1="'"&strvalue(0)&"','"&strvalue(1)&"','"& strvalue(12)&"','"& strvalue(13)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
	        strvalue(14)&"','"&strGlMode&"','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(1)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy')"
			                                                                  '"&strvalue(4)&"to_date(sysdate,'dd-mon-yyyy')
 strvalues2="'"&strvalue(0)&"','"&strvalue(1)&"','CASH','"&strvalue(11)&"','1','"&strvalue(5)&"','"& _
			actbal& "','" & strCshMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(2)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy')"					
			                                        'modid                   'comgl      'modeoftran
  			
   strvar=strvalues &"|" & strvalues1 &"|" & strvalues2
   
   
  
   ArrTrans(0,0)="I"     
   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
   ArrTrans(0,2)=strfldnms 'passing columns 
   ArrTrans(0,3)=strvar  'passing values
   ArrTrans(0,4)=""'passing where condition
   
  strinsrt=ObjIns.DataTransactions(ArrTrans)
  
else  '--------------------regular  cash transaction------------
   
       if  Request.QueryString("flag")="" then
	        	  strbatchno=objNoGen.getbatchno(strvalue(0))
		     Redim strtranno(2)
		       for i=0 to 1	
		         strtranno(i)=objNoGen.gettranno(strvalue(0))		
		        next
	         else
		        strbatchno=Trim(Request.QueryString("flag"))
		       Redim strtranno(2)
		    for i=0 to 1	
			    strtranno(i)=objNoGen.gettranno(strvalue(0))		
		  next
	   End if
	  
	'''================
	set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")	
	
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
		"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
		"MACHINEID,SYSTEMDATE,APPLICATIONDATE,COL48"  
		
   ' actualAmt="-"&strvalue(6)
   ' actbal=strvalue(6)
	
'	Response.Write Request("paytype")
	
    if Request("paytype")="Rcpt" then
		actualAmt="-"&strvalue(6)
		actbal=strvalue(6)	
		strCshMode="1"
	    strGlMode="2"
	elseif Request("paytype")="pay" then
		actualAmt="-"&strvalue(6)
		strCshMode="2"
	    strGlMode="1"
	end if

   strvalues="'"&strvalue(0)&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			actbal&"','"& strGlMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(0)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"		
			                                                                  '"&strvalue(4)&"to_date(sysdate,'dd-mon-yyyy')
   strvalues1="'"&strvalue(0)&"','"&strvalue(1)&"','CASH','"&strvalue(11)&"','1','"&strvalue(5)&"','"& _
			actualAmt&"','" & strCshMode & "','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno(1)&"','" & vUserid &"','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppdate&"','dd-mon-yyyy'),'" & contra & "'"					
  
  
   strvar=strvalues &"|" & strvalues1
   ArrTrans(0,0)="I"     
   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
   ArrTrans(0,2)=strfldnms 'passing columns 
   ArrTrans(0,3)=strvar  'passing values
   ArrTrans(0,4)=""'passing where condition
   
   strinsrt=ObjIns.DataTransactions(ArrTrans)
     
  
End if


set ObjIns=nothing

'--------------------------------------------------------------------------------------------
 CASE "TRINS"   '''''TRANSFER MODE(Insertion)
        
		if  Request.QueryString("flag")="" then
		  strbatchno=objNoGen.getbatchno
		  strtranno=objNoGen.gettranno		
		else
			 strbatchno=Trim(Request.QueryString("flag"))
			 strtranno=objNoGen.gettranno		
		End if

	''================
	set ObjIns=server.CreateObject("GeneralTransactions.DBTransactions")
	strvalue=Split(Request.QueryString("strIn"),"~")
	strfldnms="BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO,CUSTOMERID,AMOUNT,MODEOFTRAN,"&_
			"ENTEREDTIMEBAL,TRANSTATUS,REMARKS,BATCHNO,TRANNO,CASHIERID,USERID,"&_
			"MACHINEID,SYSTEMDATE,APPLICATIONDATE"  

	strvalues="'"&strvalue(0)&"','"&strvalue(1)&"','"&strvalue(2)&"','"&strvalue(3)&"','"&strvalue(4)&"','"&strvalue(5)&"','"& _
			strvalue(6)&"','"&strvalue(7)&"','"&strvalue(8)&"','"&strvalue(9)&"','"&strvalue(10)&"','"&_
			strbatchno&"','"&strtranno&"','','" & vUserid &"','" & vMachineId &"',to_date(sysdate,'dd-mon-yyyy'),to_date('"&vAppDate&"','dd-mon-yyyy')"		
     
   ArrTrans(0,0)="I"     
   ArrTrans(0,1)="GENTEMPTRANSLOG" 'passing the table name
   ArrTrans(0,2)=strfldnms  'passing columns
   ArrTrans(0,3)=strvalues  'passing values
   ArrTrans(0,4)="" 'passing where condition
   
	strinsrt=ObjIns.DataTransactions(ArrTrans)  ''INSERTING THROUH OBJECT
	'Response.Write window.document.frm1.batGenNo3.value
 
End select

'--------------------------------------------------------------------------------------------
	%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<script language="javascript">
	function sendBatchNo()
	{
	 
	  var str1=window.document.frm1.batGenNo1.value;
	  var str2=window.document.frm1.batGenNo2.value;
	  var str3=""
	  str3=window.document.frm1.batGenNo3.value;
	  
	  var vRslt=window.document.frm1.trnRslt.value;
	  var strabbbrcode1=""
	  var str='<%=Request("paytype")%>'
	  strabbbrcode1='<%=Request("abbbrcode")%>'
	  
	  {
	  if(strabbbrcode1!="")
	  {
		var strabb1=window.document.frm1.batabbGenNo1.value;
		var strabb2=window.document.frm1.batabbGenNo2.value;
	  }
	  }
	  
	 {
	  if(strabbbrcode1!="")
	        {
	      window.attachEvent(window.opener.AbbReceiptFlexPopulate(str1,str2,vRslt,strabb1,strabb2));
			 }
	  else if((str=='Rcpt')&& (str3!=""))
	  {
	     window.attachEvent(window.opener.RemReceiptFlexPopulate(str1,str2,str3,vRslt));
	          }
	  else if((str=='Rcpt')&&(str3==""))
	  {  
	     window.attachEvent(window.opener.ReceiptFlexPopulate(str1,str2,vRslt));
	         }
	  else if(str=='Pay'){
		 window.attachEvent(window.opener.FlexPopulate(str1,str2,vRslt));
	  }
	  else if(str=='transfer'){
		 window.attachEvent(window.opener.FlexPopulate(str1,str2,vRslt));
	  }
	  else{}
	 } 
	  window.close();//  
	  
	}
//onload="sendBatchNo()"	
</script>

<body onload="sendBatchNo()">

<form name="frm1">
  <%if paymode="CH" and  strmodule="REM" and strmode="2" then%>
  <input name="batGenNo1" value="<%=strbatchno%>~<%=strtranno(0)%>~" size="20"> <input name="batGenNo2" value="<%=strbatchno%>~<%=strtranno(1)%>~" size="20">
  <input name="batGenNo3" value="<%=strbatchno%>~<%=strtranno(2)%>~" size="20"> <input name="trnRslt" value="<%=strinsrt%>" size="20">
  
  <%elseif paymode="CH"then%>
  <input name="batGenNo1" value="<%=strbatchno%>~<%=strtranno(0)%>~" size="20"> <input name="batGenNo2" value="<%=strbatchno%>~<%=strtranno(1)%>~" size="20">
  <input name="batGenNo3"  size="20"> <input name="trnRslt" value="<%=strinsrt%>" size="20">
  
  <%elseif paymode="TRINS" then%>
  <input name="batGenNo1" value="<%=strbatchno%>~<%=strtranno%>~<%=formatdate%>~" size="20">
  <input name="batGenNo2" value size="20"> <input name="trnRslt" value="<%=strinsrt%>" size="20">
  <%end if%>
  
  <%if len(strabbbrcode)>0 then%>
  <input name="batabbGenNo1" value="<%=strabbbatchno%>~<%=strabbtranno(0)%>~<%=formatdate%>~" size="20">
  <input name="batabbGenNo2" value="<%=strabbbatchno%>~<%=strabbtranno(1)%>" size="20"> 
  <%end if%>
  <p>&nbsp;</p>
</form>

</body>

</html>
