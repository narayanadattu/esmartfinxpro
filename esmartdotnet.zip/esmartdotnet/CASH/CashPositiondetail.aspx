<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="CashPositiondetail.aspx.vb" Inherits="eSmartDotNet.CashPositiondetail"%>

<%
dim strSql, strNftsYn as string
strNftsYn="N"
dim rsNFTS, objNFTS
rsNFTS=server.CreateObject("adodb.recordset")
objNFTS =server.CreateObject("ReportPurposeOnly.Reportonly")
strSql="SELECT NFTSCONVYN FROM GENBANKPARM"
rsNFTS=objNFTS.SingleSelectStat(strSql)
if objNFTS.ConnError<>"Connected" then
	if not rsNFTS.bof and not rsNFTS.eof then
		strNftsYn=rsNFTS(0).value
	end if
end if
%>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styletag.css">
			<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
			<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
			<meta name="ProgId" content="FrontPage.Editor.Document">
			<title>Cash Position Details</title>
			<SCRIPT LANGUAGE=javascript>
			//function for sending parameters to reportgrid template page
function ReportParam(strrep)
{

var smoddesc = ""
var StrCol=""
var StrRow=""
var StrHead=""
var StrCols=""
var StrColRow=""
var strheaddate = ""
var strheadamt=""

StrHead= " Cash Position Details Report " + ",60,80"
StrCol=""
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,0)+",18,L"+"~"
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,1)+",7,L"+"~"
	if ('<%=strNftsYn%>' == "Y")
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,2)+",17,L"+"~"
	else
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,2)+",7,L"+"~"
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,3)+",30,L"+"~"
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,4)+",15,R"+"~"
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,5)+",7,C"+"~"
	StrCol=StrCol+window.document.frmtran.Mfgaccdtls.TextMatrix(0,6)+",7,C"+"|"
	


for(icnt=1;icnt<=window.document.frmtran.Mfgaccdtls.Rows-1;icnt++)
	{
		StrCols=""
			for(jcnt=0;jcnt<=window.document.frmtran.Mfgaccdtls.Cols-1;jcnt++)
			{
				if (strrep == "report")
				{				
				StrCols=StrCols+window.document.frmtran.Mfgaccdtls.TextMatrix(icnt,jcnt)+"~"
				}
				else if (strrep == "xlreport")
				{
				if ((jcnt ==0) || (('<%=strNftsYn%>' == "Y" ) && jcnt ==2))
				{
				StrCols=StrCols+ "'" + window.document.frmtran.Mfgaccdtls.TextMatrix(icnt,jcnt)+"~"
				}
				else
				{
				StrCols=StrCols+window.document.frmtran.Mfgaccdtls.TextMatrix(icnt,jcnt)+"~"
				}
				}
			}
			StrCols=StrCols.substr(0,StrCols.length-1)
			StrColRow=StrColRow+StrCols+"|"
}

	StrCol=StrCol+StrColRow
	
	StrArr=StrHead+"|"+StrCol

	window.document.frmtran.hreport.value=StrArr
	///posting to server side page

	if (strrep == "report")
	{
window.document.frmtran.action="http://" + 
	"<%=session("moduledir")%>" +"/reportgridtemplatectr.aspx?strng="+"/CASH/frmCashPosition"
	}
	else if (strrep == "xlreport")
	{
	window.document.frmtran.action="http://" + 
	"<%=session("moduledir")%>" +"/ReportGridTemplateXL.aspx?strng="+"/CASH/frmCashPosition"
	}
		
	window.document.frmtran.method="post"
	window.document.frmtran.submit();
}

			</SCRIPT>
	</head>
	<body topmargin="0" leftmargin="0">
		<form name="frmtran">
			<div align="center">
				<center>
					<table width="60%" cellspacing="0" cellpadding="0" class="tablebordermain">					 
						<tr>
							<td width="100%">
								<table border="0" width="60%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="100%">
											<object id=Mfgaccdtls style="LEFT: 0px; WIDTH: 700px; TOP: 0px; HEIGHT: 130px" height=130 width=700 classid=clsid:6262D3A0-531B-11CF-91F6-C2863C385E30 name=Mfgaccdtls >
	<PARAM NAME="_ExtentX" VALUE="12594">
	<PARAM NAME="_ExtentY" VALUE="3149">
	<PARAM NAME="_Version" VALUE="393216">
	<PARAM NAME="Rows" VALUE="2">
	<PARAM NAME="Cols" VALUE="5">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="HighLight" VALUE="1">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="AllowUserResizing" VALUE="1">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="FormatString" VALUE="">
	<PARAM NAME="OLEDropMode" VALUE="0">
	</OBJECT>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</center>
			</div>
<%
dim objfetch

objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 

if len(trim(Request.QueryString("tds")))>0 then

	strtds=split(Request.QueryString("tds"),"~")
	sbrcode = strtds(0)
	scrcode = strtds(1)
	sdate = strtds(2)
	
	objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 
    resDtls=server.CreateObject("adodb.recordset")
   
	
'' deposit
'if smodid = "DEP" then

sqlstr= "SELECT a.branchcode,a.CASHIERID,a.AMOUNTALLOTED,NVL(r.amount,0) receipts,NVL(p.amount,0) payments FROM (SELECT CASHIERID,SUM(amount) amount FROM CASHRECEIPTSTRN WHERE applicationdate='" & sdate & "' and branchcode='" & sbrcode & "' GROUP BY CASHIERID) r, (SELECT CASHIERID,SUM(amount) amount FROM CASHPAYMENTSTRN WHERE applicationdate='" & sdate & "' and branchcode='" & sbrcode & "' GROUP BY CASHIERID) p, (SELECT branchcode,CASHIERID,AMOUNTALLOTED FROM CASHALLOTMENTSTRN WHERE applicationdate='" & sdate & "' and branchcode='" & sbrcode & "') a WHERE A.CASHIERID=R.CASHIERID(+) AND A.CASHIERID=P.CASHIERID(+) ORDER BY a.cashierid"

resDtls=objfetch.SingleSelectStat(sqlstr)



dim strDenom, rsDnom, objDnom
		
		rsDnom = server.CreateObject("adodb.recordset")
		objDnom	= server.CreateObject("ReportPurposeOnly.Reportonly")
		
		strDenom = "  SELECT DENOMINATIONTYPE ||' -'||Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='INR' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC "
			
		rsDnom = objDnom.SingleSelectStat(strDenom)
		
		if objDnom.ConnError="Connected" then
			if not rsDnom.bof and not rsDnom.eof then
				
				denom = ""
				DenFld = ""
				
			
				do until rsDnom.eof
					''NVL(D1,0) D1
					denom = denom & " NVL(" & rsDnom(1).value & ",0)" & rsDnom(1).value & ","
					
					DenFld = DenFld & "|>                 " & rsDnom(0).value 
				
				rsDnom.movenext()
				loop
	
				denom = mid(denom,1,denom.length-1)
				'DenFld = mid(DenFld,1,DenFld.length-1)
			
			end if
			rsDnom = nothing
		end if
		
		dim stDval, rsDval, objDval, sDval
		
		rsDval = server.CreateObject("adodb.recordset")
		objDval	= server.CreateObject("ReportPurposeOnly.Reportonly")
		
		stDval = "SELECT " & denom & " FROM  CASHCASHIERPOSMST WHERE UPPER(currencycode)='INR' and branchcode='" & sbrcode & "' ORDER BY CASHIERID"
		
		rsDval = objDval.SingleSelectStat(stDval)
		
		if objDval.ConnError="Connected" then
			if not rsDval.bof and not rsDval.eof then
				do until rsDval.EOF
					
					for i = 0 to rsDval.fields.count - 1 
						sDval = sDval & rsDval(i).value & "~"
					next i	
						
					sDval = mid(sDval,1,sDval.length-1)
					
						sDval = sDval & "|"
					rsDval.movenext()
				loop
				sDval = mid(sDval,1,sDval.length-1)
				
			end if
			rsDval = nothing
		end if
		
		
		
if not resDtls.eof and not resDtls.bof then
			
			dim strDval ,sVald
			
			
			strDval = sDval.split("|")
			
				des="<Branch          |<Casher ID         |>Cash Allot                  |>Receipt                  |>Payment             |>Cash on Hand                  "
				
				des = des + DenFld
				
				Response.Write("<script language=vbscript>"& chr(13))
				Response.Write("sub show()" & chr(13))
				'	Response.Write("alert(window.document.frmtran.Mfgaccdtls.rows)"  & chr(13))
				Response.Write("window.document.frmtran.Mfgaccdtls.formatstring="& chr(34)& des & chr(34)& chr(13))
				''Response.Write("window.document.frmtran.Mfgaccdtls.cols=6" & chr(13))
				resDtls.movefirst()
				
				for i=0 to resDtls.RecordCount - 1
				
				Response.Write("window.document.frmtran.Mfgaccdtls.rows=window.document.frmtran.Mfgaccdtls.rows + 1" & chr(13))
				for j=0 to resDtls.Fields.Count - 1
					Response.Write("window.document.frmtran.Mfgaccdtls.textmatrix("& i+1 &","& j &")="& chr(34)& resDtls(j).value & chr(34)& chr(13))
					
					if j>1
						Response.Write("window.document.frmtran.Mfgaccdtls.textmatrix("& i+1 &","& j &")="& chr(34)& cDbl(resDtls(j).value).ToString("n",System.Globalization.CultureInfo.CreateSpecificCulture("hi-IN")) & chr(34)& chr(13))
					
					end if
					
					
					
					Response.Write("window.document.frmtran.Mfgaccdtls.textmatrix("& i+1 &","& 5 &")="& chr(34)&  cDbl(resDtls(2).value+resDtls(3).value-resDtls(4).value).ToString("n",System.Globalization.CultureInfo.CreateSpecificCulture("hi-IN")) & chr(34)& chr(13))
				next
				
				sVald = strDval(i).split("~") 
				
				for k = 0 to ubound(sVald)
					Response.Write("window.document.frmtran.Mfgaccdtls.textmatrix("& i+1 &","& 6+k &")="& chr(34)& cDbl(sVald(k)) & chr(34)& chr(13))
				next 
					
				
				resDtls.movenext()
				next
				Response.Write("window.document.frmtran.Mfgaccdtls.rows=window.document.frmtran.Mfgaccdtls.rows - 1" & chr(13))
				Response.Write("end sub" & chr(13))
				Response.Write("call show()" & chr(13))
				Response.Write("</script>" & chr(13))
			else
			'str="No"
			kstr="No"
				des="^                                           Cash Is Not Alloted For This Branch"
				Response.Write("<script language=vbscript>" & chr(13))
				Response.Write("sub show()" & chr(13))
				Response.Write("window.document.frmtran.Mfgaccdtls.formatstring="& chr(34)& des & chr(34)& chr(13))
				Response.Write("window.document.frmtran.Mfgaccdtls.rows=1"& chr(13))
				Response.Write("window.document.frmtran.Mfgaccdtls.cols=1"& chr(13))
				Response.Write("end sub" & chr(13))
				Response.Write("call show()" & chr(13))
				Response.Write("</script>" & chr(13))

end if '' resDtls
if resDtls.state = 1 then 
resDtls.close
resDtls = nothing
end if
'end if'' dep
end if '' len


objfetch=nothing

%>
			 <input type="hidden" name="hpr" value="<%=session("precision")%>">
			<input type="hidden" name="hidtrans"><center><input type="button" value="   OK   " name="butmd" onclick="window.close()" class="button" ></center><!--<input type="button" value="Report" name="cmdreport" onClick="ReportParam('report')" class="button"><input type="button" value="XL Report" name="cmdXLreport" onclick="ReportParam('xlreport')" class="button"></center>
			<center>
			 <input name="txtbranchcode" size="10" readonly value="<%=session("branchcode")%>" maxlength="10" readonly>    <input name="txtcurrencycode" style="TEXT-ALIGN: left;text-transform=uppercase" value="<%=session("currencycode")%>" size="10" maxlength="10" readonly>
                      </center>--->
			<input type ="hidden" name = "hreport"> 
		</form>
	</body>
</html>