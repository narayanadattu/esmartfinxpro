<%@ Page CodeBehind="cashcountermgt.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashcountermgt" %>
<html>

<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashCountermgt.aspx
''''' ListForm:List
''''' iFramepage:cashCountermgtQury.aspx
''''' Trnsactionpages:CashCounterInsert.aspx
''''------------------------------------------------------------------------------------------
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Counter</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<!--
///for sending parameters to list form for branchCode
var mode
mode=""
limitdet=""
function branch()
{  
	st="Bruser"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	window.document.frmcash.txtCurrencyCode.value=""
	window.document.frmcash.txtCurrencyDesc.value=""
	splitString("window.document.frmcash","txtcid,txtcdesc,txtcounterno,txtcountername,"+
				"txtctypeid,txtCName,txtmlimit,txtlimitpay,txtreceipt")
}	
function Bruser(kstr)
{	
	assign(kstr,window.document.frmcash.txtBranchDesc,window.document.frmcash.txtBranchCode)
}	
///for sending parameters to list form for CurrencyCode
function currency()
{	
if(window.document.frmcash.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
	st="Curr"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
			
	splitString("window.document.frmcash","txtcid,txtcdesc,txtcounterno,txtcountername,"+
				"txtctypeid,txtCName,txtmlimit,txtlimitpay,txtreceipt")
}
//displaying cashiercode,name which are returned by list page
function  Currid(kstr)
{var p,prn,j,k
  var k=kstr.split("-----")
  window.document.frmcash.txtCurrencyDesc.value =k[0]
  window.document.frmcash.txtCurrencyCode.value =k[1]
  var prn=eval(k[2].length)-1
  window.document.frmcash.hpr.value=prn
  p=""
  for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	
	
 }	
 //sending parameters to list page to get cashiertypes
 function Cashiertypeid()
 {
	if(mode=="ADD")
	{
	sBr=window.document.frmcash.txtBranchCode.value
	sCurr=window.document.frmcash.txtCurrencyCode.value
	
	window.document.frmcash.txttellerlimitpay.value=""
	window.document.frmcash.txttellerreceipt.value=""
	window.document.frmcash.txtreceipt.value=""
	window.document.frmcash.txtlimitpay.value=""
	
	
	st="CashierTypeId*"+sBr+"*"+sCurr
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
			}
 }
 //displaying cashiertypeid,description which are returned by list 
 ///page while add new record 
function  CashierTypeCode(kstr)
{
var Strmain=new String()
Strmain=kstr.split("-----")

window.document.frmcash.txtctypeid.value=Strmain[0]
window.document.frmcash.txtCName.value=Strmain[1]
///function for send parameters to ifrmae page check the selected cashier type
///(payments,receipts,tellerreceipts,tellerpayments)

var sBr=window.document.frmcash.txtBranchCode.value.toUpperCase()
var cur=window.document.frmcash.txtCurrencyCode.value.toUpperCase()
var sCash=window.document.frmcash.txtctypeid.value.toUpperCase()

	st=sBr+"*"+cur+"*"+sCash+"~checkCashier"
	
	window.document.all["iBatch"].src="cashcountermgtquery.aspx"
		
	/*	window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();*/
}
 ///for sending parameters to list form for CounterNo
function CounterNo()
{
	
	
	sBr=window.document.frmcash.txtBranchCode.value
	sCash=window.document.frmcash.txtcid.value
	sCurr=window.document.frmcash.txtCurrencyCode.value
	if(mode=="ADD")
	{	
	splitString("window.document.frmcash","txtcid,txtmlimit,txtcdesc,"+
			"txtlimitpay,txtreceipt")
	st="CounterCode*"+sBr+"*"+sCash+"*"+sCurr
	
	}
	else
	{
		//st=sBr+"*"+sCash+"*"+sCur+"~Cashier"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
	  
		st="QryCounterNo*"+sBr+"*"+sCash+"*"+sCurr
	}
	
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}

//displaying CounterCode which are returned by list page while add new record 
function  CounterId(kstr)
{
//alert ("dd")
var Strmain=new String()
Strmain=kstr.split("-----")
window.document.frmcash.txtcounterno.value=Strmain[1]
window.document.frmcash.txtcountername.value=Strmain[0]
Querycounter()
 }
 //displayingCounterCode which are returned by list page while querying record 
function CounterQueryId(kstr)
{
var Strmain=new String()
Strmain=kstr.split("-----")

window.document.frmcash.txtcounterno.value=Strmain[1]
window.document.frmcash.txtcountername.value=Strmain[0]
Querycounter()
}	
///for sending parameters to list form for cashiercode 
function Cashiercode()
{	
		//splitString("window.document.frmcash",""+
				//"txtctypeid,txtCName,txtmlimit,txtlimitpay,txtreceipt")
		if(window.document.frmcash.txtBranchCode.value=="")
		{
			alert("Select BranchCode")
			return;
		}
		if(mode=="ADD")
		{	
		kstr="Cashiercou"
		}
		else 
		{
		kstr="counterCashier"
		}
		brcode=window.document.frmcash.txtBranchCode.value
		crcode=window.document.frmcash.txtCurrencyCode.value
		brcode=brcode.toUpperCase()
		crcode=crcode.toUpperCase()
		st=kstr+"*"+brcode+"*"+crcode
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:210px;DialogTop:210px")
		
}
///function for dispalying the cashierid,name returned from list page while adding
///new record
function Cashiercd(kstr)
{	
	
	assign(kstr,window.document.frmcash.txtcdesc,window.document.frmcash.txtcid)
	
	var prn=window.document.frmcash.hpr.value
	var p=""
	if(window.document.frmcash.hpr.value!="")
	{
	for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	window.document.frmcash.txtctypeid.value =""
	//window.document.frmcash.txtctypedesc.value =""
	window.document.frmcash.txtlimitpay.value=pres
	window.document.frmcash.txtreceipt.value=pres
	}

	CashierType()
}
///function for dispalying the cashierid,name returned from list page while querying
///new record
function CashCounterId(kstr)
{
var StrFld=new String()
StrFld=kstr.split("-----")
window.document.frmcash.txtcid.value=StrFld[1]
window.document.frmcash.txtcdesc.value=StrFld[0]
window.document.frmcash.txtlimitpay.readOnly=true
window.document.frmcash.txtreceipt.readOnly=true
window.document.frmcash.txttellerlimitpay.readOnly=true
window.document.frmcash.txttellerreceipt.readOnly=true
window.document.frmcash.txtmlimit.readOnly=true
CashierType()
}
//function for displaying the type of cashier for selected user
function CashierType()
{
	sBr=window.document.frmcash.txtBranchCode.value
	sCur=window.document.frmcash.txtCurrencyCode.value.toUpperCase()
	sCash=window.document.frmcash.txtcid.value
	sBr=sBr.toUpperCase()
	sCash=sCash.toUpperCase()
	if(window.document.frmcash.optTran[0].checked==true)
	{
	st=sBr+"*"+sCash+"*"+sCur+"~typeCashier"
	}
	else
	{
	st=sBr+"*"+sCash+"*"+sCur+"~Cashier"
	  
	   //window.document.all["iBatch"].src="cashcountermgtquery.aspx"
	    window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
		
	}
	
		
	
}
//finction for displaying the description fro selcted code	
function CashierDisp(strTxt)
{
//for brancgdescription
if(strTxt=="txtBranchCode")
{ 
	var sTableName,sCols,sCond,sUserId
	sBr=window.document.frmcash.txtBranchCode.value
	sBr=sBr.toUpperCase()
	
	//code commented by Radhika on 18-sep-2007
	//reason: System should accept implemented branch codes only
	//st="GENBANKBRANCHMST~BRANCHNAME~branchcode='"+sBr+"'~"+strTxt+"~DescDisplay"
	
	// new code is
	sUserId='<%=session("userid")%>'
	sTableName="GENBANKBRANCHMST Branch, GENUSERMST GenUser, GENBRANCHPMT BrnchPmt"
	sCols="Branch.Narration Narration"
	sCond=" ((UPPER(trim(GenUser.userid))='" + sUserId + "'" +
		" AND UPPER(trim(Genuser.ABBUSERYN))='Y' ) " +
		" OR Branch.branchcode =(SELECT branchcode FROM GENUSERMST " +
	    " WHERE UPPER(trim(userid))='" + sUserId + "')) " +
		" AND Branch.Branchcode=BrnchPmt.Branchcode " +
		" AND Branch.Branchcode='" + sBr + "' ORDER BY Branch.BranchCode"
	
	//alert(sCond)
	st=sTableName+"~"+sCols+"~"+sCond +"~"+strTxt+"~DescDisplay"

}
if(strTxt=="txtCurrencyCode")
{
if(window.document.frmcash.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
sCur=window.document.frmcash.txtCurrencyCode.value
sCur=sCur.toUpperCase()
st="GENCURRENCYTYPEMST~narration,PRECISION~upper(trim(currencycode))='"+sCur+"'"+
	"~"+strTxt+"~DescDisplay"
}
//for cashier description 
if(strTxt=="txtcid")
{
// value is not there in text box return the function
if(window.document.frmcash.txtcid.value=="")
{
	return
}
///for counterno
if(window.document.frmcash.txtcounterno.value=="")
{
	alert("Select Counter No")
	return;
}
if(window.document.frmcash.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
sBr=window.document.frmcash.txtBranchCode.value
sCur=window.document.frmcash.txtCurrencyCode.value
sBr=sBr.toUpperCase()
sCur=sCur.toUpperCase()
sCashId=window.document.frmcash.txtcid.value
sCashId=sCashId.toUpperCase()
sBr=sBr.toUpperCase()
sCur=sCur.toUpperCase()
/// for inserting fetch values from genusermst tab;le
if(mode=="ADD")
{
st="GENUSERMST"+"~"+"NAME"+"~"+"USERID='"+sCashId+"' and USERID NOT IN " +
	"(SELECT nvl(CASHIERID,'n') FROM CASHCOUNTERMST where " +
	"branchcode='" + sBr + "' and currencycode='" + sCur + "')"+
	"~"+strTxt+"~"+"DescDisplay"
	
}
///for querying fetch cashierids from cashcountermst table
else if((mode=="MODIFY")||(mode=="DELETE")||(mode=="VIEW"))
{
///for adding fetch counterno from cashcountermst

st="GENUSERMST g,CASHCOUNTERMST c"+"~"+"g.Name"+
	"~"+"c.BRANCHCODE='" + sBr + "' and "+
	"c.currencycode='"+sCur+"' and g.userid=c.cashierid and " +
	"c.cashierid='"+sCashId+"'"+
	"~"+strTxt+"~"+"DescDisplay"
}

}
if(strTxt=="txtcounterno")
{
/// value is not there in text box return the function
if(window.document.frmcash.txtcounterno.value=="")
{
	return
}

sBr=window.document.frmcash.txtBranchCode.value
sCur=window.document.frmcash.txtCurrencyCode.value.toUpperCase()
sCnt=window.document.frmcash.txtcounterno.value
sCash=window.document.frmcash.txtcid.value
sBr=sBr.toUpperCase()
sCash=sCash.toUpperCase()
//for add new record 
if(mode=="ADD")
{
st="CASHCOUNTERMST"+"~"+"NARRATION"+"~"+"branchcode='" + sBr + "' and " +
				"counterno='"+sCnt+"' and cashierid is null"+"~"+strTxt+"~"+"DescDisplay"
}
///for querying record 
else
{
st="CASHCOUNTERMST"+"~"+"NARRATION"+"~"+"branchcode='" + sBr + "' and " +
		"counterno='"+sCnt+"' and currencycode='"+sCur+"' and "+
		"cashierid='"+sCash+"' OR (counterstatus='C' or counterstatus='')"+
		"~"+strTxt+"~"+"DescDisplay"
}
}
//for cashiertype description

if(strTxt=="txtctypeid")
{

if(window.document.frmcash.optTran[2].checked==true)
{
	return;
}
	sCashType=window.document.frmcash.txtctypeid.value.toUpperCase()
	if(window.document.frmcash.txtcid.value=="")
	{
		alert("Select Cashier Id")
		return;
	}	
	st="CASHCASHIERTYPEMST"+"~"+"NARRATION"+"~"+"branchcode='" + sBr + "' and " +
		" currencycode='"+sCur+"' and "+
		"upper(trim(CASHIERTYPEID))='"+sCashType+"'"+
		"~"+strTxt+"~"+"DescDisplay"
}

		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
}
///sending parameters to iframe page for querying the counter details 
function Querycounter()
{
		Brst=window.document.frmcash.txtBranchCode.value
		Crst=window.document.frmcash.txtCurrencyCode.value
		Cost=window.document.frmcash.txtcounterno.value
		sCash=window.document.frmcash.txtcid.value
		Sim="*"
		sBr=sBr.toUpperCase()
		sCash=sCash.toUpperCase()
		Crst=Crst.toUpperCase()
		Cost=Cost.toUpperCase()
		st=Brst+Sim+Crst+Sim+Cost+Sim+sCash+"~CounterDetails"
		/*window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();*/
		
	
}
///function for max limit value checking
function MaxPayLimit()
{
if(eval(window.document.frmcash.txtmlimit.value)<=0)
{
alert("Enter maxCash Limit");
window.document.frmcash.txtlimitpay.value="";
window.document.frmcash.txtreceipt.value="";
window.document.frmcash.txtmlimit.focus();
return;
}
//checking for payment limits
if(eval(window.document.frmcash.txtmlimit.value)<
eval(window.document.frmcash.txtlimitpay.value))
{
alert("Payments Limit should be lessthan max Cash Limit");
window.document.frmcash.txtlimitpay.value="";
window.document.frmcash.txtlimitpay.focus();
return;
}
}
function MaxtellerPayLimit()
{

if((eval(window.document.frmcash.txtmlimit.value)<=0)||(window.document.frmcash.txtmlimit.value==""))
{
alert("Enter maxCash Limit");
window.document.frmcash.txttellerlimitpay.value="";
window.document.frmcash.txttellerreceipt.value="";
window.document.frmcash.txtmlimit.focus();
return;
}
//checking for payment limits
if(eval(window.document.frmcash.txtmlimit.value)<
eval(window.document.frmcash.txttellerlimitpay.value))
{
alert("Teller Payments Limit should be lessthan max Cash Limit");
window.document.frmcash.txttellerlimitpay.value="";
window.document.frmcash.txttellerlimitpay.focus();
return;
}
}
function MaxRecLimit()
{

if(eval(window.document.frmcash.txtmlimit.value)<=0)
{
	alert("Enter maxCash Limit");
window.document.frmcash.txtlimitpay.value="";
window.document.frmcash.txtreceipt.value="";
window.document.frmcash.txtmlimit.focus();
return;
}
if(eval(window.document.frmcash.txtmlimit.value)<
eval(window.document.frmcash.txtreceipt.value))
{
alert("Reciepts Limit should be lessthan max Cash Limit");
window.document.frmcash.txtreceipt.value=""
window.document.frmcash.txtreceipt.focus();
return;	
}
}
function MaxtellerRecLimit()
{

if(eval(window.document.frmcash.txtmlimit.value)<=0)
{
	alert("Enter maxCash Limit");
window.document.frmcash.txttellerlimitpay.value="";
window.document.frmcash.txttellerreceipt.value="";
window.document.frmcash.txtmlimit.focus();
return;
}
if(eval(window.document.frmcash.txtmlimit.value)<
eval(window.document.frmcash.txttellerreceipt.value))
{
alert("Teller Reciepts Limit should be lessthan max Cash Limit");
window.document.frmcash.txttellerreceipt.value=""
window.document.frmcash.txttellerreceipt.focus();
return;	
}
}
//for nulls checking
function Chknull(kstr){
			
if(kstr.value=="")
{		
	var prn=window.document.frmcash.hpr.value
	if(window.document.frmcash.hpr.value!="")
	{
	var p=""
	for(j=1;j<=prn;j++)
	{
    p=p + "0"
	
	}
	pres= "0." + p
		kstr.value=pres
	}
	else
	{
	pres= "0.00"
	kstr.value=pres
	
	}
		
}		
}		
///function fro clearing controls
function ClearFlds()
{

splitString("window.document.frmcash","txtcid,txtcdesc,txtcounterno,txtcountername,"+
				"txtctypeid,txtCName,txtmlimit,txtlimitpay,txtreceipt," +
				"txttellerlimitpay,txttellerreceipt")

}
//function for enablecontrols
function EnableControls()
{
window.document.frmcash.txtcid.value=""
window.document.frmcash.txtcdesc.disabled=false
window.document.frmcash.txtctypeid.disabled=false
window.document.frmcash.txtCName.disabled=false
window.document.frmcash.txtcounterno.disabled=false
window.document.frmcash.txtcountername.disabled=false
window.document.frmcash.txtlimitpay.disabled=false
window.document.frmcash.txtmlimit.disabled=false
window.document.frmcash.txtreceipt.disabled=false
window.document.frmcash.txttellerlimitpay.disabled=false
window.document.frmcash.txttellerreceipt.disabled=false
window.document.frmcash.butcashtypeid.disabled=false

}
//function for enablecontrols
function DisableControls()
{
window.document.frmcash.txtcid.disabled=true
window.document.frmcash.txtcdesc.disabled=true
window.document.frmcash.txtctypeid.disabled=true
window.document.frmcash.txtCName.disabled=true
window.document.frmcash.txtcounterno.disabled=true
window.document.frmcash.txtcountername.disabled=true
window.document.frmcash.txtlimitpay.disabled=true
window.document.frmcash.txtmlimit.disabled=true
window.document.frmcash.txtreceipt.disabled=true
window.document.frmcash.txttellerlimitpay.disabled=true
window.document.frmcash.txttellerreceipt.disabled=true
window.document.frmcash.butcashtypeid.disabled=true
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--


function Insert(){
if(mode=="VIEW")
{
return;
}
if(window.document.frmcash.txtcid.value!="" &&  
	window.document.frmcash.txtctypeid.value!="")
{
if((window.document.frmcash.txtmlimit.value=="")|
(eval(window.document.frmcash.txtmlimit.value)==0))
{
	alert("Max Cash Limit Should Not Be Null")
	return;
}
	
	/*if(limitdet=="true")
	{
	kstr=confirm("Do You Continue this cashier with existing Limits?...")
	if(kstr==false)
	{
	return;
	}
	}*/
	window.document.frmcash.hidstatus.value=""	
	window.document.frmcash.hidstatus.value=mode	
	window.document.frmcash.action="cashcounterinsert.aspx"
	window.document.frmcash.method ="post"
	window.document.frmcash.submit();
	
	
}
else
{
	alert("Cashierid and Cashiertype Should Not be Null")
}	
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript>
////function for displaying the values which are returned iframe page
function Countermgtdts(kstr)
{

var strtype=new String()
var det=new String()
strtype=kstr.split("~")

det=strtype[0].split("*")
//for description displaying  split the values
var StrArrFld=new String()
StrArrFld=strtype[0].split("|")
///for displaying branchdesc
if(strtype[1]=="txtBranchCode")
	{
	ClearFlds()
		window.document.frmcash.txtCurrencyCode.value=""
		window.document.frmcash.txtCurrencyDesc.value=""
		if(StrArrFld[0]=="No")
		{
			alert("Invalid Branch Code")
			window.document.frmcash.txtBranchCode.value=""
			window.document.frmcash.txtBranchDesc.value=""
			return;
		}
		window.document.frmcash.txtBranchDesc.value=StrArrFld[0]
		
		
	}
	///for displaying Currencydesc
if(strtype[1]=="txtCurrencyCode")
	{
		ClearFlds()
		if(StrArrFld[0]=="No")
		{
			alert("Invalid Currency Code")
			window.document.frmcash.txtCurrencyCode.value=""
			window.document.frmcash.txtCurrencyDesc.value=""
			return;
		}
		window.document.frmcash.txtCurrencyDesc.value=StrArrFld[0]
		
		
	}
///for displaying Cashierdesc
	if(strtype[1]=="txtcid")
	{
	
		//splitString("window.document.frmcash",""+
				//"txtctypeid,txtCName,txtmlimit,txtlimitpay,txtreceipt")
		if(StrArrFld[0]=="No")
		{
		alert("Invalid Cashier ID")
		window.document.frmcash.txtcid.value=""
		window.document.frmcash.txtcdesc.value=""
		return;
		}
		window.document.frmcash.txtcdesc.value=StrArrFld[0]
		CashierType()
		
	}
	
	//for Counternarration 
	if(strtype[1]=="txtcounterno")
	{
		if(StrArrFld[0]=="No")
		{
		alert("Invalid Counter No")
		window.document.frmcash.txtcounterno.value=""
		window.document.frmcash.txtcountername.value=""
		return;
		}
		
		window.document.frmcash.txtcountername.value=StrArrFld[0]
		if(window.document.frmcash.optTran[0].checked==true)
		{
		splitString("window.document.frmcash","txtmlimit,"+
		"txtlimitpay,txtreceipt")
		}
		
		Querycounter()
		
	}
//for cashiertype disbled and enabled the limit amount textboxes accoording to
//the  cashier type which was fetched from the iframe page 
	if(strtype[1]=="checkCashier")
	{
		window.document.frmcash.txtreceipt.disabled=true
		window.document.frmcash.txtlimitpay.disabled=true
		window.document.frmcash.txttellerlimitpay.disabled=true
		window.document.frmcash.txttellerreceipt.disabled=true
		
		if(det[0]=="Y")
		{
			window.document.frmcash.txtreceipt.disabled=false	
		}
		if(det[1]=="Y")
		{
			window.document.frmcash.txtlimitpay.disabled=false	
		}
		if(det[2]=="Y")
		{
			window.document.frmcash.txttellerreceipt.disabled=false	
		}
		if(det[3]=="Y")
		{
			window.document.frmcash.txttellerlimitpay.disabled=false	
		}
		precision(window.document.frmcash.txttellerreceipt,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txttellerlimitpay,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtlimitpay,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtreceipt,window.document.frmcash.hpr.value)
		
		
	}	
///for counetrdetails fro modifying
if(strtype[1]=="CounterDetails")
{
	
		if (det[1]!="")
		{
		window.document.frmcash.txtmlimit.value=det[1]
		window.document.frmcash.txtlimitpay.value =det[2]
		window.document.frmcash.txtreceipt.value =det[3]
		precision(window.document.frmcash.txtmlimit,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtlimitpay,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtreceipt,window.document.frmcash.hpr.value)
		limitdet="true"
		}
		else
		{
		limitdet=""
		}
}		
	///for cashiertype desciption
	if(strtype[1]=="txtctypeid")
	{
		
		window.document.frmcash.txtCName.value=""
		if(StrArrFld[0]=="No")
			{
			alert("Invalid Cashier Type")
			window.document.frmcash.txtctypeid.value=""
			window.document.frmcash.txtCName.value=""
			return;
			}
		window.document.frmcash.txtCName.value=StrArrFld[0]	
		///function for send parameters to ifrmae page check the selected cashier type
///(payments,receipts,tellerreceipts,tellerpayments)
var sBr=window.document.frmcash.txtBranchCode.value.toUpperCase()
var cur=window.document.frmcash.txtCurrencyCode.value.toUpperCase()
var sCash=window.document.frmcash.txtctypeid.value.toUpperCase()
	st=sBr+"*"+sCur+"*"+sCash+"~checkCashier"
		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashcountermgtquery.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
	}
		

/// for displaying the groupcode, name for selected userid,branchcode
else if(strtype[1]=="Cashier")
{
window.document.frmcash.txtctypeid.value=det[0]
window.document.frmcash.txtCName.value=det[1]	
window.document.frmcash.txtmlimit.value=det[2]
		window.document.frmcash.txtlimitpay.value =det[3]
		window.document.frmcash.txtreceipt.value =det[4]
		window.document.frmcash.txtcounterno.value=det[5]
		window.document.frmcash.txtcountername.value=det[6]
		window.document.frmcash.txttellerlimitpay.value=det[7]
		window.document.frmcash.txttellerreceipt.value=det[8]
		
		precision(window.document.frmcash.txttellerreceipt,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txttellerlimitpay,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtmlimit,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtlimitpay,window.document.frmcash.hpr.value)
		precision(window.document.frmcash.txtreceipt,window.document.frmcash.hpr.value)
}
/// for displaying the type of cashier
else if(strtype[1]=="typeCashier")
{
window.document.frmcash.txtctypeid.value=det[1]
window.document.frmcash.txtCName.value=det[2]	

		
}
}
//this function is used to set mode status depending upon the the option buttons clicked
function modeStatus()
{
	if(window.document.frmcash.optTran(0).checked==true)
	{
		mode="ADD"
		
	}
	else if(window.document.frmcash.optTran(1).checked==true)
	{
	
		mode="MODIFY"
	}
	else if(window.document.frmcash.optTran(2).checked==true)
	{

		mode="DELETE"
	}
	else if(window.document.frmcash.optTran(3).checked==true)
	{
		mode="VIEW"
	}
}
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashcountermgt.aspx" 
		
	}
}	
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);modeStatus();DispTranMsg()">

<form name="frmcash">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="18%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>Cash Counter Management</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>
		
  <input type="hidden" name="hpr">

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">
      <div align="center">
        <center>

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">
<%appdate=formatdatetime(session("applicationdate"),1)%>
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor">
                    <td width="100%"><img name="placeholder" border="0" src="file://Comserver/c/ASPTest/dscript42/transparent.gif" width="1" height="22"></td>
                  </tr>
                  <tr class="bgcolor">
                    <td width="100%">

                    

                    </td>
                  </tr>
                </table>

				

                </td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        </center>
      </div>
      <div align="center">
        <center>
        <div align="center">
          <center>

          <table width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td height="15"><font class="textblue">
              <p align="center"></font></td>
            </tr>
          </table>

          </center>
        </div>
        </center>
        <div align="center">

          <table border="0" width="98%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="17%">
              <p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</p></td>
              <td width="31%">&nbsp;<input name="txtBranchCode" style="TEXT-ALIGN: left;text-transform=uppercase" size="9" value="<%=session("branchcode")%>" onblur="Dataarrange(txtBranchCode);CashierDisp(&quot;txtBranchCode&quot;)" maxlength="10" class="txtautofill"><input type="button" class="button" value=" L " name="B3" onclick="branch()"><input name="txtBranchDesc" size="16" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
            
              <td width="20%"><p align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>
              
              <td width="35%" align="left"><input style="TEXT-ALIGN: left;text-transform=uppercase" name="txtCurrencyCode" size="9" maxlength="20" onblur="Dataarrange(txtCurrencyCode);CashierDisp(&quot;txtCurrencyCode&quot;)" value="<%=session("currencycode")%>" class="txtautofill"><input type="button" class="button" value=" L " name="B9" onclick="currency()"><input name="txtCurrencyDesc" size="16" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
              </table>

            </center>
            <div align="center">
              <center>

              <table border="0" width="98%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">

                  <table border="0" width="100%" cellspacing="00" cellpadding="0" class="tableborder1">
                    <tr class="bgcolor1">
                      <td align="middle" width="26%">
                      <p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;ADD&quot;;;ClearFlds();EnableControls();
                      window.document.frmcash.cmdLstCounter.disabled=false;
                      window.document.frmcash.butcashid.disabled=false;
                      window.document.frmcash.butcashtypeid.disabled=false;
                      window.document.frmcash.txtcid.readOnly=true;
                      window.document.frmcash.txtcounterno.readOnly=false;
                      window.document.frmcash.txtctypeid.readOnly=true" type="radio" value="INSERT" checked>
                      Counter Allotment</font></p>
                      </td>
                      <input name="optTran" onclick="mode=&quot;MODIFY&quot;;ClearFlds();EnableControls()" type="hidden" value="MODIFY">
                      <td align="middle" width="31%"><font class="textblack"><input name="optTran" onclick="mode=&quot;DELETE&quot;;;ClearFlds();
                      EnableControls();Cashiercode();window.document.frmcash.cmdLstCounter.disabled=true;
                      window.document.frmcash.butcashid.disabled=true;
                      window.document.frmcash.butcashtypeid.disabled=true;
                      window.document.frmcash.txtcid.readOnly=true;
                      window.document.frmcash.txtcounterno.readOnly=true;
                      window.document.frmcash.txtctypeid.readOnly=true"
                     type="radio" value="DELETE"> &nbsp;Cashier Delink</font></td>
                      <td align="middle" width="22%">
                      <p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;VIEW&quot;;;ClearFlds();DisableControls();
                      window.document.frmcash.butcashid.disabled=true;
                      window.document.frmcash.cmdLstCounter.disabled=true;Cashiercode();" type="radio" value="VIEW">
                      &nbsp;View&nbsp;&nbsp;</p>
                      </font></td>
                    </tr>
                  </table>

                  </td>
                </tr>
                <tr>
                  <td width="100%"></td>
                </tr>
              </table>

              </center>
            </div>
          </div>

          <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
            <tr>
              <td width="100%">&nbsp;
              <div align="center">
                <center>

                <table width="98%" class="tableborder2">
                  <tr>
                    <td>
                    <div align="center">

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="707" colspan="4" height="10">&nbsp;</td>
                        </tr>
                      </center></center>
                    <tr>
                      <td width="16%" height="27">
                      <p align="left">&nbsp;Counter No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>
                      
                      <td width="31%"><input name="txtcounterno" size="9" onkeypress="numeric()" onblur="Dataarrange (txtcounterno);;CashierDisp(&quot;txtcounterno&quot;)" style="TEXT-TRANSFORM: uppercase" maxlength="6" class="txtautofill"><input type="button" class="button" value=" L " name="cmdLstCounter" onclick="CounterNo()"><input name="txtcountername" size="16" readonly maxlength="20" class="bgcolor1"></td>
                    
                      <td width="22%" height="27">
                      <p align="right">Cashier ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>
                 
                      <td width="35%" height="27"><input name="txtcid" size="9" maxlength="20" style="TEXT-ALIGN: left;text-transform=uppercase" onblur="Dataarrange (txtcid);CashierDisp(&quot;txtcid&quot;)" class="txtautofill" readonly><input type="button" class="button" value=" L " name="butcashid" onclick="Cashiercode()"><input name="txtcdesc" size="14" readonly class="bgcolor1"></td>
                      </tr>
                      <tr>
                        <td width="16%" height="27">&nbsp;Cashier Type</td>
                        <td width="31%"><input name="txtctypeid" size="9" maxlength="20" style="TEXT-ALIGN: left;text-transform=uppercase" maxlength="10" class="txtautofill" readonly onblur="Dataarrange (txtctypeid)"><!--;CashierDisp(&quot;txtctypeid&quot;)" >--><input type="button" class="button" value=" L " name="butcashtypeid" onclick="Cashiertypeid()"><input name="txtCName" size="16" maxlength="20" readonly class="bgcolor1"></td>
                        
                        <td width="22%" height="27" align="right">Max.Cash Limit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td width="35%" height="27"><input name="txtmlimit" class="txtautofill" size="11" style="TEXT-ALIGN: right" value="0.00" maxlength="16" onkeypress="numdec(window.document.frmcash.txtmlimit.value,
                                  window.document.frmcash.hpr.value);" onblur="precision(window.document.frmcash.txtmlimit,
                          window.document.frmcash.hpr.value);
                          Chknull(window.document.frmcash.txtmlimit);
                          
                          "></td>
                      </tr>
                      <tr>
                        <td width="16%">&nbsp;Limit for Payment</td>
                        <td width="31%"><input name="txtlimitpay" size="12" value="0.00" maxlength="16" onkeypress="numdec(window.document.frmcash.txtlimitpay.value, window.document.frmcash.hpr.value);" onblur="precision(window.document.frmcash.txtlimitpay, window.document.frmcash.hpr.value); Chknull(window.document.frmcash.txtlimitpay);MaxPayLimit();" class="txtautofill"></td>
                        <td width="22%" align="right">Limit for Rcpt.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        <td width="35%"><input name="txtreceipt" maxlength="16" onblur="precision(window.document.frmcash.txtreceipt,window.document.frmcash.hpr.value); Chknull(window.document.frmcash.txtreceipt);MaxRecLimit();" onkeypress="numdec(window.document.frmcash.txtreceipt.value, window.document.frmcash.hpr.value);" size="11" style="TEXT-ALIGN: right" value="0.00" class="txtautofill"></td>
                      </tr>
                      <tr>
                        <td width="16%">&nbsp;Limit for Teller Payment</td>
                        <td width="31%"><input name="txttellerlimitpay" size="12" value="0.00" maxlength="16" onkeypress="numdec(window.document.frmcash.txttellerlimitpay.value, window.document.frmcash.hpr.value);" onblur="precision(window.document.frmcash.txttellerlimitpay, window.document.frmcash.hpr.value); Chknull(window.document.frmcash.txttellerlimitpay);MaxtellerPayLimit();" class="txtautofill"></td>
                        
                        <td width="22%" align="right">Limit for Teller Rcpt.&nbsp;&nbsp;</td>
                        <td width="35%"><input name="txttellerreceipt" maxlength="16" onblur="precision(window.document.frmcash.txttellerreceipt,window.document.frmcash.hpr.value); Chknull(window.document.frmcash.txttellerreceipt);MaxtellerRecLimit();" onkeypress="numdec(window.document.frmcash.txttellerreceipt.value, window.document.frmcash.hpr.value);" size="11" style="TEXT-ALIGN: right" value="0.00" class="txtautofill"></td>
                      </tr>
                      <tr>
                        <td width="707" height="10" colspan="4">&nbsp;</td>
                      </tr>
                      </table>

                    </div>
                    </center></center>
              </table>

              </div>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="20">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="31">
                    <tr>
                      <td width="100%" height="10"></td>
                    </tr>
                  </table>

                  <table border="0" width="100%" height="20" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%"></td>
                    </tr>
                  </table>

                  </td>
                </tr>
              </table>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="cashcountermgtquery.aspx">
                                              </iframe>
                  </td>
                </tr>
              </table>

              <input type="hidden" name="hidstatus"></td>
          </tr>
        </table>

      </div>
      </td>
    </tr>
    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="10"></td>
        </tr>
        <tr>
          <td width="100%" height="31">
          <div align="center">
            <center>

            <table width="20%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="  Ok  " name="cmdAdd" onclick="Insert()" class="button"><input type="reset" value="Cancel" name="cmdCancel" onclick="location.href=&quot;cashcountermgt.aspx&quot;" class="button"><input type="button" value="   Exit   " class="button" name="cmdexit" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;">
                <td width=" 100%" height="20"></td>
              </tr>
            </table>

            </div>
          </center></td>
        </tr>
        <tr>
          <td width="100%" height="10"></td>
        </tr>
      </table>

  </table>


</form>

<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	


</body>

