<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="frmCashReport.aspx.vb" Inherits="eSmartDotNet.frmCashReport"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Allotment</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var st
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

var brcd,Datcond,st

function toDateDisp()
{
	if(window.document.frmCashreport.cmbDateOper.value!="Between")
	{
		window.document.frmCashreport.txtToDate.disabled=true
	}
	else
	{
		window.document.frmCashreport.txtToDate.disabled=false
	}
}

function initialcheck()
{
	window.document.frmCashreport.txtToDate.disabled=true
	window.document.frmCashreport.txtFromDate.value = "<%=session("applicationdate")%>"
	window.document.frmCashreport.txtToDate.value = "<%=session("applicationdate")%>"
}

function show1()
{
	window.document.frmCashreport.txtcashdesc.value=""
	window.document.frmCashreport.txtcashid.value=""
	
	if(window.document.frmCashreport.repsch1(0).checked==true)
	{
		window.document.frmCashreport.butcashid.disabled=false
	}
	if(window.document.frmCashreport.repsch1(1).checked==true)
	{
		window.document.frmCashreport.butcashid.disabled=true
	}
}

function Cashiercode()
{
	var s1,stab
	if(window.document.frmCashreport.repsch1(0).checked==true)	
	{
		brcd = " AND A.BRANCHCODE = '"+window.document.frmCashreport.txtBrcode.value+"'"
	}
	if(window.document.frmCashreport.repsch1(1).checked==true)
	{
		brcd = ""
	}
	
	if(window.document.frmCashreport.cmbDateOper.value!="Between")
	{
		Datcond = " AND A.APPLICATIONDATE " + window.document.frmCashreport.cmbDateOper.value + "'"+window.document.frmCashreport.txtFromDate.value+"'"
	}
	else
	{
		Datcond = " AND A.APPLICATIONDATE BETWEEN '"+window.document.frmCashreport.txtFromDate.value+"' AND '"+window.document.frmCashreport.txtToDate.value+"'"
	}
	
	if(window.document.frmCashreport.txtFromDate.value == "<%=session("applicationdate")%>")
	{
		stab=""
	}
	else
	{
		stab="BKP"
	}
	
	
	s1="DNOMCASH"
	st=s1+"|"+brcd+"|"+Datcond+"|"+stab
	
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}

function ShowDivision(str)
{
	initialcheck()
	window.document.frmCashreport.txtcashdesc.value=""
	window.document.frmCashreport.txtcashid.value=""
	window.document.frmCashreport.repsch1(0).checked=true
	window.document.all.divRecpay.style.display="none"
	if(str=="0")
	{
		window.document.all.divRecpay.style.display="block"
		window.document.frmCashreport.txtDenomRep.value="Receipts"
	}
	if(str=="1")
	{
		window.document.all.divRecpay.style.display="block"
		window.document.frmCashreport.txtDenomRep.value="Payments"
	}
	
	
}

function Cashierid(kstr)
{   
	//alert(kstr)
	assign(kstr,window.document.frmCashreport.txtcashdesc,window.document.frmCashreport.txtcashid)
}

function Report(str)
{
	var strTab,stb,stCod,Rep,stCashid
	
	if(str=="HTML")
	{
		Rep = "HTML"
	}
	else
	{
		Rep = "XL"
	}
	
	
	
	if(window.document.all.divRecpay.style.display=="block")
	{
		if(window.document.frmCashreport.repsch1(0).checked==true)	
		{
			brcd = " AND BRANCHCODE = '"+window.document.frmCashreport.txtBrcode.value+"'"
		}
		if(window.document.frmCashreport.repsch1(1).checked==true)
		{
			brcd = ""
		}
		
		if(window.document.frmCashreport.txtDenomRep.value=="Receipts")
		{
			strTab = "CASHRECEIPTSTRN"
		}
		if(window.document.frmCashreport.txtDenomRep.value=="Payments")
		{
			strTab = "CASHPAYMENTSTRN"
		}
		
		if(window.document.frmCashreport.txtFromDate.value == "<%=session("applicationdate")%>")
		{
			stb = ""
		}
		else
		{
			stb = "BKP"
		}
		if(window.document.frmCashreport.cmbDateOper.value!="Between")
		{
			Datcond = " AND APPLICATIONDATE " + window.document.frmCashreport.cmbDateOper.value + "'"+window.document.frmCashreport.txtFromDate.value+"'"
		}
		else
		{
			Datcond = " AND APPLICATIONDATE BETWEEN '"+window.document.frmCashreport.txtFromDate.value+"' AND '"+window.document.frmCashreport.txtToDate.value+"'"
		}
		
		if(window.document.frmCashreport.txtcashid.value=="")
		{
			stCashid = ""
		}
		else
		{
			stCashid = " AND CASHIERID='"+window.document.frmCashreport.txtcashid.value+"' "
		}
		
		
		
		stCod = "CASHRECPAY"
		
		stt = stCod+"|"+Rep+"|"+strTab +"|"+stb+"|"+Datcond+"|"+brcd+"|"+stCashid
		//alert(" stt = "+stt)
		window.document.frmCashreport.action="CashDenomReport.aspx?strng="+stt
		window.document.frmCashreport.method="post"
		window.document.frmCashreport.submit();
	}
}

-->
</script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmCashreport.txtFromDate.value, "<%=session("applicationdate")%>")
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmCashreport.txtFromDate.value=""
				window.document.frmCashreport.txtFromDate.focus()
			}
			
			var intDiff2=getDateDiff(window.document.frmCashreport.txtToDate.value,window.document.frmCashreport.txtFromDate.value)
			
			if(intDiff2<0)
			{
				if(window.document.frmCashreport.txtFromDate.value=="")
				{
					alert("From Date Should Not be Null")
					window.document.frmCashreport.txtFromDate.focus()
				}
				
				alert("To Date Should Not be Less Than From Date.")
				window.document.frmCashreport.txtToDate.value=""
				window.document.frmCashreport.txtToDate.focus()
			}
			
			
			
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
	
	</script>

<body onload="GetMenu(&quot;<%=session("menustring")%>&quot;);initialcheck();toDateDisp();" topmargin="0" leftmargin="0">
    <%=Request.QueryString("record")%>
<form name="frmCashreport">
	<div class="header">
		<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
	</div>
    
	<div class="menuBar"><%appdate=formatdatetime(session("applicationdate"),1)%>
		<table cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
				<td width="19%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
				<td width="43%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Denomination Details</h2></td>
				<td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
			</tr>
		</table>
	</div> 
<div id="menucontrol"></div>
		
  <table width="100%" cellspacing="0" cellpadding="0" class="tblebordermain">
    <tr>
      <td width="100%">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="1">
        <tr>
          <td width="100%" height="29">

          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="12%" align="left">
                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</p>
                </td>
                <td width="38%"><input name="txtBrcode" size="9" readonly value="<%=session("branchcode")%>" class="txtautofill"><input type="button" value=" L " name="cmdbranch" onclick="Branch()" class="button"><input name="txtBrdesc" size="16" readonly value="<%=session("branchnarration")%>" class="bgcolor1">&nbsp;</td>
                
                <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency Code</td>
                <td width="35%"><input name="txtCrcode" size="9" value="<%=session("Currencycode")%>" readonly id="txtCrcode" maxlength="5" onblur="Dataarrange(txtCrcode)" class="txtautofill"><input type="button" value=" L "  class="button" name="butCurrency" onclick="Currency()" id="butCurrency"><input name="txtCrdesc" size="16" value="<%=session("Currencynarration")%>" readonly id="txtCrdesc" class="bgcolor1"></td>
              </tr>
            </table>

            </center>
          </div>
          <div align="center">
            <center>

            <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="16%" valign="top">
					<table border="01" width="100%" cellspacing="1" cellpadding="0"  >
						<tr bgcolor="#99ccff" >
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">Receipts</font></a></td>
						</tr>
						<tr bgcolor="#99ccff">
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">Payments</font></a></td>
						</tr>
				<!--		<tr bgcolor="#99ccff">
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('2')">&nbsp;<font class="textbold"></font></a>
							</td>
						</tr> 
						<tr bgcolor="#99ccff">
							<td width="100%" height="18"><a href="#" onclick="ShowDivision('3')">&nbsp;<font class="textbold"></font></a>
							</td>
						</tr> --->
					</table>
				</td>
				<td width="84%" valign="top">
					<div id="divRecpay" style="display:none">
						<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
							<tr>
								<td width="100%" >
									<table>
										<tr>
											<td align="middle" width="26%"><p align="left"><font class="textbold"><input name="txtDenomRep" class="button" value="Receipts"></font></p></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" >
									<table>
										<tr>
											<td width="30%" align="center"><input type="radio" name="repsch1" id="frmsub" onclick="show1()" checked><font class="textblack">Branch Wise </font></td>
											<td width="30%" align="center"><input type="radio" name="repsch1" id="frmnosub" onclick="show1()" ><font class="textblack">Consolidate Wise </font></td>
										</tr>
									</table>
								</td>	
							</tr>
							<tr>
								<td>
									<table class="tableborder2">
										<tr>
											<td width="20%" align="center" height="27">Operator</td>
												<td width="10%"><select size="1" name="cmbDateOper" onchange="toDateDisp()">
												<option value="=">=</option>
												<option value="&gt;">&gt;</option>
												<option value="&lt;">&lt;</option>
												<option value="Between">Between</option>
												</select></td>
												<td width="10%" align="left">&nbsp;From Date</td>
												<td width="10%"><input type="text" name="txtFromDate" id="dtpFromDate" maxlength=10 onblur="datecheck(this)" size="11"></td>
												<td width="10%">(DDMMYYYY)</td>
												<td width="10%">
												<p align="center">&nbsp;&nbsp;&nbsp;&nbsp;To</p>
												</td>
												<td width="10%">&nbsp;<input type="text" name="txtToDate" id="dtpToDate" maxlength=10 onblur="toaccdatechk(datecheck(this))" size="11"></td>
												<td width="20%">(DDMMYYYY)</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" >
									<table>
										<tr>
											<td width="15%" height="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cashier ID</td>
											<td width="30%" height="27"><input name="txtcashid" size="9" maxlength="20" style="TEXT-TRANSFORM: uppercase" class="txtautofill" class="bgcolor1" readonly ><input type="button" class="button" value=" L " name="butcashid" onclick="Cashiercode()"><input name="txtcashdesc" size="16" readonly class="bgcolor1"></td>
										</tr>
									</table>
								</td>
							</tr>
							
							
						</table>
						
					</div>
				</td>
			</tr>
			</table>
			
			<tr>
				<td width="100%" height="32" align="center"></td>
			</tr>
			<tr>
				<td width="100%" height="32"><center>
					<table width="10%" cellspacing="0" cellpadding="0" style="HEIGHT: 28px; WIDTH: 187px" class="tablebordermain">
						<tr>
							<td width="100%"><input name="cmdQuery" onclick="Report('HTML')" type="button" value=" Report " class="button"><input name="cmdQueryXl" onclick="Report('XL')" type="button" value=" XLReport " class="button"><input type="button" value="Cancel" name="cmdCancel" class="button" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/frmCashReport.aspx"%>&quot;"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module") & "module.aspx"%>&quot;"></td>
						</tr>
					</table></center>
				</td>
			</tr>
		</table>
      </td>
    </tr>
  </table>
  
  <div class="footer">
	<div class="logo"></div>
	<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises
	</div>
</div>
</form>

</body>

</html>          