<%@ Page aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Codebehind="clsbaldtlsrep.aspx.vb" Inherits="eSmartDotNet.clsbaldtlsrep"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
  <head>
  <title>Closing Balance Details Report</title>
  <% Dim BrCode, CurCode, RepDate,strsql,strRepTitle,strPrvRepdate,rsprvclsbal,appdate
   BrCode = UCase(Trim(Request.Form("txtbranchcode")))
	CurCode = UCase(Trim(Request.Form("txtcurrencycode")))
	RepDate = Request.Form("txtclsbalRepvltdate")
	appdate = session("applicationdate")
	strPrvRepdate =  DateAdd("m",-1,cdate(RepDate))
	strRepTitle = "Closing Balance Details Report As On Date " & RepDate
	rep = UCase(Trim(Request.Form("hidRep")))
	dim strQuery,GrdTot
	dim rsclsbaldtls,rssumclsbal
	dim strbrcode1
	dim strbrcond
	strbrcond = Request.QueryString("st")
	if rep = "XL" then
		Response.ContentType = "application/vnd.ms-excel"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & "clsbaldtlsrep.xls")
	end if					
	rsprvclsbal = server.CreateObject("adodb.recordset")
	rs = server.CreateObject("adodb.recordset")
	rsclsbaldtls = server.CreateObject("adodb.recordset")
	obj = server.CreateObject("ReportPurposeOnly.Reportonly")
	rssumclsbal = server.CreateObject("adodb.recordset")
	rsrcpt = server.CreateObject("adodb.recordset")
	rspaymt = server.CreateObject("adodb.recordset")
	objsumclsbal = server.CreateObject("ReportPurposeOnly.Reportonly")
	
	rsaddress=server.CreateObject("adodb.recordset")
	objfetch =server.CreateObject("queryrecordsets.fetchrecordsets")
if strbrcond = "" then
strbrcode1 = "999"
else
strbrcode1 = BrCode
end if 
	rsaddress=objfetch.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & strbrcode1 & "' and a.bankcode=b.bankcode")
	
	%>
    <meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <style>.break { page-break-after: always }
</style>

<script>
	function HandleBackFunctionality()
	{
		if(window.event)
		{
			if(window.event.clientX < 40 && window.event.clientY < 0)
			{
			var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
			else
			{
			//   alert("Browser refresh button is clicked...");
			}
		}
		else
		{
			if(event.currentTarget.performance.navigation.type == 1)
			{
			//   alert("Browser refresh button is clicked...");
	     
			}
			if(event.currentTarget.performance.navigation.type == 2)
			{
			//  alert("Browser back button is clicked...");
					var windowObject = window.self; windowObject.opener = window.self; windowObject.close();
			}
		}
	}


	function notAllowed()
	{
		if(event.ctrlKey)
		{
			event.keyCode=0;
			return false;
		}
		if(parseInt(event.button)==2 ||parseInt(event.button)==3 )
		{
			alert("This Operation Is Not Allowed");
			return false;     
		}
	} 


	function prnt()
	{
		window.document.all['divPrnt'].style.display="none";
		window.print()
		window.document.all['divPrnt'].style.display="block";
	}
		
	function SelCopy()
	{
		var copysuccess // var to check whether execCommand successfully executed
		try
		{
			copysuccess = document.execCommand("copy") // run command to copy selected text to clipboard
		} 
		catch(e)
		{
			copysuccess = false
		}
		return copysuccess
	}

	function selectText(containerid) 
	{
		if (document.selection) 
		{
			var range = document.body.createTextRange();
			range.moveToElementText(document.getElementById(containerid));
			range.select();
		} 
		else if (window.getSelection()) 
		{
			var range = document.createRange();
			range.selectNode(document.getElementById(containerid));
			window.getSelection().removeAllRanges();
			window.getSelection().addRange(range);
		}
	}

</script>
  </head>
  
  <body leftMargin="0" topMargin="0" onmousedown="notAllowed();" onkeydown="notAllowed();" onbeforeunload="HandleBackFunctionality();" >

    <form name="frmclsbaldtls">
<table width="80%" border=0>
			<tr>
				<td align="center" width="100%" colSpan="4">
					<%''''' Report Headings%>
					<center><font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
						</font>
						<br>
						<font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value) & "," & iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
						</font>
						<br>
						<font color="#000000" size="3">
							<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
						</font>
					</center>
				</td>
			</tr>
		</table>
		
<table width="80%">
			<tr>
			<td align="center" colSpan="2"><font face="courier new" color="#000000" size="2"><%=strRepTitle%></font></td>
			</tr>
			<tr>
				<td align="left" width="50%"><font face="courier new" color="#000000" size="2">User ID&nbsp;:&nbsp;<%=session("userid")%></font></td>
				<td align="right" width="50%"><font face="courier new" color="#000000" size="2">Branch Code&nbsp;:&nbsp;<%=strbrcode1%></font></td>
			</tr>
		</table>
		<table width="60%" class="tblebordermain" border="1" >
		<tr><td colspan=6> Summary</td></tr>
		<tr>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2">BrCode </font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Opening Bal</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Receipts</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Payments</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Closing Bal</font></td>
		</tr>
		
		<%
		
		dim intsumsno,dblsumopenbal,dblsumreceips,dblsumpayments,dblsumclsbal, strsumbrcode,dblgrndtotsumclsbal
		dblgrndtotsumclsbal = 0
		strsql = "SELECT branchcode FROM genbankbranchmst WHERE " & strbrcond & " branchtype != 'HO'"
		rs = objsumclsbal.SingleSelectStat(strsql)
		if objsumclsbal.ConnError="Connected" then
			if not rs.bof and not rs.eof then
				do until rs.eof

		strsumbrcode = iif(isdbnull(rs(0).value),"",rs(0).value)
		
		intsumsno  = ""
		dblsumopenbal  = 0
		dblsumreceips  = 0
		dblsumpayments  = 0
		dblsumclsbal  = 0
		
	strsql = "SELECT sum(OPENINGBAL) OPENINGBAL, sum(CLOSINGBAL) CLOSINGBAL FROM cashbalance c WHERE currencycode  = '"& CurCode &"' and  branchcode = '"& strsumbrcode &"' and applicationdate = (SELECT MAX(applicationdate) FROM cashbalance WHERE applicationdate <= '"& RepDate &"' and branchcode =  c.branchcode and currencycode = c.currencycode) group by branchcode"
rssumclsbal = objsumclsbal.SingleSelectStat(strsql)
					
					if objsumclsbal.ConnError="Connected" then
						if not rssumclsbal.bof and not rssumclsbal.eof then
							do until rssumclsbal.eof
							
							dblsumopenbal = iif(isdbnull(rssumclsbal(0).value),0,rssumclsbal(0).value) 
							dblsumclsbal =  iif(isdbnull(rssumclsbal(1).value),0,rssumclsbal(1).value) 
							
							if  dblsumopenbal = 0 then
							strsql = "SELECT sum(CLOSINGBAL) CLOSINGBAL FROM cashbalance c WHERE currencycode  = '"& CurCode &"' and  branchcode = '"& strsumbrcode &"' and applicationdate = (SELECT MAX(applicationdate)-1 FROM cashbalance WHERE applicationdate <= '"& RepDate &"' and branchcode =  c.branchcode and currencycode = c.currencycode)"
							rsprvclsbal = objsumclsbal.SingleSelectStat(strsql)
								if objsumclsbal.ConnError="Connected" then
									if not rsprvclsbal.bof and not rsprvclsbal.eof then
										dblsumopenbal = iif(isdbnull(rsprvclsbal(0).value),0,rsprvclsbal(0).value) 
									end if
								end if	
							
					if rsprvclsbal.state = 1 then
						rsprvclsbal.close
						rsprvclsbal = nothing
						end if
											
					end if ''if dblsumopenbal = 0 then
if cdate(RepDate) = cdate(appdate) then			
strsql = "SELECT SUM(amount) amount FROM CASHRECEIPTSTRN r WHERE currencycode  = '"& CurCode &"' and  branchcode = '"& strsumbrcode &"' and  applicationdate = (SELECT MAX(applicationdate) FROM CASHRECEIPTSTRN  WHERE branchcode = r.branchcode AND currencycode = r.currencycode AND applicationdate<= '"& RepDate &"')"  
else
strsql = "SELECT SUM(amount) amount FROM CASHRECEIPTSTRNBKP r WHERE currencycode  = '"& CurCode &"'  and  branchcode = '"& strsumbrcode &"' AND applicationdate = (SELECT MAX(applicationdate) FROM CASHRECEIPTSTRNBKP  WHERE branchcode = r.branchcode AND currencycode = r.currencycode AND applicationdate<= '"& RepDate &"')"
end if
		rsrcpt = objsumclsbal.SingleSelectStat(strsql)
					
					if objsumclsbal.ConnError="Connected" then
						if not rsrcpt.bof and not rsrcpt.eof then
							dblsumreceips = iif(isdbnull(rsrcpt(0).value),0,rsrcpt(0).value) 
						end if
					end if	

		if rsrcpt.state = 1 then
			rsrcpt.close
			rsrcpt = nothing
			end if
if cdate(RepDate) = cdate(appdate) then						
strsql = "SELECT SUM(amount) amount FROM CASHPAYMENTSTRN r WHERE currencycode  = '"& CurCode &"' AND   branchcode = '"& strsumbrcode &"' and applicationdate = (SELECT MAX(applicationdate) FROM CASHPAYMENTSTRN  WHERE branchcode = r.branchcode AND currencycode = r.currencycode AND applicationdate<= '"& RepDate &"')"
else
strsql = "SELECT SUM(amount) amount FROM CASHPAYMENTSTRNBKP r WHERE currencycode  = '"& CurCode &"'  AND   branchcode = '"& strsumbrcode &"' and applicationdate = (SELECT MAX(applicationdate) FROM CASHPAYMENTSTRNBKP  WHERE branchcode = r.branchcode AND currencycode = r.currencycode AND applicationdate<= '"& RepDate &"')"
end if
		rspaymt = objsumclsbal.SingleSelectStat(strsql)
					
					if objsumclsbal.ConnError="Connected" then
						if not rspaymt.bof and not rspaymt.eof then
							dblsumpayments =  iif(isdbnull(rspaymt(0).value),0,rspaymt(0).value)
						end if
					end if	
		
		if rspaymt.state = 1 then
			rspaymt.close
			rspaymt = nothing
			end if
		%>
		
		<tr>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2"><%= strsumbrcode %> </font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= cdbl(dblsumopenbal) %></font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= cdbl(dblsumreceips) %></font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= cdbl(dblsumpayments) %></font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= cdbl(dblsumclsbal) %></font></td>
				</tr>
		
		<%
		dblgrndtotsumclsbal =  cdbl(dblgrndtotsumclsbal) + cdbl(dblsumclsbal)
				rssumclsbal.movenext
							loop
						end if
					end if	
			
			if rssumclsbal.state = 1 then
			rssumclsbal.close
			rssumclsbal = nothing
			end if

					rs.movenext
						loop
						end if
					end if	
			
			if rs.state = 1 then
			rs.close
			rs = nothing
			end if

		%>
		<tr>
		
				<td colspan = "5" align = "right" ><font face="courier new" color="#000000" size="2">Summary Grand Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <%=cdbl(dblgrndtotsumclsbal) %></font></td>
		</tr>
		</table>		
		<%
		intsumsno=0
			strsql = "SELECT Denominationvalue, Denominationcode FROM CashDenominationMst WHERE UPPER(Currencycode)='"& CurCode &"' ORDER BY SUBSTR(denominationtype,1,1) DESC, SUBSTR(denominationtype,2,1) ,TO_NUMBER( denominationvalue) DESC"
rssumclsbal = objsumclsbal.SingleSelectStat(strsql)			
			
		%>
		<table><tr><td colspan=6> &nbsp;</td></tr></table>
		<table width="60%" class="tblebordermain" border="1" >
		<tr><td colspan=6> Denomination Details</td></tr>
		<tr>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2">Sno </font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Denomination</font></td>
					<td align="center" width="3%"><font face="courier new" color="#000000" size="2">*</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Avail No Pieces</font></td>
					<td align="center" width="3%"><font face="courier new" color="#000000" size="2">=</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2">Tot Sum</font></td>
					
		</tr>		
<%
					dim dblclsdtlamt,dbldenom,int1, dbltotclsdtlamt,dblgrndtotclsdtls
					dblgrndtotclsdtls=0
					if objsumclsbal.ConnError="Connected" then
						if not rssumclsbal.bof and not rssumclsbal.eof then
						do until rssumclsbal.eof 
						intsumsno= intsumsno + 1	
						
						dblclsdtlamt=0
						dbldenom = 0
						dbltotclsdtlamt = 0
						
						dbldenom =  rssumclsbal(0).value
					strsql = "SELECT SUM(NVL(D1,0)) D1 ,SUM(NVL(D2,0)) D2,SUM(NVL(D3,0)) D3, SUM(NVL(D4,0)) D4,SUM(NVL(D5,0)) D5,SUM(NVL(D6,0)) D6,SUM(NVL(D7,0)) D7, SUM(NVL(D8,0)) D8,SUM(NVL(D9,0)) D9, SUM(NVL(D10,0)) D10,SUM(NVL(D11,0)) D11,SUM(NVL(D12,0)) D12, SUM(NVL(D13,0)) D13,SUM(NVL(D14,0)) D14, SUM(NVL(D15,0)) D15,SUM(NVL(D16,0)) D16,SUM(NVL(D17,0)) D17, SUM(NVL(D18,0)) D18, SUM(NVL(D19,0)) D19, SUM(NVL(D20,0)) D20, SUM(NVL(D21,0)) D21, SUM(NVL(D22,0)) D22, SUM(NVL(D23,0)) D23, SUM(NVL(D24,0)) D24, SUM(NVL(D25,0)) D25,  SUM(NVL(D26,0)) D26, SUM(NVL(D27,0)) D27,  SUM(NVL(D28,0)) D28, SUM(NVL(D29,0)) D29, SUM(NVL(D30,0)) D30, SUM(NVL(D31,0)) D31, SUM(NVL(D32,0)) D32, SUM(NVL(D33,0)) D33, SUM(NVL(D34,0)) D34, SUM(NVL(D35,0)) D35, SUM(NVL(D36,0)) D36, SUM(NVL(D37,0)) D37, SUM(NVL(D38,0)) D38,  SUM(NVL(D39,0)) D39, SUM(NVL(D40,0)) D40, SUM(NVL(D41,0)) D41, SUM(NVL(D42,0)) D42, SUM(NVL(D43,0)) D43 , SUM(NVL(D44,0)) D44, SUM(NVL(D45,0)) D45, SUM(NVL(D46,0)) D46, SUM(NVL(D47,0)) D47, SUM(NVL(D48,0)) D48, SUM(NVL(D49,0)) D49,  SUM(NVL(D50,0))  D50 FROM cashbalance c WHERE currencycode  = '"& CurCode &"' AND  " & strbrcond & " applicationdate =  (SELECT MAX(applicationdate) FROM cashbalance  WHERE branchcode = c.branchcode  AND currencycode = c.currencycode AND applicationdate<='"& RepDate &"')"
					
						rsclsbaldtls = objsumclsbal.SingleSelectStat(strsql)			

						if objsumclsbal.ConnError="Connected" then						
							if not rsclsbaldtls.eof and not rsclsbaldtls.bof then
							For int1 = 0 To rsclsbaldtls.Fields.Count - 1  
								if cstr(rsclsbaldtls.Fields.Item(int1).Name)  = cstr(rssumclsbal(1).value) then
									dblclsdtlamt = iif(isdbnull(rsclsbaldtls(int1).value),0,rsclsbaldtls(int1).value)
								end if
							Next  
							end if
						end if
						dbltotclsdtlamt = cdbl(dbldenom) * cdbl(dblclsdtlamt)
						dblgrndtotclsdtls =  cdbl(dblgrndtotclsdtls) + cdbl(dbltotclsdtlamt)
						if rsclsbaldtls.state = 1 then
							rsclsbaldtls.close
							rsclsbaldtls = nothing
						end if

						%>
						<tr>
					<td align="center" width="4%"><font face="courier new" color="#000000" size="2"><%= intsumsno %> </font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= dbldenom %></font></td>
					<td align="center" width="3%"><font face="courier new" color="#000000" size="2">*</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%=cdbl(dblclsdtlamt)  %></font></td>
					<td align="center" width="3%"><font face="courier new" color="#000000" size="2">=</font></td>
					<td align="right" width="14%"><font face="courier new" color="#000000" size="2"><%= cdbl(dbltotclsdtlamt) %></font></td>
						</tr>
<%
						rssumclsbal.movenext
						loop	
						end if
					end if	
		
		if rssumclsbal.state = 1 then
			rssumclsbal.close
			rssumclsbal = nothing
			end if
		
%>		
		<tr>
		<td align="right" colspan=6 ><font face="courier new" color="#000000" size="2">Grand Total: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <%= cdbl(dblgrndtotclsdtls)%></font></td>
		</tr>		
		</table>
				<table align=center width = "100%" >
				<tr><td>&nbsp;</td></tr>
				<tr><td>&nbsp;</td></tr>
			<tr>
				<td align =center >
					<div id="divPrnt">
					<input type="button" value="  Select All   " name="butSelectAll" onclick="selectText('divselcopy')" class="button">
					<input type="button" value="  Copy   " name="butCopy" onclick="SelCopy()" class="button"><input onclick="prnt()" type="button" value="  Print   " name="butprnt"><input class="bgcolor" onclick="location.href='cashierwisereport.aspx'" type="button" value="   Exit   "
													name="butok"></div>
				</td>
			</tr>
		</table>
    </form>
  </body>
</html>
