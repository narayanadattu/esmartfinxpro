<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashmasterfly.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashmasterfly" %>
<HTML>
<HEAD>
<META NAME="GENERATOR"  Content="Microsoft Visual Studio 6.0">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{
  var kstr
  kstr= window.document.frmacc.hbno.value
  if(kstr)
    {
  window.attachEvent(window.parent.flycash(kstr))
  window.close()
  }
 
}
//-->
</SCRIPT>

<%
 dim obj,rs,acc,a
 kstr=Request.Form("hFlds")
	
if len(kstr)> 0 then
	StrFlds=split(kstr,"~")
	 obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	if(StrFlds(1)="CashierDetails") then
		 rs=server.CreateObject("adodb.recordset")
		 obj=server.CreateObject("queryrecordsets.fetchrecordsets")
		 rs=obj.singlerecordset("CASHCASHIERTYPEMST","paymentsyn,receiptsyn," & _
		"tellerreceiptsyn,tellerpaymentsyn", _
		"STATUS='R' and cashiertypeid='" & StrFlds(0) & "'")
		acc=rs(0).value & "|" & rs(1).value & "|" & rs(2).value & "|" & rs(3).value
		'''for currencycode from the cashcountermst table for modification and deleting
	elseif StrFlds(0)="CurrencyDet" then
	Response.Write (StrFlds(1) & "<br>")
	Response.Write (StrFlds(2) & "<br>")
		 recGen=server.CreateObject("adodb.recordset")
		 obj=server.CreateObject("queryrecordsets.fetchrecordsets")
		 recGen=obj.singlerecordset("CASHCOUNTERMST c,GENCURRENCYTYPEMST g", _
				"DISTINCT c.currencycode,g.narration", _
				"branchcode='" & StrFlds(1) & "' and " & _
				"counterno='" & StrFlds(2) & "' and " & _
				"c.currencycode=g.currencycode")
				if recGen.RecordCount<>0 then
				Response.Write ("LL")
					do until recGen.EOF
						acc=acc & recGen(0).value & "*" & recGen(1).value & "|"
					recGen.MoveNext
					loop
					Response.Write (acc)
					acc=acc & "~" & "Currency"
				end if
		
	elseif StrFlds(5)="CounterDetails" then
		 RecGen=Obj.SingleRecordset(cstr(StrFlds(0)),cstr(StrFlds(1)),cstr(StrFlds(2)))
				if not RecGen.BOF or not RecGen.EOF then
					for i=0 to RecGen.Fields.Count-1
						acc=acc &  recgen(i).value & "|"
					next
				else
				acc= "No|"	
				end if
				acc=acc & "~" & StrFlds(4)
		
	
	end if
end if	
%>
 
</HEAD>                  
<BODY bgcolor=#643428  onLoad='List()'>
<form name=frmacc>
<INPUT type=hidden id="hbno" name="hbno" value="<%=acc%>">
<input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>

</form>
</BODY>
</HTML>


