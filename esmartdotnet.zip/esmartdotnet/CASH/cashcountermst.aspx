<%@ Page CodeBehind="cashcountermst.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashcountermst" %>
<html>
<%
%>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Clearing Account Parameters</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
//// this function is used to diplay the fields which was select in the list
var cnt
cnt="<%=cnt%>"
function branch()
{
	st="Branch"
	window.showModalDialog("Listmaster.aspx"+"?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:240px")
}	 

// To assign the values for the respective branch related text boxes
function Branchid(kstr)
{

var StrFlds=new String()
StrFlds=kstr.split("-----")
	window.document.frmCounterMst.txtBranchcode.value=StrFlds[1]
	window.document.frmCounterMst.txtBranchdesc.value=StrFlds[0]
	clearFlds()
	window.document.frmCounterMst.txtCurrencyCode.value=""
	window.document.frmCounterMst.txtCurrencyDesc.value=""
	
}	 
// To get the values for the currencycode
function currency()
{
	st="Currency"
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:270px;DialogTop:240px")
}
// To assing the values for the respective currency related text boxes
function Currencyid(kstr)
{
var StrFlds=new String()
StrFlds=kstr.split("-----")
	window.document.frmCounterMst.txtCurrencyCode.value=StrFlds[1]
	window.document.frmCounterMst.txtCurrencyDesc.value=StrFlds[0]
	//clearFlds()
}
//to get Counterno for selected branchcode,currencycode
function Counter()
{

	sBr=window.document.frmCounterMst.txtBranchcode.value
	sCur=window.document.frmCounterMst.txtCurrencyCode.value
	
	if(sBr=="")
	{
	alert("select BranchCode")
	return
	}
	if(mode=="ADD")
	{
	if(sCur=="")
	{
		alert("Select CurrencyCode")
		return;
	}
	}
	sBr=sBr.toUpperCase()
	sCur=sCur.toUpperCase()
	window.document.frmCounterMst.MfgCurrency.Rows=1
	st="CounterNo|"+sBr+"|"+sCur
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
// To assing the values for the respective currency related text boxes
function Counterid(kstr)
{

var StrFlds=new String()
StrFlds=kstr.split("-----")
	window.document.frmCounterMst.txtCode.value=StrFlds[1]
	window.document.frmCounterMst.txtDesc.value=StrFlds[0]
	sBr=window.document.frmCounterMst.txtBranchcode.value
	sCode=window.document.frmCounterMst.txtCode.value
		st="CurrencyDet~"+sBr+"~"+sCode
		//Window.document.all["iBatch"].src="cashmasterfly.aspx"
		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
	
}

//this function is used to set mode status depending upon the the option buttons clicked
function modeStatus()
{
	if(window.document.frmCounterMst.optTran(0).checked==true)
	{
		mode="ADD"
	}
	else if(window.document.frmCounterMst.optTran(1).checked==true)
	{
	
	mode="MODIFY"
	}
	else if(window.document.frmCounterMst.optTran(2).checked==true)
	{

	mode="DELETE"
	}
	else if(window.document.frmCounterMst.optTran(3).checked==true)
	{
	mode="VIEW"
	}
}
// sending parameters to display the description of seleted code 
///i.e this is send to code text boxes onblur event
function DescriptionDisp(StrTxt)
{

/// for displaying the branchdescription for selected branch code
///if mode="MODIFY" then only work this function
 if(mode=="Add")
 {
 return;
 }
 
	if(StrTxt=="txtCode")
	{
		if(window.document.frmCounterMst.txtCode.value=="")
		{
		return;
		}
		sCode=window.document.frmCounterMst.txtCode.value
		sBr=window.document.frmCounterMst.txtBranchcode.value
		sCur=window.document.frmCounterMst.txtCurrencyCode.value
		sCur=sCur.toUpperCase()
		sCode=sCode.toUpperCase()
		sBr=sBr.toUpperCase()
		st="Cashcountermst~narration~counterno='"+sCode+"' and "+
		"upper(trim(branchcode))='"+sBr+"'"+
		"~~"+
			StrTxt+"~CounterDetails"
		window.document.frmCounterMst.MfgCurrency.Clear()
	window.document.frmCounterMst.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmCounterMst.MfgCurrency.Rows=1	
		window.document.all["iBatch"].src="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
	}
		
}
/// function is used to displaying the values in client 
/////side page which is coming from fly page
function flycash(kstr)
{

var StrArrMain=new String()
var StrArrFld=new String()
var StrArrRow=new String()
//split the kstr
StrArrMain=kstr.split("~")
StrArrFld=StrArrMain[0].split("|")
///for displaying branchdesc
	if(StrArrMain[1]=="txtCode")
	{
		if(StrArrFld[0]=="No")
		{
		alert("Invalid Counter No")
		window.document.frmCounterMst.txtCode.value=""
		window.document.frmCounterMst.txtDesc.value=""
		return;
		}
		sBr=window.document.frmCounterMst.txtBranchcode.value
		sCode=window.document.frmCounterMst.txtCode.value
		window.document.frmCounterMst.txtDesc.value=StrArrFld[0]
		st="CurrencyDet~"+sBr+"~"+sCode
		
		window.document.all["iBatch"].src="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
	}
	//for existing currencycode adding to grid for selected counter no which are
	//coming from iframe page
	else if(StrArrMain[1]=="Currency")
	{
		var StrRow=new String()
		var StrCol=new String()
		StrRow=StrArrMain[0].split("|")
		
		for(icnt=0;icnt<=StrRow.length-1;icnt++)
		{
			window.document.frmCounterMst.MfgCurrency.Rows=
			window.document.frmCounterMst.MfgCurrency.Rows+1
			StrCol=StrRow[icnt].split("*")
			window.document.frmCounterMst.MfgCurrency.TextMatrix(icnt+1,0)=StrCol[0]//currencycode
			window.document.frmCounterMst.MfgCurrency.TextMatrix(icnt+1,1)=StrCol[1]//currencydesc
			
			
		}
		window.document.frmCounterMst.MfgCurrency.Rows=
			window.document.frmCounterMst.MfgCurrency.Rows-1
	}
}			
//function for clearing fields
function clearFlds()
{
window.document.frmCounterMst.txtCode.value=""
window.document.frmCounterMst.txtDesc.value=""
window.document.frmCounterMst.MfgCurrency.Clear()
	window.document.frmCounterMst.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmCounterMst.MfgCurrency.Rows=1
}
///posts to server side page to do transactions 
function okClick()
{
//this function is not work id mode='VIEW'
if(mode=="VIEW")
{
return;
}
if((window.document.frmCounterMst.txtDesc.value=="")||
(window.document.frmCounterMst.txtBranchcode.value=="")||
(window.document.frmCounterMst.txtCurrencyCode.value==""))

{
alert("Enter all details")
return;
}
if(window.document.frmCounterMst.MfgCurrency.Rows==1)
{
alert("Enter Currency Code in Grid")
return;
}
///adding currencycode in the grid to hidden field
	for(icnt=1;icnt<=window.document.frmCounterMst.MfgCurrency.Rows-1;icnt++)
	{
		window.document.frmCounterMst.hCur.value=window.document.frmCounterMst.hCur.value+
			window.document.frmCounterMst.MfgCurrency.TextMatrix(icnt,0)+"|"
	}
 /// post to server side page to do the transactions 	
  	stt="CashCounterMst"
  	
	window.document.frmCounterMst.status.value=mode
	window.document.frmCounterMst.action="cashmastersinsert.aspx?strng="+stt
	window.document.frmCounterMst.method="post"
	window.document.frmCounterMst.submit();
}
//disbaling the controls 
function enableControls()
{
	window.document.frmCounterMst.txtCode.disabled=false
	window.document.frmCounterMst.txtDesc.disabled=false
	//window.document.frmCounterMst.cmdlstCode.disabled=false
	window.document.frmCounterMst.cmdAddtoGrid.disabled=false
	window.document.frmCounterMst.cmdOk.disabled=false
}
///enabling the controls 
function DisbaleControls()
{
	window.document.frmCounterMst.txtCode.disabled=true
	window.document.frmCounterMst.txtDesc.disabled=true
	//window.document.frmCounterMst.cmdlstCode.disabled=true
	window.document.frmCounterMst.cmdAddtoGrid.disabled=true
	window.document.frmCounterMst.cmdOk.disabled=true
}
function AddtoGrid()
{
if(window.document.frmCounterMst.txtDesc.value=="")
{
alert("Enter Counter Description")
return;
}
if(window.document.frmCounterMst.MfgCurrency.Rows>=2)
{
kstr=confirm("Are You Sure to Allot one More currency to same counter?")
if(kstr==false)
{
	return;
}
}	
flexrow=window.document.frmCounterMst.MfgCurrency.Rows
	//checking if selected currencycode is already there in grid
	if(window.document.frmCounterMst.MfgCurrency.Rows>=2)
	{
	for(icnt=1;icnt<=window.document.frmCounterMst.MfgCurrency.Rows-1;icnt++)
	{
		if(window.document.frmCounterMst.MfgCurrency.TextMatrix
		(icnt,0)==window.document.frmCounterMst.txtCurrencyCode.value)
		{
			alert("Currency is already exists ")
			return;
		}
	}	
	}
	
			//st=st.toUpperCase()
				
				window.document.frmCounterMst.MfgCurrency.Rows=
				window.document.frmCounterMst.MfgCurrency.Rows+1
				window.document.frmCounterMst.MfgCurrency.TextMatrix(flexrow,0)=
				window.document.frmCounterMst.txtCurrencyCode.value
				window.document.frmCounterMst.MfgCurrency.TextMatrix(flexrow,1)=
				window.document.frmCounterMst.txtCurrencyDesc.value

}



//-->
</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function MfgCurrency_Click() {
if(window.document.frmCounterMst.optTran[3].checked==true)
{
return;
}
kstr=confirm("Are You Sure To Delete the Row")
if(kstr==true)
{
	if(window.document.frmCounterMst.MfgCurrency.Rows>2)
	{
		window.document.frmCounterMst.txtCurrencyCode.value=
		window.document.frmCounterMst.MfgCurrency.TextMatrix
		(window.document.frmCounterMst.MfgCurrency.row,0)
		
		window.document.frmCounterMst.txtCurrencyDesc.value=
		window.document.frmCounterMst.MfgCurrency.TextMatrix
		(window.document.frmCounterMst.MfgCurrency.row,1)	
		window.document.frmCounterMst.MfgCurrency.RemoveItem
		(window.document.frmCounterMst.MfgCurrency.Row)						
	}
	else
	{
		window.document.frmCounterMst.txtCurrencyCode.value=
		window.document.frmCounterMst.MfgCurrency.TextMatrix
		(window.document.frmCounterMst.MfgCurrency.row,0)
		window.document.frmCounterMst.txtCurrencyDesc.value=
		window.document.frmCounterMst.MfgCurrency.TextMatrix
		(window.document.frmCounterMst.MfgCurrency.row,1)
	window.document.frmCounterMst.MfgCurrency.Clear()
	window.document.frmCounterMst.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmCounterMst.MfgCurrency.Rows=1
	}
}

}
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashcountermst.aspx" 
		
	}
}	
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=MfgCurrency EVENT=Click>
<!--
 MfgCurrency_Click()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="modeStatus();DispTranMsg()">

<form name="frmCounterMst">
 
  <%appdate=formatdatetime(session("applicationdate"),1)%>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" height="17"></td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="158%" align="left">
          <p align="left"><font class="text">&nbsp;Cash Counter Master</font>
        </tr>
        <tr>
          <td width="100%" align="middle">
          <p align="center"><font face="MS Sans Serif" class="textblue"></font></td>
        </tr>
        <tr>
          <td width="100%" align="middle" height="15"></td>
        </tr>
        <tr>
          <td width="100%" align="middle">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="15%">
                  <p align="right">Branch Code&nbsp;&nbsp;&nbsp;</p></td>
                  <td width="28%"><input name="txtBranchcode" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" readonly value="<%=session("Branchcode")%>" id="txtBranchcode" maxlength="5" onblur="Dataarrange(txtBranchcode)" class="txtautofill"><input type="button" value=" L " name="cmdBranch" onclick="branch()" class="button"><input name="txtBranchdesc" size="16" value="<%=session("Branchnarration")%>" readonly></td>
                  
                  <td width="20%" align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  <td width="30%"><input name="txtCurrencyCode" size="9" value="<%=session("Currencycode")%>"  style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onblur="Dataarrange(txtCurrencyCode)" readonly maxlength="5" class="txtautofill"><input type="button" value=" L " name="cmdCurrency" onclick="currency()" class="button"><input name="txtCurrencyDesc" size="16" value="<%=session("Currencynarration")%>" readonly id="txtCurrencydesc"></td>
                </tr>
              </table>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">

                  <table border="0" width="100%" cellspacing="00" cellpadding="0" class="tableborder1">
                    <tr class="bgcolor1">
                      <td align="middle" width="26%">
                      <p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;ADD&quot;;clearFlds();
                    window.document.frmCounterMst.cmdlstCode.disabled=true
                    window.document.frmCounterMst.txtCode.readOnly=true;
                    window.document.frmCounterMst.txtDesc.readOnly=false;enableControls();window.document.frmCounterMst.txtCode.value=cnt" type="radio" value="INSERT" checked>
                      New</font></p>
                      </td>
                      <td align="middle" width="27%"><font class="textblack"><input name="optTran" onclick="mode=&quot;MODIFY&quot;;
                    ;clearFlds();window.document.frmCounterMst.cmdlstCode.disabled=false;
                    window.document.frmCounterMst.txtCode.readOnly=false;
                    window.document.frmCounterMst.txtDesc.readOnly=false;enableControls()" type="radio" value="MODIFY">
                      Modify</font></td>
                      <td align="middle" width="31%"><font class="textblack"><input name="optTran" onclick="mode=&quot;DELETE&quot;;;
                    clearFlds();window.document.frmCounterMst.cmdlstCode.disabled=false;
                    window.document.frmCounterMst.txtCode.readOnly=false;
                    window.document.frmCounterMst.txtDesc.readOnly=false;enableControls();
                    window.document.frmCounterMst.txtDesc.disabled=true;" type="radio" value="DELETE">
                      &nbsp;Delete</font></td>
                      <td align="middle" width="22%">
                      <p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;VIEW&quot;;;
                    clearFlds();window.document.frmCounterMst.cmdlstCode.disabled=false;
                    window.document.frmCounterMst.txtCode.readOnly=false;
                    
                    window.document.frmCounterMst.txtDesc.readOnly=true;DisbaleControls()" type="radio" value="VIEW">
                      &nbsp;View&nbsp;&nbsp;</p>
                      </font></td>
                    </tr>
                  </table>

                  </td>
                </tr>
                <tr>
                  <td width="100%">

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%">&nbsp;
                      <div align="center">
                        <center>

                        <table border="0" width="90%" cellspacing="0" cellpadding="0" class="tableborder2" align="center">
                          <tr>
                            <td width="5%" align="center" height="18"></td>
                            <td width="30%" height="18"></td>
                          </tr>
                          <tr>
                            <td width="5%" align="right" height="27"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;Counter No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                            <td width="30%" height="27"><font size="2" face="MS Sans Serif"><input name="txtCode" size="18" maxlength="6" onkeypress="numeric()" style="TEXT-TRANSFORM: uppercase" readonly onblur="DescriptionDisp(&quot;txtCode&quot;)" class="txtautofill"></font><input type="button" value=" L " name="cmdlstCode" disabled onclick="Counter()" class="button"></td>
                          </tr>
                          <tr>
                            <td width="5%" align="right" height="27"><font size="2" face="MS Sans Serif">&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
                            <td width="30%" height="27"><font size="2" face="MS Sans Serif"><input name="txtDesc" size="30" 
                            onblur='Dataarrange(txtDesc)' maxlength="50" onblur="Dataarrange(window.document.frmCounterMst.txtDesc)"></font></td>
                          </tr>
                          <tr>
							<td>&nbsp;</td>
                            <td width="5%" align="left" height="15">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="cmdAddtoGrid" onclick="AddtoGrid()" type="button" value=" Ok " class="button"></td>
                            <td width="57%" height="15"></td>
                          </tr>
                          <tr>
                            <td width="100%" height="15" colspan="2">
                            <p align="center">
     
                      
	<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=113 id=MfgCurrency 
	name=MfgCurrency style="HEIGHT: 113px; LEFT: 0px; TOP: 0px; WIDTH: 361px" width=361>
	<PARAM NAME="_ExtentX" VALUE="9551">
	<PARAM NAME="_ExtentY" VALUE="2990">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="0">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="2">
	<PARAM NAME="ColWidth0" VALUE="2820">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE=" CurrencyCode                      |> Description                                   ">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="9">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="9">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="CurrencyCode">
	<PARAM NAME="TextMatrix0" VALUE="CurrencyCode">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>

                            </td>
                          </tr>
                          <tr>
                            <td width="43%" align="right" height="15"></td>
                            <td width="57%" height="15"></td>
                          </tr>
                        </table>

                        </center>
                      </div>

                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="100%"></td>
                        </tr>
                      </table>

                      </td>
                    </tr>
                  </table>

                  </td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </td>
        </tr>
        <tr>
          <td width="100%" align="middle" height="10"></td>
        </tr>
        <tr>
          <td width="100%" align="middle" height="10">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="26">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="CashMasterfly.aspx">
                                              </iframe>
              </td>
            </tr>
            <tr>
              <td width="100%" height="27"></td>
            </tr>
            <tr>
              <td width="171%" align="middle">
              <div align="center">
                <center>

                <table border="0" width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td width="100%"><input name="cmdOk" onclick="okClick()" 
                    type="button" value="    Ok    " class="button"><input 
                    name="cmdCancel" onclick="window.location.href='cashcountermst.aspx'" 
                    type="button" value="Cancel" class="button"><!--<input name="cmdExit" class="bgcolor" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" type="button" value="   Exit   ">--></td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" height="25"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <input type="hidden" name="status"><input type="hidden" name="hstr">
      <input type="hidden" name="hCur">
      </form>
  </table>

</body>

</html>
