<%@ Page Language="vb"  AspCompat="true" Explicit="false" AutoEventWireup="false" Codebehind="frmcashflow.aspx.vb" Inherits="eSmartDotNet.frmcashflow"%>


<%
    Dim newappdate
    newappdate = Format(DateAdd("d", 0, Session("applicationdate")), "dd-MMM-yyyy")
    
dim strSql, strNftsYn as string
strNftsYn="N"
dim rsNFTS, objNFTS
rsNFTS=server.CreateObject("adodb.recordset")
objNFTS =server.CreateObject("ReportPurposeOnly.Reportonly")
strSql="SELECT NFTSCONVYN FROM GENBANKPARM"
rsNFTS=objNFTS.SingleSelectStat(strSql)
if objNFTS.ConnError<>"Connected" then
	if not rsNFTS.bof and not rsNFTS.eof then
		strNftsYn=rsNFTS(0).value
	end if
end if
%>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="../styletag.css">
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <meta name="GENERATOR" content="Microsoft FrontPage 4.0">
    <meta name="ProgId" content="FrontPage.Editor.Document">
    <script language="javascript" src="<%="http://" & session("moduledir")& "/proc.js"%>"> </script>
    <script language="javascript" src="<%="http://" & session("moduledir")& "/val.js"%>"> </script>
    <script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>"></script>
    <script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>"></script>
    <script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>"></script>
    <script language="JavaScript" src="../val.js"></script>
    
    <script language="javascript">
<!--
    var mode="GlTran"
    var transtr=" "
    var opmode="="	
    //alert('<%=newappdate%>');


function setDates()
{
   window.document.frmtrans.txtFromDate.Value='<%=session("applicationdate")%>'
   window.document.frmtrans.txtToDate.Value='<%=session("applicationdate")%>'

}



var strOpBal

//////// this function is called when refresh button is selected
function Refresh()
{

    //alert("raja")
    ////// if branch code is null
    if(window.document.frmtrans.txtbranchcode.value=="")
    {
        alert("Branch Code should not be null..")
        window.document.frmtrans.txtbranchcode.focus()
        return
    }
    if(window.document.frmtrans.txtcurrencycode.value=="")
    {
        alert("Currency Code should not be null..")
        window.document.frmtrans.txtcurrencycode.focus()
        return
    }
    if(window.document.frmtrans.txtModId.value=="")
    {
        alert("Module Code should not be null..")
        window.document.frmtrans.txtModId.focus()
        return
    }
	
    if(window.document.frmtrans.txtGLCode.value=="")
    {
        alert("GL Code should not be null..")
        window.document.frmtrans.txtGLCode.focus()
        return
    }
	
    
    ///// if date is null
    if(window.document.frmtrans.txtFromDate.value=="")
    {
        alert("From Date should not be null..")
        return
    }
    ///// if date is null
    if(window.document.frmtrans.txtToDate.value=="")
    {
        alert("To Date should not be null..")
        return
    }
	
	

    //alert(transtr)
    
    window.document.frmtrans.mfgDtls.FormatString= transtr
    /////// set the cursor to hour glass
    window.document.frmtrans.style.cursor="wait"
    var fromdate=window.document.frmtrans.txtFromDate.value
    var todate=window.document.frmtrans.txtToDate.value
    var curcode=window.document.frmtrans.txtcurrencycode.value
    var brcode=window.document.frmtrans.txtbranchcode.value
    var glcode=window.document.frmtrans.txtGLCode.value
    var modid=window.document.frmtrans.txtModId.value
    /////////// if pending transactions is selected
    //window.document.frmtrans.mfgDtls.Cols=3
    
    if(window.document.frmtrans.optType(0).checked==true)
    {
        mode="Branchwise"			//// set global mode to Tran
        var st = mode + "|" + brcode+ "|"+ mode + "|" + fromdate + "|" + todate + "|" + glcode + "|" + curcode + "|" + modid
    }
    
    if(window.document.frmtrans.optType(1).checked==true)
    {
        mode="Consolidated"			//// set global mode to Tran
        var st =mode + "|" + brcode+ "|"+ mode + "|" + fromdate + "|" + todate + "|" + glcode + "|" + curcode + "|" + modid
    }
   // alert(st)
    window.document.all['iBatch'].src="frmcashflowtrandtls.aspx?strval=" + st
				
}

///functions for the onblur event
function moduledesc()
{
    if(window.document.frmtrans.txtbranchcode.value=="")
    {
        alert("Branch Code should not be null..")
        window.document.frmtrans.txtbranchcode.focus()
        return
    }
    if(window.document.frmtrans.txtcurrencycode.value=="")
    {
        alert("Currency Code should not be null..")
        window.document.frmtrans.txtcurrencycode.focus()
        return
    }
    if(window.document.frmtrans.txtModId.value=="")
    {
        window.document.frmtrans.txtModDesc.value=""
        window.document.frmtrans.txtGLCode.value=""
        window.document.frmtrans.txtGLDesc.value=""
       
        window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	  
	    return
	}
    var gen="GETMODULEDESC"      			
    var del="|"
    var st=gen+del+window.document.frmtrans.txtbranchcode.value+del+window.document.frmtrans.txtcurrencycode.value+del+window.document.frmtrans.txtModId.value
    //alert(st)	
    //window.open("SBcounter.asp" + "?"+"st="+st,"get",
    //"width=1%,height=1% left=1 top=1")
    window.document.all["iBatch1"].src="../GEN/delmodedisplay.aspx?st="+st
}

function glcodedesc()
{
    if(window.document.frmtrans.txtbranchcode.value=="")
    {
        alert("Branch Code should not be null..")
        window.document.frmtrans.txtbranchcode.focus()
        return
    }
    if(window.document.frmtrans.txtcurrencycode.value=="")
    {
        alert("Currency Code should not be null..")
        window.document.frmtrans.txtcurrencycode.focus()
        return
    }
    if(window.document.frmtrans.txtModId.value=="")
    {
        alert("ModuleId should not be null..")
        window.document.frmtrans.txtGLCode.value=""
        window.document.frmtrans.txtModId.focus()
        return
    }
	
    if(window.document.frmtrans.txtGLCode.value=="")
    {
        window.document.frmtrans.txtGLDesc.value=""
       
        window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	 
	    return
	}
    var gen="GETGLCODEDESC"      			
    var del="|"
    var st=gen+del+window.document.frmtrans.txtbranchcode.value+del+window.document.frmtrans.txtcurrencycode.value+del+window.document.frmtrans.txtModId.value+del+window.document.frmtrans.txtGLCode.value
    //alert(st)	
    //window.open("SBcounter.asp" + "?"+"st="+st,"get",
    //"width=1%,height=1% left=1 top=1")
    window.document.all["iBatch1"].src="../GEN/delmodedisplay.aspx?st="+st
	
}

function moddisplay(str)
{
    //alert(str)
    str=str.split("~")
    //alert(str[0])
    if(str[0]=="GETMODULEDESC")
    {

        if(str[1]=="No")
        {
            alert("No Records Found")
            window.document.frmtrans.txtModId.value=""
            window.document.frmtrans.txtGLCode.value=""
            window.document.frmtrans.txtGLDesc.value=""
            
            window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	   
	    window.document.frmtrans.butmod.focus()
	    return
	}
	else
	{
	    window.document.frmtrans.txtModDesc.value=str[1]
	    window.document.frmtrans.txtGLCode.value=""
	    window.document.frmtrans.txtGLDesc.value=""
	  
	    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	   
	}
}
    if(str[0]=="GETGLCODEDESC")
    {


        if(str[1]=="No")
        {
            alert("No Records Found")
		
            window.document.frmtrans.txtGLCode.value=""
            window.document.frmtrans.txtGLDesc.value=""
           
            window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	 
	    window.document.frmtrans.butgl.focus()
	    return
	}
	else
	{
	    window.document.frmtrans.txtGLDesc.value=str[1]
	   
	    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
	    window.document.frmtrans.mfgDtls.rows=1
	   
	}
}

}

//////////////////////// this function is called from trandtls.aspx to display the detaisl

function DisplayCode(kstr)
{
var DblRcpAmt
var DblPayAmt
DblRcpAmt =0
DblPayAmt = 0
var StrArrFldMain=new String()
var StrArrFld=new String()
var StrArrFlds=new String()

var StrArrFld1=new String()
var StrArrFlds1=new String()

StrArrFldMain=kstr.split("$")
StrArrFld=StrArrFldMain[0].split("|")
    ///// clear flex grid
    window.document.frmtrans.mfgDtls.Rows=1
   
    ////// if data is not returned
    if (kstr=="No Data found")
    {
        alert("No Transactions found.....")
        return
    }
	
 for(icnt=0;icnt<StrArrFld.length-1;icnt++)
        {
        window.document.frmtrans.mfgDtls.rows=window.document.frmtrans.mfgDtls.rows+1
            var StrArrFlds=StrArrFld[icnt].split("~")
			window.document.frmtrans.mfgDtls.textmatrix(icnt+1,0)=Datepick1(StrArrFlds[0])
			window.document.frmtrans.mfgDtls.textmatrix(icnt+1,1)=StrArrFlds[1]
			window.document.frmtrans.mfgDtls.textmatrix(icnt+1,2)= Math.abs(StrArrFlds[2])
			window.document.frmtrans.mfgDtls.textmatrix(icnt+1,3)=StrArrFlds[3]
			window.document.frmtrans.mfgDtls.textmatrix(icnt+1,4)=StrArrFlds[4]
			
			
			DblRcpAmt = parseFloat(DblRcpAmt) + parseFloat(Math.abs(StrArrFlds[2])) 
            DblPayAmt = parseFloat(DblPayAmt) + parseFloat(StrArrFlds[3]) 
		}	
		
		 window.document.frmtrans.mfgDtls.rows = window.document.frmtrans.mfgDtls.rows + 1
		var TempRowIdx = window.document.frmtrans.mfgDtls.rows
		window.document.frmtrans.mfgDtls.Rows= 	window.document.frmtrans.mfgDtls.Rows+3
	
		 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx-1,0)= '------------'
  	 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx-1,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx-1,3)= '---------------'
    
		  window.document.frmtrans.mfgDtls.TextMatrix(TempRowIdx,0) = "Total : "
		  
		   window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx,2)=DblRcpAmt
		    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx,3)=DblPayAmt
		 
		  	 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx+1,0)= '------------'
  	 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx+1,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx+1,3)= '---------------'
		  
		  var DblRcpAmt1
var DblPayAmt1
DblRcpAmt1= 0
DblPayAmt1 = 0
  StrArrFld1=StrArrFldMain[1].split("|")
  window.document.frmtrans.mfgDtls.rows = window.document.frmtrans.mfgDtls.rows + 1

  icnt1=window.document.frmtrans.mfgDtls.rows
 
  	window.document.frmtrans.mfgDtls.Rows= 	window.document.frmtrans.mfgDtls.Rows+5
  		 window.document.frmtrans.mfgDtls.textmatrix(icnt1+1,0)= '------------'
  	 window.document.frmtrans.mfgDtls.textmatrix(icnt1+1,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(icnt1+1,3)= '---------------'
      window.document.frmtrans.mfgDtls.textmatrix(icnt1+1,4)= '---------------'
       window.document.frmtrans.mfgDtls.textmatrix(icnt1+2,0)= 'Moduleid'
  	 window.document.frmtrans.mfgDtls.textmatrix(icnt1+2,2)= 'Receipts'
    window.document.frmtrans.mfgDtls.textmatrix(icnt1+2,3)= 'Payments'
      window.document.frmtrans.mfgDtls.textmatrix(icnt1+2,4)= 'Difference'
              	 window.document.frmtrans.mfgDtls.textmatrix(icnt1+3,0)= '------------'
        	 window.document.frmtrans.mfgDtls.textmatrix(icnt1+3,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(icnt1+3,3)= '---------------'
      window.document.frmtrans.mfgDtls.textmatrix(icnt1+3,4)= '---------------'
      
  	var lntlngth 
  	lntlngth = StrArrFld1.length  -1

  	var introw
  	introw=0
  for(icnt=0;icnt< lntlngth ;icnt++)
        {
    
        window.document.frmtrans.mfgDtls.rows=window.document.frmtrans.mfgDtls.rows+1
        
            var StrArrFlds1=StrArrFld1[icnt].split("~")
           introw = icnt1 + 4  + icnt
		
			window.document.frmtrans.mfgDtls.textmatrix(introw +1,0)=StrArrFlds1[0]
	
			 window.document.frmtrans.mfgDtls.textmatrix(introw+1,2)=Math.abs(StrArrFlds1[1])
			window.document.frmtrans.mfgDtls.textmatrix(introw+1,3)=StrArrFlds1[2]
			window.document.frmtrans.mfgDtls.textmatrix(introw+1,4)=parseFloat(Math.abs(StrArrFlds1[1])) - parseFloat(StrArrFlds1[2])
			
			DblRcpAmt1 = parseFloat(DblRcpAmt1) + parseFloat(Math.abs(StrArrFlds1[1])) 
            DblPayAmt1 = parseFloat(DblPayAmt1) + parseFloat(StrArrFlds1[2]) 
		}	
		
		 window.document.frmtrans.mfgDtls.rows = window.document.frmtrans.mfgDtls.rows + 1
		var TempRowIdx1 = window.document.frmtrans.mfgDtls.rows
		window.document.frmtrans.mfgDtls.Rows=
			window.document.frmtrans.mfgDtls.Rows+3
	
	     	 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1,0)= '------------'
	     	 window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1,3)= '---------------'
      window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1,4)= '---------------'
      
		  window.document.frmtrans.mfgDtls.TextMatrix(TempRowIdx1+1,0) = "Total : "
		  
		   window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+1,2)=DblRcpAmt1
		    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+1,3)=DblPayAmt1
		  window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+1,4)= parseFloat(DblRcpAmt1) - parseFloat(DblPayAmt1)
		  
		  	   window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+2,0)= '------------'
		   window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+2,2)= '---------------'
    window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+2,3)= '---------------'
      window.document.frmtrans.mfgDtls.textmatrix(TempRowIdx1+2,4)= '---------------'
}

function round(number, precision) 
{ 
	var pair = (number + 'e').split('e') 
	var value = Math.round(pair[0] + 'e' + (+pair[1] + precision)) 
	pair = (value + 'e').split('e') 
	return +(pair[0] + 'e' + (+pair[1] - precision)) 
}

////// this function  is called on click of branch list button
function BranchCode()
{
    st="Branch"
    window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
					"DialogWidth:400px;DialogHeight:170px;DialogLeft:180px;DialogTop:190px")
}

/////// to display the selected branch code and narration from list
function Branchid(kstr)
{
    window.document.frmtrans.optType(0).checked=true
    SelectMode()
    /////// if data is returned
    if (kstr!="No Data Found..")
    {
        kstr=kstr.split("-----")			//// split it and display
        window.document.frmtrans.txtbranchcode.value=kstr[1]
        window.document.frmtrans.txtbranchdesc.value=kstr[0]
    }
}


////// this function is called on click of currency list button
function CurrencyCode()
{
    st="Currency"
    window.showModalDialog("../GEN/List.aspx" + "?"+"st="+st,window,"status:no;"+
                    "DialogWidth:400px;DialogHeight:170px;DialogLeft:180px;DialogTop:190px")

}
////// this function is called from list.aspx when currency code is selected
function Currencyid(kstr)
{
    /////// if data is returned
    window.document.frmtrans.optType(0).checked=true
    SelectMode()
    if (kstr!="No Data Found..")
    {
        kstr=kstr.split("-----")			//// split it and display
        window.document.frmtrans.txtcurrencycode.value=kstr[1]
        window.document.frmtrans.txtcurrencydesc.value=kstr[0]
        prn=kstr[2].length-1
        window.document.frmtrans.hpr.value=prn
        p=""
        for(f=1;f<=prn;f++)
        {
            p=p + "0"
        }
        pres= "0." + p 
    }
}

function Module()
{
    var st="CashStModule" + "|"+ window.document.frmtrans.txtbranchcode.value

    window.document.frmtrans.txtGLCode.value=""
    window.document.frmtrans.txtGLDesc.value=""
   
    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
    window.document.frmtrans.mfgDtls.rows=1
   

    window.showModalDialog("../GEN/List.aspx" + "?"+"st="+st,window,"status:no;"+
                    "DialogWidth:400px;DialogHeight:170px;DialogLeft:180px;DialogTop:190px")
}


function ModuleId(kstr)
{
    /////// if data is returned
    if (kstr!="No Data Found..")
    {
        kstr=kstr.split("-----")			//// split it and display
        window.document.frmtrans.txtModId.value=kstr[1]
        window.document.frmtrans.txtModDesc.value=kstr[0]
        window.document.frmtrans.mfgDtls.rows=1
     
    }

}

function SelectMode()
{
    window.document.frmtrans.txtModDesc.value=""
    window.document.frmtrans.txtModId.value=""
    window.document.frmtrans.txtGLCode.value=""
    window.document.frmtrans.txtGLDesc.value=""
    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
 
        window.document.all.divConsol.style.display="block"
       
       
        window.document.frmtrans.mfgDtls.rows=1
        transtr="  App Date              |>  Opening Balance   |>  Receipts                  |>Payments                   |>Closing Balance       "
	
		
 
   
		
    }



//////// this function is called when module id button is selected
function GLCode()
{


    //var st="StGlCode" + "|"+ window.document.frmtrans.txtbranchcode.value
   // var st="StModGlCode"+"|"+window.document.frmtrans.txtbranchcode.value+"|"+
	//window.document.frmtrans.txtModId.value.toUpperCase()
    //alert(st)
   // window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
	//		"DialogWidth:550px;DialogHeight:170px;DialogLeft:180px;DialogTop:190px")
			
	telgl="TellGlaccno";
	brcode=window.document.frmtrans.txtbranchcode.value
	modid=window.document.frmtrans.txtModId.value.toUpperCase()
	kstr=telgl+"|"+modid+"|"+brcode
	
	if(modid!="")
	{
		window.showModalDialog("../gensbca/ListGlQuery.aspx?st="+kstr,window,"status:no;"+
			"DialogWidth:500px;DialogHeight:200px;DialogLeft:190px;DialogTop:200px")
	} 
}


function glaccountid(kstr)
{
	assign(kstr,window.document.frmtrans.txtGLDesc,window.document.frmtrans.txtGLCode)
	
    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
	window.document.frmtrans.txtToDate.value='<%=newappdate%>'
    window.document.frmtrans.mfgDtls.rows=1

}

//////// this fucntion is called from list.aspx when module is is selected
function GlcodeID(kstr)
{
    /////// if data is returned
    if (kstr!="No Data Found..")
    {
        kstr=kstr.split("-----")			//// split it and display
        window.document.frmtrans.txtGLCode.value=kstr[1]
        window.document.frmtrans.txtGLDesc.value=kstr[0]
       	
        window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		window.document.frmtrans.txtToDate.value='<%=newappdate%>'
		window.document.frmtrans.mfgDtls.rows=1
		
	}

}



//////// this function is called when print button is pressed
function Print(strrep)
{
    var StrCol=""
    var StrRow=""
    var StrHead=""
    var StrCols=""
    var StrColRow=""
    mode="GlTran"		
    var appdate='<%=session("applicationdate")%>'

	
	if(window.document.frmtrans.optType(0).checked==true)
	{	
	StrHead="Branch Wise Transactions Between " + window.document.frmtrans.txtFromDate.value + " To " + window.document.frmtrans.txtToDate.value + " ,60,80"			
	}
	else
	{
	StrHead="Consolidated Transactions Between " + window.document.frmtrans.txtFromDate.value + " To " + window.document.frmtrans.txtToDate.value + " ,60,80"
	}
		

	    if(	window.document.frmtrans.mfgDtls.Rows==1)
	        return
	
	    //for(icnt=0; icnt<window.document.frmtrans.mfgDtls.Cols;icnt++)
	    //{
	    StrCol=StrCol+window.document.frmtrans.mfgDtls.textmatrix(0,0)+",12,L"+"~"
	    StrCol=StrCol+window.document.frmtrans.mfgDtls.textmatrix(0,1)+",15,R"+"~"
	    StrCol=StrCol+window.document.frmtrans.mfgDtls.textmatrix(0,2)+",15,R"+"~"
	    StrCol=StrCol+window.document.frmtrans.mfgDtls.textmatrix(0,3)+",15,R"+"~"
	    StrCol=StrCol+window.document.frmtrans.mfgDtls.textmatrix(0,4)+",15,R"+"|"	
	   
	    //}
	    StrCol=StrCol.substr(0,StrCol.length-1) +"|"
	
	    for(icnt=1;icnt<window.document.frmtrans.mfgDtls.Rows;icnt++)
	    {
	        StrCols=""
	        for(jcnt=0;jcnt<window.document.frmtrans.mfgDtls.Cols;jcnt++)
	        {
	            StrCols=StrCols+window.document.frmtrans.mfgDtls.textmatrix(icnt,jcnt)+"~"
	        }
	        StrCols=StrCols.substr(0,StrCols.length-1)
	        StrColRow=StrColRow+StrCols+"|"
	    }
	
	
	

	
	 
	StrColRow=StrColRow.substr(0,StrColRow.length-1)
	StrCol=StrCol+StrColRow
	StrArr=StrHead+"|"+StrCol
	//alert(StrArr)
	window.document.frmtrans.hreport.value=StrArr
	if(strrep=="report")
	{
		window.document.frmtrans.action="http://" + 
		"<%=session("moduledir")%>" +"/reportgridtemplateCashFlow.aspx?strng="+"/CASH/frmcashflow"
    }
    else
    {
		window.document.frmtrans.action="http://" + 
		"<%=session("moduledir")%>" +"/reportgridtemplateXLCashFlow.aspx?strng="+"/CASH/frmcashflow"
	}
        window.document.frmtrans.method="post"
        window.document.frmtrans.submit();
    }




	
    //-->
    </script>

    <script id="clientEventHandlersJS" language="javascript">
    
    ////-----------Date formate start-------------
    
     function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmtrans.txtFromDate.value, "<%=session("applicationdate")%>")
			
			if(intDiff>0)
			{
				alert("Date Should Not be Less Than Application Date.")
				window.document.frmtrans.txtFromDate.value=""
			}
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
    
    
    ////-----------Dtae formate end----------------
<!--

    function dtpFromDate_CloseUp() {chk=1
        ///// clear flex grid
        window.document.frmtrans.mfgDtls.Rows=1
     
        Datepick(window.document.frmtrans.dtpFromDate,window.document.frmtrans.txtFromDate)

        //swetha
        var starchdt='<%=session("archdate")%>'
if(Datecheck1(starchdt,window.document.frmtrans.txtFromDate)==false)
{
    window.document.frmtrans.txtFromDate.value=""
    return
}
    //
 
st=window.document.frmtrans.txtFromDate.value + "|" + "txtFromDate"
window.document.all['iBatch'].src="../GEN/datecheck.aspx?strVal="+st
}

function GetDateDif(kstr,str1)
{

    if(str1=="txtChkDate")
    {
        if (eval(kstr)>0)
        {
            alert("To Date should not be less than From Date")
            window.document.frmtrans.txtToDate.value='<%=newappdate%>'
			return
        }
    }
    if ((eval(kstr)>=0)&&(str1!="txtChkDate"))
    {
        alert("Date should not be greater or equal to application date..")
        if(str1=="txtFromDate")
        {
            //window.document.frmtrans.txtFromDate.value='<%=session("applicationdate")%>'
		    window.document.frmtrans.txtFromDate.value='<%=newappdate%>'
		    window.document.frmtrans.txtToDate.value='<%=newappdate%>'
		}
        if(str1=="txtToDate")
            //window.document.frmtrans.txtToDate.value='<%=session("applicationdate")%>'
		    window.document.frmtrans.txtToDate.value='<%=newappdate%>'
    }
	
    if(chk==1)
        checkDate()
	
}
var chk=0
function checkDate()
{
    chk=0
    st="txtChkDate" + "|" + window.document.frmtrans.txtFromDate.value + "|" + window.document.frmtrans.txtToDate.value 
    window.document.all['iBatch'].src="../GEN/datecheck.aspx?strVal="+st
}

function dtpToDate_CloseUp() 
{
    chk=1
    ///// clear flex grid
    window.document.frmtrans.mfgDtls.Rows=1
  
    Datepick(window.document.frmtrans.dtpToDate,window.document.frmtrans.txtToDate) 
    st=window.document.frmtrans.txtToDate.value + "|" + "txtToDate"
    window.document.all['iBatch'].src="../GEN/datecheck.aspx?strVal="+st
}

//-->
    </script>
    <script id="clientEventHandlersJS" language="javascript">
<!--
    function Datecheck1(fdate,tdate)
    {
        var frdt=fdate
        var todt=tdate.value
        var fmdate=new String()
        var tmdate=new String()
        fmdate=frdt.split("-")
        tmdate=todt.split("-")
        var frmdate=fmdate[0]+""+fmdate[1]+""+fmdate[2]
        var trodate=tmdate[0]+""+tmdate[1]+""+tmdate[2]
        var fromdate=Date.parse(frmdate)
        var todate=Date.parse(trodate)
        var diff=todate-fromdate
        if(eval(diff)<=0)
        {
            alert("From Date Should Be Greater Than " + frdt )
            return false
        }
	
        else
        {
            return true
        }
    }
    //-->
    </script>
    <script language="javascript" for="dtpFromDate" event="CloseUp">
<!--
    dtpFromDate_CloseUp()
    //-->
    </script>
    <script language="javascript" for="dtpToDate" event="CloseUp">
<!--
    dtpToDate_CloseUp()
    //-->
    </script>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);setDates();SelectMode();">
   
    <form name="frmtrans">
    
    <div class="header">
        <table cellpadding="0" cellspacing="0" width="99%">
            <tr>
                <td align="left" class="bankHeaderLogo"></td>
                <td align="right" class="esmartBankerLogo"></td>
            </tr>
        </table>
    </div>
    <div class="menuBar">
    
        <table cellpadding="0" cellspacing="0" width="100%">
            <tr>
				<td width="22%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
                <td width="17%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
                <td width="43%" align="left" height="22" class="subHeader">
                    <h2>Cash Flow</h2></td>
                <td width="50%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
            </tr>
        </table>
    </div>
	<div id="menucontrol"></div>
	
        <table width="100%" class="tablebordermain" cellspacing="0" cellpadding="0">
            <tr>
                <td width="100%">

                    <table border="0" width="100%" cellspacing="0" cellpadding="0">

                        <tr>
                            <td width="780" height="15">
                                <p align="center"><font class="textblue"><%=result%></p>
                                </font></td>
                        </tr>
                        <tr>
                            <td width="100%" height="29">

                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                    <tr class="bgcolor">
                                        <td width="12%" height="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
                                        <td width="38%" height="27">&nbsp;<input name="txtbranchcode" size="9" maxlength="10" readonly class="txtautofill" value="<%=session("branchcode")%>"><input type="button" value=" L " class="button" name="buttbr" onclick="BranchCode()"><input name="txtbranchdesc" size="16" value="<%=session("branchnarration")%>" readonly class="bgcolor1"></td>
                                        <td width="15%" align="right" height="27">Currency Code&nbsp;&nbsp; &nbsp;</td>
                                        <td width="35%" height="27"><input name="txtcurrencycode" maxlength="10" readonly class="txtautofill" value="<%=session("currencycode")%>" size="9"><input type="button" value=" L " class="button" name="buttcur" onclick="CurrencyCode()"><input name="txtcurrencydesc" size="16" value="<%=session("currencynarration")%>" readonly class="bgcolor1"></td>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td width="780" height="13" align="center"></td>
                        </tr>
                        <tr>
                            <td width="100%">
                                <div align="center">
                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" class="tableborder2">
                                        <tr class="bgcolor1">
                                            
                                            <td width="144" align="middle" height="19">
                                                <p align="center"><font class="textblack"><input type="radio"  name="optType" onclick="SelectMode()" checked>&nbsp;Branchwise</font></p>
                                            </td>
                                            <td width="144" align="middle" height="19">
                                                <p align="center"><font class="textblack"><input type="radio"  name="optType" onclick="SelectMode()">&nbsp;Consolidated</font></p>
                                            </td>
                                        </tr>
                                    </table>

                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td width="100%" height="13" align="center">

                                <table border="0" width="100%" cellspacing="0" cellpadding="0" height="91">
                                    <tr>
                                        <td width="100%" height="37">

                                            <center>

            <table width="100%" class="tableborder2" cellspacing="0" cellpadding="0" height="10">
            
              <tr>
                <td width="100%" valign="top" height="10" align="center">
<center>
                <table border="1" width="100%" cellspacing="0" cellpadding="0" height="26">
              <tr>
                    <td width="12%" height="26">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Module ID</td>
                    <td width="38%" height="26"><input name="txtModId" size="17" onblur="moduledesc()" style="TEXT-TRANSFORM: uppercase" onkeypress="Alphanum()" maxlength=6 class="txtautofill"><input type="button" class="button" value=" L " name="butmod" onclick="Module()"><input name="txtModDesc" size="31" readonly class="bgcolor1"></td>
                   <td width="12%" height="26">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GL Code</td>
                    <td width="38%" height="26"><input name="txtGLCode" size="17" onblur="glcodedesc()" style="TEXT-TRANSFORM: uppercase" maxlength=6 onkeypress="Alphanum()" class="txtautofill"><input type="button" class="button" value=" L " name="butgl" onclick="GLCode()" ><input name="txtGLDesc" size="31" readonly class="bgcolor1"></td>
                  
                  </tr>
               
                               
                </table>
    </center>
                </td>
              </tr>
            </table>

            </center>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="100%" height="1">
                                            <div align="center">

                                                <table border="0" width="100%" class="tableborder2" cellspacing="0" cellpadding="0" height="10">
                                                    <tr align="center">
                                                        <td width="12%" valign="middle" height="10" align="left">
														<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From</td>
                                                        <td width="10%" valign="middle" height="10" align="right"><input type="text" name="txtFromDate" size="17" onblur="datecheck(this)" class="bgcolor1" ></td>      
              
									<!---<td width="3%" align="left">
                      <OBJECT classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height=22 id=dtpFromDate name=dtpFromDate 
	style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 21px" width=21 >
	<PARAM NAME="_ExtentX" VALUE="556">
	<PARAM NAME="_ExtentY" VALUE="582">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="CalendarBackColor" VALUE="-2147483643">
	<PARAM NAME="CalendarForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTitleBackColor" VALUE="-2147483633">
	<PARAM NAME="CalendarTitleForeColor" VALUE="-2147483630">
	<PARAM NAME="CalendarTrailingForeColor" VALUE="-2147483631">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="CheckBox" VALUE="-1">
	<PARAM NAME="CustomFormat" VALUE="dd-MMM-yyyy">
	<PARAM NAME="Format" VALUE="3">
	<PARAM NAME="MaxDate" VALUE="12/31/9999">
	<PARAM NAME="MinDate" VALUE="1/1/1601">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="UpDown" VALUE="0">
	<PARAM NAME="WhatsThisHelpID" VALUE="0"></OBJECT>

                      
               </td> --->
               <td width="15%" align="left"> (DDMMYYYY)</td>
              

            </center>
                                                        <td width="15%" valign="middle" height="10" align="left">
                                                        <p align="right">To&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                        <td width="10%" valign="middle" height="10" align="rigt">
<input type="text" name="txtToDate" size="17" onblur="checkDate(datecheck(this))" class="bgcolor1"></td>
											<!--- <td width="3%" align="left">
                                                            <object classid="clsid:81E1CEC6-F2E2-4B1D-B3BD-749F2EC1F0B2" height="22" id="dtpToDate" name="dtpToDate"
                                                                style="HEIGHT: 22px; LEFT: 0px; TOP: 0px; WIDTH: 21px" width="21" >
                                                                <param name="_ExtentX" value="556">
                                                                <param name="_ExtentY" value="582">
                                                                <param name="Enabled" value="-1">
                                                                <param name="CalendarBackColor" value="-2147483643">
                                                                <param name="CalendarForeColor" value="-2147483630">
                                                                <param name="CalendarTitleBackColor" value="-2147483633">
                                                                <param name="CalendarTitleForeColor" value="-2147483630">
                                                                <param name="CalendarTrailingForeColor" value="-2147483631">
                                                                <param name="CausesValidation" value="-1">
                                                                <param name="CheckBox" value="-1">
                                                                <param name="CustomFormat" value="dd-MMM-yyyy">
                                                                <param name="Format" value="3">
                                                                <param name="MaxDate" value="12/31/9999">
                                                                <param name="MinDate" value="1/1/1601">
                                                                <param name="MousePointer" value="0">
                                                                <param name="OLEDropMode" value="0">
                                                                <param name="ToolTipText" value="">
                                                                <param name="UpDown" value="0">
                                                                <param name="WhatsThisHelpID" value="0">
                                                            </object>


														</td> ---->
														<td width="23%" align="left">(DDMMYYYY)</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            </center>
          
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="100%" height="37" align="center">
                                            <table>
                                                <tr>
                                                    <td align="middle">
                                                        <input name="ButOk2" style="HEIGHT: 24px; WIDTH: 62px" type="button" value=" Refresh" class="button" onclick="Refresh()"></td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td width="100%" height="214">
                                <div id="divConsol">
                                    <p align="center">
                                        <object classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height="251" id="mfgDtls"
                                            name="mfgDtls" style="left: 0px; top: 0px" width="90%" VIEWASTEXT>
                                            <param name="_ExtentX" value="14420">
                                            <param name="_ExtentY" value="6641">
                                            <param name="BackColor" value="-2147483643">
                                            <param name="ForeColor" value="-2147483640">
                                            <param name="Enabled" value="-1">
                                            <param name="BackStyle" value="0">
                                            <param name="BorderStyle" value="1">
                                            <param name="AllowBigSelection" value="-1">
                                            <param name="AllowUserResizing" value="1">
                                            <param name="Appearance" value="1">
                                            <param name="BackColorBkg" value="8421504">
                                            <param name="BackColorFixed" value="-2147483633">
                                            <param name="BackColorSel" value="-2147483635">
                                            <param name="CausesValidation" value="-1">
                                            <param name="Cols" value="5">
                                            <param name="ColWidth0" value="1200">
                                            <param name="DrawMode" value="0">
                                            <param name="FillStyle" value="0">
                                            <param name="FixedCols" value="0">
                                            <param name="FixedRows" value="1">
                                            <param name="FocusRect" value="1">
                                            <param name="ForeColorFixed" value="-2147483630">
                                            <param name="ForeColorSel" value="-2147483634">
                                            <param name="FormatString" value="  App Date              |>  Opening Balance   |>  Receipts                  |>Payments                   |>Closing Balance       ">
                                            <param name="GridColor" value="12632256">
                                            <param name="GridColorFixed" value="0">
                                            <param name="GridLines" value="1">
                                            <param name="GridLinesFixed" value="2">
                                            <param name="GridLineWidth" value="1">
                                            <param name="MergeCells" value="0">
                                            <param name="MergeCol0" value="0">
                                            <param name="MergeRow0" value="0">
                                            <param name="MousePointer" value="0">
                                            <param name="OLEDropMode" value="0">
                                            <param name="PictureType" value="0">
                                            <param name="Redraw" value="-1">
                                            <param name="RightToLeft" value="0">
                                            <param name="RowHeightMin" value="0">
                                            <param name="Rows" value="1">
                                            <param name="ScrollBars" value="3">
                                            <param name="ScrollTrack" value="0">
                                            <param name="SelectionMode" value="0">
                                            <param name="TextStyle" value="0">
                                            <param name="TextStyleFixed" value="0">
                                            <param name="ToolTipText" value>
                                            <param name="WhatsThisHelpID" value="0">
                                            <param name="WordWrap" value="0">
                                            <param name="ColAlignment0" value="9">
                                            <param name="ColData0" value="0">
                                            <param name="FixedAlignment0" value="9">
                                            <param name="FontWidth" value="0">
                                            <param name="hWnd" value="0">
                                            <param name="RowData0" value="0">
                                            <param name="RowHeight0" value="240">
                                            <param name="TextArray0" value="Date">
                                            <param name="textmatrix0" value="Date">
                                            <param name="row" value>
                                            <param name="col" value>
                                            <param name="RowSel" value>
                                            <param name="ColSel" value>
                                            <param name="CellBackColor" value>
                                            <param name="CellForeColor" value>
                                        </object>


                                    </p>
                                </div>
                              
                            </td>
                        </tr>
                        <tr>
                            <td width="780" height="1"></td>
                        </tr>
                        <tr>
                            <td width="100%" height="34">

                                <center>
            <table border="0" width="100%" cellspacing="0" cellpadding="0" style="HEIGHT: 30px;" class="tablebordermain">
              <tr>
                <td width="100%" align="middle">

                <!--<input name="ButOk2" style="HEIGHT: 24px; WIDTH: 62px" type="button" value=" Refresh" class="bgcolor" onclick=Refresh()>-->
                <input name="ButOk1" style="HEIGHT: 24px; WIDTH: 62px" type="button" value=" Print  " class="button" onclick=Print('report')><input name="ButOkxl" style="HEIGHT: 24px; WIDTH: 62px" type="button" value=" XLPrint  " class="button" onclick=Print('XLreport')>
                <!--<input type="button" value="XL Report" name="cmdXLreport" onclick="excelParam()" class="button"> ---><input name="ButCancel" onclick="    location.reload() " style="HEIGHT: 24px; WIDTH: 61px" type="button" value=" Cancel " class="button"><input name="ButExit" class="button" onclick="    window.location.href=&quot;http://<%=session("moduledir") & "/" & session("module") & "/" & session("module") & "module.aspx"%>    &quot;" style="HEIGHT: 24px; WIDTH: 61px" type="button" value=" Exit "></td>
              </tr>
            </table>

            </center>

                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
        </table>
        <iframe id="iBatch" align="center"
            frameborder="0" framespacing="0" noresize
            valign="top" src="frmcashflowtrandtls.aspx"
            style="BACKGROUND-COLOR: darkred; HEIGHT: 0x; WIDTH: 0px"></iframe>
        <iframe id="iBatch1" align="center"
            frameborder="0" framespacing="0" noresize
            valign="top"
            style="BACKGROUND-COLOR: darkred; HEIGHT: 1x; WIDTH: 0px"></iframe>
        <iframe id="iAccDet" align="center"
            frameborder="0" framespacing="0"
            height="0" width="0" src="reportdisplay.aspx"></iframe>
        <input type="hidden" name="hpr" value="<%=session("precision")%>">
        <input type="hidden" id="txtPrecision">
        <input type="hidden" name="colcnt"><input type="hidden" name="status">
        <input type="hidden" name="secdtls"><input type="hidden" name="seccols">
        <input type="hidden" name="txtcode"><input type="hidden" name="brcode">
        <input type="hidden" name="curcode">
        <input type="hidden" name="hreport">
		<input type="hidden" name="reptitle">
		<input type="hidden" name="reptype">
		<input type="hidden" name="hRepInfo">
        
    </form>
    <div class="footer">
        <div class="logo"></div>
        <div class="copyRight">
            &copy; E-Smart Banker - A Product of SAS Enterprises
        </div>
    </div>
</body>

</html>
