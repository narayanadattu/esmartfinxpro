<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="masterdenom1.aspx.vb" Inherits="eSmartDotNet.masterdenom1"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
function CashMultiply(Note,Rs,Av,Amt,NoteType)
{

if(NoteType=="CP")
{

Note="0."+Note	
}
 var i,T
   if (Rs.value=="")
  {
     Amt.value="0.00"
     total()
  }
  else
  {
 
   if(eval(Rs.value)<=eval(Av.value))
    {
		Amt.value=eval(Note)* eval(Rs.value)
	
		total()
	}
	else
	{
	   alert("Should not allot more than Available Pieces")
	   Rs.value=""
	   Amt.value="0.00"
	   total()
	}	
  }
    
}

//-->
</SCRIPT>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=vbscript>
sub total()
dim i,k
dim c
    Cnt=window.document.frmdm.hcnt.value
    frm=window.document.frmdm.hfrm.value
    
     k = 0
    if cnt>1 then
		for i=0 to cnt-1
			 k=cdbl(k) + cdbl(window.document.frmdm.txtamt(i).value)
		next
	else
		for i=0 to cnt-1
			 k=cdbl(k) + cdbl(window.document.frmdm.txtamt.value)
		next
	end if
	window.parent.window.document.forms(frm).txttotal.value=0 
	window.parent.window.document.forms(frm).txttotal.value=k 
	call precision(window.parent.window.document.forms(frm).txttotal,window.document.frmdm.hpr.value)
	   
end sub

</SCRIPT>

<%
	Dim obj,st,kstr,d
	kstr=Request.Form("hdenom")
	k=split(kstr,"|")	
	userid=session("userid")
	   
%>
<title></title>
</head>
<body topmargin="0" leftmargin="0">

<form name="frmdm">
 	<%
 	Dim obj1
	if len(kstr)>0 then
		 obj=server.CreateObject("cashquery.queries")
		if Ucase(k(1))="CASHVAULTMST" then
		
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)))
		else
		 rs=server.CreateObject("adodb.recordset")
		 rsTot=server.CreateObject("adodb.recordset")
		 objcou=server.CreateObject("queryrecordsets.fetchrecordsets")
		 rs=objcou.singlerecordset("cashcountermst","counterno", _
		"branchcode='" & k(2) & "' and currencycode='" & k(3) & "' and " & _
		"cashierid ='" & ucase(userid) & "'")
		'response.write("branchcode='" & k(2) & "' and currencycode='" & k(3) & "' and cashierid ='" & ucase(userid) & "'")
		'response.end
			if rs.EOF<>true and rs.BOF<> true then
				countno=rs(0).value
				 objcou=nothing
			end if
			
			st=obj.CashDenominationsAsarray(cstr(k(1)),cstr(k(2)),cstr(k(3)), _
			cstr(session("Applicationdate")),cstr(userid),cstr(countno))
			
			if trim(st(0,0))=trim("No Cash for this cashier") then 
				Dim amt1,amt2,amt3
				rs=nothing
				obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
				rs=obj1.singlerecordset("cashcashierposmst","totamount", _
				"BRANCHCODE='" & k(2) & "' AND CURRENCYCODE='" & k(3) & "' AND " & _
				"CASHIERID='" & Ucase(userid) & "' AND COUNTERNO='" & countno & "'")
				if rs.EOF<>true and rs.BOF<> true then
					amt1=rs(0).value
				end if
				rs=nothing
				rs=obj1.Singlerecordset("CASHTRANSBTCASHIERSTRN","amount", _
				"BRANCHCODE='" & k(2) & "' and CURRENCYCODE='" & k(3) & "' and " & _
				"FromCashierid='" & UCASE(USERID) & "' and status='P'")
				if not rs.eof and not rs.bof then
				do until rs.EOF
					amt2=amt2+rs(0).value
					rs.movenext
				loop
				end if
				amt1=amt1-amt2
				rs=nothing
				rs=obj1.Singlerecordset("CASHREFUNDSTRN","Refundamount", _
				"BRANCHCODE='" & k(2) & "' and CURRENCYCODE='" & k(3) & "' and " & _
				"counterno='" & countno & "' and status='P'")
				if not rs.eof and not rs.bof then
				do until rs.EOF
					amt3=amt3+rs(0).value
					rs.movenext
				loop
				end if	
				amt1=amt1-amt3
				cnt=amt1
			end if
		 obj=nothing
	    end if
	    tval=k(3)
	if ubound(st)>0 then    
	    	    	
   %>
  <%
  rcount=0
 	FOR i=0 TO ubound(st)
 		if st(i,0)<>"" then
 		rcount=rcount+1
 		end if
 	next
 	if rcount<2 then
 		varst="SINGLE"
 	end if
 	dim ind  ',cnt
 	for j=0 to ubound(st)
 	if st(j,0)="CP" then
 	   ind=ind+1
 	end if
 	next
 	m=0
 	
 	'pr=len(st(1,3))-1
 	pr=session("PRECISION")
 	
 	%>
 	<center>
  <table border="1" cellspacing="0" cellpadding="0" width="310">
    <tr class="bgcolor" valign="top">
      <td height="10" align="center" valign="top"><font class="textbold">Notes</font></td>
      <td height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
    </tr>
    <input type="hidden" name="hpr" value="<%=pr%>"><input type="hidden" name="hfrm" 
    value="<%=k(0)%>">
   	 <%c =  0 %>
    <%
  FOR i=0 TO ubound(st)%>
    <%if st(i,1)<>"" then%>
 	  <%cnt=cnt+1
 	  cal=st(i,3)
	  p=len(cal)-1
	 
	  %>
	 <%if ((st(i,0)="CF" and c = 0) or (st(i,0)="CP" and c = 0)) then 
        c = 1
        
        %>
        
    <tr class="bgcolor">
      <td height="10" align="center" valign="top"><font 
      class="textbold">Coins</font></td>
      <td height="10" align="center" valign="top">&nbsp;</td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
      <td width="90" height="10" align="center" valign="top"></td>
    </tr>
    <%end if%>	
    <tr align="center">
      <td width="90" height="10" align="right" valign="top">
		<%=st(i,1)%></td>
      <input type="hidden" name="hps" value="<%=st(i,1)%>">
      <td width="90" height="10" align="right" valign="top">
		<%=st(i,2)%><input type="hidden" name="htype" value="<%=st(i,0)%>"></td>
      <input type="hidden" name="havail" value="<%=st(i,2)%>">
      <td width="26" height="10" valign="top">*</td>
	   <% if st(i,0)="CP" then
	    
			  cal=st(i,3)
			  p=len(cal)-1
			 ' amt=st(i,1)/cal
			  amt=st(i,1)
			 ' Response.Write (amt)
			 ' Response.Write (st(i,2))
			' Response.Write  ( st(i,1)  &"|"&  st(i,2)  & "<br>")
			 'Response.Write (cdbl(amt))
	          Tot=cdbl("." &amt)*cdbl(st(i,2))
	       'Response.Write (Tot)
	          Avtot=cdbl(Avtot)+cdbl(Tot)
	          
	    %>
      <input type="hidden" name="hamt" value="<%=amt%>"> 
					<%if ind>1 then	%>	
		<%
	    if varst="SINGLE" then
	   
	    %>
	  
	     <td width="50" valign="top"><input type="text" id="txtpieces" 
      name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; 
      text-align:right" size="6" 
      onkeypress="numeric()" 
      onkeyup="CashMultiply(window.document.frmdm.hamt.value,
      window.document.frmdm.txtpieces,
      window.document.frmdm.havail,
      window.document.frmdm.txtamt,&quot;CP&quot;);
      precision(window.document.frmdm.txtamt,<%=p%>);"></td>
	    <%
	    else
	    %>			
      <td width="50" valign="top"><input type="text" id="txtpieces" 
      name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; 
      text-align:right" size="6" 
      onkeypress="numeric()" 
      onkeyup="CashMultiply(window.document.frmdm.hamt(<%=m%>).value,
      window.document.frmdm.txtpieces(<%=i%>),
      window.document.frmdm.havail(<%=i%>),
      window.document.frmdm.txtamt(<%=i%>),&quot;CP&quot;);
      precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></td>
     <%
     end if
     %> 
					  <%m=m+1
					 else%>
						<%
							if varst="SINGLE" then
						 %>	
						 
							<td width="50" valign="top"><input type="text" id="txtpieces" 
							name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" 
							size="6" onkeypress="numeric()" 
							onkeyup="CashMultiply(window.document.frmdm.hamt.value,
							window.document.frmdm.txtpieces,
							window.document.frmdm.havail,
							window.document.frmdm.txtamt,&quot;<%=st(i,0)%>&quot;);
							precision(window.document.frmdm.txtamt,<%=p%>)"></td>
						 <%
						 else
						 %>				 
							<td width="50" valign="top"><input type="text" id="txtpieces" 
							name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" 
							size="6" onkeypress="numeric()" 
							onkeyup="CashMultiply(window.document.frmdm.hamt.value,
							window.document.frmdm.txtpieces(<%=i%>),
							window.document.frmdm.havail(<%=i%>),
							window.document.frmdm.txtamt(<%=i%>),&quot;<%=st(i,0)%>&quot;);
							precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></td>
						<%end if%>
					<%end if %>
		<%else
		
		%>
		<%
		
		  Tot=cdbl(st(i,1))*cdbl(st(i,2))
		  
	      Avtot=cdbl(Avtot)+cdbl(Tot)
	    %>
	    <%
	    if varst="SINGLE" then
	 
	    %>
	  
	    <td width="50" valign="top"><input type="text" id="txtpieces" 
      name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" 
      size="6" onkeypress="numeric()" 
      onkeyup="CashMultiply(window.document.frmdm.hps.value,
      window.document.frmdm.txtpieces,
      window.document.frmdm.havail,
      window.document.frmdm.txtamt);
      precision(window.document.frmdm.txtamt,<%=p%>),&quot;<%=st(i,0)%>&quot;
      precision(window.parent.window.document.forms(frm).txttotal,<%=p%>)"></td>
      
	    <%
	    else
	    
	    %>
      <td width="50" valign="top"><input type="text" id="txtpieces" 
      name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; text-align:right" 
      size="6" onkeypress="numeric()" 
      onkeyup="CashMultiply(window.document.frmdm.hps(<%=i%>).value,
      window.document.frmdm.txtpieces(<%=i%>),
      window.document.frmdm.havail(<%=i%>),
      window.document.frmdm.txtamt(<%=i%>));
      precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>),&quot;<%=st(i,0)%>&quot;"></td>
		<%end if
		end if%>
		
      <td width="31" height="10" align="center" valign="top">=</td>
				 
      <td width="71" valign="top"><input type="text" id="txtamt" name="txtamt" 
      value="0.00" style="FONT-SIZE: x-small; HEIGHT: 18px ;text-align:right" 
      size="9" disabled></td>
      <%end if%>
    </tr>
  
	<%next %>
	<%'Finamount=cdbl(Avtot)+cdbl(cAvtot)%>
	<%'=Finamount%>
	
	<%  
	'response.write("Avtot=" & Avtot & "<br>")
	'response.write("cnt=" & cnt & "<br>")
	'response.end  %>
	
	<%
		''mahender for total cash
			
			dim CashTot,DifTot
			
			CashTot = ""
			
			if k(0) = "frmrefund" then
			
				objTot=server.CreateObject("queryrecordsets.fetchrecordsets")
				rsTot=objTot.singlerecordset("cashcashierposmst","totamount", _
				"BRANCHCODE='" & k(2) & "' AND CURRENCYCODE='" & k(3) & "' AND " & _
				"CASHIERID='" & Ucase(userid) & "' AND COUNTERNO='" & countno & "'")
				if rsTot.EOF<>true and rsTot.BOF<> true then
					CashTot = rsTot(0).value
				end if
				rs=nothing
				
				DifTot = cdbl(CashTot)-cdbl(Avtot)
			
			end if
			''mahender end
	
	%>
	
	<% if len(trim(Avtot ))> 0 then
	
	  Response.Write ("<script language=vbscript>")
	  Response.Write ("window.parent.window.document.forms(frm).txtavtotal.value=" & Avtot & chr(13))
	  Response.Write ("window.parent.window.document.forms(frm).txtctotal.value=" & Avtot & chr(13))
	  Response.Write ("window.parent.window.document.forms(frm).hpr.value=" & p & chr(13))
	 
      Response.Write ("call precision(window.parent.window.document.forms(frm).txtavtotal,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
      Response.Write ("call precision(window.parent.window.document.forms(frm).txtctotal,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
     
      Response.Write ("call precision(window.parent.window.document.forms(frm).txttotal,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
      
		if k(0) = "frmrefund" then
				Response.Write ("window.parent.window.document.forms(frm).txtCaTot.value=" & CashTot & chr(13))
				Response.Write ("window.parent.window.document.forms(frm).txtDiffTot.value=" & DifTot & chr(13))
				Response.Write ("call precision(window.parent.window.document.forms(frm).txtCaTot,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
				Response.Write ("call precision(window.parent.window.document.forms(frm).txtDiffTot,window.parent.window.document.forms(frm).hpr.value)" & chr(13))
		  
		end if
      Response.Write ("</script>" )
      end if%>
  </table>
</center>
  <%else 
        Response.Write ("<table>")
        Response.Write("<tr>")
        Response.Write("<td>")
        'Response.Write"<font size=+1 color=blue>"
		Response.Write (st(0,0) )
		'Response.Write"</font>"	
		Response.Write("</td>")
		Response.Write("</tr>")
		Response.Write("</table>")
		Response.write ("<script language=vbscript>")
		Response.Write ("window.parent.window.document.forms(frm).txtavtotal.value=" & cnt & chr(13))
		Response.Write ("window.parent.window.document.forms(frm).txtctotal.value=" & cnt & chr(13))
		Response.Write ("call precision(window.parent.window.document.forms(frm).txtctotal,2)" & chr(13))
		Response.Write ("call precision(window.parent.window.document.forms(frm).txtavtotal,2)" & chr(13))
		Response.Write ("</script>" )
		
		
     end if%>
  <% end if%>
  <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" id="hspr" name="hspr"><input type="hidden" name="hcnt" value="<%=cnt%>">
  
  
</form>

</body>

</html>
