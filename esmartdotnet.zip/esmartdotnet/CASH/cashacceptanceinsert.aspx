<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashacceptanceinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashacceptanceinsert" %>
<%
	DIM OBJ 'object variables
	dim strmsg
	Dim  ArrTran(0,4)
	dim brcode,crcode,allotedcashid,counterno,allotment,status 'to store textbox values
		status=trim(Request.Form("hStatus"))
		brcode=trim(Request.Form("txtbranchcode"))
		crcode=trim(Request.Form("txtcurrencycode"))
		allotedcashid=ucase(trim(Request.Form("txtcashcode")))
		acceptedcashid=session("userid")
		Response.Write (session("counterno"))
		allotment=trim(Request.Form("txtallotment"))
		counterno=trim(session("counterno"))
		
		'''****** for updating assigning the values to variables
		StrTabName="CASHALLOTMENTSTRN"
		StrFldNames="status"
		StrUpFldvalues="'J'" ' "'R'"
		strCondition="branchcode='" & Brcode & "' and currencycode='" & Crcode & "' and " & _
					"ALLOTMENTNO='" & allotment & "' and CashierId='" & session("userid") & "'"
		
	if len(brcode)>0 and len(crcode)>0 and len(allotedcashid)>0 and len(allotment)>0 then
		if Status="ACCEPT" then	
			
			 Obj=SERVER.CreateObject("CashTransaction.Transactions")
			   strmsg=Obj.CashAllotAcceptance(cstr(brcode),cstr(crcode), _
			   cstr(session("Applicationdate")),cstr(allotedcashid), _
			   cstr(acceptedcashid),cstr(allotment),cstr(session("MachineID")), _
			   cstr(counterno))
			   
		 elseif Status="REJECT" then	
			 Obj=SERVER.CreateObject("GeneralTransactions.DBTransactions")
			
			ArrTran(0,0)="U"			'passing the TransactionType
			ArrTran(0,1)=StrTabName		'passing the tablename
			ArrTran(0,2)=StrFldNames	'passing the FieldNames
			ArrTran(0,3)=StrUpFldvalues	'passing the Fieldvalues
			ArrTran(0,4)=strCondition	'passing the Fieldvalues
			Strmsg= Obj.DataTransactions(ArrTran)
			
		end if	
		
		 Obj=nothing
		strmsg = replace(strmsg,chr(13),"")	
		strmsg = replace(strmsg,chr(10),"")	
		Response.Redirect ("cashacceptance.aspx?record=" & strmsg)
			
	else	
		Response.Redirect ("cashacceptance.aspx?record=Fields Should Not be Null.")
			
	end if	
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
