<%@ Page Language="vb" CodeBehind="chkmodule.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.chkmodule" %>

<SCRIPT LANGUAGE=javascript>
<!--
function dayBeginClick()
{
sCnt=window.document.frmmodule.hCount.value
sMod=window.document.frmmodule.hMod.value
st=sMod
location.href="DayBegin.asp?str="+st
}
function disp(vmod)
{
	window.document.frmmodule.hMod.value=vmod
	window.document.frmmenu.action="menutrans.asp"
	window.document.frmmenu.method="post"
	window.document.frmmenu.submit();
}	

//-->
</SCRIPT>




<%
  k=Request.QueryString("record")
''Response.Write k
  mname=split(k,"|")
  
  'Response.Write session("userid")&"<br>"
  'Response.Write session("applicationdate")&"<br>"
  'Response.Write session("machineid")
%>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>



<title>New Page 1</title>
</head>
<body topmargin="0" leftmargin="0" background="cutimages/moduleimg1.jpg">

<form name="frmmodule">

  <table width="100%" border="0" cellspacing="1" cellpadding="1">
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>
  </table>

  <%if len(k)>0 then%>
  <div align="center">
    <center>

    <table width="98%" align="right" cellspacing="1" cellpadding="1">
		<tr>
        <td><input type="button" name="cmdDayBegin" value="    Day Begin     " size="10" onclick='dayBeginClick()'></td>
      </tr>
	  <% j=0
	    
	  
	  for i=0 to ubound(mname)-1
	  fname=split(mname(i),":")
	  
	   frm=lcase(fname(0))&"module.asp"
	   
	   flen=len(fname(0))
	   p=(10-cint(flen))/2
	   w=p*3
	   if fname(1)="T" then
	  
	  %>
	   <% j=1
	     strMod=strMod & fname(0) & "|" %> 
      <tr>
        <td><input type="button" name="buttform" disabled=true value="<%=space(w)%><%=fname(0)%><%=space(w)%>" size="10" onclick=disp(this.value)></td>
      </tr>
	  <%
	  else%>
	 
	  <tr>
        <td><input type="button" name="buttform"   value="<%=space(w)%><%=fname(0)%><%=space(w)%>" size="10" onclick="location.href=&quot;<%=frm%>&quot;"></td>
      </tr>
	  <%
	  end if
	
	  next

	  
	  %>
	  <% if j=1 then %>
	  
	  <tr>
        <td><input type="button" name="cmdDayEnd" disabled=true value="    Day End         " size="10" onclick="location.href=DayBegin.asp"></td>
      </tr>
      <% else %>
      <tr>
        <td><input type="button" name="cmdDayEnd" value="    Day End         " size="10" onclick="location.href=DayBegin.asp"></td>
      </tr>
      <% end if %>
      
    </table>
	<input type="hidden" name="hCount" value=<%=ubound(mname)%>>
	<input type="hidden" name="hMod" value=<%=strMod%>>
    </center>
  </div>
  <%end if%>
</form>

</body>

</html>
