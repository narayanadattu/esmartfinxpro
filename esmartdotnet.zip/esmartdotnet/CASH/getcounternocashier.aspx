<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="getcounternocashier.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.getcounternocashier" %>
<%
''kstr=Request.QueryString("st")
kstr=Request.Form("hFlds")
%>

<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="proc.js">
</SCRIPT>
<SCRIPT LANGUAGE="javascript">
<!--
function List()
{
var stri

	stri=window.document.frmacc.hbno.value
	//checking if values is there in stri then only execute this belowed functions 
if(stri)
	{
	type="<%=kstr%>"
	
	if (type.substring(0,7)=="Cashier")
		{
			window.attachEvent(window.parent.Allotcashierid(stri))
			window.close()
		}
	else if(type.substring(0,7)=="Counter")
		{
			window.attachEvent(window.parent.Allotcounterno(stri))
			window.close()
		}
	 else if(type.substring(0,8)=="Countacc")
		{
			window.attachEvent(window.parent.Allotcounteraccno(stri))
			window.close()
		}
	else if(type.substring(0,7)=="Cashacc")
		{
			window.attachEvent(window.parent.Allotcashieraccno(stri))
			window.close()
		}
	else if(type.substring(0,10)=="refCashier")
		{
			window.attachEvent(window.parent.Allotcashierid(stri))
			window.close()
		}
		
	else if(type.substring(0,10)=="refCounter")
		{
			window.attachEvent(window.parent.Allotcounterid(stri))
			window.close()
		}
	else if(type.substring(0,9)=="Getamount")
		{
			window.attachEvent(window.parent.Amount(stri))
			window.close()
		}	
	else if(type.substring(0,8)=="refundno")
		{
			window.attachEvent(window.parent.Allotrefundamount(stri))
			window.close()
		}
	///for description displaying
	else if((type.substring(0,11)=="DescDisplay")||(type.substring(0,11)=="AmountCheck"))
		{
			window.attachEvent(window.parent.DescDisplay(stri))
			window.close()
		}	
}						
}
//-->
</SCRIPT>

<%
''' if value is there in hiddenfields named hbno
if len(kstr)> 0 then
 
  dim rs,obj
  counterno=""
   rs=server.CreateObject("adodb.recordset")
   obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  
  ''''for fetching counterno  for selected cashier in cashtransferallotment form 
  if left(kstr,7)="Counter" then
			st=split(kstr,"*")
			 rs=obj.singleRecordSet("CASHCOUNTERMST","counterno", _
			"branchcode='" & st(1) & "' and currencycode='" & st(2) & "' and " & _
			 "cashierid='" & ucase(trim(st(3))) & "'","counterno")
			if not rs.EOF and not rs.bof then
					 counterno=rs(0).value
			end if
''''for fetching cashier,description   for selected counterno cashtransferallotment form 				
  elseif  left(kstr,7)="Cashier" then
			        st=split(kstr,"*")
				  	 rs=obj.singleRecordSet("CASHCOUNTERMST cash,genusermst gen", _
				  	"cash.cashierid,gen.name","cash.cashierid=gen.userid and " & _
				  	"cash.branchcode='" & st(1) &   "' and " & _
				  	"cash.currencycode='" & st(2) &   "' and " & _
				  	"cash.counterno='" & st(3) &   "'","cash.cashierid")
					if not rs.EOF and not rs.bof then
					rs.MoveFirst
					for i=0 to rs.Fields.Count - 1
						  counterno=counterno &"*"& rs(i).value
					next
					end if
					
	 elseif  left(kstr,7)="Cashacc" then
		   st=split(kstr,"*")
	        rs=obj.singleRecordSet("CASHTRANSBTCASHIERSTRN cash,genusermst gen","cash.fromcashierid,gen.name","cash.fromcashierid=gen.userid and cash.branchcode='" & st(1) &   "' and cash.currencycode='" & st(2) &   "' and cash.fromcounterno='" & st(3) & "' and cash.status='P'","cash.fromcashierid")
					if not rs.EOF and not rs.bof then
					rs.MoveFirst
					for i=0 to rs.Fields.Count - 1
						  counterno=counterno &"*"& rs(i).value
					next
					end if				
   elseif  left(kstr,8)="Countacc" then
      				 st=split(kstr,"*")
      				 
				 rs=obj.singleRecordSet("CASHTRANSBTCASHIERSTRN","FROMcounterno","branchcode='" & st(1) &   "' and currencycode='" & st(2) &   "' and FROMcashierid='" & st(3) &   "' and status='P'","FROMcounterno")
					if not rs.EOF and not rs.bof then
						counterno=rs(0).value
					end if			
	elseif  left(kstr,10)="refCashier" then
					 st=split(kstr,"*")				   
					 rs=obj.singleRecordSet("cashrefundstrn","counterno","branchcode='" & st(1) &   "' and currencycode='" & st(2) &   "' and cashierid='" & st(3) &   "' and status='P'")
					if not rs.EOF and not rs.bof then					
					for i=0 to rs.Fields.Count - 1
						  counterno=counterno &"*"& rs(i).value
					next
					end if							
	elseif  left(kstr,10)="refCounter" then
					 st=split(kstr,"*")				   
					 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen","distinct(cash.cashierid),gen.name","cash.branchcode='" & st(1) & "' and cash.currencycode='" & st(2) & "' and cash.cashierid=gen.userid and cash.counterno=" & st(3) & " ")	
					if not rs.EOF and not rs.bof then					
					for i=0 to rs.Fields.Count - 1
						  counterno=counterno &"*"& rs(i).value
					next
					end if
	elseif  left(kstr,9)="Getamount" then
					 st=split(kstr,"*")				   
					 rs=obj.singlerecordset("CASHTRANSBTCASHIERSTRN","amount","branchcode='" & st(1) &   "' and currencycode='" & st(2) &   "' and FROMcashierid='" & st(3) &   "' and fromcounterno='" & st(4) & "' and cashtransferno='" & st(5)  & "' and status='P'","amount")
					if not rs.EOF and not rs.bof then					
					  counterno=rs(0).value
					end if							
	elseif  left(kstr,8)="refundno" then
					 st=split(kstr,"*")				   
					 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen","cash.refundamount","cash.branchcode='" & st(1) & "' and cash.currencycode='" & st(2) & "' and cash.cashierid=gen.userid and cash.counterno=" & st(3) & " and cash.refundno=" & st(4) & " ")	
					if not rs.EOF and not rs.bof then					
					for i=0 to rs.Fields.Count - 1
						  counterno=counterno &"*"& rs(i).value
					next
					end if	
'''for description fetching 					
elseif 	left(kstr,11)="DescDisplay" then
	strFlds=split(kstr,"*")
	 Rs=Obj.SingleRecordset(cstr(strFlds(1)),cstr(strFlds(2)),cstr(strFlds(3)))
				if not Rs.BOF or not Rs.EOF then
					for i=0 to Rs.Fields.Count-1
						counterno=counterno &  rs(i).value & "|"
					next
				else
				counterno= "No|"	
				end if
				counterno=counterno & "~" & strFlds(4)	

elseif left(kstr,11)="AmountCheck" then
StrmainFld=split(kstr,"~")
 ObjCheckMaxAmt=server.CreateObject("Cashquery.queries")
 strcheckAmt=ObjCheckMaxAmt.CheckCashLimit(cstr(StrmainFld(1)), _
				cstr(StrmainFld(2)),session("applicationdate"),cstr(StrmainFld(3)), _
                                cstr(StrmainFld(4)),cdbl(StrmainFld(5)))
   counterno= strcheckAmt
  
		counterno=counterno & "~" & StrmainFld(6)
			
end if											
					
 Response.Write (counterno)
   obj=nothing
end if

%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=counterno%>">
  <input type="hidden" id="hFlds" name="hFlds"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
