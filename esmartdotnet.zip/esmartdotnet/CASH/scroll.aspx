<%@ Page CodeBehind="scroll.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.scroll" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Reports</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<script language=javascript>
var st

function branch()
{   
	st="Branch"
	window.open("List.asp" + "?"+"st="+st,st,"width=213%,height=150%,left=120,top=135")
}
function currency()
{  
	 st="Currency"
	 window.open("List.asp" + "?"+"st="+st,st,"width=220%,height=150%,left=510,top=210")
}

function Branchid(str)
{ 
    assign(str,window.document.frmreports.txtbranchdesc,window.document.frmreports.txtbranchcode)
} 
function Currencyid(str)
{
	assign(str,window.document.frmreports.txtcurrencydesc,window.document.frmreports.txtcurrencycode)
		
} 	

function insert()
{   if((window.document.frmreports.txtfromdate.value.length>1) &&(window.document.frmreports.txtfromdate.value.length>1))
    {
		window.document.frmreports.action="cashreport.asp"
		window.document.frmreports.method="post"
		window.document.frmreports.submit()
	}
	else
	{
		alert("Dates should not be Empty")
	}	
}
</script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function Dtpfrom_Change()
{
	Datepick(window.document.frmreports.Dtpfrom,window.document.frmreports.txtfromdate)
}

function DtpTo_Change()
{
	Datepick(window.document.frmreports.DtpTo,window.document.frmreports.txttodate)
}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=Dtpfrom EVENT=Change>
<!--
 Dtpfrom_Change()
//-->
</SCRIPT>


<SCRIPT LANGUAGE=javascript FOR=DtpTo EVENT=Change>
<!--
 DtpTo_Change()
//-->
</SCRIPT>
</head>
<body bgcolor="#c7ba95" topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Disp()">

<%appdate=formatdatetime(session("applicationdate"),1)%>

<form name="frmreports">

  <table width="100%" cellspacing="0" cellpadding="0" height="480" class="tablebordermain">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="11%"></td>
          <td width="89%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%"><img border="0" height="22" name="placeholder" src="file://Comsvr/C/SB/dscript42/transparent.gif" width="1"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25"></td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Scroll</font></td>
          <td width="33%" height="25" align="right"><font class="textwhite"><%=APPDATE%></font></td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="15">
          <p align="center"></td>
        <tr>
          <td width="100%" height="20">

          <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
            <tr class="bgcolor1">
              <td width="52%" height="20" align="right"><font class="textbold">&nbsp;<input type="radio" value="cash" id="Rdcash" checked name="Rdcash">CASH&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
              <td width="52%" height="20">
              <p align="left"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="cashier" id="Rdcash" name="Rdcash">CASHIER</font></p>
              </td>
            </tr>
          </table>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="105"><b><font color="#ffffff" size="2" face="MS Sans Serif">&nbsp;
                  </font><font color="#ffffff" face="MS Sans Serif" size="1">Branch Code</font><font color="#ffffff" size="2" face="MS Sans Serif">&nbsp;</font></b></td>
                  <td width="231"><font size="2" face="MS Sans Serif"><input name="txtbranchcode" size="9" style="TEXT-ALIGN: right" readonly value="<%=session("branchcode")%>"><input type="button" value=" L " name="buttbr" onclick="branch()"><input name="txtbranchdesc" size="14" readonly value="<%=session("branchnarration")%>"></font></td>
                  <td align="right" width="178"><b><font color="#ffffff" face="MS Sans Serif" size="1">Currency
                  Code</font><font color="#ffffff" size="2" face="MS Sans Serif">&nbsp;&nbsp;</font></b></td>
                  <td align="right" width="300"><font size="2" face="MS Sans Serif"><input name="txtcurrencycode" size="9" readonly value="<%=session("currencycode")%>"><input type="button" value=" L " name="butcur" onclick="currency()"><input name="txtcurrencydesc" size="16" readonly value="<%=session("currencynarration")%>"></font></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </td>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="20" colspan="7">

          <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
            <tr class="bgcolor1">
              <td width="50%">
              <p align="right"><font class="textbold"><input type="radio" value="Payments" checked name="Rdpay">Payment&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
              <td width="50%"><font class="textbold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <input type="radio" value="Receipts" name="Rdpay">Receipt</font></td>
            </tr>
          </table>

          </td>
        </tr>
        <tr>
          <td width="409" height="20" colspan="4">
          <p align="center"><font face="MS Sans Serif" size="3" color="#ffffff"><b>&nbsp;&nbsp;&nbsp;</b></font></p>
          </td>
          <td width="349" height="20" colspan="3">
          <p align="left"></p>
          </td>
        </tr>
        <tr>
          <td width="208" height="15"></td>
          <td width="141" height="15" colspan="2"></td>
          <td width="56" height="15"></td>
          <td width="142" height="15" colspan="2"></td>
          <td width="205" height="15"></td>
        </tr>
        <tr>
          <td width="208" height="15"></td>
          <td width="141" height="15" colspan="2"></td>
          <td width="56" height="15"></td>
          <td width="142" height="15" colspan="2"></td>
          <td width="205" height="15"></td>
        </tr>
        <tr>
          <td width="208" height="15"></td>
          <td width="141" height="15" colspan="2"></td>
          <td width="56" height="15"></td>
          <td width="142" height="15" colspan="2"></td>
          <td width="205" height="15"></td>
        </tr>
        <tr>
          <td width="208">
          <p align="right" valign="top"><font size="2" face="MS Sans Serif">From
          &nbsp;&nbsp;</font></p>
          </td>
          <td width="78"><input id="txtfromdate" name="txtfromdate" size="10" style="HEIGHT: 26px"></td>
          <td width="61">
          <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="26" id="Dtpfrom" name="Dtpfrom" style="LEFT: 0px; TOP: 23px" width="39">
            <param name="_ExtentX" value="1032">
            <param name="_ExtentY" value="688">
            <param name="_Version" value="393216">
            <param name="MousePointer" value="0">
            <param name="Enabled" value="1">
            <param name="OLEDropMode" value="0">
            <param name="CalendarBackColor" value="-2147483643">
            <param name="CalendarForeColor" value="-2147483630">
            <param name="CalendarTitleBackColor" value="-2147483633">
            <param name="CalendarTitleForeColor" value="-2147483630">
            <param name="CalendarTrailingForeColor" value="-2147483631">
            <param name="CheckBox" value="1">
            <param name="CustomFormat" value="dd-mmm-yy">
            <param name="DateIsNull" value="0">
            <param name="Format" value="662831105">
            <param name="UpDown" value="0">
            <param name="CurrentDate" value="37029">
            <param name="MaxDate" value="2958465">
            <param name="MinDate" value="-109205">
          </object>
          </td>
          <td width="56">
          <p align="right"><font size="2" face="MS Sans Serif">To&nbsp;&nbsp;&nbsp;</font></p>
          </td>
          <td width="71"><input id="txttodate" name="txttodate" size="10" style="HEIGHT: 26px"></td>
          <td width="71">
          <object classid="clsid:20DD1B9E-87C4-11D1-8BE3-0000F8754DA1" height="26" id="DtpTo" name="DtpTo" style="LEFT: 0px; TOP: 23px" width="39">
            <param name="_ExtentX" value="1032">
            <param name="_ExtentY" value="688">
            <param name="_Version" value="393216">
            <param name="MousePointer" value="0">
            <param name="Enabled" value="1">
            <param name="OLEDropMode" value="0">
            <param name="CalendarBackColor" value="-2147483643">
            <param name="CalendarForeColor" value="-2147483630">
            <param name="CalendarTitleBackColor" value="-2147483633">
            <param name="CalendarTitleForeColor" value="-2147483630">
            <param name="CalendarTrailingForeColor" value="-2147483631">
            <param name="CheckBox" value="1">
            <param name="CustomFormat" value="dd-mmm-yy">
            <param name="DateIsNull" value="0">
            <param name="Format" value="662831105">
            <param name="UpDown" value="0">
            <param name="CurrentDate" value="37029">
            <param name="MaxDate" value="2958465">
            <param name="MinDate" value="-109205">
          </object>
          </td>
          <td width="205"></td>
        </tr>
        <tr>
          <td width="760" colspan="7" height="10"></td>
        </tr>
        <tr>
          <td width="760" colspan="7" height="10"></td>
        </tr>
        <tr>
          <td width="760" colspan="7" height="10">

          <table width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" valign="top">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td>
                  <div align="center">
                    <center>

                    <table class="tablebordermain" <tr width="15%" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="760" colspan="7">
                        <p align="center"><input type="button" value="   Ok   " name="buttok" onclick="insert()" class="bgcolor"><input type="reset" value="Cancel" name="butcancel" class="bgcolor"><input type="button" value="   Exit   " name="cmdexit" onclick="location.replace(&quot;cashmodule.asp&quot;)" class="bgcolor"></td>
                    </table>

                    </center>
                  </div>
              </table>

              </td>
            </tr>
          </table>

          <p>&nbsp;</td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

</form>

</body>

</html>
