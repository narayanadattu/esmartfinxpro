<%@ Page Language="vb" CodeBehind="cashiertypemastinsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashiertypemastinsert" %>
<%
'''''****************Declaring Variables ***************
Response.Write Request.Form("txtaddress3")
Dim ObjNoteSoiledTran
Dim ObjNoteSoiledNogen
Dim  ArrTran(0,4)
dim BrCode,CurCode,CustId,Add1,Add2,Add3
Dim AmtPaid,Denom,CurNoteNo,RecieveForm,NoOfCutPiece
Dim status,AppDate,UsrId,MachId,narration,TransStatus,CutSoilTranNo
Dim StrtabName,StrFldNames,StrFldValues,StrCondition,StrMsg

'''''******* Assigning all the Frontend fields to the variables*********

BrCode=Trim(Request.Form("txtBranchcode"))
CurCode=trim(Request.Form("txtCurrencyCode"))

CustId=trim(Request.Form("txtCustomerid"))
if len(custid)=0 then
CustId=null
end if
Add1=trim(Request.Form("txtAddress1"))
if len(Add1)=0 then
Add1=null
end if
Add2=trim(Request.Form("txtaddress2"))
if len(Add2)=0 then
Add2=null
end if
Add3=trim(Request.Form("txtaddress3"))
if len(Add3)=0 then
Add3=null
end if
AmtPaid=trim(Request.Form("txtAmtPaid"))
if len(AmtPaid)=0 then
AmtPaid=null
end if
Denom=trim(Request.Form("txtdenomination"))
CurNoteNo=trim(Request.Form("txtCurNoteNo"))
RecieveForm=trim(Request.Form("txtReceivedFrom"))
if len(ReCieveForm)=0 then
RecieveForm=Null 
end if
NoOfCutPiece=trim(Request.Form("txtNoOfNotePiece"))
Appdate=session("applicationdate")
UsrId="u1"
machineId="M1"
narration=trim(Request.Form("txtNarration"))
TransStatus=trim(Request.Form("status"))
status="P"


''''********  calling the Component for CutSoilTranNo AutoGeneration and Asigning that _
'''				Retrieve number to variable
CutSoilTranno=""
Set ObjNoteSoiledNoGen=server.CreateObject("Autonumber.generation")
CutSoilTranNo=ObjNoteSoiledNoGen.GetAutoNumber("CASHCUTNSPOILNOTESMST","CUTSOILTRANNO","branchcode='"& Brcode &"' and " &_
				" Currencycode='"& CurCode &"'")
set ObjNoteSoiledNoGen=nothing

''''************Assinging the tablenames,fields,values to the variables*******

SoilTranNo=Request.Form("hSoiledNo")
StrTabName="CASHCUTNSPOILNOTESMST"   
StrFldNames="BranchCode,CurrencyCode,ReceivedFrom,status,userId,MachineId,Applicationdate," & _
			"CustId,NoOfCutPieces,PaidAmount,Narration,Add1,Add2,Add3,CUTSOILTRANNO," & _
			"Denomination,CurrencyNoteNo"
StrFldValues="'" & brCode &"','"& CurCode &"','" & RecieveForm &"','" & Status &"'," & _
			 "'" & UsrId &"','"& MachineId &"',  to_date(sysdate,'dd-mon-yy') ,'"& custId &"'," & _
			 "'" & NoOfCutPiece & "'," & AmtPaid & ",'"& narration &"','"& Add1 &"'," & _
			 "'"& Add2 &"','" & Add3 &"','"& CutSoilTranNo &"','" & Denom & "','" & CurNoteNo &"'"
			 
StrUpFldValues="'" & brCode &"'~'"& CurCode &"'~'" & RecieveForm &"'~'" & Status &"'~" & _
			 "'" & UsrId &"'~'"& MachineId &"'~ to_date(sysdate,'dd-mon-yy') ~'"& custId &"'~" & _
			 "" & NoOfCutPiece & "~'" & AmtPaid &"'~'"& narration &"'~'"& Add1 &"'~" & _
			 "'"& Add2 &"'~'" & Add3 &"'~'"& SoilTranNo &"'~'"& Denom & "'~'" & CurNoteNo &"'"			 


StrCondition="BranchCode='"& Brcode &"' and CurrencyCode='"& CurCode &"' and cutsoilTranno='" & SoilTranNO &"'"

			 					

''''''****************Setting the TransactionComponent****************

Set ObjNoteSoiledTran = SERVER.CreateObject("GeneralTransactions.DBTransactions")

''''**********************Checking Null Values *********************************
if (len(Brcode) <> 0 and len(Curcode) <> 0 and  len(CurNoteNo)<>0 and len(NoOfCutPiece)<>0) then 
''''*********************Assigning the tablenames and flds and values to Arrayvariable
'''''						 for insert****

	if TransStatus="INSERT" then
	
		ArrTran(0,0)="I"			'passing the TransactionType
		ArrTran(0,1)=StrTabName		'passing the tablename
		ArrTran(0,2)=StrFldNames	'passing the FieldNames
		ArrTran(0,3)=StrFldvalues	'passing the Fieldvalues
		ArrTran(0,4)=""				'passing the Fieldvalues
		
''''*********************Assigning the tablenames and flds and values to ArryVariable _
						'''			and Condition for Update
	
	elseif TransStatus="MODIFY" then
		
	
		ArrTran(0,0)="U"			'passing the TransactionType
		ArrTran(0,1)=StrTabName		'passing the tablename
		ArrTran(0,2)=StrFldNames	'passing the FieldNames
		ArrTran(0,3)=StrUpFldvalues	'passing the Fieldvalues
		ArrTran(0,4)=strCondition	'passing the Fieldvalues
		
		
''''*********************Assigning the tablenames and flds and values to ArryVariable _
              ''						and Condition  for Delete
		
	elseif TransStatus="DELETE" then
	
		ArrTran(0,0)="D"			'passing the TransactionType
		ArrTran(0,1)=StrTabName		'passing the tablename
		ArrTran(0,2)=""				'passing the FieldNames
		ArrTran(0,3)=""				'passing the Fieldvalues
		ArrTran(0,4)=StrCondition	'passing the Fieldvalues
	
	end if
	
''''*********** Calling the component for dataBase Transaction********************
	
	
	Response.Write strfldnames & "<br>"
	Response.Write strfldvalues
	Strmsg= ObjNoteSoiledTran.DataTransactions(ArrTran)
	set ObjNoteSoiledTran=nothing
	'Response.Write strmsg
	Response.Redirect "cutandsoilednotes.asp?record=" & StrMsg
else
StrMsg="Feilds Should not be Empty"
Response.Redirect "cutandsoilednotes.asp?record=" & StrMsg
end if
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
