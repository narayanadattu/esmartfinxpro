<%@ Page CodeBehind="cashpendingpayments.aspx.vb" Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.cashpendingpayments" %>
<html>

<%
dim vUserid,vAppldate,vCounterno,vCashierid,vBrcode,vBrdesc,vCurCode,vCurdesc,vPrec
    vUserid=session("userid")
    vAppldate=session("applicationdate")
    vCounterno=session("Counterno")
    vCahierid=session("userid")
    vBrcode=session("branchcode")
    vBrdesc=session("branchnarration")
    vCurCode=session("currencycode")
    vCurdesc=session("currencynarration")
    vAbbUser=session("abbuser")
    vPrec=session("precision")
'---------------------------------------------------------------------
dim obj, rs, obj1, rs1, obj2, rs2
dim impYnDay,impYnWek,DayLmt,WekLmt

	obj = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs = obj.SingleRecordSet("GENCONFIGMST","IMPYN,VALUE1","CODE='DAYLMT'")
	
	if not rs.EOF and not rs.BOF then
		impYnDay = rs(0).value
		DayLmt = rs(1).value
	end if
	
	obj1 = Server.CreateObject("queryrecordsets.fetchrecordsets")
	
	rs1 = obj1.SingleRecordSet("GENCONFIGMST","IMPYN,VALUE1","CODE='WEKLMT'")
	
	if not rs1.EOF and not rs1.BOF then
		impYnWek = rs1(0).value
		WekLmt = rs1(1).value
	end if
'---------------------------------------------------------------------
dim CshType,Rfldnms,RwhrCond,PayYN,TPayYN,vTotAmt,vTotNarr
        Rfldnms="cashiertypeid" 
        
  CwhrCond=" upper(branchcode)='" & cstr(ucase(trim(vBrcode))) & _
           "' and upper(currencycode)='" & cstr(ucase(trim(vCurCode))) & _
           "' and upper(cashierid)='" & cstr(ucase(trim(vUserid))) & "'"
        
        recLmt=server.CreateObject("adodb.recordset")
        objLmt=server.CreateObject("queryrecordsets.fetchrecordsets")
        recLmt=objLmt.SingleRecordset("CASHCOUNTERMST",cstr(Rfldnms),cstr(CwhrCond))
        if recLmt.RecordCount > 0 then
                                
                CshType=recLmt("CASHIERTYPEID").value
               
                Rfldnms = "paymentsyn,tellerpaymentsyn"
                
               RwhrCond = " upper(branchcode) = '" & ucase(trim(vBrcode)) & _
                           "' and upper(currencycode) = '" & Cstr(ucase(trim(vCurCode))) & _
                           "' and upper(cashiertypeid) = '" & Cstr(ucase(trim(CshType))) & _
                           "' and upper(status) = 'R'"
                 
              
                    
                recLmt=objLmt.singlerecordset("CASHCASHIERTYPEMST",cstr(Rfldnms), _
                                                  cstr(RwhrCond))
				if recLmt.recordcount>0 then
				   PayYN=recLmt("paymentsyn").value
				   TPayYN=recLmt("tellerpaymentsyn").value   
				   
				   Rfldnms="nvl(totamount,0) TotAmt"
				   recLmt=objLmt.singlerecordset("CASHCASHIERPOSMST",cstr(Rfldnms), _
                                                   cstr(CwhrCond))
                   if recLmt.recordcount>0 then
					  vTotAmt=recLmt("TotAmt").value 
					  vTotNarr="Curr. Balance : "   
				   end if   
				end if
                
        end if   
        
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var strSessionFld,strsessionflds,vProceed,Rselect,brCode,brDesc,curCode,curDesc,abbYN
//----------------------------------------------------------------------------------   
//This function is used to get the native branch and native currency codes.
function NatBranch(){
         
     with(window.document.frmTrans){
          txtbranchcode.value=strsessionflds[4];
          txtbranchdesc.value=strsessionflds[5];
          txtcurrencycode.value=strsessionflds[6];
          txtcurrencydesc.value=strsessionflds[7];
         }
}   
//----------------------------------------------------------------------------------
//This function is used to split session variables.
function PubVariables(){
  vProceed="true"
  strSessionFld=window.document.frmTrans.txtSessionflds.value
  strsessionflds=strSessionFld.split("~");
 
  <%if(vAbbUser="Y") then%>
  window.document.frmTrans.cmdBrCode.disabled=false
  window.document.frmTrans.txtbranchcode.readOnly=false
  window.document.frmTrans.txtbranchdesc.readOnly=false
  <%else%>
  window.document.frmTrans.cmdBrCode.disabled=true
  window.document.frmTrans.txtbranchcode.readOnly=true
  window.document.frmTrans.txtbranchdesc.readOnly=true
  window.document.frmTrans.optNorABB(1).disabled=true
  <%end if%>
}
//----------------------------------------------------------------------------------
function TellerBranch()
{
    brCode=window.document.frmTrans.txtbranchcode.value; 
    brDesc=window.document.frmTrans.txtbranchdesc.value; 
    st="Tellerbranch";
    window.showModalDialog('<%="http://" & session("moduledir")& "/GEN/"%>'+"TranList.aspx" + "?"+"st="+st,window,"status:no;"+
		 "DialogWidth:270px;DialogHeight:170px;DialogLeft:100px;DialogTop:60px")   
}   
//----------------------------------------------------------------------------------
function Branchcode(kstr){
     window.document.frmTrans.Mfgpaydt.Rows=1
     assign(kstr,window.document.frmTrans.txtbranchdesc,
                window.document.frmTrans.txtbranchcode);
     
   //  Cancel() 
}
//----------------------------------------------------------------------------------   
function curr()
{
   curCode=window.document.frmTrans.txtcurrencycode.value; 
   curDesc=window.document.frmTrans.txtcurrencydesc.value; 
   st="Curr";
   
    window.showModalDialog('<%="http://" & session("moduledir")& "/GEN/"%>'+"TranList.aspx" + "?"+"st="+st,window,"status:no;"+
		 "DialogWidth:270px;DialogHeight:170px;DialogLeft:480px;DialogTop:60px")   
}
//----------------------------------------------------------------------------------
//This function is used to send parameters to List form to get various currency codes and
//descriptions available.
function currency(kstr){
 var strVal;
  
     strVal=kstr.split("-----");
     window.document.frmTrans.txtcurrencycode.value=strVal[1];
     window.document.frmTrans.txtcurrencydesc.value=strVal[0];
     prcn=strVal[2].length-1;
     window.document.frmTrans.hpr.value=prcn;
     Cancel()
  // TransQuery(); 
}
//----------------------------------------------------------------------------------
function Cancel(){
   window.document.frmTrans.Mfgpaydt.Rows=1;
   window.document.frmTrans.txtbranchcode.value=strsessionflds[4]
   window.document.frmTrans.txtbranchdesc.value=strsessionflds[5]
   window.document.frmTrans.txtcurrencycode.value=strsessionflds[6]
   window.document.frmTrans.txtcurrencydesc.value=strsessionflds[7]
}
//----------------------------------------------------------------------------------   
function ABBCheck(){
	if(window.document.frmTrans.optNorABB(0).checked==true){
	   abbYN="N"
	}
	else{
	   abbYN="Y"
	}
}	 
//----------------------------------------------------------------------------------   
 function RecPayLmt(){
      var kstr="";
      with(window.document.frmTrans){
           strpm="RPLMT"+"~"+txtbranchcode.value+"~"+
                  txtcurrencycode.value+"~"+
                  strsessionflds[0]
                  window.document.all['iGeneral'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"minBalChk.aspx?strparam="+strpm
           }
 }
//-----------------------------------------------------------------------------------
 //function PayLimit(vRLmt){
 function RecLimit(vRLmt){
   var PayAmt="";
      PayAmt=vRLmt.split("~");
      MaxPayAmt=PayAmt[1]
  }	  
//-----------------------------------------------------------------------------------
  function PayLmtChk(){
   
   var LmtAmt=window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6)
       if(eval(LmtAmt)>eval(MaxPayAmt)){
       MaxPayAmt=gridprecision(MaxPayAmt,window.document.frmTrans.hpr.value)
       alert("User is not allowed to do Cash Payments"+"\n\n"+
             "Transactions above "+MaxPayAmt);  
       vProceed="false"
       }
 }
 
//----------------------------------------------------------------------------------   	  
//This function used to send parameters to get data from gentranslog
  function TransQuery(){
	var vBrCode,vCurCode,vPayType,strPrm
	
	vBrCode=window.document.frmTrans.txtbranchcode.value 
	vCurCode=window.document.frmTrans.txtcurrencycode.value 
	if(window.document.frmTrans.optPay(0).checked==true){
	   vPayType="CASH"
	}
	else if(window.document.frmTrans.optPay(1).checked==true){
	   vPayType="TELLER"
	}   
	strPrm =vBrCode+"|"+ vCurCode+"|"+vPayType+"|"+abbYN

	//alert('<%="http://" & session("moduledir")& "/" & session("moddir")& "/"%>')
	window.document.all['iPop'].src='<%="http://" & session("moduledir")& "/CASH/"%>'+"paylist.aspx?strPrm="+strPrm 
	
  }	
//----------------------------------------------------------------------------------   
//This function is used to populate flexgrid.
function  FlexPop(kstr){
	var K,i,m,b,pos,j,h,n,p,s
	for(m=1;m<=2;m++){
	b=kstr.split("$")
	}
	 st=b[0]
	var recCount=b[1]
	    if(recCount==0){
	       alert("No Pending Transactions Found.")
	    } 
	 	window.document.frmTrans.Mfgpaydt.Rows = eval(b[1])+1
		window.document.frmTrans.Mfgpaydt.Cols=b[2]

	for(p=1;p<=b[1];p++){
	      n=st.split("|")
	     if(b[1]>0){
			 for(j=0;j<b[2];j++){
				k=n[p-1].split("~")
				window.document.frmTrans.Mfgpaydt.TextMatrix(p,j)=k[j]
				if(j==6){   
		        window.document.frmTrans.Mfgpaydt.TextMatrix(p,j)=gridprecision(window.document.frmTrans.Mfgpaydt.TextMatrix(p,j),
				window.document.frmTrans.hpr.value)
		        } 
			}
		 }
		 
	}
    window.document.frmTrans.Mfgpaydt.ColWidth(13)=0	
    window.document.frmTrans.Mfgpaydt.ColWidth(14)=0
    window.document.frmTrans.Mfgpaydt.ColWidth(15)=0
    window.document.frmTrans.Mfgpaydt.ColWidth(17)=0
}
//----------------------------------------------------------------------------------       
//This function is used to call cashpaymentdetails.asp form and sends parameter 
//values to it.
  function flexClick()
  {
  
	var stDayimpYN,stWeekimpYN
	
	
	stWeekimpYN = "<%=impYnWek%>"
	stDayimpYN = "<%=impYnDay%>"
	
	
	
	
	if(stWeekimpYN == "Y")
	{
		if((window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,0)!="")&&(window.document.frmTrans.Mfgpaydt.Rows>1))
		{
			if ((window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,2) == "SB") || (window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,2) == "CA") || (window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,2) == "CC") || (window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,2) == "DEP") || (window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,2) == "LOAN"))
			{
				ChkWEKLmt()
			}
			else
			{
				showdat()
			}
		}
	}
	else
	{

		showdat()
	}
	
	
	/*var colCnt,brCrCode,colData
	var kstr
	kstr=""
	vProceed="true"
	
	var brCrCode=window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtbranchdesc.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+window.document.frmTrans.txtcurrencydesc.value+"~"
	if((window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,0)!="")&&(window.document.frmTrans.Mfgpaydt.Rows>1)){
	    PayLmtChk()
	    if(vProceed=="false"){
	       return
	    }
			
		for(colCnt=0;colCnt<window.document.frmTrans.Mfgpaydt.Cols;colCnt++){
		
			colData=window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,colCnt)
			if (colData=="Null")
			{
				colData=""
			}
			kstr=kstr+colData+"~"
		}
	
	 kstr=brCrCode+kstr+window.document.frmTrans.hpr.value+"~"+"PAY"+"~";
	 //alert(kstr)	
	 window.location.href="cashpaymentdetails.aspx?kstr="+kstr+"~"+'<%=vTotAmt%>'
	 
	}*/
  }
  
  function ChkWEKLmt()
  {
	///LmtAmt=window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6)
	
	var kstr="";
	vDayCashProced = "true"
	
	var strAppDt="<%=session("applicationdate")%>"
	
      with(window.document.frmTrans)
      {
           strpm="STWEKLMT"+"~"+Mfgpaydt.TextMatrix(Rselect,2)+"~"+Mfgpaydt.TextMatrix(Rselect,13)+"~"+Mfgpaydt.TextMatrix(Rselect,4)+"~"+Mfgpaydt.TextMatrix(Rselect,6)+"~"+Mfgpaydt.TextMatrix(Rselect,16)+"~"+strAppDt+"~"+"Y"
           /// module"~"glcode"~"accno"~"amount"~"branchcode"~"applicationdate"~"CashpaidYN
      
      }
          window.document.all['iGeneral'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"minBalChk.aspx?strparam="+strpm
  }
  
  function PopWeekpay(sWeekpay)
  {
		var stPay,stTotweek,stWeekVal
		
		
		stTotweek = "0"
		
		stWeekVal = "<%=WekLmt%>"
		
		if(sWeekpay!="No Amount")
		{
			stPay = sWeekpay.split("|")
			
			for(aCnt=0;aCnt<=stPay.length-1;aCnt++)
			{
			
				stTotweek = eval(stTotweek) + eval(stPay[aCnt])
		
			}
			
			if(stTotweek > stWeekVal)
			{
				stTotweek = stTotweek + eval(window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6))
				
				if(eval(stTotweek)>eval(stWeekVal))
				{
					if (confirm("This customer has crossed Rs."+stWeekVal+"/- cash payment for the week. Do You Want continue Y/N?") == true)
					{
						if(confirm("Are You Sure") == true)
						{
						
							showdat()
						} 
						else
						{
							return;
						}
					}
					else
					{
						return;
					}
				}
				else
				{
					showdat()
				}
			}
			
			if (stTotweek <= stWeekVal)
			{
			
				stTotweek = stTotweek + eval(window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6))
				
				if(eval(stTotweek)>eval(stWeekVal))
				{
					if (confirm("This customer has crossing Rs."+stWeekVal+"/- cash payment for the week. Do You Want continue Y/N?") == true)
					{
						if(confirm("Are You Sure") == true)
						{
						
							showdat()
						}
						else
						{
							return;
						}
					}
					else
					{
						return;
					}
				}
				else
				{
					//ChkDayLmt()
					showdat()
				}
			}
			/*else
			{
					ChkDayLmt()
			}
			*/
		}
  }
  
  function ChkDayLmt()
  {
	///LmtAmt=window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6)
	
	var kstr="";
	vDayCashProced = "true"
	
	var strAppDt="<%=session("applicationdate")%>"
	
	
      with(window.document.frmTrans)
      {
           strpm="STDAYLMT"+"~"+Mfgpaydt.TextMatrix(Rselect,2)+"~"+Mfgpaydt.TextMatrix(Rselect,13)+"~"+Mfgpaydt.TextMatrix(Rselect,4)+"~"+Mfgpaydt.TextMatrix(Rselect,6)+"~"+Mfgpaydt.TextMatrix(Rselect,16)+"~"+strAppDt
      
      }
          window.document.all['iGeneral'].src='<%="http://" & session("moduledir")& "/GEN/"%>'+"minBalChk.aspx?strparam="+strpm
  }
  
  function PopDaypay(sDypay)
  {
		var stPay,stTotday,stDayVal
		
		stTotday = "0"
		stDayVal = "<%=DayLmt%>"
		
		if(sDypay!="No Amount")
		{
			stPay = sDypay.split("|")
			
			for(aCnt=0;aCnt<=stPay.length-1;aCnt++)
			{
			
				stTotday = eval(stTotday) + eval(stPay[aCnt])
				
			}
		
			if(stTotday > stDayVal)
			{
				stTotday = stTotday + eval(window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6))
				
				
				if(eval(stTotday)>eval(stDayVal))
				{
					if (confirm("This customer has crossed Rs."+stDayVal+"/- cash payment for the day. Do You Want continue Y/N?") == true)
					{
						if(confirm("Are You Sure") == true)
						{
							showdat()
						} 
						else
						{
							return;
						}
					}
					else
					{
						return;
					}
				}
				else
				{
					showdat()
				}
			}
			if (stTotday <= stDayVal)
			{
				stTotday = stTotday + eval(window.document.frmTrans.Mfgpaydt.TextMatrix(Rselect,6))
				
				if(eval(stTotday)>eval(stDayVal))
				{
					if (confirm("This customer has crossing Rs."+stDayVal+"/- cash payment for the day. Do You Want continue Y/N?") == true)
					{
						if(confirm("Are You Sure") == true)
						{
							showdat()
						}
						else
						{
							return;
						}
					}
					else
					{
						return;
					}
				}
				else
				{
					showdat()
				}
			}
			
		}
  }	
  
  function showdat()
  {
	var colCnt,brCrCode,colData
	var kstr
	kstr=""
	vProceed="true"
	
	var brCrCode=window.document.frmTrans.txtbranchcode.value+"~"+window.document.frmTrans.txtbranchdesc.value+"~"+window.document.frmTrans.txtcurrencycode.value+"~"+window.document.frmTrans.txtcurrencydesc.value+"~"
	if((window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,0)!="")&&(window.document.frmTrans.Mfgpaydt.Rows>1)){
	    PayLmtChk()
	    if(vProceed=="false"){
	       return
	    }
			
		for(colCnt=0;colCnt<window.document.frmTrans.Mfgpaydt.Cols;colCnt++){
		
			colData=window.document.frmTrans.Mfgpaydt.TextMatrix(window.document.frmTrans.Mfgpaydt.Row,colCnt)
			if (colData=="Null")
			{
				colData=""
			}
			kstr=kstr+colData+"~"
		}
	
	 kstr=brCrCode+kstr+window.document.frmTrans.hpr.value+"~"+"PAY"+"~";
	//alert(kstr)	
	window.location.href='<%="http://" & session("moduledir")& "/CASH/"%>'+"cashpaymentdetails.aspx?kstr="+kstr+"~"+'<%=vTotAmt%>'
	}
  }

//----------------------------------------------------------------------------------
//-->
</script>

<SCRIPT LANGUAGE=javascript FOR=Mfgpaydt EVENT=DblClick>
<!--
 Rselect=window.document.frmTrans.Mfgpaydt.RowSel 
 flexClick();
//-->
</SCRIPT>

</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);PubVariables();NatBranch();RecPayLmt();ABBCheck();TransQuery();">

<%appdate=formatdatetime(session("applicationdate"),1)%>

<form name="frmTrans">

  <%if ucase(PayYN)<>"Y" then%>
  <script language="javascript">
   location.replace("cashmodule.aspx")
   alert("User is not allowed to do Cash Payments")
  </script>
  <%end if%>
  <%if cdbl(vTotAmt)=0 then %>
    <script language="javascript">
            location.replace("cashmodule.aspx") 
            alert("No Cash alloted to this User")
    </script>        
  <%end if%>
  
  
  <div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
		
        <div class="menuBar"><%appdate=formatdatetime(session("applicationdate"),1)%>
            <table cellpadding="0" cellspacing="0" width="100%" border="0">
				<tr>
					<td width="23%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="16%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="43%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Payments</h2></td>
					<td width="50%" height="22" align="right" class="subHeader"><%=APPDATE%></td>
				</tr>
			</table>
    </div>
    <div id="menucontrol"></div>
  

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="28"><img border="0" height="22" name="placeholder" src="dscript42/transparent.gif" width="1"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

     

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" nowrap height="15">
          <p align="center"></p>
          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <div align="center">
            <center>

            <table border="0" width="98%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="12%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
                <td width="38%"><input name="txtbranchcode" size="9" readonly class="txtautofill"><input type="button" value=" L " name="cmdBrCode" onclick="TellerBranch()" class="button"><input name="txtbranchdesc" size="16" readonly class="bgcolor1"></td>
                
                <td width="21%" align="right">Currency Code</td>
                <td width="35%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtcurrencycode" class="txtautofill" size="9" readonly><input type="button" value=" L " name="cmdCurCode" onclick="curr()" class="button"><input name="txtcurrencydesc" size="16" readonly class="bgcolor1"></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td>
            <%if Len(Request("trn"))>0 then%>
            <%Response.Write (Request("trn"))
      end if
            %>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%">

                <table class="tableborder2" width="100%" cellspacing="0" cellpadding="0">
                  <tr class="bgcolor1">
                    <td width="50%" align="center"><input type="radio" name="optNorABB" value="optNormal" checked onclick="ABBCheck();Cancel()">
                    <font class="textblack">Normal</font></td>
                    <td width="50%" align="center"><input type="radio" name="optNorABB" value="optABB" onclick="ABBCheck();Cancel()">
                    <font class="textblack">ABB</font></td>
                  </tr>
                </table>

                </td>
              </tr>
              <tr>
                <td width="100%" height="5"></td>
              </tr>
            </table>

            <table class="tableborder2" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor1">
                <td width="50%" align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="optCashPay" checked name="optPay" onclick="TransQuery()">
                <font class="textblack">Cash Payments</font></td>
                <td width="50%" align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" value="optTeller" name="optPay" language="javascript" onclick="TransQuery()">
                <font class="textblack">Teller Payments</font></td>
              </tr>
            </table>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="10"></td>
              </tr>
            </table>

            <div align="center">
              <center>

              <table width="70%" cellpadding="0" class="tableborder2">
                <tr>
                  <td>
                  <p>
                  <OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=391 id=Mfgpaydt 
	name=Mfgpaydt style="LEFT: 1px; TOP: 1px" width=735 VIEWASTEXT>
	<PARAM NAME="_ExtentX" VALUE="19447">
	<PARAM NAME="_ExtentY" VALUE="10345">
	<PARAM NAME="BackColor" VALUE="-2147483643">
	<PARAM NAME="ForeColor" VALUE="-2147483640">
	<PARAM NAME="Enabled" VALUE="-1">
	<PARAM NAME="BackStyle" VALUE="0">
	<PARAM NAME="BorderStyle" VALUE="1">
	<PARAM NAME="AllowBigSelection" VALUE="-1">
	<PARAM NAME="AllowUserResizing" VALUE="1">
	<PARAM NAME="Appearance" VALUE="1">
	<PARAM NAME="BackColorBkg" VALUE="8421504">
	<PARAM NAME="BackColorFixed" VALUE="-2147483633">
	<PARAM NAME="BackColorSel" VALUE="-2147483635">
	<PARAM NAME="CausesValidation" VALUE="-1">
	<PARAM NAME="Cols" VALUE="16">
	<PARAM NAME="ColWidth0" VALUE="1095">
	<PARAM NAME="DrawMode" VALUE="0">
	<PARAM NAME="FillStyle" VALUE="0">
	<PARAM NAME="FixedCols" VALUE="0">
	<PARAM NAME="FixedRows" VALUE="1">
	<PARAM NAME="FocusRect" VALUE="1">
	<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
	<PARAM NAME="ForeColorSel" VALUE="-2147483634">
	<PARAM NAME="FormatString" VALUE=">Batch  No.|>Tran No. |<Module ID|<GL Description         |>Account No.         |<Name                              |>Amount               |>Token No|<Service Description     |<Status        |<Remarks                           |<User ID               |<Machine ID         |< |< |< |<Acc Branch Code |<Acc Branch Name">
	<PARAM NAME="GridColor" VALUE="12632256">
	<PARAM NAME="GridColorFixed" VALUE="0">
	<PARAM NAME="GridLines" VALUE="1">
	<PARAM NAME="GridLinesFixed" VALUE="2">
	<PARAM NAME="GridLineWidth" VALUE="1">
	<PARAM NAME="MergeCells" VALUE="0">
	<PARAM NAME="MergeCol0" VALUE="0">
	<PARAM NAME="MergeRow0" VALUE="0">
	<PARAM NAME="MousePointer" VALUE="0">
	<PARAM NAME="OLEDropMode" VALUE="0">
	<PARAM NAME="PictureType" VALUE="0">
	<PARAM NAME="Redraw" VALUE="-1">
	<PARAM NAME="RightToLeft" VALUE="0">
	<PARAM NAME="RowHeightMin" VALUE="0">
	<PARAM NAME="Rows" VALUE="1">
	<PARAM NAME="ScrollBars" VALUE="3">
	<PARAM NAME="ScrollTrack" VALUE="0">
	<PARAM NAME="SelectionMode" VALUE="0">
	<PARAM NAME="TextStyle" VALUE="0">
	<PARAM NAME="TextStyleFixed" VALUE="0">
	<PARAM NAME="ToolTipText" VALUE="">
	<PARAM NAME="WhatsThisHelpID" VALUE="0">
	<PARAM NAME="WordWrap" VALUE="0">
	<PARAM NAME="ColAlignment0" VALUE="7">
	<PARAM NAME="ColData0" VALUE="0">
	<PARAM NAME="FixedAlignment0" VALUE="9">
	<PARAM NAME="FontWidth" VALUE="0">
	<PARAM NAME="hWnd" VALUE="0">
	<PARAM NAME="RowData0" VALUE="0">
	<PARAM NAME="RowHeight0" VALUE="240">
	<PARAM NAME="TextArray0" VALUE="Batch  No.">
	<PARAM NAME="TextMatrix0" VALUE="Batch  No.">
	<PARAM NAME="row" VALUE="">
	<PARAM NAME="col" VALUE="">
	<PARAM NAME="RowSel" VALUE="">
	<PARAM NAME="ColSel" VALUE="">
	<PARAM NAME="CellBackColor" VALUE="">
	<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
              </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" height="20"></td>
              </tr>
              <tr>
                <td width="100%" height="20">
                <div align="center">
                  <center>

                  <table border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
                    <tr>
                      <td width="100%"><input type="button" value="Refresh" name="cmdRefresh" class="button" onclick="TransQuery()"><input type="button" value="Cancel" name="cmdCancel" class="button" onclick="Cancel()"><input type="button" value="    Exit    " name="cmdExit" onclick="location.replace(&quot;cashmodule.aspx&quot;)" class="button"></td>
                    </tr>
                  </table>

                  </center>
                </div>
                </td>
              </tr>
              <tr>
                <td width="100%" height="5"></td>
              </tr>
            </table>

        </table>

        </center>
      </div>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="20"></td>
        </tr>
      </table>

  </table>

  <input type="hidden" name="txtSessionflds" value="<%=vUserid & "~" & vAppldate & "~" & vCounterno & "~" & vCahierid & "~" & vBrcode & "~" & vBrdesc & "~" & vCurCode & "~" & vCurdesc & "~"%>"><input type="hidden" name="hpr" value="<%=vPrec%>">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iPop" align=center style="display:block"
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="paylist.aspx">
                                              </iframe>
                                              
      </td>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iGeneral" align=center style="display:block"
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="minBalChk.aspx">
                                              </iframe>
                                              
      </td>
    </tr>
  </table>

</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

      <table border="0" width="90%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
          <iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=0 src="billsonblu.aspx">
          </iframe>
          </td>
        </tr>
      </table>

      </center>
    </div>
    </td>
  </tr>
</table>

<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>
		

</body>

</html>
