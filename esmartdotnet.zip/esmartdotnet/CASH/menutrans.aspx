<%@ Page Language="vb" CodeBehind="menutrans.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.menutrans" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="proc.js"></SCRIPT>
<SCRIPT LANGUAGE=javascript src="val.js"></SCRIPT>
<script language="JavaScript" src="dhtmllib.js"></script>
<script language="JavaScript" src="navbar.js"></script>
<script language="JavaScript" src="xlib.js"></script>

<SCRIPT LANGUAGE=javascript>
<!--
function disp()
{
GetMenu(window.document.frmmenudtl.txtdtls.value)
}


//-->
</SCRIPT>



<%
	dim usrid
	dim objfetch
	dim objwork
	dim recdtls
	dim vals
	dim title
	dim vmod
	dim chkstr
	
	vmod=Request.Form("hmod")
	usrid=session("userid")
	set objwork=server.CreateObject("workallotment.allotment")
	vals=objwork.userworkallotment("DELETE",cstr(usrid),cstr(vmod),cstr(session("branchcode")))
	Response.Write "DELETE" & cstr(usrid) & cstr(vmod) & cstr(session("branchcode"))
	for icount=0 to ubound(vals)-1
		valstr=valstr&",'" & vals(icount) &"'"
	next
	if len(valstr)>0 then valstr=right(valstr,len(valstr)-1)
	Response.Write ubound(vals)	
	set objfetch=server.CreateObject ("queryrecordsets.fetchrecordsets")
	set recdtls=server.CreateObject("adodb.recordset")
	set recdtls=objfetch.singlerecordset("genmoduleidformsmst","menutitle,forms","forms in(" & valstr & ") order by menutitle")
	
	Response.Write "genmoduleidformsmst" & " menutitle,forms" & " forms in(" & valstr & ") order by menutitle"
	
	
	chkstr=recdtls(0)
	mainstr=chkstr
	do while not recdtls.EOF 
		if recdtls(0)=chkstr then
			mainstr=mainstr & "," & recdtls(1)
		else
			chkstr=recdtls(0)
			mainstr=mainstr & "|" & recdtls(0)& "," & recdtls(1)
		end if
		recdtls.MoveNext
	loop
	
	set recdtls=objfetch.singlerecordset("servervirtualdirdtls","machinename,virtualdir")
	mainstr=recdtls(0) &"/" & recdtls(1) &"/" & vmod & "~" & mainstr
	


%>

 
<title></title>
</head>
<body>

<form name="frmmenudtl">
  <input name="txtdtls" type="hidden" value="<%=mainstr%>">&nbsp;<font color="black" size="4"></font>

  <table>
    <tr>
      <td width="11%">&nbsp;</td>
      <center><font color="black" size="4">
      <td>Processing..........</font> </center></FORM>
      </td>
    </tr>
  </table>

</body>

