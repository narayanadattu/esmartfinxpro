<%@ Page Language="vb" CodeBehind="TellerPaymentInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.TellerPaymentInsert" %>
<%

	'**********************************************************************************
	'*	Name Of the File : CashPaymentInsert.asp				                *
	'*	Purpose	  	     : This form is use to	insert the Teller payment details *
	'*																		    *      	                              *
	'*		   													                *
	'*			                                            			        *
	'|-------------------------------------------------------------------------------|
	'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
	'|----------------------|------------------|------------|------------------------|
	'| Nagendra Prasad		|    05-MAY-2001   |   1.0      |		                 |     
	'|				        |                  |	        |                        |
	'|-------------------------------------------------------------------------------|
	'**********************************************************************************

option explicit
Response.Buffer=true
Response.Expires=0
On Error Resume Next
Dim BrchCd,BrchNm,CurrCd,CurrNm,mydate,appldt
Dim TknNo,ScrlNo,TrnId,ModId,GiCd,AccNo,amt,narrn
Dim Dval,Dtype,DPadamt,DExamt
Dim Vartrans()
Dim i,J,K

dim vUserid,vAppldate,vCounterno
    vUserid=session("userid")
    vAppldate=session("applicationdate")
    vCounterno=session("counterno")

BrchCd=Request("txtbranchcode")
BrchNm=Request("txtbranchdesc")
CurrCd=Request("txtcurrencycode")
CurrNm=Request("txtcurrencydesc")

'TknNo=Request("txtTokenNo")
ScrlNo=Request("txtScrollNo")
TrnId=Request("txtTrnNo")
ModId=Request("txtModuleId")
GiCd=Request("txtGlcode")
AccNo=Request("txtAccNo")
amt=Request("txtAmt")
narrn=Request("txtNarration")
machid=Session("machineid")
appdt=session("Applicationdate")
user=session("userid")


Dval=split(Request("DemonValue"),"~")
Dtype=split(Request("DenomType"),"~")
DPadamt=split(Request("PaidAmt"),"~")
DExamt=split(Request("ExchgAmt"),"~")

Redim Vartrans(ubound(dval)-1,3)

For i=0 to UBound(Vartrans)  
	Vartrans(i,0)=trim(Dval(i))
	Vartrans(i,1)=DPadamt(i)
	Vartrans(i,2)=DExamt(i)
	Vartrans(i,3)=Dtype(i)
next

DIM dd,yy,mm,appldate
Dim str,strMsg,PayObj

if Len(BrchCd)<>0 and len(CurrCd)>0 and Len(TrnId)>0   then
		'----------- Calling the Component	--------------------
		 Set payObj = server.CreateObject("cashtransaction.transactions")
		
         strMsg = PayObj.cashPayments(CStr(BrchCd),CStr(CurrCd),CStr(GiCd), _
         CStr(AccNo), CInt(TknNo),cstr(vUserid), CDbl(ScrlNo), CDbl(amt), _
         CStr(narrn), "P",cstr(vUserid), cstr(machid), cstr(user), cstr(machid),cstr(user),cstr(machid), _
         cstr(vAppldate),cstr(vAppldate), CDbl(TrnId),"1212", Vartrans)   
          
 set payObj=nothing
  Response.Redirect "Tellerpayments.asp?trn=<font size=2 face=verdana color=blue><b>"&strMsg&"</b></font>"

else

strMsg="Fields Should Not be Null."
Response.Redirect "Tellerpayments.asp?trn=<font size=2 face=verdana color=blue><b>"&strMsg&"</b></font>"
end if
%>

<%if err.number<>0 then%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<br>
<br>
<br>
<br>
<center><font size="2" face="verdana" color="Red"><b></b></font><font size="2" face="verdana" color="blue"><b><%=err.number%> <%=err.description%>
<p>&nbsp;</b></font></center>


<%end if%>
