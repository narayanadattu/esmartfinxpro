<%@ Page Language="vb" CodeBehind="denomlist.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.denomlist" %>
<%

	Dim obj,obj1,msg,appdate
	str=Request.QueryString("st")
	code=str	
	set rs=server.CreateObject("adodb.recordset") 	
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("CASHDENOMINATIONMST","DENOMINATIONTYPE,DENOMINATIONCODE,DENOMINATIONVALUE"," CURRENCYCODE ='"& code &"' order by to_number(substr(DENOMINATIONCODE,2)) ")	
	k=rs.RecordCount 
	for i= 1 to k
		for j= 0 to rs.Fields.Count-1  
			msg=msg & rs(j)& ","					
		next 
		m=instrrev(msg,",")
		msg=left(msg,m-1)
	msg=msg & " | "
		rs.MoveNext() 
	next
	msg=msg & "$" & k
	%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
function List()
{
	var str
	str=window.document.frmacc.hcno.value		
	window.attachEvent(window.opener.listcode(str))
	window.close()
}

</SCRIPT>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hcno" name="hcno" value="<%=msg%>">
</form>

</body>

</html>
