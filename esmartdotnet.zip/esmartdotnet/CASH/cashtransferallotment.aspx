<%@ Page aspcompat="true" explicit="false" CodeBehind="cashtransferallotment.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashtransferallotment" %>
<html>
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashTransferAllotment.aspx
''''' ListForm:List,single
''''' iFramepage:getcounternocashier.aspx
''''' Trnsactionpages:CashtransferallotmentInsert.aspx
''''------------------------------------------------------------------------------------------
%>
<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
/*
function branch()
{   
	st="Bruser"
	window.open("List.aspx" + "?"+"st="+st,st,"width=213%,height=150%,left=120,top=135")
}

function Bruser(kstr)
{
   assign(kstr,window.document.frmtrans.txtbranchdesc,window.document.frmtrans.txtbranchcode)
     
}
function currency(){  

	 st="Curr"
	 window.open("List.aspx" + "?"+"st="+st,st,"width=220%,height=150%,left=535%,top=220%")
	 }
function Currid(kstr)
{
var p
  k=kstr.split("-----")
  window.document.frmtrans.txtcurrencydesc.value =k[0]
  window.document.frmtrans.txtcurrencycode.value =k[1]
var prn=k[2].length-1
  window.document.frmtrans.hpr.value=prn
  p=""
  for(f=1;f<=prn;f++)
  {
    p=p + "0"
  }
  pres= "0." + p 
  window.document.frmtrans.txttotal.value=pres
  window.document.frmtrans.txtAmount.value =pres
  window.document.frmtrans.txtavtotal.value =window.document.frmtrans.txtAmount.value
  window.document.frmtrans.txtCashierID.value=""
   window.document.frmtrans.txtCashierName.value=""
   window.document.frmtrans.txtCounterNo.value =""
   window.document.frmtrans.txtTransferNo.value=""
   window.document.frmtrans.txtNarration.value=""
  denom()
  
}	 
	 */
///	 
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'
//alert("CashDenom="+CashDenom)

/// send parameters to list page to get cashier id 
function CashierMgt(){
		
		st1="Cashiermgt"
		st2=window.document.frmtrans.txtbranchcode.value
		st3=window.document.frmtrans.txtcurrencycode.value
		st=st1+"*"+st2+"*"+st3
		window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
//displaying the cashierid,name which is returned in lst page 
function CashierMgtid(kstr){
		//alert("kstr="+kstr)
		assign(kstr,window.document.frmtrans.txtCashierName,
		window.document.frmtrans.txtCashierID)
		Getcounterid()
	
}
/// send parameters to list page to get Counterno
function Counter(){

		st1="Tcounter"
		st2=window.document.frmtrans.txtbranchcode.value
		st3=window.document.frmtrans.txtcurrencycode.value
		st=st1+"*"+st2+"*"+st3
		window.showModalDialog("single.aspx"+"?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
///displaying the counterno which is returned in lst page 
function Counterid(kstr){
		//alert("counterid="+kstr)
		window.document.frmtrans.txtCounterNo.value=kstr
		window.document.frmtrans.txtCashierID.value=""
		window.document.frmtrans.txtCashierName.value=""
		Getcounterid()
}
//To Get counterid depend on cashierid
function Getcounterid(){

		if(window.document.frmtrans.txtCashierID.value!=""){
		st1="Counter"
		sBr=window.document.frmtrans.txtbranchcode.value
		sCur=window.document.frmtrans.txtcurrencycode.value 
		sCash=window.document.frmtrans.txtCashierID.value 
		k="*"
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCash=sCash.toUpperCase()
		st=st1+k+sBr+k+sCur+k+sCash
		//alert("st="+st)
		//post to iframe page
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
		
}
//to get cahierid depending upon counterno
else if(window.document.frmtrans.txtCounterNo.value!=""){
		st1="Cashier"
		sBr=window.document.frmtrans.txtbranchcode.value
		sCur=window.document.frmtrans.txtcurrencycode.value 
		sCnt=window.document.frmtrans.txtCounterNo.value 
		k="*"
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		st=st1+k+sBr+k+sCur+k+sCnt
		//post to iframe page
		window.document.frames(1).frmacc.hFlds.value=""
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
}
}
///dipalying counterno which is returned in iframe page 
function Allotcounterno(stri){
		
		window.document.frmtrans.txtCounterNo.value=stri
		 
}
///dipalying cashierid,casiername  which is returned in iframe page
function  Allotcashierid(stri)
{	
//alert("stri="+stri)		
	if(stri!="") 
	{	
		kstr=stri.split("*")
		window.document.frmtrans.txtCashierID.value=kstr[1]
		window.document.frmtrans.txtCashierName.value=kstr[2]
		
	}	
}
//sending parameters to denomination iframe page to get denominations
function denom()
{
	if (CashDenom=='Y')
	{
		window.document.all.divden.style.display="block"
		//window.document.all.total.style.visibility="visible" 
		window.document.frmtrans.txttotal.style.visibility="visible" 
		//window.document.frmtrans.txtavtotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.divden.style.display="none"
		//window.document.all.total.style.visibility="hidden" 
		window.document.frmtrans.txttotal.style.visibility="hidden" 
		//window.document.frmtrans.txtavtotal.style.visibility="hidden" 
	}
	m="cashcashierposmst"
	n=window.document.frmtrans.txtbranchcode.value
	p=window.document.frmtrans.txtcurrencycode.value
	sy="|"
	f="frmtrans"
	st=f+sy+m+sy+n+sy+p
	//alert(st)
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="masterdenom.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()    
	
}

//posts to serverside page to do transactions 
function Insert()
{
	var i,n,p,a,b,c
	var k=1,a="",b="",c=""
	//alert("p="+p)
	///checking if counterno or cashier id is null
	if(window.document.frmtrans.txtCashierID.value=="")
	{
		alert("Select Cashier Id")
		return;
	}
	if(window.document.frmtrans.txtCounterNo.value=="")
	{
		alert("Select Counter No")
		return;
	}
	if(eval(window.document.frmtrans.txtAmount.value)>0)
	{
		if (CashDenom=='Y')
		{	
		if (eval(window.document.frmtrans.txtAmount.value)==eval(window.document.frmtrans.txttotal.value))
		{
			p=window.document.frames(0).frmdm.hcnt.value
			///for multiple text boxes(denominations)
			if(window.document.frames(0).frmdm.txtpieces.length>0)
			{		
				for(i=0;i<=p-1;i++)
				{
					if(window.document.frames(0).frmdm.txtpieces(i).value!=0)
					{
						k=k+1
						a1=window.document.frames(0).frmdm.hps(i).value
						a=a+a1+"|"
						b1=window.document.frames(0).frmdm.txtpieces(i).value
						b=b+b1+"|"
						c1=window.document.frames(0).frmdm.htype(i).value
						c=c+c1+"|"
					}
				}	
			}
			else
			{
				
				for(i=0;i<=p-1;i++)
				{
					if(window.document.frames(0).frmdm.txtpieces.value!=0)
					{
						k=k+1
						a1=window.document.frames(0).frmdm.hps.value
						a=a+a1+"|"
						b1=window.document.frames(0).frmdm.txtpieces.value
						b=b+b1+"|"
						c1=window.document.frames(0).frmdm.htype.value
						c=c+c1+"|"
					}
				}		
			}	 
			
		
		}	
		else
		{
			alert("Amounts should be Equal")
			return
		}	
	}
	}/// Denomination if condition
	else
	{
		alert('Amount Should not be Null')
		window.document.frmtrans.txtAmount.focus()
		return
 	
	}
	window.document.frmtrans.hcount.value=k   
	window.document.frmtrans.hvalue.value=a
	window.document.frmtrans.hpices.value=b
	window.document.frmtrans.htype.value=c
	window.document.frmtrans.action="cashtransferallotmentinsert.aspx"
	window.document.frmtrans.method ="post"
	window.document.frmtrans.submit()

}
///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {
 
 ///string values in variables 
 sCur=window.document.frmtrans.txtcurrencycode.value
sBr=window.document.frmtrans.txtbranchcode.value
sCnt=window.document.frmtrans.txtCounterNo.value
sBr=sBr.toUpperCase()
sCur=sCur.toUpperCase()
sCashId=window.document.frmtrans.txtCashierID.value
sCashId=sCashId.toUpperCase()
sUser="<%=session("userid")%>"
//for cashier description 
if(strTxt=="txtCashierID")
{
if(window.document.frmtrans.txtCashierID.value=="")
{
return;
}
st="DescDisplay"+"*"+"cashcountermst cash,genusermst gen"+"*"+"gen.name"+
	"*"+
		"cash.branchcode='" + sBr + "' and cash.currencycode='" + sCur + "' and " +
		"cash.cashierid='"+ sCashId +"' and "+
		"cash.cashierid=gen.userid and cash.cashierid not in ('" + sUser +"')"+
	"*"+strTxt
}
if(strTxt=="txtCounterNo")
{
if(window.document.frmtrans.txtCounterNo.value=="")
{
	return
}
st="DescDisplay"+"*"+"CASHCOUNTERMST"+"*"+"distinct(counterno)"+
	"*"+"branchcode='" + sBr + "' and currencycode='" + sCur +  "' and "+
	"counterno='"+sCnt+"' and "+
	"cashierid not in ('" + sUser + "')"+
	"*"+strTxt
}

if(strTxt=="AmountChk")
	{
	
	sBr=window.document.frmtrans.txtbranchcode.value
	sCur=window.document.frmtrans.txtcurrencycode.value.toUpperCase()
sBr=sBr.toUpperCase()
sCashId=window.document.frmtrans.txtCashierID.value
sCashId=sCashId.toUpperCase()
sCnt=window.document.frmtrans.txtCounterNo.value
sAmt=window.document.frmtrans.txtAmount.value

if((sAmt!="")||(eval(sAmt)>0))
{

st="AmountCheck"+"~"+sBr+"~"+sCur+"~"+sCashId+"~"+sCnt+"~"+
window.document.frmtrans.txtAmount.value+"~"+strTxt

}
	
	}
//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="getcounternocashier.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
 }
 ///functions for displaying the descriptions which is returned in iframe page 
 function DescDisplay(stri)
 {
 
	var StrMain=new String()
	var StrFlds=new String()
	StrMain=stri.split("~")
	StrFlds=StrMain[0].split("|")
	//displaying the cashiername
	if(StrMain[1]=="txtCashierID")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid Cashier ID")
			splitString("window.document.frmtrans","txtCashierID,"+
			"txtCashierName,txtCounterNo,txtAmount,txtNarration")
			return;
		}
		window.document.frmtrans.txtCashierName.value=StrFlds[0]
		Getcounterid()
	}	
	//for counterno
	if(StrMain[1]=="txtCounterNo")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid CounterNo")
			splitString("window.document.frmtrans","txtCounterNo,txtAmount,txtNarration")
			return;
		}
		
		Getcounterid()
	}
	//checking the amount alloted is exceeding the max cashlimit of selected
 //cashier and counter
 
	if(StrMain[1]=="AmountChk")
	{
		
		if(StrMain[0].toUpperCase()!="YES")
		{
			strcheck=confirm(StrFlds[0]+"  Do You Want To Continue! ")
			if(strcheck!=true)
			{
				return;
			}
			
		}
		
		
	}
		
 }
 //function for Amount is exceeding the total amount of login user in 
 ///cash cashierposmst
 function AmtCheck()
 {
 if(eval(window.document.frmtrans.txtAmount.value)<0)
 {
 return;
 }
 if(eval(window.document.frmtrans.txtAmount.value)>
 eval(window.document.frmtrans.txtavtotal.value))
 {
	alert("Amount is Exceed the Total Amount of login user: "+"<%=session("userid")%>")
	window.document.frmtrans.txtAmount.value=""
	window.document.frmtrans.txtAmount.focus()
	return;
 }
 
 }
 ///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	//alert(strtran)
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
		alert(strtran)
		window.location.href="cashtransferallotment.aspx" 
		
	}
}	

//-->
</SCRIPT>
<title></title>
</head>
<body topmargin="0" leftmargin="0" 
onload="denom();GetMenu(&quot;<%=session("menustring")%>&quot;);DispTranMsg()">

<form name="frmtrans" id="frmtrans">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="15%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>Cash Transfer Between Counters</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain" height="588">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="22%" ></td>
          <td width="89%" >

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%"><img name="placeholder" border="0" src="file://Comsvr/c/ASPTest/dscript42/transparent.gif" width="1" ></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

       <%appdate=formatdatetime(session("Applicationdate"),1)%>

      

     <!--- <table align="center" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td height="15"><font class="textblue">
          <p align="center"></font></td>
        </tr>
      </table> --->

      <div align="center">
        <center>

        <table border="0" width="98%" cellspacing="0" cellpadding="0" bordercolor="#7D5445">
          <tr>
            <td width="100%">
            <div align="center">
              <center>

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr class="bgcolor">
                  <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp; Branch Code&nbsp;</td>
                  <td width="32%"><input name="txtbranchcode" size="9" 
                  value="<%=session("branchcode")%>" readonly class="txtautofill"><input 
                  type="button" class="button" 
                  value=" L " name="buttbr" disabled onclick="branch()"><input 
                  name="txtbranchdesc" size="16" 
                  class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
                  
                  <td width="15%" align="right">Currency Code&nbsp;</td>
                  <td width="32%"><input 
                  name="txtcurrencycode" 
                  value="<%=session("currencycode")%>" size="9" class="txtautofill"
                  readonly><input type="button" class="button" value=" L " 
                  name="buttcur" disabled
                  onclick="currency()"><input 
                  name="txtcurrencydesc" size="16" 
                  class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
                </tr>
              </table>

              </center>
            </div>
            </td>
          </tr>
          <tr>
            <td width="100%">

            <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td>
                <div align="center">
                  <center>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0" bordercolor="#7D5445">
                    <tbody>
                      <tr>
                        <td width="488" valign="top">
                        <div align="center">
                          <center>

                          <table width="98%" cellpadding="0" class="tableborder2">
                            <tr>
                              <td width="51%" valign="top">

                              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td width="100%" height="5" colspan="2"></td>
                                </tr>
                                <tr>
                                  <td width="100%" height="5" colspan="2">

                                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                    <tr class="bgcolor">
                                      <td width="24%"></td>
                                      <td width="41%">
                                      <p align="center"><font class="subheading">Cashier
                                      Details</font>
                                      <td width="35%"></td>
                                    </tr>
                                  </table>

                                  </td>
                                </tr>
                                <tr>
                                  <td width="100%" height="15" colspan="2"></td>
                                </tr>
                                <tr>
                                  <td width="15%" height="28">&nbsp; To Cashier
                                  ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                  <td width="32%" height="28"><input name="txtCashierID" class="txtautofill"
                                  size="9"  maxlength=20; style="TEXT-TRANSFORM: uppercase"
                                  onblur='Dataarrange(window.document.frmtrans.txtCashierID);
                                  DescrptionDisp("txtCashierID")' 
                                  style="TEXT-ALIGN: left"><input type="button" class="button" value=" L " name="cmdCashierId" onclick="CashierMgt()"><font size="2" face="MS Sans Serif"><input name="txtCashierName" size="15" class="bgcolor1"></font></td>
                                </tr>
                                <tr>
                                  <td width="15%" height="28">&nbsp; To Counter
                                  ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                  <td width="32%" height="28"><input 
                                  name="txtCounterNo" size="9"  maxlength=6 class="txtautofill"
                                  onkeypress='numeric()' onblur='DescrptionDisp("txtCounterNo")'
                                   ><input 
                                  name="cmdcounterId" onclick="Counter()" 
                                  type="button" class="button" value=" L "></td>
                                </tr>
                               
                                <tr>
                                  <td width="15%" height="28">&nbsp;
                                  Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                  <td width="32%" height="28"><input name="txtAmount" class="txtautofill"
                                  size="9" value="0.00" style="TEXT-ALIGN: right" maxlength=16
                                  onfocus="amtselect(window.document.frmtrans.txtAmount)" 
                                  onkeypress="numdec(window.document.frmtrans.txtAmount.value,
                                  window.document.frmtrans.hpr.value);"
                                  onblur='precision(window.document.frmtrans.txtAmount,
                                  window.document.frmtrans.hpr.value);
                                  CheckZero(window.document.frmtrans.txtAmount);AmtCheck();DescrptionDisp("AmountChk")'></td>
                                </tr>
                                <tr>
                                  <td width="31%" height="28">&nbsp;
                                  Narration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                  <td width="69%" height="28"><input name="txtNarration" size="29" maxlength=80 
                                  onblur='Dataarrange(window.document.frmtrans.txtNarration)' 
                                  ></td>
                                </tr>
                                <tr>
                                  <td width="116%" height="24" colspan="2">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width="116%" height="27" colspan="2">&nbsp;</td>
                                </tr>
                                
                              </table>

                            </tr>
                          </table>

                          </center>
                        </div>
                        <td width="378" valign="top">
                        <div align="center" id="divden">
                          <div align="center" id="denom">
                            <center>

                            <table width="95%" cellpadding="0" class="tableborder2">
                              <tr>
                                <td>

                                <table border="0" width="70%" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="100%">
                                    <div align="center">
                                      <center>

                                      <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                        <tr>
                                          <td width="100%" align="middle" valign="top">
                                          <td align="middle" valign="top"><iframe  id="den" align=center          
                  frameborder=0 framespacing=0 noresize height=380 width=360 
                              valign="top" src="masterdenom.aspx" 
                              style="BACKGROUND-COLOR: darkred"></iframe></td>
                                        </tr>
                                      </table>

                                      </center>
                                    </div>
                                </table>

                            </table>

                            </center>
                          </div>
                        </div>
                        </td>
                      </tr>
                    </center>
                  </table>

                </div>
                <center></center><input name="hidpieces" type="hidden">

                <table border="0" width="100%" cellspacing="0" cellpadding="0" height="21">
                  <tr>
                    <td width="386" height="5"></td>
                    <td width="14" height="5"></td>
                    <td width="64" height="5"></td>
                    <td width="208" height="5"></td>
                    <td width="83" height="5"></td>
                  </tr>
                  <tr>
                    <td width="386" height="21">
                    
                    </td>
                    <td width="5%" height="21"></td>
                    <td width="5%" height="21"></td>
                    <td width="5%" align="center"><font class="textred"><span id="total" style="VISIBILITY: visible">Amount</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtavtotal" size="9" value="0.00" class="bgcolor1" readonly style="TEXT-ALIGN: right" ></td>
                    
                    <td width="83" height="21"><input name="txttotal" size="8" value="0.00" class="bgcolor1" readonly style="TEXT-ALIGN: right" onchange="amountdigits(window.document.frmtrans.txttotal)"></td>
                  </tr>
                </table>
                
                <div align="center">
                      <center>

                      <table width="20%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="100%">
                          <p align="center"><input name="cmdok" onclick="Insert()" type="button" 
                          value="   Ok   " class="button"><input 
                          type="reset" value="Cancel" name="cmdcancel" 
                          onclick="location.href=&quot;cashtransferallotment.aspx&quot;" 
                          class="button"><input type="button" class="button" value="   Exit   " 
                          name="cmdexit" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;" class="bgcolor"></p>
                          </td>
                        </tr>
                      </table>

                      </center>
                    </div>
                
                
                
				<table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="getcounternocashier.aspx">
                                              </iframe>
      </td>
    </tr>
  </table>
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%" height="5">
                  <tr>
                    <td width="100%">
                  </tr>
                  <tr>
                    <td width="100%" height="5">
                </table>

                </center>
            </table>

        </tr>
        </table>

      </div>
      </td>
    </tr>
  </table>

<input type="hidden" name="txtctotal">  <input type="hidden" name="hdate" value="<%=appdate%>"><input type="hidden" name="htype"><input type="hidden" name="hvalue"><input type="hidden" name="hpices"><input type="hidden" name="hcount"><input type="hidden" name="hpr">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="90%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%"><iframe id="ibills" align=center 
            frameBorder=0 frameSpacing=0  height=0 width=0 src="billsonblu.aspx">
            </iframe>
            </td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
  </table>

  <p>&nbsp;</p>
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</form>

</body>

</html>
