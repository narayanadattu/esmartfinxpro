<%@ Page CodeBehind="cashmasters.aspx.vb" Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Inherits="eSmartDotNet.cashmasters" %>
<html>

<head>
<!---<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document"> 
<frameset framespacing="0" border="0" frameborder="0" rows="100,*">
  <frame name="banner" scrolling="no" noresize target="contents" src="menu.aspx"> 
  <frameset framespacing="0" border="0" frameborder="0" cols="10%,75%">
    <frame src="cashmastergifs.aspx" frameborder="0" scrolling="auto">
    <frame src="blankcash.aspx" frameborder="0" name="forms" scrolling="auto">
  </frameset>
  <noframes> -->
  <link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Master</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>

<SCRIPT LANGUAGE=javascript>
<!--
var st,val,flag
var mode

var cnt
cnt="<%=cnt%>"

function branch()
{
    
	window.document.frmcashiertype.txtbranchdesc.value=""
	window.document.frmcashiertype.txtcurrencycode.value=""
	window.document.frmcashiertype.txtcurrencydesc.value=""
	window.document.frmcashiertype.txtcashiertype.value=""
	window.document.frmcashiertype.txtnarration.value=""
	window.document.frmcashiertype.txtCashBranchcode.value=""
	window.document.frmcashiertype.txtCashBranchdesc.value=""

	window.document.frmcashiertype.txtCashCurrencyCode.value=""
	window.document.frmcashiertype.txtCashCurrencyDesc.value=""

	st="Branch"
	
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
    
    			
}	 
// To assign the values for the respective branch related text boxes
function Branchid(kstr)
{
	if(window.document.all.divCashierType.style.display=="block")
	{
		assign(kstr,window.document.frmcashiertype.txtbranchdesc,window.document.frmcashiertype.txtbranchcode)
	}
	if(window.document.all.divCashCounter.style.display=="block")
	{
		assign(kstr,window.document.frmcashiertype.txtCashBranchdesc,window.document.frmcashiertype.txtCashBranchcode)
	}
}	 

// To get the values for the currencycode

function currency()
{
	window.document.frmcashiertype.txtcashiertype.value=""
	window.document.frmcashiertype.txtnarration.value=""
	
	st="Currency"
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
}

// To assing the values for the respective currency related text boxes
function Currencyid(kstr)
{
	if(window.document.all.divCashierType.style.display=="block")
	{
		assign(kstr,window.document.frmcashiertype.txtcurrencydesc,window.document.frmcashiertype.txtcurrencycode)
	}
	if(window.document.all.divCashCounter.style.display=="block")
	{
		assign(kstr,window.document.frmcashiertype.txtCashCurrencyDesc,window.document.frmcashiertype.txtCashCurrencyCode)
	}
}


function query()
{
	stc=window.document.frmcashiertype.txtbranchcode.value
	stb=window.document.frmcashiertype.txtcurrencycode.value 
	st="cashiertypes"+"|"+stc+"|"+stb
	
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:390px;DialogHeight:180px;DialogLeft:190px;DialogTop:200px");
	
 
}

function cashiertypes(kstr)
{
	
   k=kstr.split("-----")
   st=k[1]
   window.document.frmcashiertype.txtcashiertype.value=k[1]
   window.document.frmcashiertype.txtnarration.value=k[0]
   
   callfl()
   
}


function callfl()
{
	var sCash=window.document.frmcashiertype.txtcashiertype.value
	st=sCash+"~CashierDetails"
	//window.open("cashmasterfly.aspx"+ "?"+"st="+st,"cashier","width=1,height=1,left=0,top=0")
		//Window.document.all["iBatch"].src="cashmasterfly.aspx"
		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="cashmasterfly.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
}

function flycash(kstr)
{
   k=kstr.split("|")
   window.document.frmcashiertype.cmbpayments.value=k[0]
   window.document.frmcashiertype.cmbreceipts.value=k[1]
   window.document.frmcashiertype.cmbtellerreceipts.value=k[2]
   window.document.frmcashiertype.cmbtellerpayments.value=k[3]
   
}

function rdentry_onclick()
 {
   
   if(window.document.frmcashiertype.rdentry(3).checked==true)
   {
     query()
     with(window.document.frmcashiertype)
         {
           butok.disabled=true
           txtcashiertype.readOnly=true
           txtnarration.readOnly=true
           cmbreceipts.disabled=true
		   cmbpayments.disabled=true
		   cmbtellerpayments.disabled=true
		   cmbtellerreceipts.disabled=true
         }  
    
     
   } 
   else if(window.document.frmcashiertype.rdentry(0).checked==true)
   { 
    
     with(window.document.frmcashiertype)
     {   
        txtcashiertype.value=""
        txtnarration.value=""
        txtcashiertype.readOnly=false
        txtnarration.readOnly=false
        txtcashiertype.focus()
        butok.disabled=false
        txtcashiertype.focus()
        cmbreceipts.disabled=false
		cmbpayments.disabled=false
		cmbtellerpayments.disabled=false
		   cmbtellerreceipts.disabled=false
     }   
        
   } 
   else if(window.document.frmcashiertype.rdentry(1).checked==true)
   {    
        window.document.frmcashiertype.txtcashiertype.value=""
        window.document.frmcashiertype.txtnarration.value=""
        window.document.frmcashiertype.cmbpayments.value="N"
        window.document.frmcashiertype.cmbreceipts.value="N"
        query()
        
        with(window.document.frmcashiertype)
        {
		   butok.disabled=false
		   txtcashiertype.readOnly=true
		   txtnarration.readOnly=false
		   cmbreceipts.disabled=false
		   cmbpayments.disabled=false
		   cmbtellerpayments.disabled=false
		   cmbtellerreceipts.disabled=false
		}   
   }		
  
  else if(window.document.frmcashiertype.rdentry(2).checked==true)
   {    
        window.document.frmcashiertype.txtcashiertype.value=""
        window.document.frmcashiertype.txtnarration.value=""
        window.document.frmcashiertype.cmbpayments.value="N"
        window.document.frmcashiertype.cmbreceipts.value="N"
        query()
        with(window.document.frmcashiertype)
        {
		   butok.disabled=false
		   fl=false
		   txtcashiertype.readOnly=true
		   txtnarration.readOnly=true
		   cmbreceipts.disabled=true
		   cmbpayments.disabled=true
		   cmbtellerpayments.disabled=true
		   cmbtellerreceipts.disabled=true
		}   
    }		
  } 

function butok_onclick() 
{
  if(window.document.frmcashiertype.rdentry(0).checked==true)
  { 
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
		stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="INSERT"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
		alert(" Reddy = 3")
	}
  }
  else if(window.document.frmcashiertype.rdentry(1).checked==true)
  {
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
    stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="MODIFY"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
	}
  }
  else if(window.document.frmcashiertype.rdentry(2).checked==true)
  { 
    if(window.document.frmcashiertype.txtcashiertype.value==""||window.document.frmcashiertype.txtnarration.value=="")
    alert("Mandatory fields cannot be null")
    else
    {
		stt="CashierTypeMst"
		window.document.frmcashiertype.status.value=""
		window.document.frmcashiertype.status.value="DELETE"
		window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
		window.document.frmcashiertype.method="post"
		window.document.frmcashiertype.submit()
	}
  }

}


function butcancel_onclick()
 {
   location.replace("cashmasters.aspx")
 }

/*function butexit_onclick() 
{
   //location.replace("blankcash.aspx")
    window.parent.window.location.replace("MASTERmodule.aspx")
}*/

function txtcashiertype_onkeypress()
 {
   if((window.document.frmcashiertype.txtcashiertype.value).length>20)
   event.keyCode=0
 }
 
function txtnarration_onkeypress() 
{
   if((window.document.frmcashiertype.txtnarration.value).length>40)
   event.keyCode=0
}

function DescrptionDisp(strTxt)
 {
		sBr=window.document.frmcashiertype.txtbranchcode.value.toUpperCase()
		sCur=window.document.frmcashiertype.txtcurrencycode.value.toUpperCase()
		sCash=window.document.frmcashiertype.txtcashiertype.value.toUpperCase()

	//for cashier description 
if(strTxt=="txtbranchcode")
{
		window.document.frmcashiertype.txtbranchdesc.value=""
		window.document.frmcashiertype.txtcurrencycode.value=""
		window.document.frmcashiertype.txtcurrencydesc.value=""
		window.document.frmcashiertype.txtcashiertype.value=""
		window.document.frmcashiertype.txtnarration.value=""
	if(window.document.frmcashiertype.txtbranchcode.value=="")
		{
			return;
		}


		st="GENBANKBRANCHMST"+"~"+"BRANCHNAME"+
			"~"+"branchcode='"+sBr+"'"+
			"~"+strTxt+"~"+"DescDisplay"
 }
	//for cashier description 
if(strTxt=="txtcurrencycode")
{

			window.document.frmcashiertype.txtcurrencydesc.value=""
			window.document.frmcashiertype.txtcashiertype.value=""
			window.document.frmcashiertype.txtnarration.value=""
		if(window.document.frmcashiertype.txtbranchcode.value=="")
		{
		alert("Select BranchCode")
		return;
		}

	  if(window.document.frmcashiertype.txtcurrencycode.value=="")
	   {
	     return;
	   }

		st="GENCURRENCYTYPEMST"+"~"+"narration"+
			"~"+"currencycode='"+sCur+"'"+
			"~"+strTxt+"~"+"DescDisplay"
}
///for duplicate cashier checking
 if(strTxt=="CashierCheck")
		{
			st="CASHCASHIERTYPEMST"+"~"+"CASHIERTYPEID"+
			"~"+"branchcode='"+sBr+"' and currencycode='"+sCur+"' and "+
			"CASHIERTYPEID='"+sCash+"'"+
			"~"+strTxt+"~"+"DescDisplay"	
		}

//post to ifrmae page to get desciptions
		
		Window.document.all["iBatch"].src="counter.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="counter.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
}


///function for sending parameters to display the description on blur event
 ///displaying the counterno
function Allot(kstr)
{

	var StrMainFld=new String()
	StrMainFld=kstr.split("~")
	StrFlds=StrMainFld[0].split("|")
	
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtbranchcode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid BranchCode ")
			window.document.frmcashiertype.txtbranchcode.value=""
			window.document.frmcashiertype.txtbranchdesc.value=""
			return;
		}
		window.document.frmcashiertype.txtbranchdesc.value=StrFlds[0]
		
		
	}
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtcurrencycode")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid CurrencyCode ")
			window.document.frmcashiertype.txtcurrencycode.value=""
			window.document.frmcashiertype.txtcurrencydesc.value=""
			return;
		}
		window.document.frmcashiertype.txtcurrencydesc.value=StrFlds[0]
	
	}
	///for duplicate cashiers checking
	if(StrMainFld[1]=="CashierCheck")
	{
		if(StrFlds[0]!="No")
		{
			alert("Cashier Type Already exists ")
			window.document.frmcashiertype.txtcashiertype.value=""
			window.document.frmcashiertype.txtnarration.value=""
			return;
		}
	}
}


///function for checking the login user is abb or not 
  function abbcheck()
	 {
		
		AbbStatus="<%=session("abbuser")%>"
		
		if(AbbStatus.toUpperCase()=="Y")
		{
		window.document.frmcashiertype.buttbr.disabled=false
		window.document.frmcashiertype.txtbranchcode.readOnly=false
		window.document.frmcashiertype.buttbr.focus()
		}
		else
		{
		window.document.frmcashiertype.buttbr.disabled=true
		window.document.frmcashiertype.txtbranchcode.readOnly=true
		
		}
		
	}

	///function for checking the duplicate cashiers 
  function cashiercheck()
   {
    if(window.document.frmcashiertype.rdentry[0].checked==true)
     {
     DescrptionDisp("CashierCheck")
     }
   }
   
  
///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	      alert(strtran)
		window.location.href="cashmasters.aspx" 
		
	}
}	

function ShowDivision(str)
{
	window.document.all.divCashierType.style.display="none"
	window.document.all.divCashCounter.style.display="none"
	window.document.all.divExit.style.display="none"
	
	if(str=="0")//for cashier type
	{
		window.document.all.divCashierType.style.display="block"
	}
	if(str=="1")//for cash counter
	{
		window.document.all.divCashCounter.style.display="block"
	}
	if(str=="2")//for exit
	{
		window.document.all.divExit.style.display="block"
	}
}
//to get Counterno for selected branchcode,currencycode
function Counter()
{
 

	sBr=window.document.frmcashiertype.txtCashBranchcode.value
	sCur=window.document.frmcashiertype.txtCashCurrencyCode.value
	
	if(sBr=="")
	{
		alert("select BranchCode")
		return
	}
	
	if(mode=="ADD")
	{
		if(sCur=="")
		{
			alert("Select CurrencyCode")
			return;
		}
	}
	
	sBr=sBr.toUpperCase()
	sCur=sCur.toUpperCase()
	window.document.frmcashiertype.MfgCurrency.Rows=1
	
	st="CounterNo|"+sBr+"|"+sCur
	
	window.showModalDialog("Listmaster.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
// To assing the values for the respective currency related text boxes
function Counterid(kstr)
{

var StrFlds=new String()
StrFlds=kstr.split("-----")
	window.document.frmcashiertype.txtCode.value=StrFlds[1]
	window.document.frmcashiertype.txtDesc.value=StrFlds[0]
	sBr=window.document.frmcashiertype.txtCashBranchcode.value
	sCode=window.document.frmcashiertype.txtCode.value
		st="CurrencyDet~"+sBr+"~"+sCode
		//Window.document.all["iBatch"].src="cashmasterfly.aspx"
		window.document.frames(0).frmacc.hFlds.value=st
		window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		window.document.frames(0).frmacc.method="post"
		window.document.frames(0).frmacc.submit();
	
}

//this function is used to set mode status depending upon the the option buttons clicked
function modeStatus()
{
	if(window.document.frmcashiertype.optTran(0).checked==true)
	{
		mode="ADD"
	}
	else if(window.document.frmcashiertype.optTran(1).checked==true)
	{
		mode="MODIFY"
	}
	else if(window.document.frmcashiertype.optTran(2).checked==true)
	{
		mode="DELETE"
	}
	else if(window.document.frmcashiertype.optTran(3).checked==true)
	{
		mode="VIEW"
	}
}
// sending parameters to display the description of seleted code 
///i.e this is send to code text boxes onblur event
function DescriptionDisp(StrTxt)
{

/// for displaying the branchdescription for selected branch code
///if mode="MODIFY" then only work this function
 if(mode=="Add")
 {
 return;
 }
 
	if(StrTxt=="txtCode")
	{
		if(window.document.frmcashiertype.txtCode.value=="")
		{
		return;
		}
		sCode=window.document.frmcashiertype.txtCode.value
		sBr=window.document.frmcashiertype.txtCashBranchcode.value
		sCur=window.document.frmcashiertype.txtCashCurrencyCode.value
		sCur=sCur.toUpperCase()
		sCode=sCode.toUpperCase()
		sBr=sBr.toUpperCase()
		st="Cashcountermst~narration~counterno='"+sCode+"' and "+
		"upper(trim(branchcode))='"+sBr+"'"+
		"~~"+
			StrTxt+"~CounterDetails"
		window.document.frmcashiertype.MfgCurrency.Clear()
	window.document.frmcashiertype.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmcashiertype.MfgCurrency.Rows=1	
		window.document.all["iBatch"].src="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
	}
		
}
/// function is used to displaying the values in client 
/////side page which is coming from fly page
function flycash(kstr)
{

var StrArrMain=new String()
var StrArrFld=new String()
var StrArrRow=new String()
//split the kstr
StrArrMain=kstr.split("~")
StrArrFld=StrArrMain[0].split("|")
///for displaying branchdesc
	if(StrArrMain[1]=="txtCode")
	{
		if(StrArrFld[0]=="No")
		{
		alert("Invalid Counter No")
		window.document.frmcashiertype.txtCode.value=""
		window.document.frmcashiertype.txtDesc.value=""
		return;
		}
		sBr=window.document.frmcashiertype.txtCashBranchcode.value
		sCode=window.document.frmcashiertype.txtCode.value
		window.document.frmcashiertype.txtDesc.value=StrArrFld[0]
		st="CurrencyDet~"+sBr+"~"+sCode
		
		window.document.all["iBatch"].src="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.hFlds.value=st
		//window.document.frames(0).frmacc.action="CashMasterfly.aspx"
		//window.document.frames(0).frmacc.method="post"
		//window.document.frames(0).frmacc.submit();
	}
	//for existing currencycode adding to grid for selected counter no which are
	//coming from iframe page
	else if(StrArrMain[1]=="Currency")
	{
		var StrRow=new String()
		var StrCol=new String()
		StrRow=StrArrMain[0].split("|")
		
		for(icnt=0;icnt<=StrRow.length-1;icnt++)
		{
			window.document.frmcashiertype.MfgCurrency.Rows=
			window.document.frmcashiertype.MfgCurrency.Rows+1
			StrCol=StrRow[icnt].split("*")
			window.document.frmcashiertype.MfgCurrency.TextMatrix(icnt+1,0)=StrCol[0]//currencycode
			window.document.frmcashiertype.MfgCurrency.TextMatrix(icnt+1,1)=StrCol[1]//currencydesc
			
			
		}
		window.document.frmcashiertype.MfgCurrency.Rows=
			window.document.frmcashiertype.MfgCurrency.Rows-1
	}
}			
//function for clearing fields
function clearFlds()
{
window.document.frmcashiertype.txtCode.value=""
window.document.frmcashiertype.txtDesc.value=""
window.document.frmcashiertype.MfgCurrency.Clear()
	window.document.frmcashiertype.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmcashiertype.MfgCurrency.Rows=1
}
///posts to server side page to do transactions 
function okClick()
{
//this function is not work id mode='VIEW'
if(mode=="VIEW")
{
return;
}
if((window.document.frmcashiertype.txtDesc.value=="")||
(window.document.frmcashiertype.txtCashBranchcode.value=="")||
(window.document.frmcashiertype.txtCashCurrencyCode.value==""))

{
alert("Enter all details")
return;
}
if(window.document.frmcashiertype.MfgCurrency.Rows==1)
{
alert("Enter Currency Code in Grid")
return;
}
///adding currencycode in the grid to hidden field
	for(icnt=1;icnt<=window.document.frmcashiertype.MfgCurrency.Rows-1;icnt++)
	{
		window.document.frmcashiertype.hCur.value=window.document.frmcashiertype.hCur.value+
			window.document.frmcashiertype.MfgCurrency.TextMatrix(icnt,0)+"|"
	}
 /// post to server side page to do the transactions 	
  	stt="CashCounterMst"
  	
	window.document.frmcashiertype.status.value=mode
	window.document.frmcashiertype.action="cashmastersinsert.aspx?strng="+stt
	window.document.frmcashiertype.method="post"
	window.document.frmcashiertype.submit();
}
//disbaling the controls 
function enableControls()
{
	window.document.frmcashiertype.txtCode.disabled=false
	window.document.frmcashiertype.txtDesc.disabled=false
	//window.document.frmcashiertype.cmdlstCode.disabled=false
	window.document.frmcashiertype.cmdAddtoGrid.disabled=false
	window.document.frmcashiertype.cmdOk.disabled=false
}
///enabling the controls 
function DisbaleControls()
{
	window.document.frmcashiertype.txtCode.disabled=true
	window.document.frmcashiertype.txtDesc.disabled=true
	//window.document.frmcashiertype.cmdlstCode.disabled=true
	window.document.frmcashiertype.cmdAddtoGrid.disabled=true
	window.document.frmcashiertype.cmdOk.disabled=true
}
function AddtoGrid()
{
if(window.document.frmcashiertype.txtDesc.value=="")
{
alert("Enter Counter Description")
return;
}
if(window.document.frmcashiertype.MfgCurrency.Rows>=2)
{
kstr=confirm("Are You Sure to Allot one More currency to same counter?")
if(kstr==false)
{
	return;
}
}	
flexrow=window.document.frmcashiertype.MfgCurrency.Rows
	//checking if selected currencycode is already there in grid
	if(window.document.frmcashiertype.MfgCurrency.Rows>=2)
	{
	for(icnt=1;icnt<=window.document.frmcashiertype.MfgCurrency.Rows-1;icnt++)
	{
		if(window.document.frmcashiertype.MfgCurrency.TextMatrix
		(icnt,0)==window.document.frmcashiertype.txtCashCurrencyCode.value)
		{
			alert("Currency is already exists ")
			return;
		}
	}	
	}
	
			//st=st.toUpperCase()
				
		window.document.frmcashiertype.MfgCurrency.Rows=
		window.document.frmcashiertype.MfgCurrency.Rows+1
		window.document.frmcashiertype.MfgCurrency.TextMatrix(flexrow,0)=
		window.document.frmcashiertype.txtCashCurrencyCode.value
		window.document.frmcashiertype.MfgCurrency.TextMatrix(flexrow,1)=
		window.document.frmcashiertype.txtCashCurrencyDesc.value

}

//-->
</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function MfgCurrency_Click() {
if(window.document.frmcashiertype.optTran[3].checked==true)
{
return;
}
kstr=confirm("Are You Sure To Delete the Row")
if(kstr==true)
{
	if(window.document.frmcashiertype.MfgCurrency.Rows>2)
	{
		window.document.frmcashiertype.txtCashCurrencyCode.value=
		window.document.frmcashiertype.MfgCurrency.TextMatrix
		(window.document.frmcashiertype.MfgCurrency.row,0)
		
		window.document.frmcashiertype.txtCashCurrencyDesc.value=
		window.document.frmcashiertype.MfgCurrency.TextMatrix
		(window.document.frmcashiertype.MfgCurrency.row,1)	
		window.document.frmcashiertype.MfgCurrency.RemoveItem
		(window.document.frmcashiertype.MfgCurrency.Row)						
	}
	else
	{
		window.document.frmcashiertype.txtCashCurrencyCode.value=
		window.document.frmcashiertype.MfgCurrency.TextMatrix
		(window.document.frmcashiertype.MfgCurrency.row,0)
		window.document.frmcashiertype.txtCashCurrencyDesc.value=
		window.document.frmcashiertype.MfgCurrency.TextMatrix
		(window.document.frmcashiertype.MfgCurrency.row,1)
	window.document.frmcashiertype.MfgCurrency.Clear()
	window.document.frmcashiertype.MfgCurrency.FormatString=
	"CurrencyCode                      |> Description                                   "
	window.document.frmcashiertype.MfgCurrency.Rows=1
	}
}

}
	
//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=MfgCurrency EVENT=Click>
<!--
 MfgCurrency_Click()
//-->
</SCRIPT>
<body bgcolor="#C7BA95" topmargin="0" leftmargin="0" onload="abbcheck();modeStatus();DispTranMsg()">
  <form name="frmcashiertype">
  <div class="header">
	<table  cellpadding="0" cellspacing="0" width="99%">
		<tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr>
	</table>			
  </div>
  
  <div class="menuBar">
	<table cellpadding="0" cellspacing="0" width="100%" border="0">
		<tr>
			<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
			<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
			<td width="40%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Master</h2></td>
			<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
		</tr>
	</table>
  </div>
  <div id="menucontrol"></div>
  <!--- <p>The page uses frames but your browser doesnot support them</p> -->

  </body>
  <div id = "cashfrm">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebordermain">
		<tr>
			<td width="16%" valign="top">
				<table border="01" width="100%" cellspacing="1" cellpadding="0">
					<tr bgcolor="#99ccff" >
						<td width="100%" height="18"><a href="#" onclick="ShowDivision('0')">&nbsp;<font class="textbold">Cashier Type</font></a></td>
					</tr>
					<tr bgcolor="#99ccff">
						<td width="100%" height="18"><a href="#" onclick="ShowDivision('1')">&nbsp;<font class="textbold">Cash Counter</font></a></td>
					</tr>
					<tr bgcolor="#99ccff">
						<td width="100%" height="18"><a href="#" onclick="window.parent.window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module") & "module.aspx"%>&quot;">&nbsp;<font class="textbold">EXIT</font></a></td>
					</tr>
				</table>	
			</td>
			<td width="84%" valign="top">
			
			<div id="divCashierType" style="display:none">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
					<tr>
						<td width="100%" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Cashier Type" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
					</tr>
					<tr class="bgcolor">
						<td width="100%">
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr>
									<td width="20%">&nbsp;&nbsp;&nbsp;Branch Code</td>
									<td width="25%"><input name="txtbranchcode" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" value="<%=session("branchcode")%>" size="9" onblur='Dataarrange(txtbranchcode);DescrptionDisp("txtbranchcode")' style="HEIGHT: 22px; WIDTH: 66px" class="txtautofill"><input type="button" value=" L " name="buttbr" style="HEIGHT: 23px" onclick="branch()" class="button"><input name="txtbranchdesc" value="<%=session("branchnarration")%>" size="16" readonly style="HEIGHT: 22px; WIDTH: 116px" class="bgcolor1"></td>
									<td width="22%"><p align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
									<td width="29%"><input name="txtcurrencycode" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" value="<%=session("currencycode")%>" onblur='Dataarrange(txtcurrencycode);DescrptionDisp("txtcurrencycode")' size="9"  style="HEIGHT: 22px; WIDTH: 66px" class="txtautofill"><input type="button" value=" L " name="buttcur" style="HEIGHT: 23px" onclick="currency()" class="button"><input name="txtcurrencydesc" value="<%=session("currencynarration")%>" size="16" readonly style="HEIGHT: 22px; WIDTH: 116px" class="bgcolor1"></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
								<tr class="bgcolor1">
									<td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" checked language="javascript" onclick="return rdentry_onclick()">
									New</font></td>
									<td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
									Modify</font></td>
									<td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
									Delete</font></td>
									<td width="25%" align="middle"><font class="textblack"><input type="radio" name="rdentry" language="javascript" onclick="return rdentry_onclick()">
									View</font></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
								<tr>
									<td width="20%" height="10"></td>
									<td width="47%" height="10" colspan="4"></td>
									<td width="29%" align="left" height="10"></td>
								</tr>
								<tr>
									<td width="15%">&nbsp;&nbsp;Cashier Type&nbsp;&nbsp;</td>
									<td width="14%"><input size="12" name="txtcashiertype" 
									language="javascript" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onkeypress="return txtcashiertype_onkeypress()" onblur='Dataarrange(txtcashiertype);cashiercheck()' class="txtautofill"></td>
									<td width="19%" colspan="3">
									<p align="right">Narration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
									</td>
									<td width="29%" align="left"><input name="txtnarration" 
									style="HEIGHT: 22px; WIDTH: 143px" 
									language="javascript" onblur='Dataarrange(txtnarration)' onkeypress="return txtnarration_onkeypress()" size="20"></td>
								</tr>
								<tr>
									<td width="20%" height="15"></td>
									<td width="47%" height="15" colspan="4"></td>
									<td width="29%" height="15"></td>
								</tr>
								<tr>
									<td width="15%">&nbsp;&nbsp;Receipts&nbsp;&nbsp;</td>
									<td width="14%"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbreceipts">
									<option value="N" selected>N</option>
									<option value="Y">Y</option>
									</select></td>
									<td width="19%" colspan="3">
									<p align="right">Payments&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
									</td>
									<td width="29%" align="left"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbpayments">
									<option value="N" selected>N</option>
									<option value="Y">Y</option>
									</select></td>
								</tr>
								<tr>
									<td width="20%" height="15"></td>
									<td width="47%" height="15" colspan="4"></td>
									<td width="29%" height="15"></td>
								</tr>
								<tr>
									<td width="15%">&nbsp;&nbsp;Teller Receipts</td>
									<td width="14%"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbtellerreceipts">
									<option value="N" selected>N</option>
									<option value="Y">Y</option>
									</select></td>
									<td width="19%" colspan="3">
									<p align="right">Teller Payments&nbsp;&nbsp;&nbsp;</p>
									</td>
									<td width="29%" align="left"><select size="1" style="HEIGHT: 22px; WIDTH: 36px" name="cmbtellerpayments">
									<option value="N" selected>N</option>
									<option value="Y">Y</option>
									</select></td>
								</tr>
								<tr>
									<td width="20%" height="10"></td>
									<td width="14%" height="10"></td>
									<td width="14%" height="10"></td>
									<td width="7%" height="10"></td>
									<td width="12%" height="10"></td>
									<td width="29%" align="left" height="10"></td>
								</tr>
								</table>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<center>
							<table border="0" width="10%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%"><input type="button" value="    Ok    " 
									name="butok" language="javascript" onclick="return butok_onclick()" 
									class="button"><input type="button" value="Cancel" name="butcancel" 
									language="javascript" onclick="return butcancel_onclick()" 
									class="button"><!--<input type="button" value="   Exit   " name="butexit" language="javascript" onclick="return butexit_onclick()" class="bgcolor">--></td>
								</tr>
							</table>
							</center>
						</td>
					</tr>
					
				</table>
			</div>
			<div id="divCashCounter" style="display:none">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
					<tr>
						<td width="100%" height="15"><font color="#000000" size="3" class="textbold"><input name="lblothers" value="Cash Counter" class="button" size="37" style="text-align: Left; color: #FFFFFF; font-size: 8pt; font-family: MS Sans Serif; font-weight: bold; border-style: none" readonly></font></td>
					</tr>
					<tr>
						<td width="100%">
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tr class="bgcolor">
									<td width="15%"><p align="right">Branch Code&nbsp;&nbsp;&nbsp;</p></td>
									<td width="28%"><input name="txtCashBranchcode" size="9" style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" readonly value="<%=session("Branchcode")%>" id="txtCashBranchcode" maxlength="5" onblur="Dataarrange(txtCashBranchcode)" class="txtautofill"><input type="button" value=" L " name="cmdBranch" onclick="branch()" class="button"><input name="txtCashBranchdesc" size="16" value="<%=session("Branchnarration")%>" readonly></td>
					                  
									<td width="20%" align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;</td>
									<td width="30%"><input name="txtCashCurrencyCode" size="9" value="<%=session("Currencycode")%>"  style="TEXT-TRANSFORM: uppercase" style="TEXT-ALIGN: left" onblur="Dataarrange(txtCashCurrencyCode)" readonly maxlength="5" class="txtautofill"><input type="button" value=" L " name="cmdCurrency" onclick="currency()" class="button"><input name="txtCashCurrencyDesc" size="16" value="<%=session("Currencynarration")%>" readonly id="txtCashCurrencyDesc"></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<table border="0" width="100%" cellspacing="00" cellpadding="0" class="tableborder1">
								<tr class="bgcolor1">
									<td align="middle" width="26%"><p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;ADD&quot;;clearFlds();window.document.frmcashiertype.cmdlstCode.disabled=truewindow.document.frmcashiertype.txtCode.readOnly=true;window.document.frmcashiertype.txtDesc.readOnly=false;enableControls();window.document.frmcashiertype.txtCode.value=cnt" type="radio" value="INSERT" checked>New</font></p></td>
									<td align="middle" width="27%"><font class="textblack"><input name="optTran" onclick="mode=&quot;MODIFY&quot;;;clearFlds();window.document.frmcashiertype.cmdlstCode.disabled=false;window.document.frmcashiertype.txtCode.readOnly=false;window.document.frmcashiertype.txtDesc.readOnly=false;enableControls()" type="radio" value="MODIFY">Modify</font></td>
									<td align="middle" width="31%"><font class="textblack"><input name="optTran" onclick="mode=&quot;DELETE&quot;;;clearFlds();window.document.frmcashiertype.cmdlstCode.disabled=false;window.document.frmcashiertype.txtCode.readOnly=false;window.document.frmcashiertype.txtDesc.readOnly=false;enableControls();window.document.frmcashiertype.txtDesc.disabled=true;" type="radio" value="DELETE">&nbsp;Delete</font></td>
									<td align="middle" width="22%"><p align="center"><font class="textblack"><input name="optTran" onclick="mode=&quot;VIEW&quot;;;clearFlds();window.document.frmcashiertype.cmdlstCode.disabled=false;window.document.frmcashiertype.txtCode.readOnly=false;window.document.frmcashiertype.txtDesc.readOnly=true;DisbaleControls()" type="radio" value="VIEW">&nbsp;View&nbsp;&nbsp;</p></font></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<center>
								<table border="0" width="90%" cellspacing="0" cellpadding="0" class="tableborder2" align="center">
									<tr>
										<td width="5%" align="center" height="18"></td>
										<td width="30%" height="18"></td>
									</tr>
									<tr>
										<td width="5%" align="right" height="27"><font size="2" face="MS Sans Serif">&nbsp;&nbsp;Counter No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
										<td width="30%" height="27"><font size="2" face="MS Sans Serif"><input name="txtCode" size="18" maxlength="6" onkeypress="numeric()" style="TEXT-TRANSFORM: uppercase" readonly onblur="DescriptionDisp(&quot;txtCode&quot;)" class="txtautofill"></font><input type="button" value=" L " name="cmdlstCode" disabled onclick="Counter()" class="button"></td>
									</tr>
									<tr>
										<td width="5%" align="right" height="27"><font size="2" face="MS Sans Serif">&nbsp;Description&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
										<td width="30%" height="27"><font size="2" face="MS Sans Serif"><input name="txtDesc" size="30" 
										onblur='Dataarrange(txtDesc)' maxlength="50" onblur="Dataarrange(window.document.frmcashiertype.txtDesc)"></font></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td width="5%" align="left" height="15">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="cmdAddtoGrid" onclick="AddtoGrid()" type="button" value=" Ok " class="button"></td>
										<td width="57%" height="15"></td>
									</tr>
									<tr>
										<td width="100%" height="15" colspan="2">
										<p align="center">
			                      
				<OBJECT classid="clsid:88AD8DB1-906F-4826-881F-5018C6E1D6CE" height=113 id=MfgCurrency 
				name=MfgCurrency style="HEIGHT: 113px; LEFT: 0px; TOP: 0px; WIDTH: 361px" width=361 >
				<PARAM NAME="_ExtentX" VALUE="9551">
				<PARAM NAME="_ExtentY" VALUE="2990">
				<PARAM NAME="BackColor" VALUE="-2147483643">
				<PARAM NAME="ForeColor" VALUE="-2147483640">
				<PARAM NAME="Enabled" VALUE="-1">
				<PARAM NAME="BackStyle" VALUE="0">
				<PARAM NAME="BorderStyle" VALUE="1">
				<PARAM NAME="AllowBigSelection" VALUE="-1">
				<PARAM NAME="AllowUserResizing" VALUE="0">
				<PARAM NAME="Appearance" VALUE="1">
				<PARAM NAME="BackColorBkg" VALUE="8421504">
				<PARAM NAME="BackColorFixed" VALUE="-2147483633">
				<PARAM NAME="BackColorSel" VALUE="-2147483635">
				<PARAM NAME="CausesValidation" VALUE="-1">
				<PARAM NAME="Cols" VALUE="2">
				<PARAM NAME="ColWidth0" VALUE="2820">
				<PARAM NAME="DrawMode" VALUE="0">
				<PARAM NAME="FillStyle" VALUE="0">
				<PARAM NAME="FixedCols" VALUE="0">
				<PARAM NAME="FixedRows" VALUE="1">
				<PARAM NAME="FocusRect" VALUE="1">
				<PARAM NAME="ForeColorFixed" VALUE="-2147483630">
				<PARAM NAME="ForeColorSel" VALUE="-2147483634">
				<PARAM NAME="FormatString" VALUE=" CurrencyCode                      |> Description                                   ">
				<PARAM NAME="GridColor" VALUE="12632256">
				<PARAM NAME="GridColorFixed" VALUE="0">
				<PARAM NAME="GridLines" VALUE="1">
				<PARAM NAME="GridLinesFixed" VALUE="2">
				<PARAM NAME="GridLineWidth" VALUE="1">
				<PARAM NAME="MergeCells" VALUE="0">
				<PARAM NAME="MergeCol0" VALUE="0">
				<PARAM NAME="MergeRow0" VALUE="0">
				<PARAM NAME="MousePointer" VALUE="0">
				<PARAM NAME="OLEDropMode" VALUE="0">
				<PARAM NAME="PictureType" VALUE="0">
				<PARAM NAME="Redraw" VALUE="-1">
				<PARAM NAME="RightToLeft" VALUE="0">
				<PARAM NAME="RowHeightMin" VALUE="0">
				<PARAM NAME="Rows" VALUE="1">
				<PARAM NAME="ScrollBars" VALUE="3">
				<PARAM NAME="ScrollTrack" VALUE="0">
				<PARAM NAME="SelectionMode" VALUE="0">
				<PARAM NAME="TextStyle" VALUE="0">
				<PARAM NAME="TextStyleFixed" VALUE="0">
				<PARAM NAME="ToolTipText" VALUE="">
				<PARAM NAME="WhatsThisHelpID" VALUE="0">
				<PARAM NAME="WordWrap" VALUE="0">
				<PARAM NAME="ColAlignment0" VALUE="9">
				<PARAM NAME="ColData0" VALUE="0">
				<PARAM NAME="FixedAlignment0" VALUE="9">
				<PARAM NAME="FontWidth" VALUE="0">
				<PARAM NAME="hWnd" VALUE="0">
				<PARAM NAME="RowData0" VALUE="0">
				<PARAM NAME="RowHeight0" VALUE="240">
				<PARAM NAME="TextArray0" VALUE="CurrencyCode">
				<PARAM NAME="TextMatrix0" VALUE="CurrencyCode">
				<PARAM NAME="row" VALUE="">
				<PARAM NAME="col" VALUE="">
				<PARAM NAME="RowSel" VALUE="">
				<PARAM NAME="ColSel" VALUE="">
				<PARAM NAME="CellBackColor" VALUE="">
				<PARAM NAME="CellForeColor" VALUE=""></OBJECT>
										</td>
									</tr>
									<tr>
										<td width="43%" align="right" height="15"></td>
										<td width="57%" height="15"></td>
									</tr>
							</table>
						</center>
						</td>
					</tr>
					<tr>
						<td width="100%">
							<center>
							<table border="0" width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
								<tr>
									<td width="100%"><input name="cmdOk" onclick="okClick()" type="button" value="    Ok    " class="button"><input name="cmdCancel" onclick="window.location.href='cashmasters.aspx'" type="button" value="Cancel" class="button"></td>
								</tr>
							</table>
							</center>
						</td>
					</tr>
					
				</table>
			</div>
			<div id="divExit" style="display:none">
				<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
				
				</table>
			</div>
			
			</td>
		</tr>
	</table>
	
	<table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">
			<iframe id="iBatch" align=center frameBorder=0 frameSpacing=0 height=0 width=0 src="CashMasterFly.aspx"></iframe>
			<input type="hidden" name="status">
			<input type="hidden" name="hstr">
			<input type="hidden" name="hCur">
          </td>
        </tr>
      </table>
  </div>
  </form>
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	
		
</head>
</html>
