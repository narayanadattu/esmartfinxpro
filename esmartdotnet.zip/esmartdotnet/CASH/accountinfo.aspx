<%@ Page CodeBehind="accountinfo.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.accountinfo" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Customer Information</title>
<SCRIPT language="javascript" src="proc.js"></SCRIPT>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function btnmid_onclick() 
{
brcd=window.document.custform.hidbrcd.value 
st="Moduleid"+ brcd
window.open ("LGlist.asp"+"?"+"st="+st,"module","width=213%,height=150%,left=350,top=165")
window.document.custform.txtmid.value=""
window.document.custform.txtdesc1.value=""
window.document.custform.txtgcd.value=""
window.document.custform.txtdesc2.value=""
window.document.custform.txtano.value=""
window.document.custform.txtdesc3.value=""
window.document.custform.txtcid.value=""
}
function Modulecode(str)
  {
assign(str,window.document.custform.txtdesc1 ,window.document.custform.txtmid)
window.document.custform.txtdesc1.readOnly=true
window.document.custform.txtmid.readOnly=true  
  }

function btngcd_onclick() 
   {
   if(window.document.custform.txtmid.value!="")
  {
 brcd=window.document.custform.hidbrcd.value 
st1=window.document.custform.txtmid.value
st2="Glcode"   
st=st2+"|"+brcd+"|"+st1
window.open ("LGlist.asp"+"?"+"st="+st,"module","width=213%,height=150%,left=350,top=165")
}
else
{
alert('Module Id should not be null')
}  
   }
   
function Glid(str)
  {
  
assign(str,window.document.custform.txtdesc2 ,window.document.custform.txtgcd ) 
window.document.custform.txtdesc2.readOnly=true
window.document.custform.txtgcd.readOnly=true 
}

  

function btnano_onclick() 
{
if(window.document.custform.txtgcd.value!="")
{
st1=window.document.custform.txtmid.value
st2="AccCode"  
brcd=window.document.custform.hidbrcd.value
st3=window.document.custform.txtgcd.value 
st=st2+"|"+brcd+"|"+st1+"|"+st3
window.open ("LGlist.asp"+"?"+"st="+st,"module","width=213%,height=150%,left=350,top=165")
}
else
{
  alert('Gl Code should not be null')
  
}
}
function Accid(str)
  {
    strsp=str.split("-----")
    window.document.custform.txtano.value=strsp[1]
    window.document.custform.txtdesc3.value=strsp[0]
    window.document.custform.txtcid.value =strsp[2]
    window.document.custform.action ="custaddress.asp"
    window.document.custform.method ="post"
    window.document.custform.submit()
  }
  
  function Custidreturn()
{
 if(window.document.custform.txtcid.value!="")
 {
  cid=window.document.custform.txtcid.value
  cname=window.document.custform.txtdesc3.value
  add=window.document.custform.haddress.value
  str=cid+"|"+cname+"|"+add
  window.attachEvent(window.opener.custid(str))
  window.close()
}
else
{
alert('Customer Id should not be null')
}

}
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0">

<form name="custform">

  <table border="0" align="middle" width="100%" bordercolor="#7D5445" cellspacing="0" cellpadding="0" height="480">
    <tr>
      <td width="100%" valign="top">

      <table border="0" width="40%" cellspacing="0" cellpadding="0">
        <% bid=Request.QueryString("std")
         
         ms=Request.QueryString("star")
         ms1=split(ms,"|")
         
         if (ms<>"") then 
         ad1=ms1(7) 'address
         ad2=ms1(8)'address
         ad3=ms1(9)'address
         address=ad1&","&ad2&","&ad3%>
      
      
        <tr>
          <td width="100%" valign="top"><input type="hidden" name="haddress" value="<%=address%>">

          <table width="100%" cellspacing="0" cellpadding="0" style="height: 150px" class="tablebordermain">
            <tbody>
              <tr>
                <td width="107">

                <table width="331" cellspacing="0" cellpadding="0" id="TABLE1" style="height: 150px">
                  <tr>
                    <td width="84">&nbsp;Module ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td width="241"><input name="txtmid" value="<%=ms1(0)%>" size="9" readonly style="height: 22"><input type="button" value=" L " name="btnmid" language="javascript" onclick="return btnmid_onclick()" style="HEIGHT: 23px; WIDTH: 23px"><input name="txtdesc1" readonly size="18" value="<%=ms1(1)%>" style="height: 22"></td>
                  </tr>
                  <tr>
                    <td width="84">&nbsp;GL
                    Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td width="241"><input name="txtgcd" value="<%=ms1(2)%>" readonly size="9"><input type="button" value=" L " name="btngcd" language="javascript" onclick="return btngcd_onclick()" style="height: 21; width: 23"><input name="txtdesc2" value="<%=ms1(3)%>" readonly size="18"></td>
                  </tr>
                  <tr>
                    <td width="84">&nbsp;Account No&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td width="241"><input name="txtano" value="<%=ms1(4)%>" readonly size="9"><input type="button" value=" L " name="btnano" language="javascript" onclick="return btnano_onclick()" style="height: 21; width: 23"><input name="txtdesc3" value="<%=ms1(5)%>" readonly size="18"></td>
                  </tr>
                  <tr>
                    <td width="84">&nbsp;Customer Id&nbsp;&nbsp;&nbsp;</td>
                    <td width="232"><input name="txtcid" size="9" value="<%=ms1(6)%>" readonly style="HEIGHT: 22px; WIDTH: 169px"></td>
                  </tr>
                  <center></center><center>
                  <tr>
                    <td width="327" colspan="2">
                    <div align="center">
                      <center>

                      <table width="10%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="80%"><input type="button" value="    Ok   " name="B3" onclick="Custidreturn()" class="bgcolor"><input type="reset" value="Cancel" name="reset1" class="bgcolor"></td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                  </tr>
                  </table>

                </center></td>
              </tr>
          </table>

          </td>
        </tr>
        <tr>
          <td width="100%" valign="top" height="10"></td>
        </tr>
        <tr>
          <td width="100%" valign="top" height="10"></td>
        </tr>
      </table>

      </td>
    </tr>
  </table>

  <input type="hidden" name="hidbrcd" value="<%=bid%>">
</form>
<%else%>

<table>
  <tr>
    <td width="100%" valign="top">

    <table align="middle" border="1" width="330" bordercolor="#7D5445" cellspacing="0" cellpadding="0" style="height: 140px">
      <tbody>
        <tr>
          <td width="107">

          <table align="middle" border="1" width="331" bordercolor="#D9D2B3" cellspacing="0" cellpadding="0" id="TABLE1" style="height: 140px">
            <tr>
              <td width="85"><font size="2" face="MS Sans Serif">&nbsp;Module
              ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
              <td colspan="3" width="240"><font size="2" face="MS Sans Serif"><input name="txtmid" size="9" readonly><input type="button" value=" L " name="btnmid" language="javascript" onclick="return btnmid_onclick()" style="height: 22; width: 23"><input name="txtdesc1" readonly size="18"></font></td>
            </tr>
            <tr>
              <td width="85"><font size="2" face="MS Sans Serif">&nbsp;GL
              Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
              <td colspan="3" width="240"><font size="2" face="MS Sans Serif"><input name="txtgcd" readonly size="9"><input type="button" value=" L " name="btngcd" language="javascript" onclick="return btngcd_onclick()" style="height: 22; width: 23"><input name="txtdesc2" readonly size="18"></font></td>
            </tr>
            <tr>
              <td width="85"><font size="2" face="MS Sans Serif">&nbsp;Account
              No&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
              <td colspan="3" width="240"><font size="2" face="MS Sans Serif"><input name="txtano" readonly size="9"><input type="button" value=" L " name="btnano" language="javascript" onclick="return btnano_onclick()" style="height: 22; width: 23"><input name="txtdesc3" readonly size="18"></font></td>
            </tr>
            <tr>
              <td width="85"><font size="2" face="MS Sans Serif">&nbsp;Customer
              Id&nbsp;&nbsp;&nbsp;</font></td>
              <td width="231"><font size="2" face="MS Sans Serif"><input name="txtcid" size="9" readonly style="HEIGHT: 22px; WIDTH: 169px"></font></td>
            </tr>
            <center></center><center>
            <tr>
              <td width="327" colspan="4">
              <div align="center">
                <center>

                <table border="1" width="10%" bordercolor="#7d5445" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="80%"><font size="2" face="MS Sans Serif"><input type="button" value="    Ok   " name="butok" onclick="Custidreturn()"><input type="button" value="Cancel" name="reset1" onclick="window.close()"></font></td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            </table>

          </center></td>
        </tr>
    </table>

    </td>
  </tr>
  <tr>
    <td width="100%" valign="top" height="10"></td>
  </tr>
  <tr>
    <td width="100%" valign="top" height="10"></td>
  </tr>
  <input type="hidden" name="hidbrcd" value="<%=bid%>">
  </form>
  <% end if%>
</table>

</body>

