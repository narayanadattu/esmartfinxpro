<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashacceptance.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashacceptance" %>
<html>
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashAcceptance.aspx
''''' ListForm:List,single
''''' iFramepage:acceptamount.aspx
''''' Trnsactionpages:CashAcceptanceInsert.aspx
''''------------------------------------------------------------------------------------------
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
 /* for branchcode,currency not available function 	
 //To Get Branchcode
function branch()
{   
	st="Bruser"
	window.open("List.aspx" + "?"+"st="+st,st,"width=213%,height=150%,left=120,top=135")
}
function Bruser(kstr)
{
   assign(kstr,window.document.frmcashacp.txtbranchdesc,window.document.frmcashacp.txtbranchcode)
   clear()
}
//To clearing the controls 
function clear(){

   window.document.all.den.src="masterdenom.aspx"
   window.document.frmcashacp.txtallotment.value=""
   window.document.frmcashacp.txtcurrencydesc.value =""
   window.document.frmcashacp.txtcashcode.value=""
   window.document.frmcashacp.txtcashdesc.value=""
   window.document.frmcashacp.txtcounterno.value =""
   window.document.frmcashacp.txtcurrencycode.value=""
   window.document.frmcashacp.txtamount.value ="0.00"
   window.document.frmcashacp.txttotal.value ="0.00"
}
//To Get Currencycode
function currency()
{ 
  
	st="Curr"
	window.open("List.aspx" + "?"+"st="+st,st,"width=250%,height=150%,left=540%,top=210%")
  
}
//for currencyde
function Currid(kstr)
{ 
	var p,m,j,prn
	m=kstr.split("-----")
	window.document.frmcashacp.txtcurrencydesc.value =m[0]
	window.document.frmcashacp.txtcurrencycode.value =m[1]
	prn=m[2].length-1
	window.document.frmcashacp.hpr.value=prn
	p=""
	for(j=1;j<=prn;j++)
	{
		p=p + "0"
	}
	pres= "0." + p

	window.document.frmcashacp.txttotal.value=pres
	window.document.frmcashacp.txtamount.value =pres
	window.document.frmcashacp.txtallotment.value=""
	window.document.frmcashacp.txtcashcode.value =""
	window.document.frmcashacp.txtcashdesc.value =""
	window.document.frmcashacp.txtcounterno.value =""
	window.document.all.den.src="acceptdenom1.aspx"

}
*/
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'

//Tosend parameters to list page to get AllotmentNo
function Allotment()
{
	var st
	var sym="*"
	var st1="Allotment"
	var st2=window.document.frmcashacp.txtbranchcode.value 
	var st3=window.document.frmcashacp.txtcurrencycode.value
	st=st1+sym+st2+sym+st3
	window.showModalDialog("single.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	

}
///displaying allotmentno which is returned from list page
function Allotmentid(kstr)
{
	window.document.frmcashacp.txtallotment.value =kstr
	Amount()
}
///sending parameters to iframe page to fetch the counterno,alloted amount,cashierid 
///for selected allotment no
	function Amount()
	{
		st1=window.document.frmcashacp.txtbranchcode.value
		st2=window.document.frmcashacp.txtcurrencycode.value 
		st3=window.document.frmcashacp.txtallotment.value 
		st=st1+"|"+st2+"|"+st3+"~"+"AcceptAmount"
		//alert(st)
		//window.document.all["iBatch"].src="acceptamount.aspx"
		
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="acceptamount.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
	}
	
function TotalSumAmount(kstr)
{
	window.document.frmcashacp.txttotal.value = kstr
	window.document.frmcashacp.txttotal.value= gridprecision(window.document.frmcashacp.txttotal.value,
					window.document.frmcashacp.hpr.value)
}
	
///function for diplayingvalues  which is
	///returned by iframe page 
function Allotedamount(kstr)
{ 

	var StrMainFld=new String()
	var StrFlds=new String()
	StrMainFld=kstr.split("~")
	StrFlds=StrMainFld[0].split("*")
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtallotment")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid Allotment No")
			window.document.frmcashacp.txtallotment.value=""
			window.document.frmcashacp.txtcashcode.value=""
			window.document.frmcashacp.txtcashdesc.value=""
			window.document.frmcashacp.txtcounterno.value=""
			window.document.frmcashacp.txtamount.value=""
			window.document.frmcashacp.txttotal.value=""
			window.document.frmcashacp.all.den.src="acceptdenom1.aspx"
			
			return;
		}
		window.document.frmcashacp.txtallotment.value=StrFlds[0]
		Amount()
		
	}
	///for displaying the counterno,alloted amount,cashierid which is
	///returned by iframe page 
	if(StrMainFld[1]=="AcceptAmount")
	{
		window.document.frmcashacp.txtcashcode.value=StrFlds[1]
		window.document.frmcashacp.txtcashdesc.value=StrFlds[2]
		window.document.frmcashacp.txtamount.value=StrFlds[3]
		if(StrFlds[4]){
			window.document.frmcashacp.txtcounterno.value=StrFlds[4]
		}
		precision(window.document.frmcashacp.txtamount,window.document.frmcashacp.hpr.value)
		precision(window.document.frmcashacp.txttotal,window.document.frmcashacp.hpr.value)
		//for displaying the denomination page 
		Denom()
		
	}
}
///sending parameters to iframe page to fetch denominatio values for selected 
//branchcode,allotmentno
function Denom()
{	
window.document.frmcashacp.all.den.style.display="Block"
	m="cashallotmentstrn"
	n=window.document.frmcashacp.txtbranchcode.value
	p=window.document.frmcashacp.txtcurrencycode.value
	q=window.document.frmcashacp.txtcashcode.value 
	s=window.document.frmcashacp.txtcounterno.value
	allot=window.document.frmcashacp.txtallotment.value
	sy="|"
	f="frmcashacp"
	st=f+sy+m+sy+n+sy+p+sy+p+sy+s+sy+allot
	window.document.frames(0).frmdm.hdenom.value=st
	window.document.frames(0).frmdm.action="acceptdenom1.aspx"
	window.document.frames(0).frmdm.method="post"
	window.document.frames(0).frmdm.submit()
}
//post to server dise page to do the transaction  for Accept
function acceptCash()
{

window.document.frmcashacp.hStatus.value=""
if(eval(window.document.frmcashacp.txtamount.value)>0)
{
	if (CashDenom=='Y')
	{
		if(eval(window.document.frmcashacp.txtamount.value)==eval(window.document.frmcashacp.txttotal.value))
		{
			window.document.frmcashacp.hStatus.value="ACCEPT"
			window.document.frmcashacp.action="cashacceptanceinsert.aspx"
			window.document.frmcashacp.method="post"
			window.document.frmcashacp.submit()
		}
		else
		{
			alert("Amounts Should be Equal")
			window.document.frmcashacp.txtamount.focus()
			return;
		}
	}
	else
	{
		window.document.frmcashacp.hStatus.value="ACCEPT"
		window.document.frmcashacp.action="cashacceptanceinsert.aspx"
		window.document.frmcashacp.method="post"
		window.document.frmcashacp.submit()
	}
}
else
{
		alert('Allotment No Should be Specified to Accept the Allotment')
		window.document.frmcashacp.cmdallot.focus()
		return;
		alert("Accepted Amount Should not be Null")
		window.document.frmcashacp.txtamount.focus()
}
}

// //post to server dise page to do the transaction  for Accept
function reject()
{
	window.document.frmcashacp.hStatus.value=""
	if(window.document.frmcashacp.txtamount.value!="0.00")
	{
		window.document.frmcashacp.hStatus.value="REJECT"
		window.document.frmcashacp.action="cashacceptanceinsert.aspx"
		window.document.frmcashacp.method="post"
		window.document.frmcashacp.submit()
	
   }
   else
   {
		alert('Allotment No Should be Specified to Reject the Allotment')
		window.document.frmcashacp.cmdallot.focus()
		return;
   }
}
///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {
 
	//for cashier description 
if(strTxt=="txtallotment")
{
if(window.document.frmcashacp.txtallotment.value=="")
{
return;
}
// value is not there in text box return the function
if(window.document.frmcashacp.txtcurrencycode.value=="")
{
	alert("enter CurrencyCode")
	return
}
if(window.document.frmcashacp.txtbranchcode.value=="")
{
	alert("Select BranchCode")
	return;
}
sBr=window.document.frmcashacp.txtbranchcode.value
sBr=sBr.toUpperCase()
sAllot=window.document.frmcashacp.txtallotment.value
sCur=window.document.frmcashacp.txtcurrencycode.value
sUser="<%=session("userid")%>"
sUser=sUser.toUpperCase()
sCur=sCur.toUpperCase()
st="cashallotmentstrn"+"~"+"Allotmentno"+
	"~"+"cashierid='" + sUser +"' and " +
		"status='P' and branchcode='"+ sBr +"' and " +
		"currencycode='"+ sCur +"' and " +
		"allotmentno='"+ sAllot +"'"+
	"~"+strTxt+"~"+"DescDisplay"
	
}

//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="acceptamount.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
 }
 ///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.location.href="cashacceptance.aspx" 
		
	}
}	

///function for display cash denomination.
function Denom1()
{ 
	if (CashDenom=='Y')
	{
		window.document.all.denom.style.display="block"
		window.document.all.total.style.visibility="visible" 
		window.document.frmcashacp.txttotal.style.visibility="visible" 
	}
	else
	{
		window.document.all.denom.style.display="none"
		window.document.all.total.style.visibility="hidden" 
		window.document.frmcashacp.txttotal.style.visibility="hidden" 
	}
}

//-->
</SCRIPT>
<title>Cash Accepence</title>
</head>
<body topmargin="0" leftmargin="0" onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Denom1();DispTranMsg()">

<%appdate=formatdatetime(session("applicationdate"),1)%>
<form name="frmcashacp">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>Cash Acceptance</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>
		
  <input name="h" type="hidden"><input type="hidden" name="hnote">
  <div align="center">
    <center>

    <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%" valign="top">

        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%">

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="100%" ><img name="placeholder" border="0" src="file://Comserver/c/ASPTest/dscript42/transparent.gif" width="1" ></td>
              </tr>
            </table>

            </td>
          </tr>
        </table>

        </center>

        

        <center>

          <%'if len(Request.QueryString("record"))>0 then%>

       <!--- <table align="center" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td height="15" width="100%"><font class="textblue">
            <p align="center"></font></td>
          </tr>
        </table> --->

          <%'end if%>

        

        <div align="center">
          <center>

          <table border="0" width="98%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
              <td width="32%">&nbsp;<input name="txtbranchcode" size="9" class="txtautofill"
              value="<%=SESSION("branchcode")%>" readonly><input type="button" class="button" value=" L " name="buttbr" onclick="branch()" disabled><input name="txtbranchdesc" size="16" class="bgcolor1" value="<%=SESSION("branchnarration")%>" readonly></td>
              
              <td align="right" width="20%">
              <p>Currency Code</p></td>
              <td width="32%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txtcurrencycode" size="9" value="<%=session("currencycode")%>" class="txtautofill" readonly><input type="button" class="button" value=" L " name="butcur" onclick="currency()" disabled><input name="txtcurrencydesc" size="16" class="bgcolor1" value="<%=SESSION("currencynarration")%>" readonly></td>
            </tr>
          </table>

          </center>
        </div>
        <div align="center">
          <center>

          <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          </center>
          <tr>
            <td>
            <div align="center">
              <center>

              <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="47%" valign="top">
                  <div align="center">
                    <center>

                    <table width="96%" cellpadding="0" class="tableborder2">
                      <tr>
                        <td>&nbsp;

                        <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td valign="top" width="15%">&nbsp;Allotment No</td>
                            <td width="32%" height="30" valign="top"><input name="txtallotment" size="9" maxlength=2 onkeypress='numeric()' onblur='DescrptionDisp("txtallotment")' class="txtautofill"><input type="button" class="button" value=" L " name="cmdallot" onclick="Allotment()"></td>
                          </tr>
                          <tr>
                            <td valign="top" width="15%">&nbsp;Alloted&nbsp;By&nbsp;</td>
                            <td valign="top" height="30" width="32%"><input name="txtcashcode" size="9" readonly class="txtautofill"><!--<input type="button" value=" L " name="buttcash" onclick="Cashiercode()">--><input name="txtcashdesc" size="16" readonly class="bgcolor1"></td>
                          </tr>
                          <tr>
                            <td valign="top" width="15%">&nbsp;Counter No</td>
                            <td width="32%" valign="top" height="30"><input name="txtcounterno" size="9" class="txtautofill" style="TEXT-ALIGN:right" onkeypress="numeric()" readonly></td>
                          </tr>
                          <tr>
                            <td valign="top" width="15%">&nbsp; Amt Accepted</td>
                            <td width="32%" height="30" valign="top"><input 
                            name="txtamount" size="9" value="0.00" 
                            class="bgcolor1" style="TEXT-ALIGN: right" readonly
                            ></td>
                          </tr>
                          <tr>
                            <td width="318" height="60" valign="top" colspan="2">&nbsp;</td>
                          </tr>
                        </table>

                    </table>

                    </center>
                  </div>
                  </td>
                  <td width="64%" valign="top">
                  <div id="denom" align="center">
                    <div align="center">
                      <center>

                      <table width="95%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td>
                          <div align="center">
                            <center>

                            <table border="0" cellspacing="0" cellpadding="0" width="60%">
                              <tr>
                                <td><iframe id=den align=center  frameborder=0 framespacing=0   noresize height=380 width=380 valign="top" src="acceptdenom1.aspx" 
				                 style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                      </table>

                      </center>
                    </div>
                  </div>
                  &nbsp;&nbsp;&nbsp;</td>
                </tr>
              </table>

              </center>
            </div>
            <div align="center">
              <center>

              <table border="0" width="99%" cellspacing="0" cellpadding="0">
                <tbody>
                  <tr>
                    <td width="47%" height="5"></td>
                    <td width="41%" align="right" height="5"></td>
                    <td width="12%" height="5"></td>
                  </tr>
                  <tr>
                    <td width="47%">
                    <div align="center">
                      <center>

                      <table width="50%" cellspacing="0" cellpadding="0" class="tablebordermain">
                        <tr>
                          <td width="100%" align="middle"><input type="button" 
                          value="Accept" name="butaccpt" onclick="acceptCash()" class="button"><input 
                          type="button" value="Reject" 
                          name="butreject" onclick="reject()" 
                          class="button"><input type="reset" 
                          value="Cancel" name="Cmdcancel" 
                          onclick="location.href=&quot;cashacceptance.aspx&quot;" 
                          class="button"><input type="button" value="   Exit   " name="cmdexit" 
                          class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;"></td>
                        </tr>
                      </table>

                      </center>
                    </div>
                    </td>
                    <td width="41%" align="right"><span id="total" style="VISIBILITY: hidden"><font >Total</font>&nbsp;</td>
                    <td width="12%"><input id="txttotal" name="txttotal" size="9"  class="bgcolor1" style="TEXT-ALIGN: right" readonly value="0.00"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                  <tr>
                    <td width="100%" colspan="3" align="middle" height="15"></td>
                  </tr>
                </center><center></center>
                <tr>
                  <td width="100%" colspan="3" align="middle">
              </table>

              <input type="hidden" name="hpr"></center><input type="hidden" name="hStatus">
            </div>
            <center><center></center></center>
        </table>

        </div>
      </td>
    </tr>
    </table>

  </div>


</form>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
    <div align="center">
      <center>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="acceptamount.aspx">
                                              </iframe>
                  </td>
                </tr>
              </table>
      </center>
    </div>
    </td>
  </tr>
</table>

<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	

</body>

</html>
