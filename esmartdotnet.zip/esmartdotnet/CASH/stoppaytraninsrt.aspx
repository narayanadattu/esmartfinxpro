<%@ Page Language="vb" CodeBehind="stoppaytraninsrt.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.stoppaytraninsrt" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CashPaymentInsert.asp				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| N.Hari babu          |    26-APR-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************
%>
<% str=Request.QueryString("st")%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var s,rec,fld
  s= window.document.frmtrans.hval.value 
  rec=window.document.frmtrans.hrec.value
  fld=window.document.frmtrans.hflds.value
  str=s+"$"+rec+"$"+fld
  window.attachEvent(window.opener.TempTranslogpop1(str))  
  window.close()
}
//-->
</SCRIPT>    
<% 
	
   joint=split(str,"|")
   
 if len(joint(0))>0 then
  dim fldnms
      fldnms="GCHQ.CHQSERIESNO,GCHQ.CHEQUENO,GSTOP.STOPREASON,GSTOP.STOPNO,GCHQ.APPLICATIONDATE"
  		

  set rs=server.CreateObject("adodb.recordset")
  set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
  
  set rs=obj.singleRecordSet("GENCHEQUEDTLS GCHQ,GENSTOPPAYMST GSTOP",cstr(fldnms),"upper(GCHQ.BRANCHCODE)='" &  ucase(trim(joint(0))) & "' and  upper(GCHQ.MODULEID)='" &  ucase(trim(joint(1))) & "'  and upper(GCHQ.GLCODE)='" & ucase(trim(joint(2))) & "' AND GCHQ.accno='" & joint(3) & "' and GCHQ.STOPSTATUS='S' AND GCHQ.CHEQUENO BETWEEN  GSTOP.FROMCHQNO AND GSTOP.TOCHQNO")

 if not rs.EOF and not rs.bof then
 rs.MoveFirst

		do until rs.EOF                                     
			for i=0 to rs.Fields.Count -  1
				if  rs(i)="" then
				  a= a & "Null"
				else
				  a= a & rs(i)
				end if
				if i<>rs.Fields.Count - 1 then
				 a= a & "~"
				end if
			next
		 a=a & "|"
		
		 rs.MoveNext
		loop
  pay=mid(a,1,len(a)-1)
 end if
   
  rscnt=rs.RecordCount 
  fldcnt=rs.Fields.Count 
 set obj=nothing  
end if
%>
<title></title>
</head>
<body onload="List()">

<form name="frmtrans">
  <input type="hidden" name="hval" value="<%=pay%>"><input type="hidden" id="htno" name="hrec" value="<%=rscnt%>"><input type="hidden" id="htno" name="hflds" value="<%=fldcnt%>"><center><font class="textblue">Processing..........</font></center>
</form>
<br>
<br>
<br>
<br>
<center><font class="textred">Error No:</font> <font size="2" face="verdana" color="blue"><b><%=err.number%> 
 -- <%=err.description%>
<p>&nbsp;</b></font></center>
<%end if
Response.End()%>

</body>

</html>
<%if err.number<>0 then%>
