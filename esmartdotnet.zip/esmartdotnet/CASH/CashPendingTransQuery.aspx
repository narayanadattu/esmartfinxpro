<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="CashPendingTransQuery.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.CashPendingTransQuery" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">

<!--
function SendList()
{
  var strpend
  //alert("Hello")
  strpend=window.document.frmPendingQuery.hbno.value
  //alert(strpend)
  if(strpend)
  {
  window.attachEvent(window.parent.TransPending(strpend))
  window.close()
  }
 
}
//-->
</SCRIPT>


<title></title>
</head>




<%
Dim BRcode,curcode,ObjPending,MachID,UserID
Dim PendingType,RsPending,appdate,StrError
Dim strPending,Rcount,Ccount,strParam,arrParam

strparam=Request.QueryString("st")
if len(strparam)>0 then
''Response.Write strParam
''Response.Write "hello"
arrParam=split(strParam,"|")
		''''brcode="0001"
brcode=arrparam(0)
		'''curcode="INR"
curcode=arrParam(1)
		'''PendingType="ACCEPTANCE"
PendingType=arrParam(2)
appdate=session("applicationdate")
'MachID="COMSERVER"
'UserID="SUJANA"
'''Response.Write arrParam(3)
 rspending=server.CreateObject("ADODB.RECORDSET")
strpending=""
'''''If strPending="" then
If ucase(trim(arrParam(3)))="GENERAL" then

	 objpending=server.CreateObject("CashQuery.Queries")
	'''Response.Write PendingType
	If Ucase(trim(pendingtype))="ACCEPTANCE" then
		'''' pending transactions of Cash Acceptance
		 RsPending=ObjPending.CashAcceptancePending(cstr(brcode),cstr(curcode),cstr(appdate),"ACCEPTANCE",cstr(MachID))
	Elseif Ucase(trim(pendingtype))="TRANSFER" then
		'''' pending transactions of Cash Transfer
		 RsPending=ObjPending.CashAcceptancePending(cstr(brcode),cstr(curcode),cstr(appdate),"TRANSFER",cstr(MachID))	
	Elseif Ucase(trim(pendingtype))="REFUND" then
		'''' pending transactions of Cash Refund
		 RsPending=ObjPending.CashAcceptancePending(cstr(brcode),cstr(curcode),cstr(appdate),"REFUND",cstr(MachID))	
	End if
	
'''''Response.Write ObjPending.ConnError
	if ObjPending.ConnError="Connected" then
		'''' sending the values to the client page for display.
		 ObjPending=nothing
			if RsPending.RecordCount>0 then
				''Response.Write "<br>" & RsPending.RecordCount & "<br>"
				RsPending.MoveFirst
				Rcount=0
				do while not RsPending.EOF 
					
				''for Rcount=0 to RsPending.RecordCount-1
					for ccount=0 to RsPending.Fields.Count-1
						strPending=strPending  & RsPending.Fields(Ccount).Value & ","
					next
					
					strPending=left(strPending,len(strPending)-1) & "|"
					RsPending.MoveNext
					Rcount=Rcount+1
				''next
				loop
					strPending=left(strPending,len(strPending)-1) & "~" & Rcount & "~" & "GENERAL"
					''Response.Write strPending
			Else
				strPending="No Records~ Please Check."
			End if
	Else
		StrError=ObjPending.ConnError
		 ObjPending=nothing
		strPending="Error~ " & StrError
	End if
''Response.Write strPending

Elseif ucase(trim(arrParam(3)))="CASHIER" then
'''' transactions pending for each cashier
	dim flds,condition,cashierid
	cashierid=ucase(trim(arrParam(4)))
		 ObjPending=server.CreateObject("QueryRecordsets.fetchrecordsets")
		
	If Ucase(trim(pendingtype))="ACCEPTANCE" then
			
			flds="cashierid,ALLOTMENTNO,AMOUNTALLOTED"
			condition=" upper(trim(branchcode))='" & BRcode & "' and upper(trim(currencycode))='" _
			& curcode & "' and upper(trim(cashierid))='" & cashierid & "' "
			''& curcode & "' and upper(trim(cashierid))='" & cashierid & "' and status='P'"
			
		'''' pending transactions of Cash Acceptance
		 RsPending=ObjPending.Singlerecordset("cashallotmentstrn",cstr(flds),cstr(condition),,CStr(BRcode),cstr(UserID),cstr(MachID))
		'''Response.Write RsPending.RecordCount

	Elseif Ucase(trim(pendingtype))="TRANSFER" then
		   
		    flds="TOCASHIERID,CASHTRANSFERNO,AMOUNT"
			condition=" upper(trim(branchcode))='" & BRcode & "' and upper(trim(currencycode))='" _
			& curcode & "' and upper(trim(tocashierid))='" & cashierid & "' "
			''& curcode & "' and upper(trim(tocashierid))='" & cashierid & "' and status='P'"
		'''' pending transactions of Cash Transfer
		 RsPending=ObjPending.Singlerecordset("CASHTRANSBTCASHIERSTRN",cstr(flds),cstr(condition),,CStr(BRcode),cstr(UserID),cstr(MachID))

	Elseif Ucase(trim(pendingtype))="REFUND" then
		
			flds="REFUNDEDUSERID,REFUNDNO,REFUNDAMOUNT"
			condition=" upper(trim(branchcode))='" & BRcode & "' and upper(trim(currencycode))='" _
			& curcode & "' and upper(trim(REFUNDEDUSERID))='" & cashierid & "' "
			''& curcode & "' and upper(trim(REFUNDEDUSERID))='" & cashierid & "' and status='P'"
		'''' pending transactions of Cash Refund
		 RsPending=ObjPending.Singlerecordset("CASHREFUNDSTRN",cstr(flds),cstr(condition), ,CStr(BRcode),cstr(UserID),cstr(MachID))

	End if
		
		if ObjPending.ConnError="Connected" then
		'''' sending the values to the client page for display.
			 ObjPending=nothing
			if RsPending.RecordCount>0 then
			
				RsPending.MoveFirst
				for Rcount=0 to RsPending.RecordCount-1
					for ccount=0 to RsPending.Fields.Count-1
						strPending=strPending  & RsPending.Fields(Ccount).Value & ","
					next
					
					strPending=left(strPending,len(strPending)-1) & "|"
					RsPending.MoveNext
				next
					strPending=left(strPending,len(strPending)-1) & "~" & RsPending.RecordCount & "~" & "CASHIER"
					'Response.Write strPending
			Else
				strPending="No Records~ Please Check."
			End if
		Else
			StrError=ObjPending.ConnError
			 ObjPending=nothing
			strPending="Error~ " & StrError
		End if
Elseif ucase(trim(arrParam(3)))="CASHIERPOSITION" then  '''' calling from cashforcashier.aspx
	Dim ArrDenom
	dim intdec
	dim cashier,counter,iCount
	Dim amtPerVal
	Dim amtTotCash
	Dim strVal
	cashier=arrParam(4)
	counter=arrParam(5)
	 ObjPending=server.CreateObject("CashQuery.Queries")
	If Ucase(trim(PendingType))="CASHCASHIERPOSMST" then
		ArrDenom=ObjPending.CashDenominationsAsArray("CASHCASHIERPOSMST",cstr(BRcode),cstr(curcode),cstr(appdate),cstr(cashier),cstr(counter),,,"N")
		
		if ubound(ArrDenom,2)>1 then
		iCount=0
		amtPerVal=0
		amtTotCash=0
			do while trim(ArrDenom(iCount,2))<>""
				
				intdec=len(ArrDenom(icount,3))-1
				amtPerVal=cdbl(ArrDenom(iCount,1)) * cdbl(ArrDenom(iCount,2))
				amtPerVal=FormatCurrency(amtPerVal,intdec)
				strPending=strPending & ArrDenom(iCount,1) &"$"& ArrDenom(iCount,2) &"$"& Right(amtPerVal,len(amtPerVal)-1)
			    amtTotCash=cdbl(amtTotCash)+cdbl(amtPerVal)
			    
				amtPerVal=0
				strPending=strPending & "|"
				icount=icount+1
			loop
				
				amtTotCash=FormatCurrency(amtTotCash,intdec)
				strPending=strPending & Right(amtTotCash,len(amtTotCash)-1)
				''''strPending=strPending & left(amtTotCash,len(amtTotCash)-1)
		else
			strPending=ArrDenom(0,0)
		End if
	End if
End if
end if
%>

<%
'Dim arrobj , obj  
' obj = server.CreateObject("TrapError.ErrorDescription")
'arrobj = objError.ErrorProcess("2147217900: ORA-00904", "invalid column name", "ok") 
'onload='List()'
'onload="SendList()"
%>
<body onload="SendList()">

<form name="frmPendingQuery">
  <input type="hidden" id="hbno" name="hbno" value="<%=strPending%>"><center><font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
