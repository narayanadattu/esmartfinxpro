<%@ Page Language="vb" CodeBehind="maxdenom.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.maxdenom" %>
<%

	Dim obj,obj1,msg,appdate
	str=Request.QueryString("st")
	k=split(str,"|")
	code=k(0)
	val=k(1)
	dtype=k(2)
	mode=k(3)	
	set rsdate=server.CreateObject("adodb.recordset") 
	set objdate=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rsdate=objdate.singlerecordset("dual","to_char(sysdate,'dd-Mon-yyyy')","")	
	appdate=rsdate(0)
	if mode="I" then
	set rs=server.CreateObject("adodb.recordset") 
	set rs1=server.CreateObject("adodb.recordset")
	set obj=server.CreateObject("queryrecordsets.fetchrecordsets")
	set rs=obj.singlerecordset("CASHDENOMINATIONMST","DENOMINATIONCODE","CURRENCYCODE='"& code &"'and DENOMINATIONVALUE='"& val &"' and DENOMINATIONTYPE='"& dtype &"'")	
	if rs.RecordCount=0 then
		set obj1=server.CreateObject("queryrecordsets.fetchrecordsets")
		set rs1=obj1.singleRecordSet("CASHDENOMINATIONMST","max(to_number(substr(DENOMINATIONCODE,2))) maxdno","CURRENCYCODE='"& code &"'")
		if not isnull(rs1(0)) then
			msg1=rs1(0)
			msg="D" & msg1 & "|" & appdate
			
		end if
	else
		msg="This Denomination Already Exists" 
	end if		
	else
		msg= appdate
	end if
	
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
function List()
{
	var str
	str=window.document.frmacc.hcno.value	
	window.attachEvent(window.opener.maxdenomcode(str))
	window.close()
}

</SCRIPT>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hcno" name="hcno" value="<%=msg%>">
</form>

</body>

</html>
