<%@ Page Language="vb" aspcompat="true" explicit="false" CodeBehind="cashrefcounter.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashrefcounter" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<%userid=session("userid")%>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{var kstr,bt,t,bl,s
  kstr= window.document.frmacc.hbno.value  
  if(kstr)
  {
  window.attachEvent(window.parent.Allot(kstr))  
  window.close()
  }
 
}
//-->
</SCRIPT>

<%dim rs,obj
'Response.Write ("fff" & "<br>")
 Response.Write (Request.Form("hFlds"))
 kstr=Request.Form("hFlds")
  ''Response.Write kstr
   rs=server.CreateObject("adodb.recordset")
   rs1=server.CreateObject("adodb.recordset")
    obj=server.CreateObject("queryrecordsets.fetchrecordsets")
if len(kstr)> 0 then
   k=split(kstr,"|") 
    Response.Write (ubound(k))
   if k(0)="cashrefundstrn" then
			if k(2)="refund" then	
				 rs=obj.singlerecordset(cstr(k(0)),"refundamount", _
				"refundeduserid='" & k(1) & "' and refundno='" & k(3) & "' and status='P'")
				counterno="R" & "|" & rs(0).value	
			elseif k(1)="counter" then
				 rs=obj.singlerecordset("cashrefundstrn cash,genusermst gen", _
				"distinct(cash.refundeduserid),gen.name", _
				"cash.refundeduserid=gen.userid  and " & _
				"cash.status<>'A' and cash.counterno=" & k(2) & " and " & _
				"cash.branchcode='" & session("branchcode") & "' and " & _
				"cash.currencycode='" & session("currencycode") & "'")			
				counterno="C" & "|" & rs(0).value & "|" & rs(1).value
			else			
				 rs=obj.singlerecordset(cstr(k(0)),"distinct(counterno)," & _
				"applicationdate","refundeduserid='" & k(1) & "' and status='P' ")
				if not rs.EOF and not rs.bof then
					counterno="M" & "|" & rs(0).value	& "|" & rs(1).value	
				end if
			end if
			
elseif trim(k(0))="GENBANKLEVELMST" THEN
		 rs=obj.singlerecordset("GENBANKLEVELMST", _
		"NARRATION,HIERARCHY","CODE='" & k(1) & "'")
		if not rs.EOF and not rs.bof then
			counterno= rs(0).value & "|" & rs(1).value
        end if
elseif trim(k(0))="cashcashierposmst" then 		
		 objNum=server.CreateObject("QueryRecordsets.fetchrecordsets")
		 RsNum=server.CreateObject("adodb.recordset")
			 RsNum=objNum.Singlerecordset("cashrefundstrn","nvl(max(REFUNDNO),0)+1", _
						"userid='" & session("userid") & "' and " & _
						"branchcode='" & session("branchcode") & "'")
		    if not RsNum.EOF and not RsNum.BOF then
				RefNo=RsNum(0).value
		    end if	
		    			
			 objNum=nothing			
		 rs=obj.singlerecordset(cstr(k(0)),"counterno,totamount", _
		"cashierid='"& session("userid") & "'")	
		if not rs.BOF and not rs.EOF then
		counterno= rs(0).value & "|" & rs(1).value & "|" & refno
		else
		counterno="No Records Found" 
		end if
		
 'else    
      '  res=split(kstr,"|")        
		' rs=obj.singleRecordSet("Cashcountermst","counterno", _
		'	"cashierid='"& cstr(res(0)) &"' and " & _
			'"branchcode='" & cstr(res(1)) & "' and " & _
			'"currencycode='" & cstr(res(2)) &"'")
		'if not rs.EOF and not rs.bof then
		 '  CounterNo=rs(0)
		  '  obj=nothing	
		  '  obj=server.CreateObject("Autonumber.generation")		   		
		  ' Alno=obj.GetAutoNumber("cashallotmentstrn","allotmentno", _
		  ' "cashierid='"& cstr(res(0)) &"' and counterno= " & counterno &"")
		'end if
       ' CounterNo=CounterNo & "*" & Alno
  end if
 
if(ubound(k)>3) then

if 	k(4)="DescripDisplay" then
 RecGen=server.CreateObject("adodb.recordset")
 RecGen=obj.singleRecordSet(cstr(k(0)),cstr(k(1)),cstr(k(2)))
			if not recGen.BOF or not recGen.EOF then
				for i=0 to recGen.Fields.Count-1
					CounterNo=CounterNo &  recGen(i).value & "*"
				next
			else
			CounterNo= "No*"	
			end if
			CounterNo=CounterNo & "|" & k(3) 
			
end if
end if	
end if 
 obj=nothing		
 'onload='List()'
%>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hbno" name="hbno" value="<%=counterno%>">
  <input type="hidden" id="hFlds" name="hFlds"><center>
  <font class="textblue">Processing..........</font></center>
</form>

</body>

</html>
