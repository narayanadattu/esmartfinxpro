<%@ Page Language="vb" CodeBehind="cashDenomRcpt.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashDenomRcpt" %>
<%'********************************************************************************
'**********************************************************************************
'*	Name Of the File : CashDenomRcpt.asp				                *
'*	Purpose	  	     : This form is use to	insert the cash payment details *
'*																		    *      	                              *
'*		   													                *
'*			                                            			        *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| T.Anil kumar         |    04-MAY-2001   |   1.0      |		                 |     
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'**********************************************************************************
'**********************************************************************************

%>
<%
Response.Buffer=true
Response.Expires=0
On Error Resume Next
Dim Userid,vCounterNo,vAppdat,vCashierid,strDenom

Userid=session("userid")
vCounterNo=session("Counterno")
vAppdate=session("applicationdate")
vBrnchcode=session("branchcode")
vCurcode=session("currencycode")

strDeno=Request.QueryString("str")

strDenom=split(strDeno,"~")

if not strDenom(0)="" and not strDenom(1)="" then 
set obj=server.CreateObject("cashquery.queries")
st=obj.CashDenominationsAsarray("cashcashierposmst",cstr(strDenom(0)),cstr(strDenom(1)),cstr(vAppdate),cstr(strDenom(2)),CStr(vCounterNo),"","Y","Y")
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript>
<!--
function CashMultiply(Note,Rs,Av,Amt)
{
   
 var i,T
   if (Rs.value=="")
  {
     Amt.value="0.00"
     totValue()
  }
  else
  {   	Amt.value=eval(Note)* eval(Rs.value)
		totValue()
  }
}

//-------------------------------------------------------------------------------------------
function CashSubsraction(Note,Rs,Amt,PaidAmt,Av)
{
 
var i,T;
if(eval(Av.value)>0){
  if (Rs.value=="")
  {
    if(PaidAmt.value==""){
		Amt.value="0.00";
	}
	else{
		Amt.value=eval(Note)*eval(PaidAmt.value);
    }
    totValue();
   }
  else
  {  
  var pamt=PaidAmt.value;
  
	if(pamt=="")
		pamt=0;
		Amt.value=(eval(Note)*eval(pamt))-(eval(Note)* eval(Rs.value));
		totValue();
    }
}
else
{
 if((event.keyCode!=9)){
 alert("Denominations not available")
 }
 Rs.value=""
}
}
//-------------------------------------------------------------------------------------------

function totValue(){
 var k=0;
  for(i=0;i<frmdm.hps.length;i++){
		k=eval(k)+ eval(window.document.frmdm.txtamt(i).value);
	}  
	parent.document.forms[0].txttotal.value=k;
	precision(window.parent.window.document.forms(frm).txttotal,window.document.frmdm.hpr.value)
	
}
//-------------------------------------------------------------------------------------------
 function xyz12(textvalue){
  textvalue=textvalue+"";
  var sum;
	if(textvalue!="")
	{ 	
	    var dotindex=textvalue.indexOf('.');
		if(dotindex==-1)
		  {
			sum=textvalue+".00";
		  }
		else 
		 {
		   var a=textvalue.substring(textvalue.indexOf('.'),textvalue.length);
		   if(a.length<2)
		     sum = textvalue+".0";
		   if((a.length)>2)
		    var b=textvalue.substring(0,textvalue.indexOf('.')+3);
		    sum = b;
		  }
	return  sum;
	}

  }
 
//-------------------------------------------------------------------------------------------  
   
//-->
</SCRIPT>
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
<body>

<form name="frmdm">
  <div align="right">

    <table border="1" cellspacing="0" cellpadding="0" width="122">
 	  <%dim ind,cnt
 	
 		for j=0 to ubound(st)
 	
 		if st(j,0)="CP" then
 		   ind=ind+1
 		end if
 		next
 	m=0
 	pr=len(st(1,3))-1
 	 ' if len(st(0,1))>0 then
 	  %>
      <input type="hidden" name="hpr" value="<%=pr%>">
      <tr class="bgcolor">
        <td width="90" align="middle"><strong><font class="textbold">Denomination<br>
        value</font></strong></td>
        <td width="90" height="10" align="middle"><font class="textbold"><strong><font color="#ffffff">Available
        </font><font class="textbold">Pieces</font></strong></font></td>
        <td width="48" height="10" align="middle"><strong><font class="textbold">&nbsp;</font></strong></td>
        <td width="26" height="10" align="middle">
        <p align="right"><strong><font class="textbold">No.of&nbsp; Pieces</font></strong></p>
        </td>
        <td width="26" height="10" align="middle"><strong><font class="textbold">Exchange
        Amount</font></strong></td>
        <td width="26" height="10" align="middle"><strong><font class="textbold">&nbsp;</font></strong></td>
        <td width="26" height="10" align="right"><strong><font class="textbold">Amount</font></strong></td>
      </tr>
     
 	  <%
 	' end if 
 	
 	if ubound(st)>0 then
 	FOR i=0 TO ubound(st)%>
 	  <%if st(i,1)<>"" then%>
 	  <%cnt=cnt+1
 	  cal=st(i,3)
	  p=len(cal)-1%>	
      <tr align="middle">
        <td width="90" height="10" align="right"><font size="2" face="Arial"><%=st(i,1)%> 
        </font><input type="hidden" name="hps" value="<%=st(i,1)%>"></td>
        <td width="90" height="10" align="right"><font size="2" face="Arial"><%=st(i,2)%>
        </font><input type="hidden" name="htype" value="<%=st(i,0)%>"><input type="hidden" name="havail" value="<%=st(i,2)%>"></td>
        <td width="48" height="10" valign="top"><font size="2" face="Arial">*</font></td>
	    <%Tot=cdbl(st(i,1))*cdbl(st(i,2))
	   Avtot=cdbl(Avtot)+cdbl(Tot)%>
	    <% if st(i,0)="CP" then
	       cal=st(i,3)
	       p=len(cal)-1
	       'amt=st(i,1)/cal
	       amt=st(i,1)
	       %>
        <input type="hidden" name="hamt" value="<%=amt%>"> 
	    <%if ind>1 then	%>				
        <td width="50"><font size="2" face="Arial"><input id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hamt(<%=m%>).value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>),window.document.frmdm.txtamt(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
        <td width="50"><font size="2" face="Arial"><input id="txtExaPic" name="txtExaPic" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashSubsraction(window.document.frmdm.hps(<%=i%>).value,this,window.document.frmdm.txtamt(<%=i%>),window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
       
           <%m=m+1
			else%>
        <td width="50"><font size="2" face="Arial"><input id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hamt.value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>),window.document.frmdm.txtamt(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
        <td width="50"><font size="2" face="Arial"><input id="txtExaPic" name="txtExaPic" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashSubsraction(window.document.frmdm.hps(<%=i%>).value,this,window.document.frmdm.txtamt(<%=i%>),window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
		  <%end if %>
		<%else%>
        <td width="50"><font size="2" face="Arial"><input id="txtpieces" name="txtpieces" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashMultiply(window.document.frmdm.hps(<%=i%>).value,window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>),window.document.frmdm.txtamt(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
        <td width="50"><font size="2" face="Arial"><input id="txtExaPic" name="txtExaPic" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="6" onkeypress="numeric()" onkeyup="CashSubsraction(window.document.frmdm.hps(<%=i%>).value,this,window.document.frmdm.txtamt(<%=i%>),window.document.frmdm.txtpieces(<%=i%>),window.document.frmdm.havail(<%=i%>));precision(window.document.frmdm.txtamt(<%=i%>),<%=p%>)"></font></td>
		<%end if%>
        <td width="31" height="10" align="middle"><font size="2" face="Arial">=</font></td>
        <% if strDenom(1)="INR" then
             des="0.00"
          elseif strDenom(1)="USD" THEN
             des="0.000"
          end if      
        %>
        <td width="71"><font size="2" face="Arial"><input id="txtamt" name="txtamt" value=" <%=des%>" style="FONT-SIZE: x-small; HEIGHT: 18px; TEXT-ALIGN: right" size="9" disabled></font></td>
        <%end if%>
      </tr>
	  <%next %>
	  <%if len(trim(Avtot ))> 0 then
	  Response.Write"<script language=vbscript>"
	  Response.Write "window.parent.window.document.forms(frm).txtavtotal.value=" & Avtot & chr(13)
      Response.Write "call precision(window.parent.window.document.forms(frm).txtavtotal,window.document.frmdm.hpr.value)" & chr(13)
      Response.Write "call precision(window.parent.window.document.forms(frm).txttotal,window.document.frmdm.hpr.value)" & chr(13)
      Response.Write"</script>" 
      end if%>
    </table>

    <input type="hidden" id="hdenom" name="hdenom"><input type="hidden" id="hspr" name="hspr"><input type="hidden" name="hcnt" value="<%=cnt%>">
    <% end if
    end if
    if ubound(st)<1 then%>

    <table align="center">
      <tr>
        <td>
        <%Response.Write "" 'No Denominations available%> 
        </td>
      </tr>
    </table>

    <%end if  
    %>
    
  </div>
</form>

</body>

</html>
