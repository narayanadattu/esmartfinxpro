<%@ Page aspcompat="true" explicit="false" Language="vb" CodeBehind="solnotesExchangeInsert.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.solnotesExchangeInsert" %>
<%	dim ObjExNoGen
	dim BrCode,CurCode,CntNo,ExNo,CashId,AmtEx,d1,status,Nartion,Mobil,Pan,Aadhar,strMode1
	Dim kstr,RsExChng
	Dim ObjExCng,RowNos,ObjCash,RecCash
	Dim DenomArr(0,5)
	rownos=Request.Form("hcount")
	Redim DenomArr(RowNos,5)
	BrCode=ucase(trim(Request.Form("txtbranchcode")))
	CurCode=ucase(trim(Request.Form("txtcurrencycode")))
	cashid=ucase(trim(session("userid")))
	AmtEx=Request.Form("txtExAmt")
	Nartion=ucase(Request.Form("txtnarration"))
	Mobil=ucase(Request.Form("txtMobile"))
	Pan=ucase(Request.Form("txtPann"))
	Aadhar=ucase(Request.Form("txtAdhar"))
	'userid="U1"
	'machineid="M1"
	userid=cashid
	machineid=ucase(trim(session("Machineid")))
	cashid=session("userid")
	CntCode=session("counterno")
	m=split(Request.Form("hvalue"),"|") 
	n=split(Request.Form("hrec"),"|") 
	p=split(Request.Form("hpaid"),"|") 
    q=split(Request.Form("htype"),"|")
    r=split(Request.Form("havail"),"|")
    strMode1 = Request.Form("hdnmode")
    
''''***** taking denominationvalues and pieces into an Array
	
	For i=1 to RowNos
		DenomArr(i,0)=m(i-1)
		DenomArr(i,1)=n(i-1)
		DenomArr(i,2)=p(i-1)
		DenomArr(i,3)=r(i-1)
		DenomArr(i,4)=q(i-1)
	
	next


''''******Cheking Null values in not nullFeilds 

if len(Brcode)<>0 and len(CurCode)<>0 then

	''***************Generation of ExchangeNo******************

	 ObjExNoGen=server.CreateObject("Autonumber.Generation")
	ExNo=ObjExNoGen.GetAutoNumber("CASHSOILNTEXCHTRN","exsno","upper(trim(branchcode))='" & brcode & "' and upper(trim(currencycode))='" & CurCode & "'")
	
	 ObjExNoGen=nothing
		
	''''*************Calling solnotesexchange Component
		Response.Write (session("counterno"))
	 ObjExChng=server.CreateObject("SoilNotesTransactions.Transactions")
	 
	 if strMode1  = "Debit" then
	kstr = ObjExChng.SoilNotesExchange("CASHSOILNTEXCHTRN",cstr(Brcode),cstr(CashId),cstr(Curcode),cstr(CntCode),cstr(ExNo), _
	cdate(session("applicationdate")),cstr(UserId),cstr(MachineId),cdbl(AmtEx),DenomArr,cdate(session("applicationdate")),cstr(Nartion),cstr(Mobil),cstr(Pan),cstr(Aadhar))
	else
	kstr = ObjExChng.SoilNotesExchange_credit("CASHSOILNTEXCHTRN",cstr(Brcode),cstr(CashId),cstr(Curcode),cstr(CntCode),cstr(ExNo), _
	cdate(session("applicationdate")),cstr(UserId),cstr(MachineId),cdbl(AmtEx),DenomArr,cdate(session("applicationdate")),cstr(Nartion),cstr(Mobil),cstr(Pan),cstr(Aadhar))
	end if 

	 ObjExChng=nothing
	Response.Redirect ("solnotesexchange.aspx?record=" & kstr)

 else
    strmsg="Should not be Empty"
	Response.Redirect ("solnotesexchange.aspx?record="& kstr)
	
end if	
%>
<head>
	<link rel="stylesheet" type="text/css" href="../styletag.css">
		<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
		<meta name="ProgId" content="FrontPage.Editor.Document">
</head>
