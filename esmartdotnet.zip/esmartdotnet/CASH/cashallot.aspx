<%@ Page CodeBehind="cashallot.aspx.vb" aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.cashallot" %>
<html>
<%
'Dim rs,obj,CashDenomyn
'rs=server.CreateObject ("adodb.recordset")
'obj=server.CreateObject("queryrecordsets.fetchrecordsets")
'rs=obj.singlerecordset("GENBANKPARM","CASHDENOMYN","Bankcode='999'")
'if rs.recordcount > 0 then
'	CashDenomyn=rs(0).value 
'end if
'rs=nothing
%>
<%
''''--------------------------------------------------------------------------------------------------
''''' Form Name:CashAllot.aspx
''''' ListForm:List
''''' iFramepage:Counter.aspx
''''' Trnsactionpages:CashAllotInsert.aspx
''''------------------------------------------------------------------------------------------
%>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Allotment</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE=javascript>
<!--
var st
var CashDenom
CashDenom='<%=session("cashdenomyn")%>'
/*
//for sending parameters to list page for fetching the Branchcode,desciptions
function branch()
{   
	st="Bruser"
	window.open("List.aspx" + "?"+"st="+st,st,"width=300%,height=150%,left=120,top=135")
}
//function for displaying the branchcode, description whixh is returned by list page 
function Bruser(kstr)
{
   assign(kstr,window.document.frmallot.txtbranchdesc,window.document.frmallot.txtbranchcode)
   window.document.all.den.src="masterdenom.aspx"
   window.document.frmallot.txtavtotal.value ="0.00"
   window.document.frmallot.txttotal.value ="0.00"
   window.document.frmallot.txtcurrencycode.value =""
   window.document.frmallot.txtcurrencydesc.value =""
}
//for sending parameters to loist page for fetching the currencycode,desciptions
function currency()
{ 
  st="Curr"
  window.open("List.aspx" + "?"+"st="+st,st,"width=300%,height=150%,left=550,top=135")
}
//function for displaying the currencycode, description whixh is returned by list page 
function Currid(kstr)
{
var p
  k=kstr.split("-----")
  window.document.frmallot.txtcurrencydesc.value =k[0]
  window.document.frmallot.txtcurrencycode.value =k[1]
  prn=k[2].length-1
  window.document.frmallot.hpr.value=prn
  p=""
  for(f=1;f<=prn;f++)
  {
    p=p + "0"
  }
  pres= "0." + p 
  window.document.frmallot.txttotal.value=pres
  window.document.frmallot.txtamount.value =pres
  window.document.frmallot.txtavtotal.value =window.document.frmallot.txtamount.value
  Denom()
}
*/
//for sending parameters to loist page for fetching the CashierCode,desciptions
function Cashiercode()
{	
	window.document.frmallot.txtamount.value=""
	window.document.frmallot.txtavtotal.value=""
	window.document.frmallot.txtCashierDesc.value=""
	window.document.frmallot.txtcountername.value=""
	window.document.frmallot.txtcounterno.value=""
	window.document.frmallot.txtctotal.value=""
	window.document.frmallot.txttotal.value=""
	//alert("calling denom")
	Denom()
	//alert("after calling denom")
   s1="CashID"
   s2=window.document.frmallot.txtbranchcode.value
   st=s1+"|"+s2
   
    window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
}
//function for displaying the CashierCode, description whixh is returned by list page 
function Cashierid(kstr)
{   
	//alert(kstr)
	 assign(kstr,window.document.frmallot.txtCashierDesc,window.document.frmallot.txtCashierId)
	 count()
}
///sending parameters to iframe page to fetch the counterno for selected cashier
function  count()
{
      	sCash = window.document.frmallot.txtCashierId.value 
		sBr=window.document.frmallot.txtbranchcode.value 
		sCur=window.document.frmallot.txtcurrencycode.value 
		sBr=sBr.toUpperCase()
		sCur=sCur.toUpperCase()
		sCash=sCash.toUpperCase()
		st=sCash+"|"+sBr+"|"+sCur+"~CounterNo"
		
		//post to iframe page
		//window.document.all["iBatch"].src="counter.aspx"
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="counter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
		
}

///displaying the counterno
function Allot(kstr)
{
	//alert(kstr)
	var StrMainFld=new String()
	StrMainFld=kstr.split("~")
	StrFlds=StrMainFld[0].split("|")
	//for counterno displaying
	if(StrMainFld[1]=="CounterNo")
	{
	window.document.frmallot.txtcounterno.value =StrFlds[0]
	window.document.frmallot.txtcountername.value =StrFlds[1]
	window.document.frmallot.txtamount.focus()
	}

	//To display total vault position
	if(StrMainFld[1]=="CASHVAULTMST")
	{
		
		if (CashDenom=='Y')
		{
			window.document.frmallot.txtValttot.value =StrFlds[0]
			precision(window.document.frmallot.txtValttot,window.document.frmallot.hpr.value)	
			
			var stDif
			
			stDif = eval(window.document.frmallot.txtValttot.value) - eval (window.document.frmallot.txtavtotal.value)
			
			window.document.frmallot.txtDiff.value = stDif
			
			window.document.frmallot.txtCashierId.focus()
			
		}
		else
		{
			window.document.frmallot.txtavtotal.value =StrFlds[0]
			precision(window.document.frmallot.txtavtotal,window.document.frmallot.hpr.value)	
			window.document.frmallot.txtCashierId.focus()
		}
	}	
	
	///for displaying cashierDescription
	if(StrMainFld[1]=="txtCashierId")
	{
		if(StrFlds[0]=="No")
		{
			alert("Invalid Cashier ID")
			window.document.frmallot.txtCashierId.value=""
			window.document.frmallot.txtCashierDesc.value=""
			return;
		}
		window.document.frmallot.txtCashierDesc.value=StrFlds[0]
		count()
		
	}
	//checking the amount alloted is exceeding the max cashlimit of selected
 //cashier and counter
 
	if(StrMainFld[1]=="AmountChk")
	{
		
		if(StrFlds[0].toUpperCase()!="YES")
		{
			strcheck=confirm(StrFlds[0]+"  Do You Want To Continue! ")
			if(strcheck!=true)
			{
				return;
			}
			
		}
		
		
	}
}
function Denom()
{ 
	if (CashDenom=='Y')
	{
		window.document.all.denom.style.display="block"
		window.document.frmallot.txttotal.style.visibility="visible" 
		frm="frmallot"
		s=window.document.frmallot.txtbranchcode.value
		s1=window.document.frmallot.txtcurrencycode.value 
		st=frm +"|"+"CASHVAULTMST"+"|"+s+ "|" + s1
		///alert(" st = "+st)
		window.document.frames(0).frmdm.hdenom.value=st
		window.document.frames(0).frmdm.hspr.value=window.document.frmallot.hpr.value 
		window.document.frames(0).frmdm.method="post"
		window.document.frames(0).frmdm.action="masterdenom.aspx"
		window.document.frames(0).frmdm.submit()	
		
		
		sBr=window.document.frmallot.txtbranchcode.value
		sBr=sBr.toUpperCase()
		sCur=window.document.frmallot.txtcurrencycode.value
		sCur=sCur.toUpperCase()
		sApplDt="<%=session("applicationdate")%>"
		sflds = "nvl(TOTAMOUNT,0) - (SELECT NVL(SUM(NVL(amountalloted,0)),0) FROM" +	
			    " CASHALLOTMENTSTRN WHERE branchcode='"+sBr+"' AND " +
			    " currencycode='"+sCur+"' AND status='P')"

		st="CASHVAULTMST~"+sflds+
			"~"+"branchcode='"+sBr+"' and currencycode='"+sCur+
			"' and APPLICATIONDATE='"+sApplDt+"'"+
			"~CASHVAULTMST~"+"DescDisplay"
		
		//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="counter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();	
	}
	else
	{
		window.document.all.denom.style.display="none"
		window.document.frmallot.txttotal.style.visibility="hidden" 
				
		sBr=window.document.frmallot.txtbranchcode.value
		sBr=sBr.toUpperCase()
		sCur=window.document.frmallot.txtcurrencycode.value
		sCur=sCur.toUpperCase()
		sApplDt="<%=session("applicationdate")%>"
		sflds = "nvl(TOTAMOUNT,0) - (SELECT NVL(SUM(NVL(amountalloted,0)),0) FROM" +	
			    " CASHALLOTMENTSTRN WHERE branchcode='"+sBr+"' AND " +
			    " currencycode='"+sCur+"' AND status='P')"

		st="CASHVAULTMST~"+sflds+
			"~"+"branchcode='"+sBr+"' and currencycode='"+sCur+
			"' and APPLICATIONDATE='"+sApplDt+"'"+
			"~CASHVAULTMST~"+"DescDisplay"
		
		//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="counter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
	
	}

}
///posts to server side page to do the transaction through the component
function Insert()
{
	var i,n,p,a,b,c
	var k=0,a="",b="",c=""
	if(window.document.frmallot.txtCashierId.value=="")
	{
		alert("Cashier Id Should not be Null")
		return;
	}
	if(window.document.frmallot.txtcounterno.value=="")
	{
		alert("Counter No Should not be Null")
		return;
	}
	if((window.document.frmallot.txtamount.value=="")||
	(eval(window.document.frmallot.txtamount.value)==0))
	{
		alert("Alloted Amount Should not be 0")
		return;
	}
	if (eval(window.document.frmallot.txtamount.value)>eval(window.document.frmallot.txtavtotal.value))
	{
		alert("Alloted Amount Should Not Exceed Total Vault Position")
		return;	
	}
	
	if (CashDenom=='Y')
	{	
		k=1
		
		if((eval(window.document.frmallot.txtDiff.value)!="0") || (eval(window.document.frmallot.txtDiff.value)!="0.00"))
		{
			alert("Difference Between Vault Cash And Denomination \n Please Verify it ")
		}
		
		if (eval(window.document.frmallot.txtamount.value)==
		eval(window.document.frmallot.txttotal.value))
		{
			p=window.document.frames(0).frmdm.hcnt.value
			///fetching the denominations values and storing in variabes to send to server 
			//page
			for(i=0;i<=p-1;i++)
			{
				///for multiple text boxes(denomination using index)
				if(window.document.frames(0).frmdm.txtpieces.length>0)
				{
					if(window.document.frames(0).frmdm.txtpieces(i).value!=0)
					{
						k=k+1
						a1=window.document.frames(0).frmdm.hps(i).value
						a=a+a1+"|"
						b1=window.document.frames(0).frmdm.txtpieces(i).value
						b=b+b1+"|"
						c1=window.document.frames(0).frmdm.htype(i).value
						c=c+c1+"|"
					}
				}
				//for single text box(denomination not using index)
				else
				{
					if(window.document.frames(0).frmdm.txtpieces.value!=0)
					{
						k=k+1
						a1=window.document.frames(0).frmdm.hps.value
						a=a+a1+"|"
						b1=window.document.frames(0).frmdm.txtpieces.value
						b=b+b1+"|"
						c1=window.document.frames(0).frmdm.htype.value
						c=c+c1+"|"
					}	
				}
			}
		}	
		else
		{
			alert("Amounts should be Equal")
			return
		}	
	}//my if condition
 		 
		window.document.frmallot.hcount.value=k 
		window.document.frmallot.hvalue.value=a
		window.document.frmallot.hpices.value=b
		window.document.frmallot.htype.value=c
		/*alert("k=" + k)
		alert("a=" + a)
		alert("b=" + b)
		alert("c=" + c)*/
		window.document.frmallot.buttInsert.disabled = true
		window.document.frmallot.action="CashAllotInsert.aspx"
		window.document.frmallot.method ="post"
		window.document.frmallot.submit()
 
 }
 ///function for sending parameters to display the description on blur event
 function DescrptionDisp(strTxt)
 {
 
	//for cashier description 
if(strTxt=="txtCashierId")
{
if(window.document.frmallot.txtCashierId.value=="")
{
return;
}
// value is not there in text box return the function
if(window.document.frmallot.txtcurrencycode.value=="")
{
	alert("enter CurrencyCode")
	return
}
if(window.document.frmallot.txtbranchcode.value=="")
{
	alert("Select BranchCode")
	return;
}
sBr=window.document.frmallot.txtbranchcode.value
sBr=sBr.toUpperCase()
sCashId=window.document.frmallot.txtCashierId.value
sCashId=sCashId.toUpperCase()
sUser="<%=session("userid")%>"
st="cashcountermst cash,genusermst gen"+"~"+"gen.name"+
	"~"+"cash.cashierid=gen.userid and "+
	"upper(trim(cash.cashierid)) <> '" + sUser + "' and " +
	"gen.branchcode='" + sBr + "' and cash.cashierid='"+ sCashId +"'"+
	"~"+strTxt+"~"+"DescDisplay"
}
//checking the amount alloted is exceeding the max cashlimit of selected
 //cashier and counter
 if(strTxt=="AmountChk")
	{
	sBr=window.document.frmallot.txtbranchcode.value
	sCur=window.document.frmallot.txtcurrencycode.value.toUpperCase()
sBr=sBr.toUpperCase()
sCashId=window.document.frmallot.txtCashierId.value
sCashId=sCashId.toUpperCase()
sCnt=window.document.frmallot.txtcounterno.value
sAmt=window.document.frmallot.txtamount.value
if((sAmt!="")||(eval(sAmt)>0))
{
st=sBr+"~"+sCur+"~"+sCashId+"~"+sCnt+"~"+window.document.frmallot.txtamount.value+"~AmountCheck"+"~"+strTxt
}
	
	
	}
//post to ifrmae page to get desciptions
		window.document.frames(1).frmacc.hFlds.value=st
		window.document.frames(1).frmacc.action="counter.aspx"
		window.document.frames(1).frmacc.method="post"
		window.document.frames(1).frmacc.submit();
 }
 //function for checking the amount alloted is exceeding the max cashlimit of selected
 //cashier and counter
 function amtallotcheck()
 {
	if((window.document.frmallot.txtamount=="")||
	(window.document.frmallot.txtamount.value==0))
	{
	return
	}
	DescrptionDisp("AmountChk")
 }
 ///function for returning the message from serverside page after transaction
function DispTranMsg()
{
var strtran
	strtran="<%=Request.QueryString("record")%>"
	
	if(strtran!="")
	{
	alert(strtran)
		window.document.frmallot.buttInsert.disabled = false
		window.location.href="cashallot.aspx" 
		
	}
}

function TotalSumAmount(kstr)
{
	window.document.frmallot.txttotal.value=kstr 
	
	window.document.frmallot.txttotal.value= gridprecision(window.document.frmallot.txttotal.value,
					window.document.frmallot.hpr.value)
}

function GetAvgTotRefAmt(kstr)
{
k=kstr.split("|")
	window.document.frmallot.txtavtotal.value =k[0]  // avg total
	window.document.frmallot.txtavtotal.value= gridprecision(window.document.frmallot.txtavtotal.value,
					window.document.frmallot.hpr.value)
	window.document.frmallot.txtctotal.value =k[1]  // c total
	window.document.frmallot.txtctotal.value= gridprecision(window.document.frmallot.txtctotal.value,
					window.document.frmallot.hpr.value)
	
}

	
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" 
onload="GetMenu(&quot;<%=session("menustring")%>&quot;);Denom();DispTranMsg()">

<form name="frmallot">

<div class="header">
            <table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="19%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="20%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="40%" align="left" height="22" class="subHeader"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash Allotment</h2></td>
					<td width="20%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div>
		<div id="menucontrol"></div>
		
  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="480">
    <tr>
      <td width="100%" valign="top">

      <!--- <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="11%" height="28"></td>
          <td width="89%" height="28"></td>
        </tr>
      </table> -->

       <%appdate=formatdatetime(session("applicationdate"),1)%>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%">

          

          <center>

        <!---  <table width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td height="15" align="center"><font class="textblue"></font></td>
            </tr>
          </table> --->

          </center>
          <div align="center">
            <center>

            <table width="98%" cellspacing="0" cellpadding="0" border="0">
              <tr class="bgcolor">
                <td width="15%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Branch Code</td>
                <td width="32%"><input name="txtbranchcode" size="9" readonly style="TEXT-TRANSFORM: uppercase" class="txtautofill" value="<%=Session("BranchCode")%>" ><input type="button" class="button" value=" L " name="B3" disabled onclick="branch()"><input name="txtbranchdesc" size="16" value="<%=session("branchnarration")%>" style="TEXT-TRANSFORM: uppercase" readonly class="bgcolor1"></td>
                
                <td width="25%" align="right">Currency Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td width="32%"><input name="txtcurrencycode" style="TEXT-TRANSFORM: uppercase" readonly class="txtautofill" size="9" value="<%=session("currencyCode")%>"><input type="button" class="button" value=" L " name="B3" disabled onclick="currency()"><input name="txtcurrencydesc" size="16" style="TEXT-TRANSFORM: uppercase" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
            </table>

            </center>
          </div>
          </td>
        </tr>
      </table>

      <div align="center">
        <center>

        <table width="98%" cellspacing="0" cellpadding="0" class="tablebordermain">
          <tr>
            <td valign="top">
            <div align="center">
              <center>

              <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
                <tr>
                  <td width="425" valign="top">&nbsp;
                  <div align="center">
                    <center>

                    <table width="98%" cellpadding="0" class="tableborder2">
                      <tbody>
                        <tr>
                          <td width="43%" valign="top">

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="100%" height="18"></td>
                            </tr>
                          </table>

                          <table border="0" width="100%" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="20%">&nbsp; Cashier ID&nbsp;&nbsp;</td>
                              <td width="32%"><input name="txtCashierId" 
                              onblur="Dataarrange (txtCashierId);;DescrptionDisp(&quot;txtCashierId&quot;)"  
                              style="TEXT-TRANSFORM: uppercase" size="9" class="txtautofill"><input type="button" class="button" value=" L " name="B4" onclick="Cashiercode()" tabindex="0"><input name="txtCashierDesc" size="16" readonly class="bgcolor1"></td>
                            </tr>
                            <tr>
                              <td width="20%">&nbsp; Counter No&nbsp;</td>
                              <td width="32%"><input name="txtcounterno" size="11" class="txtautofill" style="TEXT-ALIGN: right" readonly>&nbsp;&nbsp;<input name="txtcountername" size="17" class="bgcolor1" style="TEXT-ALIGN: right" readonly></td>
                            </tr>
                            <tr>
                              <td width="20%">&nbsp; Amt Alloted&nbsp;</td>
                              <td width="32%"><input class="txtautofill" name="txtamount" size="11" style="TEXT-ALIGN: right" value="0.00" 
                              onkeypress="numdec(window.document.frmallot.txtamount.value,
                                  window.document.frmallot.hpr.value);" onblur="amtallotcheck();precision(window.document.frmallot.txtamount,
                              window.document.frmallot.hpr.value);CheckZero(window.document.frmallot.txtamount)"  tabindex="1"></td>
                            </tr>
                            <tr>
                              <td width="12%" height="30">&nbsp;</td>
                              <td width="41%" height="30">&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="12%" height="30">&nbsp;</td>
                              <td width="41%" height="30">&nbsp;</td>
                            </tr>
                            <tr>
                              <td width="12%" height="30"></td>
                              <td width="41%" height="30"></td>
                            </tr>
                            <tr>
                              <td width="12%" height="28"></td>
                              <td width="41%" height="28"></td>
                            </tr>
                            <tr>
                              <td width="12%" height="28"></td>
                              <td width="41%" height="28"></td>
                            </tr>
                            <tr>
                              <td width="12%" height="14"></td>
                              <td width="41%" height="14"></td>
                            </tr>
                             <tr>
                              <td width="12%" height="14"></td>
                              <td width="41%" height="14"></td>
                            </tr>
                             <tr>
                              <td width="12%" height="14"></td>
                              <td width="41%" height="14"></td>
                            </tr>
                            
                            
                          </table>

                    </table>

                    </div>
                  </center>
                  <td width="371" valign="top">
                  <div id="denom" align="center" style="width: 355; height: 60">
                    &nbsp;
                    <div align="center" id="cashdenom" style="display: block">
                      <center>

                      <table width="97%" cellpadding="0" class="tableborder2">
                        <tr>
                          <td width="100%">
                          <p align="center"><font class="textmaroon">Available
                          Denominations in Vault</font></td>
                        </tr>
                        <tr>
                          <td valign="top">
                          <div align="center">
                            <center>

                            <table border="0" cellspacing="0" cellpadding="0" width="60%" class="tablebordermain">
                              <tr>
                                <td valign="top"><iframe id=den align=center  
                                frameborder=0 framespacing=0   
                                noresize height=340 width=328 valign="top" 
                                src = "masterdenom.aspx" 
                  style="BACKGROUND-COLOR: darkred"></iframe></td>
                              </tr>
                            </table>

                            </center>
                          </div>
                      </table>

                      </center>
                    </div>
                  </div>
                  </td>
              </table>

              </center>
            </div>

            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="0">
              <tr>
                <td width="173">
                <%
					dim cashdenom
					
					cashdenom = session("cashdenomyn")
					
					if cashdenom="Y" then
					
                %>
					<center>
					<font size="2" face="MS Sans Serif" color="#cc0000"><span id="total" style="VISIBILITY: visible"><b>Vault Cash</b> </span></font><input type="text" name="txtValttot" size="9" value="0.00" class="bgcolor1" style="text-align: right" readonly onchange="precision(window.document.frmallot.txtValttot,window.document.frmallot.hpr.value)">
					</center>
					
                <%
					else
					
					end if
                %>
                
                </td>
                <td width="173">
                <%
					if cashdenom="Y" then
					
                %>
					<center>
					<font size="2" face="MS Sans Serif" color="#cc0000"><span id="total" style="VISIBILITY: visible"><b>Diff VC-AT </b></span></font><input type="text" name="txtDiff" size="9" value="0.00" class="bgcolor1" style="text-align: right" readonly onchange="precision(window.document.frmallot.txtDiff,window.document.frmallot.hpr.value)">
					</center>
					
                <%
					else
					
					end if
                %>
                
                </td>
                <td width="20%" align="right"><b><font size="2" face="MS Sans Serif" color="#cc0000"><span id="total" style="VISIBILITY: visible">Available Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></b></td>
                <td width="18%" align="left"><input type="text" name="txtavtotal" size="9" value="0.00" class="bgcolor1" style="text-align: right" readonly onchange="precision(window.document.frmallot.txtavtotal,window.document.frmallot.hpr.value)"></td>
                <td align="left" width="30%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="txttotal" value="0.00" size="9" class="bgcolor1" style="text-align: right" readonly onblur="precision(window.document.frmallot.txttotal,window.document.frmallot.hpr.value)"></td>
                <td width="9"></td>
              </tr>
              <tr>
                <td width="173" height="13"></td>
                <td width="173" height="13"></td>
                <td width="273" align="right" height="13" colspan="2"></td>
                <td align="middle" width="124" height="13"></td>
                <td width="9" height="13"></td>
              </tr>
              <tr>
                <td width="100%" height="13" colspan="6">
                <div align="center">
                  <center>

                  <table width="15%" cellspacing="0" cellpadding="0" class="tablebordermain">
                    <tr>
                      <td width="100%"><input type="button" value="    Ok    " name="buttInsert" onclick="Insert()" onblur='window.document.frmallot.buttcancel.focus()' tabindex="2" class="button"><input type="button" value="Cancel" name="buttcancel" tabindex="3" onclick="window.location.href='cashallot.aspx'" class="button"><input type="button" value="   Exit   " name="cmdexit" tabindex="4" class="button" onclick="location.replace(&quot;cashmodule.aspx&quot;)"></td>
                    </tr>
                  </table>

                  </div>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100%" height="20"></td>
                    </tr>
                  </table>

                </center>
            </table>

        </table>

        </center>
      </div>
    </tr>
  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="counter.aspx">
                                              </iframe>
      </td>
    </tr>
  </table>

  <input type="hidden" name="txtctotal"><input type="hidden" name="status"><input type="hidden" name="htype" value="0"><input type="hidden" name="hvalue" value="0"><input type="hidden" name="hpices" value="0"><input type="hidden" name="hcount" value="0"><input type="hidden" name="hpr">
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
				&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	


</form>

</body>

</html>
