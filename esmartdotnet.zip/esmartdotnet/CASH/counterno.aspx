<%@ Page Language="vb" CodeBehind="counterno.aspx.vb" AutoEventWireup="false" Inherits="eSmartDotNet.counterno" %>
<%dim obj,cntNo,con
  str=Request.QueryString("st")
  con=split(str,"|")
  set obj=server.CreateObject("AutoNumber.Generation")
  cntNo=obj.GetAutoNumber("cashcountermst","counterno","branchcode=" & cstr(con(0)) &"")
	
%>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<SCRIPT LANGUAGE=javascript>
<!--
function List()
{
	var str
	str=window.document.frmacc.hcno.value
	window.attachEvent(window.opener.com(str))
	window.close()
}
//-->
</SCRIPT>
<title></title>
</head>
<body onload="List()">

<form name="frmacc">
  <input type="hidden" id="hcno" name="hcno" value="<%=cntNo%>">
</form>

</body>

</html>
