<%@ Page Language="vb" aspcompat="true" explicit="false" AutoEventWireup="false" Codebehind="cashierrecieptsrep.aspx.vb" Inherits="eSmartDotNet.cashierrecieptsrep"%>
<HTML>
	<HEAD>
		<title>Cashier Receipts and Payments</title>
		<meta http-equiv="Content-Language" content="en-us">
		<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
		<meta name="ProgId" content="FrontPage.Editor.Document">
		<SCRIPT LANGUAGE="javascript">
<!--
function prnt()
{
// hide all the buttons from the printing of report
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
window.document.frmList.butok.style.visibility="hidden"
window.document.frmList.butprnt.style.visibility="hidden"
// Print the report 
window.print()
window.document.frmList.butok.style.visibility="visible"
window.document.frmList.butprnt.style.visibility="visible"

}
//-->
		</SCRIPT>
		<%
dim kstr, mainstr
	dim cnt
	dim rsfetch
	dim objfetch
	dim arrtrans(1,4)
	dim objfrm

'width 
wtable = "800"
	wrsno="40"
	wbatchno= "40" 
	wtranno = "60"
	wglcode = "40"
	waccno = "100"
	wname = "200"
	wremarks = "200"
	wamount = "70"
	wcashierid = "70"
	wtokenno =  "80"
 
  
 'Alignment
arsno="left"
abatchno= "left" 
atranno = "right"
aglcode = "right"
aaccno = "left"
aname = "left"
aremarks = "left"
aamount = "right"
acashierid = "left"
atokenno = "right"

'font
fdetdata = "3"
fheaddata = "4"

kstr=Request.QueryString("st")

	if len(kstr)>0 then				'''''' If kstr is not empty string
		kstr=split(kstr,"~")			'''''' Split it
		strwise = trim(kstr(0))
		seldate = trim(kstr(3))
		appdate=session("applicationdate")
		userid=session("userid")	'''''' User id
		brcode=ucase(trim(kstr(1)))	'''''' Branchcode
		crcode=ucase(trim(kstr(2)))	'''''' Currncycode
		StRep = trim(kstr(4))
	end if
	
	if StRep = "XL" then
		Response.ContentType = "application/vnd.ms-excel"
		Response.AddHeader ("Content-Disposition","attachment;filename=" & "CashRecPay.xls")
	end if	
	
ReportTitle = strwise & "  Report " & seldate

objfetch =server.CreateObject("ReportPurposeOnly.Reportonly") 
rs =server.CreateObject("adodb.recordset")
rsaddress=server.CreateObject("adodb.recordset")
RsDate = server.CreateObject("adodb.recordset")

objfetch1 =server.CreateObject("queryrecordsets.fetchrecordsets")

rsaddress=objfetch1.singlerecordset("genbankbranchmst a,GENBANKPARM b","a.branchname,a.addr2,a.addr3||','||a.addr4,a.addr5||'-'||a.addr6,b.bankname", "a.branchcode='" & brcode & "' and a.bankcode=b.bankcode")

RsDate = objfetch1.SingleRecordSet("GENAPPLICATIONDATEMST", _
            "to_char(APPLICATIONDATE,'dd-Mon-yyyy')", "branchcode='" & BrCode & "'")


if strwise = "Receipts" then
amount = 0

if cdate(rsdate(0).value)=cdate(seldate) then
strmain = " SELECT  B.RECEIPTSCROLLNO RSNO, A.BATCHNO, A.TRANNO, B.GLCODE, ''''||B. ACCNO, substr(initcap(B.NAME),1,30) name,  A.REMARKS,B.AMOUNT," & _
" B.CASHIERID FROM CASHRECEIPTSTRN B,CASHTRANDAY A WHERE B.GLCODE=A.LINKGLCODE AND B.MODULEID=A.LINKMODULEID " & _
" AND B.TRANNO=A.TRANNO AND B.APPLICATIONDATE=A.APPLICATIONDATE AND B.APPLICATIONDATE='" & seldate & "' AND " & _
" A.MODEOFTRAN= 1 AND B.AMOUNT=ABS(A.AMOUNT)  and b.branchcode='" & BrCode & "' AND b.branchcode=a.branchcode ORDER BY B.RECEIPTSCROLLNO, " & _
" A.BATCHNO, A.TRANNO"

else
strmain = " SELECT  B.RECEIPTSCROLLNO RSNO, A.BATCHNO, A.TRANNO, B.GLCODE, ''''||B. ACCNO, substr(initcap(B.NAME),1,30) name,  A.REMARKS,B.AMOUNT," & _
" B.CASHIERID FROM CASHRECEIPTSTRNBKP B,CASHTRAN A WHERE B.GLCODE=A.LINKGLCODE AND B.MODULEID=A.LINKMODULEID " & _
" AND B.TRANNO=A.TRANNO AND B.APPLICATIONDATE=A.APPLICATIONDATE AND B.APPLICATIONDATE='" & seldate & "' AND " & _
" A.MODEOFTRAN= 1 AND B.AMOUNT=ABS(A.AMOUNT) and b.branchcode='" & BrCode & "' AND b.branchcode=a.branchcode ORDER BY B.RECEIPTSCROLLNO, " & _
" A.BATCHNO, A.TRANNO"
end if

rsmain = objfetch.SingleSelectStat(strmain)

%>
	</HEAD>
	<body>
		<form name="frmList">
			<table width=<%=wtable%> align="left" border =0>
				<tr>
					<td colspan="9">
						<font color="#000000" size="3">
							<%''''' Report Headings%>
							<center>
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								<br>
								<br>
								<%'''''''Title of the report %>
								<%=ReportTitle%> 
								<br>
							</center>
						</font>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="9">User Id:
						<%=userid %>
						, Currency:
						<%=crcode %>, Date: <%=appdate%>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width=<%=wrsno%> align=<%=arsno%>>
						<font size=<%=fdetdata%>>RsNo</font>
					</td>
					<td width= <%=wbatchno%> align= <%=abatchno%>>
						<font size=<%=fdetdata%>>BtNo</font>
					</td>
					<td width= <%=wtranno %> align= <%=atranno%>>
						<font size=<%=fdetdata%>>TrNo</font>
					</td>
					<td width=<%=wglcode %> align=<%=aglcode%>>
						<font size=<%=fdetdata%>>GlCode</font>
					</td>
					<td width= <%=waccno %> align= <%=aaccno%>>
						<font size=<%=fdetdata%>>AccNo</font>
					</td>
					<td width=<%=wname %> align=<%=aname%> nowrap>
						<font size=<%=fdetdata%>>Name</font>
					</td>
					<td width=<%=wremarks %> align=<%=aremarks%>>
						<font size=<%=fdetdata%>>Remarks</font>
					</td>
					<td width=<%=wamount %> align=<%=aamount%>>
						<font size=<%=fdetdata%>>Amount</font>
					</td>
					<td width=<%=wcashierid %> align=<%=acashierid%>>
						<font size=<%=fdetdata%>>CshrId</font>
					</td>
					
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
<%				
if not rsmain.EOF and not rsmain.BOF then 

      do while not rsmain.EOF 

%>
							<tr>
								<td width= <%=wrsno %> align= <%=arsno %>>
								<font size=<%=fdetdata%>>	<%=rsmain(0).value %> </font>
								</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>
								<font size=<%=fdetdata%>>	<%=rsmain(1).value%> </font>
								</td>
								<td width= <%=wtranno %> align= <%=atranno%>>
									<font size=<%=fdetdata%>><%=rsmain(2).value	%></font>
								</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>
								<font size=<%=fdetdata%>><%=rsmain(3).value %> </font>
								</td>
								<td width= <%=waccno %> align= <%=aaccno%>>
									<font size=<%=fdetdata%>><%=rsmain(4).value	%></font>
								</td>
								<td width=<%=wname %> align=<%=aname%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(5).value %> </font>
								</td>
								<td width=<%=wremarks %> align=<%=aremarks%>>
								<font size=<%=fdetdata%>>	<%=rsmain(6).value %> </font>
								</td>
								<td width=<%=wamount %> align=<%=aamount%>>
								<font size=<%=fdetdata%>>	<%=FormatNumber(iif(isdbnull(rsmain(7).value),0,rsmain(7).value),2) %> </font>
								</td>
								<td width=<%=wcashierid %> align=<%=acashierid%>>
								<font size=<%=fdetdata%>>	<%=rsmain(8).value %> </font>
								</td>
							<%
							amount = amount  + cdbl(iif(isdbnull(rsmain(7).value),0,rsmain(7).value))	
							%>	
								
							</tr>
							<% rsmain.MoveNext 
							 loop
							end if	%>
				<tr>
					
								<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wglcode %> align= <%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>
				<tr>
					<td width="150" colspan="5"><font size=<%=fdetdata%>>
						Totals: </font></td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
			<!--	<td width=<%=wtranno %> align=<%=atranno %>><font size=<%=fdetdata%>><%=cnt%></font></td> -->
			
				<td width=<%=wamount %> align=<%=aamount %>><font size=<%=fdetdata%>><%=FormatNumber(amount,2)%></font></td>					
				</tr>
				<tr>
						<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width=<%=wname %> align=<%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>

				<tr>
					<td colspan="9">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="9">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="4" align="left">
						Verified By / Signature</td>
					<td colspan="5" align="right">
						Approved By / Signature</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="9">
						<center><input type="button" value="   Exit   " name="butok" onclick="location.href='cashierwisereport.aspx'"
								class="bgcolor"> <input type="button" value="  Print   " name="butprnt" onclick="prnt()"></center>
						</FONT></td>
				</tr>
			</table>
		</form>
	</body>
</HTML>
<%else if strwise = "Payments" then %>
<%
amount = 0

if cdate(rsdate(0).value)=cdate(seldate) then

strmain = "SELECT  B.PAYMENTSCROLLNO PSNO,  A.BATCHNO BTNO,A.TRANNO TRNO,A.TOKENNO TKNO,A.GLCODE, ''''||A.ACCNO," & _
" substr(initcap(A.NAME),1,30) name, A.REMARKS,ABS(A.AMOUNT) AMOUNT, A.CASHIERID FROM GENTRANSLOG A," & _
" CASHPAYMENTSTRN B WHERE A.APPLICATIONDATE='" & seldate & "'AND A.MODEOFTRAN=1 AND A.GLCODE<>201000 AND " & _
" A.TRANNO=B.TRANNO AND A.APPLICATIONDATE=B.APPLICATIONDATE AND A.CURRENCYCODE=B.CURRENCYCODE AND " & _  
" A.CASHIERID=B.CASHIERID AND B.BRANCHCODE = '"& BrCode &"' ORDER BY A.CASHIERID, B.PAYMENTSCROLLNO,  A.BATCHNO, A.TRANNO"

else

strmain = "SELECT  B.PAYMENTSCROLLNO PSNO,  A.BATCHNO BTNO,A.TRANNO TRNO,A.TOKENNO TKNO,A.GLCODE, ''''||A.ACCNO," & _
" substr(initcap(A.NAME),1,30) name, A.REMARKS,ABS(A.AMOUNT) AMOUNT, A.CASHIERID FROM GENTRANSLOGBKP A," & _
" CASHPAYMENTSTRNBKP B WHERE A.APPLICATIONDATE='" & seldate & "'AND A.MODEOFTRAN=1 AND A.GLCODE<>201000 AND " & _
" A.TRANNO=B.TRANNO AND A.APPLICATIONDATE=B.APPLICATIONDATE AND A.CURRENCYCODE=B.CURRENCYCODE AND " & _  
" A.CASHIERID=B.CASHIERID AND B.BRANCHCODE = '"& BrCode &"' ORDER BY A.CASHIERID, B.PAYMENTSCROLLNO,  A.BATCHNO, A.TRANNO"

end if

rsmain = objfetch.SingleSelectStat(strmain)

%>
	</HEAD>
	<body>
		<form name="frmList">
			<table width=<%=wtable%> align="left" border =0>
				<tr>
					<td colspan="10">
						<font color="#000000" size="3">
							<%''''' Report Headings%>
							<center>
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								<br>
								<br>
								<%'''''''Title of the report %>
								<%=ReportTitle%> 
								<br>
							</center>
						</font>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="10">User Id:
						<%=userid %>
						, Currency:
						<%=crcode %>, Date: <%=appdate%>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width=<%=wrsno%> align=<%=arsno%>>
						<font size=<%=fdetdata%>>PsNo</font>
					</td>
					<td width= <%=wbatchno%> align= <%=abatchno%>>
						<font size=<%=fdetdata%>>BtNo</font>
					</td>
					<td width= <%=wtranno %> align= <%=atranno%>>
						<font size=<%=fdetdata%>>TrNo</font>
					</td>
					<td width= <%=wtokenno %> align= <%=atokenno%>>
						<font size=<%=fdetdata%>>TkNo</font>
					</td>
					<td width=<%=wglcode %> align=<%=aglcode%>>
						<font size=<%=fdetdata%>>GlCode</font>
					</td>
					<td width= <%=waccno %> align= <%=aaccno%>>
						<font size=<%=fdetdata%>>AccNo</font>
					</td>
					<td width=<%=wname %> align=<%=aname%>>
						<font size=<%=fdetdata%>>Name</font>
					</td>
					<td width=<%=wremarks %> align=<%=aremarks%>>
						<font size=<%=fdetdata%>>Remarks</font>
					</td>
					<td width=<%=wamount %> align=<%=aamount%>>
						<font size=<%=fdetdata%>>Amount</font>
					</td>
					<td width=<%=wcashierid %> align=<%=acashierid%>>
						<font size=<%=fdetdata%>>CshrId</font>
					</td>
					
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						------------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
<%				
if not rsmain.EOF and not rsmain.BOF then 

      do while not rsmain.EOF 

%>
							<tr>
								<td width= <%=wrsno %> align= <%=arsno %>>
								<font size=<%=fdetdata%>>	<%=rsmain(0).value %> </font>
								</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>
								<font size=<%=fdetdata%>>	<%=rsmain(1).value%> </font>
								</td>
								<td width= <%=wtranno %> align= <%=atranno%>>
									<font size=<%=fdetdata%>><%=rsmain(2).value	%></font>
								</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>
									<font size=<%=fdetdata%>><%=rsmain(3).value	%></font>
								</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>
								<font size=<%=fdetdata%>><%=rsmain(4).value %> </font>
								</td>
								<td width= <%=waccno %> align= <%=aaccno%>>
									<font size=<%=fdetdata%>><%=rsmain(5).value	%></font>
								</td>
								<td width=<%=wname %> align=<%=aname%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(6).value %> </font>
								</td>
								<td width=<%=wremarks %> align=<%=aremarks%> nowrap>
								<font size=<%=fdetdata%>>	<%=rsmain(7).value %> </font>
								</td>
								<td width=<%=wamount %> align=<%=aamount%>>
								<font size=<%=fdetdata%>>	<%=FormatNumber(iif(isdbnull(rsmain(8).value),0,rsmain(8).value),2) %> </font>
								</td>
								<td width=<%=wcashierid %> align=<%=acashierid%>>
								<font size=<%=fdetdata%>>	<%=rsmain(9).value %> </font>
								</td>
							<%
							amount = amount  + cdbl(iif(isdbnull(rsmain(8).value),0,rsmain(8).value))	
							%>	
								
							</tr>
							<% rsmain.MoveNext 
							 loop
							end if	%>
				<tr>
					
								<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>&nbsp;</td>
								<td width= <%=wglcode %> align= <%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>
				<tr>
					<td width="150" colspan="6"><font size=<%=fdetdata%>>
						Totals: </font></td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width= <%=wname %> align= <%=aname%>>&nbsp;</td>
			<!--	<td width=<%=wtranno %> align=<%=atranno %>><font size=<%=fdetdata%>><%=cnt%></font></td> -->
			
				<td width=<%=wamount %> align=<%=aamount %>><font size=<%=fdetdata%>><%=FormatNumber(amount,2)%></font></td>					
				</tr>
				<tr>
						<td width= <%=wrsno %> align= <%=arsno %>>&nbsp;</td>
								<td width= <%=wbatchno%> align= <%=abatchno%>>&nbsp;</td>
								<td width= <%=wtranno %> align= <%=atranno%>>&nbsp;</td>
								<td width= <%=wtokenno %> align= <%=atokenno%>>&nbsp;</td>
								<td width=<%=wglcode %> align=<%=aglcode%>>&nbsp;</td>
								<td width= <%=waccno %> align= <%=aaccno%>>&nbsp;</td>
								<td width=<%=wname %> align=<%=aname%>>&nbsp;</td>
								<td width= <%=wremarks %> align= <%=aremarks%>>&nbsp;</td>
								<td width= <%=wamount %> align= <%=aamount%>>--------------</td>
								<td width= <%=wcashierid %> align= <%=acashierid%>>&nbsp;</td>
				</tr>

				<tr>
					<td colspan="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="5" align="left">
						Verified By / Signature</td>
					<td colspan="5" align="right">
						Approved By / Signature</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						<center><input type="button" value="   Exit   " name="butok" onclick="location.href='cashierwisereport.aspx'"
								class="bgcolor"> <input type="button" value="  Print   " name="butprnt" onclick="prnt()"></center>
						</FONT></td>
				</tr>
			</table>
		</form>
	</body>
</HTML>
<%else if strwise = "CONSCASHIER" then %>

<%

amount = 0

dim stTail,stqry,stAlotbal, stRes
dim objBal, rsBal, objPay, rsPay, objRec, rsRec
dim stRecTot, stPayTot, stClosbal

stRecTot = 0
stPayTot = 0
stClosbal = 0

rsBal = server.CreateObject("adodb.recordset")
objBal = server.CreateObject("ReportPurposeOnly.Reportonly") 
objPay = server.CreateObject("ReportPurposeOnly.Reportonly")  
rsPay = server.CreateObject("adodb.recordset")
objRec = server.CreateObject("ReportPurposeOnly.Reportonly")  
rsRec = server.CreateObject("adodb.recordset")

if cdate(rsdate(0).value)=cdate(seldate) then
	stTail = ""
else
	stTail = "BKP"
end if
stAlotbal = 0

stqry = "" 
''stqry = "SELECT OPENINGBAL FROM CASHBALANCE WHERE applicationdate='" & seldate & "' AND branchcode='"& BrCode &"'"

stqry = "SELECT CLOSINGBAL FROM CASHBALANCE WHERE applicationdate=(SELECT TO_CHAR(MAX(applicationdate),'dd-Mon-yyyy') dat FROM cashbalance WHERE branchcode='"& BrCode &"' AND applicationdate<'" & seldate & "') AND branchcode='"& BrCode &"'" 

rsBal = objfetch.SingleSelectStat(stqry)

if not rsBal.EOF and not rsBal.BOF then 
	do while not rsBal.EOF
		stAlotbal = cdbl(stAlotbal)+cdbl(rsBal(0).value)
	rsBal.MoveNext()
	loop
end if

strmain = " SELECT DISTINCT Cashierid FROM CASHALLOTMENTSTRN" & stTail & " WHERE BRANCHCODE = '" & BrCode & "' AND APPLICATIONDATE='" & seldate & "' "

rsmain = objfetch.SingleSelectStat(strmain)

if not rsmain.EOF and not rsmain.BOF then 
	do while not rsmain.EOF
	
	stRes = stRes & rsmain(0).value & ","
	
	stqry = ""
	''for Receipts Details
    stqry = " SELECT Cashierid,COUNT(*) crcnt,nvl(SUM(Amount),0) cramt FROM CASHRECEIPTSTRN" & stTail & " WHERE BRANCHCODE = '" & BrCode & "' AND APPLICATIONDATE='" & seldate & "' AND Cashierid = '" & rsmain(0).value & "'  GROUP BY Cashierid  "  
    
    rsPay = objPay.SingleSelectStat(stqry)
    
    if objPay.ConnError="Connected" then
		if not rsPay.bof and not rsPay.eof then
			do until rsPay.eof
				stRes = stRes & rsPay(1).value & "," & rsPay(2).value & ","
				stRecTot = cdbl(stRecTot) + cdbl(rsPay(2).value)
			rsPay.movenext()
			loop
			
		else
			stRes = stRes & "0,0,"
		end if
		rsPay = nothing
	end if
	
	stqry = ""
	''for Payments Details
    stqry = " SELECT Cashierid,COUNT(*) crcnt,nvl(SUM(Amount),0) cramt FROM CASHPAYMENTSTRN" & stTail & " WHERE BRANCHCODE = '"& BrCode &"' AND APPLICATIONDATE='" & seldate & "' AND Cashierid = '" & rsmain(0).value & "'  GROUP BY Cashierid  "  
    
    rsRec = objRec.SingleSelectStat(stqry)
    
    if objRec.ConnError="Connected" then
		if not rsRec.bof and not rsRec.eof then
			do until rsRec.eof
				stRes = stRes & rsRec(1).value & "," & rsRec(2).value & ","
				stPayTot = cdbl(stPayTot) + cdbl(rsRec(2).value)
			rsRec.movenext()
			loop
		else
			stRes = stRes & "0,0,"
		end if
		rsRec = nothing
	end if
	
	stRes = mid(stRes,1,stRes.length-1)
    
    stRes = stRes & "|"
    
    rsmain.MoveNext()
	loop
	
	stRes = mid(stRes,1,stRes.length-1)
end if

%>
</HEAD>
	<body>
		<form name="frmList">
			<table width=<%=wtable%> align="left" border =0>
				<tr>
					<td colspan="10">
						<font color="#000000" size="3">
							<%''''' Report Headings%>
							<center>
								<%=iif(isdbnull(rsaddress(4).value),"",rsaddress(4).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(0).value),"",rsaddress(0).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(1).value),"",rsaddress(1).value)%>
								<br>
								<%=iif(isdbnull(rsaddress(3).value),"",rsaddress(3).value)%>
								<br>
								<br>
							</center>
						</font>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="10"><font size=<%=fdetdata%>> Receipts And Payments As On Date : <%=seldate%></font></td>
				</tr>
				<tr>
					<td align="center" colspan="10">User Id:
						<%=userid %>
						, Currency:
						<%=crcode %>, Date: <%=appdate%>
					</td>
				</tr>
				<tr>
					<td align="left" colspan="10">
						<font size=<%=fdetdata%>><b>Opening Balance : <%=stAlotbal%></b></font>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						----------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width="160" align="right" colspan="2">
						<font size=<%=fdetdata%>>Cashier Id</font>
					</td>
					<td width= "160" align="right" colspan="2">
						<font size=<%=fdetdata%>>No.OFReceipts</font>
					</td>
					<td width= "160" align="right" colspan="2">
						<font size=<%=fdetdata%>>Receipts</font>
					</td>
					<td width= "160" align="right" colspan="2">
						<font size=<%=fdetdata%>>No.OFPayments</font>
					</td>
					<td width="160" align="right" colspan="2">
						<font size=<%=fdetdata%>>Payments</font>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						----------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
<%				dim stCnt,stReval


				if stRes <> "" then
					
					stCnt  = stRes.split("|")
					
					for i=0  to ubound(stCnt)
					%>
				<tr>
				<%
					stReval = stCnt(i).split(",")
						
						for j = 0 to ubound(stReval) %>
						
						<td align="right" colspan="2" width= "160"><font face="courier new" color="#000000" size="2"><%=stReval(j)%></font></td> 
					
					<%
						next j %>
				</tr>
					<% next i 
				  
				else   %>
				<tr>
					<td width=<%=wtable%> colspan="10"><font face="courier new" color="#000000" size="2">No Records Found </font></td> 
				</tr>
					
				<%	end if %>
				<tr>
					<td width=<%=wtable%> colspan="10">
						----------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<tr>
				
					<td width="160" align=<%=atranno%> colspan="2">
						<font face="courier new" size="2"></font>
					</td>
					<td width= "160" align= <%=atranno%> colspan="2">
						<font face="courier new" size="2">Total</font>
					</td>
					<td width= "160" align= <%=atranno%> colspan="2">
						<font face="courier new" size="2"> <%=stRecTot%> </font>
					</td>
					<td width= "160" align= <%=atranno%> colspan="2">
						<font face="courier new" size="2"></font>
					</td>
					<td width="160" align=<%=atranno%> colspan="2">
						<font face="courier new" size="2"> <%=stPayTot%></font>
					</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						----------------------------------------------------------------------------------------------------------------------------------
					</td>
				</tr>
				<%
					 stClosbal = cdbl(stAlotbal) + cdbl(stClosbal)+ cdbl(stRecTot) - cdbl(stPayTot)
				%>
				<tr>
					<td align="left" colspan="10" >
						<font size=<%=fdetdata%>><b>Closing Balance : <%=stClosbal%></b></font>
					</td>
				</tr>
				<tr>
					<td colspan="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" width="240" align="left">
						Verified By / Signature</td>
					<td colspan="7" width="560" align="right">
						Approved By / Signature&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td width=<%=wtable%> colspan="10">
						<center><input type="button" value="   Exit   " name="butok" onclick="location.href='cashierwisereport.aspx'"
								class="bgcolor"> <input type="button" value="  Print   " name="butprnt" onclick="prnt()"></center>
						</FONT></td>
				</tr>
			</table>
		</form>
	</body>
</HTML>

<%end if%>