<%@ Page aspcompat="true" explicit="false" Language="vb" AutoEventWireup="false" Codebehind="frmCashReceiptTrans.aspx.vb" Inherits="eSmartDotNet.frmCashReceiptTrans" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>STR Alert Generation</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir") & "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir") & "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">

function SetValues()
{
window.document.frmCashierReport.txtRepvaultdate.value = "<%=session("applicationdate")%>"
}

function branch()
{  
	st="Bruser"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
	splitString("window.document.frmCashierReport","txtCurrencyCode,txtCurrencyDesc,txtcid,"+
				"txtcdesc,txtRepdate")
		
}	
function Bruser(kstr)
{	
	assign(kstr,window.document.frmCashierReport.txtBranchDesc,
	window.document.frmCashierReport.txtBranchCode)
}	
///for sending parameters to list form for CurrencyCode
function currency()
{	
if(window.document.frmCashierReport.txtBranchCode.value=="")
{
	alert("Select BranchCode")
	return;
}
	st="Curr"
	window.showModalDialog("List.aspx" + "?"+"st="+st,window,"status:no;"+
			"DialogWidth:300px;DialogHeight:150px;DialogLeft:120px;DialogTop:320px")
			
	splitString("window.document.frmCashierReport","txtcid,"+
				"txtcdesc,txtRepdate")
}
//displaying cashiercode,name which are returned by list page
function  Currid(kstr)
{var p,prn,j,k
  var k=kstr.split("-----")
  window.document.frmCashierReport.txtCurrencyDesc.value =k[0]
  window.document.frmCashierReport.txtCurrencyCode.value =k[1]

  var prn=eval(k[2].length)-1
  window.document.frmCashierReport.hpr.value=prn
  p=""
  for(j=1;j<=prn;j++)
  {
    p=p + "0"
  }
	pres= "0." + p
	
	
 }	

function TempDataGenerate(strrep)
{
var stt=""

	window.document.frmCashierReport.hidRep.value = strrep

	if(window.document.frmCashierReport.txtBranchCode.value=="")
	{
		
		alert("Enter All Fields")
		return;
	}
	
	if(window.document.frmCashierReport.txtRepvaultdate.value=="")
	{
	alert("Enter Report Date")
		return;
	}
	
	if(window.document.frmCashierReport.txtAccBalAmt.value=="")
	{
	alert("Enter Amount")
		return;
	}
	


	var st1 = "Receipts" +"~"+ window.document.frmCashierReport.txtBranchCode.value +"~"+ window.document.frmCashierReport.txtCurrencyCode.value +"~"+ window.document.frmCashierReport.txtRepvaultdate.value +"~"+ strrep +"~"+ window.document.frmCashierReport.cmbaccbaloper.value +"~"+ window.document.frmCashierReport.txtAccBalAmt.value
	
	
	
	window.document.frmCashierReport.action="cashtranreceiptreport.aspx?st="+st1
	window.document.frmCashierReport.method="post"
	window.document.frmCashierReport.submit();
}

</script>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
 function datecheck(obj)
		{
			var dt,arrDt
			if(obj.value=="")
				return;

			dt = obj.value
			dt=dt.toUpperCase();
			arrDt = dt.split("-")
			if(eval(arrDt[0].length)!=2)
				arrDt = dt.split("/")

			if(eval(arrDt[0].length)==2)
			{
				switch(arrDt[1])
				{
					case "JAN" :	arrDt[1]= "01";
									break ; 
					case "Jan" :	arrDt[1]= "01";
									break ; 				
					case "FEB" :	arrDt[1]= "02";
									break ;
					case "Feb" :	arrDt[1]= "02";
									break ;				 
					case "MAR" :	arrDt[1]= "03";
									break ; 
					case "Mar" :	arrDt[1]= "03";
									break ; 				
					case "APR" :	arrDt[1]= "04";
									break ; 
					case "Apr" :	arrDt[1]= "04";
									break ; 				
					case "MAY" :	arrDt[1]= "05";
									break ;
					case "May" :	arrDt[1]= "05";
									break ; 				 
					case "JUN" :	arrDt[1]= "06";
									break ; 
					case "Jun" :	arrDt[1]= "06";
									break ;				
					case "JUL" :	arrDt[1]= "07";
									break ; 
					case "Jul" :	arrDt[1]= "07";
									break ; 				
					case "AUG" :	arrDt[1]= "08";
									break ; 
					case "Aug" :	arrDt[1]= "08";
									break ;
					case "SEP" :	arrDt[1]= "09";
									break ; 
					case "Sep" :	arrDt[1]= "09";
									break ; 				
					case "OCT" :	arrDt[1]= "10";
									break ; 
					case "Oct" :	arrDt[1]= "10";
									break ; 				
					case "NOV" :	arrDt[1]= "11";
									break ; 
					case "Nov" :	arrDt[1]= "11";
									break ; 				
					case "DEC" :	arrDt[1]= "12";
									break ; 
					case "Dec" :	arrDt[1]= "12";
									break ; 										
				}
				
				dt = arrDt[0]+arrDt[1]+arrDt[2]
				obj.value = dt
			}
			formatDate(obj)
						
			var intDiff=getDateDiff(window.document.frmCashierReport.txtRepvaultdate.value, "<%=session("applicationdate")%>")
			
			if(intDiff>0)
			{
				alert("Date Should Not be Greater Than Application Date.")
				window.document.frmCashierReport.txtRepvaultdate.value=""
			}
		}
		
		function formatDate(obj)
		{
			if(obj.value!="")
			{
				var dateval=obj.value;
				dateval=dateval.replace('-','');
				dateval=dateval.replace('-','');
				dateval=dateval.replace('/','');
				dateval=dateval.replace('/','');
				len=dateval;
				if(len.length!=8)
				{
					alert("Enter Date In Valid Date Format");
					obj.value=""
					obj.select();
					return false;
				}
				else
				{  
					dd=len.substring(0,2);
					dd=dd+'-';
					mm=len.substring(2,4);
					mm=mm+'-';
					yy=len.substring(4,8);
					date1=dd+mm+yy;
					noDays=getDays((len.substring(2,4)-1),yy)
					if((len.substring(0,2)>31)||(len.substring(2,4)>12))
					{
						alert('No Of Days (or) Months Exceeds The Limit');
						obj.value=""
						obj.focus();
						obj.select();
						return false;
					}
					else if((len.substring(0,2)<1)||(len.substring(2,4)<1))
					{
						alert('No Of Days (or) Months Not Equal To Zero');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(4,8)<1950)
					{
						alert('Year Should Not Be Less Than 1950');
						obj.focus();
						obj.select();
						return false;
					}
					else if(len.substring(0,2)>noDays)
					{
						alert("Enter DD Value Not More Than "+noDays);
						obj.focus();
						obj.select();
						return false;
					}
					else
					{
						obj.value=date1;
						copyDtls(obj)
					}
				}
			}
		}
		
		function getDays(month,year)
		{
			var monarr=new Array(12);
			monarr[0]=31
			monarr[1]=(leapYear(year))?29:28
			monarr[2]=31
			monarr[3]=30
			monarr[4]=31
			monarr[5]=30
			monarr[6]=31
			monarr[7]=31
			monarr[8]=30
			monarr[9]=31
			monarr[10]=30
			monarr[11]=31
			return monarr[month]
		}
		
		function copyDtls(obj)
		{
			var dt,arrDt
			
			if(obj.value=="")
			return;
			
			dt = obj.value
			arrDt = dt.split("-")

			switch(arrDt[1])
			{
				case "01" :	arrDt[1]= "JAN";
								break ; 
				case "02" :	arrDt[1]= "FEB";
								break ; 
				case "03" :	arrDt[1]= "MAR";
								break ; 
				case "04" :	arrDt[1]= "APR";
								break ; 
				case "05" :	arrDt[1]= "MAY";
								break ; 
				case "06" :	arrDt[1]= "JUN";
								break ; 
				case "07" :	arrDt[1]= "JUL";
								break ; 
				case "08" :	arrDt[1]= "AUG";
								break ; 
				case "09" :	arrDt[1]= "SEP";
								break ; 
				case "10" :	arrDt[1]= "OCT";
								break ; 
				case "11" :	arrDt[1]= "NOV";
								break ; 
				case "12" :	arrDt[1]= "DEC";
								break ; 						
			}

			dt = arrDt[0]+"-"+arrDt[1]+"-"+arrDt[2]
			obj.value = dt
		}
		
		function leapYear(year)
		{
			if(year%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        
        //date condition for any format
        
        function getDateDiff(strDate1, strDate2)
		{
			var strArrDate1, strArrDate2
			strArrDate1=strDate1.split("-")
			strArrDate2=strDate2.split("-")
			strArrDate1[1]=changeMonth(strArrDate1[1])
			strArrDate2[1]=changeMonth(strArrDate2[1])
							
			return parseFloat(Date.parse(strArrDate1[0]+" "+strArrDate1[1]+", "+strArrDate1[2]))-parseFloat(Date.parse(strArrDate2[0]+" "+strArrDate2[1]+", "+strArrDate2[2]));
		}
				
		function changeMonth(str)
		{
			var strMonth
			str=str.toUpperCase()
			
			if(str=="JAN")
				strMonth="January"
			else if(str=="FEB")
				strMonth="February"
			else if(str=="MAR")
				strMonth="March"
			else if(str=="APR")
				strMonth="April"
			else if(str=="MAY")
				strMonth="May"
			else if(str=="JUN")
				strMonth="June"
			else if(str=="JUL")
				strMonth="July"
			else if(str=="AUG")
				strMonth="August"
			else if(str=="SEP")
				strMonth="September"
			else if(str=="OCT")
				strMonth="October"
			else if(str=="NOV")
				strMonth="November"
			else if(str=="DEC")
				strMonth="December"
			
			return strMonth;
		}
</script>

</head>
<body topmargin="0" leftmargin="0" topmargin="0" leftmargin="0" 
onload="GetMenu(&quot;<%=session("menustring")%>&quot;);SetValues()">

<form name="frmCashierReport">
<div class="header">
<table  cellpadding="0" cellspacing="0" width="99%"><tr><td align="left" class="bankHeaderLogo"></td><td align="right" class="esmartBankerLogo"></td></tr></table>			
		</div>
    
		<div class="menuBar">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td width="20%"><font face="arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>&nbsp;&nbsp;Welcome, </i>&nbsp;&nbsp;<%=session("userid") & " - " & session("userName")%></font></td>
					<td width="2%" height="22" class="subHeader"><%=vTotNarr%><span id="spnCashBal" style="VISIBILITY: visible"><%=vTotAmt%></span></td>
					<td width="35%" align="center" height="22" class="subHeader"><h2>STR Alert Generation Report</h2></td>
					<td width="25%" height="22" align="right" class="subHeader"><%=formatdatetime(session("applicationdate"),1)%></td>
				</tr>
			</table>
		</div><div id="menucontrol"></div>


  <table width="100%" border="0" height="74%" cellspacing="0" cellpadding="0" class="tblebordermain">
    <tr>
      <td>

    

    <tr>
      <td width="100%" valign="top">

    

      <%appdate=formatdatetime(session("applicationdate"),1)%>


      <table border="0" width="100%" cellspacing="0" cellpadding="0" >
        <tr>
          <td width="100%" height="29">
          <div align="center">
            <center>

            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr class="bgcolor">
                <td width="12%" height="27">
                <p align="right">&nbsp;Branch Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                </td>
                <td width="30%" height="27"><input class="txtautofill" name="txtBranchCode" style="TEXT-TRANSFORM: uppercase" 
                size="9" value="<%=session("branchcode")%>" onblur="Dataarrange(txtBranchCode);CashierDisp(&quot;txtBranchCode&quot;)" maxlength="10"><input type="button" class="button" value=" L " name="B3" onclick="branch()"><input name="txtBranchDesc" size="16" class="bgcolor1" value="<%=session("branchnarration")%>" readonly></td>
                
                <td width="15%" align="right" height="27">Currency Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td width="30%" height="27"><input class="txtautofill" name="txtCurrencyCode" style="TEXT-TRANSFORM: 
                          uppercase" size="9" maxlength="10" onblur="Dataarrange(txtCurrencyCode);CashierDisp(&quot;txtCurrencyCode&quot;)" value="<%=session("currencycode")%>"><input type="button" class="button" value=" L " name="B9" onclick="currency()"><input name="txtCurrencyDesc" size="16" class="bgcolor1" value="<%=session("currencynarration")%>" readonly></td>
              </tr>
         
            </table>

            </center>
          </div>

</td>
    </tr>
    
        <tr>
          <td width="100%" >
  <div id="divvault" style="display: block">
							<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
								
								<tr>
									<td width="100%">
										<table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder1">
											<div>
												<tr class="bgcolor1">
													
													<td align="middle" width="50%"><font class="textblack"><input name="optVaultTran" onclick="VaultCheck()" type="radio"  checked></font><input name="txtreceipts" readonly size="10" class="bgcolor4" value =  "Receipts" style="background-color:transparent;BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; font-size: 14px;TEXT-ALIGN: left " ></td>
												<!--	<td align="middle" width="50%"><p align="center"><font class="textblack"><input name="optVaultTran" onclick="VaultCheck()" type="radio" > &nbsp;<input name="txtpayments" readonly size="10" class="bgcolor4" value = "Payments" style="background-color:transparent;BORDER-BOTTOM-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-TOP-STYLE: none; COLOR: #663300;  font-size: 14px; TEXT-ALIGN: left "></font></p></td> -->
													<td align="middle" width="27%"></td>
												</tr>
											</div>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table border="1" width="100%" cellspacing="0" cellpadding="0">
											<tr>
												<td width="50%" height="27" align="right">Report Date&nbsp;&nbsp;&nbsp;&nbsp;</td>
												<td width="12%" height="27"><input type="text" name="txtRepvaultdate" id="txtRepvaultdate" maxlength=10 onblur="datecheck(this)" size="11">(DDMMYYYY)</td>
												<td width="12" height="27">
                         &nbsp;

												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</div>
</td></tr>
<tr>
                      <td width="30%" align="center">
                 
                      <div id="divname" style="display:block" align="center">
                              <table border="0" width="30%" cellspacing="0" cellpadding="0">                              
                                <tr>
                                  <td width="12%">&nbsp;Operator</td>
                                  <td width="13%"><select size="1" name="cmbaccbaloper" onchange="toDateDisp()">
                                    <option value="=">=</option>
                                    <option value="&gt;">&gt;</option>
                                    <option value="&lt;">&lt;</option>
                                  
                                  </select></td>
                                  <td width="13%" align=left>&nbsp;&nbsp;&nbsp;Amount</td>
                                  <td width="8%" align=left><input type="text" name="txtAccBalAmt" size="11" maxlength="16" 
                                  onkeypress="numdecminus(window.document.frmCashierReport.txtAccBalAmt.value,window.document.frmCashierReport.hpr.value)" 
                                  onblur="numbercheck(window.document.frmCashierReport.txtAccBalAmt);precision(window.document.frmCashierReport.txtAccBalAmt,
									window.document.frmCashierReport.hpr.value);" class="txtautofill"></td>
                                  
                                </tr>
                              </table>
                            </div>
                     </td>
                    </tr>
     <tr>
          <td width="100%" height="32"><center>
          <div align="center">
            <center>

            <table width="30%" cellspacing="0" cellpadding="0" class="tablebordermain">
              <tr>
                <td width="100%"><input type="button" value="Generate" name="cmdAdd" onclick="TempDataGenerate('HTML')" class="button">
               
                <input type="button" value="XL Generate" name="cmdAdd" onclick="TempDataGenerate('XL')" class="button">
               
                <input type="reset" value="Cancel" name="cmdCancel" onclick="location.href=&quot;Cashierwisereport.aspx&quot;" class="button"><input type="button" value="   Exit   " name="cmdexit" class="button" onclick="window.location.href=&quot;http://<%=session("moduledir")& "/" & session("module")& "/" & session("module")& "module.aspx"%>&quot;"  width="100%" height="20"></td>
              </tr>
            </table>

            <input type="hidden" name="hpr" value="<%=session("PRECISION")%>">
            <input type="hidden" name="hreport">
            </div>
          </center></center></td>
        </tr>
  </table>
   
  <input type="hidden" name="hmod" value="<%=session("module")%>"><input type="hidden" name="status"><input type="hidden" name="hidRep">

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
                                              <iframe id="iBatch" align=center 
                                              frameBorder=0 frameSpacing=0  
                                              height=0 width=0 src="cashcountermgtquery.aspx">
                                              </iframe>
      </td>
    </tr>
  </table>
<div class="footer">
			<div class="logo"></div>
			<div class="copyRight">
					&copy; E-Smart Banker - A Product of SAS Enterprises
			</div>
		</div>	
</form>


</body>

</html>