<%@ Page CodeBehind="denominationmaster.aspx.vb" Language="vb" AutoEventWireup="false" Inherits="eSmartDotNet.denominationmaster" %>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../styletag.css">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Cash Denomination</title>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/proc.js"%>"> </SCRIPT>
<SCRIPT LANGUAGE=javascript src="<%="http://" & session("moduledir")& "/val.js"%>"> </SCRIPT>
<script language="JavaScript" src="<%="http://" & session("moduledir")&"/dhtmllib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/MenuLib.js"%>" ></script>
<script language="JavaScript" src="<%="http://" & session("moduledir")& "/navbar.js"%>" ></script>
<SCRIPT LANGUAGE="javascript">
<script language="javascript">

function load()
{
init()
window.document.frmdenom.txtcurrencycode.value ="INR"
window.document.frmdenom.txtcurrencydesc.value="INDIAN RUPEES"  
window.document.frmdenom.butDelete.disabled =true
window.document.frmdenom.butModify.disabled =true 
window.document.frmdenom.butSave.disabled =true
window.document.frmdenom.butOk.disabled =true  
window.document.frmdenom.hstr.value="I"       
       
}

function currency()
{ 
  st="Currency"
  window.open("List.asp" + "?"+"st="+st,st,"width=220%,height=150% left=110 top=220")
}

function Currencyid(str)
{ 
  assign(str,window.document.frmdenom.txtcurrencydesc,window.document.frmdenom.txtcurrencycode)
}

function maxdenom()
{

if(window.document.frmdenom.hstr.value=="I")
{     
b=window.document.frmdenom.txtdenomval.value
if(b.length!=0)    
{
a=window.document.frmdenom.fgdenom.TextMatrix(1,3).length
if(a==0)
{
	crint=window.document.frmdenom.txtcurrencycode.value 
	crlater=window.document.frmdenom.fgdenom.TextMatrix(window.document.frmdenom.fgdenom.Rows-1,1)
        
	s=window.document.frmdenom.txtcurrencycode.value 
	s1=window.document.frmdenom.txtdenomval.value 
	s2=window.document.frmdenom.optdenomtype.value  
	st=s + "|"+ s1 + "|" + s2  + "|" + "I"    
   
	window.open("maxdenom.asp" + "?"+"st="+st,"hello","width=1%,height=1%")
}
else
{
	crint=window.document.frmdenom.txtcurrencycode.value 
	crlater=window.document.frmdenom.fgdenom.TextMatrix(window.document.frmdenom.fgdenom.Rows-2,1)
	dcode=window.document.frmdenom.fgdenom.TextMatrix(window.document.frmdenom.fgdenom.Rows-2,3)
if(crint!=crlater)
{
	s=window.document.frmdenom.txtcurrencycode.value 
	s1=window.document.frmdenom.txtdenomval.value 
	s2=window.document.frmdenom.optdenomtype.value 
	st=s + "|"+ s1 + "|" + s2 + "|" + "I"     
	window.open("maxdenom.asp" + "?"+"st="+st,"hello","width=1%,height=1%") 
} 
else
{	
	window.document.frmdenom.txtdenomno.value ="D" +(parseInt(dcode.substr(1))+1)       
}
}
}
else
{
	alert("Denomination Value Should Not Be Null")
}  
}
else
{
	s=window.document.frmdenom.txtcurrencycode.value 
	s1=window.document.frmdenom.txtdenomval.value 
	s2=window.document.frmdenom.optdenomtype.value  
	st=s + "|"+ s1 + "|" + s2 +  "|" + "M"     
   
	window.open("maxdenom.asp" + "?"+"st="+st,"hello","width=1%,height=1%")

}
}
function maxdenomcode(str)
{
if(str.length<13) 	
{
	appdate=str
	return;
}
	str1=str.substr(0,4)

	if(str1!="This")
	{
	window.document.frmdenom.butOk.disabled =false   
	window.document.frmdenom.butSave.disabled =false   
	c=str.indexOf("|")
	appdate=str.substr(c+1)
	str1=str.substr(0,c)
	e=str1.substr(1)
	b=e.length
	if(b>0)
	{
	a=parseInt(e)+1
	
	window.document.frmdenom.txtdenomno.value ="D" + a   
	}
	else
	{
		window.document.frmdenom.txtdenomno.value ="D" + 1   
	}
		window.document.frmdenom.hdate.value =appdate

	}
else
	{
	
	window.document.frmdenom.hdate.value =appdate
	window.document.frmdenom.txtdenomval.focus()    
	}
}



function save()
{
	var i,j,hvalue,hvalue1,str,appdate
		j=window.document.frmdenom.fgdenom.Rows-2
		for(i=1;i<=j;i++)
	{
		appdate=window.document.frmdenom.hdate.value    		
		cur= window.document.frmdenom.fgdenom.TextMatrix(i,1)
		val= window.document.frmdenom.fgdenom.TextMatrix(i,4)
		type= window.document.frmdenom.fgdenom.TextMatrix(i,2) 
		code= window.document.frmdenom.fgdenom.TextMatrix(i,3) 
		str="'" + cur + "'" + "," + "'" + type + "'" + "," + "'" + code + "'" + "," + "'" + val + "'" + "," + "'V3'" + "," + "'V3'" + "," + "'" + appdate + "'" + "," + "'" + appdate + "'"
		hvalue1=hvalue1 + str + "  |  "
	}
	if(j>0)
	{
		hvalue=hvalue1.substr(9)+  "I"
		window.document.frmdenom.hstr.value =hvalue  
		window.document.frmdenom.action="denommasterinsert.asp"
		window.document.frmdenom.method="post"   
		window.document.frmdenom.submit()
}	
	else
	{
		alert("No Records Added To Grid")
	}
  
}



var  r
r=0
function display()
{
	window.document.frmdenom.hstr.value ="I"
	crint=window.document.frmdenom.txtcurrencycode.value 
	crlater=window.document.frmdenom.fgdenom.TextMatrix(window.document.frmdenom.fgdenom.Rows-1,1)
	if(window.document.frmdenom.txtcurrencycode.value=="")
	{
		alert("Currency Code should Not Be Null")	
	return;
	}
	else if(window.document.frmdenom.txtdenomval.value=="")
	{
		alert("Denomnation Value should Not Be Null")
		return;
	}
	else if(window.document.frmdenom.txtdenomno.value=="")
	{
		alert("Denomnation Code should Not Be Null")
		return;
	}

	if(r==0)
	{
	 r=1
	}

j=window.document.frmdenom.fgdenom.rows

if(r==window.document.fgdenom.Rows - 1)
{   
   window.document.frmdenom.fgdenom.Rows = window.document.frmdenom.fgdenom.Rows + 1  
}

for(k=1;k<=j-1;k++)
{   
   if((window.document.frmdenom.fgdenom.TextMatrix(k,1)==window.document.frmdenom.txtcurrencycode.value) && (window.document.frmdenom.fgdenom.TextMatrix(k,2)== window.document.frmdenom.optdenomtype.value) && (window.document.frmdenom.fgdenom.TextMatrix(k,4)== window.document.frmdenom.txtdenomval.value))
   {
	alert("This Denomination Already Added To Grid")
	return;
   }
}
	window.document.fgdenom.TextMatrix(r,0)=r
	window.document.fgdenom.TextMatrix(r,1)=window.document.frmdenom.txtcurrencycode.value    
	window.document.fgdenom.TextMatrix(r,2)=window.document.frmdenom.optdenomtype.value    

if(r==1)
{
	window.document.fgdenom.TextMatrix(r,3)="D" +(window.document.frmdenom.txtdenomno.value.substring(2))
	window.document.fgdenom.TextMatrix(r,4)=window.document.frmdenom.txtdenomval.value
}
else 
{
if(crint==crlater)
{
	window.document.fgdenom.TextMatrix(r,3)="D" + (window.document.fgdenom.TextMatrix(r-1,3).substring(2)+1)
	window.document.fgdenom.TextMatrix(r,4)=window.document.frmdenom.txtdenomval.value
}	
else
{
	window.document.fgdenom.TextMatrix(r,3)="D" + (window.document.frmdenom.txtdenomno.value.substring(2))
	window.document.fgdenom.TextMatrix(r,4)=window.document.frmdenom.txtdenomval.value
}	
}




window.document.frmdenom.txtdenomval.value=""
window.document.frmdenom.txtdenomno.value=""
r = r + 1
r = window.document.fgdenom.Rows - 1
window.document.frmdenom.butSave.disabled =false   
}

function List()
{
	window.document.frmdenom.fgdenom.Clear()    
	window.document.frmdenom.hstr.value="M"   
	st=window.document.frmdenom.txtcurrencycode.value    
	window.open("denomlist.asp?"+"st="+st,"hello","width=1%,height=1% left=300 top=296") 	
}

function listcode(str)
{
var j,n,m,r,b,st
j=0
n=0
m=0
r=0
b=""
st=""

var balstr=new String()
var balstr1=new String()
var balstr2=new String()
	balstr=str.split("$")
	n=balstr[1]	
	st=balstr[0]			
	balstr1=st.split("|")	
	window.document.frmdenom.fgdenom.FormatString ="^   Sno   |^   Type    |^   Code    |>    Value   " 
	window.document.frmdenom.fgdenom.Rows  =n+1	
	window.document.frmdenom.fgdenom.Cols=4	
	
	for(j=1;j<=n;j++)
	{	
		window.document.frmdenom.fgdenom.TextMatrix(j,0)=j    				
		
		for(m=0;m<=2;m++)
		{	
			
			balstr2=balstr1[j-1].split(",")  						
			window.document.frmdenom.fgdenom.TextMatrix(j,m+1)=balstr2[m]
		}

	}
window.document.frmdenom.butOk.disabled =true
window.document.frmdenom.butSave.disabled =true 	 	
}

function remove()
{
	if(window.document.frmdenom.txtdenomval.value=="")
	{ 
		alert("Denomination Value Should Not Be Null")
	}	
	else if(window.document.frmdenom.txtdenomno.value=="")
	{
		alert("Denomination Code Should Not Be Null")	
	}	
	else    
	{
		window.document.frmdenom.txtcurrencycode.disabled =false   
		window.document.frmdenom.txtdenomno.disabled =false
		window.document.frmdenom.hstr.value =""
		window.document.frmdenom.action="denommasterinsert.asp"
		window.document.frmdenom.method ="post"
		window.document.frmdenom.hstr.value ="D"     
		window.document.frmdenom.hdate.value =appdate
		window.document.frmdenom.submit()        
	}		
		
}

function modify()
{
		window.document.frmdenom.txtcurrencycode.disabled =false   
		window.document.frmdenom.txtdenomno.disabled =false
		window.document.frmdenom.action="denommasterinsert.asp"
		window.document.frmdenom.method ="post"
		window.document.frmdenom.submit()        
		window.document.frmdenom.hstr.value ="M"  
		window.document.frmdenom.hdate.value =appdate 	 		
}

 function cancel()
 {
	var i,j
	j=window.document.frmdenom.fgdenom.Rows    
	window.document.frmdenom.hstr.value ="I"
	window.document.frmdenom.txtdenomval.value =""   
	window.document.frmdenom.txtdenomno.value =""
	window.document.frmdenom.fgdenom.Clear() 
	location.replace("denominationmaster.asp") 
}

//-->
</script>



<SCRIPT LANGUAGE=vbscript>
Sub fgdenom_EnterCell
	window.document.frmdenom.fgdenom.CellBackColor=vbYellow
	window.document.frmdenom.fgdenom.CellForeColor=vbRed
End Sub
Sub fgdenom_LeaveCell
	window.document.frmdenom.fgdenom.CellBackColor=vbWhite
	window.document.frmdenom.fgdenom.CellForeColor=vbBlack
End Sub

</SCRIPT>


<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function fgdenom_Click()
{
  var m,n,p,s,str,strbal,cnt
	m=0
	n=0  
	p=0  
		
	 var st =new String()  
  if(window.document.frmdenom.butSave.disabled==true)
  {
			i=window.document.frmdenom.fgdenom.Row        
			p=window.document.frmdenom.optdenomtype.length        
			strbal=window.document.frmdenom.fgdenom.TextMatrix(i,1)     				                      
     for(m=0;m<=p-1;m++)
	{		
		str=window.document.frmdenom.optdenomtype.options[m].text           
		str=str.toString()
		strbal=strbal.toString()		 
          if(str==strbal)
          {							
			window.document.frmdenom.optdenomtype.item(m).selected=true;
			return
          }  		
	}															   
     
   window.document.frmdenom.txtdenomno.value =window.document.frmdenom.fgdenom.TextMatrix(i,2)    
   window.document.frmdenom.txtdenomval.value  =window.document.frmdenom.fgdenom.TextMatrix(i,3)
   a= window.document.frmdenom.txtdenomval.value    
  if(a.length>0)
  {
   window.document.frmdenom.txtcurrencycode.disabled=true    
   window.document.frmdenom.txtdenomno.disabled=true
   window.document.frmdenom.txtcurrencydesc.disabled =true 
   window.document.frmdenom.butModify.disabled =false
   window.document.frmdenom.butDelete.disabled =false      
   
 }
}


}

//-->
</SCRIPT>
<SCRIPT LANGUAGE=javascript FOR=fgdenom EVENT=Click>
<!--
 fgdenom_Click()
//-->
</SCRIPT>
</head>
<body topmargin="0" leftmargin="0" onload="init();load()">

<form name="frmdenom">

  <table width="100%" cellspacing="0" cellpadding="0" class="tablebordermain">
    <tr>
      <td width="100%">

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="11%" height="28"></td>
          <td width="89%" height="28">

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr class="bgcolor">
              <td width="100%"><img name="placeholder" border="0" src="file://comserver/c/cashfinal/dscript42/transparent.gif" width="1" height="22"></td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="34%" height="25"></td>
          <td width="33%" height="25">
          <p align="center"><font class="text">Denomination Master</font></td>
          <td width="33%" height="25" align="right"></td>
        </tr>
      </table>

      <center>
	  <%appdate=formatdatetime(date(),1)%>	

      <table width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="75%" height="15"><font class="textblue">
          <p align="center"><%=Request.QueryString("record")%></font></td>
        </tr>
      </table>

      </center>
<table border="0" width="98%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%">

                  <table border="0" width="100%" cellspacing="00" cellpadding="0" class="tableborder1">
                    <tr class="bgcolor1">
                      <td align="middle" width="26%">
                      <p align="center"><font class="textwhite"><input name="optTran" onclick="mode=&quot;ADD&quot;;;ClearFlds();EnableControls()" type="radio" value="INSERT" checked>
                      New</font></p>
                      </td>
                      <td align="middle" width="27%"><font class="textwhite"><input name="optTran" onclick="mode=&quot;MODIFY&quot;;ClearFlds();EnableControls()" type="radio" value="MODIFY">
                      Modify</font></td>
                      <td align="middle" width="31%"><font class="textwhite"><input name="optTran" onclick="mode=&quot;DELETE&quot;;;ClearFlds();EnableControls()
                    " type="radio" value="DELETE"> &nbsp;Delete</font></td>
                      <td align="middle" width="22%">
                      <p align="center"><font class="textwhite"><input name="optTran" onclick="mode=&quot;VIEW&quot;;;ClearFlds();DisableControls()" type="radio" value="VIEW">
                      &nbsp;View&nbsp;&nbsp;</p>
                      </font></td>
                    </tr>
                  </table>

                  </td>
                </tr>
                <tr>
                  <td width="100%"></td>
                </tr>
              </table>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr class="bgcolor">
          <td width="100%" height="22">
          <p align="center"></p>
          </td>
        </tr>
        <tr>
          <td width="100%">

          <table border="0" width="100%" cellspacing="0" cellpadding="0" class="tableborder2">
            <tr>
              <td width="21%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Currency Code</td>
              <td width="44%"><input name="txtcurrencycode" size="9" readonly><input type="button" value=" L " name="B3" onclick="currency()"><input name="txtcurrencydesc" size="16" readonly></td>
              <td width="19%" align="right">Denomination Type&nbsp;&nbsp;&nbsp;&nbsp;</td>
              <td width="25%"><select size="1" name="optdenomtype">
                <option value="NF" selected>NF</option>
                <option value="NP">NP</option>
                <option value="CF">CF</option>
                <option value="CP">CP</option>
              </select></td>
            </tr>
            <tr>
              <td width="21%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Denomination Value</td>
              <td width="44%"><input name="txtdenomval" size="9" onkeypress="numeric()" onblur="maxdenom()"></td>
              <td width="19%" align="right">Denomination Code&nbsp;&nbsp;&nbsp;&nbsp;</td>
              <td width="25%"><input name="txtdenomno" size="9" readonly></td>
            </tr>
            <tr>
              <td width="21%" height="21"></td>
              <td width="44%" height="21"></td>
              <td width="19%" height="21"></td>
              <td width="25%" height="21"></td>
            </tr>
            <tr>
              <td width="100%" colspan="4" height="21">
              <div align="center">
                <center>

                <table border="0" width="10%" cellspacing="0" cellpadding="0" class="tablebordermain">
                  <tr>
                    <td width="100%"><input type="button" value="   Ok   " name="butOk" onclick="display()" class="bgcolor"><input type="button" value="  List  " name="butList" onclick="List()" class="bgcolor"></td>
                  </tr>
                </table>

                </center>
              </div>
              </td>
            </tr>
            <tr>
              <td width="100%" colspan="4" height="21">

              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="100%" height="15"></td>
                </tr>
                <tr>
                  <td width="100%">
                  <div align="center">
                    <center>

                    <table width="31%" cellspacing="0" cellpadding="0" class="tableborder2">
                      <tr>
                        <td>
                        <object classid="clsid:6262D3A0-531B-11CF-91F6-C2863C385E30" height="137" id="fgdenom" name="fgdenom" style="HEIGHT: 137px; LEFT: 0px; TOP: 0px; WIDTH: 345px" width="345">
                          <param name="_ExtentX" value="9128">
                          <param name="_ExtentY" value="3625">
                          <param name="_Version" value="393216">
                          <param name="Rows" value="2">
                          <param name="Cols" value="5">
                          <param name="FixedRows" value="1">
                          <param name="FixedCols" value="0">
                          <param name="RowHeightMin" value="0">
                          <param name="BackColor" value="-2147483643">
                          <param name="ForeColor" value="-2147483640">
                          <param name="BackColorFixed" value="-2147483633">
                          <param name="ForeColorFixed" value="-2147483630">
                          <param name="BackColorSel" value="-2147483635">
                          <param name="ForeColorSel" value="-2147483634">
                          <param name="BackColorBkg" value="8421504">
                          <param name="GridColor" value="12632256">
                          <param name="GridColorFixed" value="0">
                          <param name="WordWrap" value="0">
                          <param name="Redraw" value="-1">
                          <param name="AllowBigSelection" value="-1">
                          <param name="ScrollTrack" value="0">
                          <param name="Enabled" value="-1">
                          <param name="RightToLeft" value="0">
                          <param name="TextStyle" value="0">
                          <param name="TextStyleFixed" value="0">
                          <param name="FocusRect" value="1">
                          <param name="HighLight" value="1">
                          <param name="FillStyle" value="0">
                          <param name="GridLines" value="1">
                          <param name="GridLinesFixed" value="2">
                          <param name="ScrollBars" value="2">
                          <param name="SelectionMode" value="0">
                          <param name="MergeCells" value="0">
                          <param name="AllowUserResizing" value="0">
                          <param name="PictureType" value="0">
                          <param name="BorderStyle" value="1">
                          <param name="Appearance" value="1">
                          <param name="MousePointer" value="0">
                          <param name="GridLineWidth" value="1">
                          <param name="FormatString" value="^   Sno   |^   Currency    |^   Type    |^   Code    |&gt;  Value   ">
                          <param name="OLEDropMode" value="0">
                        </object>
                        </td>
                      </tr>
                    </table>

                    </center>
                  </div>
                  </td>
                </tr>
                <tr>
                  <td width="100%" height="10"></td>
                </tr>
              </table>

              </td>
            </tr>
          </table>

          </td>
        </tr>
      </table>

      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" height="15"></td>
        </tr>
      </table>

      </td>
    </tr>
    <input type="hidden" name="hstr"><input type="hidden" name="hdate">
    </form>

    <tr>
      <td>

      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="10">
        <tr>
          <td width="100%"></td>
        </tr>
        <tr>
          <td>
          <div align="center">
            <center>

            <table width="20%" class="tablebordermain">
              <tr>
                <td width="300%" align="center"><input type="button" value=" Add  " 
                name="butSave" onclick="save()" 
                class="bgcolor"><input type="button" 
                value=" Modify " name="butModify" 
                onclick="modify()" class="bgcolor"><input 
                type="button" value="Delete" 
                name="butDelete" onclick="remove()" 
                class="bgcolor"><input type="button" 
                value="Cancel" name="butCancel" 
                onclick="cancel()" class="bgcolor"></td>
              </tr>
            </table>

            </center>
          </div>

          <table border="0" width="100%" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" height="10"></td>
            </tr>
          </table>

        </tr>
      </table>

  </table>

  <table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
      <div align="center">
        <center>

        <table border="0" width="90%" cellspacing="0" cellpadding="0">
          <tr>
            <td width="100%"><iframe id="ibills" align=center frameBorder=0 frameSpacing=0  height=0 width=300 src="billsonblu.asp">
            </iframe>
            </td>
          </tr>
        </table>

        </center>
      </div>
      </td>
    </tr>
  </table>

</body>

</html>
