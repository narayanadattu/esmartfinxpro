Public Class cDBConnection
    Public Function GetDbConnection(ByRef o_Errmsg As String) As OracleClient.OracleConnection
        o_Errmsg = ""
        Dim objDBConnection As OracleClient.OracleConnection
        ''Dim clsPwd As New GeneratePwd.clsGeneratePasswordClass
        Dim strpassword As String
        Dim strUserId1 As String
        ''strUserId1 = "scott"
        ''gDBUserId = "scott"
        ''gDBPassword = "tiger"
        gDBTNSName = "V3" ''clsPwd.getDS()
        gDBPassword = "RamSmart2020"
        ''gConnectionString = "User Id=" & gDBUserId & _
        ''                        " ;password=" & gDBPassword & "; Data Source=" & gDBTNSName & ";"

        ''''connect and get the dynamic password
        ''Try
        ''    objDBConnection = New OracleClient.OracleConnection
        ''    With objDBConnection
        ''        .ConnectionString = gConnectionString
        ''        .Open()
        ''        If .State = ConnectionState.Open Then
        ''            GetDbConnection = objDBConnection
        ''        Else
        ''            GetDbConnection = Nothing
        ''            o_Errmsg = "Failed To Open Database Connection"
        ''        End If
        ''    End With

        ''    Dim resDBdate As OracleClient.OracleDataReader
        ''    Dim recCmd As OracleClient.OracleCommand
        ''    Dim seqName As String
        ''    Dim dtDate As Date


        ''    Dim sqname As String
        ''    gDBUserId = clsPwd.getMU()
        ''    strUserId1 = gDBUserId
        ''    sqname = "SELECT LatestDaybegindate FROM DBDATE"

        ''    recCmd = New OracleClient.OracleCommand(sqname, objDBConnection)
        ''    resDBdate = recCmd.ExecuteReader
        ''    If resDBdate.Read Then
        ''        '  dtDate = resDBdate!LatestDaybegindate

        ''        gDBUserId = clsPwd.getMU()
        ''        gDBPassword = clsPwd.getPassword(resDBdate!LatestDaybegindate & "/bank/city/grams")
        ''        gDBTNSName = clsPwd.getDS()
        ''        gConnectionString = "User Id=" & gDBUserId & " ;password=" & gDBPassword & ";Data Source=" & _
        ''                            gDBTNSName & ";"
        ''    Else
        ''        dtDate = "Batch No Is Locked"
        ''    End If
        ''    resDBdate.Close()
        ''    objDBConnection.Close()
        ''    GetDbConnection = Nothing
            ''Try to connect with the dynamic passord
        Try

            objDBConnection = New OracleClient.OracleConnection
            With objDBConnection
                .ConnectionString = "User Id=" & gDBUserId & " ;password=" & gDBPassword & ";Data Source=" & _
                                    gDBTNSName & ";"
                .Open()
                If .State = ConnectionState.Open Then
                    GetDbConnection = objDBConnection
                Else
                    GetDbConnection = Nothing
                    o_Errmsg = "Failed To Open Database Connection"
                End If
            
End With
            Exit Function
        Catch ex As Exception
            o_Errmsg = ""
            If Err.Number = 5 Then
                If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12154" Then
                    o_Errmsg = "Please Enter Correct Connect String in TNS Names (TNS:could not resolve service name)"
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" And strUserId1 = "scott" Then
                    o_Errmsg = "User/password not found while trying to get dbdate."
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" And strUserId1 = "v3" Then
                    o_Errmsg = "Main UserName/password not Tallied."
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12535" Or Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12560" Then
                    o_Errmsg = "Server or Network Not Available. (TNS:operation timed out)."
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12514" Then
                    o_Errmsg = "Server not up (Please startup the database.) or " & Chr(13) & Chr(13) & "Verify the Serviece name Mentioned in Tnsnames file is correct (TNS:listener could not resolve SERVICE_NAME given in connect descriptor)"
                    o_Errmsg = "Server not up or verify names in tns name or Listener could not  resolved"
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12505" Then
                    o_Errmsg = "Server is up But Oracle instance not yet started or TNS:listener could not resolve SID given in connect descriptor"
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-12545" Then
                    o_Errmsg = "Please Verify your systems Network connection to the Server OR Please Verify the HOST Mentioned in the Tnsnames file is correct or ORA-12545: Connect failed because target host or object does not exist"
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01034" Then
                    o_Errmsg = "Database is NOT STARTED UP to connect. To start database please click on Start Up DB button."
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
                    o_Errmsg = "DBDATE: Table or View does not exist."
                ElseIf Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
                    o_Errmsg = "DBDATE: Grant Not Given."
                Else
                    o_Errmsg = "Connection Failed Due To : " & Err.Number & " : " & Err.Description
                End If

                'ElseIf Err.Number = -2147217843 Then
                '    If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-01017" Then
                '        If gDBUserId = "scott" Then
                '            o_Errmsg = "User/password not found while trying to get dbdate."
                '        ElseIf gDBUserId = "v3" Then
                '            o_Errmsg = "Main UserName/password not Tallied."
                '        End If
                '    End If
                'ElseIf Err.Number = -2147217865 Then
                '    If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00942" Then
                '        o_Errmsg = "DBDATE: Table or View does not exist."
                '    End If
                'ElseIf Err.Number = -2147217900 Then
                '    If Mid(Err.Description, 1, InStr(1, Err.Description, ":", vbTextCompare) - 1) = "ORA-00904" Then
                '        o_Errmsg = "DBDATE: Grant Not Given."
                '    End If
                '    ''' End If
            Else
                o_Errmsg = "Unable to connect to Main User .Contact Raminfo"

            End If
            ''Try to connect with default password if connection with dynamic pwd fails
            'Try
            'o_Errmsg = ""
            '    objDBConnection = New OracleClient.OracleConnection
            '    With objDBConnection
            '        gDBPassword = clsPwd.getMUP()
            '        .ConnectionString = "User Id=" & gDBUserId & ";password=" & gDBPassword & ";Data Source=" & _
            '                            gDBTNSName & ";"
            '        .Open()
            '        If .State = ConnectionState.Open Then
            '            GetDbConnection = objDBConnection
            '        Else
            '            GetDbConnection = Nothing
            '            o_Errmsg = "Failed To Open Database Connection"
            '        End If
            '    End With
            '    Exit Function
            'Catch ex As Exception
            '    GetDbConnection = Nothing
            '    o_Errmsg = ex.Message
            'End Try

        End Try
    End Function
    Public Function getUserPwd(ByRef UserId, ByRef Pwd, ByRef TnsName)
        UserId = gDBUserId
        Pwd = gDBPassword
        TnsName = gDBTNSName
    End Function
    Public Function GetBatchno(ByVal Branchcode As String) As String
        Dim o_errmsg As String
        Dim objcon As OracleClient.OracleConnection
        Try
            If Branchcode = "" Then
                GetBatchno = "Branch Code should be sent or Sequence doesnot exists"
                Exit Function
            End If
            objcon = GetDbConnection(o_errmsg)
            If o_errmsg <> "" Then
                GetBatchno = o_errmsg
                Exit Function
            End If

            Dim recBatch As OracleClient.OracleDataReader
            Dim recCmd As OracleClient.OracleCommand
            Dim seqName As String
            seqName = "SEQBATCHNO" & Branchcode

            Dim sqname As String
            sqname = "select " & seqName & ".nextval BatchNo from dual"

            ' recBatch = AdoConnObj.Execute(sqname, adCmdText)
            recCmd = New OracleClient.OracleCommand(sqname, objcon)
            recBatch = recCmd.ExecuteReader
            If recBatch.Read Then
                GetBatchno = recBatch!batchno
            Else
                GetBatchno = "Batch No Is Locked"
            End If
            recBatch.Close()
            objcon.Close()
        Catch ex As Exception
            GetBatchno = ex.Message
        End Try

    End Function
    Public Function GetTranNo(ByVal Branchcode As String) As String

        Dim o_errmsg As String
        Dim objcon As OracleClient.OracleConnection
        Try
            If Branchcode = "" Then
                GetTranNo = "Branch Code should be sent or Sequence doesnot exists"
                Exit Function
            End If
            objcon = GetDbConnection(o_errmsg)
            If o_errmsg <> "" Then
                GetTranNo = o_errmsg
                Exit Function
            End If

            Dim recBatch As OracleClient.OracleDataReader
            Dim recCmd As OracleClient.OracleCommand
            Dim seqName As String
            seqName = "SEQTRANNO" & Branchcode

            Dim sqname As String
            sqname = "select " & seqName & ".nextval Tranno from dual"

            ' recBatch = AdoConnObj.Execute(sqname, adCmdText)
            recCmd = New OracleClient.OracleCommand(sqname, objcon)
            recBatch = recCmd.ExecuteReader
            If recBatch.Read Then
                GetTranNo = recBatch!Tranno
            Else
                GetTranNo = "Tran No Is Locked"
            End If
            recBatch.Close()
            objcon.Close()
        Catch ex As Exception
            GetTranNo = ex.Message
        End Try
    End Function

    Function getAppDate(ByVal strBrcd As String) As Date
        Dim objDBCon As New OracleClient.OracleConnection
        Dim objCon As New DatabaseConnection.cDBConnection
        Dim dr As OracleClient.OracleDataReader
        Dim objCmd As OracleClient.OracleCommand
        Dim strCmd As String, errMsg As String
        Dim dtAppDt As Date

        objDBCon = objCon.GetDbConnection(errMsg)
        If errMsg <> "" Then
            MsgBox("Connection Failed " & errMsg, MsgBoxStyle.Critical, "Esmart Utilities")
            Exit Function

        Else
            strCmd = "select APPLICATIONDATE from GENAPPLICATIONDATEMST where branchcode='" & strBrcd & "'"

            objCmd = New OracleClient.OracleCommand(strCmd, objDBCon)

            dtAppDt = objCmd.ExecuteScalar

            getAppDate = dtAppDt

            If objDBCon.State = ConnectionState.Open Then
                objDBCon.Close()
            End If
        End If

    End Function

End Class
