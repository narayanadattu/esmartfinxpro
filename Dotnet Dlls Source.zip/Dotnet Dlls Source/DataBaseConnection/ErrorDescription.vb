Public Class ErrorDescription

    Public Function ErrorProcess(ByVal ErrNumber As String, _
     ByVal ErrDesc As String, ByVal ErrClientDesc As String, _
     ByRef o_ErrMsg As String, _
     Optional ByVal ComponentName As String = "", _
     Optional ByVal Branchode As String = "", _
     Optional ByVal UserId As String = "", _
     Optional ByVal MachineID As String = "") As Boolean

        Dim drError As OracleClient.OracleDataReader
        Dim strquery As String, bTransBegin As Boolean = False
        Dim resaff As Integer
        Dim comm As OracleClient.OracleCommand
        Dim objDbConnection As New cDBConnection
        Dim dbconnection As New OracleClient.OracleConnection
        Dim dbtransaction As OracleClient.OracleTransaction

        Try
            '''' STEP 1: Get  DataBaseConnection and start transaction
            dbconnection = objDbConnection.GetDbConnection(o_ErrMsg)
            If o_ErrMsg.Trim.Length > 0 Then Throw New Exception(o_ErrMsg)
            dbtransaction = dbconnection.BeginTransaction
            bTransBegin = True

            strquery = ""
            If Right(Trim(ErrNumber), 1) = ":" Then
                ErrNumber = UCase(Trim(Mid(ErrNumber, 1, _
                InStr(1, UCase(Trim(ErrNumber)), ":") - 1)))
            Else
                ErrNumber = UCase(Trim(ErrNumber))
            End If
            Branchode = UCase(Trim(Branchode))

            'Step 2: If the error is of type ORACLE error, then Get generalised 
            '        oracle error message from GenErrorMst. If no record found
            '        with the given oracle error number, then insert a row into it

            strquery = "Select ErrorNumber,OraNarration,ClientNarration from " & _
                " GENERRORMST where" & _
                " upper(trim(errornumber))='" & UCase(Trim(ErrNumber)) & "'"

            comm = New OracleClient.OracleCommand(strquery, dbconnection)
            comm.Transaction = dbtransaction
            drError = comm.ExecuteReader

            If drError.Read = False Then
                'i.e. if there is no details found for the given oracle error 
                'So, insert the oracle error details into GenErrorMst table for 
                'further reference

                strquery = "Insert into GENERRORMST(ErrorNumber,OraNarration," & _
                    "ClientNarration) values ('" & ErrNumber & "','" & _
                    ErrDesc & "','" & ErrDesc & "')"

                comm = New OracleClient.OracleCommand(strquery, dbconnection)
                comm.Transaction = dbtransaction
                resaff = comm.ExecuteNonQuery

                If resaff <> 1 Then
                    'dbtransaction.Rollback() 'transaction rollbacked
                    'dbconnection.Close()   'DB connection closed
                    'ErrorProcess = False
                    'bTransBegin = False
                    o_ErrMsg = "Unbale to insert error details into " & _
                        "GenErrorMst table. Actual Error is " & ErrDesc
                    'Exit Function
                    Throw New Exception(o_ErrMsg)
                End If
                comm = Nothing
            Else
                'i.e. Generalised oracle error message found in GenErrorMst table
                'So, return the same message to end user
                If UCase(Left(Trim(ErrNumber), 3)) = "ORA" Then
                    'ErrDesc = drError!oranarration
                    ErrClientDesc = drError!CLIENTNARRATION
                End If
            End If
            drError.Close()

            'Step 2: Insert generated error details into GenErrorLog table

            ErrClientDesc = Replace(ErrClientDesc, "'", "")
            ErrClientDesc = Replace(ErrClientDesc, "(", "")
            ErrClientDesc = Replace(ErrClientDesc, ")", "")
            ErrDesc = Replace(ErrDesc, "'", "")
            ErrDesc = Replace(ErrDesc, "(", "")
            ErrDesc = Replace(ErrDesc, ")", "")

            strquery = "Insert into GenErrorlog(ErrorNumber,ClientNarration," & _
             " ORACLENARRATION,Branchcode, userid,machineid,errordate," & _
             " ErrorComponent )" & _
             " Values('" & ErrNumber & "', '" & ErrClientDesc & "'," & _
             " '" & ErrDesc & "','" & Branchode & "','" & UserId & "'," & _
             " '" & MachineID & "'," & " to_date('" & Format(Now, _
             "dd-MMM-yyyy HH:MM") & "','dd-mon-yy HH24:mi:ss'), '" & ComponentName & "')"

            comm = New OracleClient.OracleCommand(strquery, dbconnection)
            comm.Transaction = dbtransaction
            resaff = comm.ExecuteNonQuery

            If resaff <> 1 Then
                'dbtransaction.Rollback()  'transaction rollbacked
                'dbconnection.Close()  'DB connection closed
                'ErrorProcess = False
                o_ErrMsg = "Unbale to insert error details into " & _
                    "GenErrorLog table. Actual Error is " & ErrDesc

                'Exit Function
                Throw New Exception(o_ErrMsg)
            End If

            'Commit the transaction
            If bTransBegin = True Then
                dbtransaction.Commit()
                bTransBegin = False
            End If
            dbconnection.Close()
            ErrorProcess = True

        Catch ex As Exception
            If bTransBegin = True Then
                dbtransaction.Rollback()
            End If
            dbconnection.Close()
            comm = Nothing
            ErrorProcess = False
            If Trim(o_ErrMsg) <> "" Then
                o_ErrMsg = ex.Message & ". This is an Error from GenErrorLog and the" & _
                    " actual error occured at client transaction is " & _
                    ErrClientDesc
            End If

        End Try
    End Function
End Class
