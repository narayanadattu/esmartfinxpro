Module ModGeneral

    Public gObjOracleConnection As System.Data.OracleClient.OracleConnection
    Public gDBUserId As String = "v3"
    Public gDBPassword As String = "RamSmart2020"
    Public gDBTNSName As String = "v3"
    Public gConnectionString As String 

End Module
