Public Class updateHistTable

    Public Function recordInHist(ByVal TableName As String, _
      ByVal FldNames As String, _
      ByRef gObjOracleConnection As OracleClient.OracleConnection, _
      ByRef objTransaction As OracleClient.OracleTransaction, _
      ByRef returnMsg As String, ByRef rowsAffectedCnt As Integer, _
      Optional ByVal WhereCondition As String = "", _
      Optional ByVal BranchCode As String = "", _
      Optional ByVal UserCode As String = "", _
      Optional ByVal MachineID As String = "", _
      Optional ByVal ApplicationDate As String = "") As Boolean

        ' This is used to insert data into its History Table
        ' INPUTS :
        ' TableName : Table Name, from which data isto be inserted into its history
        ' FldNames  : Which Fields are getting updated in the main table
        ' gObjOracleConnection : Oracle Connection object, which is already opened
        ' objTransaction : Oracle Transaction Object, respective to opened connection
        ' returnMsg : Hold and Return error description, if it occurs
        ' rowsAffectedCnt : Hold and return the No. Of Rows effected while inserting
        '     data into its history table. 
        ' WhereCondition : Condition to insert data into History table
        ' BranchCode : Branch Code in which a/c's are existed
        ' UserCode   : Login User Id
        ' MachineID  : Login Machine Id
        ' ApplicationDate : Current Application Date 
        ' OUTPUTS : Possible cases are
        '     i) if given table extension not found in "Hist required table extensions"
        '        then this rowsAffectedCnt = -1 and o/p of this function is TRUE
        '    ii) if all the given columns found in "Hist not required columns list"
        '        then this rowsAffectedCnt = -1 and o/p of this function is TRUE
        '   iii) If data was sucessfully inserted into its history table 
        '        then rowsAffectedCnt = actual effected rows count returned by command 
        '        and o/p of this function is TRUE
        '   iv)  If runtime exception iccured, then o/p of this function is FALSE and 
        '        "returnMsg" variable will hold error description

        Dim arrflds As Object
        Dim strHistExt As String
        Dim StrCondition As Object, StrTabName, strfields As String
        Dim BlnHistStatus As Boolean
        Dim drHistCol As OracleClient.OracleDataReader
        Dim drHistExt As OracleClient.OracleDataReader
        Dim cmd As OracleClient.OracleCommand
        Dim sQuery, strComponent As String
        Dim arrErrSplit As Object
        Dim errNum, errDesc, clntDesc, makeFldsAsString As String
        Dim strfieldsarr As Object
        Dim i As Short

        Try
            returnMsg = ""
            StrTabName = UCase(Trim(TableName))
            strfields = UCase(FldNames)
            strfieldsarr = Split(strfields, ",")
            For i = 0 To UBound(strfieldsarr)
                If (makeFldsAsString = "") Then
                    makeFldsAsString = "'" & strfieldsarr(i) & "'"
                Else
                    makeFldsAsString = makeFldsAsString & ",'" & strfieldsarr(i) & "'"
                End If
            Next
            StrCondition = WhereCondition
            arrflds = Split(strfields, ",", -1)

            BlnHistStatus = False
            strHistExt = ""

            'Step1: Verify whether the given table extension is listed under 
            ' "History maintained tables extension list" or not
            cmd = New OracleClient.OracleCommand("Select * from" & _
                            " GENHISTNOTREQUIREDTABEXTNS", gObjOracleConnection)
            cmd.Transaction = objTransaction
            drHistExt = cmd.ExecuteReader
            cmd.Dispose()
            cmd = Nothing
            While drHistExt.Read

                If Right(StrTabName, Len(Trim(drHistExt!TABEXTENSIONNAME))) = UCase _
                (Trim(drHistExt!TABEXTENSIONNAME)) Then
                    strHistExt = Trim(drHistExt!TABBKPEXTENSIONNAME)
                    BlnHistStatus = True
                    Exit While
                End If

            End While

            If BlnHistStatus = False Then
                'Given table extension is not found in "Hist maintained table
                ' extension". So skip this "insret into Hist" process.
                rowsAffectedCnt = -1
                recordInHist = True
                drHistExt.Close()
                drHistExt = Nothing
                'cmd = Nothing
                Exit Function
            End If
            drHistExt.Close()
            drHistExt = Nothing


            Dim ICount As Integer
            Dim iHistRequiredColsCount As Integer = 0

            'Step2: Given table found in "History tobe maintained table extensions
            'list" and user has mentioned column names on which update process 
            'is to be done. Then verify that at least one column is not found in
            '"History not required columns list"

            If (BlnHistStatus = True) And Trim(strfields) <> "" Then

                'For ICount = 0 To UBound(arrflds)
                'sQuery = "Select nvl(count(*),0) from GENHISTNOTREQUIREDCOLNAME" & _
                '" where upper(columnname)='" & UCase(Trim(arrflds(ICount))) & "'"

                sQuery = "Select nvl(count(*),0) from GENHISTNOTREQUIREDCOLNAME" & _
             " where upper(columnname) in(" & makeFldsAsString & ")"

                cmd = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                cmd.Transaction = objTransaction
                drHistCol = cmd.ExecuteReader
                cmd.Dispose()
                cmd = Nothing

                If drHistCol.Read = True Then
                    'If drHistCol(0) = 0 Then
                    If drHistCol(0) <> (UBound(strfieldsarr) + 1) Then
                        'i.e. history is required for this column.
                        'So, stop this verification process and copy data into
                        'its respective history table
                        iHistRequiredColsCount = 1
                        BlnHistStatus = True
                        '       Exit For
                    End If
                End If
                'Next

                If iHistRequiredColsCount = 0 Then
                    'All the given columns found in "Hist not required columns
                    ' list". So skip this "insert into Hist" process.

                    rowsAffectedCnt = -1
                    recordInHist = True
                    drHistCol.Close()
                    drHistCol = Nothing
                    '  cmd = Nothing
                    Exit Function
                End If
                drHistCol.Close()
                drHistCol = Nothing
            End If 'end of hist not required columns verification process

            'Step3:  Now insert data into its respective history table
            sQuery = "Insert into " & Trim(StrTabName) & Trim(strHistExt) & _
                " select * from " & StrTabName
            If Trim(WhereCondition) <> "" Then
                sQuery = sQuery & " Where " & StrCondition
            End If
            cmd = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
            cmd.Transaction = objTransaction
            rowsAffectedCnt = cmd.ExecuteNonQuery()
            recordInHist = True
            cmd.Dispose()
            cmd = Nothing

        Catch ex As Exception

            recordInHist = False
            strComponent = "DatabaseConnection.updateHistTable / recordInHist"

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Inserting the data into History Table " & _
                           errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") _
                    + 1))
                End If
            Else
                errNum = "UpdateHist"
                errDesc = ex.Message
                clntDesc = "Error ! While Inserting the data Into History Table  " & _
                           errDesc
            End If

            Dim objError As New ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
             clntDesc, returnMsg, strComponent, BranchCode, UserCode, MachineID)
            If Trim(returnMsg).Length > 0 Then
                returnMsg = Replace(returnMsg, Chr(10), " ")
                returnMsg = Replace(returnMsg, Chr(13), " ")
            Else
                clntDesc = Replace(clntDesc, Chr(10), " ")
                clntDesc = Replace(clntDesc, Chr(13), " ")
                returnMsg = clntDesc
            End If
        End Try
    End Function
End Class
