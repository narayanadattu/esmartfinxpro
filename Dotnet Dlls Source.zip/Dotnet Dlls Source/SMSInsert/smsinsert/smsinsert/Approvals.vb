Imports System.Data.OracleClient
Imports System.IO
Imports System.Net
Imports System.Web
Imports System.Xml
Imports System.Configuration
Public Class Approvals
    'Dim strRefnum As String
    'Dim strMtype As String  '' M type
    'Dim strDR As String '' Delivery Report

    'Dim strPostResponse As String
    'Dim dtsubmitstrtdt As String  '' submit start date
    'Dim dtsubmitenddt As String '' submit end date
    'Dim strGetSubmitStatusDesc As String
    'Dim errmsg As String
    'Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    'Dim objconn As New OracleClient.OracleConnection
    'Dim gconnectionstring As String
    'Dim strSql As String        '' Stores SQL statement
    'Dim strsqluns As String     '' Stores SQL stattement of unsent messages
    'Dim strMobileno As String   '' stores mobile number 
    'Dim strmessage As String    '' stores message
    'Dim strseqno As Integer     '' 
    'Dim struserid As String     '' stores user id 
    'Dim strpwd As String        '' stores password
    'Dim strtranuserid As String '' stores transactional userid
    'Dim strtranpwd As String    '' stores transactional password
    'Dim strpromuserid As String '' stores promotional user id
    'Dim strprompwd As String    '' stores promotional password
    'Dim strsmsid As Long        '' stores sms id
    ''    Dim arrvalssms() As Object
    ''Dim arrvalsrscd() As Object
    'Dim strbrcd As String       '' stores branch code
    'Dim strCurCode As String    '' stores cur code
    'Dim strModId As String      '' stores modid 
    'Dim strGlcode As String     '' stores Glcode
    'Dim strAccno As String      '' stores Accno
    'Dim strSMSYN As String      '' SMS YN
    'Dim strmachid As String     '' stores machine id
    'Dim strpuserid As String    '' stores user id for error log
    'Dim objError As New DatabaseConnection.ErrorDescription '' stores Error object
    'Dim errNum As String        '' stores error number for error log
    'Dim errDesc As String       '' stores error description for error log
    'Dim clntDesc As String      '' stores client description for error log
    'Dim strComponent As String  '' stores component for error log
    ''Dim objerr1 As TrapErrorDotNet.ErrorDescription
    'Dim strsqluidpwd As String    '' stores select statement to get transactional userid, password, promotional userid, password, retrycnt
    'Dim strsmssenderid As String
    'Dim strsmstype As String        '' stores sms type
    'Dim strfeaturecode As String    '' feature cide 
    'Dim strretry As String          '' SMS retry
    'Dim retrycnt As Integer = 0       '' SMS retry count
    'Dim retrycnt1 As Integer = 0       '' SMS retry count
    'Dim cmdsms As New OracleClient.OracleCommand    ''stores command object to retrieve all unsent SMS
    'Dim drsms As OracleClient.OracleDataReader      ''stores datareader object to retrieve all unsent SMS 

    'Dim cmdsmsyn As New OracleClient.OracleCommand    ''stores command object to get smsyn
    'Dim drsmsyn As OracleClient.OracleDataReader      ''stores datareader object to GET smsyn

    'Dim cmdsmsupd As New OracleClient.OracleCommand ''stores command object to update the resoncode,reason description, donate date
    'Dim sqlstrupd As String                 ''stores update statement
    'Dim strrespfrmserv As String            ''stores boolean value response from server
    'Dim strgetstatusxml As String           '' stores boolean value  to get status from xml

    'Dim datesta As Date                     ''stores submit date
    'Dim datenow As Date                     ''stroes current date
    'Dim cmdsmssta As New OracleClient.OracleCommand  ''stores command object for status code
    'Dim drsmssta As OracleClient.OracleDataReader   ''stores datareader object for status code
    'Dim strsqlsta As String                         '' stores select statement for status
    'Dim strguidsta As String                        '' stores guid to get status

    'Dim cmdsmsgen As New OracleClient.OracleCommand '' stores command object for different feature codes
    'Dim drsmsgen As OracleClient.OracleDataReader   ''stores datareader for different feature codes
    'Dim strsqlgen As String                         '' stores select statement for different feature codes

    'Dim cmdsmsgenins As New OracleClient.OracleCommand  ''
    'Dim sqlstrgenins As String                          ''

    'Dim cmdflush As New OracleClient.OracleCommand
    'Dim intflush As Integer

    'Dim cmdsmscust As New OracleClient.OracleCommand
    'Dim drsmscust As OracleClient.OracleDataReader
    'Dim strsqlcust As String
    'Dim strtrantypeg As String
    'Dim cmdsmsclbal As New OracleClient.OracleCommand
    'Dim drsmsclbal As OracleClient.OracleDataReader
    'Dim strsqlclbal As String

    'Dim strcustmobile As String
    'Dim strname As String
    'Dim strclosebal As String

    'Dim cmdsmsfeat As New OracleClient.OracleCommand
    'Dim drsmsfeat As OracleClient.OracleDataReader
    'Dim strsqlfeat As String
    'Dim strcustmessage As String
    'Dim strmsgtags As String

    'Dim strsmstypeg As String
    'Dim strmode1 As String
    'Dim intdays As Integer
    'Dim strschtype As String
    'Dim dtschdate As Date
    'Dim dblminamt As Double
    'Dim strhodayend As String

    'Dim strbuldmsg As String
    'Dim cmdsmsuidpwd As New OracleClient.OracleCommand
    'Dim drsmsuidpwd As OracleClient.OracleDataReader
    'Dim strarrmsgtags(10) As String
    'Dim strarrcustmobno(25) As String
    'Dim intfeatcd As Integer
    'Dim dtnextpusdt As Date
    'Dim dtappldate As Date
    'Dim dtmaxappldate As Date

    'Dim strsqlgrpmb As String
    'Dim cmdgrpmb As New OracleClient.OracleCommand
    'Dim drgrpmb As OracleClient.OracleDataReader

    'Dim strsqlbrcd As String
    'Dim cmdbrcd As New OracleClient.OracleCommand
    'Dim drbrcd As OracleClient.OracleDataReader

    'Dim strsqlglcd As String
    'Dim cmdglcd As New OracleClient.OracleCommand
    'Dim drglcd As OracleClient.OracleDataReader

    'Dim sqlstrsess As String
    'Dim cmdsess As New OracleClient.OracleCommand
    'Dim strchequeno As String
    'Dim strcntmsg As String
    'Dim strSqlSMSTyHist As String ''Stores sql statement to push data from SMSTYPEMST to history table
    'Dim strsqlupdsmstype As String

    'Dim cmdsmsupdsmstype As New OracleClient.OracleCommand
    'Dim dtschdatecur As Date

    'Dim cmdmaxappldate As New OracleClient.OracleCommand
    'Dim drmaxappldate As OracleClient.OracleDataReader

    'Dim cmdapplicationdate As New OracleClient.OracleCommand
    'Dim drapplicationdate As OracleClient.OracleDataReader
    'Dim strsqlapplicationdate As String

    'Dim cmdhodayenddate As New OracleClient.OracleCommand
    'Dim drahodayenddate As OracleClient.OracleDataReader
    'Dim strsqlhodayenddate As String
    'Dim dtHoDayEnddate As Date
    'Dim h24 As Integer ' to get hour in 24 hour format
    'Dim cmdappldate As New OracleClient.OracleCommand
    'Dim drappldate As OracleClient.OracleDataReader
    'Dim strmodaccno As String
    ''for ip address
    'Dim strHostName As String = Dns.GetHostName
    'Dim intSMSCnt As Integer ''Stores Number of SMS sent in 1 second
    'Dim intThrotleCnt As Integer '' Stores count of number of SMS to be sent in 1 Sec
    'Dim tsTicks As New TimeSpan(DateTime.UtcNow.Ticks) ''Stores ticks
    'Dim dttmflush As Date
    'Dim strIPAddress As String = Dns.GetHostByName(strHostName).AddressList(0).ToString()
    'Dim intcreditlimit As Int64
    'Dim intcreditsused As Int64
    'Dim dtcrdlm As Date = Date.Now
    'Dim strupdsentyn As String
    'Dim strnfts As String '' for accno 16 digits
    'Dim preerror As String = "Y"
    'Dim intdelaymin As Integer ''when the application is stopped and started again then from when the SMS has to be sent
    'Dim dtdelaymin As Date ''when the application is stopped and started again then from when the SMS has to be sent
    'Dim dtsmsnotgomin As Date '' for how long the SMS are not going 
    'Dim intsmsnotgomin As Integer '' for how long the SMS are not going 

    'Dim strIMPSOtRevRemarks As String '' IMPS OtRevRemsrks
    'Dim strIMPSLocation As String    '' IMPS Location
    'Dim strATMRemLocRefno As String     '' ATM Ref No

    'Dim objTransaction As OracleClient.OracleTransaction
    ''' sentyn = 'N'   --- by default when the record is inserted in smstranday table
    ''' sentyn = 'P'   ---- when you push the SMS
    ''' sentyn = 'S'   ---- when we submit the SMS 
    ''' sentyn = 'C'   ---- when we get the delivered message

    'Dim strSMSBankName As String '' SMS Bank Name
    'Dim strModuleid61, strglcode61, straccno61 As String
    Public Sub TransactionApprovals(ByVal intbatchno As Long, ByRef perrDesc As String)
        Try

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If
            '' cash deposit  --- 1
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 1
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate,'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,1,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 2  and (chqfvg not in('ICCR','IC','ATM') or chqfvg is null) and abs(amount) >=" & dblminamt  'and serviceid = 1 "
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))

                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()


            '' cash payment ---- 2
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""

            intfeatcd = 2
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno,  applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,2,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " (modeoftran = 1 and CASHPAIDYN = 'Y')  and (chqfvg not in('ICCR','IC','ATM','POS','ECOM') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                     drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                     Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' inward Debit clearing --- 3
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 3
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then



                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,3,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 5  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)
                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                     drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                     Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If

            SetGenFreeResr()

            '' outward Credit clearing -- 4
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 4
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then


                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,4,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 6  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' Debit Transfer -- 7 
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 7
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount,chqno, " & _
                "  applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,7,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 3 and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)



                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            strchequeno = ""
                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            If UBound(strarrmsgtags) = 4 Then


                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                            drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If
                            ElseIf UBound(strarrmsgtags) = 3 Then
                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                            drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If
                            Else
                                strbuldmsg = ""
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' Credit Transfer  --- 8
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 8
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,8,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and (moduleid in ('SB','CA','LOAN','CC') or (moduleid = 'DEP' and glcode in (select glcode from deptypemst where INSTSYN = 'Y' )))and transtatus = 'A' and  " & _
                " modeoftran = 4  and (chqfvg not in('ICCR','IC') or chqfvg is null) and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            strclosebal = ""
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()




            '' outward return --- 6
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 6
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,linkmoduleid,linkglcode, linkaccno, batchno, tranno, modeoftran,abs(amount) amount, " & _
    " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,6,applicationdate) not in " & _
    " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate  from " & _
    " smstranday) and moduleid in ('SB','CA','CC') and transtatus = 'A' and modeoftran =  6 and serviceid = 8  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!linkaccno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!linkmoduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()


            '' inward return --- 5
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 5
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,linkmoduleid,linkglcode, linkaccno, batchno, tranno, modeoftran,abs(amount) amount, " & _
    " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where batchno = " & intbatchno & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,5,applicationdate) not in " & _
    " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate  from " & _
    " smstranday) and moduleid in ('SB','CA','CC') and transtatus = 'A' and modeoftran =  5 and serviceid = 8  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!linkaccno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!linkmoduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()


        Catch ex As Exception
            perrDesc = ex.Message
        End Try
    End Sub

    Public Sub ChequeBookIssue(ByVal strcondition As String, ByRef perrordesc As String)
        Try

       
        '' Cheque Book Issue -- 9 
        sqlstrgenins = ""
        strsqlgen = ""
        strbuldmsg = ""
        intfeatcd = 9
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then

                Exit Sub
            End If
        End If
        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then
            strsqlgen = "SELECT branchcode,CURRENCYCODE,moduleid,glcode,accno,chequeno,tochequeno, applicationdate, 'SYSTEM' USERID FROM " & _
        " GENCHEQUEDTLS C WHERE APPLICATIONDATE=getappldate(branchcode) AND " & strcondition & " AND (branchcode,moduleid,glcode,accno,9,applicationdate) " & _
        " NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY)"
            cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
            drsmsgen = cmdsmsgen.ExecuteReader()

            While drsmsgen.Read()
                strcustmobile = "" : strSMSYN = ""
                GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                'checking for customer mobile no
                If strcustmobile = "" Then
                Else
                    If strSMSYN = "Y" Then
                        strarrmsgtags = strmsgtags.Split(",")
                        ' strarrmsgtags(0) --- <accno>
                        ' strarrmsgtags(1) --- <fromchequeno>
                        ' strarrmsgtags(2) --- <tochequeno>
                        ' strarrmsgtags(3) --- <date>
                        GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                        strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                         drsmsgen!chequeno.ToString()).Replace(strarrmsgtags(2), _
                         drsmsgen!tochequeno.ToString()).Replace(strarrmsgtags(3), _
                                                    Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                        If strSMSBankName <> "" Then
                            strbuldmsg = strbuldmsg & " " & strSMSBankName
                        Else
                            strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                        End If
                        InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                    End If
                End If
            End While
        End If
        SetGenFreeResr()
        Catch ex As Exception
            perrordesc = ex.Message
        End Try
    End Sub



    Public Sub ChequeStopPayment(ByVal strcondition As String, ByRef perrordesc As String)
        '' Stop Payment -- 10
        Try

      
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then

                Exit Sub
            End If
        End If

        intfeatcd = 10

        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "SELECT branchcode,CURRENCYCODE,moduleid,glcode,accno, " & _
                " 'SYSTEM' STOPUSERID,stopdate,fromchqno FROM GENSTOPPAYMST C WHERE " & _
                " STOPDATE=GETAPPLDATE(C.BRANCHCODE) and status ='A' AND " & strcondition & "  AND (branchcode,moduleid,glcode,accno,GETAPPLDATE(C.BRANCHCODE),10) " & _
                " NOT IN (SELECT branchcode,moduleid,glcode,accno,applicationdate,NVL(FEATURECODE,0) FROM SMSTRANDAY)"
            cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
            drsmsgen = cmdsmsgen.ExecuteReader()

            While drsmsgen.Read()
                strcustmobile = "" : strSMSYN = ""
                GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                'checking for customer mobile no
                If strcustmobile = "" Then
                Else
                    If strSMSYN = "Y" Then
                        '     GetApplDate(drsmsgen!branchcode.ToString, dtappldate)


                        strarrmsgtags = strmsgtags.Split(",")
                        ' strarrmsgtags(0) --- <accno>
                        ' strarrmsgtags(1) --- <CHEQUENO>
                        ' strarrmsgtags(2) --- <stopdate>

                        GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                        strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                         drsmsgen!fromchqno.ToString()).Replace(strarrmsgtags(2), _
                                                    Format(CDate(drsmsgen!stopdate.ToString()), "dd-MMM-yyyy"))
                        If strSMSBankName <> "" Then
                            strbuldmsg = strbuldmsg & " " & strSMSBankName
                        Else
                            strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                        End If
                        InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!stopdate.ToString, drsmsgen!stopUSERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                    End If
                End If
            End While
        End If
        SetGenFreeResr()
        Catch ex As Exception
            perrordesc = ex.Message
        End Try
    End Sub

    Public Sub LoanDisbursement(ByRef perrordesc As String)
        Try
            intfeatcd = 13
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,'LOAN',moduleid,glcode,accno,DISBURSEDDATE,DISBURSEMENTAMOUNT, applicationdate, " & _
                "'SYSTEM' USERID FROM LOANDISBURSEMENTDTLS WHERE " & _
                " DISBURSEDDATE= GETAPPLDATE(branchcode) AND (branchcode,'LOAN',glcode,accno,13,applicationdate) NOT IN " & _
    " (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY)"
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <disbdate>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), strmodaccno).Replace(strarrmsgtags(1), _
                             drsmsgen!DISBURSEMENTAMOUNT.ToString()).Replace(strarrmsgtags(2), _
                                                        Format(CDate(drsmsgen!DISBURSEDDATE.ToString()), "dd-MMM-yyyy"))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If

                            InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()
        Catch ex As Exception
            perrordesc = ex.Message
        End Try
    End Sub
    Public Sub InterestingPosting()
        '' Interest Posting  --- 40
        sqlstrgenins = ""
        strsqlgen = ""
        strbuldmsg = ""
        intfeatcd = 40
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then

                Exit Sub
            End If
        End If
        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

            strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
            "  applicationdate, 'SYSTEM' USERID from gentranslog g where " & _
            " (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,8,applicationdate) not in " & _
            " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
            " smstranday) and (moduleid in ('SB','CA','LOAN','CC')) and transtatus = 'A' and  " & _
            " modeoftran = 4 and (chqfvg in('ICCR','IC') or chqfvg is null) and abs(amount) >= " & dblminamt

            cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
            drsmsgen = cmdsmsgen.ExecuteReader()

            While drsmsgen.Read()
                strcustmobile = "" : strSMSYN = ""
                GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                'checking for customer mobile no
                If strcustmobile = "" Then
                Else
                    If strSMSYN = "Y" Then
                        GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                        strarrmsgtags = strmsgtags.Split(",")
                        ' strarrmsgtags(0) --- <accno>
                        ' strarrmsgtags(1) --- <amount>
                        ' strarrmsgtags(2) --- <date>
                        ' strarrmsgtags(3) --- <balance>
                        GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                        strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                    drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                    Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                        If strSMSBankName <> "" Then
                            strbuldmsg = strbuldmsg & " " & strSMSBankName
                        Else
                            strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                        End If
                        InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                    End If
                End If
            End While
        End If
        SetGenFreeResr()
    End Sub

    Public Sub AccountOpening(ByVal pmodid As String, ByVal strtable As String, ByVal strcondition As String, ByRef perrordesc As String)
        '' A/c Opening -- 16
        sqlstrgenins = ""
        strsqlgen = ""
        strbuldmsg = ""
        intfeatcd = 16
        Try
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If

            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then


                '     strsqlgen = "SELECT branchcode,currencycode,'SB' moduleid,glcode,accno, applicationdate, 'SYSTEM' USERID,GetBranchName(branchcode) branchname   FROM SBMST WHERE STATUS='R' and transtatus = 'A'  AND  OPDATE=GETAPPLDATE(branchcode) AND (branchcode,'SB',glcode,accno,16,applicationdate) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
                '" SELECT branchcode,currencycode,'CA' moduleid,glcode,accno, applicationdate, 'SYSTEM' USERID,GetBranchName(branchcode) branchname  FROM CAMST WHERE STATUS='R' and transtatus = 'A'  AND OPDATE=GETAPPLDATE(branchcode) AND (branchcode,'CA',glcode,accno,16,applicationdate) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
                '           " UNION " & _
                '           " SELECT branchcode,currencycode,'CC' moduleid,glcode,accno, applicationdate, 'SYSTEM' USERID,  GetBranchName(branchcode) branchname FROM CCMST WHERE STATUS='R' and transtatus = 'A'  AND OPDATE=GETAPPLDATE(branchcode) AND (branchcode,'CC',glcode,accno,16,applicationdate) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
                '           " UNION " & _
                '          " SELECT branchcode,currencycode,'LOCKER' moduleid,glcode,accno, applicationdate, 'SYSTEM' USERID, GetBranchName(branchcode) branchname  FROM LOCKERMST WHERE STATUS='R' and transtatus = 'A'  AND OPDATE=GETAPPLDATE(branchcode) AND (branchcode,'LOCKER',glcode,accno,16,applicationdate) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY)"

                If pmodid = "SB" Or pmodid = "CA" Or pmodid = "CC" Or pmodid = "LOCKER" Then
                    strsqlgen = "SELECT branchcode,currencycode,'" & pmodid & "' moduleid,glcode,accno, applicationdate, 'SYSTEM' USERID,GetBranchName(branchcode) branchname   FROM " & strtable & " WHERE STATUS='R' and " & strcondition & " AND  OPDATE=GETAPPLDATE(branchcode) AND (branchcode,'" & pmodid & "',glcode,accno,16,applicationdate) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) "

                    cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                    drsmsgen = cmdsmsgen.ExecuteReader()

                    While drsmsgen.Read()
                        strcustmobile = "" : strSMSYN = ""
                        GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                        'checking for customer mobile no
                        If strcustmobile = "" Then
                        Else
                            If strSMSYN = "Y" Then
                                strarrmsgtags = strmsgtags.Split(",")
                                ' strarrmsgtags(0) --- <accno>
                                ' strarrmsgtags(1) --- <bankname>
                                ' strarrmsgtags(2) --- <date>

                                GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                 drsmsgen!branchname.ToString()).Replace(strarrmsgtags(2), _
                                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If

                                InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                            End If
                        End If
                    End While
                End If
            End If
            SetGenFreeResr()

            ''AccountClosure

            AccountClosure(pmodid, strtable, strcondition, perrordesc)
        Catch ex As Exception
            perrordesc = ex.Message
        End Try
    End Sub

    Public Sub AccountClosure(ByVal pmodid As String, ByVal strtable As String, ByVal strcondition As String, ByRef perrordesc As String)
        '' A/c Closure -- 17
        sqlstrgenins = ""
        strsqlgen = ""
        strbuldmsg = ""
        intfeatcd = 17
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then

                Exit Sub
            End If
        End If
        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

           

            ' strsqlgen = "SELECT branchcode,currencycode,'SB' moduleid,glcode,accno, GETAPPLDATE(branchcode)  applicationdate, 'SYSTEM' USERID  FROM SBMST WHERE STATUS='C' and transtatus = 'A' AND  CLOSEDATE=GETAPPLDATE(branchcode) AND (branchcode,'SB',glcode,accno,17,GETAPPLDATE(branchcode)) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
            '   " UNION " & _
            '   " SELECT branchcode,currencycode,'CA' moduleid,glcode,accno,GETAPPLDATE(branchcode) applicationdate, 'SYSTEM' USERID FROM CAMST WHERE STATUS='C' and transtatus = 'A' AND CLOSEDATE=GETAPPLDATE(branchcode) AND (branchcode,'CA',glcode,accno,17,GETAPPLDATE(branchcode)) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
            '   " UNION " & _
            '    " SELECT branchcode,currencycode,'CC' moduleid,glcode,accno,GETAPPLDATE(branchcode) applicationdate, 'SYSTEM' USERID FROM CCMST WHERE STATUS='C' and transtatus = 'A' AND CLOSEDATE=GETAPPLDATE(branchcode) AND (branchcode,'CC',glcode,accno,17,GETAPPLDATE(branchcode)) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) " & _
            '  " UNION " & _
            '   " SELECT branchcode,currencycode,'LOCKER' moduleid,glcode,accno,GETAPPLDATE(branchcode) applicationdate, 'SYSTEM' USERID FROM LOCKERMST WHERE STATUS='C' and transtatus = 'A' AND CLOSEDATE=GETAPPLDATE(branchcode) AND (branchcode,'LOCKER',glcode,accno,17,GETAPPLDATE(branchcode)) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY)"

            If pmodid = "SB" Or pmodid = "CA" Or pmodid = "CC" Or pmodid = "LOCKER" Then
                strsqlgen = "SELECT branchcode,currencycode,'" & pmodid & "' moduleid,glcode,accno, GETAPPLDATE(branchcode)  applicationdate, 'SYSTEM' USERID   FROM " & strtable & " WHERE STATUS='C' and transtatus = 'A' and " & strcondition & " AND  CLOSEDATE=GETAPPLDATE(branchcode) AND (branchcode,'" & pmodid & "',glcode,accno,17,GETAPPLDATE(branchcode)) NOT IN (SELECT branchcode,moduleid,glcode,accno,NVL(FEATURECODE,0),applicationdate FROM SMSTRANDAY) "

                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <date>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If


                            InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
        End If
        SetGenFreeResr()

    End Sub

    Public Sub NPA_Accs()
        ''  NPA A/Cs -- 51
        sqlstrgenins = ""
        strsqlgen = ""
        strbuldmsg = ""
        intfeatcd = 51
        If objconn.State <> ConnectionState.Open Then
            errmsg = ""
            objconn = ObjDbCOnnection.GetDbConnection(errmsg)
            If errmsg <> "" Then

                Exit Sub
            End If
        End If
        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

            strsqlgen = "SELECT BRANCHCODE, CURRENCYCODE, 'LOAN' MODULEID, GLCODE, ACCNO, NPAEFFDATE,APPLICATIONDATE,'SYSTEM' USERID  FROM NPALOANDTLS A WHERE npastatus = 'NPA' AND NVL(OLDNPASTATUS,'PA') = 'PA' AND APPLICATIONDATE = (SELECT APPLICATIONDATE FROM GENAPPLICATIONDATEMST WHERE branchcode = a.branchcode) AND  (branchcode,currencycode,glcode,accno,51,applicationdate) NOT IN (SELECT branchcode,currencycode,glcode,accno,NVL(featurecode,0),applicationdate FROM  smstranday)"
            cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
            drsmsgen = cmdsmsgen.ExecuteReader()

            While drsmsgen.Read()
                strcustmobile = "" : strSMSYN = ""
                GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!MODULEID.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                'checking for customer mobile no
                If strcustmobile = "" Then
                Else
                    If strSMSYN = "Y" Then
                        strarrmsgtags = strmsgtags.Split(",")
                        ' strarrmsgtags(0) --- <accno>
                        ' strarrmsgtags(1) --- <date>

                        GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                        strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), strmodaccno).Replace(strarrmsgtags(1), _
                                    Format(CDate(drsmsgen!NPAEFFDATE.ToString()), "dd-MMM-yyyy"))
                        If strSMSBankName <> "" Then
                            strbuldmsg = strbuldmsg & " " & strSMSBankName
                        Else
                            strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                        End If
                        InsertIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                    End If
                End If
            End While
        End If
        'to release the resources
        SetGenFreeResr()
    End Sub

End Class
