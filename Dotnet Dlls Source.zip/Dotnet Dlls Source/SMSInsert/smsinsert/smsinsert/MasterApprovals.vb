Public Class MasterApprovals


    Public Sub MasterApprovals(ByVal pstrCondition As String, ByRef perrDesc As String)
        Try


            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If
            '' cash deposit  --- 1
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 1
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate,'SYSTEM' USERID from gentranslog g where " & pstrCondition & " and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,1,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 2  and (chqfvg not in('ICCR','IC','ATM') or chqfvg is null) and abs(amount) >=" & dblminamt  'and serviceid = 1 "
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))

                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()



            '' Credit Transfer  --- 8
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 8
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate, 'SYSTEM' USERID from gentranslog g where " & pstrCondition & "  and (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,8,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and (moduleid in ('SB','CA','LOAN','CC') or (moduleid = 'DEP' and glcode in (select glcode from deptypemst where INSTSYN = 'Y' )))and transtatus = 'A' and  " & _
                " modeoftran = 4  and (chqfvg not in('ICCR','IC') or chqfvg is null) and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            strclosebal = ""
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()


        Catch ex As Exception

        End Try
    End Sub
End Class
