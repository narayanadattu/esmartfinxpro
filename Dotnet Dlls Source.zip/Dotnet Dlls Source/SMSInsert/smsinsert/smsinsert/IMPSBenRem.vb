Public Class IMPSBenRem
    Public Sub GetIMPSBenRem(ByVal strbatchno As String)
        Try
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If
            '' Beneficiary  --- 58
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 58
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "SELECT g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno, g.modeoftran,ABS(g.amount) amount,SUBSTR(g.remarks,0,20) remarks, " & _
                " g.applicationdate,'SYSTEM' USERID,h.PHONE,g.RATEREFCODE FROM gentranslog g,genbankbranchmst h WHERE  g.batchno = " & strbatchno & " and " & _
                " (g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno,g.MODEOFTRAN,58,g.applicationdate) NOT IN " & _
                " (SELECT a.branchcode,a.currencycode,a.moduleid,a.glcode,a.accno,a.batchno,a.tranno,a.MODEOFTRAN,NVL(a.featurecode,0),a.applicationdate FROM " & _
                " smstranday a) AND g.moduleid IN ('SB','CA','CC') AND g.transtatus = 'A' AND " & _
                " (g.modeoftran = 4 AND g.CASHPAIDYN = 'Y')  AND (g.chqfvg='IMPS')  AND  h.branchcode=g.branchcode AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'INWARD' and abs(g.amount) >= " & dblminamt  'and serviceid = 1 "

                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <IMPS Location>
                            ' strarrmsgtags(5) --- <reference no>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            '' IMPS location
                            strIMPSLocation = ""
                            If IsDBNull(drsmsgen!RATEREFCODE) = False Then
                                strIMPSLocation = GetIMPSLocation(drsmsgen!RATEREFCODE.ToString(), "impslogdtls")
                            End If


                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strIMPSLocation).Replace(strarrmsgtags(5), IIf(IsDBNull(drsmsgen!RATEREFCODE), "", drsmsgen!RATEREFCODE.ToString()))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()



            '' Remitter  --- 59
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 59
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "SELECT g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno, g.modeoftran,ABS(g.amount) amount,SUBSTR(g.remarks,0,20) remarks, " & _
                " g.applicationdate,'SYSTEM' USERID,h.PHONE,g.RATEREFCODE,g.name FROM gentranslog g,genbankbranchmst h WHERE  g.batchno = " & strbatchno & " and " & _
                " (g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno,g.MODEOFTRAN,59,g.applicationdate) NOT IN " & _
                " (SELECT a.branchcode,a.currencycode,a.moduleid,a.glcode,a.accno,a.batchno,a.tranno,a.MODEOFTRAN,NVL(a.featurecode,0),a.applicationdate FROM " & _
                " smstranday a) AND g.moduleid IN ('SB','CA','CC') AND g.transtatus = 'A' AND " & _
                " (g.modeoftran = 3)  AND (g.chqfvg='IMPS')  AND  h.branchcode=g.branchcode  AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'OUTWRD' and abs(g.amount) >= " & dblminamt  'and serviceid = 1 "

                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            'GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <Name>
                            ' strarrmsgtags(4) --- <IMPS Location>
                            ' strarrmsgtags(4) --- <Refernec no>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            '' IMPS location
                            strIMPSLocation = ""
                            If IsDBNull(drsmsgen!RATEREFCODE) = False Then
                                strIMPSLocation = GetIMPSLocation(drsmsgen!RATEREFCODE.ToString(), "impslogdtls")
                            End If
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), drsmsgen!name).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strIMPSLocation).Replace(strarrmsgtags(5), IIf(IsDBNull(drsmsgen!RATEREFCODE), "", drsmsgen!RATEREFCODE.ToString()))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()



            '' Remitter  reversal --- 60
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 60
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "SELECT g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno, g.modeoftran,ABS(g.amount) amount,SUBSTR(g.remarks,0,20) remarks, " & _
                " g.applicationdate,'SYSTEM' USERID,h.PHONE,g.RATEREFCODE FROM gentranslog g,genbankbranchmst h WHERE g.batchno = " & strbatchno & " and " & _
                " (g.branchcode,g.currencycode,g.moduleid,g.glcode, g.accno, g.batchno, g.tranno,g.MODEOFTRAN,60,g.applicationdate) NOT IN " & _
                " (SELECT a.branchcode,a.currencycode,a.moduleid,a.glcode,a.accno,a.batchno,a.tranno,a.MODEOFTRAN,NVL(a.featurecode,0),a.applicationdate FROM " & _
                " smstranday a) AND g.moduleid IN ('SB','CA','CC') AND g.transtatus = 'A' AND " & _
                " (g.modeoftran = 4 )  AND (g.chqfvg='IMPS')  AND   h.branchcode=g.branchcode AND SUBSTR(RESPONDINGBANKCODE,1,6) = 'OUTWRR' and abs(g.amount) >= " & dblminamt  'and serviceid = 1 "

                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <remarks>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <IMPSLocation>
                            ' strarrmsgtags(5) --- <Reference No>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            '' get remarks
                            strIMPSOtRevRemarks = ""
                            If IsDBNull(drsmsgen!RATEREFCODE) = False Then
                                strIMPSOtRevRemarks = GetIMPSOutRevRemarks(drsmsgen!RATEREFCODE.ToString())
                            End If
                            '' IMPS location
                            strIMPSLocation = ""
                            If IsDBNull(drsmsgen!RATEREFCODE) = False Then
                                strIMPSLocation = GetIMPSLocation(drsmsgen!RATEREFCODE.ToString(), "impslogdtls")
                            End If
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), strIMPSOtRevRemarks).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strIMPSLocation).Replace(strarrmsgtags(5), IIf(IsDBNull(drsmsgen!RATEREFCODE), "", drsmsgen!RATEREFCODE.ToString()))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()
        Catch ex As Exception

        End Try
    End Sub



    Public Sub GetBranchchannelIMPSDebit(ByVal strRefno As String)
        '' Debit branch channel -- 7 
        Dim strerrorimps As String
        Try
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If

            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 7
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "SELECT REFNO37,BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, (TRNSAMOUNT4/100)  amount , SUBSTR(remarks,0,20) remarks,APPLICATIONDATE, 'SYSTEM' USERID FROM impsbrchanfundstrnsdtls WHERE serviceid = 'OUTWRD' AND REFNO37 = '" & strRefno & "' and debitstatus = 'Y' and  TRANSTATUS='A' and (branchcode,currencycode,moduleid,glcode,accno,batchno,7,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,nvl(featurecode,0),applicationdate from " & _
                " smstranday) And abs((TRNSAMOUNT4 / 100)) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)



                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>




                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            If UBound(strarrmsgtags) = 3 Then
                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                            drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If
                            Else
                                strbuldmsg = ""
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, "0", drsmsgen!batchno.ToString, "0", strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()
        Catch ex As Exception
            strerrorimps = ex.Message
        End Try
    End Sub
End Class

