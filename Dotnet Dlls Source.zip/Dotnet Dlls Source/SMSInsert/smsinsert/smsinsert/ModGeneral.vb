Imports System.Data.OracleClient
Imports System.IO
Imports System.Net
Imports System.Web
Imports System.Xml
Imports System.Configuration
Module ModGeneral
    Public strRefnum As String
    Public strMtype As String  '' M type
    Public strDR As String '' Delivery Report

    Public strPostResponse As String
    Public dtsubmitstrtdt As String  '' submit start date
    Public dtsubmitenddt As String '' submit end date
    Public strGetSubmitStatusDesc As String
    Public errmsg As String
    Public ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Public objconn As New OracleClient.OracleConnection
    Public gconnectionstring As String
    Public strSql As String        '' Stores SQL statement
    Public strsqluns As String     '' Stores SQL stattement of unsent messages
    Public strMobileno As String   '' stores mobile number 
    Public strmessage As String    '' stores message
    Public strseqno As Integer     '' 
    Public struserid As String     '' stores user id 
    Public strpwd As String        '' stores password
    Public strtranuserid As String '' stores transactional userid
    Public strtranpwd As String    '' stores transactional password
    Public strpromuserid As String '' stores promotional user id
    Public strprompwd As String    '' stores promotional password
    Public strsmsid As Long        '' stores sms id
    '    public arrvalssms() As Object
    'public arrvalsrscd() As Object
    Public strbrcd As String       '' stores branch code
    Public strCurCode As String    '' stores cur code
    Public strModId As String      '' stores modid 
    Public strGlcode As String     '' stores Glcode
    Public strAccno As String      '' stores Accno
    Public strSMSYN As String      '' SMS YN
    Public strmachid As String     '' stores machine id
    Public strpuserid As String    '' stores user id for error log
    Public objError As New DatabaseConnection.ErrorDescription '' stores Error object
    Public errNum As String        '' stores error number for error log
    Public errDesc As String       '' stores error description for error log
    Public clntDesc As String      '' stores client description for error log
    Public strComponent As String  '' stores component for error log
    'public objerr1 As TrapErrorDotNet.ErrorDescription
    Public strsqluidpwd As String    '' stores select statement to get transactional userid, password, promotional userid, password, retrycnt
    Public strsmssenderid As String
    Public strsmstype As String        '' stores sms type
    Public strfeaturecode As String    '' feature cide 
    Public strretry As String          '' SMS retry
    Public retrycnt As Integer = 0       '' SMS retry count
    Public retrycnt1 As Integer = 0       '' SMS retry count
    Public cmdsms As New OracleClient.OracleCommand    ''stores command object to retrieve all unsent SMS
    Public drsms As OracleClient.OracleDataReader      ''stores datareader object to retrieve all unsent SMS 

    Public cmdsmsyn As New OracleClient.OracleCommand    ''stores command object to get smsyn
    Public drsmsyn As OracleClient.OracleDataReader      ''stores datareader object to GET smsyn

    Public cmdsmsupd As New OracleClient.OracleCommand ''stores command object to update the resoncode,reason description, donate date
    Public sqlstrupd As String                 ''stores update statement
    Public strrespfrmserv As String            ''stores boolean value response from server
    Public strgetstatusxml As String           '' stores boolean value  to get status from xml

    Public datesta As Date                     ''stores submit date
    Public datenow As Date                     ''stroes current date
    Public cmdsmssta As New OracleClient.OracleCommand  ''stores command object for status code
    Public drsmssta As OracleClient.OracleDataReader   ''stores datareader object for status code
    Public strsqlsta As String                         '' stores select statement for status
    Public strguidsta As String                        '' stores guid to get status

    Public cmdsmsgen As New OracleClient.OracleCommand '' stores command object for different feature codes
    Public drsmsgen As OracleClient.OracleDataReader   ''stores datareader for different feature codes
    Public strsqlgen As String                         '' stores select statement for different feature codes

    Public cmdsmsgenins As New OracleClient.OracleCommand  ''
    Public sqlstrgenins As String                          ''

    Public cmdflush As New OracleClient.OracleCommand
    Public intflush As Integer

    Public cmdsmscust As New OracleClient.OracleCommand
    Public drsmscust As OracleClient.OracleDataReader
    Public strsqlcust As String
    Public strtrantypeg As String
    Public cmdsmsclbal As New OracleClient.OracleCommand
    Public drsmsclbal As OracleClient.OracleDataReader
    Public strsqlclbal As String

    Public strcustmobile As String
    Public strname As String
    Public strclosebal As String

    Public cmdsmsfeat As New OracleClient.OracleCommand
    Public drsmsfeat As OracleClient.OracleDataReader
    Public strsqlfeat As String
    Public strcustmessage As String
    Public strmsgtags As String

    Public strsmstypeg As String
    Public strmode1 As String
    Public intdays As Integer
    Public strschtype As String
    Public dtschdate As Date
    Public dblminamt As Double
    Public strhodayend As String

    Public strbuldmsg As String
    Public cmdsmsuidpwd As New OracleClient.OracleCommand
    Public drsmsuidpwd As OracleClient.OracleDataReader
    Public strarrmsgtags(10) As String
    Public strarrcustmobno(25) As String
    Public intfeatcd As Integer
    Public dtnextpusdt As Date
    Public dtappldate As Date
    Public dtmaxappldate As Date

    Public strsqlgrpmb As String
    Public cmdgrpmb As New OracleClient.OracleCommand
    Public drgrpmb As OracleClient.OracleDataReader

    Public strsqlbrcd As String
    Public cmdbrcd As New OracleClient.OracleCommand
    Public drbrcd As OracleClient.OracleDataReader

    Public strsqlglcd As String
    Public cmdglcd As New OracleClient.OracleCommand
    Public drglcd As OracleClient.OracleDataReader

    Public sqlstrsess As String
    Public cmdsess As New OracleClient.OracleCommand
    Public strchequeno As String
    Public strcntmsg As String
    Public strSqlSMSTyHist As String ''Stores sql statement to push data from SMSTYPEMST to history table
    Public strsqlupdsmstype As String

    Public cmdsmsupdsmstype As New OracleClient.OracleCommand
    Public dtschdatecur As Date

    Public cmdmaxappldate As New OracleClient.OracleCommand
    Public drmaxappldate As OracleClient.OracleDataReader

    Public cmdapplicationdate As New OracleClient.OracleCommand
    Public drapplicationdate As OracleClient.OracleDataReader
    Public strsqlapplicationdate As String

    Public cmdhodayenddate As New OracleClient.OracleCommand
    Public drahodayenddate As OracleClient.OracleDataReader
    Public strsqlhodayenddate As String
    Public dtHoDayEnddate As Date
    Public h24 As Integer ' to get hour in 24 hour format
    Public cmdappldate As New OracleClient.OracleCommand
    Public drappldate As OracleClient.OracleDataReader
    Public strmodaccno As String
    'for ip address
    Public strHostName As String = Dns.GetHostName
    Public intSMSCnt As Integer ''Stores Number of SMS sent in 1 second
    Public intThrotleCnt As Integer '' Stores count of number of SMS to be sent in 1 Sec
    Public tsTicks As New TimeSpan(DateTime.UtcNow.Ticks) ''Stores ticks
    Public dttmflush As Date
    Public strIPAddress As String = Dns.GetHostByName(strHostName).AddressList(0).ToString()
    Public intcreditlimit As Int64
    Public intcreditsused As Int64
    Public dtcrdlm As Date = Date.Now
    Public strupdsentyn As String
    Public strnfts As String '' for accno 16 digits
    Public preerror As String = "Y"
    Public intdelaymin As Integer ''when the application is stopped and started again then from when the SMS has to be sent
    Public dtdelaymin As Date ''when the application is stopped and started again then from when the SMS has to be sent
    Public dtsmsnotgomin As Date '' for how long the SMS are not going 
    Public intsmsnotgomin As Integer '' for how long the SMS are not going 

    Public strIMPSOtRevRemarks As String '' IMPS OtRevRemsrks
    Public strIMPSLocation As String    '' IMPS Location
    Public strATMRemLocRefno As String     '' ATM Ref No

    Public objTransaction As OracleClient.OracleTransaction
    '' sentyn = 'N'   --- by default when the record is inserted in smstranday table
    '' sentyn = 'P'   ---- when you push the SMS
    '' sentyn = 'S'   ---- when we submit the SMS 
    '' sentyn = 'C'   ---- when we get the delivered message

    Public strSMSBankName As String '' SMS Bank Name
    Public strModuleid61, strglcode61, straccno61 As String



    ' get parameter details for feature
    Public Function GetParameterDetails(ByVal intfeatcd1 As Integer, ByRef strmsgtags As String, ByRef strcustmessage As String, ByRef strtrantypeg As String, ByRef strsmstypeg As String, ByRef strmode1 As String, ByRef intdays As Integer, ByRef strschtype As String, ByRef dtschdate As Date, Optional ByRef dblminamt As Double = 0) As Boolean
        Try
            strmsgtags = ""
            strcustmessage = ""
            strtrantypeg = ""
            strsmstypeg = ""
            strmode1 = ""
            intdays = 0
            strschtype = ""
            dblminamt = 0

            strsqlfeat = "select nvl(m.messagetags,'') MESSAGETAGS, nvl(s.CUSTOMERMESSAGE,'') CUSTOMERMESSAGE, s.TRANTYPE, s.SMSTYPE,s.mode1,s.days,s.schtype,nvl(s.nextpushdate,s.schday) schday,s.minamt from smstypemst s , smsfeaturemst m   where s.featurecode = m.featurecode and m.activeyn = 'Y' and s.featurecode =" & intfeatcd1

            cmdsmsfeat = New OracleClient.OracleCommand(strsqlfeat, objconn)
            drsmsfeat = cmdsmsfeat.ExecuteReader()
            If drsmsfeat.Read() Then
                strmsgtags = drsmsfeat!MESSAGETAGS.ToString
                strcustmessage = drsmsfeat!CUSTOMERMESSAGE.ToString
                strtrantypeg = drsmsfeat!TRANTYPE.ToString
                strsmstypeg = IIf(IsDBNull(drsmsfeat!SMSTYPE), "", drsmsfeat!SMSTYPE.ToString)
                strmode1 = IIf(IsDBNull(drsmsfeat!mode1), "", drsmsfeat!mode1.ToString)
                intdays = IIf(IsDBNull(drsmsfeat!days), 0, drsmsfeat!days.ToString)
                strschtype = IIf(IsDBNull(drsmsfeat!schtype), "", drsmsfeat!schtype.ToString)
                If IsDBNull(drsmsfeat!schday) Then
                Else
                    dtschdate = drsmsfeat!schday.ToString
                End If
                dblminamt = IIf(IsDBNull(drsmsfeat!minamt), 0, drsmsfeat!minamt.ToString)

                GetParameterDetails = True
                cmdsmsfeat.Dispose()
                cmdsmsfeat = Nothing
                drsmsfeat.Close()
                drsmsfeat = Nothing
                Exit Function
            Else
                GetParameterDetails = False
                Exit Function
            End If

            Exit Function
        Catch ex As Exception

            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing
        End Try
    End Function

    ' get mobile and name for customer
    Public Sub GetCustMobileName(ByVal strbrcd As String, ByVal strcurcd As String, ByVal strmodid As String, _
                                    ByVal strglcode As String, ByVal straccno As String, _
                                    ByRef strcustmobile As String, ByRef strSMSYN As String)
        Try
            strcustmobile = ""
            strSMSYN = ""
            strsqlcust = "select custmobile,name,smsyn from gencustinfomst where customerid = " & _
                " (select DISTINCT customerid from " & strmodid & "mst where " & _
                " accno = '" & straccno & "'  and glcode='" & strglcode & "'" & _
                " and branchcode='" & strbrcd & "'and currencycode = '" & strcurcd & "')"

            cmdsmscust = New OracleClient.OracleCommand(strsqlcust, objconn)
            drsmscust = cmdsmscust.ExecuteReader()
            If drsmscust.Read() Then
                strcustmobile = IIf(IsDBNull(drsmscust!custmobile), "", drsmscust!custmobile.ToString)
                strSMSYN = IIf(IsDBNull(drsmscust!smsyn), "", drsmscust!smsyn.ToString)
            End If
            cmdsmscust.Dispose()
            cmdsmscust = Nothing
            drsmscust.Close()
            drsmscust = Nothing

            Exit Sub
        Catch ex As Exception

            cmdsmscust.Dispose()
            cmdsmscust = Nothing
            drsmscust.Close()
            drsmscust = Nothing
        End Try
    End Sub
    Public Sub GetCloseBal(ByVal strbrcd As String, ByVal strcurcd As String, ByVal strmodid As String, _
                                 ByVal strglcode As String, ByVal straccno As String, ByRef strclosebal As String)
        Try

            strsqlclbal = "select sum(nvl(closebal,0)) closebal from (select curbal closebal from " & strmodid & "balance where " & _
                    " accno = '" & straccno & "'  and glcode='" & strglcode & "'" & _
                   " and branchcode='" & strbrcd & "'and currencycode = '" & strcurcd & "'" & _
                   " union all " & _
                   " select sum(nvl(amount,0)) closebal from " & strmodid & "tranday where " & _
                    " accno = '" & straccno & "'  and glcode='" & strglcode & "'" & _
                   " and branchcode='" & strbrcd & "'and currencycode = '" & strcurcd & "')"

            cmdsmsclbal = New OracleClient.OracleCommand(strsqlclbal, objconn)
            drsmsclbal = cmdsmsclbal.ExecuteReader()
            If drsmsclbal.Read() Then
                strclosebal = drsmsclbal!closebal.ToString
            End If
            cmdsmsclbal.Dispose()
            cmdsmsclbal = Nothing
            drsmsclbal.Close()
            drsmsclbal = Nothing

            Exit Sub
        Catch ex As Exception

            cmdsmsclbal.Dispose()
            cmdsmsclbal = Nothing
            drsmsclbal.Close()
            drsmsclbal = Nothing
        End Try
    End Sub
    Public Sub SetGenFreeResr()
        Try
            cmdsmsgen.Dispose()
            cmdsmsgen = Nothing
            drsmsgen.Close()
            drsmsgen = Nothing

            Exit Sub
        Catch ex As Exception

        End Try
    End Sub

    Public Sub GetAccountNo(ByVal straccno As String, ByRef strmodaccno As String)
        strmodaccno = straccno
        Try
            If strnfts = "N" Then
                If straccno.Trim.Length = 1 Then
                    strmodaccno = "XXXXX" & straccno
                ElseIf straccno.Trim.Length = 2 Then
                    strmodaccno = "XXXX" & straccno
                ElseIf straccno.Trim.Length = 3 Then
                    strmodaccno = "XXX" & straccno
                ElseIf straccno.Trim.Length = 4 Then
                    strmodaccno = "XXX" & Mid(straccno, 2, 3)
                ElseIf straccno.Trim.Length = 5 Then
                    strmodaccno = "XXX" & Mid(straccno, 3, 3)
                ElseIf straccno.Trim.Length = 6 Then
                    strmodaccno = "XXX" & Mid(straccno, 4, 3)
                ElseIf straccno.Trim.Length = 7 Then
                    strmodaccno = "XXX" & Mid(straccno, 5, 3)
                End If
            ElseIf strnfts = "Y" Then
                Dim straccno1 As String
                Dim straccnotrimst As String
                straccno1 = Mid(straccno, 10, 7)
                straccnotrimst = straccno1.TrimStart("0")
                If straccnotrimst.Trim.Length = 1 Then
                    strmodaccno = "XXXXXX" & straccnotrimst
                ElseIf straccnotrimst.Trim.Length = 2 Then
                    strmodaccno = "XXXXX" & straccnotrimst
                ElseIf straccnotrimst.Trim.Length = 3 Then
                    strmodaccno = "XXXX" & straccnotrimst
                ElseIf straccnotrimst.Trim.Length = 4 Then
                    strmodaccno = "XXXX" & Mid(straccnotrimst, 2, 3)
                ElseIf straccnotrimst.Trim.Length = 5 Then
                    strmodaccno = "XXXX" & Mid(straccnotrimst, 3, 3)
                ElseIf straccnotrimst.Trim.Length = 6 Then
                    strmodaccno = "XXXX" & Mid(straccnotrimst, 4, 3)
                ElseIf straccnotrimst.Trim.Length = 7 Then
                    strmodaccno = "XXXX" & Mid(straccnotrimst, 5, 3)
                End If
            End If


            Exit Sub
        Catch ex As Exception

            strmodaccno = straccno
        End Try
    End Sub

    '' to insert from gentranslog into smstranday 
    Public Sub InsertGentranlogIntoSMSTranday(ByVal strpbrcd As String, ByVal strpcurcd As String, ByVal strpmodid As String, ByVal strpglcd As String, ByVal strpaccno As String, ByVal strmodeoftran As String, ByVal intbatchno As Integer, ByVal inttranno As Integer, ByVal strpbuldmsg As String, ByVal strpcustmobile As String, ByVal strpappldate As String, ByVal strpuid As String, ByVal strpmacid As String, ByVal strpsmstypeg As String, ByVal intpfeatcd As Integer)
        Try

            sqlstrgenins = "insert into smstranday(SMSID, BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, " & _
            " ACCNO,MODEOFTRAN,BATCHNO, TRANNO, MESSAGE, MOBILENO, SENTYN, APPLICATIONDATE, USERID, " & _
            " MACHINEID,SMSTYPE,featurecode,SYSTEMDATE) values(SEQSMSID.nextval,'" & strpbrcd & "'," & _
            "'" & strpcurcd & "','" & strpmodid & "','" & strpglcd & "'," & _
            "'" & strpaccno & "','" & strmodeoftran & "'," & intbatchno & "," & inttranno & ",'" & strpbuldmsg & "','" & strpcustmobile & "','N'," & _
            "'" & Format(CDate(strpappldate), "dd-MMM-yyyy") & "','" & strpuid & "'," & _
            "'" & strpmacid & "','" & strpsmstypeg & "'," & intpfeatcd & ",to_date('" & Format(datenow.Now, "dd-MMM-yyyy HH:mm:ss") & "', 'dd-Mon-yyyy HH24:Mi:ss'))"

            cmdsmsgenins = New OracleClient.OracleCommand(sqlstrgenins, objconn)
            cmdsmsgenins.ExecuteNonQuery()

            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing

            Exit Sub
        Catch ex As Exception

            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing
        End Try
    End Sub
    Public Function GetSMSBankName() As String
        Try
            Dim strSMSBankName1 As String = ""
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Function
                End If
            End If

            strsqluidpwd = "select smsbankname from SMSPARAMETERS"
            cmdsmsuidpwd = New OracleClient.OracleCommand(strsqluidpwd, objconn)
            drsmsuidpwd = cmdsmsuidpwd.ExecuteReader()

            If drsmsuidpwd.HasRows = True Then
                drsmsuidpwd.Read()
                strSMSBankName1 = IIf(IsDBNull(drsmsuidpwd!smsbankname), "", drsmsuidpwd!smsbankname.ToString)
            End If
            GetSMSBankName = strSMSBankName1
            cmdsmsuidpwd.Dispose()
            cmdsmsuidpwd = Nothing
            drsmsuidpwd.Close()
            drsmsuidpwd = Nothing
            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Sub InsertIntoSMSTranday(ByVal strpbrcd As String, ByVal strpcurcd As String, ByVal strpmodid As String, ByVal strpglcd As String, ByVal strpaccno As String, ByVal strpbuldmsg As String, ByVal strpcustmobile As String, ByVal strpappldate As String, ByVal strpuid As String, ByVal strpmacid As String, ByVal strpsmstypeg As String, ByVal intpfeatcd As Integer)
        Try

            sqlstrgenins = "insert into smstranday(SMSID, BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, " & _
            " ACCNO, MESSAGE, MOBILENO, SENTYN, APPLICATIONDATE, USERID, " & _
            " MACHINEID,SMSTYPE,featurecode,SYSTEMDATE) values(SEQSMSID.nextval,'" & strpbrcd & "'," & _
            "'" & strpcurcd & "','" & strpmodid & "','" & strpglcd & "'," & _
            "'" & strpaccno & "','" & strpbuldmsg & "','" & strpcustmobile & "','N'," & _
            "'" & Format(CDate(strpappldate), "dd-MMM-yyyy") & "','" & strpuid & "'," & _
            "'" & strpmacid & "','" & strpsmstypeg & "'," & intpfeatcd & ",to_date('" & Format(datenow.Now, "dd-MMM-yyyy HH:mm:ss") & "', 'dd-Mon-yyyy HH24:Mi:ss'))"

            cmdsmsgenins = New OracleClient.OracleCommand(sqlstrgenins, objconn)
            cmdsmsgenins.ExecuteNonQuery()
            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing

            Exit Sub
        Catch ex As Exception

            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing
        End Try
    End Sub

    Public Function GetIMPSLocation(ByVal strrefnum As String, ByVal strtable As String) As String
        Try
            Dim strimpsloc As String
            strSql = "SELECT  ATMLOCATION FROM " & strtable & " WHERE refnum = '" & strrefnum & "'"
            cmdsmsfeat = New OracleClient.OracleCommand(strSql, objconn)
            drsmsfeat = cmdsmsfeat.ExecuteReader()
            If drsmsfeat.Read() Then
                strimpsloc = IIf(IsDBNull(drsmsfeat!ATMLOCATION), "", drsmsfeat!ATMLOCATION)
            Else
                strimpsloc = ""
            End If
            GetIMPSLocation = strimpsloc
            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing

            Exit Function
        Catch ex As Exception
            GetIMPSLocation = ""

            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing
        End Try
    End Function

    Public Function GetIMPSOutRevRemarks(ByVal strrefnum As String) As String
        Try
            Dim strRem As String
            strSql = "SELECT remarks FROM impslogdtls WHERE refnum = '" & strrefnum & "'"
            cmdsmsfeat = New OracleClient.OracleCommand(strSql, objconn)
            drsmsfeat = cmdsmsfeat.ExecuteReader()
            If drsmsfeat.Read() Then
                strRem = GetIMPSRemarks(IIf(IsDBNull(drsmsfeat!remarks), "", Mid(drsmsfeat!remarks, 1, 3)))
            Else
                strRem = ""
            End If
            GetIMPSOutRevRemarks = strRem
            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing

            Exit Function
        Catch ex As Exception
            GetIMPSOutRevRemarks = ""

            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing
        End Try
    End Function

    Public Function GetIMPSRemarks(ByVal strRespCode) As String
        Try
            Dim strRem As String
            strRem = ""
            If strRespCode = "0M1" Then
                strRem = "Invalid Account Number"
            ElseIf strRespCode = "0M3" Then
                strRem = "Account Inoperative / Frozen"
            ElseIf strRespCode = "0M5" Then
                strRem = "Closed Account Number"
            ElseIf strRespCode = "0M2" Then
                strRem = "Limit Exceed"
            ElseIf strRespCode = "0M0" Then
                strRem = "Transaction Failed"
            ElseIf strRespCode = "092" Then
                strRem = "Invalid IFSC Code"
            ElseIf strRespCode = "0M6" Then
                strRem = "Net Debit Cap Check at NPCI"
            ElseIf strRespCode = "0MP" Then
                strRem = "Invalid A/c OR IFSC No"
            ElseIf strRespCode = "036" Then
                strRem = "Restricted Card "
            ElseIf strRespCode = "0M4" Then
                strRem = "NRE Account "
            ElseIf strRespCode = "091" Then
                strRem = "Verification Process"
            ElseIf strRespCode = "0NC" Then
                strRem = "0NC"
            ElseIf strRespCode = "008" Then
                strRem = "host down"
            ElseIf strRespCode = "094" Then
                strRem = "Duplicate Transactions"
            End If
            GetIMPSRemarks = strRem
            Exit Function
        Catch ex As Exception
            GetIMPSRemarks = ""
        End Try
    End Function
End Module
