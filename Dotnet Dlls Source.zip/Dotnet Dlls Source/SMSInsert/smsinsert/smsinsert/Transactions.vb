Public Class Transactions
    Public Sub TransactionApp(ByRef perrDesc As String)
        Try

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then

                    Exit Sub
                End If
            End If
            '' cash deposit  --- 1
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 1
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate,'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,1,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 2  and (chqfvg not in('ICCR','IC','ATM') or chqfvg is null) and abs(amount) >=" & dblminamt  'and serviceid = 1 "
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))

                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            'to release the resources
            SetGenFreeResr()


            '' cash payment ---- 2
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""

            intfeatcd = 2
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno,  applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,2,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " (modeoftran = 1 and CASHPAIDYN = 'Y')  and (chqfvg not in('ICCR','IC','ATM','POS','ECOM') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                     drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                     Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' inward Debit clearing --- 3
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 3
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then



                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,3,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 5  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)
                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                     drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                     Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If

            SetGenFreeResr()

            '' outward Credit clearing -- 4
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 4
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then


                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,4,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','DEP','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 6  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)


                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)


                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' Debit Transfer -- 7 
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 7
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount,chqno, " & _
                "  applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,7,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and moduleid in ('SB','CA','LOAN','CC') and transtatus = 'A' and  " & _
                " modeoftran = 3 and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)



                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            strchequeno = ""
                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If

                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            If UBound(strarrmsgtags) = 4 Then


                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                            drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If
                            ElseIf UBound(strarrmsgtags) = 3 Then
                                strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                            drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                            Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                                If strSMSBankName <> "" Then
                                    strbuldmsg = strbuldmsg & " " & strSMSBankName
                                Else
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                                End If
                            Else
                                strbuldmsg = ""
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()

            '' Credit Transfer  --- 8
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 8
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,moduleid,glcode, accno, batchno, tranno, modeoftran,abs(amount) amount, " & _
                "  applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,8,applicationdate) not in " & _
                " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate from " & _
                " smstranday) and (moduleid in ('SB','CA','LOAN','CC') or (moduleid = 'DEP' and glcode in (select glcode from deptypemst where INSTSYN = 'Y' )))and transtatus = 'A' and  " & _
                " modeoftran = 4  and (chqfvg not in('ICCR','IC') or chqfvg is null) and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            strclosebal = ""
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            GetAccountNo(drsmsgen!accno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!moduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy"))
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!moduleid.ToString, drsmsgen!glcode.ToString, drsmsgen!accno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()




            '' outward return --- 6
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 6
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,linkmoduleid,linkglcode, linkaccno, batchno, tranno, modeoftran,abs(amount) amount, " & _
    " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,6,applicationdate) not in " & _
    " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate  from " & _
    " smstranday) and moduleid in ('SB','CA','CC') and transtatus = 'A' and modeoftran =  6 and serviceid = 8  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!linkaccno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!linkmoduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()


            '' inward return --- 5
            sqlstrgenins = ""
            strsqlgen = ""
            strbuldmsg = ""
            intfeatcd = 5
            If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, dblminamt) = True Then

                strsqlgen = "select branchcode,currencycode,linkmoduleid,linkglcode, linkaccno, batchno, tranno, modeoftran,abs(amount) amount, " & _
    " chqno, applicationdate, 'SYSTEM' USERID from gentranslog g where (branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,5,applicationdate) not in " & _
    " (select branchcode,currencycode,moduleid,glcode,accno,batchno,tranno,MODEOFTRAN,nvl(featurecode,0),applicationdate  from " & _
    " smstranday) and moduleid in ('SB','CA','CC') and transtatus = 'A' and modeoftran =  5 and serviceid = 8  and (chqfvg not in('ICCR','IC') or chqfvg is null)  and abs(amount) >= " & dblminamt
                cmdsmsgen = New OracleClient.OracleCommand(strsqlgen, objconn)
                drsmsgen = cmdsmsgen.ExecuteReader()

                While drsmsgen.Read()
                    strcustmobile = "" : strSMSYN = ""
                    GetCustMobileName(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strcustmobile, strSMSYN)

                    'checking for customer mobile no
                    If strcustmobile = "" Then
                    Else
                        If strSMSYN = "Y" Then
                            GetCloseBal(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, strclosebal)

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <accno>
                            ' strarrmsgtags(1) --- <amount>
                            ' strarrmsgtags(2) --- <date>
                            ' strarrmsgtags(3) --- <balance>
                            ' strarrmsgtags(4) --- <chequeno>

                            If IsDBNull(drsmsgen!chqno) Then
                                strchequeno = ""
                            Else
                                strchequeno = "by ChqNo:" & drsmsgen!chqno.ToString
                            End If
                            GetAccountNo(drsmsgen!linkaccno.ToString, strmodaccno)
                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), drsmsgen!linkmoduleid.ToString & ":" & strmodaccno).Replace(strarrmsgtags(1), _
                                        drsmsgen!amount.ToString()).Replace(strarrmsgtags(3), strclosebal).Replace(strarrmsgtags(2), _
                                        Format(CDate(drsmsgen!applicationdate.ToString()), "dd-MMM-yyyy")).Replace(strarrmsgtags(4), strchequeno)
                            If strSMSBankName <> "" Then
                                strbuldmsg = strbuldmsg & " " & strSMSBankName
                            Else
                                strbuldmsg = strbuldmsg & " " & GetSMSBankName()
                            End If
                            InsertGentranlogIntoSMSTranday(drsmsgen!branchcode.ToString, drsmsgen!currencycode.ToString, drsmsgen!linkmoduleid.ToString, drsmsgen!linkglcode.ToString, drsmsgen!linkaccno.ToString, drsmsgen!modeoftran.ToString, drsmsgen!batchno.ToString, drsmsgen!tranno.ToString, strbuldmsg, strcustmobile, drsmsgen!applicationdate.ToString, drsmsgen!USERID.ToString, strIPAddress, strsmstypeg, intfeatcd)
                        End If
                    End If
                End While
            End If
            SetGenFreeResr()


        Catch ex As Exception
            perrDesc = ex.Message
        End Try
    End Sub

End Class
