Public Class PostChargesAuto
    Dim objDr As OracleClient.OracleDataReader
    Dim objDr1 As OracleClient.OracleDataReader
    Dim objCmd As New OracleClient.OracleCommand
    Public objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim objtran As OracleClient.OracleTransaction

    Public Function postAutomatically(ByVal brCode, ByVal curCode, ByVal drMod, ByVal drGl, ByVal drAcc, ByVal Code, ByVal appDate, ByVal userId, ByVal machineID, Optional ByVal commAmt = "0", Optional ByVal servTaxAmt = "0") As String
        Try
            Dim strCommServ, strCommMod, strCommGl, strCommGlDesc, strCommAcc, strCommAmt, strServMod, strServGl, strServGlDesc, strServAcc, strServPercent, strEffDate, strSrvTax, strAutoPostCharges, errmsg, strBatchNo, strTranNo1, strTranNo2, strTranNo3, commYN, servTaxYN As String
            Dim dblComm, dblSrv, totDrAmt As Double

            dblComm = 0
            dblSrv = 0
            strCommServ = ""
            strCommMod = ""
            strCommGl = ""
            strCommGlDesc = ""
            strCommAcc = ""
            strCommAmt = ""
            strServMod = ""
            strServGl = ""
            strServGlDesc = ""
            strServAcc = ""
            strServPercent = ""
            strEffDate = ""
            strSrvTax = ""
            strAutoPostCharges = "N"
            commYN = "N"
            servTaxYN = "N"

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            strCommServ = "SELECT COMMMODULEID, COMMGLCODE, COMGLDESC, COMMACCNO, COMMAMT, " & _
                          "SRVSTAXMODULEID, SRVSTAXGLCODE, SRVSTAXGLDESC, SRVSTAXACCNO, " & _
                          "SRVSTAXPERCENT, TO_CHAR(EFFECTIVEDATE,'dd-Mon-yyyy')," & _
                          "CEIL( (COMMAMT*SRVSTAXPERCENT)/100), AUTOPOSTCHRGSYN, " & _
                          "COMMISSIONYN, SERVICETAXYN FROM " & _
                          "GENCHARGESPMT WHERE CHARGESID='" & Code & "'"

            objCmd = New OracleClient.OracleCommand(strCommServ, objconn)
            objDr = objCmd.ExecuteReader()

            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCommMod = objDr(0)
                    strCommGl = objDr(1)
                    strCommGlDesc = objDr(2)
                    strCommAcc = objDr(3)
                    strCommAmt = objDr(4)
                    strServMod = objDr(5)
                    strServGl = objDr(6)
                    strServGlDesc = objDr(7)
                    strServAcc = objDr(8)
                    strServPercent = objDr(9)
                    strEffDate = objDr(10)
                    strSrvTax = objDr(11)
                    strAutoPostCharges = objDr(12)
                    commYN = objDr(13)
                    servTaxYN = objDr(14)
                End While
            Else
                GoTo LastLine
            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg As String

            If Code <> "LRC" And commYN = "N" Then
                servTaxYN = "N"
            End If

            If Code = "CIC" Then
                If CInt(commAmt) = 0 Or commAmt = "" Then
                    strAutoPostCharges = "N"
                End If
                strChqFvg = "CIC"
                strRemarksDr = "Cheque Book Issue Charges"
                strRemarksCr = "Cheque Book Issue Charges From " & drMod & " Accno " & drAcc
                strCommAmt = commAmt
                strSrvTax = servTaxAmt
            ElseIf Code = "SPC" Then
                strChqFvg = "SPC"
                strRemarksDr = "Stop Payment Charges"
                strRemarksCr = "Stop Payment Charges From " & drMod & " Accno " & drAcc
            End If

            If strAutoPostCharges = "N" Then
                postAutomatically = "Posted SuccessFully|"
                Exit Function
            End If

            If commYN = "N" Then
                totDrAmt = CDbl(strSrvTax)
            End If

            If servTaxYN = "N" Then
                totDrAmt = CDbl(strCommAmt)
            End If

            If commYN = "Y" And servTaxYN = "Y" Then
                totDrAmt = CDbl(strCommAmt) + CDbl(strSrvTax)
            End If


            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                          "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                          "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                          "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                          "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                          "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                          "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                          "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                          "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                          "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                          "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                          "APPROVEDMACHINE, SYSTEMYEAR, ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                          "ABBYN"

            strBatchNo = ""
            strTranNo1 = ""
            strTranNo2 = ""
            strTranNo3 = ""

            If commYN = "Y" Or servTaxYN = "Y" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                strBatchNo = objCmd.ExecuteScalar

                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                strTranNo1 = objCmd.ExecuteScalar
            End If

            If commYN = "Y" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                strTranNo2 = objCmd.ExecuteScalar
            End If

            If servTaxYN = "Y" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & brCode & ".NEXTVAL TranNo FROM dual", objconn)
                strTranNo3 = objCmd.ExecuteScalar
            End If

            objtran = objconn.BeginTransaction()

            If commYN = "Y" Or servTaxYN = "Y" Then
                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                     "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                                     "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                     "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                     "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                     "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                     "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                     "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                     "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                                     "NULL,NULL,'N','" & userId & "','N',NULL,NULL,NULL,NULL,NULL,NULL,NULL," & _
                                     "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                     "NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                     "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N')"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

                StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                         "('" & brCode & "','" & curCode & "','" & drMod & "'," & _
                         "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                         "'" & strTranNo1 & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                         "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                         "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                         "NULL,NULL,'N','" & userId & "','N'," & _
                         "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                         "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                         "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL)"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing
            End If

            If commYN = "Y" Then

                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                         "NULL,NULL,'N','" & userId & "','N'," & _
                         "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                         "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                         "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N')"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

                StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                         "('" & brCode & "','" & curCode & "','" & strCommMod & "'," & _
                         "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                         "'" & strTranNo2 & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strCommMod & "MST " & _
                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & strCommMod & "MST " & _
                         "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                         "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                         "NULL,NULL,'N','" & userId & "','N'," & _
                         "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                         "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                         "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL)"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

            End If

            If servTaxYN = "Y" Then

                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                        "('" & brCode & "','" & curCode & "','" & strServMod & "'," & _
                        "'" & strServGl & "','" & strServAcc & "','" & strBatchNo & "'," & _
                        "'" & strTranNo3 & "'," & strSrvTax & ",'4',NULL,NULL,NULL," & _
                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strServMod & "MST " & _
                        "WHERE ACCNO='" & strServAcc & "' AND GLCODE='" & strServGl & "' AND " & _
                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & strServMod & "MST " & _
                        "WHERE ACCNO='" & strServAcc & "' AND GLCODE='" & strServGl & "' AND " & _
                        "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                        "NULL,NULL,'N','" & userId & "','N'," & _
                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                        "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                        "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N')"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing

                StrInsert = "INSERT INTO " & strServMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                        "('" & brCode & "','" & curCode & "','" & strServMod & "'," & _
                        "'" & strServGl & "','" & strServAcc & "','" & strBatchNo & "'," & _
                        "'" & strTranNo3 & "'," & strSrvTax & ",'4',NULL,NULL,NULL," & _
                        "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & strServMod & "MST " & _
                        "WHERE ACCNO='" & strServAcc & "' AND GLCODE='" & strServGl & "' AND " & _
                        "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & strServMod & "MST " & _
                        "WHERE ACCNO='" & strServAcc & "' AND GLCODE='" & strServGl & "' AND " & _
                        "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                        "NULL,NULL,'N','" & userId & "','N'," & _
                        "NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                        "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                        "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'N',NULL)"

                objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                objCmd.Transaction = objtran
                objCmd.ExecuteNonQuery()
                objCmd.Dispose()
                objCmd = Nothing
            End If

            objtran.Commit()
            postAutomatically = "Posted SuccessFully|" & strBatchNo

            If commYN = "N" And servTaxYN = "N" Then
                postAutomatically = "Posted SuccessFully|"
            End If
LastLine:
            If Mid(postAutomatically, 1, 19) <> "Posted SuccessFully" Then
                postAutomatically = "Error Occurred in Charges Posting"
            End If

        Catch ex As Exception
            objtran.Rollback()
            postAutomatically = ex.Message
        End Try

    End Function


    Public Function postAutomaticallyGST(ByVal brCode, ByVal curCode, ByVal drMod, ByVal drGl, ByVal drAcc, ByVal Code, ByVal appDate, ByVal userId, ByVal machineID, Optional ByVal commAmt = "0", Optional ByVal GSTAmt = "0", Optional ByVal CessAmt = "0", Optional ByVal pBatchno = "0", Optional ByVal pDrRemarks = "", Optional ByVal strchkabbyn = "N", Optional ByVal sessbrcode = "") As String
        Try
            Dim strCommServ, strCommMod, strCommGl, strCommGlDesc, strCommAcc, strCommAmt, strCGSTMod, strCGSTGl, strCGSTGlDesc, strCGSTAcc, strGSTPercent, strSGSTMod, strSGSTGl, strSGSTGlDesc, strSGSTAcc, strCESSMod, strCESSGl, strCESSGlDesc, strCESSAcc, strEffDate, strGSTAmt, strCESSAmt, strCGSTAmt, strSGSTAmt, strAutoPostCharges, errmsg, strBatchNo, strTranNoDr, strTranNoCmCr, strTranNoCGSTCr, strTranNoSGSTCr, strTranNoCESSCr, commYN, GSTYN, CessYN, strSql As String
            Dim strTaxableVal As String
            Dim dblComm, dblSrv, totDrAmt As Double
            Dim nonCustomerid As String
            Dim strTotChrgs As String
            Dim strdrbrcode As String
            Dim strcrbrcode As String
            Dim strAbbYN, strABBCols, strABBVals As String
            Dim strbatchbrcode As String
            Dim gsttxnRemarks As String
            Dim strchrgetypedesc As String

            nonCustomerid = "1111111111"
            dblComm = 0
            dblSrv = 0
            totDrAmt = 0
            strCommServ = ""
            strSql = ""
            strCommMod = ""
            strCommGl = ""
            strCommGlDesc = ""
            strCommAcc = ""
            strCommAmt = ""
            strCGSTMod = ""
            strCGSTGl = ""
            strCGSTGlDesc = ""
            strCGSTAcc = ""
            strGSTPercent = ""
            strSGSTMod = ""
            strSGSTGl = ""
            strSGSTGlDesc = ""
            strSGSTAcc = ""
            strCESSMod = ""
            strCESSGl = ""
            strCESSGlDesc = ""
            strCESSAcc = ""
            strEffDate = ""
            strGSTAmt = ""
            strCGSTAmt = ""
            strSGSTAmt = ""
            strCESSAmt = ""
            strTotChrgs = ""
            strAutoPostCharges = "N"
            commYN = "N"
            GSTYN = "N"
            CessYN = "N"
            gsttxnRemarks = ""
            strchrgetypedesc = ""
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            If strchkabbyn = "Y" Then
                strdrbrcode = brCode
                strcrbrcode = sessbrcode
                strbatchbrcode = "ABB"
                strAbbYN = "Y"
                strABBCols = ",ABBYN,ABBBRANCHCODE, ABBAPPLICATIONDATE"
                strABBVals = ",'" & strAbbYN & "','" & sessbrcode & "','" & appDate & "'"
            Else
                strdrbrcode = brCode
                strcrbrcode = brCode
                strbatchbrcode = brCode
                strAbbYN = "N"
                strABBCols = ",ABBYN"
                strABBVals = ",'" & strAbbYN & "'"

            End If

            strCommServ = "SELECT COMMMODULEID, COMMGLCODE, COMGLDESC, COMMACCNO, COMMAMT, " & _
                          "TO_CHAR(EFFECTIVEDATE,'dd-Mon-yyyy') EFFECTIVEDATE," & _
                          " nvl(AUTOPOSTCHRGSYN,'N') AUTOPOSTCHRGSYN, " & _
                          "nvl(COMMISSIONYN,'N') COMMISSIONYN FROM " & _
                          "GENCHARGESPMT WHERE CHARGESID='" & Code & "'"

            objCmd = New OracleClient.OracleCommand(strCommServ, objconn)
            objDr = objCmd.ExecuteReader()

            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCommMod = IIf(IsDBNull(objDr!COMMMODULEID), "", objDr!COMMMODULEID)
                    strCommGl = IIf(IsDBNull(objDr!COMMGLCODE), "", objDr!COMMGLCODE)
                    strCommGlDesc = IIf(IsDBNull(objDr!COMGLDESC), "", objDr!COMGLDESC)
                    strCommAcc = IIf(IsDBNull(objDr!COMMACCNO), "", objDr!COMMACCNO)
                    strCommAmt = IIf(IsDBNull(objDr!COMMAMT), 0, objDr!COMMAMT)
                    strEffDate = objDr!EFFECTIVEDATE
                    strAutoPostCharges = IIf(IsDBNull(objDr!AUTOPOSTCHRGSYN), "N", objDr!AUTOPOSTCHRGSYN)
                    commYN = IIf(IsDBNull(objDr!COMMISSIONYN), "N", objDr!COMMISSIONYN)
                End While
            Else
                GoTo LastLine
            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' GSTYN
            strSql = "SELECT nvl(impyn,'N') impyn,NVL(value1,'0') val FROM genconfigmst WHERE code = 'GSTR'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    GSTYN = IIf(IsDBNull(objDr!impyn), "N", objDr!impyn)
                    strGSTPercent = IIf(IsDBNull(objDr!val), 0, objDr!val)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' CGST
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='CGST'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCGSTMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strCGSTGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strCGSTGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strCGSTAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing


            ''SGST
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='SGST'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strSGSTMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strSGSTGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strSGSTGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strSGSTAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' Cessyn
            strSql = "SELECT nvl(impyn,'N') impyn FROM genconfigmst WHERE code = 'CESS'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    CessYN = IIf(IsDBNull(objDr!impyn), "N", objDr!impyn)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            ''CESS
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='CESS'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCESSMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strCESSGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strCESSGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strCESSAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg As String

            If Code = "CIC" Then

                strChqFvg = "CIC"
                If GSTYN = "Y" Then
                    strRemarksDr = "Cheque Book Issue Charges Inclusive GST"
                Else
                    strRemarksDr = "Cheque Book Issue Charges"
                End If

                strRemarksCr = "Cheque Book Issue Charges From " & drMod & " Accno " & drAcc
                gsttxnRemarks = "Cheque Book Issue Charges " & GetSubnature(drMod, drGl) & " Accno " & drAcc
            ElseIf Code = "SPC" Then
                strChqFvg = "SPC"
                If GSTYN = "Y" Then
                    strRemarksDr = "Stop Payment Charges Inclusive GST"
                Else
                    strRemarksDr = "Stop Payment Charges"
                End If
                strRemarksCr = "Stop Payment Charges From " & drMod & " Accno " & drAcc
                gsttxnRemarks = "Stop Payment Charges " & GetSubnature(drMod, drGl) & " Accno " & drAcc
            ElseIf Code = "INOP" Then

                strChqFvg = "INOP"
                strchrgetypedesc = ""
                GetChargeTypeCodeChk(Code, strchrgetypedesc)
                If GSTYN = "Y" Then
                    strRemarksDr = strchrgetypedesc & " Inclusive GST"
                Else
                    strRemarksDr = strchrgetypedesc & " "
                End If

                strRemarksCr = strchrgetypedesc & " From " & drMod & " Accno " & drAcc
                gsttxnRemarks = strchrgetypedesc & " " & GetSubnature(drMod, drGl) & " Accno " & drAcc

                'ElseIf (Code = "ACC" Or Code = "APPR" Or Code = "ATM" Or Code = "BNKC" Or Code = "CANC" Or Code = "CSS" Or Code = "EFEE" Or Code = "FC" Or Code = "INSU" Or Code = "IRC" Or Code = "LEGF" Or Code = "LNC" Or Code = "LPC" Or Code = "LRC" Or Code = "MBC" Or Code = "MINC" Or Code = "NEFT" Or Code = "ORC" Or Code = "OTH" Or Code = "STC" Or Code = "VALF") Then
            Else
                strchrgetypedesc = ""
                If GetChargeTypeCodeChk(Code, strchrgetypedesc) = True Then
                    strChqFvg = Code
                    If GSTYN = "Y" Then
                        strRemarksDr = pDrRemarks & " Inclusive GST"
                    Else
                        strRemarksDr = pDrRemarks
                    End If

                    strRemarksCr = strchrgetypedesc & " From " & drMod & " Accno " & drAcc
                    gsttxnRemarks = strchrgetypedesc & " " & GetSubnature(drMod, drGl) & " Accno " & drAcc
                End If
            End If

            strCommAmt = commAmt
            strGSTAmt = GSTAmt
            strCESSAmt = CessAmt

            If CInt(commAmt) = 0 Or commAmt = "" Then
                strAutoPostCharges = "N"
            End If

            If strAutoPostCharges = "N" Then
                postAutomaticallyGST = "Posted SuccessFully|"
                Exit Function
            End If


            If commYN = "Y" Then
                totDrAmt = CDbl(strCommAmt)
            End If
            If commYN = "Y" And GSTYN = "Y" Then
                totDrAmt = CDbl(strCommAmt) + CDbl(strGSTAmt)
            End If
            If commYN = "Y" And GSTYN = "Y" And CessYN = "Y" Then
                totDrAmt = CDbl(strCommAmt) + CDbl(strGSTAmt) + CDbl(strCESSAmt)
            End If


            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                          "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                          "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                          "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                          "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                          "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                          "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                          "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                          "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                          "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                          "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                          "APPROVEDMACHINE" & strABBCols

            strBatchNo = ""
            strTranNoDr = ""
            strTranNoCmCr = ""
            strTranNoCGSTCr = ""
            strTranNoSGSTCr = ""
            strTranNoCESSCr = ""

            '' DEBIT
            If commYN = "Y" Then
                If pBatchno = "0" Then
                    objCmd = New OracleClient.OracleCommand("SELECT SEQBATCHNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                    strBatchNo = objCmd.ExecuteScalar
                Else
                    strBatchNo = pBatchno
                End If
                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                strTranNoDr = objCmd.ExecuteScalar
            End If

            '' CREDIT 
            If commYN = "Y" Then
                objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                strTranNoCmCr = objCmd.ExecuteScalar


                If GSTYN = "Y" Then
                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                    strTranNoCGSTCr = objCmd.ExecuteScalar

                    objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                    strTranNoSGSTCr = objCmd.ExecuteScalar

                    If CessYN = "Y" Then
                        objCmd = New OracleClient.OracleCommand("SELECT SEQTRANNO" & strbatchbrcode & ".NEXTVAL TranNo FROM dual", objconn)
                        strTranNoCESSCr = objCmd.ExecuteScalar
                    End If
                End If
            End If



            objtran = objconn.BeginTransaction()

            If commYN = "Y" Then
                If CDbl(totDrAmt) <> 0 Then
                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                         "('" & strdrbrcode & "','" & curCode & "','" & drMod & "'," & _
                                         "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                                         "'" & strTranNoDr & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                                         "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                                         "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                         "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                                         "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                                         "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                                         "NULL,NULL,'N',NULL,'N',NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL," & _
                                         "'" & strRemarksDr & "','1',NULL,NULL,NULL,'N',NULL,NULL," & _
                                         "NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                         "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ")"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    StrInsert = "INSERT INTO " & drMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                             "('" & strdrbrcode & "','" & curCode & "','" & drMod & "'," & _
                             "'" & drGl & "','" & drAcc & "','" & strBatchNo & "'," & _
                             "'" & strTranNoDr & "',-" & totDrAmt & ",'3',NULL,NULL,NULL," & _
                             "NULL,'" & appDate & "',(SELECT CUSTOMERID FROM " & drMod & "MST " & _
                             "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                             "BRANCHCODE='" & brCode & "'),(SELECT NAME FROM " & drMod & "MST " & _
                             "WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & _
                             "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                             "NULL,NULL,'N',NULL,'N'," & _
                             "NULL,NULL,NULL,'" & strCommMod & "','" & strCommGl & "','" & strCommAcc & "',NULL,'" & strRemarksDr & "','1',NULL,NULL," & _
                             "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                             "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ",NULL)"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                End If  ''CDbl(totDrAmt) <> 0
            End If

            ''credit
            If commYN = "Y" Then
                If CDbl(strCommAmt) <> 0 Then
                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                             "('" & strcrbrcode & "','" & curCode & "','" & strCommMod & "'," & _
                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                             "'" & strTranNoCmCr & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                             "NULL,'" & appDate & "','" & nonCustomerid & "',(SELECT NAME FROM " & strCommMod & "MST " & _
                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                             "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                             "NULL,NULL,'N',NULL,'N'," & _
                             "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                             "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                             "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ")"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    StrInsert = "INSERT INTO " & strCommMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                             "('" & strcrbrcode & "','" & curCode & "','" & strCommMod & "'," & _
                             "'" & strCommGl & "','" & strCommAcc & "','" & strBatchNo & "'," & _
                             "'" & strTranNoCmCr & "'," & strCommAmt & ",'4',NULL,NULL,NULL," & _
                             "NULL,'" & appDate & "','" & nonCustomerid & "',(SELECT NAME FROM " & strCommMod & "MST " & _
                             "WHERE ACCNO='" & strCommAcc & "' AND GLCODE='" & strCommGl & "' AND " & _
                             "BRANCHCODE='" & brCode & "'),NULL,NULL,'" & strChqFvg & "'," & _
                             "NULL,NULL,'N',NULL,'N'," & _
                             "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                             "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                             "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ",NULL)"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                End If  ''CDbl(strCommAmt) <> 0


                If GSTYN = "Y" Then
                    ''CGST
                    strCGSTAmt = Math.Round(CDbl(strGSTAmt) / 2, 2)
                    If CDbl(strCGSTAmt) <> 0 Then
                        strChqFvg = "CGST"

                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                "('" & strcrbrcode & "','" & curCode & "','" & strCGSTMod & "'," & _
                                "'" & strCGSTGl & "','" & strCGSTAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNoCGSTCr & "'," & strCGSTAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                "NULL,NULL,'N',NULL,'N'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ")"

                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                        StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                "('" & strcrbrcode & "','" & curCode & "','" & strCGSTMod & "'," & _
                                "'" & strCGSTGl & "','" & strCGSTAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNoCGSTCr & "'," & strCGSTAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                "NULL,NULL,'N',NULL,'N'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ",NULL)"

                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                    End If
                    '' SGST
                    strSGSTAmt = Math.Round(CDbl(strGSTAmt) / 2, 2)
                    If CDbl(strSGSTAmt) <> 0 Then
                        strChqFvg = "SGST"
                        StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                "('" & strcrbrcode & "','" & curCode & "','" & strSGSTMod & "'," & _
                                "'" & strSGSTGl & "','" & strSGSTAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNoSGSTCr & "'," & strSGSTAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                "NULL,NULL,'N',NULL,'N'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ")"

                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing

                        StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                "('" & strcrbrcode & "','" & curCode & "','" & strSGSTMod & "'," & _
                                "'" & strSGSTGl & "','" & strSGSTAcc & "','" & strBatchNo & "'," & _
                                "'" & strTranNoSGSTCr & "'," & strSGSTAmt & ",'4',NULL,NULL,NULL," & _
                                "NULL,'" & appDate & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                "NULL,NULL,'N',NULL,'N'," & _
                                "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ",NULL)"

                        objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                        objCmd.Transaction = objtran
                        objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                    End If



                    If CessYN = "Y" Then
                        If CDbl(strCESSAmt) <> 0 Then
                            ''CESS Amount
                            strChqFvg = "CESS"
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & strcrbrcode & "','" & curCode & "','" & strCESSMod & "'," & _
                                    "'" & strCESSGl & "','" & strCESSAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoCESSCr & "'," & strCESSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N',NULL,'N'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ")"

                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing

                            StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & strcrbrcode & "','" & curCode & "','" & strCESSMod & "'," & _
                                    "'" & strCESSGl & "','" & strCESSAcc & "','" & strBatchNo & "'," & _
                                    "'" & strTranNoCESSCr & "'," & strCESSAmt & ",'4',NULL,NULL,NULL," & _
                                    "NULL,'" & appDate & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N',NULL,'N'," & _
                                    "NULL,NULL,NULL,'" & drMod & "','" & drGl & "','" & drAcc & "',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,NULL,'" & appDate & "','" & userId & "'," & _
                                    "'" & machineID & "','P',SYSDATE,NULL,NULL,NULL,NULL" & strABBVals & ",NULL)"

                            objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                            objCmd.Transaction = objtran
                            objCmd.ExecuteNonQuery()
                            objCmd.Dispose()
                            objCmd = Nothing
                        End If
                    End If '' cessyn
                End If '' gstyn

                If GSTYN = "Y" Then
                    ''POS place of supply
                    Dim strPOS As String
                    strPOS = ""
                    strSql = "SELECT  NVL(a.statecode||'-'||b.statename,'') POS FROM genbankbranchmst a,GENSTATEMST b WHERE a.statecode = b.statecode AND a.branchcode='" & strcrbrcode & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDr = objCmd.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strPOS = IIf(IsDBNull(objDr!POS), "", objDr!POS)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objCmd.Dispose()
                    objCmd = Nothing

                    '' gst customerid 
                    Dim strGSTCustomerid As String
                    Dim strRcpName As String
                    Dim strGSTIN As String
                    strGSTIN = ""
                    strGSTCustomerid = ""
                    strRcpName = ""
                    strSql = "SELECT CUSTOMERID,name FROM " & drMod & "MST WHERE ACCNO='" & drAcc & "' AND GLCODE='" & drGl & "' AND " & "BRANCHCODE='" & strcrbrcode & "'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDr = objCmd.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strGSTCustomerid = IIf(IsDBNull(objDr!CUSTOMERID), "", objDr!CUSTOMERID)
                            strRcpName = IIf(IsDBNull(objDr!name), "", objDr!name)
                        End While
                        ''GSTIN
                        strSql = "SELECT nvl(gstin,'') GSTIN FROM gencustinfomst WHERE customerid = '" & strGSTCustomerid & "'"
                        objCmd = New OracleClient.OracleCommand(strSql, objconn)
                        objCmd.Transaction = objtran
                        objDr1 = objCmd.ExecuteReader()
                        If (objDr1.HasRows) Then
                            While (objDr1.Read)
                                strGSTIN = IIf(IsDBNull(objDr1!GSTIN), "", objDr1!GSTIN)
                            End While
                        End If
                        objDr1.Close()
                        objDr1.Dispose()
                        objDr1 = Nothing


                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objCmd.Dispose()
                    objCmd = Nothing


                    '' invoice no
                    Dim strInvoiceNo As String
                    strInvoiceNo = ""
                    strSql = "SELECT NVL(MAX(TO_NUMBER(INVOICENO)),0)+1  Invoiceno FROM GSTTNXDTLS WHERE gstcode = 'GSTR'"
                    objCmd = New OracleClient.OracleCommand(strSql, objconn)
                    objCmd.Transaction = objtran
                    objDr = objCmd.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strInvoiceNo = IIf(IsDBNull(objDr!Invoiceno), "", objDr!Invoiceno)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objCmd.Dispose()
                    objCmd = Nothing

                    '' taxable value

                    strTaxableVal = ""
                    strTaxableVal = Math.Round(CDbl(strCommAmt) + CDbl(strSGSTAmt) + CDbl(strCGSTAmt) + CDbl(strCESSAmt), 2)
                    ''GSTTXNDTLS
                    StrInsert = "INSERT INTO gsttnxdtls (BRANCHCODE, CUSTOMERID, GSTCODE, GSTIN, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, " & _
    " REVERSECHARGE, INVOICETYPE, ECOMGSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, BATCHNO, STATUS, APPLICATIONDATE, " & _
    " USERID, MACHINEID, SYSTEMDATE,RECPNAME,REMARKS) VALUES " & _
      "('" & strcrbrcode & "','" & strGSTCustomerid & "','GSTR','" & strGSTIN & "','" & strInvoiceNo & "','" & appDate & "','" & strCommAmt & " ','" & strPOS & "','N','Regular','','" & strGSTPercent & "','" & strTaxableVal & "','" & strSGSTAmt & "','" & strCGSTAmt & "',0,'" & strCESSAmt & "','" & strBatchNo & "','R','" & appDate & "','" & userId & "','" & machineID & "',sysdate,'" & strRcpName & "','" & gsttxnRemarks & "')"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                End If ''GSTYN

                '' for loan and cc

                If (drMod = "LOAN" Or drMod = "CC") Then

                    ''loanchargepostdtls

                    strTotChrgs = ""
                    strTotChrgs = Math.Round(CDbl(strCommAmt) + CDbl(strGSTAmt) + CDbl(strCESSAmt), 2)
                    StrInsert = "INSERT INTO loanchargepostdtls (BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, CHARGETYPE, CHARGAMT, GSTAMT, CESS, TOTCHRGS, POSTYN, USERID, MACHINEID, APPLICATIONDATE, SYSTEMDATE) VALUES " & _
      "('" & strdrbrcode & "','" & curCode & "','" & drMod & "','" & drGl & "','" & drAcc & "','" & Code & "','" & strCommAmt & " ','" & strGSTAmt & "','" & strCESSAmt & "','" & strTotChrgs & "','Y','" & userId & "','" & machineID & "','" & appDate & "',sysdate)"

                    objCmd = New OracleClient.OracleCommand(StrInsert, objconn)
                    objCmd.Transaction = objtran
                    objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing
                End If

            End If '' commyn
            objtran.Commit()
            postAutomaticallyGST = "Posted SuccessFully|" & strBatchNo

            If commYN = "N" Then
                postAutomaticallyGST = "Posted SuccessFully|"
            End If
LastLine:
            If Mid(postAutomaticallyGST, 1, 19) <> "Posted SuccessFully" Then
                postAutomaticallyGST = "Error Occurred in Charges Posting"
            End If

        Catch ex As Exception
            objtran.Rollback()
            postAutomaticallyGST = ex.Message
        End Try

    End Function

    Private Function GetSubnature(ByVal strmodcode As String, ByVal strglcode As String) As String
        Dim strSql As String
        Dim strSubnature As String
        strSubnature = ""
        GetSubnature = ""
        If strmodcode = "LOAN" Or strmodcode = "SB" Or strmodcode = "CA" Or strmodcode = "CC" Or strmodcode = "DEP" Then

        If strmodcode = "LOAN" Then
            strSql = "SELECT LOANSUBNATURE SUBNATURE FROM " & strmodcode & "TYPEMST where glcode = '" & strglcode & "'"
        ElseIf strmodcode = "SB" Then
            strSql = "SELECT SUBNATURE FROM " & strmodcode & "TYPEMST where glcode = '" & strglcode & "'"
        ElseIf strmodcode = "CA" Then
            strSql = "SELECT SUBNATURE FROM " & strmodcode & "TYPEMST where glcode = '" & strglcode & "'"
        ElseIf strmodcode = "CC" Then
            strSql = "SELECT CCSUBNATURE SUBNATURE FROM " & strmodcode & "TYPEMST where glcode = '" & strglcode & "'"
        ElseIf strmodcode = "DEP" Then
            strSql = "SELECT DEPSUBNATURE SUBNATURE FROM " & strmodcode & "TYPEMST where glcode = '" & strglcode & "'"
        End If


        objCmd = New OracleClient.OracleCommand(strSql, objconn)
        objDr = objCmd.ExecuteReader()
        If (objDr.HasRows) Then
            While (objDr.Read)
                    strSubnature = IIf(IsDBNull(objDr!SUBNATURE), "", objDr!SUBNATURE)
            End While
        Else
                strSubnature = ""
        End If
            GetSubnature = strSubnature
        objDr.Close()
        objDr.Dispose()
        objDr = Nothing
        objCmd.Dispose()
        objCmd = Nothing
        End If

    End Function

    Private Function GetChargeTypeCodeChk(ByVal strCode As String, ByRef strChargeTypeDesc As String) As Boolean
        Dim strSql As String
        GetChargeTypeCodeChk = False
        strSql = "SELECT nvl(DESCRIPTION,'') DESCRIPTION FROM GENCHARGETYPEMST where CHARGETYPE = '" & strCode & "'"
        objCmd = New OracleClient.OracleCommand(strSql, objconn)
        objDr = objCmd.ExecuteReader()
        If (objDr.HasRows) Then
            While (objDr.Read)
                strChargeTypeDesc = IIf(IsDBNull(objDr!DESCRIPTION), "", objDr!DESCRIPTION)
            End While
            GetChargeTypeCodeChk = True
        Else
            strChargeTypeDesc = ""
            GetChargeTypeCodeChk = False
        End If
        objDr.Close()
        objDr.Dispose()
        objDr = Nothing
        objCmd.Dispose()
        objCmd = Nothing
    End Function

End Class
