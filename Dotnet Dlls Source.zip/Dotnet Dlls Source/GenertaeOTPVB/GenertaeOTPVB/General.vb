Imports System.Data.OracleClient

Public Class General
    Dim objTransaction As OracleClient.OracleTransaction
    Dim objconn As New OracleClient.OracleConnection
    Dim strsql As String
    Dim objDBConnection As New DatabaseConnection.cDBConnection
    Dim dr As OracleDataReader
    Dim objcmd As OracleCommand
    Dim o_Errmsg As String
    Dim strcustmessage As String
    Dim strmsgtags As String

    Dim strsmstypeg, strtrantypeg As String
    Dim strmode1 As String
    Dim intdays As Integer
    Dim strschtype As String
    Dim dtschdate As Date
    Dim dblminamt As Double
    Dim datenow As Date
    Private Function GenerateRandomNumberPassword() As String
        Try
            Dim length As Integer = 6
            Dim numbers As String = "0123456789"
            Dim objrandom As New Random
            Dim strrandom As String = String.Empty
            Dim noofnumbers As Integer = length
            For i As Integer = 0 To noofnumbers - 1
                Dim temp As Integer = objrandom.[Next](0, numbers.Length)
                strrandom = strrandom & temp
            Next
            GenerateRandomNumberPassword = strrandom

        Catch ex As Exception
        End Try
    End Function

    Public Function OTPGeneration(ByVal puserid As String, ByVal pmachineid As String, ByVal pappdate As String, ByRef pstrmobileno As String, ByRef pstrmobilenodisplay As String, ByRef strerrormessage1 As String) As String
        Dim strmobileno, strUserDOB As String
        Dim strerrormes As String
        Dim strotp1 As String
        Dim cnt As Integer
        Dim strnow, strnow1, strnow2 As String
        Dim strotpmessage As String
        Dim intfeatcd As Integer
        Dim strbuldmsg As String
        Dim strarrmsgtags(10) As String
        Dim strBrcode As String
        Dim blnchk As Boolean
        Try
            blnchk = False
            objconn = objDBConnection.GetDbConnection(o_Errmsg)
            objTransaction = objconn.BeginTransaction()
            strnow = Format(Now, "dd-MMM-yyyy HH:mm:ss")
            strnow1 = Format(Now, "yyyyMMddHHmm")
            strnow2 = Format(DateAdd(DateInterval.Minute, -3, Now), "yyyyMMddHHmm")
            GetRegMobileNo(puserid, objconn, objTransaction, strmobileno, strUserDOB, strBrcode, strerrormes)
            If strmobileno <> "" Then
                'If strUserDOB = "" Then
                strotp1 = GenerateRandomNumberPassword()
                'Else
                'strotp1 = strUserDOB
                'End If
                If (Len(o_Errmsg) = 0) Then
                    blnchk = False
                    strsql = "SELECT a.* FROM GENOTPDTLS a WHERE status = 'P' and userid = '" & puserid & "' AND mobileno = '" & strmobileno & "' AND TO_CHAR(senddatetime,'yyyyMMddhh24mi') between '" & strnow2 & "' and '" & strnow1 & "'"
                    objcmd = New OracleClient.OracleCommand(strsql, objconn)
                    objcmd.Transaction = objTransaction
                    dr = objcmd.ExecuteReader
                    If dr.HasRows = True Then
                        blnchk = True
                    Else
                        blnchk = False
                    End If

                    dr.Close()
                    dr = Nothing
                    objcmd.Dispose()
                    objcmd = Nothing


                    If blnchk = False Then
                        '' insert into genotpdtls
                        strsql = "insert into GENOTPDTLS(userid,mobileno,otpcode,senddatetime,status,machineid,systemdate) values('" & puserid & "','" & strmobileno & "','" & strotp1 & "', to_date('" & strnow & "','dd-Mon-yyyy HH24:mi:ss') ,'P','" & pmachineid & "',sysdate)"
                        objcmd = New OracleClient.OracleCommand(strsql, objconn)
                        objcmd.Transaction = objTransaction
                        cnt = objcmd.ExecuteNonQuery()

                        intfeatcd = 72
                        If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, objconn, objTransaction, dblminamt) = True Then

                            strarrmsgtags = strmsgtags.Split(",")
                            ' strarrmsgtags(0) --- <custom Message>

                            strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), strotp1)
                            strbuldmsg = strbuldmsg & " " & GetSMSBankName(objconn, objTransaction)
                            '' insert into smstranday
                            InsertGentranlogIntoSMSTranday(strBrcode, "INR", "", "", strotp1, "", 0, 0, strbuldmsg, strmobileno, pappdate, puserid, pmachineid, strsmstypeg, intfeatcd, objconn, objTransaction)
                            pstrmobileno = strmobileno
                            pstrmobilenodisplay = formatmobileno(strmobileno)
                        End If
                    End If
                End If ''(Len(o_Errmsg) = 0)
            End If
            objTransaction.Commit()
            Exit Function
        Catch ex As Exception
            objTransaction.Rollback()
            strerrormessage1 = ex.Message
        End Try
    End Function

    Private Function formatmobileno(ByVal pstrmobileno As String) As String

        formatmobileno = "XXXXXXX" & Right(pstrmobileno, 3)


    End Function
    Protected Sub InsertGentranlogIntoSMSTranday(ByVal strpbrcd As String, ByVal strpcurcd As String, ByVal strpmodid As String, ByVal strpglcd As String, ByVal strpaccno As String, ByVal strmodeoftran As String, ByVal intbatchno As Integer, ByVal inttranno As Integer, ByVal strpbuldmsg As String, ByVal strpcustmobile As String, ByVal strpappldate As String, ByVal strpuid As String, ByVal strpmacid As String, ByVal strpsmstypeg As String, ByVal intpfeatcd As Integer, ByRef objconn1 As OracleConnection, ByRef objTransaction1 As OracleClient.OracleTransaction)
        Dim sqlstrgenins As String
        Dim cmdsmsgenins As OracleCommand

        Try

            sqlstrgenins = "insert into smstranday(SMSID, BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, " & _
            " ACCNO,MODEOFTRAN,BATCHNO, TRANNO, MESSAGE, MOBILENO, SENTYN, APPLICATIONDATE, USERID, " & _
            " MACHINEID,SMSTYPE,featurecode,SYSTEMDATE) values(SEQSMSID.nextval,'" & strpbrcd & "'," & _
            "'" & strpcurcd & "','" & strpmodid & "','" & strpglcd & "'," & _
            "'" & strpaccno & "','" & strmodeoftran & "'," & intbatchno & "," & inttranno & ",'" & strpbuldmsg & "','" & strpcustmobile & "','N'," & _
            "'" & Format(CDate(strpappldate), "dd-MMM-yyyy") & "','" & strpuid & "'," & _
            "'" & strpmacid & "','" & strpsmstypeg & "'," & intpfeatcd & ",to_date('" & Format(datenow.Now, "dd-MMM-yyyy HH:mm:ss") & "', 'dd-Mon-yyyy HH24:Mi:ss'))"

            cmdsmsgenins = New OracleClient.OracleCommand(sqlstrgenins, objconn1)
            cmdsmsgenins.Transaction = objTransaction1
            cmdsmsgenins.ExecuteNonQuery()

            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing

            Exit Sub
        Catch ex As Exception

            cmdsmsgenins.Dispose()
            cmdsmsgenins = Nothing
        End Try
    End Sub

    Public Sub GetRegMobileNo(ByVal puserid As String, ByRef objconn1 As OracleConnection, ByRef objTransaction1 As OracleClient.OracleTransaction, ByRef pMobileno As String, ByRef pUserDOB As String, ByRef pBRANCHCODE As String, ByRef strerror As String)
        Try

            pMobileno = ""
            pUserDOB = ""

            If (Len(o_Errmsg) = 0) Then
                strsql = "select MOBILENO,userdob,BRANCHCODE from genusermst where userid = '" & puserid & "'"
                objcmd = New OracleClient.OracleCommand(strsql, objconn1)
                objcmd.Transaction = objTransaction1
                dr = objcmd.ExecuteReader
                If dr.HasRows = True Then
                    dr.Read()
                    pMobileno = IIf(IsDBNull(dr!MOBILENO), "", dr!MOBILENO)
                    If IsDBNull(dr!userdob) = True Then
                        pUserDOB = ""
                    Else
                        pUserDOB = Format(CDate(dr!userdob), "ddMMyy")
                    End If
                    pBRANCHCODE = IIf(IsDBNull(dr!BRANCHCODE), "", dr!BRANCHCODE)
                End If
            End If
            dr.Close()
            dr = Nothing
            objcmd.Dispose()
            objcmd = Nothing

            Exit Sub
        Catch ex As Exception
            strerror = ex.Message
        End Try
    End Sub

    Protected Function GetParameterDetails(ByVal intfeatcd1 As Integer, ByRef strmsgtags As String, ByRef strcustmessage As String, ByRef strtrantypeg As String, ByRef strsmstypeg As String, ByRef strmode1 As String, ByRef intdays As Integer, ByRef strschtype As String, ByRef dtschdate As Date, ByRef objconn1 As OracleConnection, ByRef objTransaction1 As OracleClient.OracleTransaction, Optional ByRef dblminamt As Double = 0) As Boolean
        Dim strsqlfeat As String
        Dim cmdsmsfeat As OracleCommand
        Dim drsmsfeat As OracleDataReader

        Try
            strmsgtags = ""
            strcustmessage = ""
            strtrantypeg = ""
            strsmstypeg = ""
            strmode1 = ""
            intdays = 0
            strschtype = ""
            dblminamt = 0

            strsqlfeat = "select nvl(m.messagetags,'') MESSAGETAGS, nvl(s.CUSTOMERMESSAGE,'') CUSTOMERMESSAGE, s.TRANTYPE, s.SMSTYPE,s.mode1,s.days,s.schtype,nvl(s.nextpushdate,s.schday) schday,s.minamt from smstypemst s , smsfeaturemst m   where s.featurecode = m.featurecode and m.activeyn = 'Y' and s.featurecode =" & intfeatcd1

            cmdsmsfeat = New OracleClient.OracleCommand(strsqlfeat, objconn1)
            cmdsmsfeat.Transaction = objTransaction1
            drsmsfeat = cmdsmsfeat.ExecuteReader()
            If drsmsfeat.Read() Then
                strmsgtags = drsmsfeat!MESSAGETAGS.ToString
                strcustmessage = drsmsfeat!CUSTOMERMESSAGE.ToString
                strtrantypeg = drsmsfeat!TRANTYPE.ToString
                strsmstypeg = IIf(IsDBNull(drsmsfeat!SMSTYPE), "", drsmsfeat!SMSTYPE.ToString)
                strmode1 = IIf(IsDBNull(drsmsfeat!mode1), "", drsmsfeat!mode1.ToString)
                intdays = IIf(IsDBNull(drsmsfeat!days), 0, drsmsfeat!days.ToString)
                strschtype = IIf(IsDBNull(drsmsfeat!schtype), "", drsmsfeat!schtype.ToString)
                If IsDBNull(drsmsfeat!schday) Then
                Else
                    dtschdate = drsmsfeat!schday.ToString
                End If
                dblminamt = IIf(IsDBNull(drsmsfeat!minamt), 0, drsmsfeat!minamt.ToString)

                GetParameterDetails = True
                cmdsmsfeat.Dispose()
                cmdsmsfeat = Nothing
                drsmsfeat.Close()
                drsmsfeat = Nothing
                Exit Function
            Else
                GetParameterDetails = False
                Exit Function
            End If

            Exit Function
        Catch ex As Exception

            cmdsmsfeat.Dispose()
            cmdsmsfeat = Nothing
            drsmsfeat.Close()
            drsmsfeat = Nothing
        End Try
    End Function


    Public Function CheckValidateOTP(ByVal puserid As String, ByVal mobileno As String, ByVal otp As String, ByRef strErrorMessage As String)

        Dim otpcode As String
        Dim sendatetime As Date
        Dim now1 As Date
        Dim diffminutes As Integer
        Dim result As String
        Dim cnt As Integer
        Try


            now1 = DateTime.Now
            objconn = objDBConnection.GetDbConnection(o_Errmsg)
            strsql = "select otpcode,senddatetime from genotpdtls  where status = 'P' and  userid = '" & puserid & "' and mobileno = '" & mobileno & "' and otpcode = '" & otp & "' and senddatetime = (select max(senddatetime) from genotpdtls where  status = 'P' and userid = '" & puserid & "' and mobileno = '" & mobileno & "'   )"
            objcmd = New OracleClient.OracleCommand(strsql, objconn)
            dr = objcmd.ExecuteReader()
            If dr.HasRows = True Then
                dr.Read()
                otpcode = dr!otpcode
                sendatetime = dr!senddatetime

                diffminutes = DateDiff(DateInterval.Minute, sendatetime, now1)
                If (diffminutes <= 10) Then  '' 3 hrs
                    result = "Success"
                    '' status = 'A'  Accepted
                    strsql = "update genotpdtls set recdatetime = to_date('" & Format(now1, "dd-MMM-yyyy HH:mm:ss") & "','dd-Mon-yyyy HH24:mi:ss'), status = 'A' where userid ='" & puserid & "' and mobileno ='" & mobileno & "' and otpcode = '" & otpcode & "' and senddatetime = to_Date('" & Format(sendatetime, "dd-MMM-yyyy HH:mm:ss") & "','dd-Mon-yyyy HH24:mi:ss')"
                    objcmd = New OracleCommand(strsql, objconn)
                    cnt = objcmd.ExecuteNonQuery()
                Else
                    result = "Expired"
                    '' status = 'R' Rejected
                    strsql = "update genotpdtls set recdatetime = to_date('" & Format(now1, "dd-MMM-yyyy HH:mm:ss") & "','dd-Mon-yyyy HH24:mi:ss'), status = 'R' where userid ='" & puserid & "' and mobileno ='" & mobileno & "' and otpcode = '" & otpcode & "' and senddatetime = to_Date('" & Format(sendatetime, "dd-MMM-yyyy HH:mm:ss") & "','dd-Mon-yyyy HH24:mi:ss')"
                    objcmd = New OracleCommand(strsql, objconn)
                    cnt = objcmd.ExecuteNonQuery()
                End If
            Else
                result = "Fail"
            End If
            CheckValidateOTP = result
            Exit Function
        Catch ex As Exception
            strErrorMessage = ex.Message
        End Try
    End Function

    Public Function CheckValidateOTPDblAuth(ByVal puserid As String, ByVal otp As String, ByRef strErrorMessage As String)
        Dim sendatetime As Date
        Dim now1 As Date
        Dim diffminutes As Integer
        Dim result As String
        Dim cnt As Integer
        Try
            objconn = objDBConnection.GetDbConnection(o_Errmsg)
            strsql = "SELECT otpcode FROM genautheticationcode WHERE userid =  '" & puserid & "'"
            objcmd = New OracleClient.OracleCommand(strsql, objconn)
            dr = objcmd.ExecuteReader()
            If dr.HasRows = True Then
                dr.Read()
                If dr!otpcode = otp Then
                    result = "Success"
                Else
                    result = "Fail"
                End If
            End If
            CheckValidateOTPDblAuth = result
            Exit Function
        Catch ex As Exception
            strErrorMessage = ex.Message
        End Try
    End Function

    Public Function ResendOTP(ByVal puserid As String, ByVal strmobileno As String, ByVal machineid As String, ByVal pappdate As String, ByRef strErrorMessage As String)

        Dim strotp As String
        Dim sendatetime As Date
        Dim now1 As Date
        Dim diffminutes As Integer
        Dim result As String
        Dim cnt As Integer
        Dim dr1 As OracleDataReader
        Dim resendcnt As Integer
        Dim strnow As String
        Dim strotpmessage, strbuldmsg As String
        Dim intfeatcd As Integer
        Dim strarrmsgtags(10) As String
        Dim strmobilenodisplay As String
        strnow = Format(Now, "dd-MMM-yyyy HH:mm:ss")


        strmobilenodisplay = formatmobileno(strmobileno)
        Try
            now1 = DateTime.Now
            objconn = objDBConnection.GetDbConnection(o_Errmsg)

            objTransaction = objconn.BeginTransaction()
            strsql = "select otpcode,senddatetime from genotpdtls where status = 'P' and userid = '" & puserid & "' and mobileno = '" & strmobileno & "'  and senddatetime = (select max(senddatetime) from genotpdtls where status = 'P' and  userid = '" & puserid & "' and mobileno = '" & strmobileno & "')"
            objcmd = New OracleClient.OracleCommand(strsql, objconn)
            objcmd.Transaction = objTransaction
            dr = objcmd.ExecuteReader()
            If dr.HasRows = True Then
                dr.Read()
                strotp = dr!otpcode
                sendatetime = dr!senddatetime

                diffminutes = DateDiff(DateInterval.Minute, sendatetime, now1)
                If (diffminutes <= 10) Then
                    strsql = "select nvl(max(resendtimes),0)+1 resendcnt from GENRESENDOTPDTLS where userid = '" & puserid & "' and mobileno = '" & strmobileno & "' and otpcode = '" & strotp & "'"

                    objcmd = New OracleCommand(strsql, objconn)
                    objcmd.Transaction = objTransaction
                    dr1 = objcmd.ExecuteReader()
                    If dr1.HasRows = True Then

                        dr1.Read()
                        resendcnt = dr1!resendcnt

                        If (resendcnt <= 2) Then
                            strsql = "insert into GENRESENDOTPDTLS(userid,mobileno,otpcode,resenddatetime,resendtimes) values('" & puserid & "','" & strmobileno & "','" & strotp & "', to_date('" & strnow & "','dd-Mon-yyyy HH24:mi:ss') ," & resendcnt & ")"
                            objcmd = New OracleCommand(strsql, objconn)
                            objcmd.Transaction = objTransaction
                            cnt = objcmd.ExecuteNonQuery()

                            If cnt <> 0 Then
                                intfeatcd = 0
                                If GetParameterDetails(intfeatcd, strmsgtags, strcustmessage, strtrantypeg, strsmstypeg, strmode1, intdays, strschtype, dtschdate, objconn, objTransaction, dblminamt) = True Then

                                    strarrmsgtags = strmsgtags.Split(",")
                                    ' strarrmsgtags(0) --- <custom Message>

                                    ''  strotpmessage = "Resend Login OTP " & strotp


                                    strbuldmsg = strcustmessage.Replace(strarrmsgtags(0), strotp).Replace(strarrmsgtags(1), strotp)
                                    strbuldmsg = strbuldmsg & " " & GetSMSBankName(objconn, objTransaction)

                                    '' insert into smstranday
                                    InsertGentranlogIntoSMSTranday("101", "INR", "", "", strotp, "", 0, 0, strbuldmsg, strmobileno, pappdate, puserid, machineid, strsmstypeg, intfeatcd, objconn, objTransaction)

                                    result = "Sent" & "~" & strmobileno & "~" & strmobilenodisplay
                                End If
                            Else
                                result = "Failed To ReSend OTP" & "~" & strmobileno & "~" & strmobilenodisplay
                            End If ''cnt <> 0 
                        Else
                            result = "ReSend OTP Exceeds More Than Two Times" & "~" & strmobileno & "~" & strmobilenodisplay
                        End If ''(resendcnt <= 2)
                    Else
                        result = "Failed To ReSend OTP" & "~" & strmobileno & "~" & strmobilenodisplay
                    End If ''dr1.HasRows = True
                Else
                    result = "ReSend OTP Exceeds 10 Minutes" & "~" & strmobileno & "~" & strmobilenodisplay
                End If ''(diffminutes <= 10)
            Else
                result = "Failed To ReSend OTP" & "~" & strmobileno & "~" & strmobilenodisplay
            End If ''dr.HasRows = True
            ResendOTP = result
            objTransaction.Commit()
            Exit Function
        Catch ex As Exception
            objTransaction.Rollback()
            strErrorMessage = ex.Message
        End Try
    End Function

    Private Function GetSMSBankName(ByRef objconn1 As OracleConnection, ByRef objTransaction1 As OracleClient.OracleTransaction) As String
        Try
            Dim strSMSBankName1 As String = ""
            strsql = "select smsbankname from SMSPARAMETERS"
            objcmd = New OracleClient.OracleCommand(strsql, objconn1)
            objcmd.Transaction = objTransaction1
            dr = objcmd.ExecuteReader()
            If dr.HasRows = True Then
                dr.Read()
                strSMSBankName1 = IIf(IsDBNull(dr!smsbankname), "", dr!smsbankname.ToString)
            End If
            GetSMSBankName = strSMSBankName1
            objcmd.Dispose()
            objcmd = Nothing
            dr.Close()
            dr = Nothing
            Exit Function
        Catch ex As Exception

        End Try
    End Function
End Class
