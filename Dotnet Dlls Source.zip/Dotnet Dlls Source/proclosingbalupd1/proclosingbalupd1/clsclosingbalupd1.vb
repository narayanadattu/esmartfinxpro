Public Class clsclosingbalupd1
    Dim objErrlog As Object
    Public ConnError As String 'error string
    Dim Rstemp As OracleClient.OracleDataReader
    Dim objdblink As Object
    Dim objError As Object
    Dim objTrans As Object
    Dim ICount As Integer
    Dim DataLink As String
    Dim ArrLink As Object
    Dim StrCondition As String
    Dim ConnTime As String
    Dim BrCode As String
    Dim MachID As String
    Dim Userid As String
    Dim arrerr As Object
    Dim errobj As Object
    'Dim objContext As ObjectContext
    Dim strComponent As String
    Dim clntDesc As String
    Const blnDebug As Boolean = True
    Dim ArrError As Object
    Dim ErrNum As String
    Dim errDesc As String
    Dim strstack As String
    Public objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim objtran As OracleClient.OracleTransaction
    Dim errmsg As String
    Dim objCmd As New OracleClient.OracleCommand

    Public Function UpdateClosingBalances(ByVal strBranchCode As String, ByVal strCurrcd As String, ByVal strmodid As String, _
    ByVal strglcode As String, ByVal straccno As String, ByVal dtfrmdate As Date, ByVal dtApplicationDate As Date, Optional ByVal strDayTran As String = "") As String
        Try


            Dim strsql As String
            Dim amt As Double
            Dim dblamttmp As Double
            Dim strupd As String
            Dim strtable As String
            Dim strtablebal As String
            Dim intreccnt As Integer
            Dim dbltempbal As Double
            dbltempbal = 0
            Dim Dstemp As New DataSet
            Dim DAtemp As New OracleClient.OracleDataAdapter
            Dim i As Integer
            'Set objContext = GetObjectContext
            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            If Trim(strDayTran) = "" Or Trim(strDayTran) = "TRAN" Then
                strtable = strmodid & "TRAN"
            ElseIf Trim(strDayTran) = "TRANDAY" Then
                strtable = strmodid & "TRANDAY"
                dtfrmdate = dtApplicationDate
            End If

            strtablebal = strmodid & "BALANCE"
            ConnError = ""

            Dim rsbal As OracleClient.OracleDataReader
            Dim strbal As String
            Dim dblbal As Double
            Dim dbldyaendbal As Double
            Dim updRowCnt As Integer
            dblbal = 0
            objtran = objconn.BeginTransaction()

            strbal = "select nvl(curbal,0) curbal  from " & strtablebal & " where accno ='" & straccno & "' and " & _
            " glcode ='" & strglcode & "' and branchcode ='" & strBranchCode & "' and " & _
            " currencycode = '" & strCurrcd & "'"

            objCmd = New OracleClient.OracleCommand(strbal, objconn)
            objCmd.Transaction = objtran
            rsbal = objCmd.ExecuteReader()

            If rsbal.HasRows = True Then
                rsbal.Read()
                dbltempbal = rsbal!curbal
            End If

            rsbal.Close()
            rsbal = Nothing

            If Trim(strDayTran) = "TRANDAY" Then
                strbal = "SELECT  SUM(AMOUNT) Daybal FROM " & strtable & _
                " WHERE ACCNO='" & straccno & "' AND GLCODE='" & strglcode & "' AND BRANCHCODE='" & strBranchCode & "'"

                objCmd = New OracleClient.OracleCommand(strbal, objconn)
                objCmd.Transaction = objtran
                rsbal = objCmd.ExecuteReader()

                If rsbal.HasRows = True Then
                    rsbal.Read()
                    dbltempbal = dbltempbal + rsbal!Daybal
                End If
                rsbal.Close()
                rsbal = Nothing
            End If


            strsql = "SELECT branchcode,currencycode,glcode,accno,nvl(amount,0) amount, NVL(dayendbal,0) Balance " & _
            " ,applicationdate,remarks,modeoftran,chqno,batchno,tranno,Chqfvg,NVL(MSTNO,1) mstno " & _
            " FROM " & strtable & " WHERE BRANCHCODE='" & strBranchCode & "' AND currencycode = '" & strCurrcd & "' and " & _
            " GLCODE='" & strglcode & "' AND  accno='" & straccno & "' AND " & _
            "APPLICATIONDATE >= TO_DATE('" & Format(dtfrmdate, "dd-MMM-yyyy") & "','dd-Mon-yyyy') AND " & _
            " APPLICATIONDATE<=TO_DATE('" & Format(dtApplicationDate, "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
            " ORDER BY   APPLICATIONDATE DESC,NVL(mstno,1) DESC,batchno DESC ,tranno DESC"

            objCmd = New OracleClient.OracleCommand(strsql, objconn)
            objCmd.Transaction = objtran
            DAtemp = New OracleClient.OracleDataAdapter(objCmd)
            DAtemp.Fill(Dstemp)
            objCmd.Dispose()
            objCmd = Nothing


            If Dstemp.Tables(0).Rows.Count > 0 Then

                intreccnt = 0
                intreccnt = Dstemp.Tables(0).Rows.Count
                If intreccnt > 0 Then
                    dbldyaendbal = dbltempbal
                    strupd = "update " & strtable & " set dayendbal = " & dbldyaendbal & " where " & _
                                  " BRANCHCODE='" & Dstemp.Tables(0).Rows(0)("BranchCode") & "' AND currencycode = '" & Dstemp.Tables(0).Rows(0)("CURRENCYCODE") & "' and " & _
                                  " GLCODE='" & Dstemp.Tables(0).Rows(0)("GlCode") & "' AND  accno='" & Dstemp.Tables(0).Rows(0)("accno") & "' AND " & _
                                  " APPLICATIONDATE=TO_DATE('" & Format(Dstemp.Tables(0).Rows(0)("ApplicationDate"), "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
                                   " and batchno = " & Dstemp.Tables(0).Rows(0)("batchno") & " and tranno = " & Dstemp.Tables(0).Rows(0)("tranno")

                    objCmd = New OracleClient.OracleCommand(strupd, objconn)
                    objCmd.Transaction = objtran
                    updRowCnt = objCmd.ExecuteNonQuery()
                    objCmd.Dispose()
                    objCmd = Nothing

                    dblamttmp = 0
                    dblamttmp = Dstemp.Tables(0).Rows(0)("amount")

                    For i = 1 To Dstemp.Tables(0).Rows.Count - 1
                        amt = 0
                        dbldyaendbal = 0
                        If dblamttmp < 0 Then

                            amt = Math.Abs(dblamttmp)
                            dbldyaendbal = dbltempbal + amt

                        ElseIf dblamttmp > 0 Then

                            amt = dblamttmp
                            dbldyaendbal = dbltempbal - amt

                        End If

                        strupd = "update " & strtable & " set dayendbal = " & dbldyaendbal & " where " & _
                           " BRANCHCODE='" & Dstemp.Tables(0).Rows(i)("BranchCode") & "' AND currencycode = '" & Dstemp.Tables(0).Rows(i)("CURRENCYCODE") & "' and " & _
                           " GLCODE='" & Dstemp.Tables(0).Rows(i)("GlCode") & "' AND  accno='" & Dstemp.Tables(0).Rows(i)("accno") & "' AND " & _
                           " APPLICATIONDATE=TO_DATE('" & Format(Dstemp.Tables(0).Rows(i)("ApplicationDate"), "dd-MMM-yyyy") & "' ,'dd-Mon-yyyy')" & _
                           " and batchno = " & Dstemp.Tables(0).Rows(i)("batchno") & " and tranno = " & Dstemp.Tables(0).Rows(i)("tranno")

                        dbltempbal = dbldyaendbal
                        objCmd = New OracleClient.OracleCommand(strupd, objconn)
                        objCmd.Transaction = objtran
                        updRowCnt = objCmd.ExecuteNonQuery()
                        objCmd.Dispose()
                        objCmd = Nothing
                        dblamttmp = 0
                        dblamttmp = Dstemp.Tables(0).Rows(i)("amount")

                    Next i
                End If
            End If
            Dstemp.Dispose()
            Dstemp = Nothing

            UpdateClosingBalances = "Updation Successfull"
            'objContext.SetComplete
            objtran.Commit()

            Exit Function
        Catch ex As Exception
            objtran.Rollback()
            UpdateClosingBalances = ex.Message
        End Try
    End Function

End Class
