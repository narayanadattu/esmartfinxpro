Public Class tdsmarking
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String
    Dim drcustamt As OracleClient.OracleDataReader
    Dim strQuery As String
    Dim strmsttable As String
    Dim strcustid As String
    Dim dblamt As Double

    Dim strcrmod As String
    Dim strcrglcd As String
    Dim strcraccno As String
    Dim drtdsrates As OracleClient.OracleDataReader
    Dim objDBConnection1 As New DatabaseConnection.cDBConnection
    Dim gObjOracleConnection1 As New OracleClient.OracleConnection

    Public Function TDSMarking(ByVal BRCode As String, _
           ByVal CURCode As String, _
           ByVal arrVals(,) As Object, _
           ByVal ApplicationDate As Date, ByVal UserId As String, _
           ByVal MachineId As String, ByVal strtds As String, _
           ByVal strfrm15h As String, ByVal strfrm15g As String, _
           ByVal strnontds As String) As String

        'Desc: This is used to Calculate TDS
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code

        'ArrVals(Idx,0) = Includes customer ids for non tds to tds transfer and every customerid number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,1) = Includes glcodes for non tds to tds transfer and every glcodes
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,2) = Includes Account Numbers for non tds to tds transfer and every a/c number
        '                 are separated by "," (Comma Symbol)

        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TDSMarking = "Transaction Successfull"
        '   else
        '     TDSMarking = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection


        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand

        Dim sQuery, strAccNos, strform15h, strform15g, strAccStatus, dtResult, strBrcod As String
        Dim iNoOfRows As Long
        Dim expectedRowCnt, delRowCnt As Integer
        Dim accountArr As Object
        Dim form15hArr As Object
        Dim form15gArr As Object
        Dim AccStatusArr As Object
        Dim brcodcond As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String
        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames As String
        Dim strCustid, strGlcds As String
        Dim CustidArr, GlcdsArr, NamesArr, tdsArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            '''' STEP 1: Get DataBase Connection
            gObjOracleConnection1 = objDBConnection1.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                              " DataBase. Reason Is " & o_Errmsg)
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strCustid = arrVals(0, 0)
            strGlcds = arrVals(1, 0)
            strAccNos = arrVals(2, 0)
            strform15h = arrVals(3, 0)
            strform15g = arrVals(4, 0)
            strAccStatus = arrVals(5, 0)
            strBrcod = arrVals(6, 0)

            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.
            CustidArr = Split(strCustid, ",")
            GlcdsArr = Split(strGlcds, ",")
            accountArr = Split(strAccNos, ",")
            form15hArr = Split(strform15h, ",")
            form15gArr = Split(strform15g, ",")
            AccStatusArr = Split(strAccStatus, ",")
            brcodcond = Split(strBrcod, ",")

            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt

                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strform15h = form15hArr(iAdx)
                            strform15g = form15gArr(iAdx)
                            strAccStatus = AccStatusArr(iAdx)
                            strBrcod = brcodcond(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strform15h = strform15h & "," & form15hArr(iAdx)
                            strform15g = strform15g & "," & form15gArr(iAdx)
                            strAccStatus = strAccStatus & "," & AccStatusArr(iAdx)
                            strBrcod = strBrcod & "," & brcodcond(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strform15h = form15hArr(iAdx)
                            strform15g = form15gArr(iAdx)
                            strAccStatus = AccStatusArr(iAdx)
                            strBrcod = brcodcond(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strform15h = strform15h & "," & form15hArr(iAdx)
                            strform15g = strform15g & "," & form15gArr(iAdx)
                            strAccStatus = strAccStatus & "," & AccStatusArr(iAdx)
                            strBrcod = strBrcod & "," & brcodcond(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String
                arrVals(0, 0) = strCustid
                arrVals(1, 0) = strGlcds
                arrVals(2, 0) = strAccNos
                arrVals(3, 0) = strform15h
                arrVals(4, 0) = strform15g
                arrVals(5, 0) = strAccStatus
                arrVals(6, 0) = strBrcod

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 1 : Do TDS calculations to debit Operative GL A/c's and 
                '             Credit Gl A/C's

                opResult = doTDSMarking(BRCode, CURCode, _
                           arrVals, ApplicationDate, UserId, _
                           MachineId, strtds, strfrm15h, strfrm15g, strnontds, gObjOracleConnection, objTransaction)
                If opResult = False Then
                    Throw New Exception("Error While doing TDS Marking")
                End If

                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False
            gObjOracleConnection1.Close()
            gObjOracleConnection1 = Nothing

            TDSMarking = "Transaction Successful "

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                TDSMarking = ex.Message
                Exit Function
            Else

                strComponent = "BULKOPERATIONS.doTDSMarking / TDSMarking"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    TDSMarking = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    TDSMarking = clntDesc
                End If
                Exit Function
            End If

        End Try
    End Function


    Private Function doTDSMarking(ByVal i_BRcode As String, _
            ByVal i_CURCode As String, _
            ByVal arrOPData(,) As Object, ByVal ApplicationDate As Date, _
            ByVal UserId As String, ByVal MachineId As String, ByVal strtds As String, _
           ByVal strfrm15h As String, ByVal strfrm15g As String, _
           ByVal strnontds As String, ByRef gObjOracleConnection As OracleClient.OracleConnection, _
            ByRef objTransaction As OracleClient.OracleTransaction) As Boolean
        Dim strremarks As String
        Dim strtrnstatus As String
        ' This Function is used for Financial Transaction while Doing  
        ' TDS Calculation
        'INPUTS :
        'i_BRcode = Branch Code in which a/c's are existed
        'i_CURCode= Currency Code
        'i_ModId = Module Id; Generally it will be wether 'SB' or 'CA' or 'DEP' modules
        'i_DrGLCOde =  
        'i_CrGLCode =  
        'arrOPData(Idx,0) = Includes Customerid for non tds to tds transfer and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,1) = Includes glcodes of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'arrOPData(Idx,2) = Includes Account Numbers for non tds to tds transfer and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,3) = Includes form15H for non tds to tds transfer and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,4) = Includes form15G for non tds to tds transfer and every a/c number
        '                 is separated by "," (Comma Symbol)

        'ApplicationDate= Current Date of Application
        'UserId = Login UserId
        'MachineId= Login MachineId
        'gObjOracleConnection = Connection Object
        'objTransaction = Transaction Object

        Dim rsdepmst As OracleClient.OracleDataReader
        Dim objdbconnection = New DatabaseConnection.cDBConnection

        Dim genTransDrQry, sbtranDrQuery, genTransCrQry, sbtranCrQuery, i_Batchno, i_Tranno, FrmTranNo, FromTranNo As String
        Dim arrCustid, arrGlcds, arrAccNo, arrform15h, arrAccCustId, arrform15g, arrAccStatus, arrBrcod As Object
        Dim objCommand As OracleClient.OracleCommand
        Dim Idx As Long
        Dim genDrNoOfRows, sbTranDrNoOfRows, genCrNoOfRows, sbTranCrNoOfRows, tdsDtlsNoOfRows, depintaccrdtlsRows As Short
        Dim strtdsdtls, depintaccrQuery As String
        Dim strModid As String
        Dim strintcompyn As String
        Dim strcompintaccrrevyn As String
        Dim strintaccrglcd, strintaccraccno As String
        Dim strmiscname As String
        Dim straccrname As String
        Dim effecdate As Date
        Dim frmdate As Date
        Dim intcnt As Integer
        Dim frmdate1 As String
        Dim todate As String
        Dim strmon As String
        Dim stryear As String
        Dim assessyear As String
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'i_Batchno = GenTran.GetBatchno(i_BRcode)


        Try
            arrCustid = CStr(arrOPData(0, 0)).Split(",")
            arrGlcds = CStr(arrOPData(1, 0)).Split(",")
            arrAccNo = CStr(arrOPData(2, 0)).Split(",")
            arrform15h = CStr(arrOPData(3, 0)).Split(",")
            arrform15g = CStr(arrOPData(4, 0)).Split(",")
            arrAccStatus = CStr(arrOPData(5, 0)).Split(",")
            arrBrcod = CStr(arrOPData(6, 0)).Split(",")

            doTDSMarking = False

            strtrnstatus = ""

            strmon = Month(ApplicationDate)
            stryear = Year(ApplicationDate)

            If strmon <= 3 Then
                frmdate1 = Format(CDate("01-Apr-" & stryear - 1), "dd-MMM-yyyy")
                todate = Format(CDate("31-Mar-" & stryear), "dd-MMM-yyyy")
            Else
                frmdate1 = Format(CDate("01-Apr-" & stryear), "dd-MMM-yyyy")
                todate = Format(CDate("31-Mar-" & stryear + 1), "dd-MMM-yyyy")
            End If
            assessyear = Year(frmdate1) & Mid(Year(todate), 3)
            Dim strCurStatus, strNewStatus, strslno As String
            For Idx = 0 To UBound(arrAccNo)
                '' start for both running accounts and closed accounts
                strCurStatus = "" : strNewStatus = ""
                If strtds = "Y" Then
                    strNewStatus = "TDS"
                ElseIf strnontds = "Y" Then
                    strNewStatus = "NTDS"
                ElseIf strfrm15h = "Y" Then
                    strNewStatus = "15H"
                ElseIf strfrm15g = "Y" Then
                    strNewStatus = "15G"
                End If
                strtdsdtls = ""
                strtdsdtls = "SELECT CASE WHEN TDSYN = 'Y' THEN 'TDS' WHEN  EXMPFORMSRECYN = 'Y' THEN '15H' WHEN  FORMS15G = 'Y' THEN '15G' WHEN NONTDS ='Y' THEN 'NTDS' END mode1,TDSYN, EXMPFORMSRECYN, FORMS15G, NONTDS  FROM depmst WHERE status = 'R' and accno = " & arrAccNo(Idx) & " and glcode = " & arrGlcds(Idx) & " and customerid = " & arrCustid(Idx) & " and branchcode = " & arrBrcod(Idx) & " and currencycode = '" & i_CURCode & "'"
                objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                rsdepmst = objCommand.ExecuteReader()
                If rsdepmst.HasRows = True Then
                    rsdepmst.Read()
                    strCurStatus = rsdepmst!mode1
                End If

                strtdsdtls = ""
                strtdsdtls = "SELECT NVL(MAX(slno),0) +1 slno FROM tdsmarkinghist"
                objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                rsdepmst = objCommand.ExecuteReader()
                If rsdepmst.HasRows = True Then
                    rsdepmst.Read()
                    strslno = rsdepmst!slno
                End If

                strtdsdtls = ""
                strtdsdtls = "insert into tdsmarkinghist(SLNO, BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, CUSTOMERID, CURSTATUS, NEWSTATUS, EFFDATE, APPLICATIONDATE, USERID,MACHINEID,  SYSTEMDATE) values('" & strslno & "'," & arrBrcod(Idx) & " ,'" & i_CURCode & "','DEP'," & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & arrCustid(Idx) & ",'" & strCurStatus & "','" & strNewStatus & "', to_Date('" & Format(Now, "dd-MMM-yyyy HH:mm:ss ") & "','dd-Mon-yyyy HH24:MI:SS'), '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',sysdate)"

                objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                objCommand.Dispose()
                objCommand = Nothing

                strtdsdtls = ""
                strtdsdtls = "update depmst set tdsyn = '" & strtds & "', NONTDS='" & strnontds & "',EXMPFORMSRECYN='" & strfrm15h & "', FORMS15G='" & strfrm15g & "' where accno = " & arrAccNo(Idx) & " and glcode = " & arrGlcds(Idx) & " and customerid = " & arrCustid(Idx) & " and branchcode = " & arrBrcod(Idx) & " and currencycode = '" & i_CURCode & "'"

                objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                objCommand.Dispose()
                objCommand = Nothing
                '' end for both running accounts and closed accounts

                '' start -- only for running status
                If arrAccStatus(Idx) = "R" Then

                    If strfrm15h = "Y" Or strfrm15g = "Y" Then

                        strQuery = "SELECT count(*) cnt FROM FORM15GHTRACKINGDTLS WHERE accno = " & arrAccNo(Idx) & " and glcode = " & arrGlcds(Idx) & " and customerid = " & arrCustid(Idx) & " and branchcode = " & arrBrcod(Idx) & " and currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear

                        objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        drtdsrates = objCommand.ExecuteReader

                        If drtdsrates.HasRows = True Then
                            If drtdsrates.Read Then
                                intcnt = drtdsrates!cnt
                            End If
                        End If

                        objCommand.Dispose()
                        objCommand = Nothing
                        drtdsrates.Close()
                        drtdsrates = Nothing

                        If intcnt = 0 Then

                            objCommand = New OracleClient.OracleCommand("Insintoform15ghtrackingdtls", gObjOracleConnection)
                            objCommand.CommandType = CommandType.StoredProcedure
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pBrcode", OracleClient.OracleType.VarChar)).Value = Replace(arrBrcod(Idx), "'", "")
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pCurcode", OracleClient.OracleType.VarChar)).Value = i_CURCode.Trim
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pglcode", OracleClient.OracleType.VarChar)).Value = Replace(arrGlcds(Idx), "'", "")
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("paccno", OracleClient.OracleType.VarChar)).Value = Replace(arrAccNo(Idx), "'", "")
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pappdate", OracleClient.OracleType.DateTime)).Value = CDate(Format(ApplicationDate, "dd-MMM-yyyy"))
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pUserID", OracleClient.OracleType.VarChar)).Value = UserId
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pMachineID", OracleClient.OracleType.VarChar)).Value = MachineId
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("pMode", OracleClient.OracleType.VarChar)).Value = "U"
                            objCommand.Parameters.Add(New OracleClient.OracleParameter("errmsg", OracleClient.OracleType.VarChar, 100)).Direction = ParameterDirection.Output
                            objCommand.Transaction = objTransaction
                            objCommand.ExecuteNonQuery()

                            If IsDBNull(objCommand.Parameters("errmsg").Value) = False Then
                                If Trim(objCommand.Parameters("errmsg").Value) <> "" Then
                                    o_Errmsg = o_Errmsg & objCommand.Parameters("errmsg").Value
                                End If
                            End If

                            objCommand.Dispose()
                            objCommand = Nothing
                        End If ''intcnt = 0

                        If intcnt > 0 Then

                            strQuery = ""
                            strQuery = "SELECT ACCNO FROM FORM15GHTRACKINGDTLS WHERE customerid = " & arrCustid(Idx) & " and  TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear
                            objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                            objCommand.Transaction = objTransaction
                            drtdsrates = objCommand.ExecuteReader
                            objCommand.Dispose()
                            objCommand = Nothing

                            If drtdsrates.HasRows = True Then

                                strQuery = ""
                                strQuery = "INSERT INTO FORM15GHTRACKINGDTLSHIST SELECT *  from FORM15GHTRACKINGDTLS WHERE TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear

                                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                                objCommand.Transaction = objTransaction
                                objCommand.ExecuteNonQuery()

                                objCommand.Dispose()
                                objCommand = Nothing

                                strQuery = ""
                                strQuery = "UPDATE FORM15GHTRACKINGDTLS SET STATUS='R' , USERID='" & UserId & "' ,MACHINEID='" & MachineId & "' WHERE TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >= " & assessyear

                                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                                objCommand.Transaction = objTransaction
                                objCommand.ExecuteNonQuery()

                                objCommand.Dispose()
                                objCommand = Nothing

                            End If ''drtdsrates.HasRows = True
                        End If ''intcnt > 0
                    End If ''strfrm15h = "Y" Or strfrm15g = "Y" 


                    If strtds = "Y" Or strnontds = "Y" Then
                        If arrform15h(Idx) = "Y" Or arrform15g(Idx) = "Y" Then
                            strQuery = ""
                            strQuery = "SELECT ACCNO FROM FORM15GHTRACKINGDTLS WHERE customerid = " & arrCustid(Idx) & " and  TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear

                            objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                            objCommand.Transaction = objTransaction
                            drtdsrates = objCommand.ExecuteReader
                            objCommand.Dispose()
                            objCommand = Nothing

                            If drtdsrates.HasRows = True Then

                                strQuery = ""
                                strQuery = "INSERT INTO FORM15GHTRACKINGDTLSHIST SELECT *  from FORM15GHTRACKINGDTLS WHERE TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear

                                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                                objCommand.Transaction = objTransaction
                                objCommand.ExecuteNonQuery()

                                objCommand.Dispose()
                                objCommand = Nothing

                                strQuery = ""
                                strQuery = "UPDATE FORM15GHTRACKINGDTLS SET STATUS='D' , USERID='" & UserId & "' ,MACHINEID='" & MachineId & "' WHERE TRIM(ACCNO) = " & arrAccNo(Idx) & " AND TRIM(glcode) = " & arrGlcds(Idx) & " AND branchcode = " & arrBrcod(Idx) & " AND currencycode = '" & i_CURCode & "' and ASSESYEAR >=  " & assessyear
                                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection)
                                objCommand.Transaction = objTransaction
                                objCommand.ExecuteNonQuery()

                                objCommand.Dispose()
                                objCommand = Nothing

                            End If ''''drtdsrates.HasRows = True
                        End If  ''arrform15h(Idx) = "Y" Or arrform15g(Idx) = "Y"
                    End If   ''strtds = "Y" Or strnontds = "Y"

                End If ''arrAccStatus(Idx) = "R"
                '' end -- only for running status

                doTDSMarking = True
            Next

        Catch ex As Exception
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.doTDSMarking" & _
                               " / doTDSMarking"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Marking Due to " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

            Else
                errNum = "doTDSMark"
                errDesc = ex.Message
                clntDesc = "Error ! while Doing TDS Marking " & errDesc

            End If

            Dim objError As New DatabaseConnection.ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
            clntDesc, o_Errmsg, strComponent, i_BRcode, UserId, MachineId)
            doTDSMarking = False
        End Try
    End Function
End Class
