Module ModGeneral

    Public Function getITformCode(ByVal strCustomerid As String, ByVal pappdate As Date, ByRef gObjOracleConnection1 As OracleClient.OracleConnection, ByVal objTransaction1 As OracleClient.OracleTransaction, ByRef strError As String) As String
        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand
        Dim pcustdob As String
        Dim intage As Integer
        Dim sno As Integer
        Dim strtofindate As Date
        Dim strcusttype As String
        Try
            strtofindate = getprvFinToDate(pappdate)
            strsql = ""
            strsql = "SELECT CUSTDOB,CUSTOMERTYPE  FROM gencustinfomst where customerid =" & strCustomerid & ""

            objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
            objcom.Transaction = objTransaction1
            rsacc = objcom.ExecuteReader

            If rsacc.HasRows = True Then
                If rsacc.Read Then
                    strcusttype = IIf(IsDBNull(rsacc!CUSTOMERTYPE), "", rsacc!CUSTOMERTYPE)
                    If IsDBNull(rsacc!CUSTDOB) = True Then
                        pcustdob = ""
                    Else
                        pcustdob = rsacc!CUSTDOB
                    End If
                End If
            End If
            If strcusttype = "1" Or strcusttype = "2" Or strcusttype = "3" Or strcusttype = "9" Then
                intage = DateDiff(DateInterval.Year, CDate(pcustdob), strtofindate)
                If intage >= 60 Then
                    sno = 3
                ElseIf pcustdob = "" Then
                    sno = 4
                Else
                    sno = 4
                End If
            Else
                sno = 4
            End If
            objcom.Dispose()
            objcom = Nothing
            rsacc.Close()
            rsacc = Nothing
            getITformCode = getITformITCode(sno, gObjOracleConnection1, objTransaction1)
        Catch ex As Exception
            strError = ex.Message
        End Try
    End Function
    Private Function getITformITCode(ByVal psno As Integer, ByRef gObjOracleConnection1 As OracleClient.OracleConnection, ByVal objTransaction1 As OracleClient.OracleTransaction) As String
        Dim rsacc1 As OracleClient.OracleDataReader
        Dim objcom1 As OracleClient.OracleCommand
        Dim strsql, strITCode As String
        Try
            strsql = "SELECT itcode FROM genitformcode WHERE sno = " & psno & ""
            objcom1 = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
            objcom1.Transaction = objTransaction1
            rsacc1 = objcom1.ExecuteReader

            If rsacc1.HasRows = True Then
                If rsacc1.Read Then
                    strITCode = IIf(IsDBNull(rsacc1!itcode), "", rsacc1!itcode)
                End If
            End If


            objcom1.Dispose()
            objcom1 = Nothing
            rsacc1.Close()
            rsacc1 = Nothing
            getITformITCode = strITCode
        Catch ex As Exception

        End Try
    End Function
    Private Function getprvFinToDate(ByVal AppDate As Date) As Date
        Dim strmon As String
        Dim stryear As String


        Dim todate As String
        Try

            strmon = Month(AppDate)
            stryear = Year((AppDate))

            If strmon <= 3 Then

                todate = Format(CDate("31-Mar-" & stryear - 1), "dd-MMM-yyyy")
            Else

                todate = Format(CDate("31-Mar-" & stryear), "dd-MMM-yyyy")
            End If ''strmon <= 3
            getprvFinToDate = CDate(todate)
        Catch ex As Exception

        End Try
    End Function
End Module
