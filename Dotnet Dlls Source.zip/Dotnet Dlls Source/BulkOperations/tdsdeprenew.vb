
Public Class tdsdeprenew
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String
    Dim drcustamt As OracleClient.OracleDataReader
    Dim drtdsmaxdt As OracleClient.OracleDataReader
    Dim strQuery As String
    Dim strmsttable As String
    Dim strcustid As String
    Dim dblamt As Double
    Dim dbltdsamt As Double
    Dim strcrmod As String
    Dim strcrglcd As String
    Dim strcraccno As String
    Dim drtdsrates As OracleClient.OracleDataReader
    Dim objDBConnection1 As New DatabaseConnection.cDBConnection
    Dim gObjOracleConnection1 As New OracleClient.OracleConnection
    Public objfetch As Object

    Public sDrIntModId, sDrIntGlCode, sDrIntAccNo As String
    Public sCrIntModId, sCrIntGlCode, sCrIntAccNo As String
    Public sIntAccrModId, sIntAccrGlCode, sIntAccrAccNo As String

    Public Function TDSdeprenewal(ByVal BRCode As String, _
              ByVal CURCode As String, ByVal frmfinyr As Date, ByVal tofinyr As Date, _
              ByVal arrVals(,) As Object, _
              ByVal ApplicationDate As Date, ByVal UserId As String, _
              ByVal MachineId As String, ByVal strmode As String, ByVal assessyear As Integer) As String

        'Desc: This is used to Calculate TDS
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code

        'ArrVals(Idx,0) = Includes customer ids for TDS Dep Renewal and every customerid number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,1) = Includes glcodes for TDS Dep Renewal and every glcodes
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,2) = Includes Account Numbers for TDS Dep Renewal and every a/c number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,3) = Includes Names of the Account holders respectively and these
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,4) = Includes category code of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,5) = Includes tds to be applied of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,6) = Includes int accr of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TDSdeprenewal = "Transaction Successfull"
        '   else
        '     TDSdeprenewal = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection


        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand

        Dim sQuery, strAccNos, dtResult As String
        Dim iNoOfRows As Long
        Dim expectedRowCnt, delRowCnt As Integer
        Dim accountArr As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String



        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames, strAcctds, strintaccr, strcatcode As String
        Dim strCustid, strGlcds As String
        Dim CustidArr, GlcdsArr, NamesArr, tdsArr, intaccrArr, catcodeArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            '''' STEP 1: Get DataBase Connection
            gObjOracleConnection1 = objDBConnection1.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                              " DataBase. Reason Is " & o_Errmsg)
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strCustid = arrVals(0, 0)
            strGlcds = arrVals(1, 0)
            strAccNos = arrVals(2, 0)
            strAccNames = arrVals(3, 0)
            strcatcode = arrVals(4, 0)
            strAcctds = arrVals(5, 0)
            strintaccr = arrVals(6, 0)

            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.
            CustidArr = Split(strCustid, ",")
            GlcdsArr = Split(strGlcds, ",")
            accountArr = Split(strAccNos, ",")
            NamesArr = Split(strAccNames, ",")
            catcodeArr = Split(strcatcode, ",")
            tdsArr = Split(strAcctds, ",")
            intaccrArr = Split(strintaccr, ",")

            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt

                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strcatcode = catcodeArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                            strintaccr = intaccrArr(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strcatcode = strcatcode & "," & catcodeArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                            strintaccr = strintaccr & "," & intaccrArr(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strcatcode = catcodeArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                            strintaccr = intaccrArr(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strcatcode = strcatcode & "," & catcodeArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                            strintaccr = strintaccr & "," & intaccrArr(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String
                arrVals(0, 0) = strCustid
                arrVals(1, 0) = strGlcds
                arrVals(2, 0) = strAccNos
                arrVals(3, 0) = strAccNames
                arrVals(4, 0) = strcatcode
                arrVals(5, 0) = strAcctds
                arrVals(6, 0) = strintaccr

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 1 : Do TDS calculations to debit Operative GL A/c's and 
                '             Credit Gl A/C's

                opResult = doTDSdeprenewal(BRCode, CURCode, frmfinyr, tofinyr, _
                           arrVals, ApplicationDate, UserId, _
                           MachineId, gObjOracleConnection, objTransaction, _
                           returnBatchNo, rtnFromTranno, rtnToTranno, strmode, assessyear)

                If opResult = False Then

                    Throw New Exception("Error While doing TDS Dep Renewal" & _
                        " to Debit  GL A/C's and Credit GL A/C's")
                End If



                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False
            gObjOracleConnection1.Close()
            gObjOracleConnection1 = Nothing

            TDSdeprenewal = "Transaction Successful" & " Batch No.(s)  " & returnBatchNo

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                TDSdeprenewal = ex.Message
                Exit Function
            Else

                strComponent = "BULKOPERATIONS.TDSDEPRENEWAL / TDSdeprenewal"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Dep Renewal " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    TDSdeprenewal = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    TDSdeprenewal = clntDesc
                End If
                Exit Function
            End If
        End Try
    End Function

    Private Function doTDSdeprenewal(ByVal i_BRcode As String, _
          ByVal i_CURCode As String, ByVal frmfinyr As Date, _
          ByVal tofinyr As Date, _
          ByVal arrOPData(,) As Object, ByVal ApplicationDate As Date, _
          ByVal UserId As String, ByVal MachineId As String, _
          ByRef gObjOracleConnection As OracleClient.OracleConnection, _
          ByRef objTransaction As OracleClient.OracleTransaction, _
          ByRef o_BatchNo As String, ByRef o_FromTranNo As String, _
          ByRef o_ToTranNo As String, ByVal strmode As String, ByVal assessyear As Integer) As Boolean
        Dim strremarks As String
        Dim strremarkstds As String
        Dim strtrnstatus As String

        Dim strErrorMessage, stritform As String
        ' This Function is used for Financial Transaction while Doing  
        ' TDS Dep Renewal
        'INPUTS :
        'i_BRcode = Branch Code in which a/c's are existed
        'i_CURCode= Currency Code
        'i_ModId = Module Id; Generally it will be wether 'SB' or 'CA' or 'DEP' modules
        'i_DrGLCOde =  
        'i_CrGLCode =  
        'arrOPData(Idx,0) = Includes customer ids for TDS Dep Renewal and every customerid number
        '                 are separated by "," (Comma Symbol)
        'arrOPData(Idx,1) = Includes glcodes for TDS Dep Renewal and every glcodes
        '                 are separated by "," (Comma Symbol)
        'arrOPData(Idx,2) = Includes Account Numbers for TDS Dep Renewal and every a/c number
        '                 are separated by "," (Comma Symbol)
        'arrOPData(Idx,3) = Includes Names of the Account holders respectively and these
        '                 are separated by "," (Comma Symbol)
        'arrOPData(Idx,4) = Includes category code of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'arrOPData(Idx,5) = Includes tds to be applied of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'arrOPData(Idx,6) = Includes int accr of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)


        'ApplicationDate= Current Date of Application
        'UserId = Login UserId
        'MachineId= Login MachineId
        'gObjOracleConnection = Connection Object
        'objTransaction = Transaction Object


        Dim objdbconnection = New DatabaseConnection.cDBConnection

        Dim genTransDrQry, sbtranDrQuery, genTransCrQry, sbtranCrQuery, i_Batchno, i_Tranno, FrmTranNo, FromTranNo As String
        Dim arrCustid, arrGlcds, arrAccNo, arrAccName, arrAccCustId, arrAccBal, arrIntAccr, arrCatCode As Object
        Dim objCommand As OracleClient.OracleCommand
        Dim Idx As Long
        Dim pltranDrQuery, genTransDrQrypl, iagenTransCrQry, iatranCrQuery, depintacCreditQuery As String
        Dim genDrNoOfRows, sbTranDrNoOfRows, genCrNoOfRows, sbTranCrNoOfRows, tdsDtlsNoOfRows, depintaccrdtlsRows As Short
        Dim genDrNoOfRowspl, plTranDrNoOfRows, iagenTransCrOfRows, iatranCrRows, depintacCreditRows As Short
        Dim strtdsdtls, depintaccrQuery As String
        Dim strintcompyn As String
        Dim strcompintaccrrevyn As String
        Dim strintaccrglcd, strintaccraccno As String
        Dim strmiscname As String
        Dim straccrname As String
        Dim effecdate As Date
        Dim frmdate As Date
        Dim sDrAccName As String
        Dim dblDrAccBal As Double
        Dim sDrGlDesc As String
        Dim sDrModDesc As String

        Dim rsintaccno As Object
        Dim sTableCols As String
        Dim strcustid1 As String

        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'i_Batchno = GenTran.GetBatchno(i_BRcode)
        i_Batchno = objdbconnection.GetBatchno(i_BRcode)
        Try

            arrCustid = CStr(arrOPData(0, 0)).Split(",")
            arrGlcds = CStr(arrOPData(1, 0)).Split(",")
            arrAccNo = CStr(arrOPData(2, 0)).Split(",")
            arrAccName = CStr(arrOPData(3, 0)).Split(",")
            arrCatCode = CStr(arrOPData(4, 0)).Split(",")
            arrAccBal = CStr(arrOPData(5, 0)).Split(",")
            arrIntAccr = CStr(arrOPData(6, 0)).Split(",")

            doTDSdeprenewal = False

            strtrnstatus = ""
            If strmode = "All" Then
                strtrnstatus = "A"
            Else
                strtrnstatus = "P"
            End If

            For Idx = 0 To UBound(arrAccNo)
                i_Tranno = objdbconnection.GetTranNo(i_BRcode)
                If Idx = 0 Then
                    FromTranNo = i_Tranno
                Else
                    i_Tranno = i_Tranno
                End If

                sDrIntAccNo = ""
                sCrIntAccNo = ""
                sDrIntGlCode = ""
                sCrIntGlCode = ""
                sIntAccrGlCode = ""
                sIntAccrAccNo = ""

                strQuery = "select G.INTDEBITACCNO,G.INTCREDITACCNO,INTDEBITGLCODE, INTCREDITGLCODE from DEPTYPEMST G where G.GLCODE=" & arrGlcds(Idx) & ""

                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                rsintaccno = objCommand.ExecuteReader
                objCommand.Dispose()
                objCommand = Nothing

                If rsintaccno.HasRows = True Then
                    If rsintaccno.Read Then
                        sDrIntAccNo = IIf(IsDBNull(rsintaccno!INTDEBITACCNO), "", rsintaccno!INTDEBITACCNO)
                        sCrIntAccNo = IIf(IsDBNull(rsintaccno!INTCREDITACCNO), "", rsintaccno!INTCREDITACCNO)
                        sDrIntGlCode = IIf(IsDBNull(rsintaccno!INTDEBITGLCODE), "", rsintaccno!INTDEBITGLCODE)
                        sCrIntGlCode = IIf(IsDBNull(rsintaccno!INTCREDITGLCODE), "", rsintaccno!INTCREDITGLCODE)

                        'Get Module id of Required Gl Codes
                        Call GetModuleID(sDrIntGlCode, sDrIntModId)
                        Call GetModuleID(sCrIntGlCode, sCrIntModId)
                    End If
                End If
                rsintaccno.Close()
                rsintaccno = Nothing
                dblDrAccBal = 0

                '                Call GetAccDetails(i_BRcode, i_CURCode, sDrIntModId, sDrIntGlCode, sDrIntAccNo, sDrAccName)
                ''    Call GetAccBalance(i_BRcode, i_CURCode, sDrIntModId, sDrIntGlCode, sDrIntAccNo, dblDrAccBal)

                sDrGlDesc = GetGLDesc(sDrIntGlCode)
                sDrModDesc = GetModuleDesc(sDrIntModId)

                strcrmod = ""
                strcrglcd = ""
                strcraccno = ""
                strmiscname = ""
                strQuery = ""

                strQuery = "SELECT DISTINCT CREDITMODULEID, CREDITGLCODE, CREDITACCNO,(select distinct name from miscmst where branchcode = '" & i_BRcode & "' AND glcode =  r.CREDITGLCODE and accno = r.CREDITACCNO) miscname FROM tdsparm r , DEPMST m  " & _
                " WHERE r.category  =  m.categorycode AND (r.category = m.categorycode OR r.category = 99) " & _
                " AND r.category = " & arrCatCode(Idx) & " AND " & _
                " m.branchcode = '" & i_BRcode & "' AND m.currencycode = '" & i_CURCode & "' AND r.effectivedate " & _
                " = (SELECT MAX(r.effectivedate) FROM tdsparm r ,DEPMST m WHERE r.category  = m.categorycode AND " & _
                " (r.category = m.categorycode OR r.category = 99 AND " & _
                " r.effectivedate <= '" & Format(ApplicationDate, "dd-MMM-yyyy") & "') AND " & _
                " r.category = " & arrCatCode(Idx) & " AND  m.branchcode = '" & i_BRcode & "' AND m.currencycode " & _
                " = '" & i_CURCode & "'  AND r.effectivedate <= '" & Format(ApplicationDate, "dd-MMM-yyyy") & "')"

                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                drtdsrates = objCommand.ExecuteReader

                If drtdsrates.HasRows = True Then
                    If drtdsrates.Read Then
                        strcrmod = IIf(IsDBNull(drtdsrates!CREDITMODULEID), "", drtdsrates!CREDITMODULEID)
                        strcrglcd = IIf(IsDBNull(drtdsrates!CREDITGLCODE), "", drtdsrates!CREDITGLCODE)
                        strcraccno = IIf(IsDBNull(drtdsrates!CREDITACCNO), "", drtdsrates!CREDITACCNO)
                        strmiscname = IIf(IsDBNull(drtdsrates!miscname), "", drtdsrates!miscname)
                    End If
                Else
                    doTDSdeprenewal = "Parameters Not Set For This Gl Code And Module ID"
                    Exit Function
                End If

                objCommand.Dispose()
                objCommand = Nothing
                drtdsrates.Close()
                drtdsrates = Nothing


                strQuery = ""
                strQuery = "SELECT EFFDATE FROM depmst m WHERE " & _
                " branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  " & _
                " glcode = " & arrGlcds(Idx) & " AND accno = " & arrAccNo(Idx) & ""

                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                drcustamt = objCommand.ExecuteReader
                If drcustamt.HasRows = True Then
                    If drcustamt.Read Then
                        effecdate = drcustamt!EFFDATE
                    End If
                End If
                objCommand.Dispose()
                objCommand = Nothing
                drcustamt.Close()
                drcustamt = Nothing

                '' start from date 
                '' if record present then frmdate = max(toddate)+1
                strQuery = ""
                strQuery = "SELECT accno FROM TDSDTLS WHERE branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  glcode = " & arrGlcds(Idx) & " And accno = " & arrAccNo(Idx) & ""

                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                drcustamt = objCommand.ExecuteReader
                If drcustamt.HasRows = True Then
                    If drcustamt.Read Then

                        strQuery = ""
                        strQuery = "SELECT MAX(todate)+1 maxdate FROM TDSDTLS WHERE branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  glcode = " & arrGlcds(Idx) & " And accno = " & arrAccNo(Idx) & ""

                        objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                        drtdsmaxdt = objCommand.ExecuteReader
                        If drtdsmaxdt.HasRows = True Then
                            If drtdsmaxdt.Read Then
                                frmdate = drtdsmaxdt!maxdate
                            End If
                        End If

                        drtdsmaxdt.Close()
                        drtdsmaxdt = Nothing
                        strremarkstds = "Pending TDS Collected For Dep Closing From " & Format(frmdate, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")
                    End If
                Else
                    '' if record does not present 
                    '' if effective date < fin yr then frmdate = frmfinyr
                    If CDate(effecdate) < CDate(frmfinyr) Then
                        frmdate = frmfinyr
                        '' if effective date >= fin yr and effecdate  <= tofinyr
                        '' frmdate = effective date 
                    ElseIf CDate(effecdate) >= CDate(frmfinyr) And effecdate <= tofinyr Then
                        frmdate = effecdate
                    End If
                    strremarkstds = "TDS From " & Format(frmfinyr, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")
                End If
                objCommand.Dispose()
                objCommand = Nothing
                drcustamt.Close()
                drcustamt = Nothing

                'frmdate = frmfinyr
                '' end to get from date 


                '' start deptypemst

                strQuery = ""
                strintaccrglcd = ""
                strintaccraccno = ""
                strintcompyn = ""
                strcompintaccrrevyn = ""
                straccrname = ""
                strQuery = "SELECT GLCODE, NARRATION, INTCOMPOUNDYN, INTACCRUEDGLCODE, INTACCRUEDACCNO, COMPINTACCRREVSEYN,(select distinct name from miscmst where glcode =  INTACCRUEDGLCODE and accno = INTACCRUEDACCNO) miscname FROM deptypemst WHERE glcode =  " & arrGlcds(Idx) & ""
                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                drcustamt = objCommand.ExecuteReader
                If drcustamt.HasRows = True Then
                    If drcustamt.Read Then
                        strintaccrglcd = IIf(IsDBNull(drcustamt!INTACCRUEDGLCODE), "", drcustamt!INTACCRUEDGLCODE)
                        strintaccraccno = IIf(IsDBNull(drcustamt!INTACCRUEDACCNO), "", drcustamt!INTACCRUEDACCNO)
                        strintcompyn = IIf(IsDBNull(drcustamt!INTCOMPOUNDYN), "", drcustamt!INTCOMPOUNDYN)
                        strcompintaccrrevyn = IIf(IsDBNull(drcustamt!COMPINTACCRREVSEYN), "", drcustamt!COMPINTACCRREVSEYN)
                        straccrname = IIf(IsDBNull(drcustamt!miscname), "", drcustamt!miscname)
                    End If
                Else
                    strintaccrglcd = ""
                    strintaccraccno = ""
                    strintcompyn = ""
                    strcompintaccrrevyn = ""
                    straccrname = ""
                End If

                objCommand.Dispose()
                objCommand = Nothing
                drcustamt.Close()
                drcustamt = Nothing

                '' end deptypemst

                strmsttable = "DEPMST"
                strQuery = ""
                strQuery = "SELECT customerid,GETANYDAYBAL(BRANCHCODE, CURRENCYCODE,'DEP', GLCODE " & _
                ", ACCNO,'" & Format(ApplicationDate, "dd-MMM-yyyy") & "') curbal  FROM " & strmsttable & " WHERE " & _
                " branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  " & _
                " glcode = " & arrGlcds(Idx) & " AND accno = " & arrAccNo(Idx) & ""

                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)

                drcustamt = objCommand.ExecuteReader

                If drcustamt.HasRows = True Then
                    While drcustamt.Read
                        strcustid1 = drcustamt!customerid
                        dblamt = drcustamt!curbal
                    End While
                End If

                objCommand.Dispose()
                objCommand = Nothing
                drcustamt.Close()
                drcustamt = Nothing


                If ((strintcompyn <> "N" And strcompintaccrrevyn = "N")) Then
                    strremarks = "TDS From " & Format(frmfinyr, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")
                    'Debit A/C balance into Debit Gl Code WITH SAME A/C NUMBER
                    genTransDrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                         " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                         " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                         " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                         " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                         " '" & i_CURCode & "','DEP'," & _
                         " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                         " '" & i_Batchno & "','" & i_Tranno & "'," & _
                         " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                         " '" & strcustid1 & "'," & _
                         " " & arrAccName(Idx) & ",'N','Y','" & strremarks & "'," & _
                         " '1','N'," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                         " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                         " sysdate,'" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & ")"


                    sbtranDrQuery = "insert into DEPTRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','DEP'," & _
                      "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & strcustid1 & "'," & _
                      " " & arrAccName(Idx) & ",'N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & ")"

                    stritform = getITformCode("'" & CStr(strcustid1) & "'", ApplicationDate, gObjOracleConnection, objTransaction, strErrorMessage)
                    strtdsdtls = "insert into tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME, BATCHNO, " & _
                    " TRANNO, AMOUNT,MODEOFTRAN, FROMDATE, TODATE, USERID, MACHINEID,applicationdate,SYSTEMDATE,TRANSTATUS, STATUS, " & _
                    " REMARKS, LNKMODULEID, LNKGLCODE, LNKACCNO,customerid,ASSESYEAR,ITFORM) values('" & i_BRcode & "'," & _
                        " '" & i_CURCode & "','DEP'," & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                        " " & arrAccName(Idx) & ",'" & i_Batchno & "','" & i_Tranno & "'," & _
                        " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3','" & Format(frmdate, "dd-MMM-yyyy") & "','" & _
                        " " & Format(tofinyr, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                        "'" & MachineId & "','" & Format(ApplicationDate, "dd-MMM-yyyy") & "',sysdate,'A','R','" & strremarkstds & "','" & strcrmod & "'," & _
                       "'" & strcrglcd & "'," & strcraccno & " ,'" & strcustid1 & "'," & assessyear & ",'" & stritform & "')"

                    i_Tranno = objdbconnection.GetTranNo(i_BRcode)


                    'CREDIT A/C BALANCE INTO CREDIT GL CODE WITH SAME A/C NUMBER
                    genTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                        " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                       " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                       " '" & i_CURCode & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & "," & _
                       " '" & i_Batchno & "','" & i_Tranno & "'," & _
                       " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                       " '','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                       " '1','N'," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                       " sysdate,'DEP'," & _
                       "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                    sbtranCrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','" & strcrmod & "'," & _
                      " '" & strcrglcd & "'," & strcraccno & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                      " '1','N','" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','DEP'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                    objCommand = New OracleClient.OracleCommand(genTransDrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranDrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(genTransCrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranCrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    If genDrNoOfRows <> 1 Or sbTranDrNoOfRows <> 1 Or tdsDtlsNoOfRows <> 1 Or _
             genCrNoOfRows <> 1 Or sbTranCrNoOfRows <> 1 Then
                        Throw New Exception("Error ! : while doing TDS Calculations")
                    End If
                End If  ''((strintcompyn <> "N" And strcompintaccrrevyn = "N") )


                '' simple
                If ((strintcompyn <> "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "N")) Then

                    strremarks = "TDS From " & Format(frmfinyr, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")

                    If CDbl(arrIntAccr(Idx)) < 0 Then
                        ''pl 
                        dbltdsamt = Math.Round(CDbl(arrAccBal(Idx)))
                    ElseIf CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx)) Then
                        dbltdsamt = Math.Round(CDbl(arrAccBal(Idx)) - CDbl(arrIntAccr(Idx)))
                    End If

                    If (arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx))) Then
                        'start Debit pltranday

                        genTransDrQrypl = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                               " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                              " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                              " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                              " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                              " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                              " '" & i_CURCode & "','" & sDrIntModId & "'," & _
                              " '" & sDrIntGlCode & "'," & sDrIntAccNo & "," & _
                              " '" & i_Batchno & "','" & i_Tranno & "'," & _
                              " " & -1 * dbltdsamt & ",'3'," & dblamt & "," & _
                              " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','','N','Y','" & strremarks & "'," & _
                              " '1','N'," & _
                              " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                              " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                              " sysdate,'DEP'," & _
                            " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                        pltranDrQuery = "insert into " & sDrIntModId & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                          " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                          " SYSTEMGENERATEDYN," & _
                          " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                          " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                          " '" & i_CURCode & "','" & sDrIntModId & "'," & _
                          " '" & sDrIntGlCode & "'," & sDrIntAccNo & "," & _
                          " '" & i_Batchno & "','" & i_Tranno & "'," & _
                          " " & -1 * dbltdsamt & ",'3'," & dblamt & "," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','','N','Y','" & strremarks & "'," & _
                          " '1','N'," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','DEP'," & _
                           " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                        'end Debit pltranday

                        i_Tranno = objdbconnection.GetTranNo(i_BRcode)

                        '' start credit  Int accr 

                        iagenTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                        " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                       " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                       " '" & i_CURCode & "','" & strcrmod & "'," & _
                       " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                       " '" & i_Batchno & "','" & i_Tranno & "'," & _
                       " " & dbltdsamt & ",'4'," & dblamt & "," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                       " '1','N'," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                       " sysdate,'DEP'," & _
                     " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                        iatranCrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                          " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                          " SYSTEMGENERATEDYN," & _
                          " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                          " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                          " '" & i_CURCode & "','" & strcrmod & "'," & _
                          " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                          " '" & i_Batchno & "','" & i_Tranno & "'," & _
                          " " & dbltdsamt & ",'4'," & dblamt & "," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                          " '1','N'," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','DEP'," & _
                           " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                        '' depintaccrueddtls

                        depintacCreditQuery = "insert into DEPINTACCRUEDDTLS(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, INTAMOUNT," & _
                "BATCHNO, TRANNO,APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
                "SYSTEMYEAR, INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO" & _
                ",PAIDBATCHNO, PAIDTRANNO, TRANSFERTODEP,REMARKS,LNKMODULEID, LNKGLCODE, LNKACCNO) values('" & i_BRcode & "'," & _
                          "'" & i_CURCode & "','DEP'," & _
                          "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & dbltdsamt & "," & _
                          "'" & i_Batchno & "','" & i_Tranno & "'," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "',sysdate, to_char(sysdate,'yyyy')," & _
                          "'" & strcrmod & "','" & strintaccrglcd & "'," & strintaccraccno & "," & _
                          "'" & i_Batchno & "','" & i_Tranno & "'," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','" & strremarkstds & "'," & _
                          "'" & strcrmod & "','" & strcrglcd & "'," & strcraccno & ")"


                        '' end credit  Int accr 
                        i_Tranno = objdbconnection.GetTranNo(i_BRcode)
                    End If  ''(arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx)))


                    'Debit A/C balance into Debit Gl Code WITH SAME A/C NUMBER
                    genTransDrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                         " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                         " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                         " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                         " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                         " '" & i_CURCode & "','" & strcrmod & "'," & _
                         " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                         " '" & i_Batchno & "','" & i_Tranno & "'," & _
                         " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                         " '1','N'," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                         " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                         " sysdate,'DEP'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                    sbtranDrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','" & strcrmod & "'," & _
                      " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','DEP'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                    stritform = getITformCode("'" & CStr(strcustid1) & "'", ApplicationDate, gObjOracleConnection, objTransaction, strErrorMessage)
                    strtdsdtls = "insert into tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME, BATCHNO, " & _
                    " TRANNO, AMOUNT,MODEOFTRAN, FROMDATE, TODATE, USERID, MACHINEID,applicationdate,SYSTEMDATE,TRANSTATUS, STATUS, " & _
                    " REMARKS, LNKMODULEID, LNKGLCODE, LNKACCNO,customerid,ASSESYEAR,ITFORM) values('" & i_BRcode & "'," & _
                        " '" & i_CURCode & "','DEP'," & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                        " " & arrAccName(Idx) & ",'" & i_Batchno & "','" & i_Tranno & "'," & _
                        " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3','" & Format(frmdate, "dd-MMM-yyyy") & "','" & _
                        " " & Format(tofinyr, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                        "'" & MachineId & "','" & Format(ApplicationDate, "dd-MMM-yyyy") & "',sysdate,'A','R','" & strremarkstds & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & " ,'" & strcustid1 & "'," & assessyear & ",'" & stritform & "')"

                    '' depintaccrueddtls

                    depintaccrQuery = "insert into DEPINTACCRUEDDTLS(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, INTAMOUNT," & _
            "BATCHNO, TRANNO,APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
            "SYSTEMYEAR, INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO" & _
            ",PAIDBATCHNO, PAIDTRANNO, TRANSFERTODEP,REMARKS,LNKMODULEID, LNKGLCODE, LNKACCNO) values('" & i_BRcode & "'," & _
                      "'" & i_CURCode & "','DEP'," & _
                      "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & -1 * Math.Round(CDbl(arrAccBal(Idx))) & "," & _
                      "'" & i_Batchno & "','" & i_Tranno & "'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "',sysdate, to_char(sysdate,'yyyy')," & _
                      "'" & strcrmod & "','" & strintaccrglcd & "'," & strintaccraccno & "," & _
                      "'" & i_Batchno & "','" & i_Tranno & "'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','" & strremarkstds & "'," & _
                      "'" & strcrmod & "','" & strcrglcd & "'," & strcraccno & ")"


                    i_Tranno = objdbconnection.GetTranNo(i_BRcode)

                    'CREDIT A/C BALANCE INTO CREDIT GL CODE WITH SAME A/C NUMBER

                    genTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                        " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                       " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                       " '" & i_CURCode & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & "," & _
                       " '" & i_Batchno & "','" & i_Tranno & "'," & _
                       " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                       " '1','N'," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                       " sysdate,'DEP'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                    sbtranCrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','" & strcrmod & "'," & _
                      " '" & strcrglcd & "'," & strcraccno & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                      " '1','N','" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','DEP'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                    If (arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx))) Then

                        objCommand = New OracleClient.OracleCommand(genTransDrQrypl, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        genDrNoOfRowspl = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(pltranDrQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        plTranDrNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(iagenTransCrQry, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        iagenTransCrOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(iatranCrQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        iatranCrRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(depintacCreditQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        depintacCreditRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing
                    End If  '''(arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx)))

                    objCommand = New OracleClient.OracleCommand(genTransDrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranDrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(depintaccrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    depintaccrdtlsRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(genTransCrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranCrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    If (arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx))) Then
                        If genDrNoOfRowspl <> 1 Or plTranDrNoOfRows <> 1 Or iagenTransCrOfRows <> 1 Or _
                                    iatranCrRows <> 1 Or depintacCreditRows <> 1 Then
                            Throw New Exception("Error ! : while doing TDS Dep Renewel pl ")
                        End If
                    End If  ''(arrIntAccr(Idx) < 0) Or (CDbl(arrIntAccr(Idx)) < CDbl(arrAccBal(Idx)))

                    If genDrNoOfRows <> 1 Or sbTranDrNoOfRows <> 1 Or tdsDtlsNoOfRows <> 1 Or _
            depintaccrdtlsRows <> 1 Or genCrNoOfRows <> 1 Or sbTranCrNoOfRows <> 1 Then
                        Throw New Exception("Error ! : while doing TDS Dep Renewel")
                    End If

                End If ''((strintcompyn <> "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "N"))

                doTDSdeprenewal = True

            Next
            'o_BatchNo = i_Batchno
            If oBatchNo = "" Then
                oBatchNo = i_Batchno
            Else
                oBatchNo = oBatchNo & " , " & i_Batchno
            End If

            o_BatchNo = oBatchNo
            o_FromTranNo = FromTranNo
            o_ToTranNo = i_Tranno
        Catch ex As Exception
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.TDSDEPRENEWAL" & _
                               " / doTDSdeprenewal"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Dep Renewal Due to " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

            Else
                errNum = "doTDSrenw"
                errDesc = ex.Message
                clntDesc = "Error ! while Doing TDS Dep Renewal " & errDesc

            End If

            Dim objError As New DatabaseConnection.ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
            clntDesc, o_Errmsg, strComponent, i_BRcode, UserId, MachineId)
            doTDSdeprenewal = False
        End Try
    End Function

    Private Sub GetModuleID(ByVal i_sGlCode As String, ByRef o_sModuleId As String)
        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand

        strsql = ""
        strsql = "select distinct(G.MODULEID) MODULEID,G.NARRATION,M.NARRATION from GENGLSHEETMST G,GENMODULEMST M where G.GLCODE='" & UCase(Trim(i_sGlCode)) & "' AND G.MODULEID=M.MODULEID"

        objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
        rsacc = objcom.ExecuteReader

        If rsacc.HasRows = True Then
            If rsacc.Read Then
                o_sModuleId = IIf(IsDBNull(rsacc!MODULEID), "", rsacc!MODULEID)
            End If
        End If
        objcom.Dispose()
        objcom = Nothing
        rsacc.Close()
        rsacc = Nothing
    End Sub
    Private Function GetGLDesc(ByVal i_sGlCode As String) As String
        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand

        strsql = ""
        strsql = "select gldescription from GENGLMASTMST where GLCODE='" & UCase(Trim(i_sGlCode)) & "'"

        objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
        rsacc = objcom.ExecuteReader

        If rsacc.HasRows = True Then
            If rsacc.Read Then
                GetGLDesc = IIf(IsDBNull(rsacc!gldescription), "", rsacc!gldescription)
            End If
        End If
        objcom.Dispose()
        objcom = Nothing
        rsacc.Close()
        rsacc = Nothing
    End Function

    Private Function GetModuleDesc(ByVal i_sModCode As String) As String
        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand

        strsql = ""
        strsql = "select narration from GENMODULEMST where moduleid='" & UCase(Trim(i_sModCode)) & "'"

        objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
        rsacc = objcom.ExecuteReader

        If rsacc.HasRows = True Then
            If rsacc.Read Then
                GetModuleDesc = IIf(IsDBNull(rsacc!narration), "", rsacc!narration)
            End If
        End If
        objcom.Dispose()
        objcom = Nothing
        rsacc.Close()
        rsacc = Nothing
    End Function

    Private Sub GetAccDetails(ByVal i_sBrCode As String, ByVal i_sCurCode As String, _
        ByVal i_sModCode As String, ByVal i_sGlCode As String, ByVal i_sAccNo As String, _
        ByRef o_sName As String, Optional ByRef O_sCustomerid As String = "")

        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand

        strsql = ""
        strsql = "select name,CUSTOMERID from " & Trim(i_sModCode) & "MST  where branchcode='" & i_sBrCode & "' AND currencycode='" & i_sCurCode & "' AND glcode='" & i_sGlCode & "' AND accno = '" & i_sAccNo & "'"

        objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
        rsacc = objcom.ExecuteReader

        If rsacc.HasRows = True Then
            If rsacc.Read Then
                o_sName = IIf(IsDBNull(rsacc!name), "", rsacc!name)
                O_sCustomerid = IIf(IsDBNull(rsacc!CUSTOMERID), "", rsacc!CUSTOMERID)
            End If
        End If
        objcom.Dispose()
        objcom = Nothing
        rsacc.Close()
        rsacc = Nothing
    End Sub
End Class
