'*******************************************************************************
'*********************************************************************************
'*	Name Of the File : Preparing dll for BulkOperations                          *
'*	Purpose	  	     : This dll is used To Transfer the A/c.s Operative to       *
'*                     Inopeartive                                               *
'*			                                            			             *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| V.Anil Kumar         |    01-jun-2007   |   3.1      |		                 |    '|                      |                  |            |                        |    
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'*********************************************************************************
'*********************************************************************************

Public Class SBCAOperations
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String

    Dim strCommServ, strCommMod, strCommGl, strCommGlDesc, strCommAcc, strCommAmt, strCGSTMod, strCGSTGl, strCGSTGlDesc, strCGSTAcc, strGSTPercent, strCessPercent, strSGSTMod, strSGSTGl, strSGSTGlDesc, strSGSTAcc, strCESSMod, strCESSGl, strCESSGlDesc, strCESSAcc, strEffDate, strGSTAmt, strCESSAmt, strCGSTAmt, strSGSTAmt, strAutoPostCharges, errmsg, strBatchNo, strTranNoDr, strTranNoCmCr, strTranNoCGSTCr, strTranNoSGSTCr, strTranNoCESSCr, commYN, GSTYN, CessYN, strSql As String
    Dim strTaxableVal As String
    Dim dblComm, dblSrv, totDrAmt As Double
    Dim nonCustomerid As String
    Dim objDr As OracleClient.OracleDataReader
    Dim objDr1 As OracleClient.OracleDataReader
    Dim objCmd As New OracleClient.OracleCommand
    Dim objconn As New OracleClient.OracleConnection
    Dim ObjDbCOnnection As New DatabaseConnection.cDBConnection
    Dim StrInsert, strTranCols, strRemarksDr, strRemarksCr, strChqFvg As String
    Dim dblDrcharges As Double
    Dim dblTotDrcharges As Double
    Dim dblGSTamt As Double
    Dim dblCESSamt As Double
    Dim dblTotGSTamt As Double
    Dim dblTotCESSamt As Double
    Dim retCGSTcnt As Integer
    Dim retSGSTcnt As Integer
    Dim retCESScnt As Integer
    Dim strPOS As String
    Dim strGSTCustomerid As String
    Dim strRcpName As String
    Dim strGSTIN As String
    Dim strInvoiceNo As String
    Public Function TransferOperativeToInoperative(ByVal BRCode As String, _
          ByVal CURCode As String, ByVal MODId As String, _
          ByVal GLCode As String, ByVal arrVals(,) As Object, _
          ByVal CutOffDt As Date, ByVal InOperGLCode As String, _
          ByVal ApplicationDate As Date, ByVal UserId As String, _
          ByVal MachineId As String) As String

        'Desc: This is used to transfer Operative A/C's as Inpoerative A/C's
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'SB' or 'CA' modules
        'GLCode = Operative Gl Code
        'ArrVals(Idx,0) = Includes Account Numbers to trasfer and every a/c number
        '                 is separated by "," (Comma Symbol)
        'ArrVals(Idx,0) = Includes Names of the Account holders respectively and these
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,0) = Includes CustomerIDs of the Account holders respectively 
        '                 and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,0) = Includes Current Balances of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'CutOffDt = CutoffDate to identify Inoperate A/C's
        'InOperGLCode = Inoperative GLCODE for the Respective Operative GLCODE
        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TransferOperativeToInoperative = "Transaction Successfull"
        '   else
        '     TransferOperativeToInoperative = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim existCond, strInsertCond, strUpdateCond, strBulkInsertCond As String
        Dim strinsertcondsbbal
        Dim sQuery, strAccNos, dtResult As String
        Dim iNoOfRows As Long, sMstTable As String, sBalanceTable As String
        Dim expectedRowCnt, delRowCnt As Integer, delRowCntc As Integer
        Dim accountArr As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strObjHist, returnMsg As String
        Dim rowsEffectedcnt As Integer
        Dim fldnames As String
        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames, strAccCustIds, strAccBals As String
        Dim NamesArr, custidArr, balArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strAccNos = arrVals(0, 0)
            strAccNames = arrVals(1, 0)
            strAccCustIds = arrVals(2, 0)
            strAccBals = arrVals(3, 0)

            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.
            accountArr = Split(strAccNos, ",")
            NamesArr = Split(strAccNames, ",")
            custidArr = Split(strAccCustIds, ",")
            balArr = Split(strAccBals, ",")


            sMstTable = Trim(MODId) & "MST"
            sBalanceTable = Trim(MODId) & "BALANCE"

            ''''' STEP 1: Get DataBase Connection
            'gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
            'If Trim(o_Errmsg) <> "" Then
            '    'TransferOperativeToInoperative = "Connection Failed With" & _
            '    '                                 " DataBase. Reason Is " & o_Errmsg
            '    'Exit Function
            '    Throw New Exception("Connection Failed With" & _
            '                                     " DataBase. Reason Is " & o_Errmsg)
            'End If
            'bConnOpened = True

            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt
               
                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strAccCustIds = custidArr(iAdx)
                            strAccBals = balArr(iAdx)
                        Else
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strAccCustIds = strAccCustIds & "," & custidArr(iAdx)
                            strAccBals = strAccBals & "," & balArr(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strAccCustIds = custidArr(iAdx)
                            strAccBals = balArr(iAdx)
                        Else
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strAccCustIds = strAccCustIds & "," & custidArr(iAdx)
                            strAccBals = strAccBals & "," & balArr(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                '''' STEP 2 : Check Whether data is with Running status in SBMST 
                '''           While Transfering the A/c. To Inoperative..
                sQuery = "select nvl(count(*),0) from " & sMstTable & " where" & _
                      " trim(upper(branchcode))='" & UCase(BRCode) & "' and" & _
                      " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                    " and glcode='" & GLCode & "' and trim(ACCNO) in(" & strAccNos & _
                        ") and STATUS='R'"
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                iNoOfRows = objcommand.ExecuteScalar

                'If iNoOfRows = 0 Then
                'If iNoOfRows <> (UBound(accountArr) + 1) Then

                If UBoundValue = 0 Then
                    UBoundValue = UBound(accountArr) + 1
                End If

                If iNoOfRows <> UBoundValue Then
                    Throw New Exception("All the Given Accounts were not found in its Master table with Running Status, to Transfer them as Inoperative Accs")
                End If

                expectedRowCnt = iNoOfRows

                ' STEP 3 : Preparing the Conditions  
                ' (i)   to check whether same data exists with InoperativeGlCode
                ' (ii)  to Insert data
                ' (iii) to Update data             

                existCond = "trim(upper(branchcode))='" & UCase(BRCode) & "' and" & _
                            " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                            " and glcode='" & InOperGLCode & "' and" & _
                            " trim(ACCNO) in(" & strAccNos & ")"

                strInsertCond = "trim(upper(branchcode))='" & UCase(BRCode) & "' and" & _
                        " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                        " and glcode='" & GLCode & "' and" & _
                        " trim(ACCNO) in(" & strAccNos & ") and status='R'"

                strinsertcondsbbal = "trim(upper(branchcode))='" & UCase(BRCode) & "' and" & _
                        " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                        " and glcode='" & GLCode & "' and" & _
                        " trim(ACCNO) in(" & strAccNos & ")"

                strBulkInsertCond = "trim(upper(branchcode))='" & UCase(BRCode) & "' and" & _
                         " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                         " and glcode='" & GLCode & "' and" & _
                         " trim(ACCNO) in(" & strAccNos & ")"

                strUpdateCond = strInsertCond

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 4.2 : check whether data is existing in Master table with
                '''          InoperativeGlcode. If Exists, delete it
                sQuery = "select nvl(count(*),0) from " & sMstTable & _
                         " where " & existCond
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                iNoOfRows = objcommand.ExecuteScalar

                If iNoOfRows > 0 Then

                    '' Before deleting the data from Master Table
                    '' Move the data to History Table
                    fldnames = ""
                    objHist.recordInHist(sMstTable, fldnames, _
                      gObjOracleConnection, objTransaction, returnMsg, _
                      rowsEffectedcnt, strUpdateCond, BRCode, _
                      UserId, MachineId, ApplicationDate)

                    If returnMsg <> "" Then
                        Throw New Exception(returnMsg)
                    End If
                    'If rowsEffectedcnt <> iNoOfRows Then
                    '    Throw New Exception("Unable Move the data into History Table")
                    'End If

                    sQuery = "delete from " & sBalanceTable & " where " & existCond
                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                                                 gObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    delRowCntc = objcommand.ExecuteNonQuery()
                    If delRowCntc <> iNoOfRows Then
                        Throw New Exception("Unable To Delete The Data In Child Table")
                    End If

                    sQuery = "delete from " & sMstTable & " where " & existCond
                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                                                 gObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    delRowCnt = objcommand.ExecuteNonQuery()
                    If delRowCnt <> iNoOfRows Then
                        Throw New Exception("Unable To Delete The Data In Master Table")
                    End If

                    'STEP 5:Call the Function To delete the data from the dependent tables
                    dtResult = DeleteDataInDependentTables(existCond, _
                       gObjOracleConnection, objTransaction, o_Errmsg, _
                       BRCode, UserId, MachineId)

                    If dtResult = False Then
                        'TransferOperativeToInoperative = "Error While Deleting" & _
                        '                                " The Data From Dependent Tables"
                        'objTransaction.Rollback()
                        'gObjOracleConnection.Close()
                        'Exit Function
                        'Throw New Exception("Error While Deleting" & _
                        '                    " The Data From Dependent Tables")
                        Throw New Exception(o_Errmsg)
                    End If
                End If

                'For i = 0 To UBound(accountArr) - 1

                '    strInsertCond = "trim(upper(branchcode))='" & _
                '    UCase(BRCode) & "' and" & _
                '    " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                '    " and glcode='" & GLCode & "' and" & _
                '    " trim(ACCNO) =" & accountArr(i) & " and status='R'"

                '    strBulkInsertCond = "trim(upper(branchcode))='" & _
                '    UCase(BRCode) & "' and" & _
                '    " trim(upper(currencycode))='" & UCase(CURCode) & "'" & _
                '    " and glcode='" & GLCode & "' and" & _
                '    " trim(ACCNO) =" & accountArr(i) & ""

                '    strUpdateCond = strInsertCond

                If Trim(MODId) = "SB" Then
                    sQuery = "insert into " & sMstTable & "(BRANCHCODE,CURRENCYCODE," & _
                       " GLCODE,ACCNO,NAME,CHEQUEBOOK,OPDATE,OPBAL,CLOSEDATE," & _
                       " EFFECTIVEDATE,MATURITYDATE, MATURITYVALUE," & _
                       " TRANSFERFROMBRANCHCODE,TRANSFERTOBRANCHCODE, ROI," & _
                       " TDSYN, NARRATION, FROMACCNO,CATEGORY,BANKSTAFFYN," & _
                       " OPERATEDBY, CATEGORYCODE,INTRODUCERYN," & _
                       " JOINTHOLDERYN,NOMINEEYN,CUSTOMERID,OPERATINGINSTR," & _
                       " GUARDIANYN, POWEROFATTOR," & _
                       " MINORYN, SIGNATUREYN, APPLICATIONDATE, USERID, MACHINEID," & _
                       " TRANSTATUS,STATUS,APPROVEDBY, APPROVEDMACHINE,APPROVEDDATE)" & _
                       " select BRANCHCODE,CURRENCYCODE,'" & InOperGLCode & "',ACCNO," & _
                       " NAME,CHEQUEBOOK,OPDATE,OPBAL,CLOSEDATE,EFFECTIVEDATE," & _
                       " MATURITYDATE, MATURITYVALUE,TRANSFERFROMBRANCHCODE," & _
                       " TRANSFERTOBRANCHCODE, ROI, TDSYN, NARRATION, FROMACCNO," & _
                       " CATEGORY, BANKSTAFFYN, OPERATEDBY, CATEGORYCODE," & _
             " INTRODUCERYN,JOINTHOLDERYN,NOMINEEYN,CUSTOMERID,OPERATINGINSTR," & _
                       " GUARDIANYN, POWEROFATTOR," & _
                       " MINORYN, SIGNATUREYN,'" & Format(ApplicationDate, _
                       " dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "'," & _
                       " 'A','R','SYSTEM','" & MachineId & "'," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'" & _
                       " from " & sMstTable & " where " & strInsertCond

                ElseIf Trim(MODId) = "CA" Then
                    sQuery = "insert into " & sMstTable & "(BRANCHCODE, CURRENCYCODE," & _
                            " GLCode,ACCNO,NAME,CHEQUEBOOK,OPDATE,OPBAL,CLOSEDATE," & _
                            " EFFECTIVEDATE, MATURITYDATE, MATURITYVALUE," & _
                            " TRANSFERFROMBRANCHCODE,TRANSFERTOBRANCHCODE,ROI,TDSYN," & _
                            " NARRATION, FROMACCNO, OPERATINGINSTR, OPERATEDBY," & _
                            " POWEROFATTOR, BANKSTAFFYN, TYPEOFORG," & _
                            " INTRODUCERYN, JOINTHOLDERYN, NOMINEEYN, CATEGORYCODE," & _
                            " CUSTOMERID, GUARDIANYN, MINORDOB, SIGNATUREYN," & _
                            " ApplicationDate, UserId, MachineId, TRANSTATUS, STATUS," & _
                            " MINORYN,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE)" & _
                            " select BRANCHCODE, CURRENCYCODE," & _
                            " '" & InOperGLCode & "',ACCNO,NAME,CHEQUEBOOK,OPDATE," & _
                            " OPBAL,CLOSEDATE," & _
                            " EFFECTIVEDATE, MATURITYDATE, MATURITYVALUE," & _
                            " TRANSFERFROMBRANCHCODE,TRANSFERTOBRANCHCODE,ROI,TDSYN," & _
                            " NARRATION, FROMACCNO, OPERATINGINSTR, OPERATEDBY," & _
                            " POWEROFATTOR, BANKSTAFFYN, TYPEOFORG," & _
                            " INTRODUCERYN, JOINTHOLDERYN, NOMINEEYN, CATEGORYCODE," & _
                            " CUSTOMERID, GUARDIANYN, MINORDOB, SIGNATUREYN," & _
                            " '" & Format(ApplicationDate, "dd - MMM - yyyy") & "'," & _
                            " '" & UserId & "','" & MachineId & "','A','R'," & _
                            " MINORYN,'SYSTEM','" & MachineId & "'," & _
                            " '" & Format(ApplicationDate, "dd - MMM - yyyy") & "'" & _
                            " from " & sMstTable & " where " & strInsertCond

                End If

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                iNoOfRows = objcommand.ExecuteNonQuery
                If iNoOfRows <> expectedRowCnt Then
                    Throw New Exception("Failed to insert inoperative A/C's into " & _
                                        "its Master table")
                End If


                ''' STEP 10 :Update STATUS,IPTRANSFERDATE,IPTRANSFERUSER,
                '''          IPTRANSFERMACHINE,IPTRANSFERCUTOFFDATE in SBMST
                '''          for OperativeGlcode

                ''' step 10.1: First insert data into Hist Table before Updating 

                fldnames = "STATUS,IPTRANSFERDATE,IPTRANSFERUSER," & _
                                        "IPTRANSFERCUTOFFDATE"
                objHist.recordInHist(sMstTable, fldnames, _
                  gObjOracleConnection, objTransaction, returnMsg, rowsEffectedcnt, _
                  strUpdateCond, BRCode, UserId, MachineId, ApplicationDate)

                If Trim(returnMsg) <> "" Then
                    Throw New Exception(returnMsg)
                End If
                'If rowsEffectedcnt <> -1 And rowsEffectedcnt <> expectedRowCnt Then
                '    Throw New Exception("Unable to Move Data into History Table")
                'End If

                ''code added by CH Narayana Dattu date : 06 Jul 2012
                ''' Insert data into SBBALANCE 
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If Trim(MODId) = "SB" Then
                    sQuery = "insert into " & sBalanceTable & " (BRANCHCODE,CURRENCYCODE," & _
                                       " GLCODE,ACCNO,CURBAL,CASHIERID,PREVCURBAL,CLEARBAL,PREVCLEARBAL," & _
                                       " APPROVEDDATE,SANCTIONAMOUNT, APPLICATIONDATE," & _
                                       " USERID,MACHINEID, STATUS," & _
                                       " SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                                       " SYSTEMYEAR)" & _
                                        " select BRANCHCODE,CURRENCYCODE,'" & InOperGLCode & "',ACCNO," & _
                                       " 0,CASHIERID,PREVCURBAL,CLEARBAL,PREVCLEARBAL," & _
                                       " APPROVEDDATE,SANCTIONAMOUNT,'" & _
                                        Format(ApplicationDate, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',                                    STATUS,SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                                       " SYSTEMYEAR from " & sBalanceTable & "  where " & strinsertcondsbbal

                ElseIf Trim(MODId) = "CA" Then
                    sQuery = "insert into " & sBalanceTable & " (BRANCHCODE,CURRENCYCODE," & _
                             " GLCODE,ACCNO,CURBAL,CASHIERID,PREVCURBAL,CLEARBAL,PREVCLEARBAL," & _
                             " APPROVEDDATE,SANCTIONAMOUNT, APPLICATIONDATE," & _
                             " USERID,MACHINEID, STATUS," & _
                             " SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                             " SYSTEMYEAR)" & _
                            " select BRANCHCODE,CURRENCYCODE,'" & InOperGLCode & "',ACCNO," & _
                              " 0,CASHIERID,PREVCURBAL,CLEARBAL,PREVCLEARBAL," & _
                               " APPROVEDDATE,SANCTIONAMOUNT,'" & _
                             Format(ApplicationDate, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',                                    STATUS,SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE,APPROVEDBY,APPROVEDMACHINE," & _
                             " SYSTEMYEAR from " & sBalanceTable & "  where " & strinsertcondsbbal
                End If


                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                iNoOfRows = objcommand.ExecuteNonQuery
                If iNoOfRows <> expectedRowCnt Then
                    Throw New Exception("Failed to insert inoperative A/C's into " & sBalanceTable & "its SBBALANCE Table")
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                sQuery = "update " & sMstTable & " set STATUS='T'," & _
                  " IPTRANSFERDATE='" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " IPTRANSFERUSER='" & UserId & "'," & _
                  " IPTRANSFERMACHINE='" & MachineId & "'," & _
                  " IPTRANSFERCUTOFFDATE='" & Format(CutOffDt, "dd-MMM-yyyy") & "'" & _
                  " where " & strUpdateCond

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                iNoOfRows = objcommand.ExecuteNonQuery()
                If iNoOfRows <> expectedRowCnt Then
                    Throw New Exception("Failed to Update Operative A/C's Data " & _
                    " In Master Table")
                End If


                ''' STEP 12 : Inserting the data of given A/C. No. into
                '''           GENCUSTJOINTHOLDERMST with Inoperativeglcode 
                '''           and (applicationdate,userid,machineid)

                sQuery = "insert into GENCUSTJOINTHOLDERMST(BRANCHCODE," & _
                  " CURRENCYCODE, MODULEID, GLCODE, ACCNO, CUSTOMERID," & _
                  " SNO,JHCUSTOMERID,JOINTHOLDERNAME,MINORDOB,MINORYN," & _
                  " APPLICATIONDATE,USERID,MACHINEID,STATUS)" & _
                  " select BRANCHCODE,CURRENCYCODE, MODULEID, '" & InOperGLCode & "'," & _
                  " ACCNO, CUSTOMERID,SNO,JHCUSTOMERID, JOINTHOLDERNAME, MINORDOB," & _
                  " MINORYN, '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "','" & MachineId & "'," & _
                  " STATUS from GENCUSTJOINTHOLDERMST where " & strBulkInsertCond

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()

                ''' STEP 13 : Inserting the data of given A/C. No. into
                '''           GENCUSTGUARDIANMST with Inoperativeglcode 
                '''           and (applicationdate,userid,machineid)

                sQuery = "insert into GENCUSTGUARDIANMST(BRANCHCODE, CURRENCYCODE," & _
                  " MODULEID, GLCODE, ACCNO, CUSTOMERID," & _
                  " GRDCUSTOMERID, GUARDIANNAME, RELATION, NOMCUSTOMERID, DOB," & _
                  " APPLICATIONDATE,USERID, MACHINEID, STATUS)" & _
                  " select  BRANCHCODE,CURRENCYCODE,MODULEID,'" & InOperGLCode & "'," & _
                  " ACCNO, CUSTOMERID,GRDCUSTOMERID,GUARDIANNAME, RELATION," & _
                  " NOMCUSTOMERID, DOB," & _
                  " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "','" & MachineId & "'," & _
                  " STATUS from GENCUSTGUARDIANMST where " & strBulkInsertCond
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()


                ''' STEP 14 : Inserting the data of given A/C. No. into
                '''           GENCUSTNOMINEEMST with Inoperativeglcode 
                '''           and (applicationdate,userid,machineid)

                sQuery = "insert into GENCUSTNOMINEEMST(BRANCHCODE, CURRENCYCODE," & _
                " MODULEID, GLCODE, ACCNO, CUSTOMERID," & _
                " SNO, NOMCUSTOMERID, NOMINEENAME, MINNOMINEEDOB, MINORYN, RELATION," & _
                " RECEIVERNAME," & _
                " APPLICATIONDATE, USERID, MACHINEID,STATUS)" & _
                " select  BRANCHCODE,CURRENCYCODE,MODULEID,'" & InOperGLCode & "'," & _
                " ACCNO,CUSTOMERID, SNO, NOMCUSTOMERID, NOMINEENAME," & _
                " MINNOMINEEDOB, MINORYN," & _
                " RELATION, RECEIVERNAME," & _
                " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "'," & _
                " STATUS from GENCUSTNOMINEEMST where " & strBulkInsertCond

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()

                ''' STEP 15 : Inserting the data of given A/C. No. into
                '''           GENCUSTINTRODUCERMST with Inoperativeglcode 
                '''           and (applicationdate,userid,machineid)

                sQuery = "insert into GENCUSTINTRODUCERMST(BRANCHCODE,CURRENCYCODE," & _
                   " MODULEID,GLCODE,ACCNO,CUSTOMERID,SNO," & _
                   " INTRCUSTOMERID, RELATION, INTRNAME, APPLICATIONDATE," & _
                   " USERID, MACHINEID, STATUS)" & _
                   " select BRANCHCODE,CURRENCYCODE,MODULEID,'" & InOperGLCode & "'," & _
                   " ACCNO, CUSTOMERID, SNO, INTRCUSTOMERID, RELATION, INTRNAME," & _
                   " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "'," & _
                   " '" & MachineId & "',STATUS  from GENCUSTINTRODUCERMST" & _
                   " where " & strBulkInsertCond

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()

                ''' STEP 16 : Inserting the data of given A/C. No. into
                '''           GENSIGNOTRIESMST with Inoperativeglcode 
                '''           and (applicationdate,userid,machineid)

                sQuery = "insert into GENSIGNOTRIESMST(BRANCHCODE,CURRENCYCODE," & _
                         " MODULEID,GLCODE,ACCNO,CUSTOMERID,NAME," & _
                         " SIGNATURECODE, APPLICATIONDATE, USERID, MACHINEID," & _
                         " STATUS,ACCCUSTOMERID)" & _
                         " select BRANCHCODE,CURRENCYCODE,MODULEID," & _
                         " '" & InOperGLCode & "',ACCNO, CUSTOMERID, NAME," & _
                         " SIGNATURECODE," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                         " '" & UserId & "','" & MachineId & "',STATUS," & _
                         " ACCCUSTOMERID  from GENSIGNOTRIESMST where " & strBulkInsertCond

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String
                arrVals(0, 0) = strAccNos
                arrVals(1, 0) = strAccNames
                arrVals(2, 0) = strAccCustIds
                arrVals(3, 0) = strAccBals

                ''' STEP 17 : Do Transfer Transaction to debit Operative GL A/c's and 
                '             Credit InOperative Gl A/C's
                opResult = doSBTransferTransactions(BRCode, CURCode, MODId, GLCode, _
                           InOperGLCode, arrVals, ApplicationDate, UserId, _
                           MachineId, gObjOracleConnection, objTransaction, _
                           returnBatchNo, rtnFromTranno, rtnToTranno)
                If opResult = False Then
                    'TransferOperativeToInoperative = "Error While doing Transfer " & _
                    '"Trancaction to Debit Operative GL A/C's and Credit InOperative " & _
                    '"GL A/C's"
                    'objTransaction.Rollback()
                    'gObjOracleConnection.Close()
                    'Exit Function
                    Throw New Exception("Error While doing Transfer Trancaction" & _
                        " to Debit Operative GL A/C's and Credit InOperative" & _
                        " GL A/C's")
                End If

                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False

            'Dim opResult As String

            '''' STEP 17 : Do Transfer Transaction to debit Operative GL A/c's and 
            ''             Credit InOperative Gl A/C's
            'opResult = doSBTransferTransactions(BRCode, CURCode, MODId, GLCode, _
            '           InOperGLCode, arrVals, ApplicationDate, UserId, _
            '           MachineId, gObjOracleConnection, objTransaction, _
            '           returnBatchNo, rtnFromTranno, rtnToTranno)
            'If opResult = False Then
            '    'TransferOperativeToInoperative = "Error While doing Transfer " & _
            '    '"Trancaction to Debit Operative GL A/C's and Credit InOperative " & _
            '    '"GL A/C's"
            '    'objTransaction.Rollback()
            '    'gObjOracleConnection.Close()
            '    'Exit Function
            '    Throw New Exception("Error While doing Transfer Trancaction" & _
            '        " to Debit Operative GL A/C's and Credit InOperative" & _
            '        " GL A/C's")
            'End If

            'objTransaction.Commit()
            'bTransBegin = False
            'gObjOracleConnection.Close()
            'bConnOpened = False

            'TransferOperativeToInoperative = "Transaction Successful" & _
            '"   Batch No. : " & returnBatchNo & " From TranNo. :" & rtnFromTranno & "    To TranNo. :" & rtnToTranno

            TransferOperativeToInoperative = "Transaction Successful" & " Batch No.(s)  " & returnBatchNo

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                TransferOperativeToInoperative = ex.Message
                Exit Function
            Else
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS / TransferToInoperative"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while transferring Operative to Inoperative " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    TransferOperativeToInoperative = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    TransferOperativeToInoperative = clntDesc
                End If
                Exit Function
            End If

        End Try
    End Function

    Private Function doSBTransferTransactions(ByVal i_BRcode As String, _
          ByVal i_CURCode As String, ByVal i_ModId As String, _
          ByVal i_DrGLCOde As String, ByVal i_CrGLCode As String, _
          ByVal arrOPData(,) As Object, ByVal ApplicationDate As Date, _
          ByVal UserId As String, ByVal MachineId As String, _
          ByRef gObjOracleConnection As OracleClient.OracleConnection, _
          ByRef objTransaction As OracleClient.OracleTransaction, _
          ByRef o_BatchNo As String, ByRef o_FromTranNo As String, _
          ByRef o_ToTranNo As String) As Boolean

        ' This Function is used for Financial Transaction while transfering 
        'Accounts Operative To Inoperative OR Inoperative To Operative
        'INPUTS :
        'i_BRcode = Branch Code in which a/c's are existed
        'i_CURCode= Currency Code
        'i_ModId = Module Id; Generally it will be wether 'SB' or 'CA' modules
        'i_DrGLCOde =  Glcode which is transferring 
        'i_CrGLCode =  GLCode which is in Present mode(whether Operative/Inoperative)

        'arrOPData(Idx,0) = Includes Account Numbers to transfer and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,0) = Includes Names of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'arrOPData(Idx,0) = Includes CustomerIDs of the Account holders respectively 
        '                 and these are separated by "," (Comma Symbol)
        'arrOPData(Idx,0) = Includes Current Balances of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)

        'ApplicationDate= Current Date of Application
        'UserId = Login UserId
        'MachineId= Login MachineId
        'gObjOracleConnection = Connection Object
        'objTransaction = Transaction Object


        Dim objdbconnection = New DatabaseConnection.cDBConnection

        Dim genTransDrQry, sbtranDrQuery, genTransCrQry, sbtranCrQuery, i_Batchno, i_Tranno, FrmTranNo, FromTranNo As String
        Dim arrAccNo, arrAccName, arrAccCustId, arrAccBal As Object
        Dim objCommand As OracleClient.OracleCommand
        Dim Idx As Long
        Dim genDrNoOfRows, sbTranDrNoOfRows, genCrNoOfRows, sbTranCrNoOfRows As Short


        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'i_Batchno = GenTran.GetBatchno(i_BRcode)
        i_Batchno = objDBConnection.GetBatchno(i_BRcode)

        Try
            arrAccNo = CStr(arrOPData(0, 0)).Split(",")
            arrAccName = CStr(arrOPData(1, 0)).Split(",")
            arrAccCustId = CStr(arrOPData(2, 0)).Split(",")
            arrAccBal = CStr(arrOPData(3, 0)).Split(",")

            doSBTransferTransactions = False

            For Idx = 0 To UBound(arrAccNo)
                i_Tranno = objdbconnection.GetTranNo(i_BRcode)
                If Idx = 0 Then
                    FromTranNo = i_Tranno
                Else
                    i_Tranno = i_Tranno
                End If
                'Debit A/C balance into Debit Gl Code WITH SAME A/C NUMBER
                genTransDrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                     " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                     " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                     " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                     " SYSTEMDATE) values('" & i_BRcode & "'," & _
                     " '" & i_CURCode & "','" & i_ModId & "'," & _
                     " '" & i_DrGLCOde & "'," & arrAccNo(Idx) & "," & _
                     " '" & i_Batchno & "','" & i_Tranno & "'," & _
                     " " & -arrAccBal(Idx) & ",'3'," & -arrAccBal(Idx) & "," & _
                     " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                     " " & arrAccCustId(Idx) & "," & _
                     " " & arrAccName(Idx) & ",'N','Y','Transfer To Inoperative'," & _
                     " '1','N'," & _
                     " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                     " '" & UserId & "','" & MachineId & "','A'," & _
                     " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "')"


                sbtranDrQuery = "insert into " & i_ModId & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                  " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                  " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                  " SYSTEMGENERATEDYN," & _
                  " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                  " MACHINEID, TRANSTATUS) values('" & i_BRcode & "'," & _
                  " '" & i_CURCode & "','" & i_ModId & "'," & _
                  " '" & i_DrGLCOde & "'," & arrAccNo(Idx) & "," & _
                  " '" & i_Batchno & "','" & i_Tranno & "'," & _
                  " " & -arrAccBal(Idx) & ",'3'," & -arrAccBal(Idx) & "," & _
                  " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " " & arrAccCustId(Idx) & "," & _
                  " " & arrAccName(Idx) & ",'N','Y','Transfer To Inoperative'," & _
                  " '1','N'," & _
                  " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "','" & MachineId & "','A')"


                i_Tranno = objdbconnection.GetTranNo(i_BRcode)

                'CREDIT A/C BALANCE INTO CREDIT GL CODE WITH SAME A/C NUMBER

                genTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                    " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                   " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " SYSTEMDATE) values('" & i_BRcode & "'," & _
                   " '" & i_CURCode & "','" & i_ModId & "'," & _
                   " '" & i_CrGLCode & "'," & arrAccNo(Idx) & "," & _
                   " '" & i_Batchno & "','" & i_Tranno & "'," & _
                   " " & arrAccBal(Idx) & ",'4'," & arrAccBal(Idx) & "," & _
                   " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                   " " & arrAccCustId(Idx) & "," & _
                   " " & arrAccName(Idx) & ",'N','Y','Transfer To Inoperative'," & _
                   " '1','N'," & _
                   " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "','A'," & _
                   " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "')"


                sbtranCrQuery = "insert into " & i_ModId & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                  " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                  " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                  " SYSTEMGENERATEDYN," & _
                  " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                  " MACHINEID, TRANSTATUS) values('" & i_BRcode & "'," & _
                  " '" & i_CURCode & "','" & i_ModId & "'," & _
                  " '" & i_CrGLCode & "'," & arrAccNo(Idx) & "," & _
                  " '" & i_Batchno & "','" & i_Tranno & "'," & _
                  " " & arrAccBal(Idx) & ",'4'," & arrAccBal(Idx) & "," & _
                  " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " " & arrAccCustId(Idx) & "," & _
                  " " & arrAccName(Idx) & ",'N','Y','Transfer To Inoperative'," & _
                  " '1','N'," & _
                  " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "','" & MachineId & "','A')"


                objCommand = New OracleClient.OracleCommand(genTransDrQry, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                genDrNoOfRows = objCommand.ExecuteNonQuery()

                objCommand = New OracleClient.OracleCommand(sbtranDrQuery, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                sbTranDrNoOfRows = objCommand.ExecuteNonQuery()

                objCommand = New OracleClient.OracleCommand(genTransCrQry, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                genCrNoOfRows = objCommand.ExecuteNonQuery()

                objCommand = New OracleClient.OracleCommand(sbtranCrQuery, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                sbTranCrNoOfRows = objCommand.ExecuteNonQuery()
                If genDrNoOfRows <> 1 Or sbTranDrNoOfRows <> 1 Or _
         genCrNoOfRows <> 1 Or sbTranCrNoOfRows <> 1 Then
                    Throw New Exception("Error ! : while doing transfer transactions")
                End If
                doSBTransferTransactions = True
            Next
            'o_BatchNo = i_Batchno
            If oBatchNo = "" Then
                oBatchNo = i_Batchno
            Else
                oBatchNo = oBatchNo & " , " & i_Batchno
            End If

            o_BatchNo = oBatchNo
            o_FromTranNo = FromTranNo
            o_ToTranNo = i_Tranno
        Catch ex As Exception
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / doSBTransferTransaction"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while transferring Operative to Inoperative Due to " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

            Else
                errNum = "doSBTransfer"
                errDesc = ex.Message
                clntDesc = "Error ! while Doing Transfer Transactions " & errDesc

            End If

            Dim objError As New DatabaseConnection.ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
            clntDesc, o_Errmsg, strComponent, i_BRcode, UserId, MachineId)
            doSBTransferTransactions = False
        End Try
    End Function

    Private Function DeleteDataInDependentTables(ByVal existCond As String, _
          ByRef gObjOracleConnection As OracleClient.OracleConnection, _
          ByRef objTransaction As OracleClient.OracleTransaction, _
          ByRef o_ErrMsg As String, _
          ByVal Brcode As String, ByVal Userid As String, _
          ByVal MachineId As String) As Boolean


        'Desc: This is used to Delete The Data from all the dependent Tables
        '      which exists with inoperative GLCODE
        'Inputs:
        'existCond =This is the condition to delete the data from all dependent
        '           tables which holds BranchCode,
        '           CurrencyCode,A/C. Nos. with status 'R' 
        'gObjOracleConnection =OracleCOnnection Object 
        'objTransaction = Transaction Object


        Dim TableNames, arrTableNames As Object
        Dim sQuery As String
        Dim objcommand As OracleClient.OracleCommand
        Dim idx, delVal As Short
        Dim fldnames As String
        Dim returnMsg As String, rowsEffectedcnt As Integer
        Dim objHist As New DatabaseConnection.updateHistTable

        TableNames = "GENCUSTJOINTHOLDERMST,GENCUSTGUARDIANMST," & _
                     " GENCUSTNOMINEEMST,GENCUSTINTRODUCERMST,GENSIGNOTRIESMST"
        arrTableNames = CStr(TableNames).Split(",")


        Try
            'For idx = 0 To UBound(arrTableNames)

            '    sQuery = "delete from " & arrTableNames(idx) & "  where " & existCond
            '    objcommand = New OracleClient.OracleCommand(sQuery, _
            '                                              gObjOracleConnection)
            '    objcommand.Transaction = objTransaction
            '    objcommand.ExecuteNonQuery()

            'Next

            For idx = 0 To UBound(arrTableNames)

                fldnames = ""
                objHist.recordInHist(arrTableNames(idx), fldnames, _
                  gObjOracleConnection, objTransaction, returnMsg, rowsEffectedcnt, _
                  existCond, Brcode, Userid, MachineId)
                If returnMsg <> "" Then
                    Throw New Exception(returnMsg)
                End If

                sQuery = "delete from " & arrTableNames(idx) & "  where " & existCond
                objcommand = New OracleClient.OracleCommand(sQuery, _
                                                          gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()

            Next

            DeleteDataInDependentTables = True

        Catch ex As Exception

            DeleteDataInDependentTables = False

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / DeleteDataInDependentTables"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while deleting data from dependent tables " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, Brcode, Userid, MachineId)
                o_ErrMsg = clntDesc
            Else
                errNum = "DELDATA"
                errDesc = ex.Message
                clntDesc = "Error ! while deleting data from dependent Tables " & errDesc
                o_ErrMsg = clntDesc
            End If

        End Try
    End Function
    Public Function PostSBCACreditInterest(ByVal CurrencyCode As String, _
           ByVal ModuleId As String, _
           ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
           ByVal IntCalcToDt As Date, ByVal roundOfParam As Double, _
           ByVal UserId As String, _
           ByVal ApplicationDt As Date, ByVal MachineId As String, _
           ByVal arrVals(,) As Object, ByRef o_ErrMsg As String, _
           Optional ByVal BranchCode As String = "", _
           Optional ByVal FrmAccPre As String = "", _
           Optional ByVal FrmAccNo As String = "", _
           Optional ByVal FrmAccSuf As String = "", _
           Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Post The Interests to the A/c. holders for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'SB' or 'CA' modules
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= CustomerIds
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Account Holder's Current Balances
        'arrVals(5,0)= calculated Interests
        'O_ErrMsg = Holds the ErrorMessage/Batch No. which will return to 
        'the caller function
        'BranchCode = Branch Code in which a/c's are existed

        'Outputs:
        ' if the whole process is successfully executed
        '    function PostSBCACreditInterest will return True and O_ErrMsg Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 
        Dim strremarks As String = ""
        Dim strdrremarks As String = ""
        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, debitGlCode, debitAccNo, debitModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted, rtnValue, rtnAccBal As String

        Dim bTransBegin As Boolean = False

        Dim getDebitBal, getCreditBal, sumCrIntAmount, entryDebitAmount As Double
        sumCrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drDebitGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        Dim objgencls As New BulkOperations.GeneralCls
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim objAccBal As AccountDetailsRCW.AccDetails
        'objAccBal = New AccountDetailsRCW.AccDetails

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer


        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            arrCurBal = Split(arrVals(4, 0), ",")
            arrInterests = Split(arrVals(5, 0), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Debit Entry for Multiple Credit Entries
                    ' into respective tables
                    If prevBrCode <> "" Then
                        strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                          " '" & CurrencyCode & "', '" & debitModuleId & "'," & _
                          " '" & debitGlCode & "','" & debitAccNo & "'," & _
                          " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar

                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current Balance" & _
                            " of Debit GL " & debitGlCode & " and Accno. " & _
                            debitAccNo & ". " & vbNewLine & rtnValue)
                        Else
                            getDebitBal = CDbl(rtnValue)
                        End If


                        ''rtnAccBal = objAccBal.GetBalance(prevBrCode, CurrencyCode, _
                        ''                    debitModuleId, debitGlCode, debitAccNo)
                        ''If Mid(UCase(Trim(rtnAccBal)), 1, 5) = "ERROR" Then
                        ''    Throw New Exception("Unable to get Current Balance" & _
                        ''    " of Debit GL " & debitGlCode & " and Accno. " & _
                        ''    debitAccNo & ". " & vbNewLine & rtnAccBal)
                        ''ElseIf rtnAccBal = "" Then
                        ''    rtnAccBal = 0
                        ''    getDebitBal = CDbl(rtnAccBal)
                        ''Else
                        ''    getDebitBal = CDbl(rtnAccBal)
                        ''End If

                        ' i_TranNo = GenTran.GetTranNo(arrBrCodes(idx))
                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                        strdrremarks = ""
                        strdrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")

                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                     " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & debitModuleId & "'," & _
                        " '" & debitGlCode & "','" & debitAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & -sumCrIntAmount & ",'3'," & getDebitBal & "," & _
                        " " & getDebitBal & "," & getDebitBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','" & strdrremarks & "','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICCR')"


                        tranDrQuery = "insert into " & Trim(debitModuleId) & "TRANDAY" & _
                            "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                            " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                            " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                            " EFFECTIVEDATE,CASHPAIDYN," & _
                            " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                            " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                            " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                            " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                            " '" & debitModuleId & "','" & debitGlCode & "'," & _
                            " '" & debitAccNo & "','" & i_Batchno & "'," & _
                            " '" & i_TranNo & "'," & -sumCrIntAmount & "," & _
                            " '3'," & getDebitBal & "," & _
                            " " & getDebitBal & "," & getDebitBal & "," & _
                            " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                            " 'N','Y','" & strdrremarks & "','1','N'," & _
                            " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                            " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                            " 'SYSTEM','" & MachineId & "','ICCR')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Debit Entry" & _
                            " into Trans Log")
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Debit Entry" & _
                            " into " & Trim(debitModuleId) & " Tran Day")
                        End If
                    End If  '''end of debit entry posting

                    ' i_Batchno = GenTran.GetBatchno(arrBrCodes(idx))
                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                        ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()
                    bTransBegin = True

                        If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                        '  Verify In GENSYSTEMACTIVELOG  whether interest is
                        '  Posted
                        ' for the Given Gl Code A/c. holders in Given Range of Dates

                        ' Preparing the condition for Verifying the data with
                        ' given condition
                        ' if not found in GENSYSTEMACTIVELOG will post the Entry
                        ' for the same condition

                        strInsertCond = " CURRENCYCODE='" & CurrencyCode & _
                        "' and MODULEID='" & ModuleId & "'" & _
                     " and GLCODE='" & Glcode & "' and ACTIVITYID='ICCR' and" & _
                        " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                        "' and BRANCHCODE='" & arrBrCodes(idx) & "'"

                            strQuery = "select nvl(count(*),0) from" & _
                            " GENSYSTEMACTIVITYLOG where " & strInsertCond
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                            i_NoOfRows = objcommand.ExecuteScalar
                            If i_NoOfRows <> 0 Then
                                Throw New Exception("Already " & ModuleId & _
                                " Credit Interest Was Posted For This Period")
                            End If

                        strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                             " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                            " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                              " STATUS,APPROVEDBY," & _
                              " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                            " ('" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                              " '" & ModuleId & "','" & Glcode & "'," & _
                        " 'ICCR','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                              " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                              " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " '" & UserId & "'," & _
                        " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                              " " & roundOfParam & "," & i_Batchno & ")"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            i_NoOfRows = objcommand.ExecuteNonQuery()
                            If i_NoOfRows <> 1 Then
                                Throw New Exception("Unable To Insert Data Into" & _
                                " GensystemActivityLog For The Branch " & arrBrCodes(idx))
                            End If
                        End If   ''' End of FrmAccno Not Null

                        ''Get the DebitGlcode and Debit Account Number
                        'for the respective Credit Gl Code
                        strQuery = "select INTDEBITGLCODE,INTDEBITACCNO from" & _
                         " " & Trim(ModuleId) & "TYPEMST where" & _
                         " MODULEID='" & Trim(ModuleId) & "' and" & _
                         " GLCODE='" & Trim(Glcode) & "'"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        drDebitGLACC = objcommand.ExecuteReader
                        If drDebitGLACC.Read Then
                            If IsDBNull(drDebitGLACC(0)) = False And _
                                          IsDBNull(drDebitGLACC(1)) = False Then
                                debitGlCode = drDebitGLACC(0)
                                debitAccNo = drDebitGLACC(1)
                            Else
                            Throw New Exception("Debit Parameters Not Available" & _
                               " For the Credit GL in" & ModuleId & " TYPEMST Table")
                            End If
                        Else
                            Throw New Exception("Debit Parameters Not Available" & _
                            " For the Credit GL in" & ModuleId & " TYPEMST Table")

                        End If
                        drDebitGLACC = Nothing

                        '' save the Parameters like DebitGlcode,Debit Account No.
                        ' and Round Value


                    '' save the Parameters like 
                    ' COL1=Glcode into which sum of Dr. interest was credited
                    ' COL2=Account No. into which sum of Dr. interest was credited
                    ' COL3=Value to round of the calculated interest
                    ' COL4= suffix of the interest calculated accounts
                    'COL5= A/C. No. from which interest was calculated
                    ' COL6=prefix of the interest calculated accounts
                    'COL7= A/C. No. upto which interest was calculated

                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6," & _
                    "COL7,COL8,COL9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "', '" & Glcode & "','" & UserId & "','" & _
                    MachineId & "','SYSTEM','" & MachineId & "','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(IntCalcToDt, "dd-MMM-yyyy") & "','" & _
                    debitGlCode & "','" & debitAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & _
                    FrmAccNo & "','" & FrmAccSuf & "','" & _
                    ToAccNo & "','',''," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable to Insert the data into" & _
                            " Actual Parameters Table while Crediting " & ModuleId & _
                            " interest")
                        End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    'strQuery = "select moduleid from GENGLMASTMST where" & _
                    '  " BranchCode='" & arrBrCodes(idx) & "' and" & _
                    '       " GLCODE='" & debitGlCode & "'"

                    strQuery = "select moduleid from GENGLMASTMST where" & _
                             " GLCODE='" & debitGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                           ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        drGetModId = objcommand.ExecuteReader
                        If drGetModId.Read Then
                            If IsDBNull(drGetModId(0)) = False Then
                                debitModuleId = drGetModId(0)
                            Else
                                Throw New Exception("Module Id for the GL " & _
                                debitGlCode & " Not Available")
                            End If
                        Else
                        Throw New Exception("Module Id for the GL " & debitGlCode & _
                            " Not Available")
                        End If
                        drGetModId = Nothing
                    End If ''' End of Inserting entries into systemactivitylog and actual
                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder
                'strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                '      " '" & CurrencyCode & "', '" & Trim(ModuleId) & "'," & _
                '      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                '      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                'objcommand = New OracleClient.OracleCommand(strQuery, _
                '                                         ObjOracleConnection)
                'objcommand.Transaction = objTransaction
                'rtnValue = objcommand.ExecuteScalar
                'If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                '    Throw New Exception("Unable to get Current Balance" & _
                '         " of Credit GL " & Glcode & " and Accno. " & _
                '         arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                'Else
                '    getCreditBal = CDbl(rtnValue)
                'End If

                'i_TranNo = GenTran.GetTranNo(arrBrCodes(idx))
                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                strremarks = ""

                strremarks = objgencls.GetRemarks(arrBrCodes(idx), CurrencyCode, ModuleId, Glcode, arrAccnos(idx))

                strremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE,CUSTOMERID," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & arrInterests(idx) & ",'4'," & arrCurBal(idx) & "," & _
                " " & arrCurBal(idx) & "," & arrCurBal(idx) & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','" & strremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICCR')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & arrInterests(idx) & "," & _
                   " '4'," & arrCurBal(idx) & "," & _
                   " " & arrCurBal(idx) & "," & arrCurBal(idx) & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','" & strremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','ICCR')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Credit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Credit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If
                '' sum, credit interest amount of A/c. holders which are existed in
                '' same branch
                sumCrIntAmount = sumCrIntAmount + arrInterests(idx)

                prevBrCode = arrBrCodes(idx)

                ''''' Debit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then
                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                       " '" & CurrencyCode & "', '" & debitModuleId & "'," & _
                       " '" & debitGlCode & "','" & debitAccNo & "'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Debit GL " & debitGlCode & " and Accno. " & _
                            debitAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getDebitBal = CDbl(rtnValue)
                    End If

                    ''rtnAccBal = objAccBal.GetBalance(arrBrCodes(idx), CurrencyCode, debitModuleId, debitGlCode, debitAccNo)

                    ''If Mid(UCase(Trim(rtnAccBal)), 1, 5) = "ERROR" Then
                    ''    Throw New Exception("Unable to get Current Balance" & _
                    ''        " of Debit GL " & debitGlCode & " and Accno. " & _
                    ''         debitAccNo & ". " & vbNewLine & rtnAccBal)
                    ''ElseIf rtnAccBal = "" Then
                    ''    rtnAccBal = 0
                    ''    getDebitBal = CDbl(rtnAccBal)
                    ''Else
                    ''    getDebitBal = CDbl(rtnAccBal)
                    ''End If
                    'If rtnAccBal = "" Then
                    '    Throw New Exception("Unable to get Current Balance" & _
                    '  " of Debit GL " & debitGlCode & " and Accno. " & _
                    '    debitAccNo & ". " & vbNewLine & rtnValue)
                    'Else
                    '    getDebitBal = CDbl(rtnAccBal)
                    'End If                   

                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    strdrremarks = ""
                    strdrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                  " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                    " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                    " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & debitModuleId & "'," & _
                    " '" & debitGlCode & "','" & debitAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & -sumCrIntAmount & ",'3'," & getDebitBal & "," & _
                    " " & getDebitBal & "," & getDebitBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','" & strdrremarks & "','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICCR')"

                    tranDrQuery = "insert into " & Trim(debitModuleId) & "TRANDAY" & _
                      "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                       " EFFECTIVEDATE,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                       " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                       " '" & debitModuleId & "','" & debitGlCode & "'," & _
                       " '" & debitAccNo & "','" & i_Batchno & "'," & _
                       " '" & i_TranNo & "'," & -sumCrIntAmount & "," & _
                       " '3'," & getDebitBal & "," & _
                       " " & getDebitBal & "," & getDebitBal & "," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'N','Y','" & strdrremarks & "','1','N'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "'," & _
                       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'SYSTEM','" & MachineId & "','ICCR')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()
                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Debit Entry" & _
                        " into Trans Log")
                    End If
                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnTranDrQuery = objcommand.ExecuteNonQuery()
                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Debit Entry" & _
                        " into " & Trim(debitModuleId) & " Tran Day")
                    End If
                End If
            Next ''' End of Credit Interest Posting

            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
               " LASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & _
               "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
               " GLCODE ='" & Glcode & "' and" & _
               " (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") "
                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                'If i_NoOfRows <> (UBound(arrAccnos) + 1) Then
                'Throw New Exception("Unable to Modify The LastIntCalcDate While" & _
                '" Crediting Interest")
                'End If

                '' inserting  interest posted accs. details 
                'strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                '" and GLCODE ='" & Trim(Glcode) & "'" & _
                '" and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                '" and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                '" and USERID='" & Trim(UserId) & "' and" & _
                '" MACHINEID='" & Trim(MachineId) & "' and" & _
                '" APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                '" and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                strProdDtlsCond = " USERID='" & Trim(UserId) & "' " & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                strQuery = "insert into GENSBCAINTPRODUCTSDTLS(BRANCHCODE," & _
                 " CURRENCYCODE,MODULEID,GLCODE, ACCNO, CATEGORYCODE, PRODFROMDT," & _
              " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT,USERID," & _
                 " MACHINEID,APPLICATIONDATE," & _
                 " STATUS,TRANSTATUS,APPROVEDBY," & _
                 " APPROVEDDATE, APPROVEDMACHINE,ACTIVITYID) select BRANCHCODE," & _
                 " CURRENCYCODE,'" & ModuleId & "', GLCODE, ACCNO," & _
                 " CATEGORYCODE, PRODFROMDT," & _
                 " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT," & _
                 " '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
             " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " '" & MachineId & "','ICCR' from " & Trim(ModuleId) & "INTCALTEMP" & _
                 " where " & strProdDtlsCond


                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()


            Next i

            '' inserting Interest Not posted accno. details (missing accnos.)
            strIntDtlsNotPosted = "USERID='" & Trim(UserId) & "' " & _
            " and accno not in (select accno from GENSBCAINTPRODUCTSDTLS  " & _
            " where upper(branchcode)='" & UCase(Trim(BranchCode)) & "'" & _
            " and upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "'" & _
            " and glcode='" & Glcode & "'" & _
            " and intcalfromdt='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
            " and intcaltodt='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "' )"

            strQuery = "insert into SBCAINTNOTPOSTDTLS(BRANCHCODE," & _
               " CURRENCYCODE,MODULEID,GLCODE, ACCNO," & _
               " CATEGORYCODE, PRODFROMDT," & _
             " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT,USERID," & _
               " MACHINEID,APPLICATIONDATE," & _
               " APPROVEDBY,APPROVEDMACHINE,ACTIVITYID) select BRANCHCODE," & _
               " CURRENCYCODE,'" & ModuleId & "', GLCODE, ACCNO," & _
               " CATEGORYCODE, PRODFROMDT," & _
               " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT," & _
               " '" & UserId & "','" & MachineId & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
               " 'SYSTEM','" & MachineId & "','ICCR' from " & Trim(ModuleId) _
               & "INTCALTEMP where " & strIntDtlsNotPosted

            objcommand = New OracleClient.OracleCommand(strQuery, _
                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery()

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCACreditInterest = True

            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCACreditInterest = False

            If bTransBegin = True Then
                objTransaction.Rollback()
                objTransaction = Nothing
            End If

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCACreditInterest"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCAInterest Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCAInterest Posting Reason Is "
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Function PostSBCADebitInterest(ByVal CurrencyCode As String, _
       ByVal ModuleId As String, _
       ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
       ByVal IntCalcToDt As Date, ByVal roundOfParam As Double, _
       ByVal UserId As String, _
       ByVal ApplicationDt As Date, ByVal MachineId As String, _
       ByVal ChkDebitVal As String, _
       ByVal arrVals(,) As Object, ByRef o_ErrMsg As String, _
       Optional ByVal BranchCode As String = "", _
       Optional ByVal FrmAccPre As String = "", _
       Optional ByVal FrmAccNo As String = "", _
       Optional ByVal FrmAccSuf As String = "", _
       Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Post The Debit Interests of A/c. holders for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'SB' or 'CA' modules
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= CustomerIds
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Account Holder's Current Balances
        'arrVals(5,0)= calculated Interests
        'O_ErrMsg = Holds the Error Message (OR) Batch No. which will return 
        'to the caller function
        'BranchCode = Branch Code in which a/c's are existed
        'Outputs:
        ' if the whole process is successfully executed
        '    function PostSBCACreditInterest will return True with 
        '    (O_ErrMsg)=Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo, rtnAccBal As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, rtnExcQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, creditGlCode, creditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted As String

        Dim getDebitBal, getCreditBal, sumDrIntAmount, entryDebitAmount As Double
        sumDrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim objAccBal As AccountDetailsRCW.AccDetailsClass
        'objAccBal = New AccountDetailsRCW.AccDetailsClass

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer

        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_Errmsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            arrCurBal = Split(arrVals(4, 0), ",")
            arrInterests = Split(arrVals(5, 0), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit Entries
                    ' into respective tables
                    If prevBrCode <> "" Then
                        strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                        " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                         " '" & creditGlCode & "','" & creditAccNo & "'," & _
                         " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar
                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current Balance" & _
                                " of Credit GL " & creditGlCode & " and Accno. " & _
                                creditAccNo & ". " & vbNewLine & rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If

                        'rtnAccBal = objAccBal.GetBalance(prevBrCode, _
                        '    CurrencyCode, creditModuleId, creditGlCode, creditAccNo)
                        'If Mid(UCase(Trim(rtnAccBal)), 1, 5) = "ERROR" Then
                        '    Throw New Exception("Unable to get Current Balance" & _
                        '    " of Credit GL " & creditGlCode & " and Accno. " & _
                        '    creditAccNo & ". " & vbNewLine & rtnAccBal)
                        'ElseIf rtnAccBal = "" Then
                        '    rtnAccBal = 0
                        '    getCreditBal = CDbl(rtnAccBal)
                        'Else
                        '    getCreditBal = CDbl(rtnAccBal)
                        'End If

                        ' i_TranNo = GenTran.GetTranNo(arrBrCodes(idx))
                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                     " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                        " '" & creditGlCode & "','" & creditAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & sumDrIntAmount & ",'4'," & getCreditBal & "," & _
                        " " & getCreditBal & "," & getCreditBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','Debit Interest Posting','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICDR')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & "TRANDAY" & _
                              "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & creditGlCode & "'," & _
                             " '" & creditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrIntAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','Debit Interest Posting','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "','ICDR')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log")
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & " Tran Day")
                        End If
                        '''  strQuery = "insert into GENEXCEPTIONALTRANDAY" & _
                        '''"(BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,EXCEPTIONCODE," & _
                        '''"APPLICATIONDATE,SYSTEMDATE, APPROVEDDATE, APPROVEDSYSTEMDATE)" & _
                        '''" select BRANCHCODE, CURRENCYCODE," & _
                        '''"BATCHNO,TRANNO,'1',APPLICATIONDATE," & _
                        '''" sysdate,APPROVEDDATE,sysdate from GENTRANSLOG" & _
                        '''" where BRANCHCODE='" & arrBrCodes(idx) & "' and" & _
                        '''" CURRENCYCODE='" & CurrencyCode & "' and" & _
                        '''" BATCHNO='" & i_Batchno & "' and EXCEPTIONYN='Y' and" & _
                        '''" applicationdate='" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                        '''"'"
                        '''  objcommand = New OracleClient.OracleCommand(strQuery, _
                        '''                                        ObjOracleConnection)
                        '''  objcommand.Transaction = objTransaction
                        '''  rtnExcQuery = objcommand.ExecuteNonQuery()

                        'If rtnExcQuery <> 1 Then
                        '    Throw New Exception("Unable To Insert Exceptional" & _
                        '    " Details Entry into Exceptional Tran Day")
                        'End If
                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()
                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                        '  Verify In GENSYSTEMACTIVELOG  whether interest is  Posted
                        ' for the Given Gl Code A/c. holders in Given Range of Dates

                        ' Preparing the condition for Verifying the data with given 
                        ' condition
                        ' if not found in GENSYSTEMACTIVELOG will post the Entry
                        ' for the same condition

                        strInsertCond = " CURRENCYCODE='" & CurrencyCode & _
                        "' and MODULEID='" & ModuleId & "'" & _
                        " and GLCODE='" & Glcode & "' and ACTIVITYID='ICDR' and" & _
                        " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                        "' and BRANCHCODE='" & arrBrCodes(idx) & "'"

                        strQuery = "select nvl(count(*),0) from" & _
                        " GENSYSTEMACTIVITYLOG where " & strInsertCond
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                           ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteScalar
                        If i_NoOfRows <> 0 Then
                            Throw New Exception("Already " & ModuleId & _
                            " Debit Interest Was Posted For This Period")
                        End If

                        strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                          " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                          " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                          " STATUS,APPROVEDBY," & _
                          " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                          " ('" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                          " '" & ModuleId & "','" & Glcode & "'," & _
                         " 'ICDR','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                          " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                          " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "'," & _
                          " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                          " " & roundOfParam & "," & i_Batchno & ")"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                              ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data Into" & _
                            " GensystemActivityLog For The Branch " & arrBrCodes(idx))
                        End If
                    End If   ''' End of FrmAccno Not Null

                    ''Get the CreditGlcode and Credit Account Number
                    'for the respective Debit Gl Code
                    strQuery = "select INTCREDITGLCODE,INTCREDITACCNO from" & _
                     " " & Trim(ModuleId) & "TYPEMST where" & _
                     " MODULEID='" & Trim(ModuleId) & "' and" & _
                     " GLCODE='" & Trim(Glcode) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                            ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC(0)) = False And _
                                      IsDBNull(drCreditGLACC(1)) = False Then
                            creditGlCode = drCreditGLACC(0)
                            creditAccNo = drCreditGLACC(1)
                        Else
                            Throw New Exception("Credit Parameters Not Available" & _
                            " For the GL in" & ModuleId & " TYPEMST Table")
                        End If
                    Else
                        Throw New Exception("Credit Parameters Not Available" & _
                        " For the GL in" & ModuleId & " TYPEMST Table")
                    End If
                    drCreditGLACC = Nothing

                    '' save the Parameters like 
                    ' COL1=Glcode into which sum of Dr. interest was credited
                    ' COL2=Account No. into which sum of Dr. interest was credited
                    ' COL3=Value to round of the calculated interest
                    ' COL4= suffix of the interest calculated accounts
                    'COL5= A/C. No. from which interest was calculated
                    ' COL6=prefix of the interest calculated accounts
                    'COL7= A/C. No. upto which interest was calculated
                    'COL8= User parameter to specify to post interest even
                    ' when balance is getting -Ve


                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,USERID," & _
                    "MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6," & _
                    "COL7,COL8,COL9,COL10,COL11,COL12)values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & "','" & _
                    MachineId & "','SYSTEM','" & MachineId & "','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(IntCalcToDt, "dd-MMM-yyyy") & "','" & _
                    creditGlCode & "','" & creditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & FrmAccNo & _
                    "','" & FrmAccSuf & "','" & ToAccNo & "','" & _
                    ChkDebitVal & "',''," & i_Batchno & ")"

                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data into" & _
                        " Actual Parameters Table while Debiting " & ModuleId & _
                        " interest")
                    End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    'strQuery = "select moduleid from GENGLMASTMST where" & _
                    '  " BranchCode='" & arrBrCodes(idx) & "' and" & _
                    ' " GLCODE='" & creditGlCode & "'"

                    strQuery = "select moduleid from GENGLMASTMST where" & _
                               " GLCODE='" & creditGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.Read Then
                        If IsDBNull(drGetModId(0)) = False Then
                            creditModuleId = drGetModId(0)
                        Else
                            Throw New Exception("Module Id for the GL " & _
                            creditGlCode & " Not Available")
                        End If
                    Else
                        Throw New Exception("Module Id for the GL " & creditGlCode & _
                        " Not Available")
                    End If
                    drGetModId = Nothing
                End If ''' End of Inserting entries into systemactivitylog and actual
                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder
                'strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                '      " '" & CurrencyCode & "', '" & Trim(ModuleId) & "'," & _
                '      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                '      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                'objcommand = New OracleClient.OracleCommand(strQuery, _
                '                                         ObjOracleConnection)
                'objcommand.Transaction = objTransaction
                'rtnValue = objcommand.ExecuteScalar
                'If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                '    Throw New Exception("Unable to get Current Balance" & _
                '         " of GL " & Glcode & " and Accno. " & _
                '         arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                'Else
                '    getDebitBal = CDbl(rtnValue)
                'End If


                '' Making ExceptionYN=Y/N based on balance after posting
                Dim strExcYN As String
                If (arrCurBal(idx) - arrInterests(idx)) < 0 Then
                    strExcYN = "Y"
                Else
                    strExcYN = "N"
                End If

                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE,CUSTOMERID," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -arrInterests(idx) & ",'3'," & arrCurBal(idx) & "," & _
                " " & arrCurBal(idx) & "," & arrCurBal(idx) & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','Debit Interest Posting'," & _
                " '1','" & strExcYN & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICDR')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -arrInterests(idx) & "," & _
                   " '3'," & arrCurBal(idx) & "," & _
                   " " & arrCurBal(idx) & "," & arrCurBal(idx) & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','Debit Interest Posting','1','" & strExcYN & "'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','ICDR')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If
                ' sum, credit interest amount of A/c. holders which are existed in
                ' same branch
                sumDrIntAmount = sumDrIntAmount + arrInterests(idx)
                prevBrCode = arrBrCodes(idx)

                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    ''rtnAccBal = objAccBal.GetBalance(arrBrCodes(idx), _
                    ''        CurrencyCode, creditModuleId, creditGlCode, creditAccNo)
                    ''If Mid(UCase(Trim(rtnAccBal)), 1, 5) = "ERROR" Then
                    ''    Throw New Exception("Unable to get Current Balance" & _
                    ''        " of credit GL " & creditGlCode & " and Accno. " & _
                    ''        creditAccNo & ". " & vbNewLine & rtnAccBal)
                    ''ElseIf rtnAccBal = "" Then
                    ''    rtnAccBal = 0
                    ''    getCreditBal = CDbl(rtnAccBal)
                    ''Else
                    ''    getCreditBal = CDbl(rtnAccBal)
                    ''End If

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                       " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                        " '" & creditGlCode & "','" & creditAccNo & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & creditGlCode & " and Accno. " & _
                            creditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If

                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                  " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                    " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                    " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & creditGlCode & "','" & creditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrIntAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','Debit Interest Posting','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','ICDR')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & "TRANDAY" & _
                      "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                       " EFFECTIVEDATE,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                       " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                       " '" & creditModuleId & "','" & creditGlCode & "'," & _
                       " '" & creditAccNo & "','" & i_Batchno & "'," & _
                       " '" & i_TranNo & "'," & sumDrIntAmount & "," & _
                       " '4'," & getCreditBal & "," & _
                       " " & getCreditBal & "," & getCreditBal & "," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'N','Y','Debit Interest Posting','1','N'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "'," & _
                       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'SYSTEM','" & MachineId & "','ICDR')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()
                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If
                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnTranDrQuery = objcommand.ExecuteNonQuery()
                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If
                    ''''strQuery = "insert into GENEXCEPTIONALTRANDAY" & _
                    ''''  "(BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,EXCEPTIONCODE," & _
                    ''''  "APPLICATIONDATE,SYSTEMDATE, APPROVEDDATE, APPROVEDSYSTEMDATE)" & _
                    ''''  " select BRANCHCODE, CURRENCYCODE," & _
                    ''''  "BATCHNO,TRANNO,'1',APPLICATIONDATE," & _
                    ''''  " sysdate,APPROVEDDATE,sysdate from GENTRANSLOG" & _
                    ''''  " where BRANCHCODE='" & arrBrCodes(idx) & "' and" & _
                    ''''  " CURRENCYCODE='" & CurrencyCode & "' and" & _
                    ''''  " BATCHNO='" & i_Batchno & "' and EXCEPTIONYN='Y' and" & _
                    ''''  " applicationdate='" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                    ''''  "'"

                    ''''objcommand = New OracleClient.OracleCommand(strQuery, _
                    ''''                                      ObjOracleConnection)
                    ''''objcommand.Transaction = objTransaction
                    ''''rtnExcQuery = objcommand.ExecuteNonQuery()

                    'If rtnExcQuery <> 1 Then
                    '    Throw New Exception("Unable To Insert Exceptional" & _
                    '    " Details Entry into Exceptional Tran Day")
                    'End If
                End If
            Next ''' End of Credit Interest Posting

            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_Errmsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_Errmsg <> "" Then
                    Throw New Exception(o_Errmsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
               " OPPLASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & _
               "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
               " GLCODE ='" & Glcode & "' and" & _
               " (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") "
                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                'If i_NoOfRows <> (UBound(arrAccnos) + 1) Then
                'Throw New Exception("Unable to Modify The LastIntCalcDate While" & _
                '" Crediting Interest")
                'End If

                '' inserting  interest posted accs. details 
                'strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                '" and GLCODE ='" & Trim(Glcode) & "'" & _
                '" and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                '" and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                '" and USERID='" & Trim(UserId) & "' and" & _
                '" MACHINEID='" & Trim(MachineId) & "' and" & _
                '" APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                '" and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                strProdDtlsCond = " upper(USERID)='" & UCase(Trim(UserId)) & "'" & _
                " and (BRANCHCODE,ACCNO) in (" & BulkArr(i) & ")"

                '    sharath 05-mar-2008
                ' strQuery = "insert into GENSBCAINTPRODUCTSDTLS(BRANCHCODE," & _
                ' " CURRENCYCODE,MODULEID,GLCODE, ACCNO, CATEGORYCODE, PRODFROMDT," & _
                '" PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT,USERID," & _
                ' " MACHINEID,APPLICATIONDATE," & _
                ' " STATUS,TRANSTATUS,APPROVEDBY," & _
                ' " APPROVEDDATE, APPROVEDMACHINE) select BRANCHCODE," & _
                ' " CURRENCYCODE,'" & ModuleId & "', GLCODE, ACCNO," & _
                ' " CATEGORYCODE, PRODFROMDT," & _
                ' " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT," & _
                ' " '" & UserId & "','" & MachineId & "'," & _
                ' " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                '" 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                ' " '" & MachineId & "' from " & Trim(ModuleId) & "INTCALTEMP" & _
                ' " where " & strProdDtlsCond


                strQuery = "insert into GENSBCAINTPRODUCTSDTLS(BRANCHCODE," & _
                 " CURRENCYCODE,MODULEID,GLCODE, ACCNO, CATEGORYCODE, PRODFROMDT," & _
              " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT,USERID," & _
                 " MACHINEID,APPLICATIONDATE," & _
                 " STATUS,TRANSTATUS,APPROVEDBY," & _
                 " APPROVEDDATE, APPROVEDMACHINE,ACTIVITYID) select BRANCHCODE," & _
                 " CURRENCYCODE,'" & ModuleId & "', GLCODE, ACCNO," & _
                 " CATEGORYCODE, PRODFROMDT," & _
                 " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT," & _
                 " '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
             " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " '" & MachineId & "','ICDR' from " & Trim(ModuleId) & "DEBITINTCALTEMP1" & _
                 " where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

            Next i

            '' inserting Interest Not posted accno. details (missing accnos.)
            'strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
            '" and GLCODE ='" & Trim(Glcode) & "'" & _
            '" and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
            '" and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
            '" and USERID='" & Trim(UserId) & "' and" & _
            '" MACHINEID='" & Trim(MachineId) & "' and" & _
            '" APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
            '" and (branchcode,ACCNO) not in(select distinct branchcode,accno from " & _
            '" GENSBCAINTPRODUCTSDTLS  " & _
            '" where upper(branchcode)='" & UCase(Trim(BranchCode)) & "'" & _
            '" and upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "'" & _
            '" and glcode='" & Glcode & "'" & _
            '" and intcalfromdt='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
            '" and intcaltodt='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "' )"

            strIntDtlsNotPosted = " upper(USERID)='" & UCase(Trim(UserId)) & "' " & _
            " and ACCNO not in(select distinct accno from " & _
            " GENSBCAINTPRODUCTSDTLS " & _
            " where upper(branchcode)='" & UCase(Trim(BranchCode)) & "'" & _
            " and upper(currencycode)='" & UCase(Trim(CurrencyCode)) & "'" & _
            " and glcode='" & Glcode & "'" & _
            " and intcalfromdt='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
            " and intcaltodt='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "' )"

            strQuery = "insert into SBCAINTNOTPOSTDTLS(BRANCHCODE," & _
               " CURRENCYCODE,MODULEID,GLCODE, ACCNO," & _
               " CATEGORYCODE, PRODFROMDT," & _
             " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT,USERID," & _
               " MACHINEID,APPLICATIONDATE," & _
               " APPROVEDBY,APPROVEDMACHINE,ACTIVITYID) select BRANCHCODE," & _
               " CURRENCYCODE,'" & ModuleId & "', GLCODE, ACCNO," & _
               " CATEGORYCODE, PRODFROMDT," & _
               " PRODTODT,MONTHBAL,ROI,INTEREST,INTCALFROMDT,INTCALTODT," & _
               " '" & UserId & "','" & MachineId & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
               " 'SYSTEM','" & MachineId & "','ICDR' from " & Trim(ModuleId) _
               & "DEBITINTCALTEMP1 where " & strIntDtlsNotPosted


            objcommand = New OracleClient.OracleCommand(strQuery, _
                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery()


            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCADebitInterest = True

            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCADebitInterest = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCADbitInterest"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCAInterest Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BranchCode, UserId, MachineId)
                o_Errmsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCADebitInterest Posting"
                o_Errmsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Sub GSTParameters(ByVal strcode As String, ByVal strbrcode As String)

        nonCustomerid = "1111111111"
        strCommServ = ""
        strSql = ""
        strCGSTMod = ""
        strCGSTGl = ""
        strCGSTGlDesc = ""
        strCGSTAcc = ""
        strGSTPercent = ""
        strSGSTMod = ""
        strSGSTGl = ""
        strSGSTGlDesc = ""
        strSGSTAcc = ""
        strCESSMod = ""
        strCESSGl = ""
        strCESSGlDesc = ""
        strCESSAcc = ""
        strEffDate = ""
        strGSTAmt = ""
        strCGSTAmt = ""
        strSGSTAmt = ""
        strCESSAmt = ""

        strAutoPostCharges = "N"
        commYN = "N"
        CessYN = "N"


        Try

            If objconn.State <> ConnectionState.Open Then
                errmsg = ""
                objconn = ObjDbCOnnection.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If


            ''POS place of supply

            strPOS = ""
            strSql = "SELECT  NVL(a.statecode||'-'||b.statename,'') POS FROM genbankbranchmst a,GENSTATEMST b WHERE a.statecode = b.statecode AND a.branchcode='" & strbrcode & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strPOS = IIf(IsDBNull(objDr!POS), "", objDr!POS)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' GSTYN
            strSql = "SELECT nvl(impyn,'N') impyn,NVL(value1,'0') val FROM genconfigmst WHERE code = 'GSTR'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strGSTPercent = IIf(IsDBNull(objDr!val), 0, objDr!val)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' CGST
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='CGST'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCGSTMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strCGSTGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strCGSTGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strCGSTAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing


            ''SGST
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='SGST'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strSGSTMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strSGSTGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strSGSTGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strSGSTAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            '' Cessyn
            strSql = "SELECT nvl(impyn,'N') impyn,NVL(value1,'0') val  FROM genconfigmst WHERE code = 'CESS'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    CessYN = IIf(IsDBNull(objDr!impyn), "N", objDr!impyn)
                    strCessPercent = IIf(IsDBNull(objDr!val), "N", objDr!val)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing


            ''CESS
            strSql = "SELECT NVL(a.MODULEID,'') moduleid , NVL(a.GLCODE,'') glcode, NVL(a.ACCNO,'') accno,NVL(b.gldescription,'') gldescription FROM GSTTYPEPMT a, GENGLMASTMST b WHERE a.glcode=b.glcode AND a.gstcode='GSTR' AND a.gsttype='CESS'"
            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read)
                    strCESSMod = IIf(IsDBNull(objDr!moduleid), "", objDr!moduleid)
                    strCESSGl = IIf(IsDBNull(objDr!glcode), "", objDr!glcode)
                    strCESSGlDesc = IIf(IsDBNull(objDr!gldescription), "", objDr!gldescription)
                    strCESSAcc = IIf(IsDBNull(objDr!accno), "", objDr!accno)
                End While
            End If
            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            If strcode = "FC" Then
                If GSTYN = "Y" Then
                    strRemarksDr = "Folio Charges Inclusive GST "
                Else
                    strRemarksDr = "Folio Charges "
                End If
            ElseIf strcode = "MBC" Then
                If GSTYN = "Y" Then
                    strRemarksDr = "Minimum Balance Charges Inclusive GST "
                Else
                    strRemarksDr = "Minimum Balance Charges "
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub


    Public Function PostSBCADebitFolioCharges(ByVal CurrencyCode As String, _
              ByVal ModuleId As String, _
              ByVal Glcode As String, ByVal ChargeCalcFromDt As Date, _
              ByVal ChargeCalcToDt As Date, ByVal roundOfParam As Double, _
              ByVal UserId As String, _
              ByVal ApplicationDt As Date, ByVal MachineId As String, _
              ByVal arrVals() As Object, ByVal CkDrCharge As Boolean, _
              ByVal ChargeType As String, ByRef o_ErrMsg As String, _
              Optional ByVal BranchCode As String = "", _
              Optional ByVal FrmAccPre As String = "", _
              Optional ByVal FrmAccNo As String = "", _
              Optional ByVal FrmAccSuf As String = "", _
              Optional ByVal ToAccNo As String = "", Optional ByVal strGSTYN As String = "") As Boolean

        'Desc: This is used to Post The Debit Folio Charges of A/c. holders for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'SB' or 'CA' modules
        'GLCode =Gl Code
        'ChargeCalcFromDt And ChargeCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2)= CustomerIds
        'arrVals(3)= Account Holder's Names
        'arrVals(4)= calculated Charges
        'arrVals(5)= Balances of Account
        'O_ErrMsg = Holds the Error Message which will return to the caller function
        'ckdrcharge = Holds True or False to allow posting charges even if balance is
        'less than zero
        'BranchCode = Branch Code in which a/c's are existed

        'Outputs:
        ' if the whole process is successfully executed
        '    function PostSBCADebitFolioCharges will return True with error message
        '    (O_ErrMsg)="" 
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos, strAccountNosNP _
           As String
        Dim strInsertCond, strCkDrCharge, strQuery, i_Batchno, i_TranNo As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery As Integer
        Dim arrBrCodes, arrBrCodesNP, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, arrAccnosNP, _
            arrAccBal, arrCustids, arrTotalCharge, arrCurBalance, arrAccNames As Object
        Dim prevBrCode, CreditGlCode, CreditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted, EntriesPerFolio As String
        Dim CreditAccName As String
        'ChargeType = "FOLIO"

        Dim getDebitBal, getCreditBal, sumDrChargeAmount, entryDebitAmount As Double
        sumDrChargeAmount = 0
        dblTotGSTamt = 0
        dblTotCESSamt = 0
        Dim dblCGSTBal, dblSGSTBal, dblCESSBal As Double
        Dim i, j, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim AccBal As AccountDetailsRCW.AccDetailsClass
        'AccBal = New AccountDetailsRCW.AccDetailsClass

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, BulkArrNP(200) As String, Cnt, CntNP, BulkArrIdx, BulkArrIdxNP As Integer
        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If

           
            GSTYN = strGSTYN
            GSTParameters("FC", BranchCode)

            arrBrCodes = Split(arrVals(0), ",")
            arrAccnos = Split(arrVals(1), ",")
            arrCustids = Split(arrVals(2), ",")
            arrAccNames = Split(arrVals(3), ",")
            arrCurBalance = Split(arrVals(4), ",")
            arrTotalCharge = Split(arrVals(5), ",")
            arrBrCodesNP = Split(arrVals(6), ",")
            arrAccnosNP = Split(arrVals(7), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If


            CntNP = 0 : BulkArrIdxNP = 0
            strAccountNosNP = ""
            For j = 0 To UBound(arrAccnosNP)
                CntNP += 1
                strAccountNosNP = strAccountNosNP & _
                "('" & Trim(arrBrCodesNP(j)) & "','" & Trim(arrAccnosNP(j)) & "') ,"
                If CntNP = 480 Then
                    strAccountNosNP = Mid(strAccountNosNP, 1, _
                        Len(Trim(strAccountNosNP)) - 1)
                    BulkArrNP(BulkArrIdxNP) = strAccountNosNP
                    BulkArrIdxNP += 1
                    strAccountNosNP = ""
                    CntNP = 0
                End If
            Next
            If Trim(strAccountNosNP) <> "" Then
                strAccountNosNP = Mid(strAccountNosNP, 1, _
                    Len(Trim(strAccountNosNP)) - 1)
                BulkArrNP(BulkArrIdxNP) = strAccountNosNP
                BulkArrIdxNP += 1
            End If


            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit Entries
                    ' into respective tables

                    If prevBrCode <> "" Then
                        'Get current balance of credit Account

                        strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                 ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar
                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current Balance" & _
                                " of Credit GL " & CreditGlCode & " and Accno. " & _
                                CreditAccNo & ". " & vbNewLine & rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If

                        ''rtnValue = AccBal.GetBalance(prevBrCode, CurrencyCode, _
                        ''creditModuleId, CreditGlCode, CreditAccNo)

                        ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        ''    Throw New Exception("Error Occured While Getting Current" & _
                        ''    "Balance For Given Credit Account Where Credit GLCode = " & _
                        ''    CreditGlCode & " And Credit AccountNo = " & _
                        ''    CreditAccNo & " And Credit Module id = " & creditModuleId & _
                        ''    "and Branch Code =" & prevBrCode & " Currency Code = " & _
                        ''    CurrencyCode & " . The Error is " & rtnValue)
                        ''Else
                        ''    getCreditBal = Val(rtnValue)
                        ''End If


                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                        strRemarksCr = "Folio Charges From " & ModuleId & " Glcode " & Glcode
                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG,CUSTOMERID,NAME)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                        " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                        " " & getCreditBal & "," & getCreditBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','" & strRemarksCr & "','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','FC','" & nonCustomerid & "','" & CreditAccName & "')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & _
                        "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CUSTOMERID,NAME) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & CreditGlCode & _
                             "','" & CreditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','" & strRemarksCr & "','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log For The Branch " & arrBrCodes(idx))
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & _
                            " Tran Day For The Branch " & arrBrCodes(idx))
                        End If
                        '===========================================

                        ''''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT" & _
                        ''''" BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,'1'," & _
                        ''''"APPLICATIONDATE,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE," & _
                        ''''"APPROVEDDATE,APPROVEDSYSTEMDATE,VERIFIEDSYSTEMDATE WHERE " & _
                        ''''"BRANCHCODE ='" & arrBrCodes(idx) & " AND CURRENCYCODE ='" & _
                        ''''CurrencyCode & " AND BATCHNO= " & i_Batchno & "AND " & _
                        ''''" EXCEPTIONYN='Y'"

                        ''''objcommand = New OracleClient.OracleCommand(strQuery, _
                        ''''                                            ObjOracleConnection)
                        ''''objcommand.Transaction = objTransaction
                        ''''objcommand.ExecuteNonQuery()

                        '' gst value

                        If GSTYN = "Y" Then

                            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                                  "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                                  "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                                  "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                                  "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                                  "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                                  "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                                  "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                                  "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                                  "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                                  "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                                  "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                                  "ABBYN"

                            ''CGST
                            strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strCGSTAmt) <> 0 Then
                                strChqFvg = "CGST"

                                dblCGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                     " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCGSTBal = 0
                                Else
                                    dblCGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                            '' SGST
                            strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strSGSTAmt) <> 0 Then
                                strChqFvg = "SGST"
                                dblSGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                     " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblSGSTBal = 0
                                Else
                                    dblSGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If

                            If CessYN = "Y" Then
                                If CDbl(dblTotCESSamt) <> 0 Then
                                    ''CESS Amount
                                    strChqFvg = "CESS"
                                    dblCESSBal = 0
                                    strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                         " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                         " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                         " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    rtnValue = objcommand.ExecuteScalar
                                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                        dblCESSBal = 0
                                    Else
                                        dblCESSBal = CDbl(rtnValue)
                                    End If

                                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Trans  Log ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing

                                    StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Tran Day ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing
                                End If
                            End If '' cessyn
                        End If '' gstyn


                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()

                    Dim MaxToDate As String

                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                        strQuery = "select NVL(to_char(MAX(TODATE)),0) from " & _
                        " GENSYSTEMACTIVITYLOG WHERE MODULEID='" & Trim(ModuleId) & _
                        "' and" & _
                        " GLCODE='" & Trim(Glcode) & "' AND CURRENCYCODE = '" & _
                        CurrencyCode & "' AND BRANCHCODE = '" & arrBrCodes(idx) & _
                        "' AND ACTIVITYID='FC'"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction

                        MaxToDate = CStr(objcommand.ExecuteScalar())
                        'MaxToDate = objcommand.ExecuteScalar()

                        If MaxToDate <> "0" Then
                            If CDate(MaxToDate) > ChargeCalcFromDt Then
                                Throw New Exception(" Already Charges Were" & _
                                 " Calculated For The Range of Dates ")
                            End If
                        End If

                        strQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                            "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE," & _
                            "ACTIVITYID,FROMDATE,TODATE,APPLICATIONDATE," & _
                            "UserId,MachineId,STATUS,APPROVEDBY," & _
                            "APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) VALUES" & _
                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & _
                            "','" & ModuleId & "','" & Glcode & "'," & _
                            "'FC','" & Format(ChargeCalcFromDt, _
                            "dd-MMM-yyyy") & "', '" & Format(ChargeCalcToDt, _
                            "dd-MMM-yyyy") & "','" & Format(ApplicationDt, _
                            "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            " '" & MachineId & "','A','SYSTEM','" & MachineId & _
                            "'," & roundOfParam & "," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                          ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data Into" & _
                            " GensystemActivityLog For The Branch " & _
                              arrBrCodes(idx))
                        End If
                    End If   ''' End of FrmAccno Not Null
                    ''Get the CreditGlCode and Credit Account Number
                    'for the respective Debit Gl Code
                    strQuery = "select FOLIOCHARGESGLCODE,FOLIOCHARGESACCNO," & _
                     " ENTRIESPERFOLIO from " & Trim(ModuleId) & "TYPEMST where" & _
                     " MODULEID='" & Trim(ModuleId) & "' and" & _
                     " GLCODE='" & Trim(Glcode) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                            ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC(0)) = False And _
                                      IsDBNull(drCreditGLACC(1)) = False And _
                                      IsDBNull(drCreditGLACC(2)) = False Then
                            CreditGlCode = drCreditGLACC(0)
                            CreditAccNo = drCreditGLACC(1)
                            EntriesPerFolio = drCreditGLACC(2)
                        Else
                            Throw New Exception("Charges Parameters Not Available" & _
                            " For the GL in" & ModuleId & "TYPEMST Table")
                        End If
                    Else
                        Throw New Exception("Charges Parameters Not Available" & _
                        " For the GL in" & ModuleId & " TYPEMST Table")
                    End If
                    drCreditGLACC = Nothing


                    If CkDrCharge = True Then
                        strCkDrCharge = "Y"
                    Else
                        strCkDrCharge = "N"
                    End If


                    '' save the Parameters like creditGlcode,Credit Account No.
                    ' and Round Value,a/c prefix,suffix and its range, entries per folio
                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6," & _
                    "COL7,COL8, col9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & "','" & _
                    MachineId & "','SYSTEM','" & MachineId & "','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcToDt, "dd-MMM-yyyy") & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & FrmAccNo & _
                    "','" & FrmAccSuf & "','" & ToAccNo & "','" & _
                    strCkDrCharge & "','" & EntriesPerFolio & "'," & _
                    i_Batchno & ")"

                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data into" & _
                        " Actual Parameters Table while debiting " & ModuleId & _
                        " Charge")
                    End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    'strQuery = "select moduleid from GENGLMASTMST where" & _
                    '   " BranchCode='" & arrBrCodes(idx) & "' and" & _
                    '   " GLCODE='" & CreditGlCode & "'"
                    strQuery = "select moduleid from GENGLMASTMST where" & _
                               " GLCODE='" & CreditGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.Read Then
                        If IsDBNull(drGetModId(0)) = False Then
                            creditModuleId = drGetModId(0)
                        Else
                            Throw New Exception("Module Id for the GL " & _
                            CreditGlCode & " Not Available")
                        End If
                    Else
                        Throw New Exception("Module Id for the GL " & _
                        CreditGlCode & " Not Available")
                    End If
                    drGetModId = Nothing

                    '' to get credit account name

                    CreditAccName = ""
                    strQuery = "SELECT name FROM " & creditModuleId & "mst WHERE glcode =  '" & CreditGlCode & "' AND accno = '" & CreditAccNo & "' AND branchcode = '" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.HasRows Then
                        If drGetModId.Read Then
                            CreditAccName = IIf(IsDBNull(drGetModId!name), "", drGetModId!name)
                        End If
                    Else
                        CreditAccName = ""
                    End If
                    drGetModId = Nothing
                End If ''' End of Inserting entries into systemactivitylog and actual

                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder
                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                   " '" & CurrencyCode & "', '" & ModuleId & "'," & _
                   " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                         ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnValue = objcommand.ExecuteScalar
                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    Throw New Exception("Unable to get Current Balance" & _
                        " of Debilt GL " & Glcode & " and Accno. " & _
                        arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                Else
                    getDebitBal = CDbl(rtnValue)
                End If


                ''rtnValue = ""
                ''rtnValue = AccBal.GetBalance(arrBrCodes(idx), CurrencyCode, _
                ''Trim(ModuleId), Glcode, arrAccnos(idx))

                ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                ''    Throw New Exception("Error Occured While Getting Current" & _
                ''    "Balance For Given Account Where GLCode = " & Glcode & _
                ''    " And AccountNo = " & arrAccnos(idx) & " And Module id = " & _
                ''    Trim(ModuleId) & "and Branch Code =" & arrBrCodes(idx) & _
                ''    " Currency Code = " & CurrencyCode & " . The Error is " & rtnValue)
                ''Else
                ''    getDebitBal = Val(rtnValue)
                ''End If

                Dim drException As String

                'This checks whether exceptions are accpted or not

                If (getDebitBal - arrTotalCharge(idx)) < 0 Then
                    drException = "Y"
                Else
                    drException = "N"
                End If


                dblDrcharges = 0
                dblGSTamt = 0
                dblCESSamt = 0
                dblTotDrcharges = 0
                dblDrcharges = CDbl(arrTotalCharge(idx))


                If GSTYN = "Y" Then
                    '' to get gst amt
                    dblGSTamt = CDbl(arrTotalCharge(idx) * CDbl(strGSTPercent) / 100)

                    ''to get cess amt
                    If CessYN = "Y" Then
                        dblCESSamt = Math.Round(CDbl(arrTotalCharge(idx) * CDbl(strCessPercent) / 100))
                    End If

                    If GSTYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt
                    End If
                    If CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblCESSamt
                    End If

                    If GSTYN = "Y" And CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt + dblCESSamt
                    End If
                Else
                    dblTotDrcharges = CDbl(arrTotalCharge(idx))
                End If

                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE,CUSTOMERID," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG,LINKMODULEID, LINKGLCODE, LINKACCNO)" & _
                " VALUES('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -1 * dblTotDrcharges & ",'3'," & getDebitBal & "," & _
                " " & getDebitBal & "," & getDebitBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','" & strRemarksDr & "'," & _
                " '1','" & drException & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','FC','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG,LINKMODULEID, LINKGLCODE, LINKACCNO) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -1 * dblTotDrcharges & "," & _
                   " '3'," & getDebitBal & "," & _
                   " " & getDebitBal & "," & getDebitBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','" & strRemarksDr & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','FC','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If


                If GSTYN = "Y" Then

                    '' gst customerid 

                    strGSTIN = ""
                    strGSTCustomerid = ""
                    strRcpName = ""
                    strSql = "SELECT CUSTOMERID,name FROM " & ModuleId & "MST WHERE ACCNO='" & arrAccnos(idx) & "' AND GLCODE='" & Glcode & "' AND " & "BRANCHCODE='" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strGSTCustomerid = IIf(IsDBNull(objDr!CUSTOMERID), "", objDr!CUSTOMERID)
                            strRcpName = IIf(IsDBNull(objDr!name), "", objDr!name)
                        End While
                        ''GSTIN
                        strSql = "SELECT nvl(gstin,'') GSTIN FROM gencustinfomst WHERE customerid = '" & strGSTCustomerid & "'"
                        objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        objDr1 = objcommand.ExecuteReader()
                        If (objDr1.HasRows) Then
                            While (objDr1.Read)
                                strGSTIN = IIf(IsDBNull(objDr1!GSTIN), "", objDr1!GSTIN)
                            End While
                        End If
                        objDr1.Close()
                        objDr1.Dispose()
                        objDr1 = Nothing


                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing


                    '' invoice no
                    strInvoiceNo = ""
                    strSql = "SELECT NVL(MAX(TO_NUMBER(INVOICENO)),0)+1  Invoiceno FROM GSTTNXDTLS WHERE gstcode = 'GSTR'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strInvoiceNo = IIf(IsDBNull(objDr!Invoiceno), "", objDr!Invoiceno)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing

                    '' taxable value

                    strTaxableVal = ""
                    strTaxableVal = Math.Round(CDbl(arrTotalCharge(idx)) + CDbl(dblGSTamt) + CDbl(dblCESSamt), 2)
                    ''GSTTXNDTLS
                    StrInsert = "INSERT INTO gsttnxdtls (BRANCHCODE, CUSTOMERID, GSTCODE, GSTIN, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, " & _
    " REVERSECHARGE, INVOICETYPE, ECOMGSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, BATCHNO, STATUS, APPLICATIONDATE, " & _
    " USERID, MACHINEID, SYSTEMDATE,RECPNAME) VALUES " & _
      "('" & arrBrCodes(idx) & "','" & strGSTCustomerid & "','GSTR','" & strGSTIN & "','" & strInvoiceNo & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & arrTotalCharge(idx) & " ','" & strPOS & "','N','Regular','','" & strGSTPercent & "','" & strTaxableVal & "','" & Math.Round(dblGSTamt / 2, 2) & "','" & Math.Round(dblGSTamt / 2, 2) & "',0,'" & dblCESSamt & "','" & i_Batchno & "','R','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',sysdate,'" & strRcpName & "')"

                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objcommand.ExecuteNonQuery()
                    objcommand.Dispose()
                    objcommand = Nothing
                End If ''GSTYN



                ' sum, credit interest amount of A/c. holders which are existed in
                ' same branch
                sumDrChargeAmount = sumDrChargeAmount + dblDrcharges
                prevBrCode = arrBrCodes(idx)

                If GSTYN = "Y" Then
                    dblTotGSTamt = dblTotGSTamt + dblGSTamt
                    If CessYN = "Y" Then
                        dblTotCESSamt = dblTotCESSamt + dblCESSamt
                    End If
                End If
                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    ''rtnValue = AccBal.GetBalance(prevBrCode, CurrencyCode, _
                    ''creditModuleId, CreditGlCode, CreditAccNo)

                    ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    ''    Throw New Exception("Error Occured While Getting Current" & _
                    ''    "Balance For Given Credit Account Where Credit GLCode = " & _
                    ''    CreditGlCode & " And Credit AccountNo = " & _
                    ''    CreditAccNo & " And Credit Module id = " & creditModuleId & _
                    ''    "and Branch Code =" & prevBrCode & " Currency Code = " & _
                    ''    CurrencyCode & " . The Error is " & rtnValue)
                    ''Else
                    ''    getCreditBal = Val(rtnValue)
                    ''End If

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & CreditGlCode & " and Accno. " & _
                            CreditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If
                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                    strRemarksCr = "Folio Charges From " & ModuleId & " Glcode " & Glcode

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                  " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                    " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                    " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG,CUSTOMERID,NAME)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','" & strRemarksCr & "','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','FC','" & nonCustomerid & "','" & CreditAccName & "')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & "TRANDAY" & _
                      "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                       " EFFECTIVEDATE,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CUSTOMERID,NAME) values(" & _
                       " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                       " '" & creditModuleId & "','" & CreditGlCode & "'," & _
                       " '" & CreditAccNo & "','" & i_Batchno & "'," & _
                       " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                       " '4'," & getCreditBal & "," & _
                       " " & getCreditBal & "," & getCreditBal & "," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'N','Y','" & strRemarksCr & "','1','N'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "'," & _
                       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()
                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If
                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnTranDrQuery = objcommand.ExecuteNonQuery()
                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If


                    '========================================================
                    '''objcommand = New OracleClient.OracleCommand("select count(*) from GENTRANSLOG WHERE BRANCHCODE ='" & _
                    '''arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '''"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'", ObjOracleConnection)
                    '''objcommand.Transaction = objTransaction
                    '''rtnTranDrQuery = objcommand.ExecuteScalar
                    '''If rtnTranDrQuery > 0 Then
                    '''    strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY" & _
                    '''    " SELECT BRANCHCODE," & _
                    '''"CURRENCYCODE,BATCHNO,TRANNO,'1',APPLICATIONDATE,SYSTEMDATE," & _
                    '''"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDDATE,APPROVEDSYSTEMDATE," & _
                    '''"VERIFIEDSYSTEMDATE FROM GENTRANSLOG WHERE BRANCHCODE ='" & _
                    '''arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '''"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'"

                    '''    objcommand = New OracleClient.OracleCommand(strQuery, _
                    '''                                                ObjOracleConnection)
                    '''    objcommand.Transaction = objTransaction
                    '''    objcommand.ExecuteNonQuery()
                    '''End If

                    '' gst value

                    If GSTYN = "Y" Then

                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                              "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                              "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                              "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                              "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                              "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                              "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                              "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                              "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                              "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                              "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                              "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                              "ABBYN"

                        ''CGST
                        strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strCGSTAmt) <> 0 Then
                            strChqFvg = "CGST"

                            dblCGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                 " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblCGSTBal = 0
                            Else
                                dblCGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If
                        '' SGST
                        strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strSGSTAmt) <> 0 Then
                            strChqFvg = "SGST"
                            dblSGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                 " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblSGSTBal = 0
                            Else
                                dblSGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If

                        If CessYN = "Y" Then
                            If CDbl(dblTotCESSamt) <> 0 Then
                                ''CESS Amount
                                strChqFvg = "CESS"
                                dblCESSBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                     " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCESSBal = 0
                                Else
                                    dblCESSBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Trans  Log ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                        End If '' cessyn
                    End If '' gstyn


                End If
            Next ''' End of Credit Interest Posting




            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ")"

                'SHARATH  ----------------------------
                'objHist.recordInHist(Trim(ModuleId) & "MST","LASTINTCALCDATE", _
                'ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                'strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                objHist.recordInHist(Trim(ModuleId) & "CHARGEDATEDTLS", _
                "LASTCHARGECALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                ' SHARATH ---------------------------------
                '  strQuery = "update " & Trim(ModuleId) & "MST set" & _
                ' " OPPLASTINTCALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                ' "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                ' " GLCODE ='" & Glcode & "' and" & _
                ' " (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") "

                strQuery = "update " & Trim(ModuleId) & "CHARGEDATEDTLS set" & _
                " LASTCHARGECALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and (BRANCHCODE,ACCNO) in(" & _
                BulkArr(i) & ")  AND CHARGETYPE='FC'"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                'If i_NoOfRows <> (UBound(arrAccnos) + 1) Then
                'Throw New Exception("Unable to Modify The LastIntCalcDate While" & _
                '" Crediting Interest")
                'End If

                '' inserting  charges posted accs. details 
                strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") AND CHARGETYPE='" & _
                ChargeType & "'"

                strQuery = "insert into " & Trim(ModuleId) & _
                 "CHARGEPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                 " MODULEID,GLCODE, ACCNO, VARCHARCOL1, CHRGCALCFROMDT," & _
                 " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                 " CURRENCYCOL2,USERID," & _
                 " MACHINEID,APPLICATIONDATE," & _
                 " VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                 " DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                 " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                 " VARCHARCOL1, CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                 " CURRENCYCOL2, '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                 MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                 "CHRGCALCTEMP where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

            Next i

            'BULK OPERATIONS For not posted accno. STARTS FROM HERE
            For j = 0 To (BulkArrIdxNP - 1)

                '' inserting Interest Not posted accno. details (missing accnos.)

                strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) IN (" & BulkArrNP(j) & _
                ") AND CHARGETYPE='" & ChargeType & "'"

                'and  (currencycode,GLCODE,CHRGCALCFROMDT,CHRGCALCTODT," & _
                '               " USERID,MACHINEID,APPLICATIONDATE,BRANCHCODE,ACCNO,CHARGETYPE) not in (select currencycode,GLCODE,CHRGCALCFROMDT,CHRGCALCTODT," & _
                '              " USERID,MACHINEID,APPLICATIONDATE,BRANCHCODE,ACCNO,CHARGETYPE from " & Trim(ModuleId) & "CHRGCALCTEMP "

                strQuery = "insert into  " & Trim(ModuleId) & _
                "CHARGENOTPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                " MODULEID,GLCODE, ACCNO, VARCHARCOL1, CHRGCALCFROMDT," & _
                " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                " CURRENCYCOL2,USERID," & _
                " MACHINEID,APPLICATIONDATE," & _
                " VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                " DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                " VARCHARCOL1, CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                " CURRENCYCOL2, '" & UserId & "','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                "CHRGCALCTEMP where " & strIntDtlsNotPosted

                objcommand = New OracleClient.OracleCommand(strQuery, _
                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
            Next j

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCADebitFolioCharges = True

            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCADebitFolioCharges = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCADebitFolioCharges"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCAFolioCharges Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCAFolioCharges Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function
    Public Function PostSBCADebitMinBalCharges(ByVal CurrencyCode As String, _
                      ByVal ModuleId As String, ByVal Glcode As String, _
                      ByVal ChargeCalcFromDt As Date, _
                      ByVal ChargeCalcToDt As Date, ByVal roundOfParam As Double, _
                      ByVal UserId As String, ByVal ApplicationDt As Date, _
                      ByVal MachineId As String, ByVal arrVals() As Object, _
                      ByVal CkDrCharge As Boolean, ByVal ChargeType As String, _
                      ByRef o_ErrMsg As String, _
                      Optional ByVal BranchCode As String = "", _
                      Optional ByVal FrmAccPre As String = "", _
                      Optional ByVal FrmAccNo As String = "", _
                      Optional ByVal FrmAccSuf As String = "", _
                      Optional ByVal ToAccNo As String = "", Optional ByVal strGSTYN As String = "") As Boolean


        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
            As String

        Dim strInsertCond, strCkDrCharge, strQuery, i_Batchno, i_TranNo As _
            String

        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery As _
            Integer

        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrCustids, arrTotalCharge, arrCurBalance, arrAccNames _
            As Object

        Dim prevBrCode, CreditGlCode, CreditAccNo, creditModuleId, _
            genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, _
            strProdDtlsCond, strIntDtlsNotPosted As String


        Dim getDebitBal, getCreditBal, sumDrChargeAmount, entryDebitAmount As _
            Double
        Dim CreditAccName As String
        sumDrChargeAmount = 0
        dblTotGSTamt = 0
        dblTotCESSamt = 0
        Dim dblCGSTBal, dblSGSTBal, dblCESSBal As Double

        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim AccBal As AccountDetailsRCW.AccDetailsClass
        'AccBal = New AccountDetailsRCW.AccDetailsClass

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer

        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If

            GSTYN = strGSTYN
            GSTParameters("MBC", BranchCode)

            arrBrCodes = Split(arrVals(0), ",")
            arrAccnos = Split(arrVals(1), ",")
            arrCustids = Split(arrVals(2), ",")
            arrAccNames = Split(arrVals(3), ",")
            arrCurBalance = Split(arrVals(4), ",")
            arrTotalCharge = Split(arrVals(5), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit Entries
                    ' into respective tables

                    If prevBrCode <> "" Then
                        'Get current balance of credit Account

                        strQuery = "select GETANYDAYBAL('" & prevBrCode & _
                        "','" & CurrencyCode & "', '" & creditModuleId & _
                        "','" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') " & _
                        "from dual"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                         ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar

                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current " & _
                                "Balance of Credit GL " & CreditGlCode & _
                                " and Accno. " & CreditAccNo & ". " & _
                                vbNewLine & rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If


                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                        strRemarksCr = "Min Bal Charges From " & ModuleId & " Glcode " & Glcode

                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,chqfvg,CUSTOMERID,NAME)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                        " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                        " " & getCreditBal & "," & getCreditBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','" & strRemarksCr & "','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','MBC','" & nonCustomerid & "','" & CreditAccName & "')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & _
                        "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CUSTOMERID,NAME) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & CreditGlCode & _
                             "','" & CreditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','" & strRemarksCr & "','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log For The Branch " & arrBrCodes(idx))
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & _
                            " Tran Day For The Branch " & arrBrCodes(idx))
                        End If


                        '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT" & _
                        '''" BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,'1'," & _
                        '''"APPLICATIONDATE,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE," & _
                        '''"APPROVEDDATE,APPROVEDSYSTEMDATE,VERIFIEDSYSTEMDATE WHERE " & _
                        '''"BRANCHCODE ='" & arrBrCodes(idx) & " AND CURRENCYCODE ='" & _
                        '''CurrencyCode & " AND BATCHNO= " & i_Batchno & "AND " & _
                        '''" EXCEPTIONYN='Y'"

                        '''objcommand = New OracleClient.OracleCommand(strQuery, _
                        '''                                            ObjOracleConnection)
                        '''objcommand.Transaction = objTransaction
                        '''objcommand.ExecuteNonQuery()


                        '' gst value

                        If GSTYN = "Y" Then

                            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                                  "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                                  "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                                  "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                                  "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                                  "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                                  "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                                  "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                                  "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                                  "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                                  "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                                  "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                                  "ABBYN"

                            ''CGST
                            strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strCGSTAmt) <> 0 Then
                                strChqFvg = "CGST"

                                dblCGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                     " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCGSTBal = 0
                                Else
                                    dblCGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                            '' SGST
                            strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strSGSTAmt) <> 0 Then
                                strChqFvg = "SGST"
                                dblSGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                     " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblSGSTBal = 0
                                Else
                                    dblSGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If

                            If CessYN = "Y" Then
                                If CDbl(dblTotCESSamt) <> 0 Then
                                    ''CESS Amount
                                    strChqFvg = "CESS"
                                    dblCESSBal = 0
                                    strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                         " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                         " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                         " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    rtnValue = objcommand.ExecuteScalar
                                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                        dblCESSBal = 0
                                    Else
                                        dblCESSBal = CDbl(rtnValue)
                                    End If

                                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Trans  Log ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing

                                    StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Tran Day ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing
                                End If
                            End If '' cessyn
                        End If '' gstyn

                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()

                    Dim MaxToDate As String

                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                        strQuery = "select NVL(to_char(MAX(TODATE)),0) from " & _
                        " GENSYSTEMACTIVITYLOG WHERE MODULEID='" & Trim(ModuleId) & _
                        "' and" & _
                        " GLCODE='" & Trim(Glcode) & "' AND CURRENCYCODE = '" & _
                        CurrencyCode & "' AND BRANCHCODE = '" & arrBrCodes(idx) & _
                        "' AND ACTIVITYID='MBC'"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction

                        MaxToDate = CStr(objcommand.ExecuteScalar())


                        If MaxToDate <> "0" Then
                            If CDate(MaxToDate) > ChargeCalcFromDt Then
                                Throw New Exception(" Already Charges Were" & _
                                 " Calculated For The Range of Dates ")
                            End If
                        End If

                        strQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                            "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE," & _
                            "ACTIVITYID,FROMDATE,TODATE,APPLICATIONDATE," & _
                            "UserId,MachineId,STATUS,APPROVEDBY," & _
                            "APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) VALUES" & _
                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & _
                            "','" & ModuleId & "','" & Glcode & "'," & _
                            "'MBC','" & Format(ChargeCalcFromDt, _
                            "dd-MMM-yyyy") & "', '" & Format(ChargeCalcToDt, _
                            "dd-MMM-yyyy") & "','" & Format(ApplicationDt, _
                            "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            " '" & MachineId & "','A','SYSTEM','" & MachineId _
                            & "'," & roundOfParam & "," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                          ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()

                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data " & _
                            "Into GensystemActivityLog For The Branch " & _
                            arrBrCodes(idx))
                        End If
                    End If  ''' End of FrmAccno Not Null

                    ''Get the CreditGlCode and Credit Account Number
                    'for the respective Debit Gl Code

                    strQuery = "select MINBALGLCODE,MINBALACCNO" & _
                     " from " & Trim(ModuleId) & "TYPEMST where" & _
                     " MODULEID='" & Trim(ModuleId) & "' and" & _
                     " GLCODE='" & Trim(Glcode) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC(0)) = False And _
                                      IsDBNull(drCreditGLACC(1)) = False Then
                            CreditGlCode = drCreditGLACC(0)
                            CreditAccNo = drCreditGLACC(1)
                        Else
                            Throw New Exception("Charges Parameters Not " & _
                            "Available For the GL in" & ModuleId & "TYPEMST ")
                        End If
                    Else
                        Throw New Exception("Charges Parameters Not " & _
                        "Available For the GL in" & ModuleId & " TYPEMST ")

                    End If

                    drCreditGLACC = Nothing

                    If CkDrCharge = True Then
                        strCkDrCharge = "Y"
                    Else
                        strCkDrCharge = "N"
                    End If


                    '' save the Parameters like creditGlcode,Credit Account No.
                    ' and Round Value,a/c prefix,suffix and its range, entries per folio
                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5," & _
                    "COL6,COL7,COL8,col9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & _
                    "','" & MachineId & "','SYSTEM','" & MachineId & _
                    "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcToDt, "dd-MMM-yyyy") & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & _
                    FrmAccNo & "','" & FrmAccSuf & "','" & ToAccNo & _
                    "','" & strCkDrCharge & "',''," & i_Batchno & ")"


                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)

                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery

                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data " & _
                        "into Actual Parameters Table while debiting " & _
                        ModuleId & " Charge")
                    End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    strQuery = "select moduleid from GENGLMASTMST where" & _
                               " GLCODE='" & CreditGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader

                    If drGetModId.Read Then
                        If IsDBNull(drGetModId(0)) = False Then
                            creditModuleId = drGetModId(0)
                        Else
                            Throw New Exception("Module Id for the GL " & _
                            CreditGlCode & " Not Available")
                        End If
                    Else
                        Throw New Exception("Module Id for the GL " & _
                        CreditGlCode & " Not Available")
                    End If
                    drGetModId = Nothing

                    '' to get credit account name

                    CreditAccName = ""
                    strQuery = "SELECT name FROM " & creditModuleId & "mst WHERE glcode =  '" & CreditGlCode & "' AND accno = '" & CreditAccNo & "' AND branchcode = '" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.HasRows Then
                        If drGetModId.Read Then
                            CreditAccName = IIf(IsDBNull(drGetModId!name), "", drGetModId!name)
                        End If
                    Else
                        CreditAccName = ""
                    End If
                    drGetModId = Nothing

                End If ''' End of Inserting entries into systemactivitylog and actual



                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder

                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                   " '" & CurrencyCode & "', '" & ModuleId & "'," & _
                   " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                         ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnValue = objcommand.ExecuteScalar

                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    Throw New Exception("Unable to get Current Balance" & _
                        " of Debilt GL " & Glcode & " and Accno. " & _
                        arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                Else
                    getDebitBal = CDbl(rtnValue)
                End If

                Dim drException As String

                'This checks whether exceptions are accpted or not

                If (getDebitBal - arrTotalCharge(idx)) < 0 Then
                    drException = "Y"
                Else
                    drException = "N"
                End If

                '' GST Value
                dblDrcharges = 0
                dblGSTamt = 0
                dblCESSamt = 0
                dblTotDrcharges = 0
                dblDrcharges = CDbl(arrTotalCharge(idx))

                If GSTYN = "Y" Then
                    '' to get gst amt
                    dblGSTamt = CDbl(arrTotalCharge(idx) * CDbl(strGSTPercent) / 100)

                    ''to get cess amt
                    If CessYN = "Y" Then
                        dblCESSamt = Math.Round(CDbl(arrTotalCharge(idx) * CDbl(strCessPercent) / 100))
                    End If

                    If GSTYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt
                    End If
                    If CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblCESSamt
                    End If

                    If GSTYN = "Y" And CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt + dblCESSamt
                    End If
                Else
                    dblTotDrcharges = CDbl(arrTotalCharge(idx))
                End If


                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO," & _
                "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                "APPROVEDTIMEBAL,EFFECTIVEDATE,CUSTOMERID,NAME,CASHPAIDYN," & _
                " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG,LINKMODULEID, LINKGLCODE, LINKACCNO)" & _
                " VALUES('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -dblTotDrcharges & ",'3'," & getDebitBal & "," & _
                " " & getDebitBal & "," & getDebitBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','" & strRemarksDr & "'," & _
                " '1','" & drException & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','MBC','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG,LINKMODULEID, LINKGLCODE, LINKACCNO) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -dblTotDrcharges & "," & _
                   " '3'," & getDebitBal & "," & _
                   " " & getDebitBal & "," & getDebitBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','" & strRemarksDr & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','MBC','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If


                If GSTYN = "Y" Then

                    '' gst customerid 

                    strGSTIN = ""
                    strGSTCustomerid = ""
                    strRcpName = ""
                    strSql = "SELECT CUSTOMERID,name FROM " & ModuleId & "MST WHERE ACCNO='" & arrAccnos(idx) & "' AND GLCODE='" & Glcode & "' AND " & "BRANCHCODE='" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strGSTCustomerid = IIf(IsDBNull(objDr!CUSTOMERID), "", objDr!CUSTOMERID)
                            strRcpName = IIf(IsDBNull(objDr!name), "", objDr!name)
                        End While
                        ''GSTIN
                        strSql = "SELECT nvl(gstin,'') GSTIN FROM gencustinfomst WHERE customerid = '" & strGSTCustomerid & "'"
                        objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        objDr1 = objcommand.ExecuteReader()
                        If (objDr1.HasRows) Then
                            While (objDr1.Read)
                                strGSTIN = IIf(IsDBNull(objDr1!GSTIN), "", objDr1!GSTIN)
                            End While
                        End If
                        objDr1.Close()
                        objDr1.Dispose()
                        objDr1 = Nothing


                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing


                    '' invoice no

                    strInvoiceNo = ""
                    strSql = "SELECT NVL(MAX(TO_NUMBER(INVOICENO)),0)+1  Invoiceno FROM GSTTNXDTLS WHERE gstcode = 'GSTR'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strInvoiceNo = IIf(IsDBNull(objDr!Invoiceno), "", objDr!Invoiceno)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing

                    '' taxable value

                    strTaxableVal = ""
                    strTaxableVal = Math.Round(CDbl(arrTotalCharge(idx)) + CDbl(dblGSTamt) + CDbl(dblCESSamt), 2)
                    ''GSTTXNDTLS
                    StrInsert = "INSERT INTO gsttnxdtls (BRANCHCODE, CUSTOMERID, GSTCODE, GSTIN, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, " & _
    " REVERSECHARGE, INVOICETYPE, ECOMGSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, BATCHNO, STATUS, APPLICATIONDATE, " & _
    " USERID, MACHINEID, SYSTEMDATE,RECPNAME) VALUES " & _
      "('" & arrBrCodes(idx) & "','" & strGSTCustomerid & "','GSTR','" & strGSTIN & "','" & strInvoiceNo & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & arrTotalCharge(idx) & " ','" & strPOS & "','N','Regular','','" & strGSTPercent & "','" & strTaxableVal & "','" & Math.Round(dblGSTamt / 2, 2) & "','" & Math.Round(dblGSTamt / 2, 2) & "',0,'" & dblCESSamt & "','" & i_Batchno & "','R','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',sysdate,'" & strRcpName & "')"

                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objcommand.ExecuteNonQuery()
                    objcommand.Dispose()
                    objcommand = Nothing
                End If ''GSTYN



                ' sum, credit amount of A/c. holders which are existed in
                ' same branch
                sumDrChargeAmount = sumDrChargeAmount + dblDrcharges

                If GSTYN = "Y" Then
                    dblTotGSTamt = dblTotGSTamt + dblGSTamt
                    If CessYN = "Y" Then
                        dblTotCESSamt = dblTotCESSamt + dblCESSamt
                    End If
                End If

                prevBrCode = arrBrCodes(idx)

                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                     "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & CreditGlCode & " and Accno " & _
                            CreditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If

                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    strRemarksCr = "Min Bal Charges From " & ModuleId & " Glcode " & Glcode

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE, " & _
                    "CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO, " & _
                    "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                    "APPROVEDTIMEBAL,EFFECTIVEDATE,CASHPAIDYN, " & _
                    "SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG,CUSTOMERID,NAME)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','" & strRemarksCr & "','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','MBC','" & nonCustomerid & "','" & CreditAccName & "')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & _
                    "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    "ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                    "ENTEREDTIMEBAL,VERIFIEDTIMEBAL,APPROVEDTIMEBAL, " & _
                    "EFFECTIVEDATE,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS, " & _
                    "SERVICEID,EXCEPTIONYN,APPLICATIONDATE,USERID, " & _
                    "MACHINEID,TRANSTATUS, APPROVEDDATE,APPROVEDBY, " & _
                    "APPROVEDMACHINE,CUSTOMERID,NAME) values('" & arrBrCodes(idx) & "','" & _
                    CurrencyCode & "','" & creditModuleId & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & i_Batchno & _
                    "','" & i_TranNo & "'," & sumDrChargeAmount & ",'4'," & _
                    getCreditBal & "," & getCreditBal & "," & getCreditBal & _
                    ",'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','N'," & _
                    " 'Y','" & strRemarksCr & "','1','N','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & _
                    "','" & MachineId & "','A','" & Format(ApplicationDt, _
                    "dd-MMM-yyyy") & "', 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()

                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If

                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction

                    rtnTranDrQuery = objcommand.ExecuteNonQuery()

                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If

                    '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT BRANCHCODE," & _
                    '''"CURRENCYCODE,BATCHNO,TRANNO,'1',APPLICATIONDATE,SYSTEMDATE," & _
                    '''"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDDATE,APPROVEDSYSTEMDATE," & _
                    '''"VERIFIEDSYSTEMDATE FROM GENTRANSLOG WHERE BRANCHCODE ='" & _
                    '''arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '''"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'"

                    '''objcommand = New OracleClient.OracleCommand(strQuery, _
                    '''                                            ObjOracleConnection)
                    '''objcommand.Transaction = objTransaction
                    '''objcommand.ExecuteNonQuery()

                    '' gst value

                    If GSTYN = "Y" Then

                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                              "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                              "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                              "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                              "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                              "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                              "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                              "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                              "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                              "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                              "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                              "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                              "ABBYN"

                        ''CGST
                        strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strCGSTAmt) <> 0 Then
                            strChqFvg = "CGST"

                            dblCGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                 " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblCGSTBal = 0
                            Else
                                dblCGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If
                        '' SGST
                        strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strSGSTAmt) <> 0 Then
                            strChqFvg = "SGST"
                            dblSGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                 " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblSGSTBal = 0
                            Else
                                dblSGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If

                        If CessYN = "Y" Then
                            If CDbl(dblTotCESSamt) <> 0 Then
                                ''CESS Amount
                                strChqFvg = "CESS"
                                dblCESSBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                     " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCESSBal = 0
                                Else
                                    dblCESSBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Trans  Log ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & strRemarksCr & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                        End If '' cessyn
                    End If '' gstyn


                End If
            Next ''' End of Debit MinBal Posting



            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & _
                    ") AND CHARGETYPE='MBC'"

                objHist.recordInHist(Trim(ModuleId) & "CHARGEDATEDTLS", _
                "LASTCHARGECALCDATE", ObjOracleConnection, objTransaction, _
                o_ErrMsg, rowcount, strWherecond, BranchCode, UserId, _
                MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If

                '------it is a temperory code 
                'Dim ChargeCalcDt As Date

                'If ChargeCalcToDt = ApplicationDt Then
                'ChargeCalcDt = DateAdd(DateInterval.Day, -1, _
                '                  ChargeCalcToDt)
                'End If

                'Charges are updating to -1 of ApplicationDt for getting 
                '   those records in next calculation (Bcoz., Tran 
                '   Effectivedate>LastChrgCalcDate)
                'To Accept Current Day Transactions
                '------it is a temporary code

                strQuery = "update " & Trim(ModuleId) & "CHARGEDATEDTLS set" & _
                " LASTCHARGECALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and (BRANCHCODE,ACCNO) in(" & _
                BulkArr(i) & ") AND CHARGETYPE='MBC'"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                '' inserting  charges posted accs. details 
                strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") AND CHARGETYPE='" & _
                ChargeType & "'"

                strQuery = "insert into " & Trim(ModuleId) & _
                 "CHARGEPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                 " MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                 " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3,USERID,MACHINEID,APPLICATIONDATE," & _
                 " VARCHARCOL3,VARCHARCOL4,APPROVEDBY, DATECOL1, " & _
                 "APPROVEDMACHINE,CHARGETYPE) " & _
                 " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                 " CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                 MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                 "CHRGCALCTEMP where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                '' inserting Interest Not posted accno. details (missing accnos.)

                strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) NOT IN (" & BulkArr(i) & _
                ") AND CHARGETYPE='" & ChargeType & "'"

                strQuery = "insert into  " & Trim(ModuleId) & _
                "CHARGENOTPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                " MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                " CURRENCYCOL3,USERID," & _
                " MACHINEID,APPLICATIONDATE," & _
                " VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                " DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                " CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                " CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                "CHRGCALCTEMP where " & strIntDtlsNotPosted

                objcommand = New OracleClient.OracleCommand(strQuery, _
                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCADebitMinBalCharges = True
            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCADebitMinBalCharges = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCADebitMinBalCharges"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCA Minimum Balance Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCAMinBalCharges Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Function PostSBCABankCharges(ByVal CurrencyCode As String, _
                  ByVal ModuleId As String, ByVal Glcode As String, _
                  ByVal ChargeCalcFromDt As Date, _
                  ByVal ChargeCalcToDt As Date, ByVal roundOfParam As Double, _
                  ByVal UserId As String, ByVal ApplicationDt As Date, _
                  ByVal MachineId As String, ByVal arrVals() As Object, _
                   ByVal ChargeType As String, _
                  ByRef o_ErrMsg As String, _
                  Optional ByVal BranchCode As String = "", _
                  Optional ByVal FrmAccPre As String = "", _
                  Optional ByVal FrmAccNo As String = "", _
                  Optional ByVal FrmAccSuf As String = "", _
                  Optional ByVal ToAccNo As String = "", Optional ByVal remarks As String = "", Optional ByVal strGSTYN As String = "") As Boolean


        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos, stRemark _
            As String

        Dim strInsertCond, strCkDrCharge, strQuery, i_Batchno, i_TranNo As _
            String

        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery As _
            Integer

        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrCustids, arrTotalCharge, arrCurBalance, arrAccNames _
            As Object

        Dim prevBrCode, CreditGlCode, CreditAccNo, creditModuleId, _
            genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, _
            strProdDtlsCond, strIntDtlsNotPosted As String


        Dim getDebitBal, getCreditBal, sumDrChargeAmount, entryDebitAmount As _
            Double
        Dim CreditAccName As String
        sumDrChargeAmount = 0
        dblTotGSTamt = 0
        dblTotCESSamt = 0
        Dim dblCGSTBal, dblSGSTBal, dblCESSBal As Double
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim AccBal As AccountDetailsRCW.AccDetailsClass
        'AccBal = New AccountDetailsRCW.AccDetailsClass

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer

        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If

            GSTYN = strGSTYN
            GSTParameters("", BranchCode)

            arrBrCodes = Split(arrVals(0), ",")
            arrAccnos = Split(arrVals(1), ",")
            arrCustids = Split(arrVals(2), ",")
            arrAccNames = Split(arrVals(3), ",")
            arrCurBalance = Split(arrVals(4), ",")
            arrTotalCharge = Split(arrVals(5), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            stRemark = remarks

            If stRemark <> "" Then
                stRemark = stRemark
            Else
                stRemark = "Min Bal Charges Posting"
            End If


            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit Entries
                    ' into respective tables

                    If prevBrCode <> "" Then
                        'Get current balance of credit Account

                        strQuery = "select GETANYDAYBAL('" & prevBrCode & _
                        "','" & CurrencyCode & "', '" & creditModuleId & _
                        "','" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') " & _
                        "from dual"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                         ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar

                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current " & _
                                "Balance of Credit GL " & CreditGlCode & _
                                " and Accno. " & CreditAccNo & ". " & _
                                vbNewLine & rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If


                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CUSTOMERID,NAME)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                        " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                        " " & getCreditBal & "," & getCreditBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','" & stRemark & "','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & CreditAccName & "')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & _
                        "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CUSTOMERID,NAME) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & CreditGlCode & _
                             "','" & CreditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','" & stRemark & "','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log For The Branch " & arrBrCodes(idx))
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & _
                            " Tran Day For The Branch " & arrBrCodes(idx))
                        End If


                        '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT" & _
                        '''" BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,'1'," & _
                        '''"APPLICATIONDATE,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE," & _
                        '''"APPROVEDDATE,APPROVEDSYSTEMDATE,VERIFIEDSYSTEMDATE WHERE " & _
                        '''"BRANCHCODE ='" & arrBrCodes(idx) & " AND CURRENCYCODE ='" & _
                        '''CurrencyCode & " AND BATCHNO= " & i_Batchno & "AND " & _
                        '''" EXCEPTIONYN='Y'"

                        '''objcommand = New OracleClient.OracleCommand(strQuery, _
                        '''                                            ObjOracleConnection)
                        '''objcommand.Transaction = objTransaction
                        '''objcommand.ExecuteNonQuery()

                        '' gst value

                        If GSTYN = "Y" Then

                            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                                  "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                                  "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                                  "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                                  "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                                  "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                                  "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                                  "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                                  "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                                  "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                                  "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                                  "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                                  "ABBYN"

                            ''CGST
                            strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strCGSTAmt) <> 0 Then
                                strChqFvg = "CGST"

                                dblCGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                     " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCGSTBal = 0
                                Else
                                    dblCGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                            '' SGST
                            strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strSGSTAmt) <> 0 Then
                                strChqFvg = "SGST"
                                dblSGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                     " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblSGSTBal = 0
                                Else
                                    dblSGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If

                            If CessYN = "Y" Then
                                If CDbl(dblTotCESSamt) <> 0 Then
                                    ''CESS Amount
                                    strChqFvg = "CESS"
                                    dblCESSBal = 0
                                    strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                         " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                         " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                         " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    rtnValue = objcommand.ExecuteScalar
                                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                        dblCESSBal = 0
                                    Else
                                        dblCESSBal = CDbl(rtnValue)
                                    End If

                                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Trans  Log ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing

                                    StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Tran Day ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing
                                End If
                            End If '' cessyn
                        End If '' gstyn


                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()

                    Dim MaxToDate As String

                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                        strQuery = "select NVL(to_char(MAX(TODATE)),0) from " & _
                        " GENSYSTEMACTIVITYLOG WHERE MODULEID='" & Trim(ModuleId) & _
                        "' and" & _
                        " GLCODE='" & Trim(Glcode) & "' AND CURRENCYCODE = '" & _
                        CurrencyCode & "' AND BRANCHCODE = '" & arrBrCodes(idx) & _
                        "' AND ACTIVITYID='GBC'"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction

                        MaxToDate = CStr(objcommand.ExecuteScalar())


                        If MaxToDate <> "0" Then
                            If CDate(MaxToDate) > ChargeCalcFromDt Then
                                Throw New Exception(" Already Charges Were" & _
                                 " Calculated For The Range of Dates ")
                            End If
                        End If

                        strQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                            "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE," & _
                            "ACTIVITYID,FROMDATE,TODATE,APPLICATIONDATE," & _
                            "UserId,MachineId,STATUS,APPROVEDBY," & _
                            "APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) VALUES" & _
                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & _
                            "','" & ModuleId & "','" & Glcode & "'," & _
                            "'GBC','" & Format(ChargeCalcFromDt, _
                            "dd-MMM-yyyy") & "', '" & Format(ChargeCalcToDt, _
                            "dd-MMM-yyyy") & "','" & Format(ApplicationDt, _
                            "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            " '" & MachineId & "','A','SYSTEM','" & MachineId _
                            & "'," & roundOfParam & "," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                          ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()

                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data " & _
                            "Into GensystemActivityLog For The Branch " & _
                            arrBrCodes(idx))
                        End If
                    End If  ''' End of FrmAccno Not Null

                    ''Get the CreditGlCode and Credit Account Number
                    'for the respective Debit Gl Code

                    strQuery = "select BNKSRVGLCODE,BNKSRVACCNO" & _
                     " from " & Trim(ModuleId) & "TYPEMST where" & _
                     " MODULEID='" & Trim(ModuleId) & "' and" & _
                     " GLCODE='" & Trim(Glcode) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC(0)) = False And _
                                      IsDBNull(drCreditGLACC(1)) = False Then
                            CreditGlCode = drCreditGLACC(0)
                            CreditAccNo = drCreditGLACC(1)
                        Else
                            Throw New Exception("Charges Parameters Not " & _
                            "Available For the GL in" & ModuleId & "TYPEMST ")
                        End If
                    Else
                        Throw New Exception("Charges Parameters Not " & _
                        "Available For the GL in" & ModuleId & " TYPEMST ")

                    End If

                    drCreditGLACC = Nothing


                    strCkDrCharge = ""

                    '' save the Parameters like creditGlcode,Credit Account No.
                    ' and Round Value,a/c prefix,suffix and its range, entries per folio
                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5," & _
                    "COL6,COL7,COL8,col9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & _
                    "','" & MachineId & "','SYSTEM','" & MachineId & _
                    "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcToDt, "dd-MMM-yyyy") & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & _
                    FrmAccNo & "','" & FrmAccSuf & "','" & ToAccNo & _
                    "','" & strCkDrCharge & "',''," & i_Batchno & ")"


                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)

                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery

                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data " & _
                        "into Actual Parameters Table while debiting " & _
                        ModuleId & " Charge")
                    End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    strQuery = "select moduleid from GENGLMASTMST where" & _
                               " GLCODE='" & CreditGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader

                    If drGetModId.Read Then
                        If IsDBNull(drGetModId(0)) = False Then
                            creditModuleId = drGetModId(0)
                        Else
                            Throw New Exception("Module Id for the GL " & _
                            CreditGlCode & " Not Available")
                        End If
                    Else
                        Throw New Exception("Module Id for the GL " & _
                        CreditGlCode & " Not Available")
                    End If
                    drGetModId = Nothing

                    '' to get credit account name

                    CreditAccName = ""
                    strQuery = "SELECT name FROM " & creditModuleId & "mst WHERE glcode =  '" & CreditGlCode & "' AND accno = '" & CreditAccNo & "' AND branchcode = '" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.HasRows Then
                        If drGetModId.Read Then
                            CreditAccName = IIf(IsDBNull(drGetModId!name), "", drGetModId!name)
                        End If
                    Else
                        CreditAccName = ""
                    End If
                    drGetModId = Nothing

                End If ''' End of Inserting entries into systemactivitylog and actual

                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder

                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                   " '" & CurrencyCode & "', '" & ModuleId & "'," & _
                   " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                         ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnValue = objcommand.ExecuteScalar

                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    Throw New Exception("Unable to get Current Balance" & _
                        " of Debilt GL " & Glcode & " and Accno. " & _
                        arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                Else
                    getDebitBal = CDbl(rtnValue)
                End If

                Dim drException As String

                'This checks whether exceptions are accpted or not

                If (getDebitBal - arrTotalCharge(idx)) < 0 Then
                    drException = "Y"
                Else
                    drException = "N"
                End If

                dblDrcharges = 0
                dblGSTamt = 0
                dblCESSamt = 0
                dblTotDrcharges = 0
                dblDrcharges = CDbl(arrTotalCharge(idx))

                If GSTYN = "Y" Then
                    '' to get gst amt
                    dblGSTamt = CDbl(arrTotalCharge(idx) * CDbl(strGSTPercent) / 100)

                    ''to get cess amt
                    If CessYN = "Y" Then
                        dblCESSamt = Math.Round(CDbl(arrTotalCharge(idx) * CDbl(strCessPercent) / 100))
                    End If

                    If GSTYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt
                    End If
                    If CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblCESSamt
                    End If

                    If GSTYN = "Y" And CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt + dblCESSamt
                    End If
                Else
                    dblTotDrcharges = CDbl(arrTotalCharge(idx))
                End If


                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO," & _
                "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                "APPROVEDTIMEBAL,EFFECTIVEDATE,CUSTOMERID,NAME,CASHPAIDYN," & _
                " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,LINKMODULEID, LINKGLCODE, LINKACCNO)" & _
                " VALUES('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -1 * dblTotDrcharges & ",'3'," & getDebitBal & "," & _
                " " & getDebitBal & "," & getDebitBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','" & stRemark & "'," & _
                " '1','" & drException & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,LINKMODULEID, LINKGLCODE, LINKACCNO) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -1 * dblTotDrcharges & "," & _
                   " '3'," & getDebitBal & "," & _
                   " " & getDebitBal & "," & getDebitBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','" & stRemark & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If

                If GSTYN = "Y" Then

                    '' gst customerid 

                    strGSTIN = ""
                    strGSTCustomerid = ""
                    strRcpName = ""
                    strSql = "SELECT CUSTOMERID,name FROM " & ModuleId & "MST WHERE ACCNO='" & arrAccnos(idx) & "' AND GLCODE='" & Glcode & "' AND " & "BRANCHCODE='" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strGSTCustomerid = IIf(IsDBNull(objDr!CUSTOMERID), "", objDr!CUSTOMERID)
                            strRcpName = IIf(IsDBNull(objDr!name), "", objDr!name)
                        End While
                        ''GSTIN
                        strSql = "SELECT nvl(gstin,'') GSTIN FROM gencustinfomst WHERE customerid = '" & strGSTCustomerid & "'"
                        objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        objDr1 = objcommand.ExecuteReader()
                        If (objDr1.HasRows) Then
                            While (objDr1.Read)
                                strGSTIN = IIf(IsDBNull(objDr1!GSTIN), "", objDr1!GSTIN)
                            End While
                        End If
                        objDr1.Close()
                        objDr1.Dispose()
                        objDr1 = Nothing


                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing


                    '' invoice no
                    strInvoiceNo = ""
                    strSql = "SELECT NVL(MAX(TO_NUMBER(INVOICENO)),0)+1  Invoiceno FROM GSTTNXDTLS WHERE gstcode = 'GSTR'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strInvoiceNo = IIf(IsDBNull(objDr!Invoiceno), "", objDr!Invoiceno)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing

                    '' taxable value

                    strTaxableVal = ""
                    strTaxableVal = Math.Round(CDbl(arrTotalCharge(idx)) + CDbl(dblGSTamt) + CDbl(dblCESSamt), 2)
                    ''GSTTXNDTLS
                    StrInsert = "INSERT INTO gsttnxdtls (BRANCHCODE, CUSTOMERID, GSTCODE, GSTIN, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, " & _
    " REVERSECHARGE, INVOICETYPE, ECOMGSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, BATCHNO, STATUS, APPLICATIONDATE, " & _
    " USERID, MACHINEID, SYSTEMDATE,RECPNAME) VALUES " & _
      "('" & arrBrCodes(idx) & "','" & strGSTCustomerid & "','GSTR','" & strGSTIN & "','" & strInvoiceNo & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & arrTotalCharge(idx) & " ','" & strPOS & "','N','Regular','','" & strGSTPercent & "','" & strTaxableVal & "','" & Math.Round(dblGSTamt / 2, 2) & "','" & Math.Round(dblGSTamt / 2, 2) & "',0,'" & dblCESSamt & "','" & i_Batchno & "','R','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',sysdate,'" & strRcpName & "')"

                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objcommand.ExecuteNonQuery()
                    objcommand.Dispose()
                    objcommand = Nothing
                End If ''GSTYN

                ' sum, credit amount of A/c. holders which are existed in
                ' same branch
                sumDrChargeAmount = sumDrChargeAmount + dblDrcharges
                prevBrCode = arrBrCodes(idx)

                If GSTYN = "Y" Then
                    dblTotGSTamt = dblTotGSTamt + dblGSTamt
                    If CessYN = "Y" Then
                        dblTotCESSamt = dblTotCESSamt + dblCESSamt
                    End If
                End If
                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                     "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & CreditGlCode & " and Accno " & _
                            CreditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If
                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE, " & _
                    "CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO, " & _
                    "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                    "APPROVEDTIMEBAL,EFFECTIVEDATE,CASHPAIDYN, " & _
                    "SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CUSTOMERID,NAME)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','" & stRemark & "','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & CreditAccName & "')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & _
                    "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    "ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                    "ENTEREDTIMEBAL,VERIFIEDTIMEBAL,APPROVEDTIMEBAL, " & _
                    "EFFECTIVEDATE,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS, " & _
                    "SERVICEID,EXCEPTIONYN,APPLICATIONDATE,USERID, " & _
                    "MACHINEID,TRANSTATUS, APPROVEDDATE,APPROVEDBY, " & _
                    "APPROVEDMACHINE,CUSTOMERID,NAME) values('" & arrBrCodes(idx) & "','" & _
                    CurrencyCode & "','" & creditModuleId & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & i_Batchno & _
                    "','" & i_TranNo & "'," & sumDrChargeAmount & ",'4'," & _
                    getCreditBal & "," & getCreditBal & "," & getCreditBal & _
                    ",'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','N'," & _
                    " 'Y','" & stRemark & "','1','N','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & _
                    "','" & MachineId & "','A','" & Format(ApplicationDt, _
                    "dd-MMM-yyyy") & "', 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()

                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If

                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction

                    rtnTranDrQuery = objcommand.ExecuteNonQuery()

                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If

                    '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT BRANCHCODE," & _
                    '''"CURRENCYCODE,BATCHNO,TRANNO,'1',APPLICATIONDATE,SYSTEMDATE," & _
                    '''"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDDATE,APPROVEDSYSTEMDATE," & _
                    '''"VERIFIEDSYSTEMDATE FROM GENTRANSLOG WHERE BRANCHCODE ='" & _
                    '''arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '''"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'"

                    '''objcommand = New OracleClient.OracleCommand(strQuery, _
                    '''                                            ObjOracleConnection)
                    '''objcommand.Transaction = objTransaction
                    '''objcommand.ExecuteNonQuery()

                    '' gst value

                    If GSTYN = "Y" Then

                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                              "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                              "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                              "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                              "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                              "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                              "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                              "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                              "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                              "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                              "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                              "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                              "ABBYN"

                        ''CGST
                        strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strCGSTAmt) <> 0 Then
                            strChqFvg = "CGST"

                            dblCGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                 " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblCGSTBal = 0
                            Else
                                dblCGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If
                        '' SGST
                        strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strSGSTAmt) <> 0 Then
                            strChqFvg = "SGST"
                            dblSGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                 " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblSGSTBal = 0
                            Else
                                dblSGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If

                        If CessYN = "Y" Then
                            If CDbl(dblTotCESSamt) <> 0 Then
                                ''CESS Amount
                                strChqFvg = "CESS"
                                dblCESSBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                     " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCESSBal = 0
                                Else
                                    dblCESSBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Trans  Log ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                        End If '' cessyn
                    End If '' gstyn


                End If
            Next ''' End of Debit MinBal Posting

            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & _
                    ") AND CHARGETYPE='GBC'"

                objHist.recordInHist(Trim(ModuleId) & "CHARGEDATEDTLS", _
                "LASTCHARGECALCDATE", ObjOracleConnection, objTransaction, _
                o_ErrMsg, rowcount, strWherecond, BranchCode, UserId, _
                MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If

                '------it is a temperory code 
                'Dim ChargeCalcDt As Date

                'If ChargeCalcToDt = ApplicationDt Then
                'ChargeCalcDt = DateAdd(DateInterval.Day, -1, _
                '                  ChargeCalcToDt)
                'End If

                'Charges are updating to -1 of ApplicationDt for getting 
                '   those records in next calculation (Bcoz., Tran 
                '   Effectivedate>LastChrgCalcDate)
                'To Accept Current Day Transactions
                '------it is a temporary code

                strQuery = "update " & Trim(ModuleId) & "CHARGEDATEDTLS set" & _
                " LASTCHARGECALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and (BRANCHCODE,ACCNO) in(" & _
                BulkArr(i) & ") AND CHARGETYPE='GBC'"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                '' inserting  charges posted accs. details 
                strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") AND CHARGETYPE='" & _
                ChargeType & "'"

                strQuery = "insert into " & Trim(ModuleId) & _
                 "CHARGEPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                 " MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                 " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3,USERID,MACHINEID,APPLICATIONDATE," & _
                 " VARCHARCOL3,VARCHARCOL4,APPROVEDBY, DATECOL1, " & _
                 "APPROVEDMACHINE,CHARGETYPE) " & _
                 " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                 " CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                 MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                 "CHRGCALCTEMP where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                ''' inserting Interest Not posted accno. details (missing accnos.)

                'strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
                '" and GLCODE ='" & Trim(Glcode) & "'" & _
                '" and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                '"' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                '" and USERID='" & Trim(UserId) & "' and" & _
                '" MACHINEID='" & Trim(MachineId) & "' and" & _
                '" APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                '" and (BRANCHCODE,ACCNO) NOT IN (" & BulkArr(i) & _
                '") AND CHARGETYPE='" & ChargeType & "'"

                'strQuery = "insert into  " & Trim(ModuleId) & _
                '"CHARGENOTPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                '" MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                '" CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                '" NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                '" CURRENCYCOL3,USERID," & _
                '" MACHINEID,APPLICATIONDATE," & _
                '" VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                '" DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                '" select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                '" CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                '" NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                '" CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                '" '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                '" 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                'MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                '"CHRGCALCTEMP where " & strIntDtlsNotPosted

                'objcommand = New OracleClient.OracleCommand(strQuery, _
                '            ObjOracleConnection)
                'objcommand.Transaction = objTransaction
                'i_NoOfRows = objcommand.ExecuteNonQuery()
            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCABankCharges = True
            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCABankCharges = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCABankCharges"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCA Minimum Balance Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCAMinBalCharges Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Function PostSMSCharges(ByVal CurrencyCode As String, _
                ByVal ModuleId As String, ByVal Glcode As String, _
                ByVal ChargeCalcFromDt As Date, _
                ByVal ChargeCalcToDt As Date, ByVal roundOfParam As Double, _
                ByVal UserId As String, ByVal ApplicationDt As Date, _
                ByVal MachineId As String, ByVal arrVals() As Object, _
                 ByVal ChargeType As String, _
                ByRef o_ErrMsg As String, _
                Optional ByVal BranchCode As String = "", _
                Optional ByVal FrmAccPre As String = "", _
                Optional ByVal FrmAccNo As String = "", _
                Optional ByVal FrmAccSuf As String = "", _
                Optional ByVal ToAccNo As String = "", Optional ByVal remarks As String = "", Optional ByVal strGSTYN As String = "") As Boolean


        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos, stRemark _
            As String

        Dim strInsertCond, strCkDrCharge, strQuery, i_Batchno, i_TranNo As _
            String

        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery As _
            Integer

        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrCustids, arrTotalCharge, arrCurBalance, arrAccNames _
            As Object

        Dim prevBrCode, CreditGlCode, CreditAccNo, creditModuleId, _
            genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, _
            strProdDtlsCond, strIntDtlsNotPosted As String


        Dim getDebitBal, getCreditBal, sumDrChargeAmount, entryDebitAmount As _
            Double
        Dim CreditAccName As String
        sumDrChargeAmount = 0
        dblTotGSTamt = 0
        dblTotCESSamt = 0
        Dim dblCGSTBal, dblSGSTBal, dblCESSBal As Double
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'Dim AccBal As AccountDetailsRCW.AccDetailsClass
        'AccBal = New AccountDetailsRCW.AccDetailsClass

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer

        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If

            GSTYN = strGSTYN
            GSTParameters("", BranchCode)

            arrBrCodes = Split(arrVals(0), ",")
            arrAccnos = Split(arrVals(1), ",")
            arrCustids = Split(arrVals(2), ",")
            arrAccNames = Split(arrVals(3), ",")
            arrCurBalance = Split(arrVals(4), ",")
            arrTotalCharge = Split(arrVals(5), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & _
                "('" & Trim(arrBrCodes(i)) & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            stRemark = remarks

            If stRemark <> "" Then
                stRemark = stRemark
            Else
                stRemark = "SMS Charges Posting"
            End If


            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit Entries
                    ' into respective tables

                    If prevBrCode <> "" Then
                        'Get current balance of credit Account

                        strQuery = "select GETANYDAYBAL('" & prevBrCode & _
                        "','" & CurrencyCode & "', '" & creditModuleId & _
                        "','" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') " & _
                        "from dual"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                         ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar

                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current " & _
                                "Balance of Credit GL " & CreditGlCode & _
                                " and Accno. " & CreditAccNo & ". " & _
                                vbNewLine & rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If


                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                        genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                        " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CUSTOMERID,NAME,CHQFVG)" & _
                        " values('" & arrBrCodes(idx) & "'," & _
                        " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                        " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                        " '" & i_Batchno & "','" & i_TranNo & "'," & _
                        " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                        " " & getCreditBal & "," & getCreditBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " 'N','Y','" & stRemark & "','1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & CreditAccName & "','" & ChargeType & "')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & _
                        "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CUSTOMERID,NAME,CHQFVG) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & CreditGlCode & _
                             "','" & CreditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','" & stRemark & "','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "','" & ChargeType & "')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log For The Branch " & arrBrCodes(idx))
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & _
                            " Tran Day For The Branch " & arrBrCodes(idx))
                        End If


                        '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT" & _
                        '''" BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,'1'," & _
                        '''"APPLICATIONDATE,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE," & _
                        '''"APPROVEDDATE,APPROVEDSYSTEMDATE,VERIFIEDSYSTEMDATE WHERE " & _
                        '''"BRANCHCODE ='" & arrBrCodes(idx) & " AND CURRENCYCODE ='" & _
                        '''CurrencyCode & " AND BATCHNO= " & i_Batchno & "AND " & _
                        '''" EXCEPTIONYN='Y'"

                        '''objcommand = New OracleClient.OracleCommand(strQuery, _
                        '''                                            ObjOracleConnection)
                        '''objcommand.Transaction = objTransaction
                        '''objcommand.ExecuteNonQuery()

                        '' gst value

                        If GSTYN = "Y" Then

                            strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                                  "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                                  "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                                  "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                                  "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                                  "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                                  "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                                  "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                                  "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                                  "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                                  "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                                  "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                                  "ABBYN"

                            ''CGST
                            strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strCGSTAmt) <> 0 Then
                                strChqFvg = "CGST"

                                dblCGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                     " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCGSTBal = 0
                                Else
                                    dblCGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                        "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCGSTcnt = 0
                                retCGSTcnt = objcommand.ExecuteNonQuery()
                                If retCGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                            '' SGST
                            strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                            If CDbl(strSGSTAmt) <> 0 Then
                                strChqFvg = "SGST"
                                dblSGSTBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                     " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblSGSTBal = 0
                                Else
                                    dblSGSTBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Trans Log ")
                                End If

                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                        "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retSGSTcnt = 0
                                retSGSTcnt = objcommand.ExecuteNonQuery()
                                If retSGSTcnt <> 1 Then
                                    Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If

                            If CessYN = "Y" Then
                                If CDbl(dblTotCESSamt) <> 0 Then
                                    ''CESS Amount
                                    strChqFvg = "CESS"
                                    dblCESSBal = 0
                                    strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                         " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                         " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                         " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    rtnValue = objcommand.ExecuteScalar
                                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                        dblCESSBal = 0
                                    Else
                                        dblCESSBal = CDbl(rtnValue)
                                    End If

                                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                    StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Trans  Log ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing

                                    StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                            "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                            "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                            "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                            "NULL,NULL,'N','" & UserId & "','Y'," & _
                                            "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                            "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                            "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                    objcommand.Transaction = objTransaction
                                    retCESScnt = 0
                                    retCESScnt = objcommand.ExecuteNonQuery()
                                    If retCESScnt <> 1 Then
                                        Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                        " into Tran Day ")
                                    End If
                                    objcommand.Dispose()
                                    objcommand = Nothing
                                End If
                            End If '' cessyn
                        End If '' gstyn


                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()

                    Dim MaxToDate As String

                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                        strQuery = "select NVL(to_char(MAX(TODATE)),0) from " & _
                        " GENSYSTEMACTIVITYLOG WHERE MODULEID='" & Trim(ModuleId) & _
                        "' and" & _
                        " GLCODE='" & Trim(Glcode) & "' AND CURRENCYCODE = '" & _
                        CurrencyCode & "' AND BRANCHCODE = '" & arrBrCodes(idx) & _
                        "' AND ACTIVITYID='" & ChargeType & "'"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction

                        MaxToDate = CStr(objcommand.ExecuteScalar())


                        If MaxToDate <> "0" Then
                            If CDate(MaxToDate) > ChargeCalcFromDt Then
                                Throw New Exception(" Already Charges Were" & _
                                 " Calculated For The Range of Dates ")
                            End If
                        End If

                        strQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                            "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE," & _
                            "ACTIVITYID,FROMDATE,TODATE,APPLICATIONDATE," & _
                            "UserId,MachineId,STATUS,APPROVEDBY," & _
                            "APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) VALUES" & _
                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & _
                            "','" & ModuleId & "','" & Glcode & "'," & _
                            "'" & ChargeType & "','" & Format(ChargeCalcFromDt, _
                            "dd-MMM-yyyy") & "', '" & Format(ChargeCalcToDt, _
                            "dd-MMM-yyyy") & "','" & Format(ApplicationDt, _
                            "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            " '" & MachineId & "','A','SYSTEM','" & MachineId _
                            & "'," & roundOfParam & "," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                          ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()

                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data " & _
                            "Into GensystemActivityLog For The Branch " & _
                            arrBrCodes(idx))
                        End If
                    End If  ''' End of FrmAccno Not Null

                    ''Get the CreditGlCode and Credit Account Number
                    'for the respective Debit Gl Code

                    strQuery ="SELECT COMMMODULEID, COMMGLCODE, COMMACCNO FROM GENCHARGESPMT WHERE chargesid = '"& ChargeType   &"'"
                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC!COMMMODULEID) = False And IsDBNull(drCreditGLACC!COMMGLCODE) = False And IsDBNull(drCreditGLACC!COMMACCNO) = False Then
                            creditModuleId = drCreditGLACC!COMMMODULEID
                            CreditGlCode = drCreditGLACC!COMMGLCODE
                            CreditAccNo = drCreditGLACC!COMMACCNO
                        Else
                            Throw New Exception("Charges Parameters Not " & _
                            "Available For the chargesid SMS in GENCHARGESPMT ")
                        End If
                    Else
                        Throw New Exception("Charges Parameters Not " & _
                        "Available For the chargesid SMS in GENCHARGESPMT ")

                    End If

                    drCreditGLACC = Nothing

                    strCkDrCharge = ""

                    '' save the Parameters like creditGlcode,Credit Account No.
                    ' and Round Value,a/c prefix,suffix and its range, entries per folio
                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5," & _
                    "COL6,COL7,COL8,col9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & _
                    "','" & MachineId & "','SYSTEM','" & MachineId & _
                    "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcToDt, "dd-MMM-yyyy") & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & _
                    FrmAccNo & "','" & FrmAccSuf & "','" & ToAccNo & _
                    "','" & strCkDrCharge & "',''," & i_Batchno & ")"


                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)

                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery

                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data " & _
                        "into Actual Parameters Table while debiting " & _
                        ModuleId & " Charge")
                    End If


                    '' to get credit account name

                    CreditAccName = ""
                    strQuery = "SELECT name FROM " & creditModuleId & "mst WHERE glcode =  '" & CreditGlCode & "' AND accno = '" & CreditAccNo & "' AND branchcode = '" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.HasRows Then
                        If drGetModId.Read Then
                            CreditAccName = IIf(IsDBNull(drGetModId!name), "", drGetModId!name)
                        End If
                    Else
                        CreditAccName = ""
                    End If
                    drGetModId = Nothing

                End If ''' End of Inserting entries into systemactivitylog and actual

                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder

                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                   " '" & CurrencyCode & "', '" & ModuleId & "'," & _
                   " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                         ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnValue = objcommand.ExecuteScalar

                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    Throw New Exception("Unable to get Current Balance" & _
                        " of Debilt GL " & Glcode & " and Accno. " & _
                        arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                Else
                    getDebitBal = CDbl(rtnValue)
                End If

                Dim drException As String

                'This checks whether exceptions are accpted or not

                If (getDebitBal - arrTotalCharge(idx)) < 0 Then
                    drException = "Y"
                Else
                    drException = "N"
                End If

                dblDrcharges = 0
                dblGSTamt = 0
                dblCESSamt = 0
                dblTotDrcharges = 0
                dblDrcharges = CDbl(arrTotalCharge(idx))

                If GSTYN = "Y" Then
                    '' to get gst amt
                    dblGSTamt = CDbl(arrTotalCharge(idx) * CDbl(strGSTPercent) / 100)

                    ''to get cess amt
                    If CessYN = "Y" Then
                        dblCESSamt = Math.Round(CDbl(arrTotalCharge(idx) * CDbl(strCessPercent) / 100))
                    End If

                    If GSTYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt
                    End If
                    If CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblCESSamt
                    End If

                    If GSTYN = "Y" And CessYN = "Y" Then
                        dblTotDrcharges = CDbl(arrTotalCharge(idx)) + dblGSTamt + dblCESSamt
                    End If
                Else
                    dblTotDrcharges = CDbl(arrTotalCharge(idx))
                End If


                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO," & _
                "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                "APPROVEDTIMEBAL,EFFECTIVEDATE,CUSTOMERID,NAME,CASHPAIDYN," & _
                " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,LINKMODULEID, LINKGLCODE, LINKACCNO,CHQFVG)" & _
                " VALUES('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -1 * dblTotDrcharges & ",'3'," & getDebitBal & "," & _
                " " & getDebitBal & "," & getDebitBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','" & stRemark & "'," & _
                " '1','" & drException & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "','" & ChargeType & "')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,LINKMODULEID, LINKGLCODE, LINKACCNO,CHQFVG) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -1 * dblTotDrcharges & "," & _
                   " '3'," & getDebitBal & "," & _
                   " " & getDebitBal & "," & getDebitBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','" & stRemark & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "','" & ChargeType & "')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If

                If GSTYN = "Y" Then

                    '' gst customerid 

                    strGSTIN = ""
                    strGSTCustomerid = ""
                    strRcpName = ""
                    strSql = "SELECT CUSTOMERID,name FROM " & ModuleId & "MST WHERE ACCNO='" & arrAccnos(idx) & "' AND GLCODE='" & Glcode & "' AND " & "BRANCHCODE='" & arrBrCodes(idx) & "'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strGSTCustomerid = IIf(IsDBNull(objDr!CUSTOMERID), "", objDr!CUSTOMERID)
                            strRcpName = IIf(IsDBNull(objDr!name), "", objDr!name)
                        End While
                        ''GSTIN
                        strSql = "SELECT nvl(gstin,'') GSTIN FROM gencustinfomst WHERE customerid = '" & strGSTCustomerid & "'"
                        objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        objDr1 = objcommand.ExecuteReader()
                        If (objDr1.HasRows) Then
                            While (objDr1.Read)
                                strGSTIN = IIf(IsDBNull(objDr1!GSTIN), "", objDr1!GSTIN)
                            End While
                        End If
                        objDr1.Close()
                        objDr1.Dispose()
                        objDr1 = Nothing


                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing


                    '' invoice no
                    strInvoiceNo = ""
                    strSql = "SELECT NVL(MAX(TO_NUMBER(INVOICENO)),0)+1  Invoiceno FROM GSTTNXDTLS WHERE gstcode = 'GSTR'"
                    objcommand = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objDr = objcommand.ExecuteReader()
                    If (objDr.HasRows) Then
                        While (objDr.Read)
                            strInvoiceNo = IIf(IsDBNull(objDr!Invoiceno), "", objDr!Invoiceno)
                        End While
                    End If
                    objDr.Close()
                    objDr.Dispose()
                    objDr = Nothing
                    objcommand.Dispose()
                    objcommand = Nothing

                    '' taxable value

                    strTaxableVal = ""
                    strTaxableVal = Math.Round(CDbl(arrTotalCharge(idx)) + CDbl(dblGSTamt) + CDbl(dblCESSamt), 2)
                    ''GSTTXNDTLS
                    StrInsert = "INSERT INTO gsttnxdtls (BRANCHCODE, CUSTOMERID, GSTCODE, GSTIN, INVOICENO, INVDATE, INVVALUE, PLACEOFSUPPLY, " & _
    " REVERSECHARGE, INVOICETYPE, ECOMGSTIN, RATE, TAXABLEVALUE, SGST, CGST, IGST, CESS, BATCHNO, STATUS, APPLICATIONDATE, " & _
    " USERID, MACHINEID, SYSTEMDATE,RECPNAME) VALUES " & _
      "('" & arrBrCodes(idx) & "','" & strGSTCustomerid & "','GSTR','" & strGSTIN & "','" & strInvoiceNo & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & arrTotalCharge(idx) & " ','" & strPOS & "','N','Regular','','" & strGSTPercent & "','" & strTaxableVal & "','" & Math.Round(dblGSTamt / 2, 2) & "','" & Math.Round(dblGSTamt / 2, 2) & "',0,'" & dblCESSamt & "','" & i_Batchno & "','R','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId & "',sysdate,'" & strRcpName & "')"

                    objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    objcommand.ExecuteNonQuery()
                    objcommand.Dispose()
                    objcommand = Nothing
                End If ''GSTYN

                ' sum, credit amount of A/c. holders which are existed in
                ' same branch
                sumDrChargeAmount = sumDrChargeAmount + dblDrcharges
                prevBrCode = arrBrCodes(idx)

                If GSTYN = "Y" Then
                    dblTotGSTamt = dblTotGSTamt + dblGSTamt
                    If CessYN = "Y" Then
                        dblTotCESSamt = dblTotCESSamt + dblCESSamt
                    End If
                End If
                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                     "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & CreditGlCode & " and Accno " & _
                            CreditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If
                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE, " & _
                    "CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO, " & _
                    "AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL, " & _
                    "APPROVEDTIMEBAL,EFFECTIVEDATE,CASHPAIDYN, " & _
                    "SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CUSTOMERID,NAME,CHQFVG)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','" & stRemark & "','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & CreditAccName & "','" & ChargeType & "')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & _
                    "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    "ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                    "ENTEREDTIMEBAL,VERIFIEDTIMEBAL,APPROVEDTIMEBAL, " & _
                    "EFFECTIVEDATE,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS, " & _
                    "SERVICEID,EXCEPTIONYN,APPLICATIONDATE,USERID, " & _
                    "MACHINEID,TRANSTATUS, APPROVEDDATE,APPROVEDBY, " & _
                    "APPROVEDMACHINE,CUSTOMERID,NAME,CHQFVG) values('" & arrBrCodes(idx) & "','" & _
                    CurrencyCode & "','" & creditModuleId & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & i_Batchno & _
                    "','" & i_TranNo & "'," & sumDrChargeAmount & ",'4'," & _
                    getCreditBal & "," & getCreditBal & "," & getCreditBal & _
                    ",'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','N'," & _
                    " 'Y','" & stRemark & "','1','N','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & _
                    "','" & MachineId & "','A','" & Format(ApplicationDt, _
                    "dd-MMM-yyyy") & "', 'SYSTEM','" & MachineId & "','" & nonCustomerid & "','" & CreditAccName & "','" & ChargeType & "')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()

                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If

                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction

                    rtnTranDrQuery = objcommand.ExecuteNonQuery()

                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If

                    '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT BRANCHCODE," & _
                    '''"CURRENCYCODE,BATCHNO,TRANNO,'1',APPLICATIONDATE,SYSTEMDATE," & _
                    '''"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDDATE,APPROVEDSYSTEMDATE," & _
                    '''"VERIFIEDSYSTEMDATE FROM GENTRANSLOG WHERE BRANCHCODE ='" & _
                    '''arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '''"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'"

                    '''objcommand = New OracleClient.OracleCommand(strQuery, _
                    '''                                            ObjOracleConnection)
                    '''objcommand.Transaction = objTransaction
                    '''objcommand.ExecuteNonQuery()

                    '' gst value

                    If GSTYN = "Y" Then

                        strTranCols = "BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, BATCHNO, " & _
                                              "TRANNO, AMOUNT, MODEOFTRAN, ENTEREDTIMEBAL, VERIFIEDTIMEBAL, " & _
                                              "APPROVEDTIMEBAL, DAYENDBAL, EFFECTIVEDATE, CUSTOMERID, NAME, " & _
                                              "CHQNO, CHQSERIESNO, CHQFVG, CHQDATE, TOKENNO, CASHPAIDYN, " & _
                                              "CASHIERID, SYSTEMGENERATEDYN, RATE, FCURRENCYCODE, FAMOUNT, " & _
                                              "LINKMODULEID, LINKGLCODE, LINKACCNO, LINKACCTYPE, REMARKS, " & _
                                              "SERVICEID, CLGRATETYPE, RESPONDINGBRANCHCODE, " & _
                                              "RESPONDINGSECTIONCODE, EXCEPTIONYN, RESPONDINGBANKCODE, " & _
                                              "RATEREFCODE, APPROVEDSYSTEMDATE, VERIFIEDSYSTEMDATE, " & _
                                              "APPROVEDDATE, APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, " & _
                                              "SYSTEMDATE, VERIFIEDBY, VERIFIEDMACHINE, APPROVEDBY, " & _
                                              "APPROVEDMACHINE,  ABBBRANCHCODE, ABBAPPLICATIONDATE, " & _
                                              "ABBYN"

                        ''CGST
                        strCGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strCGSTAmt) <> 0 Then
                            strChqFvg = "CGST"

                            dblCGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strCGSTMod & "'," & _
                 " '" & strCGSTGl & "','" & strCGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblCGSTBal = 0
                            Else
                                dblCGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))
                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"
                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strCGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCGSTMod & "'," & _
                                    "'" & strCGSTGl & "','" & strCGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strCGSTAmt & ",'4'," & dblCGSTBal & "," & dblCGSTBal & "," & dblCGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retCGSTcnt = 0
                            retCGSTcnt = objcommand.ExecuteNonQuery()
                            If retCGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert CGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If
                        '' SGST
                        strSGSTAmt = Math.Round(CDbl(dblTotGSTamt) / 2, 2)
                        If CDbl(strSGSTAmt) <> 0 Then
                            strChqFvg = "SGST"
                            dblSGSTBal = 0
                            strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                 " '" & CurrencyCode & "', '" & strSGSTMod & "'," & _
                 " '" & strSGSTGl & "','" & strSGSTAcc & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            rtnValue = objcommand.ExecuteScalar
                            If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                dblSGSTBal = 0
                            Else
                                dblSGSTBal = CDbl(rtnValue)
                            End If

                            i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                            StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Trans Log ")
                            End If

                            objcommand.Dispose()
                            objcommand = Nothing

                            StrInsert = "INSERT INTO " & strSGSTMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                    "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strSGSTMod & "'," & _
                                    "'" & strSGSTGl & "','" & strSGSTAcc & "','" & i_Batchno & "'," & _
                                    "'" & i_TranNo & "'," & strSGSTAmt & ",'4'," & dblSGSTBal & "," & dblSGSTBal & "," & dblSGSTBal & "," & _
                                    "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strSGSTGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                    "NULL,NULL,'N','" & UserId & "','Y'," & _
                                    "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                    "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                    "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                            objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            retSGSTcnt = 0
                            retSGSTcnt = objcommand.ExecuteNonQuery()
                            If retSGSTcnt <> 1 Then
                                Throw New Exception("Unable To Insert SGST Credit Entry" & _
                                " into Tran Day ")
                            End If
                            objcommand.Dispose()
                            objcommand = Nothing
                        End If

                        If CessYN = "Y" Then
                            If CDbl(dblTotCESSamt) <> 0 Then
                                ''CESS Amount
                                strChqFvg = "CESS"
                                dblCESSBal = 0
                                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                     " '" & CurrencyCode & "', '" & strCESSMod & "'," & _
                     " '" & strCESSGl & "','" & strCESSAcc & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                rtnValue = objcommand.ExecuteScalar
                                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                                    dblCESSBal = 0
                                Else
                                    dblCESSBal = CDbl(rtnValue)
                                End If

                                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                                StrInsert = "INSERT INTO GENTRANSLOG (" & strTranCols & ") VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N')"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Trans  Log ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing

                                StrInsert = "INSERT INTO " & strCESSMod & "TRANDAY (" & strTranCols & ", MSTNO) VALUES " & _
                                        "('" & arrBrCodes(idx) & "','" & CurrencyCode & "','" & strCESSMod & "'," & _
                                        "'" & strCESSGl & "','" & strCESSAcc & "','" & i_Batchno & "'," & _
                                        "'" & i_TranNo & "'," & dblTotCESSamt & ",'4'," & dblCESSBal & "," & dblCESSBal & "," & dblCESSBal & "," & _
                                        "NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & nonCustomerid & "','" & strCESSGlDesc & "',NULL,NULL,'" & strChqFvg & "'," & _
                                        "NULL,NULL,'N','" & UserId & "','Y'," & _
                                        "NULL,NULL,NULL,'" & ModuleId & "','" & Glcode & "','',NULL,'" & stRemark & "','1',NULL,NULL," & _
                                        "NULL,'N',NULL,NULL,NULL,NULL,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                                        "'" & MachineId & "','A',SYSDATE,NULL,NULL,'" & UserId & "','" & MachineId & "',NULL,NULL,'N',NULL)"

                                objcommand = New OracleClient.OracleCommand(StrInsert, ObjOracleConnection)
                                objcommand.Transaction = objTransaction
                                retCESScnt = 0
                                retCESScnt = objcommand.ExecuteNonQuery()
                                If retCESScnt <> 1 Then
                                    Throw New Exception("Unable To Insert CESS Credit Entry" & _
                                    " into Tran Day ")
                                End If
                                objcommand.Dispose()
                                objcommand = Nothing
                            End If
                        End If '' cessyn
                    End If '' gstyn


                End If
            Next ''' End of Debit MinBal Posting

            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                    "' and GLCODE ='" & Trim(Glcode) & _
                    "' and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & _
                    ") AND CHARGETYPE='" & ChargeType & "'"

                objHist.recordInHist(Trim(ModuleId) & "CHARGEDATEDTLS", _
                "LASTCHARGECALCDATE", ObjOracleConnection, objTransaction, _
                o_ErrMsg, rowcount, strWherecond, BranchCode, UserId, _
                MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If

                '------it is a temperory code 
                'Dim ChargeCalcDt As Date

                'If ChargeCalcToDt = ApplicationDt Then
                'ChargeCalcDt = DateAdd(DateInterval.Day, -1, _
                '                  ChargeCalcToDt)
                'End If

                'Charges are updating to -1 of ApplicationDt for getting 
                '   those records in next calculation (Bcoz., Tran 
                '   Effectivedate>LastChrgCalcDate)
                'To Accept Current Day Transactions
                '------it is a temporary code

                strQuery = "update " & Trim(ModuleId) & "CHARGEDATEDTLS set" & _
                " LASTCHARGECALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and (BRANCHCODE,ACCNO) in(" & _
                BulkArr(i) & ") AND CHARGETYPE='" & ChargeType & "'"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                '' inserting  charges posted accs. details 
                strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") AND CHARGETYPE='" & _
                ChargeType & "'"

                strQuery = "insert into " & Trim(ModuleId) & _
                 "CHARGEPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                 " MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                 " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3,USERID,MACHINEID,APPLICATIONDATE," & _
                 " VARCHARCOL3,VARCHARCOL4,APPROVEDBY, DATECOL1, " & _
                 "APPROVEDMACHINE,CHARGETYPE) " & _
                 " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                 " CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                 " CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                 MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                 "CHRGCALCTEMP where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                ''' inserting Interest Not posted accno. details (missing accnos.)

                'strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
                '" and GLCODE ='" & Trim(Glcode) & "'" & _
                '" and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                '"' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                '" and USERID='" & Trim(UserId) & "' and" & _
                '" MACHINEID='" & Trim(MachineId) & "' and" & _
                '" APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                '" and (BRANCHCODE,ACCNO) NOT IN (" & BulkArr(i) & _
                '") AND CHARGETYPE='" & ChargeType & "'"

                'strQuery = "insert into  " & Trim(ModuleId) & _
                '"CHARGENOTPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                '" MODULEID,GLCODE, ACCNO, CHRGCALCFROMDT," & _
                '" CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                '" NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                '" CURRENCYCOL3,USERID," & _
                '" MACHINEID,APPLICATIONDATE," & _
                '" VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                '" DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                '" select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                '" CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                '" NUMBERCOL2,NUMBERCOL3,CURRENCYCOL1,CURRENCYCOL2," & _
                '" CURRENCYCOL3, '" & UserId & "','" & MachineId & "'," & _
                '" '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                '" 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                'MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                '"CHRGCALCTEMP where " & strIntDtlsNotPosted

                'objcommand = New OracleClient.OracleCommand(strQuery, _
                '            ObjOracleConnection)
                'objcommand.Transaction = objTransaction
                'i_NoOfRows = objcommand.ExecuteNonQuery()
            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSMSCharges = True
            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSMSCharges = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSMSCharges"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SMS Charges Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing SBCAMinBalCharges Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Function PostSBCADebitChqIssCharges(ByVal CurrencyCode As _
              String, ByVal ModuleId As String, _
              ByVal Glcode As String, ByVal ChargeCalcFromDt As Date, _
              ByVal ChargeCalcToDt As Date, ByVal roundOfParam As Double, _
              ByVal UserId As String, _
              ByVal ApplicationDt As Date, ByVal MachineId As String, _
              ByVal arrVals() As Object, ByVal CkDrCharge As Boolean, _
              ByVal ChargeType As String, ByRef o_ErrMsg As String, _
              Optional ByVal BranchCode As String = "", _
              Optional ByVal FrmAccPre As String = "", _
              Optional ByVal FrmAccNo As String = "", _
              Optional ByVal FrmAccSuf As String = "", _
              Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Post The Debit ChqIss Charges of A/c. 
        'holders for the given Period

        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be those which are allowed 
        'for issuing Chequebooks
        'GLCode =Gl Code
        'ChargeCalcFromDt And ChargeCalcToDt are the range of Dates to 
        'calculate the charge
        'UserId = Login User Id
        'Application Date = currenct day begin date
        'MachineId = Login Machine Id
        'arrVals(0) = Includes Branchodes in which a/c's are existed is 
        'seperated by "," (comma symbol)
        'arrVals(1) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2)= CustomerIds
        'arrVals(3)= Account Holder's Names
        'arrVals(4)= Balances of Account
        'arrVals(5)= calculated Charges
        'O_ErrMsg = Holds the Error Message which will return to the caller function
        'ckdrcharge = Holds True or False to allow posting charges even if 
        'balance is less than zero
        'BranchCode = Branch Code in which a/c's are existed

        'Outputs:
        ' if the whole process is successfully executed
        '   function PostSBCADebitChqIssCharges will return True with 
        '   error message (O_ErrMsg)="" 
        ' else
        '   returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, _
            strAccountNos, strInsertCond, strCkDrCharge, strQuery, _
            i_Batchno, i_TranNo, prevBrCode, CreditGlCode, CreditAccNo, _
            creditModuleId, genCrQuery, tranCrQuery, genDrQuery, _
            tranDrQuery, strProdDtlsCond, strIntDtlsNotPosted, _
            EntriesPerFolio, strWherecond, rtnValue, BulkArr(200) As String

        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, _
            i, idx, i_NoOfRows, Cnt, BulkArrIdx, rowcount As Integer

        Dim getDebitBal, getCreditBal, sumDrChargeAmount, entryDebitAmount _
        As Double

        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrCustids, arrTotalCharge, arrCurBalance, _
            arrAccNames As Object


        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim ObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim drGetModId, drActiveLog, drCreditGLACC As OracleClient. _
            OracleDataReader
        Dim objHist As New DatabaseConnection.updateHistTable


        sumDrChargeAmount = 0

        idx = 0


        Try
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0), ",")
            arrAccnos = Split(arrVals(1), ",")
            arrCustids = Split(arrVals(2), ",")
            arrAccNames = Split(arrVals(3), ",")
            arrCurBalance = Split(arrVals(4), ",")
            arrTotalCharge = Split(arrVals(5), ",")

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For i = 0 To UBound(arrAccnos)
                Cnt += 1
                strAccountNos = strAccountNos & "('" & Trim(arrBrCodes(i)) _
                                & "','" & Trim(arrAccnos(i)) & "') ,"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, _
                        Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If
            Next
            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, _
                    Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If

            prevBrCode = ""
            For idx = 0 To UBound(arrBrCodes)
                If prevBrCode <> arrBrCodes(idx) Then
                    '''Post the single Credit Entry for Multiple Debit 
                    '       Entries into respective tables

                    If prevBrCode <> "" Then
                        'Get current balance of credit Account

                        strQuery = "select GETANYDAYBAL('" & prevBrCode & _
                        "','" & CurrencyCode & "', '" & creditModuleId & _
                        "','" & CreditGlCode & "','" & CreditAccNo & _
                        "','" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                        "') from dual"

                        objcommand = New OracleClient.OracleCommand( _
                                            strQuery, ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnValue = objcommand.ExecuteScalar

                        If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                            Throw New Exception("Unable to get Current " & _
                                "Balance of Credit GL " & CreditGlCode & _
                                " and Accno " & CreditAccNo & vbNewLine & _
                                  rtnValue)
                        Else
                            getCreditBal = CDbl(rtnValue)
                        End If


                        ''rtnValue = AccBal.GetBalance(prevBrCode, CurrencyCode, _
                        ''creditModuleId, CreditGlCode, CreditAccNo)

                        ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        ''    Throw New Exception("Error Occured While Getting Current" & _
                        ''    "Balance For Given Credit Account Where Credit GLCode = " & _
                        ''    CreditGlCode & " And Credit AccountNo = " & _
                        ''    CreditAccNo & " And Credit Module id = " & creditModuleId & _
                        ''    "and Branch Code =" & prevBrCode & " Currency Code = " & _
                        ''    CurrencyCode & " . The Error is " & rtnValue)
                        ''Else
                        ''    getCreditBal = Val(rtnValue)
                        ''End If


                        i_TranNo = objDBConnection.GetTranNo(arrBrCodes _
                                                    (idx))

                        genDrQuery = "insert into GENTRANSLOG(" & _
                        "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                        "BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                        "ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                        "APPROVEDTIMEBAL,EFFECTIVEDATE,CASHPAIDYN," & _
                        "SYSTEMGENERATEDYN,REMARKS,SERVICEID," & _
                        "EXCEPTIONYN,APPLICATIONDATE,USERID,MACHINEID," & _
                        "TRANSTATUS,SYSTEMDATE,APPROVEDBY," & _
                        "APPROVEDMACHINE,APPROVEDDATE)values('" & _
                        arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                        creditModuleId & "','" & CreditGlCode & "','" & _
                        CreditAccNo & "','" & i_Batchno & "','" & i_TranNo _
                        & "'," & sumDrChargeAmount & ",'4'," & _
                        getCreditBal & "," & getCreditBal & "," & _
                        getCreditBal & ",'" & Format(ApplicationDt, _
                        "dd-MMM-yyyy") & "','N','Y','Folio Charges " & _
                        "Posting ','1','N','" & Format(ApplicationDt, _
                       "dd-MMM-yyyy") & "','" & UserId & "','" & MachineId _
                        & "','A',sysdate,'SYSTEM','" & MachineId & "','" & _
                        Format(ApplicationDt, "dd-MMM-yyyy") & "')"


                        tranDrQuery = "insert into " & Trim(creditModuleId) & _
                        "TRANDAY (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                              " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                              " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                              " EFFECTIVEDATE,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE) values(" & _
                             " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                             " '" & creditModuleId & "','" & CreditGlCode & _
                             "','" & CreditAccNo & "','" & i_Batchno & "'," & _
                             " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                             " '4'," & getCreditBal & "," & _
                             " " & getCreditBal & "," & getCreditBal & "," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " 'N','Y','Chq Issue Charges Posting','1','N'," & _
                             " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                              " 'SYSTEM','" & MachineId & "')"

                        objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnGenDrQuery = objcommand.ExecuteNonQuery()

                        If rtnGenDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into Trans Log For The Branch " & arrBrCodes(idx))
                        End If

                        objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                  ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        rtnTranDrQuery = objcommand.ExecuteNonQuery()
                        If rtnTranDrQuery <> 1 Then
                            Throw New Exception("Unable To Insert Credit Entry" & _
                            " into " & Trim(creditModuleId) & _
                            " Tran Day For The Branch " & arrBrCodes(idx))
                        End If
                        '===========================================

                        '''strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT" & _
                        '''" BRANCHCODE,CURRENCYCODE,BATCHNO,TRANNO,'1'," & _
                        '''"APPLICATIONDATE,SYSTEMDATE,VERIFIEDBY,VERIFIEDMACHINE," & _
                        '''"APPROVEDDATE,APPROVEDSYSTEMDATE,VERIFIEDSYSTEMDATE WHERE " & _
                        '''"BRANCHCODE ='" & arrBrCodes(idx) & " AND CURRENCYCODE ='" & _
                        '''CurrencyCode & " AND BATCHNO= " & i_Batchno & "AND " & _
                        '''" EXCEPTIONYN='Y'"

                        '''objcommand = New OracleClient.OracleCommand(strQuery, _
                        '''                                            ObjOracleConnection)
                        '''objcommand.Transaction = objTransaction
                        '''objcommand.ExecuteNonQuery()

                    End If  '''end of Credit entry posting

                    i_Batchno = objDBConnection.GetBatchno(arrBrCodes(idx))

                    ''' Transaction Begin
                    objTransaction = ObjOracleConnection.BeginTransaction()

                    Dim MaxToDate As String

                    If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                        strQuery = "select NVL(to_char(MAX(TODATE)),0) from " & _
                        " GENSYSTEMACTIVITYLOG WHERE MODULEID='" & Trim(ModuleId) & _
                        "' and" & _
                        " GLCODE='" & Trim(Glcode) & "' AND CURRENCYCODE = '" & _
                        CurrencyCode & "' AND BRANCHCODE = '" & arrBrCodes(idx) & _
                        "' AND ACTIVITYID='CIC'"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                                ObjOracleConnection)
                        objcommand.Transaction = objTransaction

                        MaxToDate = CStr(objcommand.ExecuteScalar())
                        'MaxToDate = objcommand.ExecuteScalar()

                        If MaxToDate <> "0" Then
                            If CDate(MaxToDate) > ChargeCalcFromDt Then
                                Throw New Exception(" Already Charges Were" & _
                                 " Calculated For The Range of Dates ")
                            End If
                        End If

                        strQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                            "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE," & _
                            "ACTIVITYID,FROMDATE,TODATE,APPLICATIONDATE," & _
                            "UserId,MachineId,STATUS,APPROVEDBY," & _
                            "APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) VALUES" & _
                            "('" & arrBrCodes(idx) & "','" & CurrencyCode & _
                            "','" & ModuleId & "','" & Glcode & "'," & _
                            "'CIC','" & Format(ChargeCalcFromDt, _
                            "dd-MMM-yyyy") & "', '" & Format(ChargeCalcToDt, _
                            "dd-MMM-yyyy") & "','" & Format(ApplicationDt, _
                            "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            " '" & MachineId & "','A','SYSTEM','" & MachineId & _
                            "'," & roundOfParam & "," & i_Batchno & ")"

                        objcommand = New OracleClient.OracleCommand(strQuery, _
                                                          ObjOracleConnection)
                        objcommand.Transaction = objTransaction
                        i_NoOfRows = objcommand.ExecuteNonQuery()
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Data Into" & _
                            " GensystemActivityLog For The Branch " & _
                              arrBrCodes(idx))
                        End If
                    End If   ''' End of FrmAccno Not Null
                    ''Get the CreditGlCode and Credit Account Number
                    'for the respective Debit Gl Code

                    strQuery = "select CHQISSUEGLCODE,CHQISSUEACCNO " & _
                     " from " & Trim(ModuleId) & "TYPEMST where" & _
                     " MODULEID='" & Trim(ModuleId) & "' and" & _
                     " GLCODE='" & Trim(Glcode) & "'"

                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                     ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drCreditGLACC = objcommand.ExecuteReader
                    If drCreditGLACC.Read Then
                        If IsDBNull(drCreditGLACC(0)) = False And _
                           IsDBNull(drCreditGLACC(1)) = False Then

                            CreditGlCode = drCreditGLACC(0)
                            CreditAccNo = drCreditGLACC(1)
                        Else

                            Throw New Exception("Charges Parameters Not Available" & _
                            " For the GL in" & ModuleId & "TYPEMST Table")
                        End If
                    Else
                        Throw New Exception("Charges Parameters Not Available" & _
                        " For the GL in" & ModuleId & " TYPEMST Table")

                    End If

                    drCreditGLACC = Nothing

                    If CkDrCharge = True Then
                        strCkDrCharge = "Y"
                    Else
                        strCkDrCharge = "N"
                    End If


                    '' save the Parameters like creditGlcode,Credit Account No.
                    ' and Round Value,a/c prefix,suffix and its range, entries per folio
                    strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6," & _
                    "COL7,COL8, col9,COL10,COL11,COL12) values('" & _
                    arrBrCodes(idx) & "','" & CurrencyCode & "','" & _
                    ModuleId & "','" & Glcode & "','" & UserId & "','" & _
                    MachineId & "','SYSTEM','" & MachineId & "','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcFromDt, "dd-MMM-yyyy") & "','" & _
                    Format(ChargeCalcToDt, "dd-MMM-yyyy") & "','" & _
                    CreditGlCode & "','" & CreditAccNo & "','" & _
                    roundOfParam & "','" & FrmAccPre & "','" & FrmAccNo & _
                    "','" & FrmAccSuf & "','" & ToAccNo & "','" & _
                    strCkDrCharge & "',''," & i_Batchno & ")"

                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    i_NoOfRows = objcommand.ExecuteNonQuery
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable to Insert the data into" & _
                        " Actual Parameters Table while debiting " & ModuleId & _
                        " Charge")
                    End If

                    '' Get The moduled id from GENGLMASTMST for the Debit Gl Code to 
                    ' decide the TRAN TABLE to debit the amount from that Glcode 
                    'account

                    'strQuery = "select moduleid from GENGLMASTMST where" & _
                    '   " BranchCode='" & arrBrCodes(idx) & "' and" & _
                    '   " GLCODE='" & CreditGlCode & "'"
                    strQuery = "select moduleid from GENGLMASTMST where" & _
                               " GLCODE='" & CreditGlCode & "'"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    drGetModId = objcommand.ExecuteReader
                    If drGetModId.Read Then
                        If IsDBNull(drGetModId(0)) = False Then
                            creditModuleId = drGetModId(0)
                        Else
                            Throw New Exception("Module Id for the GL " & _
                            CreditGlCode & " Not Available")
                        End If
                    Else
                        Throw New Exception("Module Id for the GL " & _
                        CreditGlCode & " Not Available")
                    End If
                    drGetModId = Nothing
                End If ''' End of Inserting entries into systemactivitylog and actual
                ' parameters tables when branch differs

                ''' Transaction PART For a Single Account
                ''' Get the current Balance of account holder
                strQuery = "select GETANYDAYBAL('" & arrBrCodes(idx) & "'," & _
                   " '" & CurrencyCode & "', '" & ModuleId & "'," & _
                   " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
               " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                         ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnValue = objcommand.ExecuteScalar
                If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    Throw New Exception("Unable to get Current Balance" & _
                        " of Debit GL " & Glcode & " and Accno. " & _
                        arrAccnos(idx) & ". " & vbNewLine & rtnValue)
                Else
                    getDebitBal = CDbl(rtnValue)
                End If


                ''rtnValue = ""
                ''rtnValue = AccBal.GetBalance(arrBrCodes(idx), CurrencyCode, _
                ''Trim(ModuleId), Glcode, arrAccnos(idx))

                ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                ''    Throw New Exception("Error Occured While Getting Current" & _
                ''    "Balance For Given Account Where GLCode = " & Glcode & _
                ''    " And AccountNo = " & arrAccnos(idx) & " And Module id = " & _
                ''    Trim(ModuleId) & "and Branch Code =" & arrBrCodes(idx) & _
                ''    " Currency Code = " & CurrencyCode & " . The Error is " & rtnValue)
                ''Else
                ''    getDebitBal = Val(rtnValue)
                ''End If

                Dim drException As String

                'This checks whether exceptions are accpted or not

                If (getDebitBal - arrTotalCharge(idx)) < 0 Then
                    drException = "Y"
                Else
                    drException = "N"
                End If

                i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                genCrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE,CUSTOMERID," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE)" & _
                " VALUES('" & arrBrCodes(idx) & "'," & _
                " '" & CurrencyCode & "','" & ModuleId & "'," & _
                " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                " '" & i_Batchno & "','" & i_TranNo & "'," & _
                " " & -arrTotalCharge(idx) & ",'3'," & getDebitBal & "," & _
                " " & getDebitBal & "," & getDebitBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & arrCustids(idx) & "'," & _
                " '" & arrAccNames(idx) & "','N','Y','Chq Issue Charges Posting'," & _
                " '1','" & drException & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "')"

                tranCrQuery = "insert into " & Trim(ModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE) values(" & _
                   " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                   " '" & ModuleId & "','" & Glcode & "'," & _
                   " '" & arrAccnos(idx) & "','" & i_Batchno & "'," & _
                   " '" & i_TranNo & "'," & -arrTotalCharge(idx) & "," & _
                   " '3'," & getDebitBal & "," & _
                   " " & getDebitBal & "," & getDebitBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & arrCustids(idx) & "','" & arrAccNames(idx) & "'," & _
                   " 'N','Y','Chq Issue Charges Posting','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "')"
                objcommand = New OracleClient.OracleCommand(genCrQuery, _
                                                           ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnGenCrQuery = objcommand.ExecuteNonQuery
                If rtnGenCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into Trans Log")
                End If
                objcommand = New OracleClient.OracleCommand(tranCrQuery, _
                                                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                rtnTranCrQuery = objcommand.ExecuteNonQuery
                If rtnTranCrQuery <> 1 Then
                    Throw New Exception("Unable To Insert Debit Entry" & _
                    " into " & ModuleId & " Tran Day")
                End If
                ' sum, credit interest amount of A/c. holders which are existed in
                ' same branch
                sumDrChargeAmount = sumDrChargeAmount + arrTotalCharge(idx)
                prevBrCode = arrBrCodes(idx)

                '''''Credit Entry for last branch code A/c. Nos (OR) Single Branch
                ''    Code
                If idx = UBound(arrBrCodes) Then

                    ''rtnValue = AccBal.GetBalance(prevBrCode, CurrencyCode, _
                    ''creditModuleId, CreditGlCode, CreditAccNo)

                    ''If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                    ''    Throw New Exception("Error Occured While Getting Current" & _
                    ''    "Balance For Given Credit Account Where Credit GLCode = " & _
                    ''    CreditGlCode & " And Credit AccountNo = " & _
                    ''    CreditAccNo & " And Credit Module id = " & creditModuleId & _
                    ''    "and Branch Code =" & prevBrCode & " Currency Code = " & _
                    ''    CurrencyCode & " . The Error is " & rtnValue)
                    ''Else
                    ''    getCreditBal = Val(rtnValue)
                    ''End If

                    strQuery = "select GETANYDAYBAL('" & prevBrCode & "'," & _
                     " '" & CurrencyCode & "', '" & creditModuleId & "'," & _
                     " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                     " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "') from dual"
                    objcommand = New OracleClient.OracleCommand(strQuery, _
                                                             ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnValue = objcommand.ExecuteScalar
                    If Mid(UCase(Trim(rtnValue)), 1, 5) = "ERROR" Then
                        Throw New Exception("Unable to get Current Balance" & _
                            " of Credit GL " & CreditGlCode & " and Accno. " & _
                            CreditAccNo & ". " & vbNewLine & rtnValue)
                    Else
                        getCreditBal = CDbl(rtnValue)
                    End If
                    i_TranNo = objDBConnection.GetTranNo(arrBrCodes(idx))

                    genDrQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                  " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL,VERIFIEDTIMEBAL," & _
                    " APPROVEDTIMEBAL,EFFECTIVEDATE," & _
                    " CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE)" & _
                    " values('" & arrBrCodes(idx) & "'," & _
                    " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                    " '" & CreditGlCode & "','" & CreditAccNo & "'," & _
                    " '" & i_Batchno & "','" & i_TranNo & "'," & _
                    " " & sumDrChargeAmount & ",'4'," & getCreditBal & "," & _
                    " " & getCreditBal & "," & getCreditBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " 'N','Y','Chq Issue Charges Posting','1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "')"

                    tranDrQuery = "insert into " & Trim(creditModuleId) & "TRANDAY" & _
                      "(BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                       " EFFECTIVEDATE,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE) values(" & _
                       " '" & arrBrCodes(idx) & "','" & CurrencyCode & "'," & _
                       " '" & creditModuleId & "','" & CreditGlCode & "'," & _
                       " '" & CreditAccNo & "','" & i_Batchno & "'," & _
                       " '" & i_TranNo & "'," & sumDrChargeAmount & "," & _
                       " '4'," & getCreditBal & "," & _
                       " " & getCreditBal & "," & getCreditBal & "," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'N','Y','Chq Issue Charges Posting','1','N'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "'," & _
                       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'SYSTEM','" & MachineId & "')"

                    objcommand = New OracleClient.OracleCommand(genDrQuery, _
                                                               ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnGenDrQuery = objcommand.ExecuteNonQuery()
                    If rtnGenDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into Trans Log")
                    End If
                    objcommand = New OracleClient.OracleCommand(tranDrQuery, _
                                                                ObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    rtnTranDrQuery = objcommand.ExecuteNonQuery()
                    If rtnTranDrQuery <> 1 Then
                        Throw New Exception("Unable To Insert Credit Entry" & _
                        " into " & Trim(creditModuleId) & " Tran Day")
                    End If
                    '========================================================
                    'strQuery = "INSERT INTO GENEXCEPTIONALTRANDAY SELECT BRANCHCODE," & _
                    '"CURRENCYCODE,BATCHNO,TRANNO,'1',APPLICATIONDATE,SYSTEMDATE," & _
                    '"VERIFIEDBY,VERIFIEDMACHINE,APPROVEDDATE,APPROVEDSYSTEMDATE," & _
                    '"VERIFIEDSYSTEMDATE FROM GENTRANSLOG WHERE BRANCHCODE ='" & _
                    'arrBrCodes(idx) & "' AND CURRENCYCODE ='" & CurrencyCode & _
                    '"' AND BATCHNO= " & i_Batchno & " AND EXCEPTIONYN='Y'"

                    'objcommand = New OracleClient.OracleCommand(strQuery, _
                    '                                            ObjOracleConnection)
                    'objcommand.Transaction = objTransaction
                    'objcommand.ExecuteNonQuery()

                End If
            Next ''' End of Credit Interest Posting

            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = "CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Trim(Glcode) & "' and (BRANCHCODE,ACCNO)" & _
                " in(" & BulkArr(i) & ")"

                'SHARATH  ----------------------------
                'objHist.recordInHist(Trim(ModuleId) & "MST","LASTINTCALCDATE", _
                'ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                'strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                objHist.recordInHist(Trim(ModuleId) & "CHARGEDATEDTLS", _
                "LASTCHARGECALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                ' SHARATH ---------------------------------
                '  strQuery = "update " & Trim(ModuleId) & "MST set" & _
                ' " OPPLASTINTCALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                ' "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                ' " GLCODE ='" & Glcode & "' and" & _
                ' " (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") "

                strQuery = "update " & Trim(ModuleId) & "CHARGEDATEDTLS set" & _
                " LASTCHARGECALCDATE='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & _
                "' where CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and (BRANCHCODE,ACCNO) in(" & _
                BulkArr(i) & ")  AND CHARGETYPE='CIC'"

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                'If i_NoOfRows <> (UBound(arrAccnos) + 1) Then
                'Throw New Exception("Unable to Modify The LastIntCalcDate While" & _
                '" Crediting Interest")
                'End If

                '' inserting  charges posted accs. details 
                strProdDtlsCond = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) in(" & BulkArr(i) & ") AND CHARGETYPE='" & _
                ChargeType & "'"

                strQuery = "insert into " & Trim(ModuleId) & _
                 "CHARGEPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                 " MODULEID,GLCODE, ACCNO, VARCHARCOL1, CHRGCALCFROMDT," & _
                 " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                 " CURRENCYCOL2,USERID," & _
                 " MACHINEID,APPLICATIONDATE," & _
                 " VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                 " DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                 " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                 " VARCHARCOL1, CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                 " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                 " CURRENCYCOL2, '" & UserId & "','" & MachineId & "'," & _
                 " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                 " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                 MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                 "CHRGCALCTEMP where " & strProdDtlsCond

                objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()

                '' inserting Interest Not posted accno. details (missing accnos.)

                strIntDtlsNotPosted = "CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and CHRGCALCFROMDT='" & Format(ChargeCalcFromDt, "dd-MMM-yyyy") & _
                "' and CHRGCALCTODT='" & Format(ChargeCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' and" & _
                " MACHINEID='" & Trim(MachineId) & "' and" & _
                " APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and (BRANCHCODE,ACCNO) NOT IN (" & BulkArr(i) & _
                ") AND CHARGETYPE='" & ChargeType & "'"

                strQuery = "insert into  " & Trim(ModuleId) & _
                "CHARGENOTPOSTDTLS(BRANCHCODE,CURRENCYCODE," & _
                " MODULEID,GLCODE, ACCNO, VARCHARCOL1, CHRGCALCFROMDT," & _
                " CHRGCALCTODT,VARCHARCOL2,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                " CURRENCYCOL2,USERID," & _
                " MACHINEID,APPLICATIONDATE," & _
                " VARCHARCOL3,VARCHARCOL4,APPROVEDBY," & _
                " DATECOL1, APPROVEDMACHINE,CHARGETYPE)" & _
                " select BRANCHCODE,CURRENCYCODE,'" & ModuleId & "',GLCODE, ACCNO," & _
                " VARCHARCOL1, CHRGCALCFROMDT,CHRGCALCTODT,CUSTOMERID,NUMBERCOL1," & _
                " NUMBERCOL2,NUMBERCOL3,NUMBERCOL4,NUMBERCOL5,CURRENCYCOL1," & _
                " CURRENCYCOL2, '" & UserId & "','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " 'R','A','SYSTEM','" & Format(ApplicationDt, "dd-MMM-yyyy") & "','" & _
                MachineId & "','" & ChargeType & "' from " & Trim(ModuleId) & _
                "CHRGCALCTEMP where " & strIntDtlsNotPosted

                objcommand = New OracleClient.OracleCommand(strQuery, _
                            ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostSBCADebitChqIssCharges = True

            o_ErrMsg = "Batch No.: " & i_Batchno
            o_ErrMsg = Replace(o_ErrMsg, Chr(10), " ")
            o_ErrMsg = Replace(o_ErrMsg, Chr(13), " ")
        Catch ex As Exception
            PostSBCADebitChqIssCharges = False
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.SBCAOPERATIONS" & _
                               " / PostSBCADebitFolioCharges"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing Chq Issue Chrges Posting " & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing ChqIssueCharges Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function
End Class
