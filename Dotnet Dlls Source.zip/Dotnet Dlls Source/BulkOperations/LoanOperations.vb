
'*******************************************************************************
'*********************************************************************************
'*	Name Of the File : LoanOperations                                            * 
'*	Purpose	  	     : To do bulk operations w.r.t. Loan Module                  *
'*			                                            			             *
'|-------------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	         |         
'|----------------------|------------------|------------|------------------------|
'| G.Radhika            |    29-Oct-2007   |   1.0      |		                 |    
'|				        |                  |	        |                        |
'|-------------------------------------------------------------------------------|
'*********************************************************************************
'*********************************************************************************

Public Class LoanOperations
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim ObjOracleConnection As New OracleClient.OracleConnection
    Dim objTransaction As OracleClient.OracleTransaction

    Private Function GetAccBalance(ByVal BrCode As String, ByVal CurCode As String, _
        ByVal ModuleId As String, ByVal GlCode As String, ByVal AccNo As String, _
        Optional ByRef o_ObjTran As OracleClient.OracleTransaction = Nothing) _
        As Double

        Dim objCmd As OracleClient.OracleCommand
        Dim objDr As OracleClient.OracleDataReader
        Dim sQuery As String

        sQuery = "Select nvl(curbal,0) + nvl( (select sum(nvl(AMOUNT,0)) from gentranslog" & _
            " where branchcode='" & BrCode & "' and currencycode='" & _
            CurCode & "' and glcode='" & GlCode & "' and accno='" & AccNo & "') , 0) " & _
        " FROM " & Trim(ModuleId) & "BALANCE" & _
        " where branchcode='" & BrCode & "' and currencycode='" & _
        CurCode & "' and glcode='" & GlCode & "' and accno='" & AccNo & "'"

        objCmd = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
        If IsNothing(o_ObjTran) = False Then
            objCmd.Transaction = o_ObjTran
        End If
        objDr = objCmd.ExecuteReader
        If objDr.Read = False Then
            GetAccBalance = 0
        ElseIf IsDBNull(objDr(0)) = True Then
            GetAccBalance = 0
        Else
            GetAccBalance = objDr(0)
        End If
        objDr = Nothing
        objCmd = Nothing

    End Function

    Private Function GetDataReader(ByVal i_sQuery As String, _
        Optional ByRef o_ObjTran As OracleClient.OracleTransaction = Nothing) _
        As OracleClient.OracleDataReader

        Dim objCmd As OracleClient.OracleCommand

        objCmd = New OracleClient.OracleCommand(i_sQuery, ObjOracleConnection)
        If IsNothing(o_ObjTran) = False Then
            objCmd.Transaction = o_ObjTran
        End If
        GetDataReader = objCmd.ExecuteReader

    End Function

    Private Function ExecuteQuery(ByVal i_sQuery As String) As Integer

        Dim objCmd As OracleClient.OracleCommand

        objCmd = New OracleClient.OracleCommand(i_sQuery, ObjOracleConnection)
        objCmd.Transaction = objTransaction
        ExecuteQuery = objCmd.ExecuteNonQuery

    End Function

    Private Function GetDescription(ByVal i_sQuery As String, _
        Optional ByRef o_ObjTran As OracleClient.OracleTransaction = Nothing) _
        As String

        Dim objCmd As OracleClient.OracleCommand
        Dim objDr As OracleClient.OracleDataReader

        objCmd = New OracleClient.OracleCommand(i_sQuery, ObjOracleConnection)
        If IsNothing(o_ObjTran) = False Then
            objCmd.Transaction = o_ObjTran
        End If
        objDr = objCmd.ExecuteReader
        If objDr.Read = False Then
            GetDescription = ""
        ElseIf IsDBNull(objDr(0)) = True Then
            GetDescription = ""
        Else
            GetDescription = objDr(0)
        End If

        objDr = Nothing
        objCmd = Nothing

    End Function

    Public Function PostLoanOrCCSimpleInterest(ByVal CurrencyCode As String, _
       ByVal ModuleId As String, _
       ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
       ByVal IntCalcToDt As Date, ByVal roundOfParam As Double, _
       ByVal UserId As String, _
       ByVal ApplicationDt As Date, ByVal MachineId As String, _
       ByVal arrVals(,) As Object, ByVal TotalInterest As Double, _
       ByRef o_ErrMsg As String, _
       Optional ByVal BranchCode As String = "", _
       Optional ByVal FrmAccPre As String = "", _
       Optional ByVal FrmAccNo As String = "", _
       Optional ByVal FrmAccSuf As String = "", _
       Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Debit Interest to Loan/CC Accounts for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'LOAN' or 'CC' 
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= Customer Ids
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Calculated Interests
        'O_ErrMsg = Holds the Error Message (OR) Batch No. which will return 
        'to the caller function
        'BranchCode = Branch Code in which a/c's are existed
        'Outputs:
        ' if the whole process is successfully executed
        '    function PostLoanOrCCDebitInterest will return True with 
        '    (O_ErrMsg)=Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo, rtnAccBal As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, rtnExcQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, creditGlCode, creditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted As String

        Dim strremarks As String = ""
        Dim strcrremarks As String = ""
        Dim objgencls As New BulkOperations.GeneralCls



        Dim getDebitBal, getCreditBal, sumDrIntAmount, entryDebitAmount As Double
        sumDrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        Dim drObj As OracleClient.OracleDataReader
        Dim LoanMstReader As OracleClient.OracleDataReader
        Dim npaReader As OracleClient.OracleDataReader

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue, sQuery As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer
        Dim sTypeTable, sMstTable, sInterestType As String
        Dim DebitGlCode, DebitAccNo, DebitModId As String
        Dim NPAimplimentedYN, NPAStatus, NAME, strlastIntDtValue, POSTINTERESTYN, FldNames As String
        Dim FldValues, strCustCond As String
        Dim TotalUnpostedAmt, TotalNpaAmt As Double

        Try
            TotalInterest = 0
            TotalUnpostedAmt = 0
            TotalNpaAmt = 0
            sTypeTable = Trim(ModuleId) & "TypeMst"
            sMstTable = Trim(ModuleId) & "Mst"

            'Step 1: Get Database Connection
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Database Connection Failed. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            'arrCurBal = Split(arrVals(4, 0), ",")
            arrInterests = Split(arrVals(4, 0), ",")

            sQuery = "select NPAIMPLEMENTEDYN from GENBANKPARM"
            objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
            npaReader = objcommand.ExecuteReader

            If npaReader.Read = False Then
                Throw New Exception("Unable to read bank params details")
            End If

            NPAimplimentedYN = npaReader(0)
            npaReader.Close()
            npaReader = Nothing


            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                '  Verify In GENSYSTEMACTIVELOG  whether interest is  Posted
                ' for the Given Gl Code A/c's in Given Range of Dates

                ' Preparing the condition for Verifying the data with given 
                ' condition
                ' if not found in GENSYSTEMACTIVELOG will post the Entry
                ' for the same condition

                strQuery = " CURRENCYCODE='" & CurrencyCode & _
                "' and MODULEID='" & ModuleId & "'" & _
                " and GLCODE='" & Glcode & "' and ACTIVITYID='IC' and" & _
                " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                "' and BRANCHCODE='" & BranchCode & "'"

                strQuery = "select nvl(count(*),0) from GENSYSTEMACTIVITYLOG where " & strQuery
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                i_NoOfRows = objcommand.ExecuteScalar
                If i_NoOfRows <> 0 Then
                    Throw New Exception("Already " & ModuleId & " Interest Was Posted For This Period")
                End If
                objcommand = Nothing
            End If

            'Step 3: Get Type wise parameters of given Gl Code
            strQuery = "Select INTCREDITGLCODE IntCrGl ,INTCREDITACCNO IntCrAccno," & _
            " INTACCRUEDGLCODE IntAccrGl,MISCACCNO IntAccrAccNo,POSTINTERESTYN from " & _
            sTypeTable & " where upper(MODULEID)='" & UCase(ModuleId) & _
            "' and upper(GLCODE)='" & Glcode & "'"

            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
            drObj = objcommand.ExecuteReader

            If drObj.Read = False Then
                Throw New Exception("Unable to read details of given Gl Code form Typemaster")
            End If

            DebitGlCode = drObj("IntAccrGl")
            DebitAccNo = drObj("IntAccrAccNo")
            creditGlCode = drObj("IntCrGl")
            creditAccNo = drObj("IntCrAccno")
            POSTINTERESTYN = drObj("POSTINTERESTYN")

            'Get Module IDs of both Credit and debit GL Codes
            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & DebitGlCode & "'"
            DebitModId = GetDescription(strQuery)
            If DebitModId = "" Then
                Throw New Exception("Module Id for the GL " & DebitGlCode & " Not Available")
            End If

            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & creditGlCode & "'"
            creditModuleId = GetDescription(strQuery)
            If creditModuleId = "" Then
                Throw New Exception("Module Id for the GL " & creditGlCode & " Not Available")
            End If

            'Get balances of both Debit and Credit Accounts
            Dim DebitAccBal, CreditAccBal As Double
            Dim Batchno, DebitTranNo, CreditTranNo As Integer
            Dim DebitAccName, CreditAccName As String

            'Get Names of both Debit and credit a/c's
            strQuery = "select nvl(NAME,'') from " & Trim(DebitModId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(DebitGlCode) & "' and ACCNO='" & DebitAccNo & "'"
            DebitAccName = GetDescription(strQuery)
            If DebitAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & DebitAccNo & " GL " & DebitGlCode)
            End If

            strQuery = "select nvl(NAME,'') from " & Trim(creditModuleId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(creditGlCode) & "' and ACCNO='" & creditAccNo & "'"
            CreditAccName = GetDescription(strQuery)
            If CreditAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & creditAccNo & " GL " & creditGlCode)
            End If

            'Balance of Debit A/C 
            DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo)
            CreditAccBal = GetAccBalance(BranchCode, CurrencyCode, creditModuleId, creditGlCode, creditAccNo)

            Batchno = objDBConnection.GetBatchno(BranchCode)
            DebitTranNo = objDBConnection.GetTranNo(BranchCode)
            CreditTranNo = objDBConnection.GetTranNo(BranchCode)

            'Begin Transaction
            objTransaction = ObjOracleConnection.BeginTransaction()

            'Insert into Activity Log, if interest is NOT posting for a range of accounts of given gl
            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                  " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                  " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                  " STATUS,APPROVEDBY," & _
                  " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                  " ('" & BranchCode & "','" & CurrencyCode & "'," & _
                  " '" & ModuleId & "','" & Glcode & "'," & _
                 " 'IC','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "'," & _
                  " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                  " " & roundOfParam & "," & Batchno & ")"
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Data Into" & _
                    " GensystemActivityLog For The Branch " & BranchCode)
                End If
            End If

            'Save the Parameters like 
            'COL1=Interest Calculated From Date
            'COL2=Interest Calculated Upto Date
            'COL3=Glcode into which sum of loan interest was credited
            'COL4=Account No. into which sum of loan interest was credited
            'COL5=Value to round of the calculated interest
            'COL6=Prefix of the interest calculated accounts
            'COL7=A/C. No. from which interest was calculated
            'COL8=Suffix of the interest calculated accounts
            'COL9=A/C. No. upto which interest was calculated
            'COL10=Interest Type simple/compound
            'COL11=Compound Mode
            'COL12=Batch Number through which interest was posted
            strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6,COL7,COL8,COL9,COL10,COL11,COL12)" & _
                    " values('" & BranchCode & "'," & _
                    " '" & CurrencyCode & "','" & ModuleId & "'," & _
                    " '" & Glcode & "'," & _
                    " '" & UserId & "','" & MachineId & "','SYSTEM'," & _
                    " '" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                    " '" & creditGlCode & "','" & creditAccNo & "'," & _
                    " '" & roundOfParam & "','" & FrmAccPre & "'," & _
                    " '" & FrmAccNo & "','" & FrmAccSuf & "'," & _
                    " '" & ToAccNo & "','SIMPLE',''," & Batchno & ")"

            objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery
            If i_NoOfRows <> 1 Then
                Throw New Exception("Unable to Insert the data into" & _
                " Actual Parameters Table while Debiting " & ModuleId & _
                " interest")
            End If

            'Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
            'Reason: Oracle IN clause will not take too many values
            'And also Insert a Row into LOANINTACCRUEDDTLS table for each A/C
            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For idx = 0 To UBound(arrAccnos)

                Cnt += 1
                strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If

                sQuery = "select NPAStatus,NAME,LASTINTCALCDATE from " & ModuleId & "MST WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE='" & CurrencyCode & "' AND GLCODE='" & _
                Glcode & "' AND ACCNO='" & arrAccnos(idx) & "'"

                objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                LoanMstReader = objcommand.ExecuteReader

                If LoanMstReader.Read = False Then
                    Throw New Exception("Unable to read master details of given Account number" & arrAccnos(idx))
                End If

                NPAStatus = LoanMstReader("NPAStatus")
                NAME = IIf(IsDBNull(LoanMstReader("NAME")), "", LoanMstReader("NAME"))
                strlastIntDtValue = LoanMstReader("LASTINTCALCDATE")
                LoanMstReader.Close()
                LoanMstReader = Nothing

                If (POSTINTERESTYN = "N" And NPAimplimentedYN = "N") Or _
                (POSTINTERESTYN = "N" And (NPAimplimentedYN = "Y" And NPAStatus = "P")) Then

                    TotalUnpostedAmt = TotalUnpostedAmt + arrInterests(idx)

                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','Interest'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "UNPOSTINTEREST(" & FldNames & ") values(" & _
                    FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        ModuleId & " UNPOSTINTEREST For The accno " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                    " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                    " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set UNPOSTINTBAL= nvl(UNPOSTINTBAL,0) + " & _
                    CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To update UNPOSTINTBAL balance For The accno " & arrAccnos(idx))
                    End If

                ElseIf (NPAimplimentedYN = "Y" And NPAStatus = "N") Then

                    TotalNpaAmt = TotalNpaAmt + arrInterests(idx)

                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "NPAINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert npa interest Data Into NPAINTEREST " & _
                        " For a/c " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                     " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                     " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set NPAINTBAL=nvl(NPAINTBAL,0) + " & _
                    CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable update NPAINTBAL to balance table for a/c " & arrAccnos(idx))
                    End If

                Else

                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))

                    TotalInterest = TotalInterest + arrInterests(idx)

                    strQuery = "insert into " & Trim(ModuleId) & "INTACCRUEDDTLS" & _
                        "(BranchCode,CurrencyCode, ModuleId, Glcode, ACCNO, Batchno, TRANNO," & _
                        "DEBIT, CREDIT, APPLICATIONDATE, UserId, MachineId, TRANSTATUS, " & _
                        "SYSTEMDATE, APPROVEDBY, APPROVEDMACHINE, VERIFIEDBY, VERIFIEDMACHINE," & _
                        "SYSTEMYEAR,INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO,REMARKS) values(" & _
                        " '" & BranchCode & "','" & CurrencyCode & "'," & _
                        " '" & ModuleId & "','" & Glcode & "'," & _
                        " '" & arrAccnos(idx) & "'," & Batchno & "," & _
                        DebitTranNo & "," & arrInterests(idx) & "," & _
                        " 0,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "'," & _
                        " 'A',sysdate,'" & UserId & "','" & MachineId & "'," & _
                        " '" & UserId & "','" & MachineId & "'," & _
                        "to_number(to_char(sysdate,'yyyy')),'" & DebitModId & "','" & _
                        DebitGlCode & "','" & DebitAccNo & "','" & strremarks & "')"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Data into " & _
                        Trim(ModuleId) & "INTACCRUEDDTLS table for the A/C " & _
                        arrAccnos(idx))
                    End If
                End If
            Next idx

            If TotalInterest <> 0 Then
                'Then do Financial Transaction by Debiting Interest Accrued Gl and 
                'Crediting Interest Credit Gl in Type Master table 
                'Note: Sum of interest of all a/c's is to be debited at one shot
                strremarks = ""
                strremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")

                'Make Debit Entry first
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & DebitModId & "'," & _
                " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                " '" & Batchno & "','" & DebitTranNo & "'," & _
                " " & (-1 * TotalInterest) & ",'3'," & DebitAccBal & "," & _
                " " & DebitAccBal & "," & DebitAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Debit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & DebitModId & "','" & DebitGlCode & "'," & _
                   " '" & DebitAccNo & "','" & Batchno & "'," & _
                   " '" & DebitTranNo & "'," & (-1 * TotalInterest) & "," & _
                   " '3'," & DebitAccBal & "," & _
                   " " & DebitAccBal & "," & DebitAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & DebitAccName & "'," & _
                   " 'N','Y','" & strremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Debit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If

                strcrremarks = ""
                strcrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
                'Make Credit Entry first
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                " '" & creditGlCode & "','" & creditAccNo & "'," & _
                " '" & Batchno & "','" & CreditTranNo & "'," & _
                " " & TotalInterest & ",'4'," & CreditAccBal & "," & _
                " " & CreditAccBal & "," & CreditAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & CreditAccName & "','N','Y','" & strcrremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(creditModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & creditModuleId & "','" & creditGlCode & "'," & _
                   " '" & creditAccNo & "','" & Batchno & "'," & _
                   " '" & CreditTranNo & "'," & TotalInterest & "," & _
                   " '4'," & CreditAccBal & "," & _
                   " " & CreditAccBal & "," & CreditAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & CreditAccName & "'," & _
                   " 'N','Y','" & strcrremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If
            End If

            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If


            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = "BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and GLCODE ='" & _
                Trim(Glcode) & "' and ACCNO in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
                " LASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " where BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and ACCNO in(" & BulkArr(i) & ") "

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows = 0 Then
                    Throw New Exception("Unable To update Last Int Calc Date of " & _
                    "certain Accounts")
                End If

                'Inserting  interest posted accs. details 
                strProdDtlsCond = "BranchCode='" & BranchCode & "'" & _
                " and CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                " and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' " & _
                " and MACHINEID='" & Trim(MachineId) & "'" & _
                " and APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and ACCNO in(" & BulkArr(i) & ")"


                strQuery = "insert into " & Trim(ModuleId) & "INTERESTDTLS " & _
                "(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE) " & _
                " Select BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE from " & Trim(ModuleId) & "INTCALTEMP" & _
                 " where " & strProdDtlsCond

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows = 0 Then
                    Throw New Exception("Unable To Insert Loan Products Details")
                End If

            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostLoanOrCCSimpleInterest = True


            o_ErrMsg = "Transaction Successfull" & Chr(13)

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Batch No.: " & Batchno & Chr(13)
            End If

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Interest Accrured = " & CStr(TotalInterest) & Chr(13) & _
                " credit P/L account = " & CStr(TotalInterest) & Chr(13)
            End If

            If POSTINTERESTYN = "N" Then
                o_ErrMsg = o_ErrMsg & " Total Unposted interest= " & CStr(TotalUnpostedAmt) & Chr(13)
            End If

            If NPAimplimentedYN = "Y" Then
                o_ErrMsg = o_ErrMsg & " Total Npa interest= " & CStr(TotalNpaAmt)
            End If

            ''o_ErrMsg = "Batch No.: " & Batchno & Chr(13) & _
            ''" Debit Interest Accrured = " & CStr(TotalInterest) & " credit P/L account" & Chr(13) & _
            ''" Total Unposted amount= " & CStr(TotalUnpostedAmt) & Chr(13) & _
            ''" Total Npa Amount= " & CStr(TotalNpaAmt)


        Catch ex As Exception
            PostLoanOrCCSimpleInterest = False
            objTransaction.Rollback()
            ObjOracleConnection.Close()

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.LoanOPERATIONS" & _
                               " / PostLoanOrCCSimpleInterest"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing Loan or CC Simple Interest Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing Loan or CC Simple Interest Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function
    Public Function PostLoanOrCCSimpleInterestPenal(ByVal CurrencyCode As String, _
           ByVal ModuleId As String, _
           ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
           ByVal IntCalcToDt As Date, ByVal roundOfParam As Double, _
           ByVal UserId As String, _
           ByVal ApplicationDt As Date, ByVal MachineId As String, _
           ByVal arrVals(,) As Object, ByVal TotalInterest As Double, _
           ByRef o_ErrMsg As String, _
           Optional ByVal BranchCode As String = "", _
           Optional ByVal FrmAccPre As String = "", _
           Optional ByVal FrmAccNo As String = "", _
           Optional ByVal FrmAccSuf As String = "", _
           Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Debit Interest to Loan/CC Accounts for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'LOAN' or 'CC' 
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= Customer Ids
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Calculated Interests
        'O_ErrMsg = Holds the Error Message (OR) Batch No. which will return 
        'to the caller function
        'BranchCode = Branch Code in which a/c's are existed
        'Outputs:
        ' if the whole process is successfully executed
        '    function PostLoanOrCCDebitInterest will return True with 
        '    (O_ErrMsg)=Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo, rtnAccBal As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, rtnExcQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrbelowlimitint, arrabovelimitint, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, creditGlCode, creditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted As String

        Dim strremarks As String = ""
        Dim strcrremarks As String = ""
        Dim objgencls As New BulkOperations.GeneralCls


        Dim getDebitBal, getCreditBal, sumDrIntAmount, entryDebitAmount As Double
        sumDrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        Dim drObj As OracleClient.OracleDataReader
        Dim LoanMstReader As OracleClient.OracleDataReader
        Dim npaReader As OracleClient.OracleDataReader

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue, sQuery As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer
        Dim sTypeTable, sMstTable, sInterestType As String
        Dim DebitGlCode, DebitAccNo, DebitModId As String
        Dim NPAimplimentedYN, NPAStatus, NAME, strlastIntDtValue, POSTINTERESTYN, FldNames As String
        Dim FldValues, strCustCond As String
        Dim TotalUnpostedAmt, TotalNpaAmt As Double
        Dim TotalBelowlimitInterest As Double
        Dim TotalAbovelimitInterest As Double
        Try
            TotalInterest = 0
            TotalBelowlimitInterest = 0
            TotalAbovelimitInterest = 0
            TotalUnpostedAmt = 0
            TotalNpaAmt = 0
            sTypeTable = Trim(ModuleId) & "TypeMst"
            sMstTable = Trim(ModuleId) & "Mst"

            'Step 1: Get Database Connection
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Database Connection Failed. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            'arrCurBal = Split(arrVals(4, 0), ",")
            arrInterests = Split(arrVals(4, 0), ",")
            arrbelowlimitint = Split(arrVals(5, 0), ",")
            arrabovelimitint = Split(arrVals(6, 0), ",")
            sQuery = "select NPAIMPLEMENTEDYN from GENBANKPARM"
            objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
            npaReader = objcommand.ExecuteReader

            If npaReader.Read = False Then
                Throw New Exception("Unable to read bank params details")
            End If

            NPAimplimentedYN = npaReader(0)
            npaReader.Close()
            npaReader = Nothing


            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                '  Verify In GENSYSTEMACTIVELOG  whether interest is  Posted
                ' for the Given Gl Code A/c's in Given Range of Dates

                ' Preparing the condition for Verifying the data with given 
                ' condition
                ' if not found in GENSYSTEMACTIVELOG will post the Entry
                ' for the same condition

                strQuery = " CURRENCYCODE='" & CurrencyCode & _
                "' and MODULEID='" & ModuleId & "'" & _
                " and GLCODE='" & Glcode & "' and ACTIVITYID='IC' and" & _
                " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                "' and BRANCHCODE='" & BranchCode & "'"

                strQuery = "select nvl(count(*),0) from GENSYSTEMACTIVITYLOG where " & strQuery
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                i_NoOfRows = objcommand.ExecuteScalar
                If i_NoOfRows <> 0 Then
                    Throw New Exception("Already " & ModuleId & " Interest Was Posted For This Period")
                End If
                objcommand = Nothing
            End If

            'Step 3: Get Type wise parameters of given Gl Code
            strQuery = "Select INTCREDITGLCODE IntCrGl ,INTCREDITACCNO IntCrAccno," & _
            " INTACCRUEDGLCODE IntAccrGl,MISCACCNO IntAccrAccNo,POSTINTERESTYN from " & _
            sTypeTable & " where upper(MODULEID)='" & UCase(ModuleId) & _
            "' and upper(GLCODE)='" & Glcode & "'"

            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
            drObj = objcommand.ExecuteReader

            If drObj.Read = False Then
                Throw New Exception("Unable to read details of given Gl Code form Typemaster")
            End If

            DebitGlCode = drObj("IntAccrGl")
            DebitAccNo = drObj("IntAccrAccNo")
            creditGlCode = drObj("IntCrGl")
            creditAccNo = drObj("IntCrAccno")
            POSTINTERESTYN = drObj("POSTINTERESTYN")

            'Get Module IDs of both Credit and debit GL Codes
            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & DebitGlCode & "'"
            DebitModId = GetDescription(strQuery)
            If DebitModId = "" Then
                Throw New Exception("Module Id for the GL " & DebitGlCode & " Not Available")
            End If

            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & creditGlCode & "'"
            creditModuleId = GetDescription(strQuery)
            If creditModuleId = "" Then
                Throw New Exception("Module Id for the GL " & creditGlCode & " Not Available")
            End If

            'Get balances of both Debit and Credit Accounts
            Dim DebitAccBal, CreditAccBal As Double
            Dim Batchno, DebitTranNo, DebitTranNo1, CreditTranNo As Integer
            Dim DebitAccName, CreditAccName As String

            'Get Names of both Debit and credit a/c's
            strQuery = "select nvl(NAME,'') from " & Trim(DebitModId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(DebitGlCode) & "' and ACCNO='" & DebitAccNo & "'"
            DebitAccName = GetDescription(strQuery)
            If DebitAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & DebitAccNo & " GL " & DebitGlCode)
            End If

            strQuery = "select nvl(NAME,'') from " & Trim(creditModuleId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(creditGlCode) & "' and ACCNO='" & creditAccNo & "'"
            CreditAccName = GetDescription(strQuery)
            If CreditAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & creditAccNo & " GL " & creditGlCode)
            End If

            'Balance of Debit A/C 
            DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo)
            CreditAccBal = GetAccBalance(BranchCode, CurrencyCode, creditModuleId, creditGlCode, creditAccNo)

            Batchno = objDBConnection.GetBatchno(BranchCode)
            DebitTranNo = objDBConnection.GetTranNo(BranchCode)
            CreditTranNo = objDBConnection.GetTranNo(BranchCode)

            'Begin Transaction
            objTransaction = ObjOracleConnection.BeginTransaction()

            'Insert into Activity Log, if interest is NOT posting for a range of accounts of given gl
            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                  " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                  " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                  " STATUS,APPROVEDBY," & _
                  " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                  " ('" & BranchCode & "','" & CurrencyCode & "'," & _
                  " '" & ModuleId & "','" & Glcode & "'," & _
                 " 'IC','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "'," & _
                  " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                  " " & roundOfParam & "," & Batchno & ")"
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Data Into" & _
                    " GensystemActivityLog For The Branch " & BranchCode)
                End If
            End If

            'Save the Parameters like 
            'COL1=Interest Calculated From Date
            'COL2=Interest Calculated Upto Date
            'COL3=Glcode into which sum of loan interest was credited
            'COL4=Account No. into which sum of loan interest was credited
            'COL5=Value to round of the calculated interest
            'COL6=Prefix of the interest calculated accounts
            'COL7=A/C. No. from which interest was calculated
            'COL8=Suffix of the interest calculated accounts
            'COL9=A/C. No. upto which interest was calculated
            'COL10=Interest Type simple/compound
            'COL11=Compound Mode
            'COL12=Batch Number through which interest was posted
            strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6,COL7,COL8,COL9,COL10,COL11,COL12)" & _
                    " values('" & BranchCode & "'," & _
                    " '" & CurrencyCode & "','" & ModuleId & "'," & _
                    " '" & Glcode & "'," & _
                    " '" & UserId & "','" & MachineId & "','SYSTEM'," & _
                    " '" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                    " '" & creditGlCode & "','" & creditAccNo & "'," & _
                    " '" & roundOfParam & "','" & FrmAccPre & "'," & _
                    " '" & FrmAccNo & "','" & FrmAccSuf & "'," & _
                    " '" & ToAccNo & "','SIMPLE',''," & Batchno & ")"

            objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery
            If i_NoOfRows <> 1 Then
                Throw New Exception("Unable to Insert the data into" & _
                " Actual Parameters Table while Debiting " & ModuleId & _
                " interest")
            End If

            'Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
            'Reason: Oracle IN clause will not take too many values
            'And also Insert a Row into LOANINTACCRUEDDTLS table for each A/C
            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            For idx = 0 To UBound(arrAccnos)

                Cnt += 1
                strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If

                sQuery = "select NPAStatus,NAME,LASTINTCALCDATE from " & ModuleId & "MST WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE='" & CurrencyCode & "' AND GLCODE='" & _
                Glcode & "' AND ACCNO='" & arrAccnos(idx) & "'"

                objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                LoanMstReader = objcommand.ExecuteReader

                If LoanMstReader.Read = False Then
                    Throw New Exception("Unable to read master details of given Account number" & arrAccnos(idx))
                End If

                NPAStatus = LoanMstReader("NPAStatus")
                NAME = IIf(IsDBNull(LoanMstReader("NAME")), "", LoanMstReader("NAME"))
                strlastIntDtValue = LoanMstReader("LASTINTCALCDATE")
                LoanMstReader.Close()
                LoanMstReader = Nothing

                If (POSTINTERESTYN = "N" And NPAimplimentedYN = "N") Or _
                (POSTINTERESTYN = "N" And (NPAimplimentedYN = "Y" And NPAStatus = "P")) Then

                    TotalUnpostedAmt = TotalUnpostedAmt + arrInterests(idx)

                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','Interest'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "UNPOSTINTEREST(" & FldNames & ") values(" & _
                    FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        ModuleId & " UNPOSTINTEREST For The accno " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                    " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                    " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set UNPOSTINTBAL= nvl(UNPOSTINTBAL,0) + " & _
                    CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To update UNPOSTINTBAL balance For The accno " & arrAccnos(idx))
                    End If

                ElseIf (NPAimplimentedYN = "Y" And NPAStatus = "N") Then

                    TotalNpaAmt = TotalNpaAmt + arrInterests(idx)

                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))
                    strremarks = "Penal " & strremarks

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "NPAINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert npa interest Data Into NPAINTEREST " & _
                        " For a/c " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                     " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                     " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set NPAINTBAL=nvl(NPAINTBAL,0) + " & _
                    CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable update NPAINTBAL to balance table for a/c " & arrAccnos(idx))
                    End If

                Else

                    TotalInterest = TotalInterest + arrInterests(idx)

                    ''' Below limit Bal
                    If arrbelowlimitint(idx) <> 0 Then
                        strremarks = ""
                        strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))
                        '   strremarks = "Penal " & strremarks
                        TotalBelowlimitInterest = TotalBelowlimitInterest + arrbelowlimitint(idx)

                        strQuery = "insert into " & Trim(ModuleId) & "INTACCRUEDDTLS" & _
                            "(BranchCode,CurrencyCode, ModuleId, Glcode, ACCNO, Batchno, TRANNO," & _
                            "DEBIT, CREDIT, APPLICATIONDATE, UserId, MachineId, TRANSTATUS, " & _
                            "SYSTEMDATE, APPROVEDBY, APPROVEDMACHINE, VERIFIEDBY, VERIFIEDMACHINE," & _
                            "SYSTEMYEAR,INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO,REMARKS) values(" & _
                            " '" & BranchCode & "','" & CurrencyCode & "'," & _
                            " '" & ModuleId & "','" & Glcode & "'," & _
                            " '" & arrAccnos(idx) & "'," & Batchno & "," & _
                            DebitTranNo & "," & arrbelowlimitint(idx) & "," & _
                            " 0,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                            " '" & UserId & "','" & MachineId & "'," & _
                            " 'A',sysdate,'" & UserId & "','" & MachineId & "'," & _
                            " '" & UserId & "','" & MachineId & "'," & _
                            "to_number(to_char(sysdate,'yyyy')),'" & DebitModId & "','" & _
                            DebitGlCode & "','" & DebitAccNo & "','" & strremarks & "')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Below Limit Interest into " & _
                            Trim(ModuleId) & "INTACCRUEDDTLS table for the A/C " & _
                            arrAccnos(idx))
                        End If
                    End If

                    ''' Above Limit Bal
                    If arrabovelimitint(idx) <> 0 Then
                      
                        strremarks = ""
                        strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))
                        strremarks = "Penal " & strremarks

                        TotalAbovelimitInterest = TotalAbovelimitInterest + arrabovelimitint(idx)

                        strQuery = "insert into " & Trim(ModuleId) & "INTACCRUEDDTLS" & _
                           "(BranchCode,CurrencyCode, ModuleId, Glcode, ACCNO, Batchno, TRANNO," & _
                           "DEBIT, CREDIT, APPLICATIONDATE, UserId, MachineId, TRANSTATUS, " & _
                           "SYSTEMDATE, APPROVEDBY, APPROVEDMACHINE, VERIFIEDBY, VERIFIEDMACHINE," & _
                           "SYSTEMYEAR,INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO,REMARKS) values(" & _
                           " '" & BranchCode & "','" & CurrencyCode & "'," & _
                           " '" & ModuleId & "','" & Glcode & "'," & _
                           " '" & arrAccnos(idx) & "'," & Batchno & "," & _
                           DebitTranNo & "," & arrabovelimitint(idx) & "," & _
                           " 0,'" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " '" & UserId & "','" & MachineId & "'," & _
                           " 'A',sysdate,'" & UserId & "','" & MachineId & "'," & _
                           " '" & UserId & "','" & MachineId & "'," & _
                           "to_number(to_char(sysdate,'yyyy')),'" & DebitModId & "','" & _
                           DebitGlCode & "','" & DebitAccNo & "','" & strremarks & "')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Above Limit Interest into " & _
                            Trim(ModuleId) & "INTACCRUEDDTLS table for the A/C " & _
                            arrAccnos(idx))
                        End If
                    End If
                    End If
            Next idx


            'Then do Financial Transaction by Debiting Interest Accrued Gl and 
            'Crediting Interest Credit Gl in Type Master table 
            'Note: Sum of interest of all a/c's is to be debited at one shot
            ''' start below limit interest
            strremarks = ""
            strremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")

            If TotalBelowlimitInterest <> 0 Then
                'Make Debit Entry first
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & DebitModId & "'," & _
                " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                " '" & Batchno & "','" & DebitTranNo & "'," & _
                " " & (-1 * TotalBelowlimitInterest) & ",'3'," & DebitAccBal & "," & _
                " " & DebitAccBal & "," & DebitAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Below Limit Interest Debit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & DebitModId & "','" & DebitGlCode & "'," & _
                   " '" & DebitAccNo & "','" & Batchno & "'," & _
                   " '" & DebitTranNo & "'," & (-1 * TotalBelowlimitInterest) & "," & _
                   " '3'," & DebitAccBal & "," & _
                   " " & DebitAccBal & "," & DebitAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & DebitAccName & "'," & _
                   " 'N','Y','" & strremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Below Limit Interest Debit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If
            End If
            ''' end below limit interest
            ''' start above limit interest 
            strremarks = ""
            strremarks = " Penal INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
            If TotalAbovelimitInterest <> 0 Then
                'Make Debit Entry first
                DebitTranNo1 = objDBConnection.GetTranNo(BranchCode)

                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & DebitModId & "'," & _
                " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                " '" & Batchno & "','" & DebitTranNo1 & "'," & _
                " " & (-1 * TotalAbovelimitInterest) & ",'3'," & DebitAccBal & "," & _
                " " & DebitAccBal & "," & DebitAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Above Limit Interest Debit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & DebitModId & "','" & DebitGlCode & "'," & _
                   " '" & DebitAccNo & "','" & Batchno & "'," & _
                   " '" & DebitTranNo1 & "'," & (-1 * TotalAbovelimitInterest) & "," & _
                   " '3'," & DebitAccBal & "," & _
                   " " & DebitAccBal & "," & DebitAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & DebitAccName & "'," & _
                   " 'N','Y','" & strremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Above Limit Interest Debit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If
            End If
            ''' end  above limit interest 

            strcrremarks = ""
            strcrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
            If TotalInterest <> 0 Then
                'Make Credit Entry first
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                " '" & creditGlCode & "','" & creditAccNo & "'," & _
                " '" & Batchno & "','" & CreditTranNo & "'," & _
                " " & TotalInterest & ",'4'," & CreditAccBal & "," & _
                " " & CreditAccBal & "," & CreditAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & CreditAccName & "','N','Y','" & strcrremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(creditModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & creditModuleId & "','" & creditGlCode & "'," & _
                   " '" & creditAccNo & "','" & Batchno & "'," & _
                   " '" & CreditTranNo & "'," & TotalInterest & "," & _
                   " '4'," & CreditAccBal & "," & _
                   " " & CreditAccBal & "," & CreditAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & CreditAccName & "'," & _
                   " 'N','Y','" & strcrremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If

            End If

            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If


            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = "BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and GLCODE ='" & _
                Trim(Glcode) & "' and ACCNO in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
                " LASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " where BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and ACCNO in(" & BulkArr(i) & ") "

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows = 0 Then
                    Throw New Exception("Unable To update Last Int Calc Date of " & _
                    "certain Accounts")
                End If

                'Inserting  interest posted accs. details 
                strProdDtlsCond = "BranchCode='" & BranchCode & "'" & _
                " and CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                " and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' " & _
                " and MACHINEID='" & Trim(MachineId) & "'" & _
                " and APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and ACCNO in(" & BulkArr(i) & ")"


                strQuery = "insert into " & Trim(ModuleId) & "INTERESTDTLS " & _
                "(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE) " & _
                " Select BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE from " & Trim(ModuleId) & "INTCALTEMP" & _
                 " where " & strProdDtlsCond

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows = 0 Then
                    Throw New Exception("Unable To Insert Loan Products Details")
                End If

            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostLoanOrCCSimpleInterestPenal = True


            o_ErrMsg = "Transaction Successfull" & Chr(13)

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Batch No.: " & Batchno & Chr(13)
            End If

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Interest Accrured = " & CStr(TotalInterest) & Chr(13) & _
                " credit P/L account = " & CStr(TotalInterest) & Chr(13)
            End If

            If TotalBelowlimitInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Below Limit Interest Accrured = " & CStr(TotalBelowlimitInterest) & Chr(13)
            End If

            If TotalAbovelimitInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Above Limit Interest Accrured = " & CStr(TotalAbovelimitInterest) & Chr(13)
            End If

            If POSTINTERESTYN = "N" Then
                o_ErrMsg = o_ErrMsg & " Total Unposted interest= " & CStr(TotalUnpostedAmt) & Chr(13)
            End If

            If NPAimplimentedYN = "Y" Then
                o_ErrMsg = o_ErrMsg & " Total Npa interest= " & CStr(TotalNpaAmt)
            End If

            ''o_ErrMsg = "Batch No.: " & Batchno & Chr(13) & _
            ''" Debit Interest Accrured = " & CStr(TotalInterest) & " credit P/L account" & Chr(13) & _
            ''" Total Unposted amount= " & CStr(TotalUnpostedAmt) & Chr(13) & _
            ''" Total Npa Amount= " & CStr(TotalNpaAmt)


        Catch ex As Exception
            PostLoanOrCCSimpleInterestPenal = False
            objTransaction.Rollback()
            ObjOracleConnection.Close()

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.LoanOPERATIONS" & _
                               " / PostLoanOrCCSimpleInterestPenal"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing Loan or CC Simple Interest Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing Loan or CC Simple Interest Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Public Function PostLoanOrCCCompoundInterest(ByVal CurrencyCode As String, _
       ByVal ModuleId As String, _
       ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
       ByVal IntCalcToDt As Date, ByVal RoundOfParam As Double, _
       ByVal UserId As String, _
       ByVal ApplicationDt As Date, ByVal MachineId As String, _
       ByVal arrVals(,) As Object, ByVal TotalInterest As Double, _
       ByRef o_ErrMsg As String, ByVal CompoundMode As String, _
       Optional ByVal BranchCode As String = "", _
       Optional ByVal FrmAccPre As String = "", _
       Optional ByVal FrmAccNo As String = "", _
       Optional ByVal FrmAccSuf As String = "", _
       Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Debit Interest to Loan/CC Accounts for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'LOAN' or 'CC' 
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= Customer Ids
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Calculated Interests
        'O_ErrMsg = Holds the Error Message (OR) Batch No. which will return 
        'to the caller function
        'BranchCode = Branch Code in which a/c's are existed
        'Outputs:
        ' if the whole process is successfully executed
        '    function PostLoanOrCCDebitInterest will return True with 
        '    (O_ErrMsg)=Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo, rtnAccBal As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, rtnExcQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, creditGlCode, creditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted As String

        Dim strremarks As String = ""
        Dim strcrremarks As String = ""
        Dim objgencls As New BulkOperations.GeneralCls

        Dim getDebitBal, getCreditBal, sumDrIntAmount, entryDebitAmount As Double
        sumDrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        Dim drObj As OracleClient.OracleDataReader

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue, sQuery As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer
        Dim sTypeTable, sMstTable, sInterestType As String
        Dim DebitGlCode, DebitAccNo, DebitModId, NPAimplimentedYN, POSTINTERESTYN, NPAStatus, NAME, FldNames, FldValues, strlastIntDtValue, strCustCond As String
        Dim npaReader As OracleClient.OracleDataReader
        Dim LoanMstReader As OracleClient.OracleDataReader
        Dim TotalUnpostedAmt, TotalNpaAmt As Double

        Try
            TotalInterest = 0
            TotalUnpostedAmt = 0
            TotalNpaAmt = 0

            ''Need to take the sum of interests of only performing accounts 
            TotalInterest = 0
            sTypeTable = Trim(ModuleId) & "TypeMst"
            sMstTable = Trim(ModuleId) & "Mst"

            'Step 1: Get Database Connection
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Database Connection Failed. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            arrInterests = Split(arrVals(4, 0), ",")

            sQuery = "select NPAIMPLEMENTEDYN from GENBANKPARM"
            objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
            npaReader = objcommand.ExecuteReader

            If npaReader.Read = False Then
                Throw New Exception("Unable to read bank params details")
            End If

            NPAimplimentedYN = npaReader(0)
            npaReader.Close()
            npaReader = Nothing

            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                '  Verify In GENSYSTEMACTIVELOG  whether interest is  Posted
                ' for the Given Gl Code A/c's in Given Range of Dates

                ' Preparing the condition for Verifying the data with given 
                ' condition
                ' if not found in GENSYSTEMACTIVELOG will post the Entry
                ' for the same condition

                strQuery = " CURRENCYCODE='" & CurrencyCode & _
                "' and MODULEID='" & ModuleId & "'" & _
                " and GLCODE='" & Glcode & "' and ACTIVITYID='IC' and" & _
                " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                "' and BRANCHCODE='" & BranchCode & "'"

                strQuery = "select nvl(count(*),0) from GENSYSTEMACTIVITYLOG where " & strQuery
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                i_NoOfRows = objcommand.ExecuteScalar
                If i_NoOfRows <> 0 Then
                    Throw New Exception("Already " & ModuleId & " Interest Was Posted For This Period")
                End If
                objcommand = Nothing
            End If

            'Step 3: Get Type wise parameters of given Gl Code
            strQuery = "Select INTCREDITGLCODE IntCrGl ,INTCREDITACCNO IntCrAccno,POSTINTERESTYN" & _
            "  from " & sTypeTable & " where upper(MODULEID)='" & UCase(ModuleId) & _
            "' and upper(GLCODE)='" & Glcode & "'"

            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
            drObj = objcommand.ExecuteReader

            If drObj.Read = False Then
                Throw New Exception("Unable to read details of given Gl Code")
            End If

            creditGlCode = drObj("IntCrGl")
            creditAccNo = drObj("IntCrAccno")
            POSTINTERESTYN = drObj("POSTINTERESTYN")

            'Get Module ID of Credit GL Code
            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & creditGlCode & "'"
            creditModuleId = GetDescription(strQuery)
            If creditModuleId = "" Then
                Throw New Exception("Module Id for the GL " & creditGlCode & " Not Available")
            End If

            'Get balance of Credit Account
            Dim DebitAccBal, CreditAccBal As Double
            Dim Batchno, DebitTranNo, CreditTranNo As Integer
            Dim DebitAccName, CreditAccName As String

            'Get Name of credit a/c
            strQuery = "select nvl(NAME,'') from " & Trim(creditModuleId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(creditGlCode) & "' and ACCNO='" & creditAccNo & "'"
            CreditAccName = GetDescription(strQuery)
            If CreditAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & creditAccNo & " GL " & creditGlCode)
            End If

            'Balance of credit A/C 
            CreditAccBal = GetAccBalance(BranchCode, CurrencyCode, creditModuleId, creditGlCode, creditAccNo)

            Batchno = objDBConnection.GetBatchno(BranchCode)
            CreditTranNo = objDBConnection.GetTranNo(BranchCode)

            'Begin Transaction
            objTransaction = ObjOracleConnection.BeginTransaction()

            'Insert into Activity Log, if interest is NOT posting for a range of accounts of given gl
            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                  " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                  " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                  " STATUS,APPROVEDBY," & _
                  " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                  " ('" & BranchCode & "','" & CurrencyCode & "'," & _
                  " '" & ModuleId & "','" & Glcode & "'," & _
                 " 'IC','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "'," & _
                  " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                  " " & RoundOfParam & "," & Batchno & ")"
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Data Into" & _
                    " GensystemActivityLog For The Branch " & BranchCode)
                End If
            End If

            'Save the Parameters like 
            'COL1=Interest Calculated From Date
            'COL2=Interest Calculated Upto Date
            'COL3=Glcode into which sum of loan interest was credited
            'COL4=Account No. into which sum of loan interest was credited
            'COL5=Value to round of the calculated interest
            'COL6=Prefix of the interest calculated accounts
            'COL7=A/C. No. from which interest was calculated
            'COL8=Suffix of the interest calculated accounts
            'COL9=A/C. No. upto which interest was calculated
            'COL10=Interest Type simple/compound
            'COL11=Compound Mode
            'COL12=Batch Number through which interest was posted
            strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6,COL7,COL8,COL9,COL10,COL11,COL12)" & _
                    " values('" & BranchCode & "'," & _
                    " '" & CurrencyCode & "','" & ModuleId & "'," & _
                    " '" & Glcode & "'," & _
                    " '" & UserId & "','" & MachineId & "','SYSTEM'," & _
                    " '" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                    " '" & creditGlCode & "','" & creditAccNo & "'," & _
                    " '" & RoundOfParam & "','" & FrmAccPre & "'," & _
                    " '" & FrmAccNo & "','" & FrmAccSuf & "'," & _
                    " '" & ToAccNo & "','COMPOUND','" & CompoundMode & "'," & Batchno & ")"

            objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery
            If i_NoOfRows <> 1 Then
                Throw New Exception("Unable to Insert the data into" & _
                " Actual Parameters Table")
            End If

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            ''------------------------------------------------------------------
            ''Check if NPA is implimented or unposted concept is implimented
            For idx = 0 To UBound(arrAccnos)

                'Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
                'Reason: Oracle IN clause will not take too many values
                'And also make Debit Entry w.r.t. to each a/c
                Cnt += 1
                strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If

                sQuery = "select NPAStatus,NAME,LASTINTCALCDATE from " & ModuleId & "MST WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE='" & CurrencyCode & "' AND GLCODE='" & _
                Glcode & "' AND ACCNO='" & arrAccnos(idx) & "'"

                objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                LoanMstReader = objcommand.ExecuteReader

                If LoanMstReader.Read = False Then
                    Throw New Exception("Unable to read details of given Account number" & arrAccnos(idx))
                End If

                NPAStatus = LoanMstReader("NPAStatus")
                NAME = IIf(IsDBNull(LoanMstReader("NAME")), "", LoanMstReader("NAME"))
                strlastIntDtValue = LoanMstReader("LASTINTCALCDATE")
                LoanMstReader.Close()
                LoanMstReader = Nothing

                If (POSTINTERESTYN = "N" And NPAimplimentedYN = "N") Or _
                (POSTINTERESTYN = "N" And (NPAimplimentedYN = "Y" And NPAStatus = "P")) Then

                    TotalUnpostedAmt = TotalUnpostedAmt + arrInterests(idx)
                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','Interest'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "UNPOSTINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        ModuleId & " UNPOSTINTEREST For The accno " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                    " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                    " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set UNPOSTINTBAL= nvl(UNPOSTINTBAL,0) + " & CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To update UNPOSTINTBAL balance For The accno " & arrAccnos(idx))
                    End If

                ElseIf (NPAimplimentedYN = "Y" And NPAStatus = "N") Then

                    TotalNpaAmt = TotalNpaAmt + arrInterests(idx)
                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "NPAINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        " GenTransLog For The Branch " & BranchCode)
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                     " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                     " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set NPAINTBAL=nvl(NPAINTBAL,0) + " & CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        " GenTransLog For The Branch " & BranchCode)
                    End If

                Else
                    ''else debit form account
                    DebitModId = ModuleId
                    DebitGlCode = Glcode
                    DebitTranNo = objDBConnection.GetTranNo(BranchCode)
                    DebitAccNo = arrAccnos(idx)
                    DebitAccName = arrAccNames(idx)

                    TotalInterest = TotalInterest + arrInterests(idx)
                    'Balance of Loan/CC A/C 
                    DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo, objTransaction)
                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo)

                    'Make Debit Entry for each LOAN/CC Account
                    strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                    " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                    " MODEOFTRAN,ENTEREDTIMEBAL," & _
                    " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                    " EFFECTIVEDATE," & _
                    " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                    " SERVICEID,EXCEPTIONYN," & _
                    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                    " values('" & BranchCode & "'," & _
                    " '" & CurrencyCode & "','" & DebitModId & "'," & _
                    " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                    " '" & Batchno & "','" & DebitTranNo & "'," & _
                    " " & (-1 * arrInterests(idx)) & ",'3'," & DebitAccBal & "," & _
                    " " & DebitAccBal & "," & DebitAccBal & "," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                    " '1','N'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & UserId & "','" & MachineId & "','A'," & _
                    " sysdate,'SYSTEM','" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        " GenTransLog For The Branch " & BranchCode)
                    End If

                    strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                      "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                       " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                       " '" & BranchCode & "','" & CurrencyCode & "'," & _
                       " '" & DebitModId & "','" & DebitGlCode & "'," & _
                       " '" & DebitAccNo & "','" & Batchno & "'," & _
                       " '" & DebitTranNo & "'," & (-1 * arrInterests(idx)) & "," & _
                       " '3'," & DebitAccBal & "," & _
                       " " & DebitAccBal & "," & DebitAccBal & "," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & DebitAccName & "'," & _
                       " 'N','Y','" & strremarks & "','1','N'," & _
                       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "'," & _
                       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                       " 'SYSTEM','" & MachineId & "','IC')"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Tran Day Entry" & _
                        " For The Branch " & BranchCode)
                    End If

                End If

            Next idx

            If TotalInterest <> 0 Then
                'Then do Financial Transaction by 
                'Crediting Interest Credit Gl in Type Master table 
                'Note: Sum of interest of all a/c's is to be credited at one shot

                'Make Credit Entry first
                strcrremarks = ""
                strcrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                " '" & creditGlCode & "','" & creditAccNo & "'," & _
                " '" & Batchno & "','" & CreditTranNo & "'," & _
                " " & TotalInterest & ",'4'," & CreditAccBal & "," & _
                " " & CreditAccBal & "," & CreditAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & CreditAccName & "','N','Y','" & strcrremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(creditModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & creditModuleId & "','" & creditGlCode & "'," & _
                   " '" & creditAccNo & "','" & Batchno & "'," & _
                   " '" & CreditTranNo & "'," & TotalInterest & "," & _
                   " '4'," & CreditAccBal & "," & _
                   " " & CreditAccBal & "," & CreditAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & CreditAccName & "'," & _
                   " 'N','Y','" & strcrremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If
            End If
            ''----------------------------------------------------------------------------

            '''Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
            '''Reason: Oracle IN clause will not take too many values
            '''And also make Debit Entry w.r.t. to each a/c
            ''Cnt = 0 : BulkArrIdx = 0
            ''strAccountNos = ""
            ''For idx = 0 To UBound(arrAccnos)

            ''    Cnt += 1
            ''    strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
            ''    If Cnt = 480 Then
            ''        strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
            ''        BulkArr(BulkArrIdx) = strAccountNos
            ''        BulkArrIdx += 1
            ''        strAccountNos = ""
            ''        Cnt = 0
            ''    End If

            ''    DebitModId = ModuleId
            ''    DebitGlCode = Glcode
            ''    DebitTranNo = objDBConnection.GetTranNo(BranchCode)
            ''    DebitAccNo = arrAccnos(idx)
            ''    DebitAccName = arrAccNames(idx)

            ''    'Balance of Loan/CC A/C 
            ''    DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo, objTransaction)

            ''    'Make Debit Entry for each LOAN/CC Account
            ''    strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
            ''    " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
            ''    " MODEOFTRAN,ENTEREDTIMEBAL," & _
            ''    " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
            ''    " EFFECTIVEDATE," & _
            ''    " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
            ''    " SERVICEID,EXCEPTIONYN," & _
            ''    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
            ''    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
            ''    " values('" & BranchCode & "'," & _
            ''    " '" & CurrencyCode & "','" & DebitModId & "'," & _
            ''    " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
            ''    " '" & Batchno & "','" & DebitTranNo & "'," & _
            ''    " " & (-1 * arrInterests(idx)) & ",'3'," & DebitAccBal & "," & _
            ''    " " & DebitAccBal & "," & DebitAccBal & "," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''    " '" & DebitAccName & "','N','Y','Loan Interest Posting'," & _
            ''    " '1','N'," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''    " '" & UserId & "','" & MachineId & "','A'," & _
            ''    " sysdate,'SYSTEM','" & MachineId & "'," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

            ''    i_NoOfRows = ExecuteQuery(strQuery)
            ''    If i_NoOfRows <> 1 Then
            ''        Throw New Exception("Unable To Insert Debit Data Into" & _
            ''        " GenTransLog For The Branch " & BranchCode)
            ''    End If

            ''    strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
            ''      "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
            ''       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
            ''       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
            ''       " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
            ''       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
            ''       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
            ''       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
            ''       " '" & BranchCode & "','" & CurrencyCode & "'," & _
            ''       " '" & DebitModId & "','" & DebitGlCode & "'," & _
            ''       " '" & DebitAccNo & "','" & Batchno & "'," & _
            ''       " '" & DebitTranNo & "'," & (-1 * arrInterests(idx)) & "," & _
            ''       " '3'," & DebitAccBal & "," & _
            ''       " " & DebitAccBal & "," & DebitAccBal & "," & _
            ''       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " '" & DebitAccName & "'," & _
            ''       " 'N','Y','Loan Interest Posting','1','N'," & _
            ''       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " '" & UserId & "','" & MachineId & "'," & _
            ''       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " 'SYSTEM','" & MachineId & "','IC')"

            ''    i_NoOfRows = ExecuteQuery(strQuery)
            ''    If i_NoOfRows <> 1 Then
            ''        Throw New Exception("Unable To Insert Debit Tran Day Entry" & _
            ''        " For The Branch " & BranchCode)
            ''    End If
            ''Next idx

            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If


            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = "BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and GLCODE ='" & _
                Trim(Glcode) & "' and ACCNO in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
                " LASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " where BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and ACCNO in(" & BulkArr(i) & ") "

                i_NoOfRows = ExecuteQuery(strQuery)
                'If i_NoOfRows <> 1 Then
                '    Throw New Exception("Unable To update Last Int Calc Date of " & _
                '    "certain Accounts")
                'End If

                'Inserting  interest posted accs. details 
                strProdDtlsCond = "BranchCode='" & BranchCode & "'" & _
                " and CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                " and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' " & _
                " and MACHINEID='" & Trim(MachineId) & "'" & _
                " and APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and ACCNO in(" & BulkArr(i) & ")"


                strQuery = "insert into " & Trim(ModuleId) & "INTERESTDTLS " & _
                "(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE) " & _
                " Select BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE from " & Trim(ModuleId) & "INTCALTEMP" & _
                 " where " & strProdDtlsCond

                i_NoOfRows = ExecuteQuery(strQuery)
                'If i_NoOfRows <> 1 Then
                '    Throw New Exception("Unable To Insert Loan Products Details")
                'End If

            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostLoanOrCCCompoundInterest = True

            o_ErrMsg = "Transaction Successfull" & Chr(13)

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Batch No.: " & Batchno & Chr(13)
            End If

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Loans = " & CStr(TotalInterest) & Chr(13) & _
                       " credit P/L account = " & CStr(TotalInterest) & Chr(13)
            End If

            If POSTINTERESTYN = "N" Then
                o_ErrMsg = o_ErrMsg & " Total Unposted Interest = " & CStr(TotalUnpostedAmt) & Chr(13)
            End If

            If NPAimplimentedYN = "Y" Then
                o_ErrMsg = o_ErrMsg & " Total Npa Interest = " & CStr(TotalNpaAmt)
            End If



            ''o_ErrMsg = "Transaction Successfull" & _
            ''           " Batch No.: " & Batchno & Chr(13) & _
            ''           " Debit Loans = " & CStr(TotalInterest) & Chr(13) & _
            ''           " credit P/L account" & Chr(13) & _
            ''           " Total Unposted amount= " & CStr(TotalUnpostedAmt) & Chr(13) & _
            ''           " Total Npa Amount= " & CStr(TotalNpaAmt)

        Catch ex As Exception
            PostLoanOrCCCompoundInterest = False
            objTransaction.Rollback()
            ObjOracleConnection.Close()

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.LoanOPERATIONS" & _
                               " / PostLoanOrCCCompoundInterest"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing Loan or CC Compound Interest Posting - " & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing Loan or CC Compound Interest Posting - "
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function


    Public Function PostLoanOrCCCompoundInterestPenal(ByVal CurrencyCode As String, _
       ByVal ModuleId As String, _
       ByVal Glcode As String, ByVal IntCalcFromDt As Date, _
       ByVal IntCalcToDt As Date, ByVal RoundOfParam As Double, _
       ByVal UserId As String, _
       ByVal ApplicationDt As Date, ByVal MachineId As String, _
       ByVal arrVals(,) As Object, ByVal TotalInterest As Double, _
       ByRef o_ErrMsg As String, ByVal CompoundMode As String, _
       Optional ByVal BranchCode As String = "", _
       Optional ByVal FrmAccPre As String = "", _
       Optional ByVal FrmAccNo As String = "", _
       Optional ByVal FrmAccSuf As String = "", _
       Optional ByVal ToAccNo As String = "") As Boolean

        'Desc: This is used to Debit Interest to Loan/CC Accounts for the given
        '      Period
        'Inputs:
        'CURCode = Currency Code
        'MODId = Module Id; Generally it will be either 'LOAN' or 'CC' 
        'GLCode =Gl Code
        'IntCalcFromDt And IntCalcToDt are the range of Dates to calculate the 
        'Interest
        'UserId = Login User Id
        'Application Date = Login Date
        'MachineId = Login Machine Id
        'arrVals(0,0) = Includes Branchodes in which a/c's are existed is seperated
        '               by "," (comma symbol)
        'arrVals(1,0) = Account Numbers is seperated by "," (comma symbol)
        'arrVals(2,0)= Customer Ids
        'arrVals(3,0)= Account Holder's Names
        'arrVals(4,0)= Calculated Interests
        'O_ErrMsg = Holds the Error Message (OR) Batch No. which will return 
        'to the caller function
        'BranchCode = Branch Code in which a/c's are existed
        'Outputs:
        ' if the whole process is successfully executed
        '    function PostLoanOrCCDebitInterest will return True with 
        '    (O_ErrMsg)=Batch No.
        ' else
        '    returns the False and O_ErrMsg holds the errormessage 

        Dim strBrCodes, strCurCodes, StrModuleIds, strGlCodes, strAccountNos _
           As String
        Dim strInsertCond, strQuery, i_Batchno, i_TranNo, rtnAccBal As String
        Dim rtnGenDrQuery, rtnTranDrQuery, rtnGenCrQuery, rtnTranCrQuery, rtnExcQuery As Integer
        Dim arrBrCodes, arrCurCodes, arrModuleids, arrGlcodes, arrAccnos, _
            arrAccBal, arrInterests, arrbelowlimitint, arrabovelimitint, arrCustids, arrAccNames, arrCurBal As Object
        Dim prevBrCode, creditGlCode, creditAccNo, creditModuleId, _
         genCrQuery, tranCrQuery, genDrQuery, tranDrQuery, strProdDtlsCond, _
         strIntDtlsNotPosted As String

        Dim strremarks As String = ""
        Dim strcrremarks As String = ""
        Dim objgencls As New BulkOperations.GeneralCls

        Dim getDebitBal, getCreditBal, sumDrIntAmount, entryDebitAmount As Double
        sumDrIntAmount = 0
        Dim i, idx, i_NoOfRows As Integer
        idx = 0
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim objcommand As OracleClient.OracleCommand
        Dim drActiveLog As OracleClient.OracleDataReader
        Dim drCreditGLACC As OracleClient.OracleDataReader
        Dim drGetModId As OracleClient.OracleDataReader
        Dim drObj As OracleClient.OracleDataReader

        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strWherecond, rtnValue, sQuery As String
        Dim rowcount As Integer
        Dim BulkArr(200) As String, Cnt, BulkArrIdx As Integer
        Dim sTypeTable, sMstTable, sInterestType As String
        Dim DebitGlCode, DebitAccNo, DebitModId, NPAimplimentedYN, POSTINTERESTYN, NPAStatus, NAME, FldNames, FldValues, strlastIntDtValue, strCustCond As String
        Dim npaReader As OracleClient.OracleDataReader
        Dim LoanMstReader As OracleClient.OracleDataReader
        Dim TotalUnpostedAmt, TotalNpaAmt As Double
        Dim TotalBelowlimitInterest As Double
        Dim TotalAbovelimitInterest As Double
        Try
            TotalInterest = 0
            TotalUnpostedAmt = 0
            TotalNpaAmt = 0

            ''Need to take the sum of interests of only performing accounts 
            TotalInterest = 0
            TotalBelowlimitInterest = 0
            TotalAbovelimitInterest = 0

            sTypeTable = Trim(ModuleId) & "TypeMst"
            sMstTable = Trim(ModuleId) & "Mst"

            'Step 1: Get Database Connection
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Database Connection Failed. Reason Is " & o_ErrMsg)
            End If
            arrBrCodes = Split(arrVals(0, 0), ",")
            arrAccnos = Split(arrVals(1, 0), ",")
            arrCustids = Split(arrVals(2, 0), ",")
            arrAccNames = Split(arrVals(3, 0), ",")
            arrInterests = Split(arrVals(4, 0), ",")
            arrbelowlimitint = Split(arrVals(5, 0), ",")
            arrabovelimitint = Split(arrVals(6, 0), ",")

            sQuery = "select NPAIMPLEMENTEDYN from GENBANKPARM"
            objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
            npaReader = objcommand.ExecuteReader

            If npaReader.Read = False Then
                Throw New Exception("Unable to read bank params details")
            End If

            NPAimplimentedYN = npaReader(0)
            npaReader.Close()
            npaReader = Nothing

            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then

                '  Verify In GENSYSTEMACTIVELOG  whether interest is  Posted
                ' for the Given Gl Code A/c's in Given Range of Dates

                ' Preparing the condition for Verifying the data with given 
                ' condition
                ' if not found in GENSYSTEMACTIVELOG will post the Entry
                ' for the same condition

                strQuery = " CURRENCYCODE='" & CurrencyCode & _
                "' and MODULEID='" & ModuleId & "'" & _
                " and GLCODE='" & Glcode & "' and ACTIVITYID='IC' and" & _
                " TODATE>='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & _
                "' and BRANCHCODE='" & BranchCode & "'"

                strQuery = "select nvl(count(*),0) from GENSYSTEMACTIVITYLOG where " & strQuery
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                i_NoOfRows = objcommand.ExecuteScalar
                If i_NoOfRows <> 0 Then
                    Throw New Exception("Already " & ModuleId & " Interest Was Posted For This Period")
                End If
                objcommand = Nothing
            End If

            'Step 3: Get Type wise parameters of given Gl Code
            strQuery = "Select INTCREDITGLCODE IntCrGl ,INTCREDITACCNO IntCrAccno,POSTINTERESTYN" & _
            "  from " & sTypeTable & " where upper(MODULEID)='" & UCase(ModuleId) & _
            "' and upper(GLCODE)='" & Glcode & "'"

            objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
            drObj = objcommand.ExecuteReader

            If drObj.Read = False Then
                Throw New Exception("Unable to read details of given Gl Code")
            End If

            creditGlCode = drObj("IntCrGl")
            creditAccNo = drObj("IntCrAccno")
            POSTINTERESTYN = drObj("POSTINTERESTYN")

            'Get Module ID of Credit GL Code
            strQuery = "select moduleid from GENGLMASTMST where" & _
                       " GLCODE='" & creditGlCode & "'"
            creditModuleId = GetDescription(strQuery)
            If creditModuleId = "" Then
                Throw New Exception("Module Id for the GL " & creditGlCode & " Not Available")
            End If

            'Get balance of Credit Account
            Dim DebitAccBal, CreditAccBal As Double
            Dim Batchno, DebitTranNo, DebitTranNo1, CreditTranNo As Integer
            Dim DebitAccName, CreditAccName As String

            'Get Name of credit a/c
            strQuery = "select nvl(NAME,'') from " & Trim(creditModuleId) & "MST where" & _
                " BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                " GLCODE='" & Trim(creditGlCode) & "' and ACCNO='" & creditAccNo & "'"
            CreditAccName = GetDescription(strQuery)
            If CreditAccName = "" Then
                Throw New Exception("Unable to get details of the A/C" & creditAccNo & " GL " & creditGlCode)
            End If

            'Balance of credit A/C 
            CreditAccBal = GetAccBalance(BranchCode, CurrencyCode, creditModuleId, creditGlCode, creditAccNo)

            Batchno = objDBConnection.GetBatchno(BranchCode)
            CreditTranNo = objDBConnection.GetTranNo(BranchCode)

            'Begin Transaction
            objTransaction = ObjOracleConnection.BeginTransaction()

            'Insert into Activity Log, if interest is NOT posting for a range of accounts of given gl
            If FrmAccSuf = "" And FrmAccNo = "" And FrmAccSuf = "" Then
                strQuery = "insert into GENSYSTEMACTIVITYLOG(BRANCHCODE," & _
                  " CURRENCYCODE, MODULEID, GLCODE, ACTIVITYID," & _
                  " FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId," & _
                  " STATUS,APPROVEDBY," & _
                  " APPROVEDMACHINE,ROUNDOFFTO,BATCHNO) values" & _
                  " ('" & BranchCode & "','" & CurrencyCode & "'," & _
                  " '" & ModuleId & "','" & Glcode & "'," & _
                 " 'IC','" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                  " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                  " '" & UserId & "'," & _
                  " '" & MachineId & "','A','SYSTEM','" & MachineId & "'," & _
                  " " & RoundOfParam & "," & Batchno & ")"
                objcommand = New OracleClient.OracleCommand(strQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                i_NoOfRows = objcommand.ExecuteNonQuery()
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Data Into" & _
                    " GensystemActivityLog For The Branch " & BranchCode)
                End If
            End If

            'Save the Parameters like 
            'COL1=Interest Calculated From Date
            'COL2=Interest Calculated Upto Date
            'COL3=Glcode into which sum of loan interest was credited
            'COL4=Account No. into which sum of loan interest was credited
            'COL5=Value to round of the calculated interest
            'COL6=Prefix of the interest calculated accounts
            'COL7=A/C. No. from which interest was calculated
            'COL8=Suffix of the interest calculated accounts
            'COL9=A/C. No. upto which interest was calculated
            'COL10=Interest Type simple/compound
            'COL11=Compound Mode
            'COL12=Batch Number through which interest was posted
            strQuery = "insert into GENACTUALPARAMFORINTCALDTLS" & _
                    " (BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                    " USERID,MACHINEID,APPROVEDBY,APPROVEDMACHINE," & _
                    " APPLICATIONDATE,COL1,COL2,COL3,COL4,COL5,COL6,COL7,COL8,COL9,COL10,COL11,COL12)" & _
                    " values('" & BranchCode & "'," & _
                    " '" & CurrencyCode & "','" & ModuleId & "'," & _
                    " '" & Glcode & "'," & _
                    " '" & UserId & "','" & MachineId & "','SYSTEM'," & _
                    " '" & MachineId & "'," & _
                    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'," & _
                    " '" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'," & _
                    " '" & creditGlCode & "','" & creditAccNo & "'," & _
                    " '" & RoundOfParam & "','" & FrmAccPre & "'," & _
                    " '" & FrmAccNo & "','" & FrmAccSuf & "'," & _
                    " '" & ToAccNo & "','COMPOUND','" & CompoundMode & "'," & Batchno & ")"

            objcommand = New OracleClient.OracleCommand(strQuery, _
                                                        ObjOracleConnection)
            objcommand.Transaction = objTransaction
            i_NoOfRows = objcommand.ExecuteNonQuery
            If i_NoOfRows <> 1 Then
                Throw New Exception("Unable to Insert the data into" & _
                " Actual Parameters Table")
            End If

            Cnt = 0 : BulkArrIdx = 0
            strAccountNos = ""
            ''------------------------------------------------------------------
            ''Check if NPA is implimented or unposted concept is implimented
            For idx = 0 To UBound(arrAccnos)

                'Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
                'Reason: Oracle IN clause will not take too many values
                'And also make Debit Entry w.r.t. to each a/c
                Cnt += 1
                strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
                If Cnt = 480 Then
                    strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                    BulkArr(BulkArrIdx) = strAccountNos
                    BulkArrIdx += 1
                    strAccountNos = ""
                    Cnt = 0
                End If

                sQuery = "select NPAStatus,NAME,LASTINTCALCDATE from " & ModuleId & "MST WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE='" & CurrencyCode & "' AND GLCODE='" & _
                Glcode & "' AND ACCNO='" & arrAccnos(idx) & "'"

                objcommand = New OracleClient.OracleCommand(sQuery, ObjOracleConnection)
                objcommand.Transaction = objTransaction
                LoanMstReader = objcommand.ExecuteReader

                If LoanMstReader.Read = False Then
                    Throw New Exception("Unable to read details of given Account number" & arrAccnos(idx))
                End If

                NPAStatus = LoanMstReader("NPAStatus")
                NAME = IIf(IsDBNull(LoanMstReader("NAME")), "", LoanMstReader("NAME"))
                strlastIntDtValue = LoanMstReader("LASTINTCALCDATE")
                LoanMstReader.Close()
                LoanMstReader = Nothing

                If (POSTINTERESTYN = "N" And NPAimplimentedYN = "N") Or _
                (POSTINTERESTYN = "N" And (NPAimplimentedYN = "Y" And NPAStatus = "P")) Then

                    TotalUnpostedAmt = TotalUnpostedAmt + arrInterests(idx)
                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','Interest'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "UNPOSTINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        ModuleId & " UNPOSTINTEREST For The accno " & arrAccnos(idx))
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                    " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                    " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set UNPOSTINTBAL= nvl(UNPOSTINTBAL,0) + " & CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To update UNPOSTINTBAL balance For The accno " & arrAccnos(idx))
                    End If

                ElseIf (NPAimplimentedYN = "Y" And NPAStatus = "N") Then

                    TotalNpaAmt = TotalNpaAmt + arrInterests(idx)
                    FldNames = "BRANCHCODE," & _
                      " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                      " MODEOFTRAN,ENTEREDTIMEBAL," & _
                      " EFFECTIVEDATE," & _
                      " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                      " SERVICEID,EXCEPTIONYN," & _
                      " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                      " SYSTEMDATE,CHQFVG,CHQDATE,FROMDATE, TODATE"

                    strremarks = ""
                    strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, ModuleId, Glcode, arrAccnos(idx))
                    strremarks = "Penal " & strremarks
                    FldValues = "'" & BranchCode & "'," & _
                      " '" & CurrencyCode & "','" & ModuleId & "'," & _
                      " '" & Glcode & "','" & arrAccnos(idx) & "'," & _
                      " " & 999 & "," & 999 & "," & _
                      " " & (-1 * arrInterests(idx)) & ",'3'," & 0 & "," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & NAME & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','P'," & _
                      " sysdate,'IC','" & Format(CDate(strlastIntDtValue), "dd-MMM-yyyy") & "','" & _
                      Format(IntCalcFromDt, "dd-MMM-yyyy") & "','" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'"

                    strQuery = "insert into " & ModuleId & "NPAINTEREST(" & FldNames & ") values(" & FldValues & ")"

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        " GenTransLog For The Branch " & BranchCode)
                    End If

                    strCustCond = "BRANCHCODE='" & Trim(BranchCode) & "' and " & _
                     " CURRENCYCODE='" & Trim(CurrencyCode) & "' and " & _
                     " GLCODE='" & Trim(Glcode) & "' and ACCNO='" & arrAccnos(idx) & "'"

                    strQuery = "update " & ModuleId & "BALANCE set NPAINTBAL=nvl(NPAINTBAL,0) + " & CStr((-1 * arrInterests(idx))) & " where " & strCustCond

                    i_NoOfRows = ExecuteQuery(strQuery)
                    If i_NoOfRows <> 1 Then
                        Throw New Exception("Unable To Insert Debit Data Into" & _
                        " GenTransLog For The Branch " & BranchCode)
                    End If

                Else
                    ''else debit form account
                    DebitModId = ModuleId
                    DebitGlCode = Glcode
                    DebitAccNo = arrAccnos(idx)
                    'If DebitAccNo = "2925" Then
                    '    MsgBox("hi")
                    'End If
                    DebitAccName = arrAccNames(idx)

                    TotalInterest = TotalInterest + arrInterests(idx)


                    'Balance of Loan/CC A/C 
                    DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo, objTransaction)
                   
                    'Make Start Below Limit Bal Debit Entry for each LOAN/CC Account
                    If arrbelowlimitint(idx) <> 0 Then
                        strremarks = ""
                        strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo)

                        DebitTranNo = objDBConnection.GetTranNo(BranchCode)

                        TotalBelowlimitInterest = TotalBelowlimitInterest + arrbelowlimitint(idx)

                        strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL," & _
                        " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                        " EFFECTIVEDATE," & _
                        " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                        " values('" & BranchCode & "'," & _
                        " '" & CurrencyCode & "','" & DebitModId & "'," & _
                        " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                        " '" & Batchno & "','" & DebitTranNo & "'," & _
                        " " & (-1 * arrbelowlimitint(idx)) & ",'3'," & DebitAccBal & "," & _
                        " " & DebitAccBal & "," & DebitAccBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                        " '1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Debit Below Limit Interest Into" & _
                            " GenTransLog For The Branch " & BranchCode)
                        End If

                        strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                          "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                           " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                           " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                           " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                           " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                           " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                           " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                           " '" & BranchCode & "','" & CurrencyCode & "'," & _
                           " '" & DebitModId & "','" & DebitGlCode & "'," & _
                           " '" & DebitAccNo & "','" & Batchno & "'," & _
                           " '" & DebitTranNo & "'," & (-1 * arrbelowlimitint(idx)) & "," & _
                           " '3'," & DebitAccBal & "," & _
                           " " & DebitAccBal & "," & DebitAccBal & "," & _
                           " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " '" & DebitAccName & "'," & _
                           " 'N','Y','" & strremarks & "','1','N'," & _
                           " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " 'SYSTEM','" & MachineId & "','IC')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Debit Below Limit Interest Tran Day Entry" & _
                            " For The Branch " & BranchCode)
                        End If
                    End If '' end below limit interest

                    'Make start Above Limit Bal Debit Entry for each LOAN/CC Account
                    If arrabovelimitint(idx) <> 0 Then

                        'If ObjOracleConnection.State <> ConnectionState.Open Then
                        '    ObjOracleConnection = New OracleClient.OracleConnection
                        '    o_ErrMsg = ""
                        '    ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
                        '    If o_ErrMsg <> "" Then
                        '        Throw New Exception(o_ErrMsg)
                        '    End If
                        'End If
                        strremarks = ""
                        strremarks = objgencls.GetRemarks(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo)
                        strremarks = "Penal " & strremarks

                        DebitTranNo1 = objDBConnection.GetTranNo(BranchCode)
                        TotalAbovelimitInterest = TotalAbovelimitInterest + arrabovelimitint(idx)

                        strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                        " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                        " MODEOFTRAN,ENTEREDTIMEBAL," & _
                        " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                        " EFFECTIVEDATE," & _
                        " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                        " SERVICEID,EXCEPTIONYN," & _
                        " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                        " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                        " values('" & BranchCode & "'," & _
                        " '" & CurrencyCode & "','" & DebitModId & "'," & _
                        " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
                        " '" & Batchno & "','" & DebitTranNo1 & "'," & _
                        " " & (-1 * arrabovelimitint(idx)) & ",'3'," & DebitAccBal & "," & _
                        " " & DebitAccBal & "," & DebitAccBal & "," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & DebitAccName & "','N','Y','" & strremarks & "'," & _
                        " '1','N'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                        " '" & UserId & "','" & MachineId & "','A'," & _
                        " sysdate,'SYSTEM','" & MachineId & "'," & _
                        " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Debit Data Into" & _
                            " GenTransLog For The Branch " & BranchCode)
                        End If

                        strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
                          "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                           " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                           " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                           " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                           " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                           " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                           " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                           " '" & BranchCode & "','" & CurrencyCode & "'," & _
                           " '" & DebitModId & "','" & DebitGlCode & "'," & _
                           " '" & DebitAccNo & "','" & Batchno & "'," & _
                           " '" & DebitTranNo1 & "'," & (-1 * arrabovelimitint(idx)) & "," & _
                           " '3'," & DebitAccBal & "," & _
                           " " & DebitAccBal & "," & DebitAccBal & "," & _
                           " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " '" & DebitAccName & "'," & _
                           " 'N','Y','" & strremarks & "','1','N'," & _
                           " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " '" & UserId & "','" & MachineId & "'," & _
                           " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                           " 'SYSTEM','" & MachineId & "','IC')"

                        i_NoOfRows = ExecuteQuery(strQuery)
                        If i_NoOfRows <> 1 Then
                            Throw New Exception("Unable To Insert Debit Tran Day Entry" & _
                            " For The Branch " & BranchCode)
                        End If
                    End If '' end of above limit interest
                End If

            Next idx

            If TotalInterest <> 0 Then
                'Then do Financial Transaction by 
                'Crediting Interest Credit Gl in Type Master table 
                'Note: Sum of interest of all a/c's is to be credited at one shot

                'Make Credit Entry first
                strcrremarks = ""
                strcrremarks = "INT From " & Format(IntCalcFromDt, "dd-MMM-yyyy") & " To " & Format(IntCalcToDt, "dd-MMM-yyyy")
                strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
                " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
                " MODEOFTRAN,ENTEREDTIMEBAL," & _
                " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                " EFFECTIVEDATE," & _
                " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
                " SERVICEID,EXCEPTIONYN," & _
                " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
                " values('" & BranchCode & "'," & _
                " '" & CurrencyCode & "','" & creditModuleId & "'," & _
                " '" & creditGlCode & "','" & creditAccNo & "'," & _
                " '" & Batchno & "','" & CreditTranNo & "'," & _
                " " & TotalInterest & ",'4'," & CreditAccBal & "," & _
                " " & CreditAccBal & "," & CreditAccBal & "," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & CreditAccName & "','N','Y','" & strcrremarks & "'," & _
                " '1','N'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                " '" & UserId & "','" & MachineId & "','A'," & _
                " sysdate,'SYSTEM','" & MachineId & "'," & _
                " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Data Into" & _
                    " GenTransLog For The Branch " & BranchCode)
                End If

                strQuery = "insert into " & Trim(creditModuleId) & "TRANDAY(" & _
                  "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
                   " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
                   " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
                   " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
                   " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
                   " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                   " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
                   " '" & BranchCode & "','" & CurrencyCode & "'," & _
                   " '" & creditModuleId & "','" & creditGlCode & "'," & _
                   " '" & creditAccNo & "','" & Batchno & "'," & _
                   " '" & CreditTranNo & "'," & TotalInterest & "," & _
                   " '4'," & CreditAccBal & "," & _
                   " " & CreditAccBal & "," & CreditAccBal & "," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & CreditAccName & "'," & _
                   " 'N','Y','" & strcrremarks & "','1','N'," & _
                   " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " '" & UserId & "','" & MachineId & "'," & _
                   " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
                   " 'SYSTEM','" & MachineId & "','IC')"

                i_NoOfRows = ExecuteQuery(strQuery)
                If i_NoOfRows <> 1 Then
                    Throw New Exception("Unable To Insert Credit Tran Day Entry" & _
                    " For The Branch " & BranchCode)
                End If
            End If
            ''----------------------------------------------------------------------------

            '''Step 2: Split given A/C's as a batches. Each batch can hold max 480 A/C's
            '''Reason: Oracle IN clause will not take too many values
            '''And also make Debit Entry w.r.t. to each a/c
            ''Cnt = 0 : BulkArrIdx = 0
            ''strAccountNos = ""
            ''For idx = 0 To UBound(arrAccnos)

            ''    Cnt += 1
            ''    strAccountNos = strAccountNos & "'" & Trim(arrAccnos(idx)) & "',"
            ''    If Cnt = 480 Then
            ''        strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
            ''        BulkArr(BulkArrIdx) = strAccountNos
            ''        BulkArrIdx += 1
            ''        strAccountNos = ""
            ''        Cnt = 0
            ''    End If

            ''    DebitModId = ModuleId
            ''    DebitGlCode = Glcode
            ''    DebitTranNo = objDBConnection.GetTranNo(BranchCode)
            ''    DebitAccNo = arrAccnos(idx)
            ''    DebitAccName = arrAccNames(idx)

            ''    'Balance of Loan/CC A/C 
            ''    DebitAccBal = GetAccBalance(BranchCode, CurrencyCode, DebitModId, DebitGlCode, DebitAccNo, objTransaction)

            ''    'Make Debit Entry for each LOAN/CC Account
            ''    strQuery = "insert into GENTRANSLOG(BRANCHCODE," & _
            ''    " CURRENCYCODE,MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT," & _
            ''    " MODEOFTRAN,ENTEREDTIMEBAL," & _
            ''    " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
            ''    " EFFECTIVEDATE," & _
            ''    " NAME,CASHPAIDYN,SYSTEMGENERATEDYN,REMARKS," & _
            ''    " SERVICEID,EXCEPTIONYN," & _
            ''    " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
            ''    " SYSTEMDATE,APPROVEDBY,APPROVEDMACHINE,APPROVEDDATE,CHQFVG)" & _
            ''    " values('" & BranchCode & "'," & _
            ''    " '" & CurrencyCode & "','" & DebitModId & "'," & _
            ''    " '" & DebitGlCode & "','" & DebitAccNo & "'," & _
            ''    " '" & Batchno & "','" & DebitTranNo & "'," & _
            ''    " " & (-1 * arrInterests(idx)) & ",'3'," & DebitAccBal & "," & _
            ''    " " & DebitAccBal & "," & DebitAccBal & "," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''    " '" & DebitAccName & "','N','Y','Loan Interest Posting'," & _
            ''    " '1','N'," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''    " '" & UserId & "','" & MachineId & "','A'," & _
            ''    " sysdate,'SYSTEM','" & MachineId & "'," & _
            ''    " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "','IC')"

            ''    i_NoOfRows = ExecuteQuery(strQuery)
            ''    If i_NoOfRows <> 1 Then
            ''        Throw New Exception("Unable To Insert Debit Data Into" & _
            ''        " GenTransLog For The Branch " & BranchCode)
            ''    End If

            ''    strQuery = "insert into " & Trim(DebitModId) & "TRANDAY(" & _
            ''      "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE,ACCNO," & _
            ''       " BATCHNO,TRANNO,AMOUNT,MODEOFTRAN,ENTEREDTIMEBAL," & _
            ''       " VERIFIEDTIMEBAL,APPROVEDTIMEBAL," & _
            ''       " EFFECTIVEDATE,NAME,CASHPAIDYN," & _
            ''       " SYSTEMGENERATEDYN,REMARKS,SERVICEID,EXCEPTIONYN," & _
            ''       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
            ''       " APPROVEDDATE,APPROVEDBY,APPROVEDMACHINE,CHQFVG) values(" & _
            ''       " '" & BranchCode & "','" & CurrencyCode & "'," & _
            ''       " '" & DebitModId & "','" & DebitGlCode & "'," & _
            ''       " '" & DebitAccNo & "','" & Batchno & "'," & _
            ''       " '" & DebitTranNo & "'," & (-1 * arrInterests(idx)) & "," & _
            ''       " '3'," & DebitAccBal & "," & _
            ''       " " & DebitAccBal & "," & DebitAccBal & "," & _
            ''       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " '" & DebitAccName & "'," & _
            ''       " 'N','Y','Loan Interest Posting','1','N'," & _
            ''       " '" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " '" & UserId & "','" & MachineId & "'," & _
            ''       " 'A','" & Format(ApplicationDt, "dd-MMM-yyyy") & "'," & _
            ''       " 'SYSTEM','" & MachineId & "','IC')"

            ''    i_NoOfRows = ExecuteQuery(strQuery)
            ''    If i_NoOfRows <> 1 Then
            ''        Throw New Exception("Unable To Insert Debit Tran Day Entry" & _
            ''        " For The Branch " & BranchCode)
            ''    End If
            ''Next idx

            If Trim(strAccountNos) <> "" Then
                strAccountNos = Mid(strAccountNos, 1, Len(Trim(strAccountNos)) - 1)
                BulkArr(BulkArrIdx) = strAccountNos
                BulkArrIdx += 1
            End If


            'BULK OPERATIONS STARTS FROM HERE
            For i = 0 To (BulkArrIdx - 1)

                ''' Before update the Master Table , Move the data to respective 
                '   History Table
                strWherecond = "BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and GLCODE ='" & _
                Trim(Glcode) & "' and ACCNO in(" & BulkArr(i) & ")"

                objHist.recordInHist(Trim(ModuleId) & "MST", "LASTINTCALCDATE", _
                ObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)
                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If
                'If rowcount <> (UBound(arrAccnos) + 1) Then
                '    Throw New Exception("Unable Move the data to History table")
                'End If

                strQuery = "update " & Trim(ModuleId) & "MST set" & _
                " LASTINTCALCDATE='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " where BRANCHCODE='" & BranchCode & "' and " & _
                " CURRENCYCODE='" & CurrencyCode & "' and" & _
                " GLCODE ='" & Glcode & "' and ACCNO in(" & BulkArr(i) & ") "

                i_NoOfRows = ExecuteQuery(strQuery)
                'If i_NoOfRows <> 1 Then
                '    Throw New Exception("Unable To update Last Int Calc Date of " & _
                '    "certain Accounts")
                'End If

                'Inserting  interest posted accs. details 
                strProdDtlsCond = "BranchCode='" & BranchCode & "'" & _
                " and CURRENCYCODE='" & CurrencyCode & "'" & _
                " and GLCODE ='" & Trim(Glcode) & "'" & _
                " and INTCALFROMDT='" & Format(IntCalcFromDt, "dd-MMM-yyyy") & "'" & _
                " and INTCALTODT='" & Format(IntCalcToDt, "dd-MMM-yyyy") & "'" & _
                " and USERID='" & Trim(UserId) & "' " & _
                " and MACHINEID='" & Trim(MachineId) & "'" & _
                " and APPLICATIONDATE='" & Format(ApplicationDt, "dd-MMM-yyyy") & "'" & _
                " and ACCNO in(" & BulkArr(i) & ")"


                strQuery = "insert into " & Trim(ModuleId) & "INTERESTDTLS " & _
                "(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE) " & _
                " Select BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, CATEGORYCODE, CUSTOMERID," & _
                " OPDATE, RECORDTYPE, PRODFROMDT, PRODTODT, BALANCE, COMPOUNDBAL," & _
                " TOTALBALANCE, LIMITAMT, BELOWLMTBAL, ABOVELMTBAL, NOD, ROI," & _
                " ABOVEROI, BELOWLMTINT, ABOVELMTINT, INTEREST, INTCALFROMDT," & _
                " INTCALTODT, COMPOUNDDATEYN, USERID, MACHINEID, APPLICATIONDATE," & _
                " ERRORMSG, SYSTEMDATE from " & Trim(ModuleId) & "INTCALTEMP" & _
                 " where " & strProdDtlsCond

                i_NoOfRows = ExecuteQuery(strQuery)
                'If i_NoOfRows <> 1 Then
                '    Throw New Exception("Unable To Insert Loan Products Details")
                'End If

            Next i

            objTransaction.Commit()
            ObjOracleConnection.Close()
            PostLoanOrCCCompoundInterestPenal = True

            o_ErrMsg = "Transaction Successfull" & Chr(13)

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Batch No.: " & Batchno & Chr(13)
            End If

            If TotalInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Loans = " & CStr(TotalInterest) & Chr(13) & _
                       " credit P/L account = " & CStr(TotalInterest) & Chr(13)
            End If

            If TotalBelowlimitInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Interest For Loans = " & CStr(TotalBelowlimitInterest) & Chr(13)
            End If

            If TotalAbovelimitInterest <> 0 Then
                o_ErrMsg = o_ErrMsg & " Debit Penal Interest For Loans = " & CStr(TotalAbovelimitInterest) & Chr(13)
            End If

            If POSTINTERESTYN = "N" Then
                o_ErrMsg = o_ErrMsg & " Total Unposted Interest = " & CStr(TotalUnpostedAmt) & Chr(13)
            End If

            If NPAimplimentedYN = "Y" Then
                o_ErrMsg = o_ErrMsg & " Total Npa Interest = " & CStr(TotalNpaAmt)
            End If



            ''o_ErrMsg = "Transaction Successfull" & _
            ''           " Batch No.: " & Batchno & Chr(13) & _
            ''           " Debit Loans = " & CStr(TotalInterest) & Chr(13) & _
            ''           " credit P/L account" & Chr(13) & _
            ''           " Total Unposted amount= " & CStr(TotalUnpostedAmt) & Chr(13) & _
            ''           " Total Npa Amount= " & CStr(TotalNpaAmt)

        Catch ex As Exception
            PostLoanOrCCCompoundInterestPenal = False
            objTransaction.Rollback()
            ObjOracleConnection.Close()

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.LoanOPERATIONS" & _
                               " / PostLoanOrCCCompoundInterestPenal"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing Loan or CC Compound Interest Posting - " & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing Loan or CC Compound Interest Posting - "
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function
End Class

