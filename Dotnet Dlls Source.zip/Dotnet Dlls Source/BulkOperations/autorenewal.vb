
Public Class autorenewal
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String
    Dim drcustamt As OracleClient.OracleDataReader
    Dim drtdsmaxdt As OracleClient.OracleDataReader
    Dim strQuery As String
    Dim strmsttable As String
    Dim strcustid As String
    Dim dblamt As Double

    Dim strcrmod As String
    Dim strcrglcd As String
    Dim strcraccno As String
    Dim drtdsrates As OracleClient.OracleDataReader
    Dim objDBConnection1 As New DatabaseConnection.cDBConnection
    Dim gObjOracleConnection1 As New OracleClient.OracleConnection

    Public sDrIntModId, sDrIntGlCode, sDrIntAccNo As String
    Public sCrIntModId, sCrIntGlCode, sCrIntAccNo As String
    Public sIntAccrModId, sIntAccrGlCode, sIntAccrAccNo As String
    Dim dbltdsamt As Double


    Public Function AutoRenewalInsert(ByVal BRCode As String, _
                  ByVal CURCode As String, _
                  ByVal arrVals(,) As Object, _
                  ByVal ApplicationDate As Date, ByVal UserId As String, _
                  ByVal MachineId As String, ByVal strmode As String) As String

        'Desc: This is used to Calculate TDS
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code

        'ArrVals(Idx,0) = Includes customer ids for tds calculation and every customerid number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,1) = Includes glcodes for tds calculation and every glcodes
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,2) = Includes Account Numbers for tds calculation and every a/c number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,3) = Includes Names of the Account holders respectively and these
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,4) = Includes category code of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,5) = Includes opamt to be applied of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,6) = Includes mat amt of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,7) = Includes mat date of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,8) = Includes new roi of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,9) = Includes new mat amt of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,10) = Includes new mat date of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,11) = Includes int calc of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,12) = Includes paid int of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,13) = Includes pend int to be paid of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ArrVals(Idx,14) = Includes int accr of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)

        'ArrVals(Idx,15) = Includes tds amt of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)

        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TDSExecClosing = "Transaction Successfull"
        '   else
        '     TDSExecClosing = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection


        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand

        Dim sQuery, strAccNos, dtResult As String
        Dim iNoOfRows As Long
        Dim expectedRowCnt, delRowCnt As Integer
        Dim accountArr As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String



        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames, strAcctds, strintaccr, strcatcode As String
        Dim strCustid, strGlcds As String
        Dim stropamt, strmatamt, strmatdate, strnewroi, strnewmatamt, strnewmatdate, strintcalc, strpaidint, strpeninttobepaid, strintaccramt, strtdsamt As String
        Dim CustidArr, GlcdsArr, NamesArr, tdsArr, intaccrArr, catcodeArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            '''' STEP 1: Get DataBase Connection
            gObjOracleConnection1 = objDBConnection1.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                              " DataBase. Reason Is " & o_Errmsg)
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strCustid = arrVals(0, 0)
            strGlcds = arrVals(1, 0)
            strAccNos = arrVals(2, 0)
            strAccNames = arrVals(3, 0)
            strcatcode = arrVals(4, 0)
            stropamt = arrVals(5, 0)
            strmatamt = arrVals(6, 0)
            strmatdate = arrVals(7, 0)
            strnewroi = arrVals(8, 0)
            strnewmatamt = arrVals(9, 0)
            strnewmatdate = arrVals(10, 0)
            strintcalc = arrVals(11, 0)
            strpaidint = arrVals(12, 0)
            strpeninttobepaid = arrVals(13, 0)
            strintaccramt = arrVals(14, 0)
            strtdsamt = arrVals(15, 0)



            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.
            CustidArr = Split(strCustid, ",")
            GlcdsArr = Split(strGlcds, ",")
            accountArr = Split(strAccNos, ",")
            NamesArr = Split(strAccNames, ",")
            catcodeArr = Split(strcatcode, ",")
            

            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt

                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strcatcode = catcodeArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                            strintaccr = intaccrArr(iAdx)
                        Else
                            strCustid = strCustid & "," & accountArr(iAdx)
                            strGlcds = strGlcds & "," & accountArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strcatcode = strcatcode & "," & catcodeArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                            strintaccr = strintaccr & "," & intaccrArr(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strcatcode = catcodeArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                            strintaccr = intaccrArr(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strcatcode = strcatcode & "," & catcodeArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                            strintaccr = strintaccr & "," & intaccrArr(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String
                arrVals(0, 0) = strCustid
                arrVals(1, 0) = strGlcds
                arrVals(2, 0) = strAccNos
                arrVals(3, 0) = strAccNames
                arrVals(4, 0) = strcatcode
                arrVals(5, 0) = strAcctds
                arrVals(6, 0) = strintaccr

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 1 : Do TDS calculations to debit Operative GL A/c's and 
                '             Credit Gl A/C's

                opResult = doTDSExecutionsClosing(BRCode, CURCode, frmfinyr, tofinyr, _
                           arrVals, ApplicationDate, UserId, _
                           MachineId, gObjOracleConnection, objTransaction, _
                           returnBatchNo, rtnFromTranno, rtnToTranno, strmode, assessyear)

                If opResult = False Then

                    Throw New Exception("Error While doing TDS Calculation" & _
                        " to Debit  GL A/C's and Credit GL A/C's")
                End If

                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False
            gObjOracleConnection1.Close()
            gObjOracleConnection1 = Nothing

            tdsexecclosing = "Transaction Successful" & " Batch No.(s)  " & returnBatchNo

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                tdsexecclosing = ex.Message
                Exit Function
            Else

                strComponent = "BULKOPERATIONS.TDSCALCULATIONS / TDSExecClosing"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    tdsexecclosing = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    tdsexecclosing = clntDesc
                End If
                Exit Function
            End If

        End Try
    End Function




End Class
