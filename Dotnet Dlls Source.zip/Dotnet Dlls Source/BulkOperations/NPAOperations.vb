'***************************************************************************
'***************************************************************************
'*	Name Of the File : Preparing dll for NPAOperations                     *
'*	Purpose	  	     : This Class is used To Classify PA or NPA Accounts   *
'*			                                            		           *
'|-------------------------------------------------------------------------|
'|     @Author 	        |    Created On    |  Version   |      Remarks	   |
'|----------------------|------------------|------------|------------------|
'| V.Anil Kumar         |    01-jun-2007   |   3.1      |                  |'|                      |                  |            |                  |
'|				        |                  |	        |                  |
'|-------------------------------------------------------------------------|
'***************************************************************************'***************************************************************************


Public Class NPAOperations
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Public Function LoanNpaTransaction(ByVal BranchCode As String, _
    ByVal CurrencyCode As String, ByVal ModuleId As String, ByVal GlCode As String, ByVal CutOffDt As String, ByRef o_ErrMsg As String) As String(,)

        'IntCutOffDate = CutOffDt

        Dim bConnOpened, bTransBegin As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strObjHist, returnMsgm, sQuery As String
        Dim iNoOfRows, ErrMsg As String
        Dim SchCutOffDt, IntCutOffDate, dtNPAeffdate As Date
        Dim npaDs As New DataSet
        Dim npaReader As OracleClient.OracleDataReader
        Dim npaDA As New OracleClient.OracleDataAdapter
        Dim strArr(,) As String
        Dim i As Integer
        Dim schAmt, CurBal As Double
        Dim scheduleAvailableYN As String
        Dim strNPAEffDt As String
        Dim lnschdreader As OracleClient.OracleDataReader
        Dim sancdate As Date  '' sanctioned date
        Dim repaydate As Date '' reapyment date
        Dim sancamt As Double '' sanctioned amount
        Try

            gObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)

            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                          " DataBase. Reason Is " & o_ErrMsg)
            End If

            sQuery = "select nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)" & _
            ",nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(" & _
            "PRINRECOVERYDAYS, 0),nvl(INTRECOVERYDAYS, 0) from " & _
            "NPAASSETTYPEPMT where upper(trim(glcode))='" & GlCode & "'"

            objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)

            npaReader = objcommand.ExecuteReader
            objcommand.Dispose()

            Dim newDt As Double

            If npaReader.Read Then

                '''calculating the npa priniciple calc date for the given cuttoffdate
                newDt = -(CDbl(npaReader(0)) + CDbl(npaReader(1)))

                SchCutOffDt = Convert.ToDateTime(CutOffDt).AddMonths(newDt)


                SchCutOffDt = Convert.ToDateTime(SchCutOffDt).AddDays _
                                                (-CDbl(npaReader(4)))

                SchCutOffDt = Format(SchCutOffDt, "dd-MMM-yyyy")

            Else
                Throw New Exception("Parameters Not Available" & _
                " For the GLCode " & GlCode)
            End If

            npaReader.Close()
            npaReader = Nothing

            sQuery = "select accno,name,decode(nvl(NPASTATUS,'P'), 'P', 'PA'," & _
            "'N', 'NPA','P') NPASTATUS, nvl(SANCTIONEDAMT, 0)," & _
            "SANCTIONEDDATE from loanmst WHERE upper(trim(branchcode))" & _
            "='" & BranchCode & "' and upper(trim(currencycode))='" & _
            CurrencyCode & "' and upper(trim(glcode))='" & GlCode & _
            "' and opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') " & _
            "and (CLOSEDATE>to_date('" & SchCutOffDt & "','dd-mm-yyyy')" & _
            " or closedate is null ) ORDER BY TO_NUMBER(accno) "
            objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)

            npaDA = New OracleClient.OracleDataAdapter(objcommand)
            npaDA.Fill(npaDs)
            objcommand.Dispose()

            If npaDs Is Nothing Or npaDs.Tables(0).Rows.Count = 0 Then
                'Throw New Exception("No Records")
                Exit Function
            End If

            ReDim strArr(npaDs.Tables(0).Rows.Count - 1, 7)
            Dim pa As Integer
            Dim Idx As Long

            Idx = 0

            For i = 0 To npaDs.Tables(0).Rows.Count - 1

                'If npaDs.Tables(0).Rows(i)(0) = "14324" Then
                '    MsgBox("hi")
                'End If

                pa = 0

                'Get Current Balance of current a/c in the loop
                sQuery = "select getanydaybal('" & BranchCode & "','" & _
                CurrencyCode & "','" & ModuleId & "','" & GlCode & "','" & _
                npaDs.Tables(0).Rows(i)(0) & "','" & CutOffDt & "') from dual"

                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                ErrMsg = objcommand.ExecuteScalar
                objcommand.Dispose()

                If ErrMsg.Length >= 5 Then
                    If UCase(ErrMsg.Substring(0, 5)) = "ERROR" Then
                        Throw New Exception(ErrMsg & "For Accno" & _
                        npaDs.Tables(0).Rows(i)(0))
                    Else
                        CurBal = CDbl(ErrMsg)
                    End If
                Else
                    CurBal = CDbl(ErrMsg)
                End If

                If CurBal = 0 Then
                    GoTo EndOfForLoop
                End If


                scheduleAvailableYN = "Y"
                '' if sch cutofdate < sacntion date then
                If CDate(SchCutOffDt) < CDate(npaDs.Tables(0).Rows(i)(4)) Then
                    schAmt = npaDs.Tables(0).Rows(i)(3)  '' sanction amount
                Else

                    'Get Schedule Balance of current a/c in the loop
                    sQuery = "select nvl(BALANCEAMT,0),REPAYDUEDATE from LOANSCHEDULEDTLS" & _
                        " where branchcode='" & BranchCode & "' and currencycode='" & _
                        CurrencyCode & "' and glcode='" & GlCode & "' and accno='" & _
                        npaDs.Tables(0).Rows(i)(0) & "' and " & _
                        " REPAYDUEDATE=(select max(REPAYDUEDATE) from loanscheduledtls" & _
                        " where branchcode='" & BranchCode & "' and currencycode='" & _
                        CurrencyCode & "' and glcode='" & GlCode & "' and accno='" & _
                        npaDs.Tables(0).Rows(i)(0) & "' and REPAYDUEDATE<=to_date('" & _
                        SchCutOffDt & "','dd-mm-yyyy'))"

                    objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                    '    ErrMsg = objcommand.ExecuteScalar
                    lnschdreader = objcommand.ExecuteReader
                    objcommand.Dispose()
                    If lnschdreader.Read Then
                        If lnschdreader.HasRows = False Then
                            scheduleAvailableYN = "N"
                            schAmt = 0
                            If CDate(npaDs.Tables(0).Rows(i)(4)) > SchCutOffDt Then
                                pa = 1
                            End If
                        Else
                            If CStr(lnschdreader(0)).Length >= 5 Then
                                If UCase(CStr(lnschdreader(0)).Substring(0, 5)) = "ERROR" Then
                                    Throw New Exception(lnschdreader(0) & " For Accno" & _
                                    npaDs.Tables(0).Rows(i)(0))
                                Else
                                    schAmt = CDbl(lnschdreader(0))
                                End If
                            Else
                                schAmt = CDbl(lnschdreader(0))
                            End If
                            repaydate = CDate(lnschdreader(1))
                        End If
                    End If
                    lnschdreader.Close()
                    lnschdreader = Nothing
                End If
                'If npaDs.Tables(0).Rows(i)(0) = "14324" Then
                '    MsgBox("hi")
                'End If


                sancdate = CDate(npaDs.Tables(0).Rows(i)(4))
                sancamt = CDbl(npaDs.Tables(0).Rows(i)(3))
                'If CurBal >= 0 Or Math.Abs(CurBal) <= Math.Abs(schAmt) Or pa = 1 Then
                If CurBal > 0 Or Math.Abs(CurBal) <= Math.Abs(schAmt) Or pa = 1 Then
                    If ((sancdate = repaydate) And (sancamt = schAmt)) Then
                        strArr(Idx, 0) = npaDs.Tables(0).Rows(i)(0)
                        strArr(Idx, 1) = npaDs.Tables(0).Rows(i)(1)
                        strArr(Idx, 2) = npaDs.Tables(0).Rows(i)(2)
                        strArr(Idx, 3) = npaDs.Tables(0).Rows(i)(3)
                        strArr(Idx, 4) = schAmt
                        strArr(Idx, 5) = CurBal


                        strNPAEffDt = getNpaEffectedDate(BranchCode, CurrencyCode, GlCode, strArr(Idx, 0), npaDs.Tables(0).Rows(i)(4), gObjOracleConnection, SchCutOffDt, CDate(CutOffDt))
                        If (strNPAEffDt = "") Then
                            strArr(Idx, 6) = "PA"
                            strArr(Idx, 7) = ""
                        ElseIf (strNPAEffDt.Length > 11) Then
                            Throw New Exception(strNPAEffDt)
                        Else
                            If CDate(strNPAEffDt) <= CDate(CutOffDt) Then
                                strArr(Idx, 6) = "NPA"
                                strArr(Idx, 7) = strNPAEffDt
                            Else
                                strArr(Idx, 6) = "PA"
                                strArr(Idx, 7) = ""
                            End If
                        End If

                        Idx += 1
                    Else

                        strArr(Idx, 0) = npaDs.Tables(0).Rows(i)(0)   'accno
                        strArr(Idx, 1) = npaDs.Tables(0).Rows(i)(1)   'name
                        strArr(Idx, 2) = npaDs.Tables(0).Rows(i)(2)   'npastatus
                        strArr(Idx, 3) = npaDs.Tables(0).Rows(i)(3)   'sanctionamt
                        strArr(Idx, 4) = schAmt                       'schedulebal
                        strArr(Idx, 5) = CurBal                       'curbalance
                        strArr(Idx, 6) = "PA"                         'pa/npa
                        strArr(Idx, 7) = ""
                        Idx += 1

                    End If

                Else

                    If Math.Abs(CurBal) > Math.Abs(schAmt) And scheduleAvailableYN = "Y" Then
                        strArr(Idx, 0) = npaDs.Tables(0).Rows(i)(0)
                        strArr(Idx, 1) = npaDs.Tables(0).Rows(i)(1)
                        strArr(Idx, 2) = npaDs.Tables(0).Rows(i)(2)
                        strArr(Idx, 3) = npaDs.Tables(0).Rows(i)(3)
                        strArr(Idx, 4) = schAmt
                        strArr(Idx, 5) = CurBal

                        'New Code written by Monica on 19-JAN-2011


                        'strArr(Idx, 6) = "NPA"
                        strNPAEffDt = getNpaEffectedDate(BranchCode, CurrencyCode, GlCode, strArr(Idx, 0), npaDs.Tables(0).Rows(i)(4), gObjOracleConnection, SchCutOffDt, CDate(CutOffDt))

                        If (strNPAEffDt = "") Then
                            strArr(Idx, 6) = "PA"
                            strArr(Idx, 7) = ""

                        ElseIf (strNPAEffDt.Length > 11) Then
                            Throw New Exception(strNPAEffDt)
                        Else
                            If CDate(strNPAEffDt) <= CDate(CutOffDt) Then

                                strArr(Idx, 6) = "NPA"
                                strArr(Idx, 7) = strNPAEffDt
                            Else
                                strArr(Idx, 6) = "PA"
                                strArr(Idx, 7) = ""
                            End If
                        End If

                        'END of New Code written by Monica on 19-JAN-2011

                        Idx += 1
                    ElseIf scheduleAvailableYN = "N" Then
                        strArr(Idx, 0) = npaDs.Tables(0).Rows(i)(0)   'accno
                        strArr(Idx, 1) = npaDs.Tables(0).Rows(i)(1)   'name
                        strArr(Idx, 2) = npaDs.Tables(0).Rows(i)(2)   'npastatus
                        strArr(Idx, 3) = npaDs.Tables(0).Rows(i)(3)   'sanctionamt
                        strArr(Idx, 4) = schAmt                       'schedulebal
                        strArr(Idx, 5) = CurBal                       'curbalance
                        strArr(Idx, 6) = "PA"                         'pa/npa
                        strArr(Idx, 7) = ""
                        Idx += 1
                    End If
                End If
EndOfForLoop:
            Next

            gObjOracleConnection.Close()
            LoanNpaTransaction = strArr

        Catch ex As Exception
            gObjOracleConnection.Close()
            MsgBox(ex.Message)
            Exit Function
        End Try
    End Function

    Public Function getNpaEffectedDate(ByVal BranchCode As String, _
    ByVal CurrencyCode As String, ByVal GlCode As String, ByVal Accno As String, ByVal Santioneddate As Date, ByVal OraConn As OracleClient.OracleConnection, ByVal SchCutOffDt As Date, ByVal cutoffdate As Date) As String

        'Code commented by Monica on 18-JAN-2011

        '''Dim dsEffdt As DataSet
        '''Dim daEffdt As New OracleClient.OracleDataAdapter
        '''Dim objCommand As New OracleClient.OracleCommand
        '''Dim strQuery As String
        '''Dim npaReader As OracleClient.OracleDataReader
        '''Dim dtNPAdt As String

        '''dtNPAdt = Format(SchCutOffDt, "dd-MMM-yyyy")

        '''''get previous NPA effected date
        '''strQuery = "SELECT TO_CHAR(NPAEFFDATE,'dd-MON-yyyy') FROM NPALOANDTLS " & _
        '''" WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        '''"' AND CURRENCYCODE='" & CurrencyCode & "' AND NPASTATUS='NPA'"

        '''objCommand = New OracleClient.OracleCommand(strQuery, OraConn)

        '''npaReader = objCommand.ExecuteReader

        ''''' compare the cutoff date, NPAeffeted date and santioned date and take which ever is oldest
        '''If npaReader.Read Then

        '''    If CDate(npaReader(0)) < dtNPAdt Then
        '''        dtNPAdt = npaReader(0)
        '''    End If

        '''End If

        '''If Santioneddate > dtNPAdt Then
        '''    dtNPAdt = Santioneddate
        '''End If

        '''Return dtNPAdt

        'END of Code commented by Monica on 18-JAN-2011

        '****************************************************************************
        'New Code written by Monica on 18-JAN-2011

        Dim dsEffdt As DataSet
        Dim daEffdt As New OracleClient.OracleDataAdapter
        Dim objCommand As New OracleClient.OracleCommand
        Dim strQuery As String
        Dim strQueryIns, strDisbmntDt As String
        Dim stremi, strsqlemi, strgncnmst As String
        Dim genconmstReader As OracleClient.OracleDataReader
        Dim lntypeReader As OracleClient.OracleDataReader

        Dim npaReader As OracleClient.OracleDataReader
        Dim icReader As OracleClient.OracleDataReader
        Dim InsReader, DisbmntReader As OracleClient.OracleDataReader
        Dim dtNPAdt, dtDisbSanc, dtCutOff As Date
        Dim intMnths, strCutOff As String
        Dim strQryMnths As String
        Dim effDate As Date
        Dim diffMnths As Long
        Dim MnthsReader As OracleClient.OracleDataReader
        Dim strNPAdt As String
        Dim dblInstalAmt As Double
        Dim lngsandtduedt As Long
        '' get EMI loan type mst 
        strsqlemi = ""
        stremi = ""
        strsqlemi = "SELECT nvl(EMIYN,'N') emiyn FROM loantypemst WHERE glcode ='" & GlCode & "'"
        objCommand = New OracleClient.OracleCommand(strsqlemi, OraConn)
        lntypeReader = objCommand.ExecuteReader
        If lntypeReader.Read Then
            If lntypeReader.HasRows Then
                stremi = lntypeReader!emiyn
            Else
                stremi = "N"
            End If
        End If
        objCommand.Dispose()
        lntypeReader.Dispose()

        '' get IMPYN from genconfigmst
        strsqlemi = ""
        strgncnmst = ""
        strsqlemi = "SELECT nvl(IMPYN,'N') IMPYN FROM genconfigmst WHERE code = 'NPAINS'"
        objCommand = New OracleClient.OracleCommand(strsqlemi, OraConn)
        genconmstReader = objCommand.ExecuteReader
        If genconmstReader.Read Then
            If genconmstReader.HasRows Then
                strgncnmst = genconmstReader!IMPYN
            Else
                strgncnmst = "N"
            End If
        End If
        objCommand.Dispose()
        genconmstReader.Dispose()
        dtNPAdt = Format(SchCutOffDt, "dd-MMM-yyyy")

        'strQryMnths = "select nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)" & _
        strQryMnths = "select CASE WHEN NVL(PRINRECOVERYMTHS,0) =0 THEN NVL(PRINRECOVERYDAYS, 0)/30 ELSE" & _
        " NVL(PRINRECOVERYMTHS, 0) End ,nvl(PRINPASTDUEMTHS,0)" & _
    ",nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(" & _
    "PRINRECOVERYDAYS, 0),nvl(INTRECOVERYDAYS, 0) from " & _
    "NPAASSETTYPEPMT where upper(trim(glcode))='" & GlCode & "'"

        objCommand = New OracleClient.OracleCommand(strQryMnths, OraConn)

        MnthsReader = objCommand.ExecuteReader
        objCommand.Dispose()

        If MnthsReader.Read Then
            dtCutOff = Convert.ToDateTime(dtNPAdt).AddMonths(MnthsReader(0) + MnthsReader(1))
            strCutOff = Format(dtCutOff, "dd-MMM-yyyy")
        Else
            strNPAdt = "Set Parameters For GLcode " & GlCode
            Return strNPAdt
            Exit Function
        End If


        ''get previous NPA effected date
        '' sum of credit amount
        strQuery = "SELECT nvl(SUM(AMOUNT),0) FROM LOANTRAN " & _
        " WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        "' AND CURRENCYCODE='" & CurrencyCode & "' AND AMOUNT>0 AND APPLICATIONDATE<=to_date('" & Format(cutoffdate, "dd-MMM-yyyy") & "','dd-mon-yyyy')"

        objCommand = New OracleClient.OracleCommand(strQuery, OraConn)

        npaReader = objCommand.ExecuteReader
        objCommand.Dispose()

        '' interest amount
        strQueryIns = "SELECT nvl(SUM(AMOUNT),0) FROM LOANTRAN " & _
        " WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        "' AND CURRENCYCODE='" & CurrencyCode & "' AND CHQFVG='IC'  AND APPLICATIONDATE<=to_date('" & Format(cutoffdate, "dd-MMM-yyyy") & "','dd-mon-yyyy')"

        objCommand = New OracleClient.OracleCommand(strQueryIns, OraConn)

        icReader = objCommand.ExecuteReader
        objCommand.Dispose()
        '' installment amount
        strQueryIns = "SELECT nvl(INSTALMENTAMT,0),SANCTIONEDDATE,duedate FROM LOANMST " & _
        " WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        "' AND CURRENCYCODE='" & CurrencyCode & "'"

        objCommand = New OracleClient.OracleCommand(strQueryIns, OraConn)

        InsReader = objCommand.ExecuteReader
        objCommand.Dispose()
        '' disbursement date 
        strDisbmntDt = "SELECT DISBURSEMENTDATE FROM LOANDISBURSEMENTDTLS " & _
        " WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        "' AND CURRENCYCODE='" & CurrencyCode & "'"

        'strDisbmntDt = "SELECT FIRSTREPAYMNTDATE FROM LOANmst " & _
        '" WHERE  ACCNO='" & Accno & "' AND GLCODE='" & GlCode & "' AND BRANCHCODE='" & BranchCode & _
        '"' AND CURRENCYCODE='" & CurrencyCode & "'"

        objCommand = New OracleClient.OracleCommand(strDisbmntDt, OraConn)

        DisbmntReader = objCommand.ExecuteReader
        objCommand.Dispose()

        '''changed by dattu 11-Feb-2015 
        If strgncnmst = "Y" Then
            If npaReader.Read And InsReader.Read Then
                If InsReader(0) = 0 Then
                    strNPAdt = "Set Installment Amount for the A/C " & Accno
                    Return strNPAdt
                    Exit Function
                End If

                If icReader.Read Then
                    If stremi = "Y" Then
                        dblInstalAmt = npaReader(0) ''+ Math.Abs(icReader(0))  ''sum of credit amount
                    Else
                        dblInstalAmt = npaReader(0) + icReader(0)  ''sum of credit amt + interest applied
                    End If
                    'dblInstalAmt = npaReader(0) - icReader(0)
                Else
                    dblInstalAmt = npaReader(0)   '' sum of credit amount
                End If ''icReader

                intMnths = Math.Round(dblInstalAmt / InsReader(0)) + 1   '' total installment amout / installment amount
            End If

        Else  ''strgncnmst = "N"

            If npaReader.Read And InsReader.Read Then
                If InsReader(0) = 0 Then
                    strNPAdt = "Set Installment Amount for the A/C " & Accno
                    Return strNPAdt
                    Exit Function
                End If

                If icReader.Read Then

                    dblInstalAmt = npaReader(0) + icReader(0)  ''sum of credit amt + interet applied
                    'dblInstalAmt = npaReader(0) - icReader(0)
                Else
                    dblInstalAmt = npaReader(0)     ''' sum of credit amount
                End If  ''icReader

                intMnths = Math.Round(dblInstalAmt / InsReader(0))   '' total installment amout / instalment amount
            End If
        End If ''strgncnmst



        If DisbmntReader.Read = True Then
            If IsDBNull(DisbmntReader(0)) = True Then
                strNPAdt = "Set DisbursementDate for the A/C " & Accno
                Return strNPAdt
                Exit Function
            Else
                dtDisbSanc = DisbmntReader(0)    ''' disbursement date
            End If

        Else
            dtDisbSanc = InsReader(1)   '''  sanctioned date
        End If


        If strgncnmst = "Y" Then   '' genconfigmst impyn = "Y"

            lngsandtduedt = DateDiff(DateInterval.Month, InsReader(1), InsReader(2))
            If lngsandtduedt < CLng(intMnths) Then
                dtNPAdt = Convert.ToDateTime(InsReader(2)).AddMonths(MnthsReader(0) + MnthsReader(1))
                strNPAdt = Format(dtNPAdt, "dd-MMM-yyyy")
            Else
                'effDate = dtCutOff
                effDate = Convert.ToDateTime(dtDisbSanc).AddMonths(intMnths)

                dtNPAdt = Convert.ToDateTime(dtNPAdt).AddMonths(MnthsReader(0) + MnthsReader(1))
                diffMnths = DateDiff(DateInterval.Month, effDate, dtNPAdt)

                If (intMnths = 0) Then
                    dtNPAdt = Convert.ToDateTime(dtDisbSanc).AddMonths(MnthsReader(0) + MnthsReader(1))
                    dtNPAdt = Convert.ToDateTime(dtNPAdt).AddDays(1)
                    strNPAdt = Format(dtNPAdt, "dd-MMM-yyyy")

                ElseIf (diffMnths >= (MnthsReader(0) + MnthsReader(1))) Then

                    dtNPAdt = Convert.ToDateTime(effDate).AddMonths(MnthsReader(0) + MnthsReader(1))
                    dtNPAdt = Convert.ToDateTime(dtNPAdt).AddDays(1)
                    strNPAdt = Format(dtNPAdt, "dd-MMM-yyyy")

                Else
                    strNPAdt = ""
                End If
            End If

        Else  ''strgncnmst = "N"

            'effDate = dtCutOff
            effDate = Convert.ToDateTime(dtDisbSanc).AddMonths(intMnths)   ''' disbursement date + no of installments

            dtNPAdt = Convert.ToDateTime(dtNPAdt).AddMonths(MnthsReader(0) + MnthsReader(1))  '''' schedule date 
            diffMnths = DateDiff(DateInterval.Month, effDate, dtNPAdt)       '''' diff months  of schedule date and eff date

            If (intMnths = 0) Then
                dtNPAdt = Convert.ToDateTime(dtDisbSanc).AddMonths(MnthsReader(0) + MnthsReader(1))  '' disbursement date + no of months
                dtNPAdt = Convert.ToDateTime(dtNPAdt).AddDays(1)  '''  schedule date + one day
                strNPAdt = Format(dtNPAdt, "dd-MMM-yyyy")     ''' schedule date 

            ElseIf (diffMnths >= (MnthsReader(0) + MnthsReader(1))) Then

                dtNPAdt = Convert.ToDateTime(effDate).AddMonths(MnthsReader(0) + MnthsReader(1))    ''' effective date + no of months 
                dtNPAdt = Convert.ToDateTime(dtNPAdt).AddDays(1)  ''' schedula date  +  one daye
                strNPAdt = Format(dtNPAdt, "dd-MMM-yyyy")   ''' schedule date 

            Else
                strNPAdt = ""
            End If
        End If  ''strgncnmst 

        npaReader.Dispose()
        daEffdt.Dispose()
        InsReader.Dispose()
        DisbmntReader.Dispose()
        MnthsReader.Dispose()
        Return strNPAdt

        'End of New Code written by Monica on 18-JAN-2011
    End Function

    Public Function CCTransaction(ByVal BranchCode As String, _
    ByVal CurrencyCode As String, ByVal ModuleId As String, ByVal GlCode As String, ByVal CutOffDt As String, ByRef o_ErrMsg As String) As String(,)


        Dim bConnOpened, bTransBegin As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strObjHist, returnMsgm, sQuery As String
        Dim iNoOfRows, ErrMsg As String
        Dim SchCutOffDt, IntCutOffDate As Date
        Dim npaDS As New DataSet
        Dim npaReader As OracleClient.OracleDataReader
        Dim npaDA As New OracleClient.OracleDataAdapter
        Dim strArr(,) As String
        Dim i As Integer
        Dim schAmt, sumCr, sumChr, CurBal As Double

        Try

            gObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)

            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                          " DataBase. Reason Is " & o_ErrMsg)
            End If

            '''fetching the principle recovery months,pastdue and interest recovery months,past due

            sQuery = "select nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)" & _
            ",nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(" & _
            "PRINRECOVERYDAYS, 0),nvl(INTRECOVERYDAYS, 0) from " & _
            "NPAASSETTYPEPMT where upper(trim(branchcode))='" & BranchCode & _
            "' and upper(trim(glcode))='" & GlCode & "'"

            objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)

            npaReader = objcommand.ExecuteReader

            Dim newDt As Double

            If npaReader.Read Then

                '''calculating the npa priniciple calc date for the given cuttoffdate

                newDt = -(CDbl(npaReader(0)) + CDbl(npaReader(1)))

                SchCutOffDt = Convert.ToDateTime(CutOffDt).AddMonths(newDt)

                SchCutOffDt = Convert.ToDateTime(SchCutOffDt).AddDays _
                                                (-CDbl(npaReader(4)))
                SchCutOffDt = Format(SchCutOffDt, "dd-MMM-yyyy")



            Else
                Throw New Exception("Parameters Not Available" & _
                " For the GLCode " & GlCode)
            End If


            sQuery = "select accno,name from ccmst WHERE upper(trim(branchcode))='" & BranchCode & "' and upper(trim(currencycode))='" & CurrencyCode & "' and upper(trim(glcode))='" & GlCode & "' and opdate<=to_date('" & CutOffDt & "','dd-mm-yyyy') and (CLOSEDATE>to_date('" & SchCutOffDt & "','dd-mm-yyyy') or closedate is null ) ORDER BY accno"

            objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
            npaDA = New OracleClient.OracleDataAdapter(objcommand)
            npaDA.Fill(npaDS)

            If npaDS Is Nothing Or npaDS.Tables(0).Rows.Count = 0 Then
                'Throw New Exception("No Records")
                Exit Function
            End If

            ReDim strArr(npaDS.Tables(0).Rows.Count - 1, 5)
            Dim pa As Integer

            For i = 0 To npaDS.Tables(0).Rows.Count - 1

                sQuery = "select getanydaybal('" & BranchCode & "','" & CurrencyCode & "','" & ModuleId & "','" & GlCode & "','" & npaDS.Tables(0).Rows(i)(0) & "','" & CutOffDt & "') from dual"
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                ErrMsg = objcommand.ExecuteScalar

                If ErrMsg.Length >= 5 Then
                    If UCase(ErrMsg.Substring(0, 5)) = "ERROR" Then
                        Throw New Exception(ErrMsg & "For Accno" & npaDS.Tables(0).Rows(i)(0))
                    Else
                        CurBal = CDbl(ErrMsg)
                    End If
                Else
                    CurBal = CDbl(ErrMsg)
                End If

                If CurBal >= 0 Then
                    strArr(i, 0) = npaDS.Tables(0).Rows(i)(0)
                    strArr(i, 1) = npaDS.Tables(0).Rows(i)(1)
                    strArr(i, 2) = "" 'npaDS.Tables(0).Rows(i)(2)
                    strArr(i, 3) = CurBal
                    strArr(i, 4) = "" ' limit amount
                    strArr(i, 5) = "PA"
                Else
                    sQuery = "select nvl(count(*),0) from cctran upper" & _
                             "(trim(branchcode))='" & BranchCode & _
                             "' and upper(trim(currencycode))='" & _
                             CurrencyCode & "' and upper(trim(glcode))='" _
                             & GlCode & "' and accno ='" & _
                             npaDS.Tables(0).Rows(i)(0) & "' and " & _
                             "trim(upper(CHQFVG))<>'IC' and " & _
                             "effectivedate between '" & SchCutOffDt & _
                             "' and '" & CutOffDt & "'"

                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                     gObjOracleConnection)
                    ErrMsg = objcommand.ExecuteScalar
                    If ErrMsg = "0" Then
                        strArr(i, 0) = npaDS.Tables(0).Rows(i)(0)
                        strArr(i, 1) = npaDS.Tables(0).Rows(i)(1)
                        strArr(i, 2) = "" 'npaDS.Tables(0).Rows(i)(2)
                        strArr(i, 3) = CurBal
                        strArr(i, 4) = "" ' limit amount
                        strArr(i, 5) = "NPA"
                    Else
                        sQuery = "select nvl(sum(amount),0) from cctran upper" & _
                             "(trim(branchcode))='" & BranchCode & _
                             "' and upper(trim(currencycode))='" & _
                             CurrencyCode & "' and upper(trim(glcode))='" _
                             & GlCode & "' and accno ='" & _
                             npaDS.Tables(0).Rows(i)(0) & "' and " & _
                             "effectivedate between '" & SchCutOffDt & _
                             "' and '" & CutOffDt & "' and amount>=0"
                        objcommand = New OracleClient.OracleCommand(sQuery _
                        , gObjOracleConnection)
                        ErrMsg = objcommand.ExecuteScalar
                        sumCr = ErrMsg

                        sQuery = "select nvl(sum(amount),0) from cctran" & _
                                 " upper(trim(branchcode))='" & BranchCode _
                                 & "' and upper(trim(currencycode))='" & _
                                 CurrencyCode & "' and upper(trim(glcode))='" _
                                 & GlCode & "' and accno ='" & _
                                 npaDS.Tables(0).Rows(i)(0) & "' and " & _
                                 "trim(upper(CHQFVG))='IC' and " & _
                                 "trim(remarks)='Loan Interest Posting'" & _
                                 " and effectivedate between '" & _
                                 SchCutOffDt & "' and '" & CutOffDt & _
                                 "' and amount<0"

                        objcommand = New OracleClient.OracleCommand(sQuery _
, gObjOracleConnection)
                        ErrMsg = objcommand.ExecuteScalar
                        sumChr = ErrMsg
                        If sumCr >= sumChr Then
                            strArr(i, 0) = npaDS.Tables(0).Rows(i)(0)
                            strArr(i, 1) = npaDS.Tables(0).Rows(i)(1)
                            strArr(i, 2) = "" 'npaDS.Tables(0).Rows(i)(2)
                            strArr(i, 3) = CurBal
                            strArr(i, 4) = "" ' limit amount
                            strArr(i, 5) = "NPA"
                        Else
                            '3rd condition required
                        End If
                    End If

                End If

            Next

        Catch ex As Exception



        End Try

    End Function
    Public Function PostNPATransactions(ByVal BranchCode As String, _
                 ByVal CurrencyCode As String, ByVal ModuleId As String, _
                 ByVal Glcode As String, ByVal AsOnDate As Date, _
                 ByVal UserId As String, ByVal ApplicationDt As Date, _
                 ByVal MachineId As String, ByVal arrVals() As Object, _
                 ByRef o_ErrMsg As String) As Boolean

        Dim bConnOpened, bTransBegin As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection
        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand
        Dim objHist As New DatabaseConnection.updateHistTable
        Dim strObjHist, returnMsgm, sQuery, iNoOfRows, ErrMsg, strAccountNos, strNpaAcc, strPaAcc As String
        Dim SchCutOffDt, effDate As Date
        Dim npaDS As New DataSet
        Dim npaReader As OracleClient.OracleDataReader
        Dim npaDA As New OracleClient.OracleDataAdapter
        Dim strArr() As String
        Dim idx, i, count, noofPa, noofNpa, rowcount As Integer
        Dim schAmt, sumCr, sumChr, CurBal As Double
        Dim sMainTable, sBkpTable, sMstTable As String
        Dim bActionStarted As Boolean = False
        Dim BulkArrPA(200) As String, CntPA, BulkArrIdxPA As Integer
        Dim BulkArrNPA(200) As String, CntNPA, BulkArrIdxNPA, cntAccList As Integer

        Try

            ModuleId = UCase(Trim(ModuleId))
            sMstTable = ModuleId & "MST"
            sMainTable = "NPA" & ModuleId & "DTLS"
            sBkpTable = "NPA" & ModuleId & "DTLSBCKP"
            cntAccList = 900

            gObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)

            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                          " DataBase. Reason Is " & o_ErrMsg)
            End If

            '''fetching the principle recovery months,pastdue 
            'Code modified by Radhika on 07 Feb 2009
            'sQuery = "select nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)" & _
            '",nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(" & _
            '"PRINRECOVERYDAYS, 0),nvl(INTRECOVERYDAYS, 0) from " & _
            '"NPAASSETTYPEPMT where upper(trim(branchcode))='" & BranchCode & _
            '"' and upper(trim(glcode))='" & Glcode & "'"

            sQuery = "select nvl(PRINRECOVERYMTHS,0),nvl(PRINPASTDUEMTHS,0)" & _
            ",nvl(INTRECOVERYMTHS,0), nvl(INTPASTDUEMTHS,0),nvl(" & _
            "PRINRECOVERYDAYS, 0),nvl(INTRECOVERYDAYS, 0) from " & _
            "NPAASSETTYPEPMT where upper(trim(glcode))='" & Glcode & "'"


            objcommand = New OracleClient.OracleCommand(sQuery, _
                         gObjOracleConnection)
            npaReader = objcommand.ExecuteReader
            'gObjOracleConnection.Close()
            objcommand.Dispose()
            objcommand = Nothing

            Dim newDt As Double

            '''calculating the npa priniciple calc date for the given cuttoffdate
            If npaReader.Read Then
                newDt = -(CDbl(npaReader(0)) + CDbl(npaReader(1)))
                SchCutOffDt = Convert.ToDateTime(AsOnDate).AddMonths(newDt)
                SchCutOffDt = Convert.ToDateTime(SchCutOffDt).AddDays _
                                               (-CDbl(npaReader(4)))
                SchCutOffDt = Format(SchCutOffDt, "dd-MMM-yyyy")
            Else
                Throw New Exception("Parameters Not Available" & _
                " For the GLCode " & Glcode)
            End If
            npaReader.Close()
            npaReader = Nothing

            'To check whether NPAClassification is already done for the given as on date
            sQuery = "SELECT COUNT(*) FROM NPAPAACTIVITYLOG WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE = '" & CurrencyCode & _
                "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & _
                "' AND EFFECTIVEDATE >= '" & Format(AsOnDate, "dd-MMM-yyyy") & _
                "' AND STATUS='C'"


            objcommand = New OracleClient.OracleCommand(sQuery, _
                             gObjOracleConnection)
            ErrMsg = objcommand.ExecuteScalar
            objcommand.Dispose()
            objcommand = Nothing

            If ErrMsg <> 0 Then

                sQuery = " select max(effectivedate) FROM " & _
                "NPAPAACTIVITYLOG WHERE BRANCHCODE='" & BranchCode & _
                "' AND CURRENCYCODE = '" & CurrencyCode & "' AND " & _
                "MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & _
                "' AND EFFECTIVEDATE >= '" & Format(AsOnDate, _
                "dd-MMM-yyyy") & "' AND STATUS='C'"


                objcommand = New OracleClient.OracleCommand(sQuery, _
                                 gObjOracleConnection)

                effDate = objcommand.ExecuteScalar
                objcommand.Dispose()
                objcommand = Nothing
                Throw New Exception("NPA Classification has already been" & _
                " done upto : " & effDate)

            End If

            'To check whether any classification is already under process
            'for the as on date
            sQuery = "SELECT COUNT(*) FROM NPAPAACTIVITYLOG WHERE BRANCHCODE='" & _
                BranchCode & "' AND CURRENCYCODE = '" & CurrencyCode & _
                "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & _
                "' AND EFFECTIVEDATE >= '" & Format(AsOnDate, "dd-MMM-yyyy") & _
                "' AND STATUS='B'"


            objcommand = New OracleClient.OracleCommand(sQuery, _
                                         gObjOracleConnection)
            ErrMsg = objcommand.ExecuteScalar
            objcommand.Dispose()
            objcommand = Nothing
            If ErrMsg <> "0" Then

                sQuery = " select max(effectivedate) FROM " & _
                "NPAPAACTIVITYLOG WHERE BRANCHCODE='" & BranchCode & _
                "' AND CURRENCYCODE = '" & CurrencyCode & "' AND " & _
                "MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & _
                "' AND EFFECTIVEDATE >= '" & Format(AsOnDate, _
                "dd-MMM-yyyy") & "' AND STATUS='B'"


                objcommand = New OracleClient.OracleCommand(sQuery, _
                                 gObjOracleConnection)

                effDate = objcommand.ExecuteScalar
                objcommand.Dispose()
                objcommand = Nothing
                Throw New Exception("NPA Classification is already in " & _
                    " progress for " & Glcode & " As On Date " & _
                    CStr(Format(effDate, "dd-MMM-yyyy")))

            End If

            'To say other User's who are doing the same classification that
            'the process has begun for the given as on date
            sQuery = "insert into NPAPAACTIVITYLOG (BRANCHCODE, CURRENCYCODE," & _
                "MODULEID, GLCODE, EFFECTIVEDATE, STATUS, ACTIVITYID, USERID," & _
                "MACHINEID, APPLICATIONDATE, SYSTEMDATE) values ('" & _
                BranchCode & "','" & CurrencyCode & "','" & ModuleId & "','" & _
                Glcode & "','" & Format(AsOnDate, "dd-MMM-yyyy") & _
                "','B','NPA','" & UserId & "','" & MachineId & "','" & _
                Format(ApplicationDt, "dd-MMM-yyyy") & "',sysdate)"


            objcommand = New OracleClient.OracleCommand(sQuery, _
                             gObjOracleConnection)
            ErrMsg = objcommand.ExecuteNonQuery

            objcommand.Dispose()
            objcommand = Nothing

            If ErrMsg <> "1" Then
                Throw New Exception(ErrMsg)
            End If
            bActionStarted = True

            Dim arrBrCodes, arrAccs, arrNames, arrNpaStatus, arrNpa, _
            arrCurbal, arrSanBal, arrSchBal, arrNpaEffDate As Object
            Dim strCols, strVals, strWherecond, fldnames, strNpa As String

            arrBrCodes = Split(arrVals(0), ",")
            arrAccs = Split(arrVals(1), ",")
            arrNpaStatus = Split(arrVals(2), ",")
            arrNames = Split(arrVals(3), ",")
            arrSanBal = Split(arrVals(4), ",")
            arrSchBal = Split(arrVals(5), ",")
            arrCurbal = Split(arrVals(6), ",")
            arrNpa = Split(arrVals(7), ",")
            arrNpaEffDate = Split(arrVals(8), ",")

            objTransaction = gObjOracleConnection.BeginTransaction()
            bTransBegin = True

            Dim sBkpTableName, sMainTableName, sModId As String

            sModId = ModuleId
            sMainTableName = "NPA" & sModId & "DTLS" 'Ex: NPALOANDTLS
            sBkpTableName = "NPA" & sModId & "DTLSBKP" 'Ex: NPALOANDTLSBCKP

            ''check if there are old recodes if present shift them to backup
            sQuery = "select count(*) from " & _
                sMainTableName & " WHERE BRANCHCODE='" & BranchCode & "' AND glcode='" & Glcode & "'"
            objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
            objcommand.Transaction = objTransaction
            ErrMsg = objcommand.ExecuteScalar
            objcommand.Dispose()
            objcommand = Nothing


            ''Moving old data to Backup table
            If ErrMsg <> 0 Then
                If sModId = "LOAN" Then
                    sQuery = "insert into " & sBkpTableName & "(BRANCHCODE, CURRENCYCODE, GLCODE, ACCNO, NAME, SANCTIONEDAMT, SCHEDULEBAL, CURRENTBAL, NPASTATUS, ASSETSTATUS, USERID, MACHINEID, APPLICATIONDATE, SYSTEMDATE, NPAEFFDATE, OLDNPASTATUS, OLDASSETSTATUS) select * from " & _
                        sMainTableName & " WHERE BRANCHCODE='" & BranchCode & _
                        "' AND glcode='" & Glcode & "'"
                Else
                    sQuery = "insert into " & sBkpTableName & " (select * from " & _
                                           sMainTableName & " WHERE BRANCHCODE='" & BranchCode & _
                                           "' AND glcode='" & Glcode & "')"
                End If
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()
                objcommand.Dispose()
                objcommand = Nothing

            End If

                'sQuery = "delete from NPALOANDTLS"
                sQuery = "delete from " & sMainTableName & _
                " WHERE BRANCHCODE='" & BranchCode & "' AND glcode='" & Glcode & "'"
                objcommand = New OracleClient.OracleCommand(sQuery, gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()
            objcommand.Dispose()
            objcommand = Nothing


                noofPa = 0
                noofNpa = 0
                strNpaAcc = ""
                strPaAcc = ""
                BulkArrIdxPA = 0
                BulkArrIdxNPA = 0
                CntPA = 0
                CntNPA = 0
                For idx = 0 To UBound(arrBrCodes)

                    ' to get all the accounts comes under PA or NPA

                    If arrNpa(idx) = "NPA" Then
                        noofNpa += 1
                        CntNPA += 1
                        If strNpaAcc = "" Then
                            strNpaAcc = "'" & arrAccs(idx) & "'"
                        Else
                            strNpaAcc = strNpaAcc & ",'" & arrAccs(idx) & "'"
                        End If

                        If CntNPA = cntAccList Then
                            BulkArrNPA(BulkArrIdxNPA) = strNpaAcc
                            BulkArrIdxNPA += 1
                            strNpaAcc = ""
                            CntNPA = 0
                        End If

                    ElseIf arrNpa(idx) = "PA" Then
                        noofPa += 1
                        CntPA += 1
                        If strPaAcc = "" Then
                            strPaAcc = "'" & arrAccs(idx) & "'"
                        Else
                            strPaAcc = strPaAcc & ",'" & arrAccs(idx) & "'"
                        End If

                        If CntPA = cntAccList Then
                            BulkArrPA(BulkArrIdxPA) = strPaAcc
                            BulkArrIdxPA += 1
                            strPaAcc = ""
                            CntPA = 0
                        End If

                    End If



                    ' If Account is classifying form PA to NPA or NPA to PA we insert it into NPANPADTLS and if the account is classfying from npa to npa and if it is not there in the NPANPADTLS upto now we insert by assuming it as a PA to NPA Classification


                    If arrNpa(idx) <> arrNpaStatus(idx) Or (arrNpa(idx) = _
                                    "NPA" And arrNpaStatus(idx) = "NPA") Then

                        ErrMsg = 1
                        If arrNpa(idx) = "NPA" And _
                                                arrNpaStatus(idx) = "NPA" Then

                            sQuery = "select count(*) from NPANPADTLS where" & _
                            " branchcode='" & BranchCode & "' and " & _
                            "currencycode='" & CurrencyCode & "' and " & _
                            "moduleid='" & ModuleId & "' and glcode='" & _
                            Glcode & "' and accno='" & arrAccs(idx) & "'"

                            ' & _ " and NPACALCDT='" & Format(AsOnDate, _
                            '"dd-MMM-yyyy") & "'"


                            objcommand = New OracleClient.OracleCommand( _
                                             sQuery, gObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            ErrMsg = objcommand.ExecuteScalar
                            objcommand.Dispose()
                        objcommand = Nothing
                        End If

                        strCols = ""

                        ''PA to NPA
                        If (arrNpa(idx) = "NPA" And arrNpaStatus(idx) = "PA") _
                            Or CInt(ErrMsg) = 0 Then

                            strCols = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                                "ACCNO,PATONPADT,NPATOPADT,APPLICATIONDATE," & _
                                "USERID, MACHINEID, STATUS, SYSTEMDATE,NPACALCDT"

                            strVals = "'" & BranchCode & "','" & CurrencyCode & _
                                "','" & ModuleId & "','" & Glcode & "','" & _
                                arrAccs(idx) & "','" & Format(CDate(arrNpaEffDate(idx)), "dd-MMM-yyyy") & _
                                "','','" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                                "','" & UserId & "','" & MachineId & "','R',sysdate,'" & _
                                Format(AsOnDate, "dd-MMM-yyyy") & "'"

                        ElseIf arrNpa(idx) = "PA" And arrNpaStatus(idx) = "NPA" Then
                            ''NPA to PA
                            strCols = "BRANCHCODE,CURRENCYCODE,MODULEID,GLCODE," & _
                                "ACCNO,NPATOPADT,PATONPADT,APPLICATIONDATE," & _
                                "USERID, MACHINEID, STATUS, SYSTEMDATE,NPACALCDT"

                            strVals = "'" & BranchCode & "','" & CurrencyCode & _
                                                            "','" & ModuleId & "','" & Glcode & "','" & _
                                                            arrAccs(idx) & "','" & Format(AsOnDate, "dd-MMM-yyyy") & _
                                                            "','','" & Format(ApplicationDt, "dd-MMM-yyyy") & _
                                                            "','" & UserId & "','" & MachineId & "','R',sysdate,'" & _
                                                            Format(AsOnDate, "dd-MMM-yyyy") & "'"


                        End If

                        If strCols <> "" Then
                            sQuery = "insert into NPANPADTLS (" & strCols & _
                                     ") values (" & strVals & ")"

                            objcommand = New OracleClient.OracleCommand(sQuery _
                                             , gObjOracleConnection)
                            objcommand.Transaction = objTransaction
                            ErrMsg = objcommand.ExecuteNonQuery
                            objcommand.Dispose()
                        objcommand = Nothing
                            If ErrMsg <> "1" Then
                                Throw New Exception(ErrMsg)
                            End If
                        End If

                    End If


                    strWherecond = "branchcode='" & BranchCode & "' and " & _
                        "currencycode='" & CurrencyCode & "' and glcode='" & _
                        Glcode & "' and accno = '" & arrAccs(idx) & "' and " & _
                        "applicationdate='" & Format(ApplicationDt, _
                        "dd-MMM-yyyy") & "' and upper(userid)='" & UCase(UserId) & _
                        "' and upper" & "(machineid)='" & UCase(MachineId) & _
                        "' and effectivedate='" & Format(AsOnDate, "dd-MMM-yyyy") & "'"

                    fldnames = ""

                    strCols = "BRANCHCODE,CURRENCYCODE,GLCODE,ACCNO,NAME," & _
                        "NPAEFFDATE,SANCTIONEDAMT,SCHEDULEBAL,CURRENTBAL," & _
                        "NPASTATUS,ASSETSTATUS,USERID,MACHINEID,APPLICATIONDATE," & _
                        "SYSTEMDATE,oldNPAStatus"

                    strVals = "'" & BranchCode & "','" & CurrencyCode & "','" _
                        & Glcode & "','" & arrAccs(idx) & "','" & arrNames(idx) & _
                        "','" & arrNpaEffDate(idx) & "','" & _
                        arrSanBal(idx) & "','" & _
                        arrSchBal(idx) & "','" & arrCurbal(idx) & "','" & _
                        arrNpa(idx) & "','','" & UserId & "','" & MachineId & _
                        "','" & Format(ApplicationDt, "dd-MMM-yyyy") & "',sysdate,'" & _
                        arrNpaStatus(idx) & "'"

                    'NPALOANDTLS
                    sQuery = "insert into " & sMainTable & " (" & strCols & ") " & _
                             "values (" & strVals & ")"


                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                     gObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    ErrMsg = objcommand.ExecuteNonQuery
                    objcommand.Dispose()
                objcommand = Nothing
                    If ErrMsg <> "1" Then
                        Throw New Exception(ErrMsg)
                    End If
                    ' gObjOracleConnection.Close()
                Next

                If strNpaAcc <> "" Then
                    BulkArrNPA(BulkArrIdxNPA) = strNpaAcc
                    BulkArrIdxNPA += 1
                End If

                If strPaAcc <> "" Then
                    BulkArrPA(BulkArrIdxPA) = strPaAcc
                    BulkArrIdxPA += 1
                End If
                'strNpaAcc = "'" & strNpaAcc & "'"
                'strPaAcc = "'" & strPaAcc & "'"

                strWherecond = " CURRENCYCODE='" & CurrencyCode & _
                "' and GLCODE ='" & Trim(Glcode) & "' and BRANCHCODE='" & _
                BranchCode & "'"

                'LOANMST
                objHist.recordInHist(sMstTable, "NPASTATUS", _
                gObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If

                For i = 0 To (BulkArrIdxPA - 1)
                    sQuery = "update " & sMstTable & " set NPASTATUS='P' " & _
                            "where branchcode='" & BranchCode & "' and " & _
                            "currencycode='" & CurrencyCode & "' and glcode='" & _
                            Glcode & "' and accno in (" & BulkArrPA(i) & ")"


                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                    gObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    ErrMsg = objcommand.ExecuteNonQuery
                    objcommand.Dispose()
                objcommand = Nothing
                    ''If ErrMsg <> noofPa Then
                    ''    Throw New Exception("Updation to Npastatus in " & sMstTable & " Failed")
                    ''End If
                Next i

                For i = 0 To (BulkArrIdxNPA - 1)

                    sQuery = "update " & sMstTable & " set NPASTATUS='N' " & _
                            "where branchcode='" & BranchCode & "' and " & _
                            "currencycode='" & CurrencyCode & "' and glcode='" & _
                            Glcode & "' and accno in (" & BulkArrNPA(i) & ")"


                    objcommand = New OracleClient.OracleCommand(sQuery, _
                                    gObjOracleConnection)
                    objcommand.Transaction = objTransaction
                    ErrMsg = objcommand.ExecuteNonQuery
                    objcommand.Dispose()
                objcommand = Nothing
                    ''If ErrMsg <> noofNpa Then
                    ''    Throw New Exception("Updation to Npastatus in " & sMstTable & " Failed")
                    ''End If

                Next i

                sQuery = "INSERT INTO GENSYSTEMACTIVITYLOG(" & _
                    "BRANCHCODE,CURRENCYCODE, MODULEID, GLCODE,ACTIVITYID," & _
                    "FROMDATE,TODATE,APPLICATIONDATE,UserId,MachineId,STATUS," & _
                    "APPROVEDBY,APPROVEDMACHINE) VALUES('" & BranchCode & "','" & _
                    CurrencyCode & "','" & ModuleId & "','" & Glcode & "','NPA','" & _
                    Format(SchCutOffDt, "dd-MMM-yyyy") & "','" & _
                    Format(AsOnDate, "dd-MMM-yyyy") & "','" & _
                    Format(ApplicationDt, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                    " '" & MachineId & "','A','SYSTEM','" & MachineId & "')"


                objcommand = New OracleClient.OracleCommand(sQuery, _
                                                  gObjOracleConnection)
                objcommand.Transaction = objTransaction
                ErrMsg = objcommand.ExecuteNonQuery()
                objcommand.Dispose()
            objcommand = Nothing
                If ErrMsg <> 1 Then
                    Throw New Exception("Unable To Insert Data " & _
                    "Into GensystemActivityLog For The Branch " & _
                    arrBrCodes(idx))
                End If

                'sharath

                strWherecond = "BRANCHCODE='" & BranchCode & "' AND " & _
                    "CURRENCYCODE = '" & CurrencyCode & "' AND MODULEID='" & _
                    ModuleId & "' AND GLCODE='" & Glcode & "' AND " & _
                    " EFFECTIVEDATE = '" & Format(AsOnDate, "dd-MMM-yyyy") & "'"

                objHist.recordInHist("NPAPAACTIVITYLOG", "", _
                gObjOracleConnection, objTransaction, o_ErrMsg, rowcount, _
                strWherecond, BranchCode, UserId, MachineId, ApplicationDt)

                If o_ErrMsg <> "" Then
                    Throw New Exception(o_ErrMsg)
                End If

                sQuery = "update NPAPAACTIVITYLOG set status='C' " & _
                    " WHERE BRANCHCODE='" & BranchCode & "' AND CURRENCYCODE = '" & _
                    CurrencyCode & "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & _
                    Glcode & "' AND EFFECTIVEDATE = '" & Format(AsOnDate, _
                    "dd-MMM-yyyy") & "' AND STATUS='B'"


                objcommand = New OracleClient.OracleCommand(sQuery, _
                                                  gObjOracleConnection)
                objcommand.Transaction = objTransaction
                ErrMsg = objcommand.ExecuteNonQuery()
                objcommand.Dispose()
            objcommand = Nothing
                If ErrMsg <> "1" Then
                    Throw New Exception("Updation to Close NPA Activity Failed")
                End If

                objTransaction.Commit()
                gObjOracleConnection.Close()
                PostNPATransactions = True

                o_ErrMsg = "Posting Successfull.."

        Catch ex As Exception

            If IsNothing(objTransaction) = False Then

                objTransaction.Rollback()
                objTransaction = Nothing

            End If

            'Delete inserted activity details from NPAPAACTIVITYLOG
            If bActionStarted = True Then
                sQuery = "delete FROM NPAPAACTIVITYLOG WHERE BRANCHCODE='" & _
                    BranchCode & "' AND CURRENCYCODE = '" & CurrencyCode & _
                    "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & _
                    Glcode & "' AND EFFECTIVEDATE = '" & Format(AsOnDate, _
                    "dd-MMM-yyyy") & "' AND STATUS='B'"

                objcommand = Nothing
                objcommand = New OracleClient.OracleCommand(sQuery, _
                                            gObjOracleConnection)
                objcommand.Transaction = objTransaction
                objcommand.ExecuteNonQuery()
            End If

            objcommand = Nothing

            objDBConnection = Nothing
            gObjOracleConnection = Nothing
            '  MsgBox(ex.Message, MsgBoxStyle.Critical)
            PostNPATransactions = False

            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.NPAOperations" & _
                               " / PostNPATransactions"
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing NPA Classification Posting" & vbLf & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_ErrMsg, strComponent, BranchCode, UserId, MachineId)
                o_ErrMsg = clntDesc
            Else
                clntDesc = "Error ! while doing NPA Classification Posting"
                o_ErrMsg = clntDesc & " " & ex.Message
            End If
        End Try

    End Function
End Class
