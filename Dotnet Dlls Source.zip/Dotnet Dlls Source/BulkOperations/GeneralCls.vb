Public Class GeneralCls
    Public Function GetRemarks(ByVal strbrcd As String, ByVal strcurcd As String, ByVal strmodcd As String, ByVal strglcd As String, ByVal straccno As String) As String
        Try
            Dim strsql As String
            Dim objcommand As OracleClient.OracleCommand
            Dim drremarks As OracleClient.OracleDataReader
            Dim objDBConnection As New DatabaseConnection.cDBConnection
            Dim ObjOracleConnection As New OracleClient.OracleConnection
            Dim o_ErrMsg As String
            Dim strfrmdt As String
            Dim strtodt As String
            Dim strmsttab As String
            Dim strintcaltemptab As String
            ObjOracleConnection = objDBConnection.GetDbConnection(o_ErrMsg)
            If Trim(o_ErrMsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_ErrMsg)
            End If


            strmsttab = strmodcd & "MST"
            '' sb interest calculation 
            If UCase(strmodcd) = "SB" Then
                strsql = "SELECT TO_CHAR(LASTINTCALCDATE+1,'dd-Mon-yyyy')  FROM " & strmsttab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strfrmdt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing

                strintcaltemptab = strmodcd & "INTCALTEMP"
                strsql = "SELECT TO_CHAR(INTCALTODT,'dd-Mon-yyyy')  FROM " & strintcaltemptab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strtodt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing

                GetRemarks = "INT From " & strfrmdt & " To " & strtodt
                Exit Function
            End If

            '' DEP interest calculation 
            If UCase(strmodcd) = "DEP" Then
                strsql = "SELECT TO_CHAR(LASTINTCALCDATE+1,'dd-Mon-yyyy')  FROM " & strmsttab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strfrmdt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing

                strintcaltemptab = strmodcd & "INTCALTEMP"
                strsql = "SELECT TO_CHAR(TODATE,'dd-Mon-yyyy')  FROM " & strintcaltemptab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strtodt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing

                GetRemarks = "INT From " & strfrmdt & " To " & strtodt
                Exit Function
            End If


            '' Loan or CC  interest calculation 
            If UCase(strmodcd) = "LOAN" Or UCase(strmodcd) = "CC" Then
                strsql = "SELECT TO_CHAR(LASTINTCALCDATE+1,'dd-Mon-yyyy')  FROM " & strmsttab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strfrmdt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing

                strintcaltemptab = strmodcd & "INTCALTEMP"
                strsql = "SELECT TO_CHAR(INTCALTODT,'dd-Mon-yyyy')  FROM " & strintcaltemptab & " WHERE accno =  '" & straccno & "' and glcode = '" & strglcd & "' and branchcode = '" & strbrcd & "' and currencycode = '" & strcurcd & "'"
                objcommand = New OracleClient.OracleCommand(strsql, ObjOracleConnection)
                drremarks = objcommand.ExecuteReader
                If drremarks.Read Then
                    If IsDBNull(drremarks(0)) = False Then
                        strtodt = drremarks(0)
                    Else
                        Throw New Exception("")
                    End If
                End If

                drremarks.Close()
                drremarks = Nothing
                objcommand.Dispose()
                objcommand = Nothing
                ObjOracleConnection.Dispose()
                ObjOracleConnection = Nothing
                GetRemarks = "INT From " & strfrmdt & " To " & strtodt

                Exit Function

            End If

        Catch ex As Exception

        End Try
    End Function

End Class
