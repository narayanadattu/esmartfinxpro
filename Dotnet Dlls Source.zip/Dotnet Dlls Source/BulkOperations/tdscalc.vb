Public Class tdscalc
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String
    Dim drcustamt As OracleClient.OracleDataReader
    Dim strQuery As String
    Dim strmsttable As String
    Dim strcustid As String
    Dim dblamt As Double

    Dim strcrmod As String
    Dim strcrglcd As String
    Dim strcraccno As String
    Dim drtdsrates As OracleClient.OracleDataReader
    Dim objDBConnection1 As New DatabaseConnection.cDBConnection
    Dim gObjOracleConnection1 As New OracleClient.OracleConnection

    Public Function TDSCalc(ByVal BRCode As String, _
              ByVal CURCode As String, ByVal frmfinyr As Date, ByVal tofinyr As Date, _
              ByVal arrVals(,) As Object, _
              ByVal ApplicationDate As Date, ByVal UserId As String, _
              ByVal MachineId As String, ByVal strmode As String) As String

        'Desc: This is used to Calculate TDS
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code

        'ArrVals(Idx,0) = Includes customer ids for tds calculation and every customerid number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,1) = Includes glcodes for tds calculation and every glcodes
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,2) = Includes Account Numbers for tds calculation and every a/c number
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,3) = Includes Names of the Account holders respectively and these
        '                 are separated by "," (Comma Symbol)
        'ArrVals(Idx,4) = Includes tds to be applied of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)
        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TDSCalc = "Transaction Successfull"
        '   else
        '     TDSCalc = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection


        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand

        Dim sQuery, strAccNos, dtResult As String
        Dim iNoOfRows As Long
        Dim expectedRowCnt, delRowCnt As Integer
        Dim accountArr As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String



        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames, strAcctds As String
        Dim strCustid, strGlcds As String
        Dim CustidArr, GlcdsArr, NamesArr, tdsArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            '''' STEP 1: Get DataBase Connection
            gObjOracleConnection1 = objDBConnection1.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                              " DataBase. Reason Is " & o_Errmsg)
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strCustid = arrVals(0, 0)
            strGlcds = arrVals(1, 0)
            strAccNos = arrVals(2, 0)
            strAccNames = arrVals(3, 0)
            strAcctds = arrVals(4, 0)


            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.
            CustidArr = Split(strCustid, ",")
            GlcdsArr = Split(strGlcds, ",")
            accountArr = Split(strAccNos, ",")
            NamesArr = Split(strAccNames, ",")
            tdsArr = Split(strAcctds, ",")


            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt

                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strAccNames = NamesArr(iAdx)
                            strAcctds = tdsArr(iAdx)
                        Else
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strAccNames = strAccNames & "," & NamesArr(iAdx)
                            strAcctds = strAcctds & "," & tdsArr(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String
                arrVals(0, 0) = strCustid
                arrVals(1, 0) = strGlcds
                arrVals(2, 0) = strAccNos
                arrVals(3, 0) = strAccNames
                arrVals(4, 0) = strAcctds

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 1 : Do TDS calculations to debit Operative GL A/c's and 
                '             Credit Gl A/C's

                opResult = doTDSCalculations(BRCode, CURCode, frmfinyr, tofinyr, _
                           arrVals, ApplicationDate, UserId, _
                           MachineId, gObjOracleConnection, objTransaction, _
                           returnBatchNo, rtnFromTranno, rtnToTranno, strmode)

                If opResult = False Then

                    Throw New Exception("Error While doing TDS Calculation" & _
                        " to Debit  GL A/C's and Credit GL A/C's")
                End If



                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False
            gObjOracleConnection1.Close()
            gObjOracleConnection1 = Nothing

            TDSCalc = "Transaction Successful" & " Batch No.(s)  " & returnBatchNo

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                TDSCalc = ex.Message
                Exit Function
            Else

                strComponent = "BULKOPERATIONS.TDSCALCULATIONS / TDSCALC"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    TDSCalc = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    TDSCalc = clntDesc
                End If
                Exit Function
            End If

        End Try
    End Function



    Private Function doTDSCalculations(ByVal i_BRcode As String, _
          ByVal i_CURCode As String, ByVal frmfinyr As Date, _
          ByVal tofinyr As Date, _
          ByVal arrOPData(,) As Object, ByVal ApplicationDate As Date, _
          ByVal UserId As String, ByVal MachineId As String, _
          ByRef gObjOracleConnection As OracleClient.OracleConnection, _
          ByRef objTransaction As OracleClient.OracleTransaction, _
          ByRef o_BatchNo As String, ByRef o_FromTranNo As String, _
          ByRef o_ToTranNo As String, ByVal strmode As String) As Boolean
        Dim strremarks As String
        Dim strtrnstatus As String
        ' This Function is used for Financial Transaction while Doing  
        ' TDS Calculation
        'INPUTS :
        'i_BRcode = Branch Code in which a/c's are existed
        'i_CURCode= Currency Code
        'i_ModId = Module Id; Generally it will be wether 'SB' or 'CA' or 'DEP' modules
        'i_DrGLCOde =  
        'i_CrGLCode =  
        'arrOPData(Idx,0) = Includes Customerid for tds calculation and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,1) = Includes glcodes of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'arrOPData(Idx,2) = Includes Account Numbers for tds calculation and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,3) = Includes Names of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'arrOPData(Idx,4) = Includes Current Balances of the Account holders 
        '                 respectively and these are separated by "," (Comma Symbol)

        'ApplicationDate= Current Date of Application
        'UserId = Login UserId
        'MachineId= Login MachineId
        'gObjOracleConnection = Connection Object
        'objTransaction = Transaction Object


        Dim objdbconnection = New DatabaseConnection.cDBConnection

        Dim genTransDrQry, sbtranDrQuery, genTransCrQry, sbtranCrQuery, i_Batchno, i_Tranno, FrmTranNo, FromTranNo As String
        Dim arrCustid, arrGlcds, arrAccNo, arrAccName, arrAccCustId, arrAccBal As Object
        Dim objCommand As OracleClient.OracleCommand
        Dim Idx As Long
        Dim genDrNoOfRows, sbTranDrNoOfRows, genCrNoOfRows, sbTranCrNoOfRows, tdsDtlsNoOfRows, depintaccrdtlsRows As Short
        Dim strtdsdtls, depintaccrQuery As String
        Dim strModid As String
        Dim strintcompyn As String
        Dim strcompintaccrrevyn As String
        Dim strintaccrglcd, strintaccraccno As String
        Dim strmiscname As String
        Dim straccrname As String
        Dim effecdate As Date
        Dim frmdate As Date
        'Dim GenTran As GeneralTranQueriesRCW.TransactionQueriesClass
        'GenTran = New GeneralTranQueriesRCW.TransactionQueriesClass
        'i_Batchno = GenTran.GetBatchno(i_BRcode)
        i_Batchno = objdbconnection.GetBatchno(i_BRcode)

        Try
            arrCustid = CStr(arrOPData(0, 0)).Split(",")
            arrGlcds = CStr(arrOPData(1, 0)).Split(",")
            arrAccNo = CStr(arrOPData(2, 0)).Split(",")
            arrAccName = CStr(arrOPData(3, 0)).Split(",")
            arrAccBal = CStr(arrOPData(4, 0)).Split(",")

            doTDSCalculations = False

            strtrnstatus = ""
            If strmode = "All" Then
                strtrnstatus = "A"
            Else
                strtrnstatus = "P"
            End If

            For Idx = 0 To UBound(arrAccNo)
                i_Tranno = objdbconnection.GetTranNo(i_BRcode)
                If Idx = 0 Then
                    FromTranNo = i_Tranno
                Else
                    i_Tranno = i_Tranno
                End If

                strQuery = ""
                strQuery = "SELECT moduleid FROM genglmastmst WHERE glcode = " & arrGlcds(Idx) & ""
                objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)

                drcustamt = objCommand.ExecuteReader

                If drcustamt.HasRows = True Then
                    If drcustamt.Read Then
                        strModid = drcustamt!moduleid
                    End If
                Else
                    strModid = ""
                End If

                objCommand.Dispose()
                objCommand = Nothing
                drcustamt.Close()
                drcustamt = Nothing



                '' DEP Moduleid
                If strModid = "DEP" Or strModid = "SB" Then

                    strcrmod = ""
                    strcrglcd = ""
                    strcraccno = ""
                    strmiscname = ""
                    strQuery = ""

                    strQuery = "SELECT DISTINCT CREDITMODULEID, CREDITGLCODE, CREDITACCNO,(select distinct name from miscmst where branchcode = '" & i_BRcode & "' AND glcode =  r.CREDITGLCODE and accno = r.CREDITACCNO) miscname FROM TDSRATES r , " & strModid & "MST m  " & _
                    " WHERE r.glcode  = m.glcode AND (r.category = m.categorycode OR r.category = 99 ) " & _
                    " AND  r.moduleid = '" & strModid & "' AND r.glcode = " & arrGlcds(Idx) & " AND " & _
                    " m.branchcode = '" & i_BRcode & "' AND m.currencycode = '" & i_CURCode & "' AND r.effectivedate " & _
                    " = (SELECT MAX(r.effectivedate) FROM TDSRATES r ," & strModid & "MST m WHERE r.glcode  = m.glcode AND " & _
                    " (r.category = m.categorycode OR r.category = 99 AND " & _
                    " r.effectivedate <= '" & Format(ApplicationDate, "dd-MMM-yyyy") & "') AND  " & _
                    " r.moduleid = '" & strModid & "' AND " & _
                    " r.glcode = " & arrGlcds(Idx) & " AND  m.branchcode = '" & i_BRcode & "' AND m.currencycode " & _
                    " = '" & i_CURCode & "'  AND r.effectivedate <= '" & Format(ApplicationDate, "dd-MMM-yyyy") & "')"

                    objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                    drtdsrates = objCommand.ExecuteReader

                    If drtdsrates.HasRows = True Then
                        If drtdsrates.Read Then

                            strcrmod = IIf(IsDBNull(drtdsrates!CREDITMODULEID), "", drtdsrates!CREDITMODULEID)
                            strcrglcd = IIf(IsDBNull(drtdsrates!CREDITGLCODE), "", drtdsrates!CREDITGLCODE)
                            strcraccno = IIf(IsDBNull(drtdsrates!CREDITACCNO), "", drtdsrates!CREDITACCNO)
                            strmiscname = IIf(IsDBNull(drtdsrates!miscname), "", drtdsrates!miscname)
                        End If
                    Else
                        doTDSCalculations = "Parameters Not Set For This Gl Code And Module ID"
                        Exit Function
                    End If

                    objCommand.Dispose()
                    objCommand = Nothing
                    drtdsrates.Close()
                    drtdsrates = Nothing

                    '' start to get from date 
                    If strModid = "DEP" Then
                        strQuery = ""
                        strQuery = "SELECT EFFDATE FROM depmst m WHERE " & _
                        " branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  " & _
                        " glcode = " & arrGlcds(Idx) & " AND accno = " & arrAccNo(Idx) & ""

                        objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)
                        drcustamt = objCommand.ExecuteReader
                        If drcustamt.HasRows = True Then
                            If drcustamt.Read Then
                                effecdate = drcustamt!EFFDATE
                            End If
                        End If
                        objCommand.Dispose()
                        objCommand = Nothing
                        drcustamt.Close()
                        drcustamt = Nothing

                        If CDate(effecdate) < CDate(frmfinyr) Then
                            frmdate = frmfinyr
                        ElseIf CDate(effecdate) >= CDate(frmfinyr) And effecdate <= tofinyr Then
                            frmdate = effecdate
                        End If
                    End If '' strModid = "DEP" 
                    If strModid = "SB" Then
                        frmdate = frmfinyr
                    End If ''strModid = "SB"
                    '' end to get from date 

                    '' start deptypemst
                    If strModid = "DEP" Then
                        strQuery = ""
                        strintaccrglcd = ""
                        strintaccraccno = ""
                        strintcompyn = ""
                        strcompintaccrrevyn = ""
                        straccrname = ""
                        strQuery = "SELECT GLCODE, NARRATION, INTCOMPOUNDYN, INTACCRUEDGLCODE, INTACCRUEDACCNO, COMPINTACCRREVSEYN,(select distinct name from miscmst where glcode =  INTACCRUEDGLCODE and accno = INTACCRUEDACCNO) miscname FROM deptypemst WHERE glcode =  " & arrGlcds(Idx) & ""
                        objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)

                        drcustamt = objCommand.ExecuteReader

                        If drcustamt.HasRows = True Then
                            If drcustamt.Read Then
                                strintaccrglcd = IIf(IsDBNull(drcustamt!INTACCRUEDGLCODE), "", drcustamt!INTACCRUEDGLCODE)
                                strintaccraccno = IIf(IsDBNull(drcustamt!INTACCRUEDACCNO), "", drcustamt!INTACCRUEDACCNO)
                                strintcompyn = IIf(IsDBNull(drcustamt!INTCOMPOUNDYN), "", drcustamt!INTCOMPOUNDYN)
                                strcompintaccrrevyn = IIf(IsDBNull(drcustamt!COMPINTACCRREVSEYN), "", drcustamt!COMPINTACCRREVSEYN)
                                straccrname = IIf(IsDBNull(drcustamt!miscname), "", drcustamt!miscname)
                            End If
                        Else
                            strintaccrglcd = ""
                            strintaccraccno = ""
                            strintcompyn = ""
                            strcompintaccrrevyn = ""
                            straccrname = ""
                        End If

                        objCommand.Dispose()
                        objCommand = Nothing
                        drcustamt.Close()
                        drcustamt = Nothing

                    End If ''strModid = "DEP"

                    '' end deptypemst

                    strmsttable = strModid & "MST"
                    strQuery = ""
                    strQuery = "SELECT customerid,GETANYDAYBAL(BRANCHCODE, CURRENCYCODE,'" & strModid & "', GLCODE " & _
                    ", ACCNO,'" & Format(ApplicationDate, "dd-MMM-yyyy") & "') curbal  FROM " & strmsttable & " WHERE " & _
                    " branchcode = '" & i_BRcode & "' AND currencycode = '" & i_CURCode & "' AND  " & _
                    " glcode = " & arrGlcds(Idx) & " AND accno = " & arrAccNo(Idx) & ""


                    objCommand = New OracleClient.OracleCommand(strQuery, gObjOracleConnection1)

                    drcustamt = objCommand.ExecuteReader

                    If drcustamt.HasRows = True Then
                        While drcustamt.Read
                            strcustid = drcustamt!customerid
                            dblamt = drcustamt!curbal
                        End While
                    End If

                    objCommand.Dispose()
                    objCommand = Nothing
                    drcustamt.Close()
                    drcustamt = Nothing



                    If ((strModid = "DEP" And strintcompyn <> "N" And strcompintaccrrevyn = "N") Or (strModid = "SB")) Then

                        strremarks = "TDS From " & Format(frmfinyr, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")

                        'Debit A/C balance into Debit Gl Code WITH SAME A/C NUMBER
                        genTransDrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                              " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                             " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                             " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                             " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                             " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                             " '" & i_CURCode & "','" & strModid & "'," & _
                             " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                             " '" & i_Batchno & "','" & i_Tranno & "'," & _
                             " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                             " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                             " " & arrCustid(Idx) & "," & _
                             " " & arrAccName(Idx) & ",'N','Y','" & strremarks & "'," & _
                             " '1','N'," & _
                             " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                             " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                             " sysdate,'" & strcrmod & "'," & _
                           " '" & strcrglcd & "'," & strcraccno & ")"


                        sbtranDrQuery = "insert into " & strModid & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                          " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                          " SYSTEMGENERATEDYN," & _
                          " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                          " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                          " '" & i_CURCode & "','" & strModid & "'," & _
                          "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                          " '" & i_Batchno & "','" & i_Tranno & "'," & _
                          " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " " & arrCustid(Idx) & "," & _
                          " " & arrAccName(Idx) & ",'N','Y','" & strremarks & "'," & _
                          " '1','N'," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','" & strcrmod & "'," & _
                           " '" & strcrglcd & "'," & strcraccno & ")"



                        strtdsdtls = "insert into tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME, BATCHNO, " & _
                        " TRANNO, AMOUNT,MODEOFTRAN, FROMDATE, TODATE, USERID, MACHINEID,applicationdate,SYSTEMDATE,TRANSTATUS, STATUS, " & _
                        " REMARKS, LNKMODULEID, LNKGLCODE, LNKACCNO,customerid) values('" & i_BRcode & "'," & _
                            " '" & i_CURCode & "','" & strModid & "'," & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                            " " & arrAccName(Idx) & ",'" & i_Batchno & "','" & i_Tranno & "'," & _
                            " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3','" & Format(frmdate, "dd-MMM-yyyy") & "','" & _
                            " " & Format(tofinyr, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                            "'" & MachineId & "','" & Format(ApplicationDate, "dd-MMM-yyyy") & "',sysdate,'A','R','" & strremarks & "','" & strcrmod & "'," & _
                           "'" & strcrglcd & "'," & strcraccno & " ," & arrCustid(Idx) & ")"

                        i_Tranno = objdbconnection.GetTranNo(i_BRcode)

                        'CREDIT A/C BALANCE INTO CREDIT GL CODE WITH SAME A/C NUMBER


                        genTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                            " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                           " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                           " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                           " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                           " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                           " '" & i_CURCode & "','" & strcrmod & "'," & _
                           " '" & strcrglcd & "'," & strcraccno & "," & _
                           " '" & i_Batchno & "','" & i_Tranno & "'," & _
                           " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                           " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                           " '','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                           " '1','N'," & _
                           " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                           " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                           " sysdate,'" & strModid & "'," & _
                           "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                        sbtranCrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                          " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                          " SYSTEMGENERATEDYN," & _
                          " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                          " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                          " '" & i_CURCode & "','" & strcrmod & "'," & _
                          " '" & strcrglcd & "'," & strcraccno & "," & _
                          " '" & i_Batchno & "','" & i_Tranno & "'," & _
                          " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                          " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                          " '1','N','" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                          " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','" & strModid & "'," & _
                           " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                        objCommand = New OracleClient.OracleCommand(genTransDrQry, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        genDrNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(sbtranDrQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        sbTranDrNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(genTransCrQry, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        genCrNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        objCommand = New OracleClient.OracleCommand(sbtranCrQuery, gObjOracleConnection)
                        objCommand.Transaction = objTransaction
                        sbTranCrNoOfRows = objCommand.ExecuteNonQuery()

                        objCommand.Dispose()
                        objCommand = Nothing

                        If genDrNoOfRows <> 1 Or sbTranDrNoOfRows <> 1 Or tdsDtlsNoOfRows <> 1 Or _
                 genCrNoOfRows <> 1 Or sbTranCrNoOfRows <> 1 Then
                            Throw New Exception("Error ! : while doing TDS Calculations")
                        End If

                    End If  ''((strModid = "DEP" And strintcompyn <> "N" And strcompintaccrrevyn = "N") Or (strModid = "SB"))

                End If ''strModid = "DEP" or strModid = "SB"

                If (strModid = "DEP") And ((strintcompyn <> "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "N")) Then

                    strremarks = "TDS From " & Format(frmfinyr, "dd-MMM-yyyy") & " To " & Format(tofinyr, "dd-MMM-yyyy")

                    'Debit A/C balance into Debit Gl Code WITH SAME A/C NUMBER
                    genTransDrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                          " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                         " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                         " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                         " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                         " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                         " '" & i_CURCode & "','" & strcrmod & "'," & _
                         " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                         " '" & i_Batchno & "','" & i_Tranno & "'," & _
                         " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                         " '1','N'," & _
                         " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                         " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                         " sysdate,'" & strModid & "'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                    sbtranDrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','" & strcrmod & "'," & _
                      " '" & strintaccrglcd & "'," & strintaccraccno & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & straccrname & "','N','Y','" & strremarks & "'," & _
                      " '1','N'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','" & strModid & "'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                  
                    strtdsdtls = "insert into tdsdtls(BRANCHCODE, CURRENCYCODE, MODULEID,GLCODE, ACCNO, NAME, BATCHNO, " & _
                    " TRANNO, AMOUNT,MODEOFTRAN, FROMDATE, TODATE, USERID, MACHINEID,applicationdate,SYSTEMDATE,TRANSTATUS, STATUS, " & _
                    " REMARKS, LNKMODULEID, LNKGLCODE, LNKACCNO,customerid) values('" & i_BRcode & "'," & _
                        " '" & i_CURCode & "','" & strModid & "'," & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & _
                        " " & arrAccName(Idx) & ",'" & i_Batchno & "','" & i_Tranno & "'," & _
                        " " & -1 * Math.Round(CDbl(arrAccBal(Idx))) & ",'3','" & Format(frmdate, "dd-MMM-yyyy") & "','" & _
                        " " & Format(tofinyr, "dd-MMM-yyyy") & "','" & UserId & "'," & _
                        "'" & MachineId & "','" & Format(ApplicationDate, "dd-MMM-yyyy") & "',sysdate,'A','R','" & strremarks & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & " ," & arrCustid(Idx) & ")"

                    '' depintaccrueddtls


                    depintaccrQuery = "insert into DEPINTACCRUEDDTLS(BRANCHCODE, CURRENCYCODE, MODULEID, GLCODE, ACCNO, INTAMOUNT," & _
            "BATCHNO, TRANNO,APPLICATIONDATE, USERID, MACHINEID, TRANSTATUS, SYSTEMDATE," & _
            "SYSTEMYEAR, INTACCRMODULEID, INTACCRGLCODE, INTACCRACCNO" & _
            ",PAIDBATCHNO, PAIDTRANNO, TRANSFERTODEP,REMARKS,LNKMODULEID, LNKGLCODE, LNKACCNO) values('" & i_BRcode & "'," & _
                      "'" & i_CURCode & "','" & strModid & "'," & _
                      "" & arrGlcds(Idx) & "," & arrAccNo(Idx) & "," & -1 * Math.Round(CDbl(arrAccBal(Idx))) & "," & _
                      "'" & i_Batchno & "','" & i_Tranno & "'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "',sysdate, to_char(sysdate,'yyyy')," & _
                      "'" & strcrmod & "','" & strintaccrglcd & "'," & strintaccraccno & "," & _
                      "'" & i_Batchno & "','" & i_Tranno & "'," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','" & strremarks & "'," & _
                      "'" & strcrmod & "','" & strcrglcd & "'," & strcraccno & ")"


                    i_Tranno = objdbconnection.GetTranNo(i_BRcode)

                    'CREDIT A/C BALANCE INTO CREDIT GL CODE WITH SAME A/C NUMBER

                    genTransCrQry = "insert into GENTRANSLOG(BRANCHCODE,CURRENCYCODE," & _
                        " MODULEID,GLCODE,ACCNO,BATCHNO,TRANNO,AMOUNT,MODEOFTRAN," & _
                       " ENTEREDTIMEBAL,EFFECTIVEDATE, CUSTOMERID, NAME,CASHPAIDYN," & _
                       " SYSTEMGENERATEDYN,REMARKS, SERVICEID,EXCEPTIONYN," & _
                       " APPLICATIONDATE,USERID,MACHINEID,TRANSTATUS," & _
                       " SYSTEMDATE,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                       " '" & i_CURCode & "','" & strcrmod & "'," & _
                       " '" & strcrglcd & "'," & strcraccno & "," & _
                       " '" & i_Batchno & "','" & i_Tranno & "'," & _
                       " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                       " '1','N'," & _
                       " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                       " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "'," & _
                       " sysdate,'" & strModid & "'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"


                    sbtranCrQuery = "insert into " & strcrmod & "TRANDAY(BRANCHCODE,CURRENCYCODE," & _
                      " MODULEID, GLCODE, ACCNO, BATCHNO, TRANNO, AMOUNT, MODEOFTRAN," & _
                      " ENTEREDTIMEBAL,EFFECTIVEDATE,CUSTOMERID, NAME,CASHPAIDYN," & _
                      " SYSTEMGENERATEDYN," & _
                      " REMARKS,SERVICEID,EXCEPTIONYN,APPLICATIONDATE, USERID," & _
                      " MACHINEID, TRANSTATUS,LINKMODULEID, LINKGLCODE, LINKACCNO) values('" & i_BRcode & "'," & _
                      " '" & i_CURCode & "','" & strcrmod & "'," & _
                      " '" & strcrglcd & "'," & strcraccno & "," & _
                      " '" & i_Batchno & "','" & i_Tranno & "'," & _
                      " " & Math.Round(CDbl(arrAccBal(Idx))) & ",'4'," & dblamt & "," & _
                      " '" & Format(ApplicationDate, "dd-MMM-yyyy") & "','','" & strmiscname & "','N','Y','" & strremarks & "'," & _
                      " '1','N','" & Format(ApplicationDate, "dd-MMM-yyyy") & "'," & _
                      " '" & UserId & "','" & MachineId & "','" & strtrnstatus & "','" & strModid & "'," & _
                       " " & arrGlcds(Idx) & "," & arrAccNo(Idx) & ")"

                    objCommand = New OracleClient.OracleCommand(genTransDrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranDrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranDrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(depintaccrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    depintaccrdtlsRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(genTransCrQry, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    genCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    objCommand = New OracleClient.OracleCommand(sbtranCrQuery, gObjOracleConnection)
                    objCommand.Transaction = objTransaction
                    sbTranCrNoOfRows = objCommand.ExecuteNonQuery()

                    objCommand.Dispose()
                    objCommand = Nothing

                    If genDrNoOfRows <> 1 Or sbTranDrNoOfRows <> 1 Or tdsDtlsNoOfRows <> 1 Or _
            depintaccrdtlsRows <> 1 Or genCrNoOfRows <> 1 Or sbTranCrNoOfRows <> 1 Then
                        Throw New Exception("Error ! : while doing TDS Calculations")
                    End If


                End If ''(strModid = "DEP") And ((strintcompyn <> "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "Y") Or (strintcompyn = "N" And strcompintaccrrevyn = "N"))



                doTDSCalculations = True

            Next
            'o_BatchNo = i_Batchno
            If oBatchNo = "" Then
                oBatchNo = i_Batchno
            Else
                oBatchNo = oBatchNo & " , " & i_Batchno
            End If

            o_BatchNo = oBatchNo
            o_FromTranNo = FromTranNo
            o_ToTranNo = i_Tranno
        Catch ex As Exception
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.TDSCALCULATIONS" & _
                               " / doTDSCalculations"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations Due to " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

            Else
                errNum = "doTDSCalc"
                errDesc = ex.Message
                clntDesc = "Error ! while Doing TDS Calculations " & errDesc

            End If

            Dim objError As New DatabaseConnection.ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
            clntDesc, o_Errmsg, strComponent, i_BRcode, UserId, MachineId)
            doTDSCalculations = False
        End Try
    End Function

End Class
