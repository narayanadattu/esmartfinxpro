Public Class tdschallanupd
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errResult As Boolean
    Dim errNum, errDesc, clntDesc, o_Errmsg As String
    Dim oBatchNo As String
    Dim drcustamt As OracleClient.OracleDataReader
    Dim strQuery As String
    Dim strmsttable As String
    Dim strcustid As String
    Dim dblamt As Double

    Dim strcrmod As String
    Dim strcrglcd As String
    Dim strcraccno As String
    Dim drtdsrates As OracleClient.OracleDataReader
    Dim objDBConnection1 As New DatabaseConnection.cDBConnection
    Dim gObjOracleConnection1 As New OracleClient.OracleConnection

    Public Function TDSChallanUpd(ByVal BRCode As String, _
           ByVal CURCode As String, _
           ByVal arrVals(,) As Object, _
           ByVal ApplicationDate As Date, ByVal strchallanno As String, ByVal dtchallandate As Date, ByVal UserId As String, ByVal MachineId As String, ByVal strbsrcode As String) As String

        'Desc: This is used to Calculate TDS
        'Inputs:
        'BRCode = Branch Code in which a/c's are existed
        'CURCode = Currency Code

        'ArrVals(Idx,0) = Includes app date for  TDS challan updation and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'ArrVals(Idx,1) = Includes Customerid for TDS challan updation and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'ArrVals(Idx,2) = Includes glcodes of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'ArrVals(Idx,3) = Includes Account Numbers for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)
        'ArrVals(Idx,4) = Includes batchno for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)
        'ArrVals(Idx,5) = Includes tranno for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)

        'ApplicationDate = Current Application Date
        'UserID = Login UserID
        'MachineId = Login MachineID
        'Outputs:
        '   If everything done successfully then 
        '     TDSChallanUpd = "Transaction Successfull"
        '   else
        '     TDSChallanUpd = error message description

        Dim bConnOpened, bTransBegin, bIncrement As Boolean
        Dim objDBConnection As New DatabaseConnection.cDBConnection
        Dim gObjOracleConnection As New OracleClient.OracleConnection


        Dim objTransaction As OracleClient.OracleTransaction
        Dim objcommand As OracleClient.OracleCommand

        Dim sQuery, strAccNos, dtResult As String
        Dim strbatchno, strtranno As String
        Dim iNoOfRows As Long
        Dim expectedRowCnt, delRowCnt As Integer
        Dim accountArr As Object
        Dim batchnoArr As Object
        Dim trannoArr As Object
        Dim returnBatchNo, rtnFromTranno, rtnToTranno As String
        Dim i, iAdx, iFromdx, iTodx, UBoundValue, IncrementVal, iCnt As Integer
        Dim strAccNames As String
        Dim strCustid, strGlcds As String
        Dim strappdate As String
        Dim appdateArr, CustidArr, GlcdsArr, NamesArr, tdsArr As Object
        bIncrement = False
        Try
            bConnOpened = False : bTransBegin = False
            If arrVals.GetUpperBound(0) < 0 Then
                'TransferOperativeToInoperative = "No Data Sent To Component"
                'Exit Function
                Throw New Exception("No Data Sent To Component")
            End If

            '''' STEP 1: Get DataBase Connection
            gObjOracleConnection1 = objDBConnection1.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                              " DataBase. Reason Is " & o_Errmsg)
            End If

            ''' Assigning the string of Account No.s  to strAccNos
            strappdate = arrVals(0, 0)
            strCustid = arrVals(1, 0)
            strGlcds = arrVals(2, 0)
            strAccNos = arrVals(3, 0)
            strbatchno = arrVals(4, 0)
            strtranno = arrVals(5, 0)

            ''' Split the A/c.'s and put it into one array for the count of
            '' Given A/c. Nos.

            appdateArr = Split(strappdate, ",")
            CustidArr = Split(strCustid, ",")
            GlcdsArr = Split(strGlcds, ",")
            accountArr = Split(strAccNos, ",")
            batchnoArr = Split(strbatchno, ",")
            trannoArr = Split(strtranno, ",")

            iCnt = Math.Floor((UBound(accountArr) - 1) / 900)
            If UBound(accountArr) = 0 Then
                iCnt = 1
                bIncrement = True
            End If

            For i = 0 To iCnt

                '''' STEP 1: Get DataBase Connection
                gObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If Trim(o_Errmsg) <> "" Then
                    Throw New Exception("Connection Failed With" & _
                                  " DataBase. Reason Is " & o_Errmsg)
                End If
                bConnOpened = True
                If i = 0 And UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = 0 To 900
                        If strAccNos = "" Then
                            strappdate = appdateArr(iAdx)
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strbatchno = batchnoArr(iAdx)
                            strtranno = trannoArr(iAdx)
                        Else
                            strappdate = strappdate & "," & appdateArr(iAdx)
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strbatchno = strbatchno & "," & batchnoArr(iAdx)
                            strtranno = strtranno & "," & trannoArr(iAdx)
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                    'UBoundValue = 900
                ElseIf UBound(accountArr) > 900 Then
                    strAccNos = ""
                    UBoundValue = 0
                    For iAdx = iFromdx To iTodx
                        If strAccNos = "" Then
                            strappdate = appdateArr(iAdx)
                            strCustid = CustidArr(iAdx)
                            strGlcds = GlcdsArr(iAdx)
                            strAccNos = accountArr(iAdx)
                            strbatchno = batchnoArr(iAdx)
                            strtranno = trannoArr(iAdx)
                        Else
                            strappdate = strappdate & "," & appdateArr(iAdx)
                            strCustid = strCustid & "," & CustidArr(iAdx)
                            strGlcds = strGlcds & "," & GlcdsArr(iAdx)
                            strAccNos = strAccNos & "," & accountArr(iAdx)
                            strbatchno = strbatchno & "," & batchnoArr(iAdx)
                            strtranno = strtranno & "," & trannoArr(iAdx)
                        End If
                        If iAdx = UBound(accountArr) Then
                            UBoundValue = UBoundValue + 1
                            Exit For
                        End If
                        UBoundValue = UBoundValue + 1
                    Next
                End If
                IncrementVal = IncrementVal + UBoundValue

                iFromdx = IncrementVal
                If iFromdx + 900 >= UBound(accountArr) Then
                    iTodx = UBound(accountArr)
                Else
                    iTodx = iFromdx + 900
                End If

                Dim opResult As String

                arrVals(0, 0) = strappdate
                arrVals(1, 0) = strCustid
                arrVals(2, 0) = strGlcds
                arrVals(3, 0) = strAccNos
                arrVals(4, 0) = strbatchno
                arrVals(5, 0) = strtranno

                ''' STEP 4.1 :  Begin Database transaction
                objTransaction = gObjOracleConnection.BeginTransaction()
                bTransBegin = True

                ''' STEP 1 : Do TDS calculations to debit Operative GL A/c's and 
                '             Credit Gl A/C's

                opResult = doTDSChallanUpd(BRCode, CURCode, _
                           arrVals, ApplicationDate, strchallanno, dtchallandate, UserId, MachineId, gObjOracleConnection, objTransaction, strbsrcode)
                If opResult = False Then
                    Throw New Exception("Error While doing TDS Challan Update")
                End If

                objTransaction.Commit()
                bTransBegin = False
                gObjOracleConnection.Close()
                bConnOpened = False

                If bIncrement = True Then
                    Exit For
                End If
            Next

            bIncrement = False
            gObjOracleConnection1.Close()
            gObjOracleConnection1 = Nothing

            TDSChallanUpd = "Transaction Successful "

        Catch ex As Exception
            If bTransBegin = True Then
                objTransaction.Rollback()
            End If
            If bConnOpened = True Then
                gObjOracleConnection.Close()
            End If

            'If raised exception is because of an oracle error,
            ' then record about this error in database
            If UCase(Trim(Left(ex.Message, 3))) <> "ORA" Then
                TDSChallanUpd = ex.Message
                Exit Function
            Else

                strComponent = "BULKOPERATIONS.doTDSChallanUpd / TDSChallanUpd"
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations " & _
                    " Due to " & errDesc

                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

                Dim objError As New DatabaseConnection.ErrorDescription

                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BRCode, UserId, MachineId)
                If Trim(o_Errmsg).Length > 0 Then
                    o_Errmsg = Replace(o_Errmsg, Chr(10), " ")
                    o_Errmsg = Replace(o_Errmsg, Chr(13), " ")
                    TDSChallanUpd = o_Errmsg
                Else
                    clntDesc = Replace(clntDesc, Chr(10), " ")
                    clntDesc = Replace(clntDesc, Chr(13), " ")
                    TDSChallanUpd = clntDesc
                End If
                Exit Function
            End If

        End Try
    End Function


    Private Function doTDSChallanUpd(ByVal i_BRcode As String, _
            ByVal i_CURCode As String, _
            ByVal arrOPData(,) As Object, ByVal ApplicationDate As Date, _
            ByVal strchallanno As String, ByVal dtchallandate As Date, _
             ByVal UserId As String, ByVal MachineId As String, _
            ByRef gObjOracleConnection As OracleClient.OracleConnection, _
            ByRef objTransaction As OracleClient.OracleTransaction, ByVal strbsrcode As String) As Boolean
        Dim strremarks As String
        Dim strtrnstatus As String
        ' This Function is used for Financial Transaction while Doing  
        ' TDS challan updation
        'INPUTS :
        'i_BRcode = Branch Code in which a/c's are existed
        'i_CURCode= Currency Code
        'i_ModId = Module Id; Generally it will be wether 'SB' or 'CA' or 'DEP' modules
        'i_DrGLCOde =  
        'i_CrGLCode =  
        'arrOPData(Idx,0) = Includes app date for  TDS challan updation and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,1) = Includes Customerid for TDS challan updation and every Customerid number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,2) = Includes glcodes of the Account holders respectively and 
        '                   these are separated by "," (Comma Symbol)
        'arrOPData(Idx,3) = Includes Account Numbers for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,4) = Includes batchno for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)
        'arrOPData(Idx,5) = Includes tranno for TDS challan updation and every a/c number
        '                 is separated by "," (Comma Symbol)

        'ApplicationDate= Current Date of Application
        'UserId = Login UserId
        'MachineId= Login MachineId
        'gObjOracleConnection = Connection Object
        'objTransaction = Transaction Object


        Dim objdbconnection = New DatabaseConnection.cDBConnection

        Dim genTransDrQry, sbtranDrQuery, genTransCrQry, sbtranCrQuery, i_Batchno, i_Tranno, FrmTranNo, FromTranNo As String
        Dim arrappdate, arrCustid, arrGlcds, arrAccNo, arrbatchno, arrAccCustId, arrtranno As Object
        Dim objCommand As OracleClient.OracleCommand
        Dim Idx As Long
        Dim genDrNoOfRows, sbTranDrNoOfRows, genCrNoOfRows, sbTranCrNoOfRows, tdsDtlsNoOfRows, depintaccrdtlsRows As Short
        Dim strtdsdtls, depintaccrQuery As String
        Dim strModid As String
        Dim strintcompyn As String
        Dim strcompintaccrrevyn As String
        Dim strintaccrglcd, strintaccraccno As String
        Dim strmiscname As String
        Dim straccrname As String
        Dim effecdate As Date
        Dim frmdate As Date

        Try
            arrappdate = CStr(arrOPData(0, 0)).Split(",")
            arrCustid = CStr(arrOPData(1, 0)).Split(",")
            arrGlcds = CStr(arrOPData(2, 0)).Split(",")
            arrAccNo = CStr(arrOPData(3, 0)).Split(",")
            arrbatchno = CStr(arrOPData(4, 0)).Split(",")
            arrtranno = CStr(arrOPData(5, 0)).Split(",")

            doTDSChallanUpd = False

            strtrnstatus = ""

            For Idx = 0 To UBound(arrAccNo)

                strtdsdtls = ""
                strtdsdtls = "update tdsdtls set CHALLANNO  = '" & strchallanno & "', CHALLANDATE='" & Format(dtchallandate, "dd-MMM-yyyy") & "', bsrcode = '" & strbsrcode & "' where accno = " & arrAccNo(Idx) & " and glcode = " & arrGlcds(Idx) & " and customerid = " & arrCustid(Idx) & " and BATCHNO = " & arrbatchno(Idx) & " and  TRANNO = " & arrtranno(Idx) & " and APPLICATIONDATE = " & arrappdate(Idx) & "  and branchcode = '" & i_BRcode & "' and currencycode = '" & i_CURCode & "'"

                objCommand = New OracleClient.OracleCommand(strtdsdtls, gObjOracleConnection)
                objCommand.Transaction = objTransaction
                tdsDtlsNoOfRows = objCommand.ExecuteNonQuery()

                objCommand.Dispose()
                objCommand = Nothing

                doTDSChallanUpd = True
            Next


        Catch ex As Exception
            If strComponent = "" Then
                strComponent = "BULKOPERATIONS.doTDSChallanUpd" & _
                               " / doTDSChallanUpd"
            End If

            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while Doing TDS Calculations Due to " & errDesc
                arrErrSplit = Split(errDesc, "(")

                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                    & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If

            Else
                errNum = "doTDSCalc"
                errDesc = ex.Message
                clntDesc = "Error ! while Doing TDS Calculations " & errDesc

            End If

            Dim objError As New DatabaseConnection.ErrorDescription

            objError.ErrorProcess(errNum, errDesc, _
            clntDesc, o_Errmsg, strComponent, i_BRcode, UserId, MachineId)
            doTDSChallanUpd = False
        End Try
    End Function


End Class
