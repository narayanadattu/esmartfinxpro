Public Class Gengldaybook
    Dim objcmd As OracleClient.OracleCommand
    Dim sQuery As String
    Dim objconn As New OracleClient.OracleConnection
    Dim objDBConnection As New DatabaseConnection.cDBConnection
    Dim o_Errmsg As String
    Dim objtran As OracleClient.OracleTransaction
    Dim recgengldybk As OracleClient.OracleDataReader
    Dim strComponent As String
    Dim arrErrSplit As Object
    Dim errNum, errDesc, clntDesc, BranchCode, UserId, MachineId As String

Public Function Gengldaybookupd(ByVal strbrcode As String, ByVal strcurcode As String, ByVal strappdate As Date, ByVal UserId As String, ByVal MachineId As String) As Boolean
        Try

            If objconn.State <> ConnectionState.Open Then
                o_Errmsg = ""
                objconn = objDBConnection.GetDbConnection(o_Errmsg)
                If o_Errmsg <> "" Then
                    Throw New Exception(o_Errmsg)
                    Exit Function
                End If
            End If

            BranchCode = strbrcode
            UserId = UserId
            MachineId = MachineId
            objtran = objconn.BeginTransaction()
            objconn = objDBConnection.GetDbConnection(o_Errmsg)
            If Trim(o_Errmsg) <> "" Then
                Throw New Exception("Connection Failed With" & _
                                   " DataBase. Reason Is " & o_Errmsg)
            End If

            sQuery = "select DAYBEGINSTATUS, DAYENDSTATUS, HODAYBEGINSTATUS, HODAYENDSTATUS " & _
                     "FROM GENAPPLICATIONDATEMST WHERE branchcode = '" & BranchCode & "' AND " & _
                     "applicationdate ='" & Format(strappdate, "dd-MMM-yyyy") & "'"

            objcmd = New OracleClient.OracleCommand(sQuery, objconn)
            '     objcmd.Transaction = objtran
            recgengldybk = objcmd.ExecuteReader
            objcmd.Dispose()
            objcmd = Nothing
            If recgengldybk.HasRows Then
                recgengldybk.Read()

                If (recgengldybk!DAYBEGINSTATUS = "O" And recgengldybk!DAYENDSTATUS = "N" And recgengldybk!HODAYBEGINSTATUS = "O" And recgengldybk!HODAYENDSTATUS = "N") Or (recgengldybk!DAYBEGINSTATUS = "O" And recgengldybk!DAYENDSTATUS = "O" And recgengldybk!HODAYBEGINSTATUS = "O" And recgengldybk!HODAYENDSTATUS = "N") Then
                    objtran = objconn.BeginTransaction()
                    sQuery = "delete from gengldaybook WHERE branchcode = '" & BranchCode & "' AND " & _
                     "applicationdate ='" & Format(strappdate, "dd-MMM-yyyy") & "'"

                    objcmd = New OracleClient.OracleCommand(sQuery, objconn)
                    objcmd.Transaction = objtran
                    recgengldybk = objcmd.ExecuteReader
                    objcmd.Dispose()
                    objcmd = Nothing
                    recgengldybk.Dispose()
                    recgengldybk.Close()


                    objcmd = New OracleClient.OracleCommand(sQuery, objconn)
                    objcmd.Transaction = objtran
                    recgengldybk = objcmd.ExecuteReader
                    objcmd.Dispose()
                    objcmd = Nothing

                    HODayEnd(strbrcode, strcurcode, strappdate)
                    objtran.Commit()
                    o_Errmsg = "Transaction Successful."

                End If
            End If
            Gengldaybookupd = True
            Exit Function
        Catch ex As Exception
            Gengldaybookupd = False
            objtran.Rollback()

            If strComponent = "" Then
                strComponent = "Gengldaybookupd.Gengldaybook" & _
                               " / Gengldaybook "
            End If
            If UCase(Trim(Left(ex.Message, 3))) = "ORA" Then
                errNum = UCase(Mid(Trim(ex.Message), 1, InStr(1, ex.Message, ":")))
                errDesc = UCase(Mid(Trim(ex.Message), InStr(1, ex.Message, ":")))
                clntDesc = "Error ! while doing SBCA Minimum Balance Posting" & errDesc
                arrErrSplit = Split(errDesc, "(")
                If UBound(arrErrSplit) > 0 Then
                    errDesc = UCase(arrErrSplit(0)) & " " _
                & UCase(Mid(Trim(arrErrSplit(1)), InStr(1, arrErrSplit(1), ")") + 1))
                End If
                Dim objError As New DatabaseConnection.ErrorDescription
                objError.ErrorProcess(errNum, errDesc, _
                 clntDesc, o_Errmsg, strComponent, BranchCode, UserId, MachineId)
                o_Errmsg = clntDesc
            Else
                clntDesc = "Error ! while doing GENGLDAYBOOK Posting"
                o_Errmsg = clntDesc & " " & ex.Message
            End If
        End Try
    End Function

    Private Function HODayEnd(ByVal BranchCode As String, ByVal CurrencyCode As String, ByVal ApplicationDate As Date)

        ''''''''''''''' to prepare Day Book at current date
        Try
            ''''''' Variables Declaration
            Dim appDate As Date
            Dim BrCode As String
            Dim CRCode As String
            Dim StrString As String

            Dim strAppDate As String

            Dim StrTabName, strflds, qryflds, qrytable, qrycondition, strQuery, StrInsert, StrCondition, StrDelete As String
            Dim recSupplement As OracleClient.OracleDataReader

            '''''' Reading parameters
            appDate = ApplicationDate
            BrCode = BranchCode
            CRCode = CurrencyCode
            strAppDate = CStr(Format(CDate(appDate), "dd-MMM-yyyy"))
            ''''' Setting variable values

            ''''' Temp Table name
            StrTabName = "RepSupplementaryTemp"

            ''''' Field names to temp table
            strflds = "BRANCHCODE,BRANCHNARRATION,CURRENCYCODE,CURRENCYNARRATION," & _
                        "MODULEID,GLCODE,GLNarration,ACCNO,NAME,TRANNO,DRCASH,DRTRAN,DRCLG," & _
                        "CRCASH,CRTRAN,CRCLG,APPLICATIONDATE,REPNO,USERID"

            ''''''' Query fields
            qryflds = " a.branchcode,x.narration,a.currencycode,y.narration," & _
                    "a.moduleid,a.glcode,z.narration,a.accno,a.name," & _
                    "a.tranno, decode(a.modeoftran,'1',b.amount,null) DRCASH ," & _
                    "decode(a.modeoftran,'3',b.amount,null) DRTRAN ," & _
                    "decode(a.modeoftran,'5',b.amount,null) DRCLG ," & _
                    "decode(a.modeoftran,'2',b.amount,null) CRCASH , " & _
                    "decode(a.modeoftran,'4',b.amount,null) CRTRAN ," & _
                    "decode(a.modeoftran,'6',b.amount,null) CRCLG,'" & strAppDate & "',999,'VINOD'"

            ''''' Query Tables
            qrytable = "GenTransLog a,GenTransLog b,GenBankBranchMst x,GenCurrencyTypeMst y," & _
                        "GenGlSheetMst z"

            '''''' Query condition
            qrycondition = "a.branchcode = b.branchcode And a.currencycode = b.currencycode " & _
                        " and a.branchcode='" & BrCode & "' and a.currencycode='" & CRCode & "'" & _
                        " and a.applicationdate='" & strAppDate & "' AND a.applicationdate=" & _
                        "B.applicationdate AND a.transtatus='A' and b.transtatus='A' " & _
                        " and a.modeoftran=b.modeoftran and a.tranno=b.tranno and a.batchno=" & _
                        " b.batchno and a.branchcode=x.branchcode and b.branchcode=x.branchcode " & _
                        " and a.currencycode=y.currencycode and b.currencycode=y.currencycode " & _
                        " and upper(a.glcode)=upper(z.glcode) and upper(b.glcode)=upper(z.glcode) " & _
                        " and z.branchcode=x.branchcode order by a.glcode,a.accno,a.batchno,a.modeoftran"


            strQuery = "   Select " & qryflds & "  from " & qrytable & " where " & qrycondition


            StrInsert = "Insert into " & StrTabName & "( " & strflds & ") " & strQuery


            ''''''' Insert into Supplementary Temp
            objcmd = New OracleClient.OracleCommand(StrInsert, objconn)
            objcmd.Transaction = objtran
            objcmd.ExecuteNonQuery()
            objcmd.Dispose()
            objcmd = Nothing

            ''''' GenGLDayBokk Table columns
            strflds = "Branchcode,CurrencyCode,Moduleid,GLcode,GLNarration,Total1,Total3,Total5,GTotal1," & _
                  "Total2,Total4,Total6,GTotal2,Effect"

            ''''' Query columns of GenSupplementaryTemp
            ''''' It includes dr grand total and cr grand total
            qryflds = "branchcode,currencycode,Moduleid,Glcode,GLNarration," & _
                   "nvl(sum(drcash),0),nvl(sum(drtran),0),nvl(sum(drclg),0)," & _
                   "nvl(sum(drcash),0)+nvl(sum(drtran),0)+" & _
                   "nvl(sum(drclg),0)," & _
                   "nvl(sum(crcash),0),nvl(sum(crtran),0),nvl(sum(crclg),0)," & _
                   "nvl(sum(crcash),0)+nvl(sum(crtran),0)+nvl(sum(crclg),0)," & _
                   "(nvl(sum(drcash),0)+nvl(sum(drtran),0)+nvl(sum(drclg),0))+" & _
                   "(nvl(sum(crcash),0)+nvl(sum(crtran),0)+nvl(sum(crclg),0))"

            ''''' Query table name
            qrytable = "RepSupplementaryTemp"

            ''''' Query condition
            ''''' This is a constant condition based on which the inserted records will
            ''''' be queried and deleted after insertion
            qrycondition = "repno=999 and upper(userid)='VINOD' " & _
                        "group by branchcode,moduleid,glcode,currencycode,glnarration"

            strQuery = "Select " & qryflds & ",'" & strAppDate & "'  from " & qrytable & " where " & qrycondition

            ''if no row is available in GenGLDayBook then insert or update the existing row kishroe
            StrInsert = "Insert into GenGLDayBook( " & strflds & ",Applicationdate ) " & strQuery



            objcmd = New OracleClient.OracleCommand(StrInsert, objconn)
            objcmd.Transaction = objtran
            objcmd.ExecuteNonQuery()
            objcmd.Dispose()
            objcmd = Nothing

            '''' Insert abb entry to gengldaybook
            Dim strSqlQuery As String
            Dim dBlABBAmount As String
            Dim errmsg As String
            Dim objDr As OracleClient.OracleDataReader
           
            dBlABBAmount = 0
            strSqlQuery = "SELECT SUM(AMOUNT) TOTAL FROM GENTRANSLOG WHERE applicationdate=" & _
                          "'" & strAppDate & "' AND BRANCHCODE='" & BrCode & "' AND " & _
                          "ABBYN='Y' AND TRANSTATUS='A'"
            objcmd = New OracleClient.OracleCommand(strSqlQuery, objconn)
            objcmd.Transaction = objtran
            objDr = objcmd.ExecuteReader()
            If (objDr.HasRows) Then
                While (objDr.Read())
                    dBlABBAmount = -CDbl(IIf(IsDBNull(objDr!TOTAL), 0, objDr!TOTAL))
                End While
            End If
            objcmd.Dispose()
            objcmd = Nothing
            'dBlABBAmount = CDbl(recgengldybk!TOTAL)

            Dim strInsertABB As String

            If dBlABBAmount > 0 Then
                strInsertABB = "INSERT INTO GENGLDAYBOOK (BRANCHCODE, CURRENCYCODE, MODULEID, " & _
                               "GLCODE, GLNARRATION, TOTAL1, TOTAL2, TOTAL3, TOTAL4, TOTAL5, " & _
                               "TOTAL6, GTOTAL1, GTOTAL2, EFFECT, CLOSINGBALANCE, OPENINGBALANCE, " & _
                               "APPLICATIONDATE)VALUES('" & BrCode & "','" & CRCode & "','ABB'," & _
                               "'111111','ABB RECONCILIATION ACCOUNT',0,0,0," & dBlABBAmount & ",0," & _
                               "0,0," & dBlABBAmount & "," & dBlABBAmount & ",0,0,'" & strAppDate & "')"
            Else
                strInsertABB = "INSERT INTO GENGLDAYBOOK (BRANCHCODE, CURRENCYCODE, MODULEID, " & _
                               "GLCODE, GLNARRATION, TOTAL1, TOTAL2, TOTAL3, TOTAL4, TOTAL5, " & _
                               "TOTAL6, GTOTAL1, GTOTAL2, EFFECT, CLOSINGBALANCE, OPENINGBALANCE, " & _
                               "APPLICATIONDATE)VALUES('" & BrCode & "','" & CRCode & "','ABB'," & _
                               "'111111','ABB RECONCILIATION ACCOUNT',0,0," & dBlABBAmount & ",0," & _
                               "0,0," & dBlABBAmount & ",0," & dBlABBAmount & ",0,0,'" & strAppDate & "')"
            End If

            objcmd = New OracleClient.OracleCommand(strInsertABB, objconn)
            objcmd.Transaction = objtran
            objcmd.ExecuteNonQuery()
            objcmd.Dispose()
            objcmd = Nothing
            '''' Insert abb entry to gengldaybook ended here

            ''''''' Update Closing Balance
            'Dim strAppDate As String

            strAppDate = CStr(Format(CDate(appDate), "dd-MMM-yyyy"))

            StrInsert = "Update GenGlDayBook a set ClosingBalance=Effect+nvl((" & _
                        " select ClosingBalance from GenGlDayBook where applicationdate=" & _
                        " (select max(applicationdate) from GenGlDayBook where " & _
                        " applicationdate<'" & strAppDate & "' and glcode=a.glcode " & _
                        " and branchcode='" & BrCode & "' and currencycode=a.currencycode ) " & _
                        " and glcode=a.glcode  and currencycode=a.currencycode and branchcode=" & _
                        "'" & BrCode & "' ),0), OpeningBalance=nvl((" & _
                        " select ClosingBalance from GenGlDayBook where applicationdate=" & _
                        " (select max(applicationdate) from GenGlDayBook where " & _
                        " applicationdate<'" & strAppDate & "' and glcode=a.glcode  " & _
                        " and branchcode='" & BrCode & "' and currencycode=a.currencycode ) " & _
                        " and glcode=a.glcode  and currencycode=a.currencycode and branchcode=" & _
                        "'" & BrCode & "'),0)  where applicationdate='" & strAppDate & "' and " & _
                        "currencycode='" & CRCode & "' and branchcode='" & BrCode & "'"



            objcmd = New OracleClient.OracleCommand(StrInsert, objconn)
            objcmd.Transaction = objtran
            objcmd.ExecuteNonQuery()
            objcmd.Dispose()
            objcmd = Nothing


            ''''' Delete records from temporary table
            StrTabName = "RepSupplementaryTemp"
            StrCondition = "repno=999 and upper(userid)='VINOD' "
            StrDelete = "Delete from " & StrTabName & " Where " & StrCondition

            objcmd = New OracleClient.OracleCommand(StrDelete, objconn)
            objcmd.Transaction = objtran
            objcmd.ExecuteNonQuery()
            objcmd.Dispose()
            objcmd = Nothing

            Exit Function
        Catch ex As Exception
            ''MsgBox(ex.Message)
        End Try
    End Function

End Class
