Public Class Validations
    Dim ObjOracleConnection As New OracleClient.OracleConnection
    Dim objcommand As OracleClient.OracleCommand
    Dim objDBConnection As New DatabaseConnection.cDBConnection
    Dim o_Errmsg As String


    Public Function getDebitCreditByYealrly(ByVal BranchCode As String, _
               ByVal ModuleId As String, _
               ByVal Glcode As String, _
               ByVal AccNo As String, _
               ByVal AppDate As String) As String

        Dim fromdate As String, Todate As String
        Try

            Dim drCreditDebit As OracleClient.OracleDataReader
            'Dim daOracleDataAdapter As OracleClient.OracleDataAdapter
            Dim objcommand As OracleClient.OracleCommand
            Dim vb() As String = GetFinancialYear(AppDate).Split("-")
            fromdate = "1-APR-" & vb(0)
            Todate = "31-MAR-" & vb(1)

            Dim strSqlQuery As String = "SELECT (" & _
                                " SELECT NVL(SUM(AMOUNT),0) FROM " & ModuleId & "TRAN WHERE modeoftran=1 AND BRANCHCODE='" & BranchCode & "'" & _
                                " AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & "' AND ACCNO='" & AccNo & "'" & _
                                " AND APPLICATIONDATE BETWEEN '" & fromdate & "' AND '" & Todate & "') AS DR " & _
                                "," & _
                                "(" & _
                                "SELECT NVL(SUM(AMOUNT),0) " & _
                                " FROM " & ModuleId & "TRAN WHERE modeoftran=2 AND BRANCHCODE='" & BranchCode & "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & "'" & _
                                " AND ACCNO='" & AccNo & "'" & _
                                " AND APPLICATIONDATE BETWEEN '" & fromdate & "' AND '" & Todate & "') AS CR," & _
                                "(" & _
                                " SELECT NVL(SUM(AMOUNT),0) FROM " & ModuleId & "TRANDAY WHERE modeoftran=1 AND BRANCHCODE='" & BranchCode & "'" & _
                                " AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & "' AND ACCNO='" & AccNo & "' " & _
                                " AND APPLICATIONDATE BETWEEN '" & fromdate & "' AND '" & Todate & "') AS DRDAY " & _
                                "," & _
                                 "(" & _
                                "SELECT NVL(SUM(AMOUNT),0) " & _
                                " FROM " & ModuleId & "TRANDAY WHERE modeoftran=2 AND BRANCHCODE='" & BranchCode & "' AND MODULEID='" & ModuleId & "' AND GLCODE='" & Glcode & "'" & _
                                " AND ACCNO='" & AccNo & "'" & _
                                " AND APPLICATIONDATE BETWEEN '" & fromdate & "' AND '" & Todate & "') AS CRDAY," & _
                                " TO_NUMBER(VALUE1) AS MAXAMOUNT" & _
                                " FROM GENCONFIGMST WHERE CODE='CTR'"

            ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)

            If (Len(o_Errmsg) = 0) Then

                objcommand = New OracleClient.OracleCommand(strSqlQuery, ObjOracleConnection)
                'daOracleDataAdapter = New OracleClient.OracleDataAdapter(objcommand)
                'daOracleDataAdapter.Fill(ds)
                drCreditDebit = objcommand.ExecuteReader

                Dim debitBalance As String = "0", creditBalance As String = "0", maxAmount As String = "0"
                Dim dtbTable As DataTable
                Dim i As Int16, rcount

                If drCreditDebit.Read Then
                    If Not (System.Convert.IsDBNull(drCreditDebit("DR"))) Then
                        debitBalance = Convert.ToDecimal(drCreditDebit("DR")) + Convert.ToDecimal(drCreditDebit("DRDAY"))
                    End If

                    If Not (System.Convert.IsDBNull(drCreditDebit("CR"))) Then
                        creditBalance = Convert.ToDecimal(drCreditDebit("CR")) + Convert.ToDecimal(drCreditDebit("CRDAY"))
                    End If

                    If Not (System.Convert.IsDBNull(drCreditDebit("MAXAMOUNT"))) Then
                        maxAmount = drCreditDebit("MAXAMOUNT")
                    End If

                End If
                drCreditDebit = Nothing
                objcommand = Nothing
                ObjOracleConnection = Nothing
                objDBConnection = Nothing
                Return debitBalance & "|" & creditBalance & "|" & maxAmount

            Else
                Return o_Errmsg
            End If

        Catch ex As Exception
            Return ex.Message.ToString()
        End Try

    End Function

    Public Function GetExcIntRevFrmDepIntAccDtls(ByVal br As String, ByVal cr As String, ByVal gl As String, ByVal acc As String, ByVal frmdate As String, ByVal todate As String, ByRef strError As String) As String

        Dim strSql As String
        Dim rsdepintaccr As OracleClient.OracleDataReader
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg As String
        Dim dbldepaccrintexcessamount As Double
        dbldepaccrintexcessamount = 0
        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            strSql = "SELECT SUM(ABS(INTAMOUNT)) INTAMOUNT FROM DEPINTACCRUEDDTLS WHERE  ACCNO = '" & acc & "' AND GLCODE = '" & gl & "' AND INTAMOUNT < 0 AND MODULEID = 'DEP' AND (REMARKS LIKE 'Excess Interest Adjusted%'  OR REMARKS LIKE 'Excess Int Reverse%'  OR REMARKS LIKE 'Excess Int Rev To GL%') AND APPLICATIONDATE  BETWEEN '" & Format(CDate(frmdate), "dd-MMM-yyyy") & "' AND  '" & Format(CDate(todate), "dd-MMM-yyyy") & "' AND BRANCHCODE = '" & br & "' AND currencycode = '" & cr & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            rsdepintaccr = objCmd.ExecuteReader()
            If rsdepintaccr.HasRows = True Then
                rsdepintaccr.Read()
                If IsDBNull(rsdepintaccr!INTAMOUNT) Then
                    dbldepaccrintexcessamount = 0
                Else
                    dbldepaccrintexcessamount = rsdepintaccr!INTAMOUNT
                End If

            End If

            rsdepintaccr.Close()
            rsdepintaccr = Nothing
            objCmd.Dispose()
            objCmd = Nothing



            GetExcIntRevFrmDepIntAccDtls = dbldepaccrintexcessamount
        Catch ex As Exception
            strError = ex.Message
        End Try
    End Function

    Public Function GetFinancialYear(ByVal AppDate As String) As String

        Dim finyear As String = String.Empty
        Dim sDateTime As DateTime = Convert.ToDateTime(AppDate) 'DateTime.Now
        Dim month As Integer = sDateTime.Month
        Dim year As Integer = sDateTime.Year

        If month > 3 Then
            finyear = year.ToString() & "-" & Convert.ToString((year + 1))
        Else
            finyear = Convert.ToString((year - 1)) & "-" & year.ToString()
        End If

        Return finyear

    End Function

    Public Function getSystemDate(ByVal objCon As OracleClient.OracleConnection) As String
        Dim objDrcust As OracleClient.OracleDataReader
        Dim objCmd As New OracleClient.OracleCommand
        Dim strsystemdate As String
        Dim errmsg, sQuery As String
        Try
            sQuery = "select to_char(sysdate,'dd-Mon-yyyy') sysdate1 from dual"
            objCmd = New OracleClient.OracleCommand(sQuery, objCon)

            objDrcust = objCmd.ExecuteReader()
            If (objDrcust.HasRows) Then
                objDrcust.Read()
                strsystemdate = IIf(IsDBNull(objDrcust!sysdate1), "", objDrcust!sysdate1)
            End If
            getSystemDate = strsystemdate
            objDrcust.Close()
            objDrcust.Dispose()
            objDrcust = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Function
        Catch ex As Exception
            getSystemDate = Format(Now, "dd-MMM-yyyy")
        End Try
    End Function
    Public Function GetDepCertificateNameWOconn(ByVal objCon As OracleClient.OracleConnection) As String

        Dim objCmd As New OracleClient.OracleCommand

        Dim errmsg, sQuery As String
        Try

            Dim objDrcust As OracleClient.OracleDataReader
            Dim strDepCertName1 As String
            strDepCertName1 = ""
            sQuery = "select depcertificate from genbankparm"

            objCmd = New OracleClient.OracleCommand(sQuery, objCon)

            objDrcust = objCmd.ExecuteReader()
            If (objDrcust.HasRows) Then
                objDrcust.Read()
                strDepCertName1 = IIf(IsDBNull(objDrcust!depcertificate), "", objDrcust!depcertificate)
            End If
            objDrcust.Close()
            objDrcust.Dispose()
            objDrcust = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetDepCertificateNameWOconn = strDepCertName1
            Exit Function
        Catch ex As Exception
            GetDepCertificateNameWOconn = "MAHARAJA"
        End Try
    End Function
    Public Function GetAnyDayBalance(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String, ByVal TranDate As Date) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim dblAnyDayBal, dblCCLmt As Double
        dblAnyDayBal = 0 : dblCCLmt = 0
        If objCon.State <> ConnectionState.Open Then
            errmsg = ""
            objCon = dbCon.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If
        strQuery = "select GETANYDAYBAL('" & BrCode & "'," & _
                      " '" & CrCode & "' ,'" & ModId & "'," & _
                      " '" & GlCode & "','" & AccNo & "'," & _
                     " '" & Format(TranDate, "dd-MMM-yyyy") & "') from dual"

        objCmd = New OracleClient.OracleCommand(strQuery, objCon)
        dblAnyDayBal = objCmd.ExecuteScalar

        objCmd.Dispose()
        objCmd = Nothing

        If ModId = "CC" Then
            strQuery = "SELECT LINKEDAMOUNT FROM GENLIMITLNK WHERE LINKEDACCNO='" & AccNo & "' AND LINKEDGLCODE='" & GlCode & "' AND LINKEDMODULEID='" & ModId & "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CrCode & "' AND STATUS='R'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dblCCLmt = objCmd.ExecuteScalar
            dblAnyDayBal = dblAnyDayBal + dblCCLmt
            objCmd.Dispose()
            objCmd = Nothing
        End If

        GetAnyDayBalance = dblAnyDayBal

    End Function





    Public Function GetAnyDayBalanceAppr(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String, ByVal TranDate As Date) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim dblAnyDayBal, dblCCLmt As Double
        dblAnyDayBal = 0 : dblCCLmt = 0
        If objCon.State <> ConnectionState.Open Then
            errmsg = ""
            objCon = dbCon.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If
        strQuery = "select GetanydaybalAppr('" & BrCode & "'," & _
                      " '" & CrCode & "' ,'" & ModId & "'," & _
                      " '" & GlCode & "','" & AccNo & "'," & _
                     " '" & Format(TranDate, "dd-MMM-yyyy") & "') from dual"

        objCmd = New OracleClient.OracleCommand(strQuery, objCon)
        dblAnyDayBal = objCmd.ExecuteScalar

        objCmd.Dispose()
        objCmd = Nothing



        GetAnyDayBalanceAppr = dblAnyDayBal

    End Function

    Public Function GetMinAmountBalMst(ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim objmdr As OracleClient.OracleDataReader
        Dim dblMinAmt As Double
        dblMinAmt = 0
        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "SELECT MINAMOUNT FROM genminmaxbalancemst WHERE  glcode = '" & GlCode & "' AND  moduleid = '" & ModId & "' AND currencycode = '" & CrCode & "' AND categorycode = '99'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            objcommand = New OracleClient.OracleCommand(strQuery, objCon)

            objmdr = objcommand.ExecuteReader
            If objmdr.HasRows Then
                objmdr.Read()
                dblMinAmt = IIf(IsDBNull(objmdr!MINAMOUNT), 0, objmdr!MINAMOUNT)
            Else
                dblMinAmt = 0
            End If
            objmdr.Close()
            objmdr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetMinAmountBalMst = dblMinAmt
            Exit Function
        Catch ex As Exception
            dblMinAmt = 0
            GetMinAmountBalMst = dblMinAmt
        End Try

    End Function



    Public Sub GetAnyDayBalanceCC(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String, ByVal TranDate As Date, ByRef pdblAnyDayBal As Double, ByRef pdbllimitamt As Double, ByRef strError As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim dblAnyDayBal As Double
        Try
            dblAnyDayBal = 0
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "select GETANYDAYBAL('" & BrCode & "'," & _
                          " '" & CrCode & "' ,'" & ModId & "'," & _
                          " '" & GlCode & "','" & AccNo & "'," & _
                         " '" & Format(TranDate, "dd-MMM-yyyy") & "') from dual"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dblAnyDayBal = objCmd.ExecuteScalar

            objCmd.Dispose()
            objCmd = Nothing


            Dim dbllimitamt As Double = 0
            Dim rstod As OracleClient.OracleDataReader
            Dim dbltodlimitamt As Double = 0
            Dim strSql As String
            Dim objDr As OracleClient.OracleDataReader


            strSql = " select Sum(nvl(LINKEDAMOUNT,0)) AMOUNT from GENLIMITLNK where LINKEDACCNO='" & AccNo & "' and LINKEDGLCODE='" & GlCode & "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='INR' AND LINKEDMODULEID='" & ModId & "'   and closedate is null and status='R' "

            objCmd = New OracleClient.OracleCommand(strSql, objCon)

            objDr = objCmd.ExecuteReader()
            If objDr.HasRows = True Then
                objDr.Read()
                dbllimitamt = IIf(IsDBNull(objDr!AMOUNT), 0, objDr!AMOUNT)
            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            strSql = "SELECT NVL(TODLIMITAMT,0) TODLIMITAMT FROM genlimitlnk WHERE LINKEDACCNO = '" & AccNo & "' AND LINKEDGLCODE='" & GlCode & "' AND  LINKEDMODULEID='" & ModId & "' AND BRANCHCODE= '" & BrCode & "' AND CURRENCYCODE='INR' AND TODEXPDATE >= '" & Format(TranDate, "dd-MMM-yyyy") & "' AND TODEXPDATE IS NOT NULL "

            objCmd = New OracleClient.OracleCommand(strSql, objCon)

            rstod = objCmd.ExecuteReader()

            If rstod.HasRows = True Then
                rstod.Read()
                dbltodlimitamt = IIf(IsDBNull(rstod!TODLIMITAMT), 0, rstod!TODLIMITAMT)
            Else
                dbltodlimitamt = 0
            End If
            rstod.Close()
            rstod = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            pdblAnyDayBal = dblAnyDayBal
            pdbllimitamt = dbllimitamt + dbltodlimitamt


            Exit Sub
        Catch ex As Exception
            strError = ex.Message
            pdblAnyDayBal = 0
            pdbllimitamt = 0

        End Try


    End Sub

    Public Sub GetAnyDayBalanceCCAppr(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String, ByVal TranDate As Date, ByRef pdblAnyDayBal As Double, ByRef pdbllimitamt As Double, ByRef strError As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim dblAnyDayBal As Double
        Try
            dblAnyDayBal = 0
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "select GetanydaybalAppr('" & BrCode & "'," & _
                          " '" & CrCode & "' ,'" & ModId & "'," & _
                          " '" & GlCode & "','" & AccNo & "'," & _
                         " '" & Format(TranDate, "dd-MMM-yyyy") & "') from dual"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dblAnyDayBal = objCmd.ExecuteScalar

            objCmd.Dispose()
            objCmd = Nothing


            Dim dbllimitamt As Double = 0
            Dim rstod As OracleClient.OracleDataReader
            Dim dbltodlimitamt As Double = 0
            Dim strSql As String
            Dim objDr As OracleClient.OracleDataReader


            strSql = " select Sum(nvl(LINKEDAMOUNT,0)) AMOUNT from GENLIMITLNK where LINKEDACCNO='" & AccNo & "' and LINKEDGLCODE='" & GlCode & "' AND BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='INR' AND LINKEDMODULEID='" & ModId & "'   and closedate is null and status='R' "

            objCmd = New OracleClient.OracleCommand(strSql, objCon)

            objDr = objCmd.ExecuteReader()
            If objDr.HasRows = True Then
                objDr.Read()
                dbllimitamt = IIf(IsDBNull(objDr!AMOUNT), 0, objDr!AMOUNT)
            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            strSql = "SELECT NVL(TODLIMITAMT,0) TODLIMITAMT FROM genlimitlnk WHERE LINKEDACCNO = '" & AccNo & "' AND LINKEDGLCODE='" & GlCode & "' AND  LINKEDMODULEID='" & ModId & "' AND BRANCHCODE= '" & BrCode & "' AND CURRENCYCODE='INR' AND TODEXPDATE >= '" & Format(TranDate, "dd-MMM-yyyy") & "' AND TODEXPDATE IS NOT NULL "

            objCmd = New OracleClient.OracleCommand(strSql, objCon)

            rstod = objCmd.ExecuteReader()

            If rstod.HasRows = True Then
                rstod.Read()
                dbltodlimitamt = IIf(IsDBNull(rstod!TODLIMITAMT), 0, rstod!TODLIMITAMT)
            Else
                dbltodlimitamt = 0
            End If
            rstod.Close()
            rstod = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            pdblAnyDayBal = dblAnyDayBal
            pdbllimitamt = dbllimitamt + dbltodlimitamt


            Exit Sub
        Catch ex As Exception
            strError = ex.Message
            pdblAnyDayBal = 0
            pdbllimitamt = 0
        End Try
    End Sub

    Public Function GetRefno(ByRef gObjOracleConnection As OracleClient.OracleConnection, ByRef objTransaction As OracleClient.OracleTransaction, ByRef returnMsg As String) As String
        Try
            Dim strSql1 As String
            Dim objDrcust As OracleClient.OracleDataReader
            Dim strRefno As String
            Dim objCmd As New OracleClient.OracleCommand
            Dim errmsg As String

            strSql1 = "SELECT (SELECT H2Hbankname FROM GENBANKPARM)||TO_CHAR(SYSDATE,'yymmdd')||x.refno  refno FROM (SELECT LPAD(NVL(MAX(SUBSTR(refno,11,6)),0)+1,6,'0') refno FROM neftrtgsdtls WHERE TO_NUMBER(SUBSTR(refno,5,6)) = TO_NUMBER(TO_CHAR(SYSDATE,'yymmdd'))) x"

            objCmd = New OracleClient.OracleCommand(strSql1, gObjOracleConnection)
            objCmd.Transaction = objTransaction
            objDrcust = objCmd.ExecuteReader()
            If (objDrcust.HasRows) Then
                objDrcust.Read()
                strRefno = IIf(IsDBNull(objDrcust!refno), "", objDrcust!refno)
            Else
                strRefno = ""
            End If
            GetRefno = strRefno
            objDrcust.Close()
            objDrcust = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Function
        Catch ex As Exception
            returnMsg = ex.Message
            If Trim(returnMsg).Length > 0 Then
                returnMsg = Replace(returnMsg, Chr(10), " ")
                returnMsg = Replace(returnMsg, Chr(13), " ")
            End If

        End Try
    End Function

    Public Function GetRefnoWithOutTrans() As String
        Try
            Dim objCon As New OracleClient.OracleConnection
            Dim objCmd As New OracleClient.OracleCommand
            Dim dbCon As New DatabaseConnection.cDBConnection
            Dim errmsg, strQuery As String
            Dim strMobileNo As String = ""
            Dim dr As OracleClient.OracleDataReader
            Dim objDrcust As OracleClient.OracleDataReader
            Dim strSql1, strRefno As String
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strSql1 = "SELECT (SELECT H2Hbankname FROM GENBANKPARM)||TO_CHAR(SYSDATE,'yymmdd')||x.refno  refno FROM (SELECT LPAD(NVL(MAX(SUBSTR(refno,11,6)),0)+1,6,'0') refno FROM neftrtgsdtls WHERE TO_NUMBER(SUBSTR(refno,5,6)) = TO_NUMBER(TO_CHAR(SYSDATE,'yymmdd'))) x"

            objCmd = New OracleClient.OracleCommand(strSql1, objCon)

            objDrcust = objCmd.ExecuteReader()
            If (objDrcust.HasRows) Then
                objDrcust.Read()
                strRefno = IIf(IsDBNull(objDrcust!refno), "", objDrcust!refno)
            Else
                strRefno = ""
            End If
            GetRefnoWithOutTrans = strRefno
            objDrcust.Close()
            objDrcust = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Function
        Catch ex As Exception
            GetRefnoWithOutTrans = ex.Message


        End Try
    End Function

    Public Function GetHOTRALWBrCode() As String
        Try
            Dim objCon As New OracleClient.OracleConnection
            Dim objCmd As New OracleClient.OracleCommand
            Dim dbCon As New DatabaseConnection.cDBConnection
            Dim errmsg, strQuery As String
            Dim strBrcode As String = "101"
            Dim dr As OracleClient.OracleDataReader
            Dim objDrcust As OracleClient.OracleDataReader
            Dim strSql1 As String
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strSql1 = "SELECT  branchcode  FROM GENCONFIGMST WHERE impyn = 'Y' and code = 'HOTRAW'"
            objCmd = New OracleClient.OracleCommand(strSql1, objCon)
            objDrcust = objCmd.ExecuteReader()
            If (objDrcust.HasRows) Then
                objDrcust.Read()
                strBrcode = IIf(IsDBNull(objDrcust!branchcode), "", objDrcust!branchcode)
            Else
                strBrcode = "101"
            End If
            GetHOTRALWBrCode = strBrcode
            objDrcust.Close()
            objDrcust = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Function
        Catch ex As Exception
            GetHOTRALWBrCode = "101"
        End Try
    End Function


    Public Function GetCCDrCrLienYN(ByVal strBrCode As String, ByVal strCurcode As String, ByVal strModId As String, ByVal strGlcode As String, _
    ByVal strAccno As String, ByVal TranDate As Date, ByRef o_Errmsg As String) As String

        Dim strDrLnYN As String
        Dim strCrLnYN As String
        Dim strAllowYN As String
        Dim dblDrLnAmt As Double
        Dim dblCrLnAmt As Double
        Dim dblAccBal As Double
        Dim dblfinLeinLimAmt As Double
        Dim strDrCrLnYN As String
        Dim strSql As String
        Dim objCmd As New OracleClient.OracleCommand
        Dim rsneftAck As OracleClient.OracleDataReader
        Try
            If strModId = "CC" Then
            Else
                GoTo End1
            End If

            ''   ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)

            If ObjOracleConnection.State <> ConnectionState.Open Then
                o_Errmsg = ""
                ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If o_Errmsg <> "" Then
                    Throw New Exception(o_Errmsg)
                    Exit Function
                End If
            End If
            If (Len(o_Errmsg) = 0) Then

                strSql = "SELECT DRLIENYN, CRLIENYN FROM " & strModId & "mst  WHERE branchcode ='" & strBrCode & "' AND " & _
" currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"
                objCmd = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                rsneftAck = objCmd.ExecuteReader

                If rsneftAck.HasRows = True Then
                    rsneftAck.Read()
                    strDrLnYN = IIf(IsDBNull(rsneftAck!DRLIENYN), "N", rsneftAck!DRLIENYN)
                    strCrLnYN = IIf(IsDBNull(rsneftAck!CRLIENYN), "N", rsneftAck!CRLIENYN)
                Else
                    strDrLnYN = "N"
                    strCrLnYN = "N"
                End If

                objCmd.Dispose()
                objCmd = Nothing
                rsneftAck.Close()
                rsneftAck = Nothing

                strSql = "SELECT DRLIENAMT, CRLIENAMT FROM SBCALIENDTLS WHERE branchcode ='" & strBrCode & "' AND " & _
                " currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"

                objCmd = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                rsneftAck = objCmd.ExecuteReader

                If rsneftAck.HasRows = True Then
                    rsneftAck.Read()

                    dblDrLnAmt = IIf(IsDBNull(rsneftAck!DRLIENAMT), 0, rsneftAck!DRLIENAMT)
                    dblCrLnAmt = IIf(IsDBNull(rsneftAck!CRLIENAMT), 0, rsneftAck!CRLIENAMT)
                Else
                    dblDrLnAmt = 0
                    dblCrLnAmt = 0
                End If

                objCmd.Dispose()
                objCmd = Nothing
                rsneftAck.Close()
                rsneftAck = Nothing

                GetCCDrCrLienYN = strDrLnYN & "|" & dblDrLnAmt & "|" & strCrLnYN & "|" & dblCrLnAmt

            End If
            Exit Function
End1:
            GetCCDrCrLienYN = "|||"
            Exit Function
        Catch ex As Exception
            o_Errmsg = ex.Message
        End Try
    End Function

    Public Function GetSBCADrCrLienYN(ByVal strMode As String, ByVal strBrCode As String, ByVal strCurcode As String, ByVal strModId As String, ByVal strGlcode As String, _
    ByVal strAccno As String, ByVal TransAmt As Double, ByVal TranDate As Date, ByRef o_Errmsg As String) As String

        Dim strDrLnYN As String
        Dim strCrLnYN As String
        Dim strAllowYN As String
        Dim dblDrLnAmt As Double
        Dim dblCrLnAmt As Double
        Dim dblAccBal As Double
        Dim dblfinLeinLimAmt As Double
        Dim strDrCrLnYN As String
        Dim strSql As String
        Dim objCmd As New OracleClient.OracleCommand
        Dim rsneftAck As OracleClient.OracleDataReader
        Try
            If strModId = "SB" Or strModId = "CA" Then
            Else
                GoTo End1
            End If

            ''   ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)

            If ObjOracleConnection.State <> ConnectionState.Open Then
                o_Errmsg = ""
                ObjOracleConnection = objDBConnection.GetDbConnection(o_Errmsg)
                If o_Errmsg <> "" Then
                    Throw New Exception(o_Errmsg)
                    Exit Function
                End If
            End If
            If (Len(o_Errmsg) = 0) Then



                strSql = "select GETANYDAYBAL('" & strBrCode & "'," & _
                                         " '" & strCurcode & "' ,'" & strModId & "'," & _
                                         " '" & strGlcode & "','" & strAccno & "'," & _
                                        " '" & Format(TranDate, "dd-MMM-yyyy") & "') bal from dual"

                objCmd = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                rsneftAck = objCmd.ExecuteReader
                If rsneftAck.HasRows = True Then
                    rsneftAck.Read()
                    dblAccBal = IIf(IsDBNull(rsneftAck!bal), 0, rsneftAck!bal)
                Else
                    dblAccBal = 0
                End If
                objCmd.Dispose()
                objCmd = Nothing
                rsneftAck.Close()
                rsneftAck = Nothing

                strSql = "SELECT DRLIENYN, CRLIENYN FROM " & strModId & "mst  WHERE branchcode ='" & strBrCode & "' AND " & _
                " currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"
                objCmd = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                rsneftAck = objCmd.ExecuteReader

                If rsneftAck.HasRows = True Then
                    rsneftAck.Read()
                    strDrLnYN = IIf(IsDBNull(rsneftAck!DRLIENYN), "N", rsneftAck!DRLIENYN)
                    strCrLnYN = IIf(IsDBNull(rsneftAck!CRLIENYN), "N", rsneftAck!CRLIENYN)
                Else
                    strDrLnYN = "N"
                    strCrLnYN = "N"
                End If

                objCmd.Dispose()
                objCmd = Nothing
                rsneftAck.Close()
                rsneftAck = Nothing

                strSql = "SELECT DRLIENAMT, CRLIENAMT FROM SBCALIENDTLS WHERE branchcode ='" & strBrCode & "' AND " & _
                " currencycode ='" & strCurcode & "' AND glcode ='" & strGlcode & "'  AND accno ='" & strAccno & "'"

                objCmd = New OracleClient.OracleCommand(strSql, ObjOracleConnection)
                rsneftAck = objCmd.ExecuteReader

                If rsneftAck.HasRows = True Then
                    rsneftAck.Read()

                    dblDrLnAmt = IIf(IsDBNull(rsneftAck!DRLIENAMT), 0, rsneftAck!DRLIENAMT)
                    dblCrLnAmt = IIf(IsDBNull(rsneftAck!CRLIENAMT), 0, rsneftAck!CRLIENAMT)
                Else
                    dblDrLnAmt = 0
                    dblCrLnAmt = 0
                End If

                objCmd.Dispose()
                objCmd = Nothing
                rsneftAck.Close()
                rsneftAck = Nothing

                If strModId = "SB" Or strModId = "CA" Then
                    '' for Debit lien yn
                    If strMode = "Dr" Then
                        If strDrLnYN = "Y" Then
                            If dblAccBal - dblDrLnAmt >= TransAmt Then
                                strAllowYN = "Y"
                            Else
                                strAllowYN = "N"
                            End If
                        Else
                            strAllowYN = "Y"
                        End If
                    End If


                    '' for Credit Lien YN
                    If strMode = "Cr" Then
                        If strCrLnYN = "Y" Then
                            strAllowYN = "N"
                        Else
                            strAllowYN = "Y"
                        End If
                    End If

                    If strMode = "Dr" Then
                        dblfinLeinLimAmt = dblDrLnAmt
                        strDrCrLnYN = strDrLnYN
                    ElseIf strMode = "Cr" Then
                        dblfinLeinLimAmt = dblCrLnAmt
                        strDrCrLnYN = strCrLnYN
                    Else
                        dblfinLeinLimAmt = 0
                        strDrCrLnYN = ""
                    End If
                End If ''strModId = "SB" Or strModId = "CA"


                GetSBCADrCrLienYN = strAllowYN
            End If
            Exit Function
End1:
            GetSBCADrCrLienYN = "Y"
            Exit Function
        Catch ex As Exception
            GetSBCADrCrLienYN = "N"
        End Try
    End Function


    Private Function GetLimitAmount(ByVal pstrBrCode As String, ByVal pstrmodid As String, ByVal pstrGlcode As String, ByVal pstrAccno As String, ByVal TranDate As Date, ByVal objconn As OracleClient.OracleConnection) As Double

        Dim objCmd As New OracleClient.OracleCommand

        Dim rstod As OracleClient.OracleDataReader
        Dim objDr As OracleClient.OracleDataReader
        Dim dbllimitamt As Double = 0
        Dim dbltodlimitamt As Double = 0
        Dim strSql As String

        Try
            strSql = " select Sum(nvl(LINKEDAMOUNT,0)) AMOUNT from GENLIMITLNK where LINKEDACCNO='" & pstrAccno & "' and LINKEDGLCODE='" & pstrGlcode & "' AND BRANCHCODE='" & pstrBrCode & "' AND CURRENCYCODE='INR' AND LINKEDMODULEID='" & pstrmodid & "'   and closedate is null and status='R' "

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            objDr = objCmd.ExecuteReader()
            If objDr.HasRows = True Then
                objDr.Read()
                dbllimitamt = IIf(IsDBNull(objDr!AMOUNT), 0, objDr!AMOUNT)
            End If

            objDr.Close()
            objDr.Dispose()
            objDr = Nothing
            objCmd.Dispose()
            objCmd = Nothing


            strSql = "SELECT NVL(TODLIMITAMT,0) TODLIMITAMT FROM genlimitlnk WHERE LINKEDACCNO = '" & pstrAccno & "' AND LINKEDGLCODE='" & pstrGlcode & "' AND  LINKEDMODULEID='" & pstrmodid & "' AND BRANCHCODE= '" & pstrBrCode & "' AND CURRENCYCODE='INR' AND TODEXPDATE >= '" & Format(TranDate, "dd-MMM-yyyy") & "' AND TODEXPDATE IS NOT NULL "

            objCmd = New OracleClient.OracleCommand(strSql, objconn)
            rstod = objCmd.ExecuteReader()

            If rstod.HasRows = True Then
                rstod.Read()
                dbltodlimitamt = IIf(IsDBNull(rstod!TODLIMITAMT), 0, rstod!TODLIMITAMT)
            Else
                dbltodlimitamt = 0
            End If
            rstod.Close()
            rstod = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            GetLimitAmount = CDbl(dbllimitamt) + CDbl(dbltodlimitamt)
            Exit Function
        Catch ex As Exception

        End Try

    End Function


    Public Function GetCustMobileNo(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strMobileNo As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "select custmobile from gencustinfomst where customerid = " & _
                    " (select DISTINCT customerid from " & ModId & "mst where " & _
                    " accno = '" & AccNo & "'  and glcode='" & GlCode & "'" & _
                    " and branchcode='" & BrCode & "'and currencycode = '" & CrCode & "')"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()
                strMobileNo = IIf(IsDBNull(dr!custmobile), "", dr!custmobile)
            Else
                strMobileNo = ""
            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetCustMobileNo = strMobileNo
            Exit Function
        Catch ex As Exception
            GetCustMobileNo = ""
        End Try
    End Function

    Public Sub GetCustomerIDName(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String, ByRef strCustomerID As String, ByRef strName As String)
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String

        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If
            strQuery = "select DISTINCT customerid customerid,name from " & ModId & "mst where " & _
                    " accno = '" & AccNo & "'  and glcode='" & GlCode & "'" & _
                    " and branchcode='" & BrCode & "'and currencycode = '" & CrCode & "'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()
                strCustomerID = IIf(IsDBNull(dr!customerid), "", dr!customerid)
                strName = IIf(IsDBNull(dr!name), "", dr!name)
            Else
                strCustomerID = ""
                strName = ""
            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            Exit Sub
        Catch ex As Exception
            strCustomerID = "1111111111"
            strName = ""
        End Try
    End Sub

    Public Function GetCloseBal(ByVal BrCode As String, ByVal CrCode As String, ByVal ModId As String, ByVal GlCode As String, ByVal AccNo As String) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strCloseBal As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "select sum(nvl(closebal,0)) closebal from (select curbal closebal from " & ModId & "balance where  accno = '" & AccNo & "'  and glcode='" & GlCode & "' and branchcode='" & BrCode & "'and currencycode = '" & CrCode & "'" & _
                   " union all " & _
                   " select sum(nvl(amount,0)) closebal from " & ModId & "tranday where accno = '" & AccNo & "'  and glcode='" & GlCode & "' and branchcode='" & BrCode & "'and currencycode = '" & CrCode & "')"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()
                strCloseBal = IIf(IsDBNull(dr!closebal), "0", dr!closebal)
            Else
                strCloseBal = ""
            End If
            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            GetCloseBal = strCloseBal
            Exit Function
        Catch ex As Exception
            GetCloseBal = ""
        End Try
    End Function



    Public Function GetNFTSCONVYN() As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strNFTSCONVYN As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "select NFTSCONVYN from genbankparm"
            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader

            If dr.HasRows = True Then
                dr.Read()
                strNFTSCONVYN = IIf(IsDBNull(dr!NFTSCONVYN), "N", dr!NFTSCONVYN)
            Else
                strNFTSCONVYN = "N"
            End If
            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetNFTSCONVYN = strNFTSCONVYN
            Exit Function
        Catch ex As Exception
            GetNFTSCONVYN = "N"
        End Try
    End Function


    ' get parameter details for feature
    Public Function GetParameterDetails(ByVal intfeatcd1 As Integer, ByRef strmsgtags As String, ByRef strcustmessage As String, ByRef strtrantypeg As String, ByRef strsmstypeg As String, ByRef strmode1 As String, ByRef intdays As Integer, ByRef strschtype As String, ByRef dtschdate As Date, Optional ByRef dblminamt As Double = 0) As Boolean
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim dr As OracleClient.OracleDataReader
        Try
            strmsgtags = ""
            strcustmessage = ""
            strtrantypeg = ""
            strsmstypeg = ""
            strmode1 = ""
            intdays = 0
            strschtype = ""
            dblminamt = 0
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "select nvl(m.messagetags,'') MESSAGETAGS, nvl(s.CUSTOMERMESSAGE,'') CUSTOMERMESSAGE, s.TRANTYPE, s.SMSTYPE,s.mode1,s.days,s.schtype,nvl(s.nextpushdate,s.schday) schday,s.minamt from smstypemst s , smsfeaturemst m   where s.featurecode = m.featurecode and m.activeyn = 'Y' and s.featurecode =" & intfeatcd1

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader()
            If dr.Read() Then
                strmsgtags = dr!MESSAGETAGS.ToString
                strcustmessage = dr!CUSTOMERMESSAGE.ToString
                strtrantypeg = dr!TRANTYPE.ToString
                strsmstypeg = IIf(IsDBNull(dr!SMSTYPE), "", dr!SMSTYPE.ToString)
                strmode1 = IIf(IsDBNull(dr!mode1), "", dr!mode1.ToString)
                intdays = IIf(IsDBNull(dr!days), 0, dr!days.ToString)
                strschtype = IIf(IsDBNull(dr!schtype), "", dr!schtype.ToString)
                If IsDBNull(dr!schday) Then
                Else
                    dtschdate = dr!schday.ToString
                End If
                dblminamt = IIf(IsDBNull(dr!minamt), 0, dr!minamt.ToString)

                GetParameterDetails = True
                objCmd.Dispose()
                objCmd = Nothing
                dr.Close()
                dr = Nothing
                Exit Function
            Else
                GetParameterDetails = False
                Exit Function
            End If

            Exit Function
        Catch ex As Exception

            objCmd.Dispose()
            objCmd = Nothing
            dr.Close()
            dr = Nothing
        End Try
    End Function

    Public Function getSMSAccno(ByVal NFTSCONVYN As String, ByVal straccno As String) As String
        Dim strmodaccno As String
        If NFTSCONVYN = "N" Then
            If Len(straccno) = 1 Then
                strmodaccno = "XXXXX" & straccno
            ElseIf Len(straccno) = 2 Then
                strmodaccno = "XXXX" & straccno
            ElseIf Len(straccno) = 3 Then
                strmodaccno = "XXX" & straccno
            ElseIf Len(straccno) = 4 Then
                strmodaccno = "XXX" & Mid(straccno, 2, 3)
            ElseIf Len(straccno) = 5 Then
                strmodaccno = "XXX" & Mid(straccno, 3, 3)
            ElseIf Len(straccno) = 6 Then
                strmodaccno = "XXX" & Mid(straccno, 4, 3)
            End If
        ElseIf NFTSCONVYN = "Y" Then

            Dim straccno1 As String
            Dim straccnotrimst As String
            straccno1 = Mid(straccno, 10, 7)
            straccnotrimst = straccno1.TrimStart("0")
            If Len(straccnotrimst) = 1 Then
                strmodaccno = "XXXXXX" & straccnotrimst
            ElseIf Len(straccnotrimst) = 2 Then
                strmodaccno = "XXXXX" & straccnotrimst
            ElseIf Len(straccnotrimst) = 3 Then
                strmodaccno = "XXXX" & straccnotrimst
            ElseIf Len(straccnotrimst) = 4 Then
                strmodaccno = "XXXX" & Mid(straccnotrimst, 2, 3)
            ElseIf Len(straccnotrimst) = 5 Then
                strmodaccno = "XXXX" & Mid(straccnotrimst, 3, 3)
            ElseIf Len(straccnotrimst) = 6 Then
                strmodaccno = "XXXX" & Mid(straccnotrimst, 4, 3)
            ElseIf Len(straccnotrimst) = 7 Then
                strmodaccno = "XXXX" & Mid(straccnotrimst, 5, 3)
            End If
        End If
        getSMSAccno = strmodaccno
    End Function

    Public Function GetSMSBankName() As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim strSMSBankName As String = ""
        Dim dr As OracleClient.OracleDataReader
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "SELECT smsbankname FROM smsparameters"
            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader

            If dr.HasRows = True Then
                dr.Read()
                strSMSBankName = IIf(IsDBNull(dr!smsbankname), "", dr!smsbankname)
            Else
                strSMSBankName = ""
            End If
            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetSMSBankName = strSMSBankName
            Exit Function
        Catch ex As Exception
            GetSMSBankName = ""
        End Try
    End Function

    Public Function GetEODProgress() As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, sQuery As String
        Dim strSMSBankName As String = ""
        Dim recnfts As OracleClient.OracleDataReader
        Dim strDayBeginStatus As String = ""
        Dim strDayEndStatus As String = ""
        Dim strHOdayBeginStatus As String = ""
        Dim strHODayEndStatus As String = ""
        Try
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            sQuery = "SELECT DAYBEGINSTATUS, DAYENDSTATUS, HODAYBEGINSTATUS, HODAYENDSTATUS FROM genapplicationdatemst  where branchcode != '999'"

            objCmd = New OracleClient.OracleCommand(sQuery, objCon)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                While recnfts.Read()


                    strDayBeginStatus = IIf(IsDBNull(recnfts!DAYBEGINSTATUS), "", recnfts!DAYBEGINSTATUS)
                    strDayEndStatus = IIf(IsDBNull(recnfts!DAYENDSTATUS), "", recnfts!DAYENDSTATUS)
                    strHOdayBeginStatus = IIf(IsDBNull(recnfts!HODAYBEGINSTATUS), "", recnfts!HODAYBEGINSTATUS)
                    strHODayEndStatus = IIf(IsDBNull(recnfts!HODAYENDSTATUS), "", recnfts!HODAYENDSTATUS)

                    If (strDayBeginStatus = "O" And strDayEndStatus = "N" And strHOdayBeginStatus = "O" And strHODayEndStatus = "N") Or (strDayBeginStatus = "O" And strDayEndStatus = "O" And strHOdayBeginStatus = "O" And strHODayEndStatus = "N") Then
                        GetEODProgress = "YES"
                    Else
                        GetEODProgress = "906"
                        Exit While
                    End If
                End While
            Else
                GetEODProgress = "906"
            End If

            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing

            Exit Function
        Catch ex As Exception
            GetEODProgress = "906"
        End Try
    End Function

    Public Function GetAccName(ByVal strfullAccno As String) As String
        Try
            Dim strfullaccno1, pstrBrId, pstrGlcd, NFTSCONVYN, pstrAccNo, pstrACTP As String
            strfullaccno1 = StrReverse(Mid(StrReverse(strfullAccno), 1, 16))

            pstrBrId = Mid(strfullaccno1, 1, 3)
            pstrGlcd = Mid(strfullaccno1, 4, 6)

            '' for accno 16 digits only
            NFTSCONVYN = GetNFTSCONVYN()
            If NFTSCONVYN = "Y" Then
                pstrAccNo = pstrBrId & pstrGlcd & Mid(strfullaccno1, 10, 7)
            Else
                pstrAccNo = Mid(strfullaccno1, 10, 7).TrimStart("0")
            End If

            pstrACTP = GetModuleID(pstrGlcd)

            Dim objCon As New OracleClient.OracleConnection
            Dim objCmd As New OracleClient.OracleCommand
            Dim dbCon As New DatabaseConnection.cDBConnection
            Dim errmsg, sQuery As String
            Dim recnfts As OracleClient.OracleDataReader

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            Dim strQuery As String
            Dim strAccName As String
            Dim dr As OracleClient.OracleDataReader
            strQuery = "select name from " & pstrACTP & "mst where " & _
                               " accno = '" & pstrAccNo & "'  and glcode='" & pstrGlcd & "'" & _
                               " and branchcode='" & pstrBrId & "'and currencycode = 'INR'"

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            dr = objCmd.ExecuteReader
            If dr.HasRows = True Then
                dr.Read()
                strAccName = IIf(IsDBNull(dr!name), "", dr!name)
            Else
                strAccName = ""
            End If

            dr.Close()
            dr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            GetAccName = strAccName
        Catch ex As Exception
            GetAccName = ""
        End Try
    End Function

    Public Function GetModuleID(ByVal pstrGlcd As String) As String
        Dim pstrACTP As String
        Try


            If pstrGlcd = "102020" Then
                pstrACTP = "SB"
            ElseIf pstrGlcd = "102030" Then
                pstrACTP = "CA"
            ElseIf Mid(pstrGlcd, 1, 3) = "104" Then
                pstrACTP = "DEP"
            ElseIf Mid(pstrGlcd, 1, 3) = "206" Then

                pstrACTP = GetModuleIDCCLOAN(pstrGlcd)
            End If
            GetModuleID = pstrACTP
            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function GetModuleIDCCLOAN(ByVal pglcode As String) As String
        Dim strmodid As String = ""
        Dim strError10 As String
        Dim strSql As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, sQuery As String
        Dim recnfts As OracleClient.OracleDataReader
        Try
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            strSql = "select moduleid  from cctypemst where glcode = '" & pglcode & "' union select moduleid  from loantypemst where glcode = '" & pglcode & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts = objCmd.ExecuteReader()
            If recnfts.HasRows = True Then
                recnfts.Read()
                strmodid = IIf(IsDBNull(recnfts!moduleid), "", recnfts!moduleid)
            End If
            GetModuleIDCCLOAN = strmodid
            recnfts.Close()
            recnfts.Dispose()
            recnfts = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            Exit Function
        Catch ex As Exception
            GetModuleIDCCLOAN = ""
            strError10 = ex.Message
        End Try
    End Function

    Public Function GetPanYN(ByVal strcustid As String, ByVal strtds As String, ByRef strErrorMessage As String, Optional ByRef pstrPAN206AAYN As String = "", Optional ByRef pstrPAN206ABYN As String = "") As String
        Dim errmsg As String
        Dim objCon As New OracleClient.OracleConnection

        Dim dbCon As New DatabaseConnection.cDBConnection

        Try
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            GetPanYN = GetPanYNDtls(strcustid, strtds, strErrorMessage, objCon, pstrPAN206AAYN, pstrPAN206ABYN)
            Exit Function
        Catch ex As Exception
            strErrorMessage = ex.Message
        End Try
    End Function
    Public Function GetPanYN_Con(ByVal strcustid As String, ByVal strtds As String, ByRef strErrorMessage As String, ByRef objCon As OracleClient.OracleConnection, Optional ByRef pstrPAN206AAYN As String = "", Optional ByRef pstrPAN206ABYN As String = "") As String
        Try


            GetPanYN_Con = GetPanYNDtls(strcustid, strtds, strErrorMessage, objCon, pstrPAN206AAYN, pstrPAN206ABYN)
            Exit Function
        Catch ex As Exception
            strErrorMessage = ex.Message
        End Try
    End Function

    Private Function GetPanYNDtls(ByVal strcustid As String, ByVal strtds As String, ByRef strErrorMessage As String, ByRef objCon As OracleClient.OracleConnection, Optional ByRef pstrPAN206AAYN As String = "", Optional ByRef pstrPAN206ABYN As String = "")
        Dim strSql As String
        Dim objCmd As New OracleClient.OracleCommand
        Dim recnfts As OracleClient.OracleDataReader
        Dim recnfts1 As OracleClient.OracleDataReader

        Dim strPANYN As String = ""
        Dim strPAN206AAYN, strPAN206ABYN As String
        strPAN206AAYN = "" : strPAN206ABYN = ""
        strSql = "SELECT PAN206AAYN,PAN206ABYN FROM gencustinfomst WHERE  CUSTOMERID = '" & strcustid & "'"
        objCmd = New OracleClient.OracleCommand(strSql, objCon)
        recnfts = objCmd.ExecuteReader()
        If recnfts.HasRows = True Then
            recnfts.Read()
            strPAN206AAYN = recnfts!PAN206AAYN
            strPAN206ABYN = recnfts!PAN206ABYN
        End If
        recnfts.Close()
        recnfts = Nothing
        objCmd.Dispose()
        objCmd = Nothing
        pstrPAN206AAYN = strPAN206AAYN
        pstrPAN206ABYN = strPAN206ABYN
        If (strtds = "TDS") Then

            strSql = "SELECT panno FROM gencustinfomst WHERE KYCID=2 and  CUSTOMERID = '" & strcustid & "'"

            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts = objCmd.ExecuteReader()
            If recnfts.HasRows = True Then
                recnfts.Read()
                If IsDBNull(recnfts!panno) = True Then
                    strPANYN = "N" '' 20%

                ElseIf recnfts!panno.ToString().Length <> 10 Then
                    strPANYN = "N"   '' 20%
                Else
                    '' pan no is there
                    If strPAN206AAYN = "Y" And strPAN206ABYN = "Y" Then
                        strPANYN = "N"   '' 20%
                    ElseIf strPAN206AAYN = "Y" And strPAN206ABYN = "N" Then
                        strPANYN = "Y"   '' 10%
                    ElseIf strPAN206AAYN = "N" And strPAN206ABYN = "Y" Then
                        strPANYN = "N"   '' 20%
                    ElseIf strPAN206AAYN = "N" And strPAN206ABYN = "N" Then
                        strPANYN = "N"   '' 20%
                    End If
                    '' 20%
                End If
            Else
                strPANYN = "N"
            End If
        ElseIf (strtds = "Form 15H" Or strtds = "Form 15G") Then
            strSql = "SELECT panno FROM gencustinfomst WHERE KYCID=2 and  CUSTOMERID = '" & strcustid & "'"

            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts = objCmd.ExecuteReader()
            If recnfts.HasRows = True Then
                recnfts.Read()
                If IsDBNull(recnfts!panno) = True Then
                    strPANYN = "N" '' 20%

                ElseIf recnfts!panno.ToString().Length <> 10 Then
                    strPANYN = "N"   '' 20%
                Else
                    '' pan no is there
                    If strPAN206AAYN = "Y" And strPAN206ABYN = "Y" Then
                        strPANYN = "N"   '' 20%
                    ElseIf strPAN206AAYN = "Y" And strPAN206ABYN = "N" Then
                        strPANYN = ""   '' 
                    ElseIf strPAN206AAYN = "N" And strPAN206ABYN = "Y" Then
                        strPANYN = "N"   '' 20%
                    ElseIf strPAN206AAYN = "N" And strPAN206ABYN = "N" Then
                        strPANYN = "N"   '' 20%
                    End If

                End If
            Else
                strPANYN = "N"
            End If
            recnfts.Close()
            recnfts = Nothing
            objCmd.Dispose()
            objCmd = Nothing

        End If
        GetPanYNDtls = strPANYN
    End Function

    Public Function GetTDSFlag(ByVal BrCode As String, ByVal CurCode As String, ByVal DepGlcode As String, ByVal DepAccNo As String) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim dbCon As New DatabaseConnection.cDBConnection

        Dim errmsg As String
        Try

            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            GetTDSFlag = GetTDSFlagDtls(BrCode, CurCode, DepGlcode, DepAccNo, objCon)

            Exit Function
        Catch ex As Exception

        End Try
    End Function

    Public Function GetTDSFlag_Con(ByVal BrCode As String, ByVal CurCode As String, ByVal DepGlcode As String, ByVal DepAccNo As String, ByRef objCon As OracleClient.OracleConnection) As String

        Try



            GetTDSFlag_Con = GetTDSFlagDtls(BrCode, CurCode, DepGlcode, DepAccNo, objCon)

            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function GetTDSFlagDtls(ByVal BrCode As String, ByVal CurCode As String, ByVal DepGlcode As String, ByVal DepAccNo As String, ByRef objCon As OracleClient.OracleConnection) As String
        Dim strSql As String

        Dim objCmd As New OracleClient.OracleCommand

        Dim strtdsyn1 As String
        Dim recnfts1 As OracleClient.OracleDataReader
        strSql = ""
        strSql = "SELECT nvl(TDSYN,'N') TDSYN, nvl(EXMPFORMSRECYN,'N') EXMPFORMSRECYN , nvl(FORMS15G,'N') FORMS15G, nvl(NONTDS,'N') NONTDS FROM depmst WHERE BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND GLCODE='" & DepGlcode & "' AND ACCNO='" & DepAccNo & "'"

        objCmd = New OracleClient.OracleCommand(strSql, objCon)
        recnfts1 = objCmd.ExecuteReader()
        If recnfts1.HasRows = True Then
            recnfts1.Read()

            If recnfts1!NONTDS = "Y" Then
                strtdsyn1 = "Non TDS"
            ElseIf recnfts1!TDSYN = "Y" Then
                strtdsyn1 = "TDS"
            ElseIf recnfts1!EXMPFORMSRECYN = "Y" Then
                strtdsyn1 = "Form 15H"
            ElseIf recnfts1!FORMS15G = "Y" Then
                strtdsyn1 = "Form 15G"
            Else
                strtdsyn1 = "Non TDS"
            End If
        Else
            strtdsyn1 = ""
        End If
        recnfts1.Close()
        recnfts1 = Nothing
        objCmd.Dispose()
        objCmd = Nothing

        GetTDSFlagDtls = strtdsyn1
    End Function
    Public Function GetTDSyn(ByVal BrCode As String, ByVal CurCode As String, ByVal DepGlcode As String, ByVal DepAccNo As String) As String
        Dim strSql As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection

        Dim recnfts1 As OracleClient.OracleDataReader
        Dim errmsg As String
        Dim strtdsyn1 As String = ""
        Dim str15Hyn1 As String = ""
        Dim str15Gyn1 As String = ""
        Dim stryn1 As String = ""
        Try
            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            strSql = ""
            strSql = "SELECT nvl(tdsyn,'N') tdsyn,nvl(EXMPFORMSRECYN,'N') EXMPFORMSRECYN, nvl(FORMS15G,'N') FORMS15G FROM depmst WHERE BRANCHCODE='" & BrCode & "' AND CURRENCYCODE='" & CurCode & "' AND GLCODE='" & DepGlcode & "' AND ACCNO='" & DepAccNo & "'"
            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts1 = objCmd.ExecuteReader()
            If recnfts1.HasRows = True Then
                recnfts1.Read()
                strtdsyn1 = recnfts1!tdsyn
                str15Hyn1 = recnfts1!EXMPFORMSRECYN
                str15Gyn1 = recnfts1!FORMS15G

                If strtdsyn1 = "Y" Then
                    stryn1 = "Y"
                ElseIf str15Hyn1 = "Y" Then
                    stryn1 = "Y"
                ElseIf str15Gyn1 = "Y" Then
                    stryn1 = "Y"
                Else
                    stryn1 = "N"
                End If
            End If

            GetTDSyn = stryn1
            recnfts1.Close()
            recnfts1 = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            Exit Function
        Catch ex As Exception

        End Try
    End Function
    Public Function getITformCode(ByVal strCustomerid As String, ByVal pappdate As Date, ByRef gObjOracleConnection1 As OracleClient.OracleConnection, ByVal objTransaction1 As OracleClient.OracleTransaction, ByRef strErrorMessage As String) As String
        Dim rsacc As OracleClient.OracleDataReader
        Dim strsql As String
        Dim objcom As OracleClient.OracleCommand
        Dim pcustdob As String
        Dim intage As Integer
        Dim sno As Integer
        Dim strtofindate As Date
        Dim strcusttype As String
        Try
            strtofindate = getprvFinToDate(pappdate)
            strsql = ""
            strsql = "SELECT CUSTDOB,CUSTOMERTYPE  FROM gencustinfomst where customerid =" & strCustomerid & ""

            objcom = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
            objcom.Transaction = objTransaction1
            rsacc = objcom.ExecuteReader

            If rsacc.HasRows = True Then
                If rsacc.Read Then
                    strcusttype = IIf(IsDBNull(rsacc!CUSTOMERTYPE), "", rsacc!CUSTOMERTYPE)
                    If IsDBNull(rsacc!CUSTDOB) = True Then
                        pcustdob = ""

                    Else
                        pcustdob = rsacc!CUSTDOB
                    End If

                End If
            End If
            If strcusttype = "1" Or strcusttype = "2" Or strcusttype = "3" Or strcusttype = "9" Then
                intage = DateDiff(DateInterval.Year, CDate(pcustdob), strtofindate)
                If intage >= 60 Then
                    sno = 3
                ElseIf pcustdob = "" Then
                    sno = 4
                Else
                    sno = 4
                End If
            Else
                sno = 4
            End If
            objcom.Dispose()
            objcom = Nothing
            rsacc.Close()
            rsacc = Nothing
            getITformCode = getITformITCode(sno, gObjOracleConnection1, objTransaction1)
        Catch ex As Exception
            strErrorMessage = ex.Message
        End Try
    End Function
    Private Function getITformITCode(ByVal psno As Integer, ByRef gObjOracleConnection1 As OracleClient.OracleConnection, ByVal objTransaction1 As OracleClient.OracleTransaction) As String
        Dim rsacc1 As OracleClient.OracleDataReader
        Dim objcom1 As OracleClient.OracleCommand
        Dim strsql, strITCode As String
        Try
            strsql = "SELECT itcode FROM genitformcode WHERE sno = " & psno & ""
            objcom1 = New OracleClient.OracleCommand(strsql, gObjOracleConnection1)
            objcom1.Transaction = objTransaction1
            rsacc1 = objcom1.ExecuteReader

            If rsacc1.HasRows = True Then
                If rsacc1.Read Then
                    strITCode = IIf(IsDBNull(rsacc1!itcode), "", rsacc1!itcode)
                End If
            End If


            objcom1.Dispose()
            objcom1 = Nothing
            rsacc1.Close()
            rsacc1 = Nothing
            getITformITCode = strITCode
        Catch ex As Exception

        End Try
    End Function
    Private Function getprvFinToDate(ByVal AppDate As Date) As Date
        Dim strmon As String
        Dim stryear As String


        Dim todate As String
        Try

            strmon = Month(AppDate)
            stryear = Year((AppDate))

            If strmon <= 3 Then

                todate = Format(CDate("31-Mar-" & stryear - 1), "dd-MMM-yyyy")
            Else

                todate = Format(CDate("31-Mar-" & stryear), "dd-MMM-yyyy")
            End If ''strmon <= 3
            getprvFinToDate = CDate(todate)
        Catch ex As Exception

        End Try
    End Function
    Public Function getITformITCode(ByVal psno As Integer) As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strQuery As String
        Dim objmdr As OracleClient.OracleDataReader
        Dim strITCode As String

        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If
            strQuery = "SELECT itcode FROM genitformcode WHERE sno = " & psno & ""

            objCmd = New OracleClient.OracleCommand(strQuery, objCon)
            objcommand = New OracleClient.OracleCommand(strQuery, objCon)

            objmdr = objcommand.ExecuteReader
            If objmdr.HasRows Then
                objmdr.Read()
                strITCode = IIf(IsDBNull(objmdr!itcode), "", objmdr!itcode)

            End If
            objmdr.Close()
            objmdr = Nothing
            objCmd.Dispose()
            objCmd = Nothing
            getITformITCode = strITCode
            Exit Function
        Catch ex As Exception
            errmsg = ex.Message
        End Try
    End Function
    Public Function GetLoginOTPYN() As String
        Dim strSql, errmsg As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection

        If objCon.State <> ConnectionState.Open Then
            errmsg = ""
            objCon = dbCon.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If

        Dim strloginotpyn As String = "N"
        Dim recnfts1 As OracleClient.OracleDataReader
        strSql = ""
        strSql = "select loginotpyn from genbankparm"

        objCmd = New OracleClient.OracleCommand(strSql, objCon)
        recnfts1 = objCmd.ExecuteReader()
        If recnfts1.HasRows = True Then
            recnfts1.Read()
            strloginotpyn = IIf(IsDBNull(recnfts1!loginotpyn), "N", recnfts1!loginotpyn)
        End If

        recnfts1.Close()
        recnfts1 = Nothing
        objCmd.Dispose()
        objCmd = Nothing

        GetLoginOTPYN = strloginotpyn
    End Function

    Public Sub GetCKYCEnrollDetails(ByVal strkycenrolldate As String, ByRef pstrckycsno As String, ByRef pstrduedate As String)
        Dim strSql, errmsg As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Sub
                End If
            End If


            Dim strckycsno, strCKYCIDPERIOD As String
            Dim recnfts1 As OracleClient.OracleDataReader
            strSql = ""
            strSql = "SELECT NVL(MAX(sno),0) +1 sno  FROM CKYCENROLLDTLS"

            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts1 = objCmd.ExecuteReader()
            If recnfts1.HasRows = True Then
                recnfts1.Read()
                strckycsno = IIf(IsDBNull(recnfts1!sno), "0", recnfts1!sno)
            End If

            recnfts1.Close()
            recnfts1 = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            strSql = ""
            strSql = "select CKYCIDPERIOD from genbankparm"

            objCmd = New OracleClient.OracleCommand(strSql, objCon)
            recnfts1 = objCmd.ExecuteReader()
            If recnfts1.HasRows = True Then
                recnfts1.Read()
                strCKYCIDPERIOD = IIf(IsDBNull(recnfts1!CKYCIDPERIOD), "0", recnfts1!CKYCIDPERIOD)
            End If

            recnfts1.Close()
            recnfts1 = Nothing
            objCmd.Dispose()
            objCmd = Nothing

            pstrduedate = DateAdd("m", CInt(strCKYCIDPERIOD), CDate(strkycenrolldate))
            pstrduedate = Format(CDate(pstrduedate), "dd-MMM-yyyy")
            pstrckycsno = strckycsno
        Catch ex As Exception

        End Try
    End Sub


    Public Function getCheckIMPSCycle(ByVal strPrcsCode As String, ByVal strTransAmt As String, ByRef sumamount As String, ByRef limitamount As String) As String
        Dim strSql, errmsg As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim recnfts As OracleClient.OracleDataReader
        Dim intfromtime, inttotime As String
        Dim dbllimitamt, dblamount, dblgentransamt As Double
        Dim sQuery As String
        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If


            dbllimitamt = 0 : dblamount = 0 : dblgentransamt = 0
            If strPrcsCode = "OUTWRD" Then
                sQuery = "  SELECT fromtime,totime,limitamt FROM IMPSCYCLEDTLS  WHERE TO_CHAR(SYSDATE,'HH24Mi') BETWEEN fromtime AND totime AND effdate = (SELECT MAX(effdate) FROM IMPSCYCLEDTLS  WHERE TO_CHAR(SYSDATE,'HH24Mi') BETWEEN fromtime AND totime )"

                objCmd = New OracleClient.OracleCommand(sQuery, objCon)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    intfromtime = recnfts!fromtime
                    inttotime = recnfts!totime
                    dbllimitamt = recnfts!limitamt
                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing

                sQuery = "select sum(amount) amount from gentranslog where (remarks NOT LIKE 'IMPS Charges Inclusive GST Charges%' AND  trim(remarks) NOT LIKE 'Charges Inclusive GST Charges%') AND  SUBSTR(respondingbankcode,1,6) = 'OUTWRD' AND chqfvg = 'IMPS' AND moduleid != 'ATM'  AND modeoftran IN (1,3,5) AND TO_CHAR(systemdate,'HH24Mi') between '" & intfromtime & "' and '" & inttotime & "'"

                objCmd = New OracleClient.OracleCommand(sQuery, objCon)
                recnfts = objCmd.ExecuteReader
                If recnfts.HasRows = True Then
                    recnfts.Read()
                    dblgentransamt = IIf(IsDBNull(recnfts!amount), 0, recnfts!amount)

                End If
                objCmd.Dispose()
                objCmd = Nothing
                recnfts.Close()
                recnfts = Nothing

                dblamount = Math.Abs(dblgentransamt) + CDbl(CDbl(strTransAmt) / 100)

                If dblamount > dbllimitamt Then
                    getCheckIMPSCycle = "121"
                Else
                    getCheckIMPSCycle = ""
                End If

            End If

            sumamount = dblamount : limitamount = dbllimitamt
            Exit Function
        Catch ex As Exception

        End Try
    End Function


    Public Function getNEFTMobileFrm_bnkbrhmst(ByVal strbrid As String) As String
        Dim strSql, errmsg As String
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim recnfts As OracleClient.OracleDataReader
        Dim strNEFTMobNo As String
        strNEFTMobNo = ""
        Dim sQuery As String
        Try


            If objCon.State <> ConnectionState.Open Then
                errmsg = ""
                objCon = dbCon.GetDbConnection(errmsg)
                If errmsg <> "" Then
                    Throw New Exception(errmsg)
                    Exit Function
                End If
            End If

            sQuery = " select NEFTMOBILE from genbankbranchmst where branchcode = '" & strbrid & "'"

            objCmd = New OracleClient.OracleCommand(sQuery, objCon)
            recnfts = objCmd.ExecuteReader
            If recnfts.HasRows = True Then
                recnfts.Read()
                strNEFTMobNo = recnfts!NEFTMOBILE

            End If
            objCmd.Dispose()
            objCmd = Nothing
            recnfts.Close()
            recnfts = Nothing
            getNEFTMobileFrm_bnkbrhmst = strNEFTMobNo
        Catch ex As Exception
            getNEFTMobileFrm_bnkbrhmst = ""
        End Try
    End Function



End Class
