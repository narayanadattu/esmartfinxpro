Public Class MatValue
    Dim Maturityvalue As Double
    Dim Strmsg As String, Tilldate As String
    Dim BreakDate As String, DateTill As String, DiffMonths As Double, NewROI As Double
    Dim NoOfQuarters As Double, DblDays As Double
    Dim Factor As Double
    Dim TERM As String
    Dim Prd As Integer, Year As Double, Mon As Double, Day As Double
    Dim PrincipalAmount As Double, Chkstr As Integer
    Dim Count, i, SimIntDays, Strperiod As Double
    Dim TotQuarters, intcount, RemainingDays, Intamt
    Dim dblNoOfDaysPerYear, InMonths, Monstr
    Public ConnError As String 'error object
    Public AdoConnObj As ADODB.Connection ' Connection Object
    Dim objdblink As Object
    Dim ArrLink As Object
    Dim objError As Object
    Dim ArrError As Object
    Const blnDebug As Boolean = True
    Dim ErrNum As String
    Dim errDesc As String
    Dim strComponent As String
    Dim lngdiffdays As Long
    Dim lngdiffdays1 As Long
    Dim strCompoundType As String
    Dim intDivPer As Integer

    Dim ObjOracleConnection As New OracleClient.OracleConnection
    Dim objcommand As OracleClient.OracleCommand
    Dim objDBConnection As New DatabaseConnection.cDBConnection
    Dim o_Errmsg As String

    Public Function GetMaturityvalue(ByVal Period As String, ByVal EffDate As String, _
    ByVal MatDate As String, ByVal Amount As Double, ByVal CompoundTerm As String, _
    ByVal InstalmentsYN As String, ByVal ROI As Double, Optional ByVal strpremat As String = "0") As Object


        Dim Prddtls
        Try

        
        dblNoOfDaysPerYear = 36500
        If Period = "" Then
            If EffDate = "" Or MatDate = "" Then
                GetMaturityvalue = "Error  ! Please send required parameters"
                Exit Function
            End If
        End If
        '----Either two dates or period can be given as input for Mat value Calculation---

        If EffDate <> "" And MatDate <> "" Then
            Tilldate = CDate(MatDate)
            BreakDate = CDate(EffDate)
        End If

        If Period <> "" Then
            Prddtls = Split(Period, "|")
            Year = Trim(Prddtls(0))
            Mon = Trim(Prddtls(1))
            Day = Trim(Prddtls(2))
                If Year = Nothing Then
                    Year = 0
                End If
                If Mon = Nothing Then
                    Mon = 0
                End If
                If Day = Nothing Then
                    Day = 0
                End If

                If InstalmentsYN = "N" And (CompoundTerm = "" Or CompoundTerm = "N") Then
                    'Do Simple int calculation based on given periodicity
                    Dim dblTempInt As Double

                    dblTempInt = 0

                    If Year > 0 Then
                        dblTempInt = (Amount * Year * ROI) / 100
                    End If

                    If Mon > 0 Then
                        dblTempInt = dblTempInt + ((Amount * Mon * ROI) / 1200)
                    End If

                    If Day > 0 Then
                        dblTempInt = dblTempInt + ((Amount * Day * ROI) / 36500)
                    End If

                    'Maturity value = Principal + calculated Interest
                    GetMaturityvalue = Amount + dblTempInt

                    Exit Function
                End If

                '------------------If period is send as input then-----------------------
                '------------BreakDate is assumed as this date for reference only--------
                BreakDate = CDate("1-jan-2000")
                Tilldate = DateAdd("YYYY", Year, BreakDate)
                Tilldate = DateAdd("M", Mon, Tilldate)
                Tilldate = DateAdd("D", Day, Tilldate)
                Tilldate = CDate(Tilldate)
            End If

        NewROI = ROI
        PrincipalAmount = Amount
        DblDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
        Count = 0
        DateTill = CDate(BreakDate)
        DateTill = CDate(DateTill)
        '--------Finding exact number of full months between two periods---------------
        '    For i = 1 To 1000
        '        DateTill = DateAdd("M", 1, CDate(DateTill))
        '        If CDate(DateTill) > CDate(Tilldate) Then
        '            Exit For
        '        End If
        '        Count = Count + 1
        '    Next
        '    DiffMonths = Count

        'Original Code commented by Radhika on 31 Mar 2008
        'DiffMonths = Fix(DateDiff("M", BreakDate, Tilldate))
            DiffMonths = GetMonthsDiff(CDate(BreakDate), CDate(Tilldate))


        If strpremat = "Y" Then
            lngdiffdays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
            If lngdiffdays < 365 Then
                lngdiffdays1 = DateDiff("D", CDate(BreakDate), CDate(Tilldate))

                Strperiod = lngdiffdays1 / 365

                PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
                GetMaturityvalue = CDbl(PrincipalAmount)
                Exit Function
            End If
        End If
        '-----------------------Simple Int calc------------------------------------------
        '----------If Compound term is null component calculates Simple Interest---------


        If CompoundTerm = "" And InstalmentsYN = "N" Or CompoundTerm = "N" And InstalmentsYN = "N" Then

            Strperiod = DiffMonths / 12
            BreakDate = DateAdd("M", DiffMonths, BreakDate)
            RemainingDays = DateDiff("D", CDate(BreakDate), CDate(Tilldate))
            If RemainingDays > 0 Then
                Strperiod = Strperiod + (RemainingDays / 365)
            End If
            PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * Strperiod * CDbl(NewROI) / 100)
            GetMaturityvalue = CDbl(PrincipalAmount)
            Exit Function
        End If

        '-----------------------Simple Int Calc Ends----------------------------------

        If InstalmentsYN = "Y" Then  'For Recurring Deposits
            GetMaturityvalue = CDbl(getRDMaturityValue(CDate(MatDate), CDate(EffDate), Amount, CDbl(ROI)))
        Else
            '-----------------------Compound Int Calc Starts------------------------------
            Select Case CompoundTerm
                Case "Q"    'Quarterly
                    If DiffMonths >= 3 Then
                        NoOfQuarters = DiffMonths / 3
                        Factor = 0.0025
                        TERM = "Q"
                        Prd = 1
                        Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                        GetMaturityvalue = PrincipalAmount
                    Else
                        'GetMaturityvalue = "Error  ! Period does not satisfy one Quarter"
                        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                        GetMaturityvalue = CDbl(Math.Round(PrincipalAmount))
                    End If
                Case "M"    'Monthly
                    If DiffMonths >= 1 Then
                        NoOfQuarters = DiffMonths
                        Factor = 1 / 1200
                        TERM = "M"
                        Prd = 1
                        Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                        GetMaturityvalue = PrincipalAmount
                    Else
                        'GetMaturityvalue = "Error  ! Period does not satisfy one Month"
                        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                        GetMaturityvalue = CDbl(Math.Round(PrincipalAmount))
                    End If
                Case "H"    'Half Yearly
                    If DiffMonths >= 6 Then
                        NoOfQuarters = DiffMonths / 6
                        Factor = 0.005
                        TERM = "Q"
                        Prd = 2
                        Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                        GetMaturityvalue = PrincipalAmount
                    Else
                        'GetMaturityvalue = "Error  ! Period does not satisfy one Halfyear"
                        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                        GetMaturityvalue = CDbl(Math.Round(PrincipalAmount))
                    End If
                Case "Y"    'Yearly
                    If DiffMonths >= 12 Then
                        NoOfQuarters = DiffMonths / 12
                        Factor = 0.01
                        TERM = "YYYY"
                        Prd = 1
                        Call CompCalculation(Factor, NoOfQuarters, TERM, Prd)
                        GetMaturityvalue = PrincipalAmount
                    Else
                        'GetMaturityvalue = "Error  ! Period does not satisfy one Year"
                        PrincipalAmount = CDbl(PrincipalAmount) + (CDbl(PrincipalAmount) * DblDays * CDbl(NewROI) / 36500)
                        GetMaturityvalue = CDbl(Math.Round(PrincipalAmount))
                    End If
            End Select
        End If

        

        Exit Function
        Catch ex As Exception
            GetMaturityvalue = ex.Message
        End Try

    End Function

    Private Sub CompCalculation(ByVal Fact As Double, ByVal Quarters As Double, ByVal TERM As String, ByVal Prd As Integer)

        '-------------Full period calculation------------------------------------------
        dblNoOfDaysPerYear = 36500
        For intcount = 1 To Quarters
            BreakDate = DateAdd(TERM, Prd, CDate(BreakDate))
            Intamt = CDbl(PrincipalAmount) * CDbl(NewROI) * Fact
            PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
        Next
        '-------------Remaining Months calculation--------------------------------------
        Count = 0
        DateTill = BreakDate
        For i = 1 To 1000
            DateTill = DateAdd("M", 1, DateTill)
            If CDate(DateTill) > CDate(Tilldate) Then
                Exit For
            End If
            Count = Count + 1
        Next
        InMonths = Count
        BreakDate = DateAdd("M", InMonths, BreakDate)
        PrincipalAmount = CDbl(PrincipalAmount) + ((CDbl(PrincipalAmount) * (InMonths / 12) * CDbl(NewROI)) / 100)
        '-------------Remaining Days calculation----------------------

        RemainingDays = DateDiff("D", BreakDate, Tilldate)
        If RemainingDays > 0 Then
            Intamt = (CDbl(PrincipalAmount) * CDbl(NewROI) * _
                           CDbl(RemainingDays)) / CDbl(dblNoOfDaysPerYear)
            PrincipalAmount = CDbl(PrincipalAmount) + CDbl(Intamt)
        End If

    End Sub

    Private Function GetMonthsDiff(ByVal i_FromDt As Date, ByVal i_ToDt As Date) As Integer
        'Dim objCon As New OracleClient.OracleConnection
        'Dim objCmd As New OracleClient.OracleCommand
        'Dim dbCon As New DatabaseConnection.cDBConnection
        'Dim errmsg, strSql As String
        'Dim dr_Gen As OracleClient.OracleDataReader


        '    If objCon.State <> ConnectionState.Open Then
        '        errmsg = ""
        '        objCon = dbCon.GetDbConnection(errmsg)
        '        If errmsg <> "" Then
        '            Throw New Exception(errmsg)
        '            Exit Function
        '        End If
        '    End If

        '    If i_FromDt > i_ToDt Then
        '        Throw New Exception("To Date Should be greater than From Date to get Months Difference")
        '    End If

        '    strSql = "Select floor(months_between('" & _
        'Format(i_ToDt, "dd-MMM-yyyy") & "', '" & Format(i_FromDt, "dd-MMM-yyyy") _
        '& "')) mon from dual"


        '    objCmd = New OracleClient.OracleCommand(strSql, objCon)

        '    dr_Gen = objCmd.ExecuteReader
        '    objCmd.Dispose()
        '    objCmd = Nothing

        '    If dr_Gen.HasRows = True Then
        '        dr_Gen.Read()
        '        GetMonthsDiff = IIf(IsDBNull(dr_Gen!mon), "", dr_Gen!mon)
        '    Else
        '        Throw New Exception("Unable to Get Months Difference between given Dates")
        '    End If
        '    dr_Gen.Close()
        '    dr_Gen = Nothing
        GetMonthsDiff = 0
        GetMonthsDiff = Math.Floor(DateDiff(DateInterval.Month, i_FromDt, i_ToDt))

    End Function


    Private Function getRDMaturityValue(ByVal MaturityDate As Date, _
    ByVal IntEffectiveDate As Date, _
    ByVal InstalmentAmt As Double, _
    ByVal ROI As Single) As Double
        Dim NoOfQuarters As Integer
        Dim FirstQuarterAmt As Double
        Dim RemainingDays As Integer
        'If Not IsDate(MaturityDate) Or Not IsDate(IntEffectiveDate) Then
        'MsgBox "Either Maturity date or Interest Effective Date is null." & Chr(13) & _
        '       "System cannot calculate Maturity Amount", vbInformation
        'Exit Function
        'End If
        'New formula is Introduced on 18-01-2003 don't change this formula without informing to the project manager
        'Code altered by Radhika on 29 Mar 2008
        'Reason: Date difference in Months not giving correct value
        'NoOfQuarters = Fix(DateDiff("M", IntEffectiveDate, MaturityDate) / 3)

        '''THIS CODE ADDED BY VINOD FOR RECURRING DEPOSIT CALCULATION

        '    Dim strCompoundType As String
        Dim intPer As Integer
        'Dim intDivPer As Integer
        Dim objCon As New OracleClient.OracleConnection
        Dim objCmd As New OracleClient.OracleCommand
        Dim dbCon As New DatabaseConnection.cDBConnection
        Dim errmsg, strSql As String
        Dim dr_Gen As OracleClient.OracleDataReader

        If objCon.State <> ConnectionState.Open Then
            errmsg = ""
            objCon = dbCon.GetDbConnection(errmsg)
            If errmsg <> "" Then
                Throw New Exception(errmsg)
                Exit Function
            End If
        End If

        strSql = "SELECT NVL(INTCOMPOUNDYN,'N') COMYN FROM DEPTYPEMST WHERE INSTSYN='Y'"

        objCmd = New OracleClient.OracleCommand(strSql, objCon)
        dr_Gen = objCmd.ExecuteReader
        objCmd.Dispose()
        objCmd = Nothing

        If dr_Gen.HasRows = True Then
            dr_Gen.Read()
            strCompoundType = IIf(IsDBNull(dr_Gen!COMYN), "", dr_Gen!COMYN)
        Else
            Throw New Exception("Unable to Get Compound Yes or No.")
        End If
        dr_Gen.Close()
        dr_Gen = Nothing

        'If rsTmp.RecordCount = 0 Then
        '    Err.Raise(999, , "Unable to Get Compound Yes or No.")
        'End If


        If strCompoundType = "M" Then
            intPer = 1
            intDivPer = 1200
        ElseIf strCompoundType = "Q" Then
            intPer = 3
            intDivPer = 400
        ElseIf strCompoundType = "H" Then
            intPer = 6
            intDivPer = 200
        ElseIf strCompoundType = "Y" Then
            intPer = 12
            intDivPer = 100
        End If

        '''THIS CODE ADDED BY VINOD FOR RECURRING DEPOSIT CALCULATION CODE ENDED HERE

        Dim intMonths As Integer
        intMonths = GetMonthsDiff(CDate(IntEffectiveDate), CDate(MaturityDate))
        NoOfQuarters = Fix(intMonths / intPer)

        RemainingDays = DateDiff("D", DateAdd("M", NoOfQuarters * intPer, IntEffectiveDate), MaturityDate)
        FirstQuarterAmt = InstalmentAmt * (intPer + ROI / intDivPer)

        If strCompoundType = "M" Then
            getRDMaturityValue = getRDCompundedValue(NoOfQuarters, FirstQuarterAmt, ROI)
        Else
            getRDMaturityValue = RDCompoundCalculation(intMonths, strCompoundType, InstalmentAmt, ROI)
        End If

        'If RemainingDays > 0 Then
        'getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * 31 * ROI / 36500)
        'End If

        'If RemainingDays > 31 Then
        '   getRDMaturityValue = (getRDMaturityValue + InstalmentAmt) + ((getRDMaturityValue + InstalmentAmt) * (RemainingDays - 31) * ROI / 36500)
        'End If

        'After Quarter, Calculate Simple Interest and add it.



        'New formula Ends here
    End Function
    Private Function getRDCompundedValue(ByVal Quarter As Integer, _
    ByVal InstalmentAmt As Double, _
    ByVal ROI As Single) As Double
        Dim SubTotal As Double
        If Quarter <= 0 Then getRDCompundedValue = 0 : Exit Function
        SubTotal = InstalmentAmt * (1 + ROI / intDivPer) ^ (Quarter - 1) + _
                   getRDCompundedValue(Quarter - 1, InstalmentAmt, ROI)
        getRDCompundedValue = SubTotal
    End Function

    Private Function RDCompoundCalculation(ByVal Months As Integer, ByVal perType As String, ByVal Amount As Double, ByVal ROI As Single) As Double

        Dim subAmount As Double
        Dim dblInstlAmt As Double
        Dim dblInt As Double
        Dim intInstallments As Integer
        Dim intAddInstal As Integer

        intAddInstal = 0
        If perType = "Q" Then
            intInstallments = 3
            intAddInstal = 3
        ElseIf perType = "H" Then
            intInstallments = 6
            intAddInstal = 6
        ElseIf perType = "Y" Then
            intInstallments = 12
            intAddInstal = 12
        End If

        dblInstlAmt = 0
        dblInt = 0

        For i = 1 To Months

            dblInstlAmt = dblInstlAmt + Amount

            If i = Months And (Months Mod intAddInstal) <> 0 Then
                dblInt = (dblInstlAmt * (1 / 12) * ROI) / 100
            Else
                dblInt = dblInt + (dblInstlAmt * (1 / 12) * ROI) / 100
            End If

            If i = intInstallments And i < Months Then
                dblInstlAmt = dblInstlAmt + dblInt + Amount
                dblInt = (dblInstlAmt * (1 / 12) * ROI) / 100
                intInstallments = intInstallments + intAddInstal
                i = i + 1
            End If
        Next

        RDCompoundCalculation = dblInstlAmt + dblInt
    End Function

End Class
